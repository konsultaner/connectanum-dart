//! Tokio based runtime that backs the connectanum native transport.

use std::{
    collections::{HashMap, HashSet, VecDeque},
    fs::File,
    io::{self, Cursor, Write},
    net::{IpAddr, SocketAddr, ToSocketAddrs},
    ops::Deref,
    pin::Pin,
    sync::{
        atomic::{AtomicBool, AtomicI64, AtomicU32, AtomicU64, Ordering},
        Arc, Mutex, OnceLock, RwLock,
    },
    task::{Context, Poll},
    time::{Duration, Instant},
};

use base64::{engine::general_purpose::STANDARD as Base64Engine, Engine as _};
use bytes::{Buf, Bytes, BytesMut};
use h2::{
    server::{self as h2_server, SendResponse as H2SendResponse},
    Error as H2Error, RecvStream as H2RecvStream,
};
use h3::{quic::BidiStream as H3BidiStreamTrait, server::RequestStream as H3RequestStream};
use h3_quinn::Connection as H3QuinnConnection;
use http::{
    header::{HeaderName as Http2HeaderName, HeaderValue as Http2HeaderValue},
    Request as Http2Request, Response as Http2Response, StatusCode as Http2StatusCode,
};
use http::{
    header::{HeaderName, HeaderValue, CONTENT_LENGTH},
    Request as HttpRequest, Response as HttpResponse, StatusCode,
};
use sha1::{Digest, Sha1};
use thiserror::Error;
use tokio::{
    io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt, BufReader},
    runtime::Runtime,
    sync::{
        mpsc::{
            self,
            error::{TryRecvError, TrySendError},
            UnboundedReceiver, UnboundedSender,
        },
        oneshot, OwnedSemaphorePermit, Semaphore,
    },
    task::{AbortHandle, JoinHandle, JoinSet},
    time,
};
use tokio_rustls::TlsAcceptor;

use crate::http_body::{spawn_http1_streaming_body, Http1BodyReclaim, StreamingError};
use crate::io_stream::{IoReadHalf, IoStream, IoWriteHalf};

mod config;
mod http1_stream;
#[cfg(test)]
mod http3_admission_tests;
mod http_body;
mod http_stream;
#[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
mod idle_allocator;
mod io_stream;
mod ktls;
mod platform;
mod protocol;
mod rawsocket;
mod tls;
mod wamp;
mod write_completion;
#[cfg(test)]
mod write_completion_tests;
use write_completion::WriteGuard;
pub use write_completion::{WriteOutcome, WriteReceipt};

use config::{HttpRouteMatch, TransportProtocol};
use quinn::{
    Connection as QuinnConnection, Endpoint as QuinnEndpoint, ServerConfig as QuinnServerConfig,
    VarInt,
};
use quinn_proto::crypto::rustls::QuicServerConfig as QuinnRustlsServerConfig;
use rand::RngCore;
use rustls::{
    pki_types::{CertificateDer, PrivateKeyDer, ServerName},
    ServerConfig as RustlsServerConfig,
};
use rustls_pemfile::{certs as load_certs, pkcs8_private_keys, rsa_private_keys};

type H3QuicBidiStream = h3_quinn::BidiStream<Bytes>;
type H3ServerStream<S> = H3RequestStream<S, Bytes>;
type H3ServerBidiStream = H3ServerStream<H3QuicBidiStream>;
type H3ServerSendStream =
    H3ServerStream<<H3QuicBidiStream as H3BidiStreamTrait<Bytes>>::SendStream>;
type H3ServerRecvStream =
    H3ServerStream<<H3QuicBidiStream as H3BidiStreamTrait<Bytes>>::RecvStream>;

const HTTP_STREAM_IDLE_FALLBACK: Duration = Duration::from_secs(10);
const HTTP_STREAM_TOTAL_FALLBACK: Duration = Duration::from_secs(40);
// Preserve a normal WebSocket Close frame without pinning queued/native owners
// indefinitely when the peer stops reading during local close.
const WEBSOCKET_CLOSE_GRACE: Duration = Duration::from_secs(1);
const HTTP_STREAM_TOTAL_MULTIPLIER: u32 = 4;
const HTTP2_MAX_CONCURRENT_STREAMS: u32 = 1024;
const HTTP2_INITIAL_STREAM_WINDOW: u32 = 8 * 1024 * 1024;
const HTTP2_INITIAL_CONNECTION_WINDOW: u32 = 64 * 1024 * 1024;
const HTTP2_MAX_FRAME_SIZE: u32 = 1 * 1024 * 1024;
const HTTP2_MAX_HEADER_LIST_SIZE: u32 = 16 * 1024 * 1024;
const HTTP2_MAX_CONCURRENT_RESET_STREAMS: usize = 256;
const HTTP2_MAX_SEND_BUFFER_SIZE: usize = 8 * 1024 * 1024;
const HTTP3_MAX_BIDI_STREAMS: u32 = 1024;
const HTTP3_MAX_UNI_STREAMS: u32 = 256;
const HTTP3_STREAM_RECEIVE_WINDOW: u32 = 8 * 1024 * 1024;
const HTTP3_CONNECTION_RECEIVE_WINDOW: u32 = 64 * 1024 * 1024;
const HTTP3_SEND_WINDOW: u64 = 64 * 1024 * 1024;
const HTTP3_DATAGRAM_BUFFER_BYTES: usize = 8 * 1024 * 1024;
const HTTP3_KEEP_ALIVE_INTERVAL: Duration = Duration::from_secs(5);
const WEBSOCKET_MASK_CHUNK_SIZE: usize = 1024 * 1024;
const WEBSOCKET_COALESCE_FRAME_SIZE: usize = 64 * 1024;
const FILE_SEGMENT_BUFFER_SIZE: usize = 4 * 1024 * 1024;
const BASE64_FILE_SEGMENT_INPUT_SIZE: usize =
    FILE_SEGMENT_BUFFER_SIZE - (FILE_SEGMENT_BUFFER_SIZE % 3);
const RESPONSE_STREAM_SLOW_PATH_1MS_US: u64 = 1_000;
const RESPONSE_STREAM_SLOW_PATH_5MS_US: u64 = 5_000;
const RESPONSE_STREAM_SLOW_PATH_10MS_US: u64 = 10_000;

#[cfg(feature = "ffi-test")]
fn ffi_test_debug_logs_enabled() -> bool {
    std::env::var_os("CONNECTANUM_FFI_TEST_DEBUG").is_some()
}

fn http_stream_timeouts(config: &config::EndpointRuntimeConfig) -> (Duration, Duration) {
    let idle = config.idle_timeout.unwrap_or(HTTP_STREAM_IDLE_FALLBACK);
    let total = idle
        .checked_mul(HTTP_STREAM_TOTAL_MULTIPLIER)
        .unwrap_or(HTTP_STREAM_TOTAL_FALLBACK);
    let total = if total.is_zero() {
        HTTP_STREAM_TOTAL_FALLBACK
    } else {
        total
    };
    (idle, total)
}

pub use config::{EndpointRuntimeConfig, HttpRouteResolution};
pub use http1_stream::HttpBodyPhase;
pub use http_body::StreamingBodyState;
pub use http_stream::{
    response_stream_channel, ResponseStreamError, ResponseStreamFrame, ResponseStreamReader,
    ResponseStreamWriter, RESPONSE_STREAM_BUFFER,
};

/// Reasons describing why an HTTP/2 or HTTP/3 connection closed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpConnectionCloseReason {
    Graceful,
    GoAway,
    IdleTimeout,
    BodyTimeout,
    ProtocolError,
    Internal,
}

/// Lifecycle event emitted whenever an HTTP/2 or HTTP/3 connection terminates.
#[derive(Debug, Clone)]
pub struct HttpConnectionEvent {
    pub connection_id: ConnectionId,
    pub protocol: ConnectionProtocol,
    pub reason: HttpConnectionCloseReason,
    pub request_count: u32,
    pub idle_timeouts: u32,
    pub body_timeouts: u32,
    pub backpressure_events: u32,
    pub max_backpressure_depth: u32,
    pub goaway_events: u32,
    pub detail: Option<String>,
}

#[derive(Debug)]
struct HttpConnectionStats {
    protocol: ConnectionProtocol,
    requests: AtomicU32,
    idle_timeouts: AtomicU32,
    body_timeouts: AtomicU32,
    backpressure_events: AtomicU32,
    max_backpressure_depth: AtomicU32,
    goaway_events: AtomicU32,
    close_reason: Mutex<Option<(HttpConnectionCloseReason, Option<String>)>>,
}

impl HttpConnectionStats {
    fn new(protocol: ConnectionProtocol) -> Arc<Self> {
        Arc::new(Self {
            protocol,
            requests: AtomicU32::new(0),
            idle_timeouts: AtomicU32::new(0),
            body_timeouts: AtomicU32::new(0),
            backpressure_events: AtomicU32::new(0),
            max_backpressure_depth: AtomicU32::new(0),
            goaway_events: AtomicU32::new(0),
            close_reason: Mutex::new(None),
        })
    }

    fn record_request(&self) {
        self.requests.fetch_add(1, Ordering::SeqCst);
    }

    fn record_idle_timeout(&self, detail: Option<String>) {
        self.idle_timeouts.fetch_add(1, Ordering::SeqCst);
        self.set_close_reason(HttpConnectionCloseReason::IdleTimeout, detail);
    }

    fn record_body_timeout(&self, detail: Option<String>) {
        self.body_timeouts.fetch_add(1, Ordering::SeqCst);
        self.set_close_reason(HttpConnectionCloseReason::BodyTimeout, detail);
    }

    fn record_backpressure(&self, depth: usize) {
        self.backpressure_events.fetch_add(1, Ordering::SeqCst);
        let depth_u32 = depth.min(u32::MAX as usize) as u32;
        let _ = self.max_backpressure_depth.fetch_update(
            Ordering::SeqCst,
            Ordering::SeqCst,
            |current| {
                if depth_u32 > current {
                    Some(depth_u32)
                } else {
                    None
                }
            },
        );
    }

    fn record_goaway(&self, detail: Option<String>) {
        self.goaway_events.fetch_add(1, Ordering::SeqCst);
        self.set_close_reason(HttpConnectionCloseReason::GoAway, detail);
    }

    fn set_close_reason(&self, reason: HttpConnectionCloseReason, detail: Option<String>) {
        let mut guard = self.close_reason.lock().unwrap();
        if guard.is_none() {
            *guard = Some((reason, detail));
        }
    }

    fn finalize(
        &self,
        connection_id: ConnectionId,
        fallback_reason: HttpConnectionCloseReason,
        fallback_detail: Option<String>,
    ) -> HttpConnectionEvent {
        let stored = self.close_reason.lock().unwrap().take();
        let (reason, detail) = stored.unwrap_or((fallback_reason, fallback_detail));
        HttpConnectionEvent {
            connection_id,
            protocol: self.protocol,
            reason,
            request_count: self.requests.load(Ordering::SeqCst),
            idle_timeouts: self.idle_timeouts.load(Ordering::SeqCst),
            body_timeouts: self.body_timeouts.load(Ordering::SeqCst),
            backpressure_events: self.backpressure_events.load(Ordering::SeqCst),
            max_backpressure_depth: self.max_backpressure_depth.load(Ordering::SeqCst),
            goaway_events: self.goaway_events.load(Ordering::SeqCst),
            detail,
        }
    }
}

#[derive(Default)]
struct HttpMetrics {
    total_events: AtomicU64,
    graceful: AtomicU64,
    goaway: AtomicU64,
    idle_timeouts: AtomicU64,
    body_timeouts: AtomicU64,
    protocol_errors: AtomicU64,
    internal_errors: AtomicU64,
    backpressure_events: AtomicU64,
    max_backpressure_depth: AtomicU32,
}

#[derive(Default)]
struct FileSegmentMetrics {
    rawsocket_zero_copy_calls_total: AtomicU64,
    rawsocket_zero_copy_bytes_total: AtomicU64,
    buffered_file_segment_calls_total: AtomicU64,
    buffered_file_segment_bytes_total: AtomicU64,
}

#[derive(Default)]
struct TransportCopyMetrics {
    websocket_mask_copy_bytes_total: AtomicU64,
    websocket_coalesce_copy_bytes_total: AtomicU64,
    tls_plaintext_accepted_bytes_total: AtomicU64,
    io_buffer_front_copy_bytes_total: AtomicU64,
    io_buffered_read_copy_bytes_total: AtomicU64,
}

#[derive(Default)]
struct HttpResponseStreamMetrics {
    streaming_responses_total: AtomicU64,
    stream_open_to_headers_send_samples_total: AtomicU64,
    stream_open_to_headers_send_us_total: AtomicU64,
    headers_send_call_samples_total: AtomicU64,
    headers_send_call_us_total: AtomicU64,
    headers_to_first_connection_write_samples_total: AtomicU64,
    headers_to_first_connection_write_us_total: AtomicU64,
    headers_to_first_connection_write_ge_1ms_total: AtomicU64,
    headers_to_first_connection_write_ge_5ms_total: AtomicU64,
    headers_to_first_connection_write_ge_10ms_total: AtomicU64,
    first_chunk_channel_wait_samples_total: AtomicU64,
    first_chunk_channel_wait_us_total: AtomicU64,
    first_chunk_channel_wait_ge_1ms_total: AtomicU64,
    first_chunk_channel_wait_ge_5ms_total: AtomicU64,
    first_chunk_channel_wait_ge_10ms_total: AtomicU64,
    headers_to_first_chunk_dequeue_samples_total: AtomicU64,
    headers_to_first_chunk_dequeue_us_total: AtomicU64,
    headers_to_first_chunk_dequeue_ge_1ms_total: AtomicU64,
    headers_to_first_chunk_dequeue_ge_5ms_total: AtomicU64,
    headers_to_first_chunk_dequeue_ge_10ms_total: AtomicU64,
    first_chunk_send_call_samples_total: AtomicU64,
    first_chunk_send_call_us_total: AtomicU64,
    first_chunk_send_call_ge_1ms_total: AtomicU64,
    first_chunk_send_call_ge_5ms_total: AtomicU64,
    first_chunk_send_call_ge_10ms_total: AtomicU64,
    headers_to_first_chunk_send_call_samples_total: AtomicU64,
    headers_to_first_chunk_send_call_us_total: AtomicU64,
    tail_chunk_channel_wait_samples_total: AtomicU64,
    tail_chunk_channel_wait_us_total: AtomicU64,
    tail_chunk_channel_wait_ge_1ms_total: AtomicU64,
    tail_chunk_channel_wait_ge_5ms_total: AtomicU64,
    tail_chunk_channel_wait_ge_10ms_total: AtomicU64,
    tail_chunk_send_call_samples_total: AtomicU64,
    tail_chunk_send_call_us_total: AtomicU64,
    tail_chunk_send_call_ge_1ms_total: AtomicU64,
    tail_chunk_send_call_ge_5ms_total: AtomicU64,
    tail_chunk_send_call_ge_10ms_total: AtomicU64,
    first_to_last_chunk_send_samples_total: AtomicU64,
    first_to_last_chunk_send_us_total: AtomicU64,
    first_to_last_chunk_send_ge_1ms_total: AtomicU64,
    first_to_last_chunk_send_ge_5ms_total: AtomicU64,
    first_to_last_chunk_send_ge_10ms_total: AtomicU64,
}

#[derive(Default)]
struct HttpRequestBodyStreamMetrics {
    streaming_requests_total: AtomicU64,
    data_chunk_samples_total: AtomicU64,
    data_chunk_wait_us_total: AtomicU64,
    first_chunk_wait_samples_total: AtomicU64,
    first_chunk_wait_us_total: AtomicU64,
    second_chunk_wait_samples_total: AtomicU64,
    second_chunk_wait_us_total: AtomicU64,
    remaining_tail_read_samples_total: AtomicU64,
    remaining_tail_read_us_total: AtomicU64,
    remaining_tail_data_wait_samples_total: AtomicU64,
    remaining_tail_data_wait_us_total: AtomicU64,
    remaining_tail_data_wait_max_us_total: AtomicU64,
    remaining_tail_data_wait_max_event_index_total: AtomicU64,
    remaining_tail_data_wait_max_bytes_before_total: AtomicU64,
    remaining_tail_data_wait_max_bytes_after_total: AtomicU64,
    remaining_tail_data_wait_max_eof_total: AtomicU64,
    remaining_tail_data_wait_max_available_capacity_before_total: AtomicI64,
    remaining_tail_data_wait_max_used_capacity_before_total: AtomicU64,
    remaining_tail_data_wait_max_available_capacity_after_data_total: AtomicI64,
    remaining_tail_data_wait_max_used_capacity_after_data_total: AtomicU64,
    remaining_tail_data_wait_max_available_capacity_after_release_total: AtomicI64,
    remaining_tail_data_wait_max_used_capacity_after_release_total: AtomicU64,
    total_read_samples_total: AtomicU64,
    total_read_us_total: AtomicU64,
}

#[derive(Debug, Clone, Copy, Default)]
struct HttpRequestBodyFlowControlSample {
    available_capacity: i64,
    used_capacity: u64,
}

#[derive(Debug, Clone, Copy, Default)]
struct HttpRequestBodyTailDataWaitMax {
    wait_us: u64,
    event_index: u64,
    bytes_before: u64,
    bytes_after: u64,
    eof: bool,
    flow_before_wait: HttpRequestBodyFlowControlSample,
    flow_after_data: HttpRequestBodyFlowControlSample,
    flow_after_release: HttpRequestBodyFlowControlSample,
}

impl HttpRequestBodyTailDataWaitMax {
    fn observe(
        &mut self,
        wait_us: u64,
        event_index: u64,
        bytes_before: u64,
        bytes_after: u64,
        eof: bool,
        flow_before_wait: HttpRequestBodyFlowControlSample,
        flow_after_data: HttpRequestBodyFlowControlSample,
        flow_after_release: HttpRequestBodyFlowControlSample,
    ) {
        if wait_us >= self.wait_us {
            *self = Self {
                wait_us,
                event_index,
                bytes_before,
                bytes_after,
                eof,
                flow_before_wait,
                flow_after_data,
                flow_after_release,
            };
        }
    }
}

#[derive(Debug, Clone, Copy, Default)]
pub struct HttpMetricsSnapshot {
    pub total_events: u64,
    pub graceful_events: u64,
    pub goaway_events: u64,
    pub idle_timeout_events: u64,
    pub body_timeout_events: u64,
    pub protocol_error_events: u64,
    pub internal_error_events: u64,
    pub backpressure_events: u64,
    pub max_backpressure_depth: u32,
}

#[derive(Debug, Clone, Copy, Default)]
pub struct FileSegmentMetricsSnapshot {
    pub rawsocket_zero_copy_calls_total: u64,
    pub rawsocket_zero_copy_bytes_total: u64,
    pub buffered_file_segment_calls_total: u64,
    pub buffered_file_segment_bytes_total: u64,
}

#[derive(Debug, Clone, Copy, Default)]
pub struct TransportCopyMetricsSnapshot {
    /// Payload bytes copied into WebSocket masking scratch buffers. In-place
    /// XOR and subsequent socket writes are not counted as additional copies.
    pub websocket_mask_copy_bytes_total: u64,
    /// Payload bytes copied into unmasked WebSocket frame/coalescing buffers.
    /// Frame headers are excluded.
    pub websocket_coalesce_copy_bytes_total: u64,
    /// Plaintext bytes accepted by Rustls writers. This counts input volume,
    /// not memory copies performed while encrypting or buffering it.
    pub tls_plaintext_accepted_bytes_total: u64,
    /// Bytes copied while staging/rebuilding prefetched transport input.
    pub io_buffer_front_copy_bytes_total: u64,
    /// Prefetched bytes copied into the caller's read buffer.
    pub io_buffered_read_copy_bytes_total: u64,
}

/// Process-wide observations at two audited Rustls byte-copy sites.
///
/// This is partial TLS coverage. Record assembly, deframer movement, capacity
/// growth and crypto-wrapper copies are not included. Concurrent TLS sessions
/// contribute to these counters; deltas are not per-connection measurements.
pub fn rustls_copy_metrics_snapshot() -> rustls::copy_observer::Snapshot {
    rustls::copy_observer::snapshot()
}

#[derive(Debug, Clone, Copy, Default)]
pub struct HttpResponseStreamMetricsSnapshot {
    pub streaming_responses_total: u64,
    pub stream_open_to_headers_send_samples_total: u64,
    pub stream_open_to_headers_send_us_total: u64,
    pub headers_send_call_samples_total: u64,
    pub headers_send_call_us_total: u64,
    pub headers_to_first_connection_write_samples_total: u64,
    pub headers_to_first_connection_write_us_total: u64,
    pub headers_to_first_connection_write_ge_1ms_total: u64,
    pub headers_to_first_connection_write_ge_5ms_total: u64,
    pub headers_to_first_connection_write_ge_10ms_total: u64,
    pub first_chunk_channel_wait_samples_total: u64,
    pub first_chunk_channel_wait_us_total: u64,
    pub first_chunk_channel_wait_ge_1ms_total: u64,
    pub first_chunk_channel_wait_ge_5ms_total: u64,
    pub first_chunk_channel_wait_ge_10ms_total: u64,
    pub headers_to_first_chunk_dequeue_samples_total: u64,
    pub headers_to_first_chunk_dequeue_us_total: u64,
    pub headers_to_first_chunk_dequeue_ge_1ms_total: u64,
    pub headers_to_first_chunk_dequeue_ge_5ms_total: u64,
    pub headers_to_first_chunk_dequeue_ge_10ms_total: u64,
    pub first_chunk_send_call_samples_total: u64,
    pub first_chunk_send_call_us_total: u64,
    pub first_chunk_send_call_ge_1ms_total: u64,
    pub first_chunk_send_call_ge_5ms_total: u64,
    pub first_chunk_send_call_ge_10ms_total: u64,
    pub headers_to_first_chunk_send_call_samples_total: u64,
    pub headers_to_first_chunk_send_call_us_total: u64,
    pub tail_chunk_channel_wait_samples_total: u64,
    pub tail_chunk_channel_wait_us_total: u64,
    pub tail_chunk_channel_wait_ge_1ms_total: u64,
    pub tail_chunk_channel_wait_ge_5ms_total: u64,
    pub tail_chunk_channel_wait_ge_10ms_total: u64,
    pub tail_chunk_send_call_samples_total: u64,
    pub tail_chunk_send_call_us_total: u64,
    pub tail_chunk_send_call_ge_1ms_total: u64,
    pub tail_chunk_send_call_ge_5ms_total: u64,
    pub tail_chunk_send_call_ge_10ms_total: u64,
    pub first_to_last_chunk_send_samples_total: u64,
    pub first_to_last_chunk_send_us_total: u64,
    pub first_to_last_chunk_send_ge_1ms_total: u64,
    pub first_to_last_chunk_send_ge_5ms_total: u64,
    pub first_to_last_chunk_send_ge_10ms_total: u64,
}

#[derive(Debug, Clone, Copy, Default)]
pub struct HttpRequestBodyStreamMetricsSnapshot {
    pub streaming_requests_total: u64,
    pub data_chunk_samples_total: u64,
    pub data_chunk_wait_us_total: u64,
    pub first_chunk_wait_samples_total: u64,
    pub first_chunk_wait_us_total: u64,
    pub second_chunk_wait_samples_total: u64,
    pub second_chunk_wait_us_total: u64,
    pub remaining_tail_read_samples_total: u64,
    pub remaining_tail_read_us_total: u64,
    pub remaining_tail_data_wait_samples_total: u64,
    pub remaining_tail_data_wait_us_total: u64,
    pub remaining_tail_data_wait_max_us_total: u64,
    pub remaining_tail_data_wait_max_event_index_total: u64,
    pub remaining_tail_data_wait_max_bytes_before_total: u64,
    pub remaining_tail_data_wait_max_bytes_after_total: u64,
    pub remaining_tail_data_wait_max_eof_total: u64,
    pub remaining_tail_data_wait_max_available_capacity_before_total: i64,
    pub remaining_tail_data_wait_max_used_capacity_before_total: u64,
    pub remaining_tail_data_wait_max_available_capacity_after_data_total: i64,
    pub remaining_tail_data_wait_max_used_capacity_after_data_total: u64,
    pub remaining_tail_data_wait_max_available_capacity_after_release_total: i64,
    pub remaining_tail_data_wait_max_used_capacity_after_release_total: u64,
    pub total_read_samples_total: u64,
    pub total_read_us_total: u64,
}

#[derive(Debug, Clone)]
pub struct HttpMetricsBreakdownSnapshot {
    pub listener_id: ListenerId,
    pub protocol: ConnectionProtocol,
    pub snapshot: HttpMetricsSnapshot,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
struct HttpMetricsKey {
    listener_id: ListenerId,
    protocol: ConnectionProtocol,
}

#[derive(Default)]
struct HttpMetricsStore {
    totals: HttpMetrics,
    by_key: Mutex<HashMap<HttpMetricsKey, Arc<HttpMetrics>>>,
}

#[derive(Default)]
struct Http2ConnectionWriteTracker {
    pending_headers_sent_at: Mutex<VecDeque<Instant>>,
}

struct InstrumentedHttp2IoStream {
    inner: IoStream,
    write_tracker: Arc<Http2ConnectionWriteTracker>,
}

static HTTP_RESPONSE_STREAM_METRICS: OnceLock<HttpResponseStreamMetrics> = OnceLock::new();
static HTTP_REQUEST_BODY_STREAM_METRICS: OnceLock<HttpRequestBodyStreamMetrics> = OnceLock::new();

impl HttpMetrics {
    fn record(&self, event: &HttpConnectionEvent) {
        self.total_events.fetch_add(1, Ordering::SeqCst);
        self.backpressure_events
            .fetch_add(event.backpressure_events as u64, Ordering::SeqCst);
        let depth = event.max_backpressure_depth;
        if depth > 0 {
            let _ = self.max_backpressure_depth.fetch_update(
                Ordering::SeqCst,
                Ordering::SeqCst,
                |current| {
                    if depth > current {
                        Some(depth)
                    } else {
                        None
                    }
                },
            );
        }
        match event.reason {
            HttpConnectionCloseReason::Graceful => {
                self.graceful.fetch_add(1, Ordering::SeqCst);
            }
            HttpConnectionCloseReason::GoAway => {
                self.goaway.fetch_add(1, Ordering::SeqCst);
            }
            HttpConnectionCloseReason::IdleTimeout => {
                self.idle_timeouts.fetch_add(1, Ordering::SeqCst);
            }
            HttpConnectionCloseReason::BodyTimeout => {
                self.body_timeouts.fetch_add(1, Ordering::SeqCst);
            }
            HttpConnectionCloseReason::ProtocolError => {
                self.protocol_errors.fetch_add(1, Ordering::SeqCst);
            }
            HttpConnectionCloseReason::Internal => {
                self.internal_errors.fetch_add(1, Ordering::SeqCst);
            }
        }
    }

    fn snapshot(&self) -> HttpMetricsSnapshot {
        HttpMetricsSnapshot {
            total_events: self.total_events.load(Ordering::SeqCst),
            graceful_events: self.graceful.load(Ordering::SeqCst),
            goaway_events: self.goaway.load(Ordering::SeqCst),
            idle_timeout_events: self.idle_timeouts.load(Ordering::SeqCst),
            body_timeout_events: self.body_timeouts.load(Ordering::SeqCst),
            protocol_error_events: self.protocol_errors.load(Ordering::SeqCst),
            internal_error_events: self.internal_errors.load(Ordering::SeqCst),
            backpressure_events: self.backpressure_events.load(Ordering::SeqCst),
            max_backpressure_depth: self.max_backpressure_depth.load(Ordering::SeqCst),
        }
    }
}

impl HttpMetricsStore {
    fn record(&self, listener_id: ListenerId, event: &HttpConnectionEvent) {
        self.totals.record(event);
        let metrics = {
            let mut guard = self
                .by_key
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            guard
                .entry(HttpMetricsKey {
                    listener_id,
                    protocol: event.protocol,
                })
                .or_insert_with(|| Arc::new(HttpMetrics::default()))
                .clone()
        };
        metrics.record(event);
    }

    fn totals_snapshot(&self) -> HttpMetricsSnapshot {
        self.totals.snapshot()
    }

    fn snapshot_with_breakdown(&self) -> (HttpMetricsSnapshot, Vec<HttpMetricsBreakdownSnapshot>) {
        let totals = self.totals_snapshot();
        let guard = self
            .by_key
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let mut breakdown = Vec::with_capacity(guard.len());
        for (key, metrics) in guard.iter() {
            breakdown.push(HttpMetricsBreakdownSnapshot {
                listener_id: key.listener_id,
                protocol: key.protocol,
                snapshot: metrics.snapshot(),
            });
        }
        breakdown.sort_by(|left, right| {
            (left.listener_id.0, protocol_sort_key(left.protocol))
                .cmp(&(right.listener_id.0, protocol_sort_key(right.protocol)))
        });
        (totals, breakdown)
    }
}

impl HttpResponseStreamMetrics {
    fn record_streaming_response(&self) {
        self.streaming_responses_total
            .fetch_add(1, Ordering::SeqCst);
    }

    fn record_headers_sent(
        &self,
        stream_opened_at: Instant,
        headers_send_call_started_at: Instant,
        headers_send_call_finished_at: Instant,
    ) {
        let stream_open_to_headers_send_us =
            saturating_instant_delta_us(stream_opened_at, headers_send_call_finished_at);
        let headers_send_call_us = saturating_instant_delta_us(
            headers_send_call_started_at,
            headers_send_call_finished_at,
        );

        self.stream_open_to_headers_send_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.stream_open_to_headers_send_us_total
            .fetch_add(stream_open_to_headers_send_us, Ordering::SeqCst);
        self.headers_send_call_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.headers_send_call_us_total
            .fetch_add(headers_send_call_us, Ordering::SeqCst);
    }

    fn record_headers_to_first_connection_write(
        &self,
        headers_sent_at: Instant,
        write_at: Instant,
    ) {
        let headers_to_first_connection_write_us =
            saturating_instant_delta_us(headers_sent_at, write_at);
        self.headers_to_first_connection_write_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.headers_to_first_connection_write_us_total
            .fetch_add(headers_to_first_connection_write_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            headers_to_first_connection_write_us,
            &self.headers_to_first_connection_write_ge_1ms_total,
            &self.headers_to_first_connection_write_ge_5ms_total,
            &self.headers_to_first_connection_write_ge_10ms_total,
        );
    }

    fn record_first_chunk(
        &self,
        queued_at: Instant,
        headers_sent_at: Instant,
        dequeue_at: Instant,
        send_call_started_at: Instant,
        send_call_finished_at: Instant,
    ) {
        let channel_wait_us = saturating_instant_delta_us(queued_at, dequeue_at);
        let headers_to_dequeue_us = saturating_instant_delta_us(headers_sent_at, dequeue_at);
        let send_call_us = saturating_instant_delta_us(send_call_started_at, send_call_finished_at);
        let headers_to_send_call_us =
            saturating_instant_delta_us(headers_sent_at, send_call_finished_at);

        self.first_chunk_channel_wait_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.first_chunk_channel_wait_us_total
            .fetch_add(channel_wait_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            channel_wait_us,
            &self.first_chunk_channel_wait_ge_1ms_total,
            &self.first_chunk_channel_wait_ge_5ms_total,
            &self.first_chunk_channel_wait_ge_10ms_total,
        );
        self.headers_to_first_chunk_dequeue_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.headers_to_first_chunk_dequeue_us_total
            .fetch_add(headers_to_dequeue_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            headers_to_dequeue_us,
            &self.headers_to_first_chunk_dequeue_ge_1ms_total,
            &self.headers_to_first_chunk_dequeue_ge_5ms_total,
            &self.headers_to_first_chunk_dequeue_ge_10ms_total,
        );
        self.first_chunk_send_call_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.first_chunk_send_call_us_total
            .fetch_add(send_call_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            send_call_us,
            &self.first_chunk_send_call_ge_1ms_total,
            &self.first_chunk_send_call_ge_5ms_total,
            &self.first_chunk_send_call_ge_10ms_total,
        );
        self.headers_to_first_chunk_send_call_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.headers_to_first_chunk_send_call_us_total
            .fetch_add(headers_to_send_call_us, Ordering::SeqCst);
    }

    fn record_tail_chunk(
        &self,
        queued_at: Instant,
        dequeue_at: Instant,
        send_call_started_at: Instant,
        send_call_finished_at: Instant,
    ) {
        let channel_wait_us = saturating_instant_delta_us(queued_at, dequeue_at);
        let send_call_us = saturating_instant_delta_us(send_call_started_at, send_call_finished_at);

        self.tail_chunk_channel_wait_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.tail_chunk_channel_wait_us_total
            .fetch_add(channel_wait_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            channel_wait_us,
            &self.tail_chunk_channel_wait_ge_1ms_total,
            &self.tail_chunk_channel_wait_ge_5ms_total,
            &self.tail_chunk_channel_wait_ge_10ms_total,
        );
        self.tail_chunk_send_call_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.tail_chunk_send_call_us_total
            .fetch_add(send_call_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            send_call_us,
            &self.tail_chunk_send_call_ge_1ms_total,
            &self.tail_chunk_send_call_ge_5ms_total,
            &self.tail_chunk_send_call_ge_10ms_total,
        );
    }

    fn record_first_to_last_chunk_send(
        &self,
        first_chunk_sent_at: Instant,
        last_chunk_sent_at: Instant,
    ) {
        let span_us = saturating_instant_delta_us(first_chunk_sent_at, last_chunk_sent_at);
        self.first_to_last_chunk_send_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.first_to_last_chunk_send_us_total
            .fetch_add(span_us, Ordering::SeqCst);
        record_response_stream_slow_path(
            span_us,
            &self.first_to_last_chunk_send_ge_1ms_total,
            &self.first_to_last_chunk_send_ge_5ms_total,
            &self.first_to_last_chunk_send_ge_10ms_total,
        );
    }

    fn snapshot(&self) -> HttpResponseStreamMetricsSnapshot {
        HttpResponseStreamMetricsSnapshot {
            streaming_responses_total: self.streaming_responses_total.load(Ordering::SeqCst),
            stream_open_to_headers_send_samples_total: self
                .stream_open_to_headers_send_samples_total
                .load(Ordering::SeqCst),
            stream_open_to_headers_send_us_total: self
                .stream_open_to_headers_send_us_total
                .load(Ordering::SeqCst),
            headers_send_call_samples_total: self
                .headers_send_call_samples_total
                .load(Ordering::SeqCst),
            headers_send_call_us_total: self.headers_send_call_us_total.load(Ordering::SeqCst),
            headers_to_first_connection_write_samples_total: self
                .headers_to_first_connection_write_samples_total
                .load(Ordering::SeqCst),
            headers_to_first_connection_write_us_total: self
                .headers_to_first_connection_write_us_total
                .load(Ordering::SeqCst),
            headers_to_first_connection_write_ge_1ms_total: self
                .headers_to_first_connection_write_ge_1ms_total
                .load(Ordering::SeqCst),
            headers_to_first_connection_write_ge_5ms_total: self
                .headers_to_first_connection_write_ge_5ms_total
                .load(Ordering::SeqCst),
            headers_to_first_connection_write_ge_10ms_total: self
                .headers_to_first_connection_write_ge_10ms_total
                .load(Ordering::SeqCst),
            first_chunk_channel_wait_samples_total: self
                .first_chunk_channel_wait_samples_total
                .load(Ordering::SeqCst),
            first_chunk_channel_wait_us_total: self
                .first_chunk_channel_wait_us_total
                .load(Ordering::SeqCst),
            first_chunk_channel_wait_ge_1ms_total: self
                .first_chunk_channel_wait_ge_1ms_total
                .load(Ordering::SeqCst),
            first_chunk_channel_wait_ge_5ms_total: self
                .first_chunk_channel_wait_ge_5ms_total
                .load(Ordering::SeqCst),
            first_chunk_channel_wait_ge_10ms_total: self
                .first_chunk_channel_wait_ge_10ms_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_dequeue_samples_total: self
                .headers_to_first_chunk_dequeue_samples_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_dequeue_us_total: self
                .headers_to_first_chunk_dequeue_us_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_dequeue_ge_1ms_total: self
                .headers_to_first_chunk_dequeue_ge_1ms_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_dequeue_ge_5ms_total: self
                .headers_to_first_chunk_dequeue_ge_5ms_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_dequeue_ge_10ms_total: self
                .headers_to_first_chunk_dequeue_ge_10ms_total
                .load(Ordering::SeqCst),
            first_chunk_send_call_samples_total: self
                .first_chunk_send_call_samples_total
                .load(Ordering::SeqCst),
            first_chunk_send_call_us_total: self
                .first_chunk_send_call_us_total
                .load(Ordering::SeqCst),
            first_chunk_send_call_ge_1ms_total: self
                .first_chunk_send_call_ge_1ms_total
                .load(Ordering::SeqCst),
            first_chunk_send_call_ge_5ms_total: self
                .first_chunk_send_call_ge_5ms_total
                .load(Ordering::SeqCst),
            first_chunk_send_call_ge_10ms_total: self
                .first_chunk_send_call_ge_10ms_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_send_call_samples_total: self
                .headers_to_first_chunk_send_call_samples_total
                .load(Ordering::SeqCst),
            headers_to_first_chunk_send_call_us_total: self
                .headers_to_first_chunk_send_call_us_total
                .load(Ordering::SeqCst),
            tail_chunk_channel_wait_samples_total: self
                .tail_chunk_channel_wait_samples_total
                .load(Ordering::SeqCst),
            tail_chunk_channel_wait_us_total: self
                .tail_chunk_channel_wait_us_total
                .load(Ordering::SeqCst),
            tail_chunk_channel_wait_ge_1ms_total: self
                .tail_chunk_channel_wait_ge_1ms_total
                .load(Ordering::SeqCst),
            tail_chunk_channel_wait_ge_5ms_total: self
                .tail_chunk_channel_wait_ge_5ms_total
                .load(Ordering::SeqCst),
            tail_chunk_channel_wait_ge_10ms_total: self
                .tail_chunk_channel_wait_ge_10ms_total
                .load(Ordering::SeqCst),
            tail_chunk_send_call_samples_total: self
                .tail_chunk_send_call_samples_total
                .load(Ordering::SeqCst),
            tail_chunk_send_call_us_total: self
                .tail_chunk_send_call_us_total
                .load(Ordering::SeqCst),
            tail_chunk_send_call_ge_1ms_total: self
                .tail_chunk_send_call_ge_1ms_total
                .load(Ordering::SeqCst),
            tail_chunk_send_call_ge_5ms_total: self
                .tail_chunk_send_call_ge_5ms_total
                .load(Ordering::SeqCst),
            tail_chunk_send_call_ge_10ms_total: self
                .tail_chunk_send_call_ge_10ms_total
                .load(Ordering::SeqCst),
            first_to_last_chunk_send_samples_total: self
                .first_to_last_chunk_send_samples_total
                .load(Ordering::SeqCst),
            first_to_last_chunk_send_us_total: self
                .first_to_last_chunk_send_us_total
                .load(Ordering::SeqCst),
            first_to_last_chunk_send_ge_1ms_total: self
                .first_to_last_chunk_send_ge_1ms_total
                .load(Ordering::SeqCst),
            first_to_last_chunk_send_ge_5ms_total: self
                .first_to_last_chunk_send_ge_5ms_total
                .load(Ordering::SeqCst),
            first_to_last_chunk_send_ge_10ms_total: self
                .first_to_last_chunk_send_ge_10ms_total
                .load(Ordering::SeqCst),
        }
    }
}

impl HttpRequestBodyStreamMetrics {
    fn record_streaming_request(&self) {
        self.streaming_requests_total.fetch_add(1, Ordering::SeqCst);
    }

    fn record_data_chunk_wait_us(&self, wait_us: u64) {
        self.data_chunk_samples_total.fetch_add(1, Ordering::SeqCst);
        self.data_chunk_wait_us_total
            .fetch_add(wait_us, Ordering::SeqCst);
    }

    fn record_first_chunk_wait(&self, reader_started_at: Instant, data_received_at: Instant) {
        let wait_us = saturating_instant_delta_us(reader_started_at, data_received_at);
        self.first_chunk_wait_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.first_chunk_wait_us_total
            .fetch_add(wait_us, Ordering::SeqCst);
    }

    fn record_second_chunk_wait(&self, first_chunk_at: Instant, data_received_at: Instant) {
        let wait_us = saturating_instant_delta_us(first_chunk_at, data_received_at);
        self.second_chunk_wait_samples_total
            .fetch_add(1, Ordering::SeqCst);
        self.second_chunk_wait_us_total
            .fetch_add(wait_us, Ordering::SeqCst);
    }

    fn record_reader_finished(
        &self,
        reader_started_at: Instant,
        finished_at: Instant,
        second_chunk_at: Option<Instant>,
        remaining_tail_data_wait_us: u64,
        remaining_tail_data_wait_max: HttpRequestBodyTailDataWaitMax,
    ) {
        self.total_read_samples_total.fetch_add(1, Ordering::SeqCst);
        self.total_read_us_total.fetch_add(
            saturating_instant_delta_us(reader_started_at, finished_at),
            Ordering::SeqCst,
        );
        if let Some(second_at) = second_chunk_at {
            self.remaining_tail_read_samples_total
                .fetch_add(1, Ordering::SeqCst);
            self.remaining_tail_read_us_total.fetch_add(
                saturating_instant_delta_us(second_at, finished_at),
                Ordering::SeqCst,
            );
            self.remaining_tail_data_wait_samples_total
                .fetch_add(1, Ordering::SeqCst);
            self.remaining_tail_data_wait_us_total
                .fetch_add(remaining_tail_data_wait_us, Ordering::SeqCst);
            self.remaining_tail_data_wait_max_us_total
                .fetch_add(remaining_tail_data_wait_max.wait_us, Ordering::SeqCst);
            self.remaining_tail_data_wait_max_event_index_total
                .fetch_add(remaining_tail_data_wait_max.event_index, Ordering::SeqCst);
            self.remaining_tail_data_wait_max_bytes_before_total
                .fetch_add(remaining_tail_data_wait_max.bytes_before, Ordering::SeqCst);
            self.remaining_tail_data_wait_max_bytes_after_total
                .fetch_add(remaining_tail_data_wait_max.bytes_after, Ordering::SeqCst);
            if remaining_tail_data_wait_max.eof {
                self.remaining_tail_data_wait_max_eof_total
                    .fetch_add(1, Ordering::SeqCst);
            }
            self.remaining_tail_data_wait_max_available_capacity_before_total
                .fetch_add(
                    remaining_tail_data_wait_max
                        .flow_before_wait
                        .available_capacity,
                    Ordering::SeqCst,
                );
            self.remaining_tail_data_wait_max_used_capacity_before_total
                .fetch_add(
                    remaining_tail_data_wait_max.flow_before_wait.used_capacity,
                    Ordering::SeqCst,
                );
            self.remaining_tail_data_wait_max_available_capacity_after_data_total
                .fetch_add(
                    remaining_tail_data_wait_max
                        .flow_after_data
                        .available_capacity,
                    Ordering::SeqCst,
                );
            self.remaining_tail_data_wait_max_used_capacity_after_data_total
                .fetch_add(
                    remaining_tail_data_wait_max.flow_after_data.used_capacity,
                    Ordering::SeqCst,
                );
            self.remaining_tail_data_wait_max_available_capacity_after_release_total
                .fetch_add(
                    remaining_tail_data_wait_max
                        .flow_after_release
                        .available_capacity,
                    Ordering::SeqCst,
                );
            self.remaining_tail_data_wait_max_used_capacity_after_release_total
                .fetch_add(
                    remaining_tail_data_wait_max
                        .flow_after_release
                        .used_capacity,
                    Ordering::SeqCst,
                );
        }
    }

    fn snapshot(&self) -> HttpRequestBodyStreamMetricsSnapshot {
        HttpRequestBodyStreamMetricsSnapshot {
            streaming_requests_total: self.streaming_requests_total.load(Ordering::SeqCst),
            data_chunk_samples_total: self.data_chunk_samples_total.load(Ordering::SeqCst),
            data_chunk_wait_us_total: self.data_chunk_wait_us_total.load(Ordering::SeqCst),
            first_chunk_wait_samples_total: self
                .first_chunk_wait_samples_total
                .load(Ordering::SeqCst),
            first_chunk_wait_us_total: self.first_chunk_wait_us_total.load(Ordering::SeqCst),
            second_chunk_wait_samples_total: self
                .second_chunk_wait_samples_total
                .load(Ordering::SeqCst),
            second_chunk_wait_us_total: self.second_chunk_wait_us_total.load(Ordering::SeqCst),
            remaining_tail_read_samples_total: self
                .remaining_tail_read_samples_total
                .load(Ordering::SeqCst),
            remaining_tail_read_us_total: self.remaining_tail_read_us_total.load(Ordering::SeqCst),
            remaining_tail_data_wait_samples_total: self
                .remaining_tail_data_wait_samples_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_us_total: self
                .remaining_tail_data_wait_us_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_us_total: self
                .remaining_tail_data_wait_max_us_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_event_index_total: self
                .remaining_tail_data_wait_max_event_index_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_bytes_before_total: self
                .remaining_tail_data_wait_max_bytes_before_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_bytes_after_total: self
                .remaining_tail_data_wait_max_bytes_after_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_eof_total: self
                .remaining_tail_data_wait_max_eof_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_available_capacity_before_total: self
                .remaining_tail_data_wait_max_available_capacity_before_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_used_capacity_before_total: self
                .remaining_tail_data_wait_max_used_capacity_before_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_available_capacity_after_data_total: self
                .remaining_tail_data_wait_max_available_capacity_after_data_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_used_capacity_after_data_total: self
                .remaining_tail_data_wait_max_used_capacity_after_data_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_available_capacity_after_release_total: self
                .remaining_tail_data_wait_max_available_capacity_after_release_total
                .load(Ordering::SeqCst),
            remaining_tail_data_wait_max_used_capacity_after_release_total: self
                .remaining_tail_data_wait_max_used_capacity_after_release_total
                .load(Ordering::SeqCst),
            total_read_samples_total: self.total_read_samples_total.load(Ordering::SeqCst),
            total_read_us_total: self.total_read_us_total.load(Ordering::SeqCst),
        }
    }
}

impl Http2ConnectionWriteTracker {
    fn note_headers_sent(&self, headers_sent_at: Instant) -> usize {
        let mut guard = self
            .pending_headers_sent_at
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        guard.push_back(headers_sent_at);
        guard.len()
    }

    fn record_connection_write(&self, write_at: Instant) {
        let pending_headers_sent_at = {
            let mut guard = self
                .pending_headers_sent_at
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            guard.drain(..).collect::<Vec<_>>()
        };
        if pending_headers_sent_at.is_empty() {
            return;
        }
        let metrics = http_response_stream_metrics();
        for headers_sent_at in pending_headers_sent_at {
            metrics.record_headers_to_first_connection_write(headers_sent_at, write_at);
        }
    }
}

fn should_yield_for_pending_http2_responses(pending_headers: usize) -> bool {
    pending_headers > 1
}

impl tokio::io::AsyncRead for InstrumentedHttp2IoStream {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut tokio::io::ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        let me = self.get_mut();
        Pin::new(&mut me.inner).poll_read(cx, buf)
    }
}

impl tokio::io::AsyncWrite for InstrumentedHttp2IoStream {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<Result<usize, io::Error>> {
        let me = self.get_mut();
        match Pin::new(&mut me.inner).poll_write(cx, buf) {
            Poll::Ready(Ok(written)) => {
                if written > 0 {
                    me.write_tracker.record_connection_write(Instant::now());
                }
                Poll::Ready(Ok(written))
            }
            other => other,
        }
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Result<(), io::Error>> {
        let me = self.get_mut();
        Pin::new(&mut me.inner).poll_flush(cx)
    }

    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Result<(), io::Error>> {
        let me = self.get_mut();
        Pin::new(&mut me.inner).poll_shutdown(cx)
    }
}

static HTTP_METRICS: OnceLock<HttpMetricsStore> = OnceLock::new();
static FILE_SEGMENT_METRICS: OnceLock<FileSegmentMetrics> = OnceLock::new();
static TRANSPORT_COPY_METRICS: OnceLock<TransportCopyMetrics> = OnceLock::new();

fn http_metrics() -> &'static HttpMetricsStore {
    HTTP_METRICS.get_or_init(HttpMetricsStore::default)
}

fn file_segment_metrics() -> &'static FileSegmentMetrics {
    FILE_SEGMENT_METRICS.get_or_init(FileSegmentMetrics::default)
}

fn transport_copy_metrics() -> &'static TransportCopyMetrics {
    TRANSPORT_COPY_METRICS.get_or_init(TransportCopyMetrics::default)
}

fn http_response_stream_metrics() -> &'static HttpResponseStreamMetrics {
    HTTP_RESPONSE_STREAM_METRICS.get_or_init(HttpResponseStreamMetrics::default)
}

fn http_request_body_stream_metrics() -> &'static HttpRequestBodyStreamMetrics {
    HTTP_REQUEST_BODY_STREAM_METRICS.get_or_init(HttpRequestBodyStreamMetrics::default)
}

fn saturating_instant_delta_us(start: Instant, end: Instant) -> u64 {
    end.saturating_duration_since(start)
        .as_micros()
        .min(u64::MAX as u128) as u64
}

fn record_response_stream_slow_path(
    value_us: u64,
    ge_1ms_total: &AtomicU64,
    ge_5ms_total: &AtomicU64,
    ge_10ms_total: &AtomicU64,
) {
    if value_us >= RESPONSE_STREAM_SLOW_PATH_1MS_US {
        ge_1ms_total.fetch_add(1, Ordering::SeqCst);
    }
    if value_us >= RESPONSE_STREAM_SLOW_PATH_5MS_US {
        ge_5ms_total.fetch_add(1, Ordering::SeqCst);
    }
    if value_us >= RESPONSE_STREAM_SLOW_PATH_10MS_US {
        ge_10ms_total.fetch_add(1, Ordering::SeqCst);
    }
}

pub fn http_metrics_snapshot() -> HttpMetricsSnapshot {
    http_metrics().totals_snapshot()
}

pub fn file_segment_metrics_snapshot() -> FileSegmentMetricsSnapshot {
    let metrics = file_segment_metrics();
    FileSegmentMetricsSnapshot {
        rawsocket_zero_copy_calls_total: metrics
            .rawsocket_zero_copy_calls_total
            .load(Ordering::Relaxed),
        rawsocket_zero_copy_bytes_total: metrics
            .rawsocket_zero_copy_bytes_total
            .load(Ordering::Relaxed),
        buffered_file_segment_calls_total: metrics
            .buffered_file_segment_calls_total
            .load(Ordering::Relaxed),
        buffered_file_segment_bytes_total: metrics
            .buffered_file_segment_bytes_total
            .load(Ordering::Relaxed),
    }
}

pub fn transport_copy_metrics_snapshot() -> TransportCopyMetricsSnapshot {
    let metrics = transport_copy_metrics();
    TransportCopyMetricsSnapshot {
        websocket_mask_copy_bytes_total: metrics
            .websocket_mask_copy_bytes_total
            .load(Ordering::Relaxed),
        websocket_coalesce_copy_bytes_total: metrics
            .websocket_coalesce_copy_bytes_total
            .load(Ordering::Relaxed),
        tls_plaintext_accepted_bytes_total: metrics
            .tls_plaintext_accepted_bytes_total
            .load(Ordering::Relaxed),
        io_buffer_front_copy_bytes_total: metrics
            .io_buffer_front_copy_bytes_total
            .load(Ordering::Relaxed),
        io_buffered_read_copy_bytes_total: metrics
            .io_buffered_read_copy_bytes_total
            .load(Ordering::Relaxed),
    }
}

pub(crate) fn record_websocket_mask_copy(bytes: usize) {
    if bytes > 0 {
        transport_copy_metrics()
            .websocket_mask_copy_bytes_total
            .fetch_add(bytes as u64, Ordering::Relaxed);
    }
}

pub(crate) fn record_websocket_coalesce_copy(bytes: usize) {
    if bytes > 0 {
        transport_copy_metrics()
            .websocket_coalesce_copy_bytes_total
            .fetch_add(bytes as u64, Ordering::Relaxed);
    }
}

pub(crate) fn record_tls_plaintext_accepted(bytes: usize) {
    if bytes > 0 {
        transport_copy_metrics()
            .tls_plaintext_accepted_bytes_total
            .fetch_add(bytes as u64, Ordering::Relaxed);
    }
}

pub(crate) fn record_rawsocket_zero_copy_file_write(bytes: usize) {
    if bytes == 0 {
        return;
    }
    let metrics = file_segment_metrics();
    metrics
        .rawsocket_zero_copy_calls_total
        .fetch_add(1, Ordering::Relaxed);
    metrics
        .rawsocket_zero_copy_bytes_total
        .fetch_add(bytes as u64, Ordering::Relaxed);
}

fn record_buffered_file_segment(bytes: usize) {
    if bytes == 0 {
        return;
    }
    let metrics = file_segment_metrics();
    metrics
        .buffered_file_segment_calls_total
        .fetch_add(1, Ordering::Relaxed);
    metrics
        .buffered_file_segment_bytes_total
        .fetch_add(bytes as u64, Ordering::Relaxed);
}

pub fn http_metrics_snapshot_with_breakdown(
) -> (HttpMetricsSnapshot, Vec<HttpMetricsBreakdownSnapshot>) {
    http_metrics().snapshot_with_breakdown()
}

pub fn http_response_stream_metrics_snapshot() -> HttpResponseStreamMetricsSnapshot {
    http_response_stream_metrics().snapshot()
}

pub fn http_request_body_stream_metrics_snapshot() -> HttpRequestBodyStreamMetricsSnapshot {
    http_request_body_stream_metrics().snapshot()
}

fn protocol_sort_key(protocol: ConnectionProtocol) -> u8 {
    match protocol {
        ConnectionProtocol::RawSocket => 0,
        ConnectionProtocol::WebSocket => 1,
        ConnectionProtocol::Http => 2,
        ConnectionProtocol::Http2 => 3,
        ConnectionProtocol::Http3 => 4,
        ConnectionProtocol::Mqtt => 5,
    }
}

fn record_http_metrics(listener_id: ListenerId, event: &HttpConnectionEvent) {
    http_metrics().record(listener_id, event);
}

pub use platform::{Runtime as PlatformRuntime, UnsupportedPlatform};
pub use protocol::{Http2Handshake, Http3Handshake, HttpHandshake, WebSocketHandshake};
pub use rawsocket::Serializer as RawSocketSerializer;
pub use wamp::{
    compose_flatbuffers_message_segments, encode_flatbuffers_message,
    encode_flatbuffers_message_segments, parse_message, parse_message_segments,
    validate_flatbuffers_payload, ParseError as WampParseError, ParsedMessage,
    Payload as WampPayload, RawFrame as WampRawFrame, WampMessage,
};

static RUNTIME_MANAGER: OnceLock<RuntimeManager> = OnceLock::new();

const MAX_FRAME_LEN: u64 = 1 << 24;
const HTTP3_DEFAULT_BODY_LIMIT: u64 = 4 * 1024 * 1024;
const WEBSOCKET_GUID: &str = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
const MAX_WEBSOCKET_MESSAGE_LEN: usize = 1 << 24;
const HTTP1_INLINE_BODY_LIMIT: usize = 64 * 1024;

/// Unique identifier for a registered listener.
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub struct ListenerId(pub u32);

/// Unique identifier for an accepted connection.
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub struct ConnectionId(pub u32);

/// Transport protocol negotiated for a connection.
#[derive(Debug, Copy, Clone, PartialEq, Eq, Hash)]
pub enum ConnectionProtocol {
    RawSocket,
    Mqtt,
    WebSocket,
    Http,
    Http2,
    Http3,
}

#[derive(Debug, Clone)]
pub struct HttpBodyHandle {
    payload: Arc<HttpBodyPayload>,
}

#[derive(Debug)]
enum HttpBodyPayload {
    Inline(Bytes),
    Streaming(StreamingPayload),
}

#[derive(Debug)]
struct StreamingPayload {
    state: Arc<StreamingBodyState>,
}

#[derive(Debug)]
pub struct HttpBodySlice {
    pub ptr: *const u8,
    pub len: usize,
}

impl HttpBodyHandle {
    pub fn empty() -> Self {
        Self {
            payload: Arc::new(HttpBodyPayload::Inline(Bytes::new())),
        }
    }

    pub fn from_bytes(bytes: Vec<u8>) -> Self {
        if bytes.is_empty() {
            return Self::empty();
        }
        Self {
            payload: Arc::new(HttpBodyPayload::Inline(Bytes::from(bytes))),
        }
    }

    pub fn from_inline(bytes: Bytes) -> Self {
        if bytes.is_empty() {
            return Self::empty();
        }
        Self {
            payload: Arc::new(HttpBodyPayload::Inline(bytes)),
        }
    }

    pub fn streaming(state: Arc<StreamingBodyState>) -> Self {
        Self {
            payload: Arc::new(HttpBodyPayload::Streaming(StreamingPayload { state })),
        }
    }

    pub fn len(&self) -> usize {
        match self.payload.as_ref() {
            HttpBodyPayload::Inline(bytes) => bytes.len(),
            HttpBodyPayload::Streaming(payload) => payload.state.total_len(),
        }
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn inline_bytes(&self) -> Option<&Bytes> {
        match self.payload.as_ref() {
            HttpBodyPayload::Inline(bytes) => Some(bytes),
            HttpBodyPayload::Streaming(_) => None,
        }
    }

    pub fn slice(&self, offset: usize, length: usize) -> Option<HttpBodySlice> {
        let total = self.len();
        if offset > total {
            return None;
        }
        let end = total.min(offset.saturating_add(length));
        let slice_len = end.saturating_sub(offset);
        match self.payload.as_ref() {
            HttpBodyPayload::Inline(bytes) => {
                let ptr = unsafe { bytes.as_ptr().add(offset) };
                Some(HttpBodySlice {
                    ptr,
                    len: slice_len,
                })
            }
            HttpBodyPayload::Streaming(_) => None,
        }
    }

    pub fn stream_read(&self, len: usize) -> Result<Option<HttpBodySlice>, StreamingError> {
        match self.payload.as_ref() {
            HttpBodyPayload::Streaming(payload) => payload.state.take_slice(len),
            _ => Ok(None),
        }
    }

    pub fn request_finish(&self) {
        if let HttpBodyPayload::Streaming(payload) = self.payload.as_ref() {
            payload.state.request_finish();
        }
    }

    pub fn is_streaming(&self) -> bool {
        matches!(self.payload.as_ref(), HttpBodyPayload::Streaming(_))
    }
}

pub struct HttpRequestSummary {
    pub method: Arc<[u8]>,
    pub target: Arc<[u8]>,
    pub path: Arc<[u8]>,
    pub query: Option<Arc<[u8]>>,
    pub protocol: Arc<[u8]>,
    pub version: u8,
    pub headers: Vec<(Arc<[u8]>, Arc<[u8]>)>,
    pub body: HttpBodyHandle,
    pub realm: Option<Arc<[u8]>>,
    pub procedure: Option<Arc<[u8]>>,
    pub route: Option<HttpRouteResolution>,
}

impl HttpRequestSummary {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        method: String,
        target: String,
        path: String,
        query: Option<String>,
        protocol: String,
        version: u8,
        headers: Vec<(Arc<[u8]>, Arc<[u8]>)>,
        body: HttpBodyHandle,
        realm: Option<String>,
        procedure: Option<String>,
        route: Option<HttpRouteResolution>,
    ) -> Self {
        Self {
            method: http_bytes_from_string(method),
            target: http_bytes_from_string(target),
            path: http_bytes_from_string(path),
            query: query.map(http_bytes_from_string),
            protocol: http_bytes_from_string(protocol),
            version,
            headers,
            body,
            realm: realm.map(http_bytes_from_string),
            procedure: procedure.map(http_bytes_from_string),
            route,
        }
    }
}

fn http_bytes_from_string(value: String) -> Arc<[u8]> {
    Arc::<[u8]>::from(value.into_bytes())
}

fn http_bytes_from_slice(value: &[u8]) -> Arc<[u8]> {
    Arc::<[u8]>::from(value.to_vec())
}

pub struct HttpResponseHandle {
    connection_id: ConnectionId,
    sender: oneshot::Sender<HttpResponseDispatch>,
}

impl HttpResponseHandle {
    fn new(connection_id: ConnectionId, sender: oneshot::Sender<HttpResponseDispatch>) -> Self {
        Self {
            connection_id,
            sender,
        }
    }

    pub fn respond(self, response: HttpResponseDispatch) -> Result<(), Error> {
        self.sender
            .send(response)
            .map_err(|_| Error::Http3ResponseSend(self.connection_id))
    }
}

#[derive(Debug)]
pub struct HttpResponseDispatch {
    pub status: i32,
    pub headers: Vec<(String, String)>,
    pub body: HttpResponseBody,
}

#[derive(Debug)]
pub enum HttpResponseBody {
    Buffered(Vec<u8>),
    Streaming(ResponseStreamReader),
}

/// Handle representing an accepted HTTP/3 bidirectional stream.
pub struct Http3BidiStream {
    id: u64,
    send: quinn::SendStream,
    recv: quinn::RecvStream,
}

impl Http3BidiStream {
    /// Returns the QUIC stream identifier.
    pub fn id(&self) -> u64 {
        self.id
    }

    /// Splits the stream into its send/receive halves.
    pub fn into_parts(self) -> (quinn::SendStream, quinn::RecvStream) {
        (self.send, self.recv)
    }
}

/// Errors that can occur when interacting with the runtime.
#[derive(Debug, Error)]
pub enum Error {
    /// The runtime has not been initialised yet.
    #[error("runtime not started")]
    RuntimeNotStarted,
    /// Attempted to start the runtime twice without shutting it down.
    #[error("runtime already started")]
    RuntimeAlreadyStarted,
    /// Native runtime is not supported on this platform.
    #[error("native runtime unsupported on this platform")]
    UnsupportedPlatform,
    /// Provided backlog value is invalid.
    #[error("backlog must be positive")]
    InvalidBacklog,
    /// No listener with the provided identifier exists.
    #[error("listener {0:?} not found")]
    ListenerNotFound(ListenerId),
    /// The accept channel was already consumed.
    #[error("accept channel already taken for listener {0:?}")]
    AcceptChannelAlreadyTaken(ListenerId),
    /// Socket address resolution failed.
    #[error("failed to resolve address {0}:{1}")]
    AddressResolution(String, u16),
    /// Listener requested for a host/port not present in the applied config.
    #[error("endpoint {0}:{1} is not configured")]
    EndpointNotConfigured(String, u16),
    /// Router configuration could not be parsed or applied.
    #[error("router configuration invalid: {0}")]
    RouterConfigInvalid(String),
    /// Connection for the provided identifier was not registered.
    #[error("connection {0:?} not found")]
    ConnectionNotFound(ConnectionId),
    /// Operation not supported for negotiated protocol.
    #[error("connection {0:?} protocol {1:?} does not support this operation")]
    UnsupportedProtocol(ConnectionId, ConnectionProtocol),
    /// Connection handshake already consumed.
    #[error("connection {0:?} handshake already consumed")]
    HandshakeAlreadyTaken(ConnectionId),
    /// HTTP/3 connection handle is unavailable.
    #[error("connection {0:?} handle unavailable")]
    ConnectionHandleUnavailable(ConnectionId),
    /// HTTP/3 response channel closed or failed.
    #[error("failed to send http/3 response for connection {0:?}")]
    Http3ResponseSend(ConnectionId),
    /// Wrapper around I/O errors.
    #[error(transparent)]
    Io(#[from] std::io::Error),
    /// Send buffer is full; the caller should retry or close the connection.
    #[error("connection {0:?} send queue full")]
    SendQueueFull(ConnectionId),
    /// Native runtime thread count env var is invalid.
    #[error("native runtime thread count invalid: {0}")]
    InvalidRuntimeThreadCount(String),
    /// A file-backed outbound segment was invalid for the selected connection.
    #[error("invalid outbound file segment: {0}")]
    InvalidFileSegment(&'static str),
    /// A deferred outbound segment had an invalid length.
    #[error("invalid deferred outbound segment: {0}")]
    InvalidDeferredSegment(&'static str),
}

const NATIVE_RUNTIME_THREADS_ENV: &str = "CONNECTANUM_NATIVE_RUNTIME_THREADS";

struct RuntimeManager {
    state: Mutex<Option<RuntimeState>>,
}

struct RuntimeState {
    runtime: Runtime,
    mqtt_runtime: Option<Runtime>,
    handle: tokio::runtime::Handle,
    registry: Arc<ListenerRegistry>,
}

struct RuntimeView {
    handle: tokio::runtime::Handle,
    registry: Arc<ListenerRegistry>,
}

// Connection handles can outlive runtime shutdown in pending opens, receive
// workers and callbacks. Keep their namespace for the lifetime of this library.
static NEXT_CONNECTION_ID: AtomicU32 = AtomicU32::new(1);

fn allocate_connection_id(sequence: &AtomicU32) -> Result<ConnectionId, Error> {
    let id = sequence
        .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |next| {
            if next == 0 || next > i32::MAX as u32 {
                None
            } else {
                Some(next + 1)
            }
        })
        .map_err(|_| Error::Io(io::Error::other("connection identifier capacity exhausted")))?;
    Ok(ConnectionId(id))
}

#[inline]
async fn with_mqtt_connection_id<F, Fut>(result: Result<ConnectionId, Error>, accept: F)
where
    F: FnOnce(ConnectionId) -> Fut,
    Fut: std::future::Future<Output = ()>,
{
    if let Ok(connection_id) = result {
        accept(connection_id).await;
    }
}

struct ListenerRegistry {
    mqtt_handle: Option<tokio::runtime::Handle>,
    listeners: Mutex<HashMap<ListenerId, ListenerEntry>>,
    connections: Mutex<HashMap<ConnectionId, ConnectionEntry>>,
    connection_events: Mutex<VecDeque<HttpConnectionEvent>>,
    next_listener_id: AtomicU32,
    #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
    idle_allocator: Arc<idle_allocator::IdleAllocatorRelease>,
    #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
    shutting_down: AtomicBool,
}

impl Default for ListenerRegistry {
    fn default() -> Self {
        Self {
            mqtt_handle: None,
            listeners: Mutex::new(HashMap::new()),
            connections: Mutex::new(HashMap::new()),
            connection_events: Mutex::new(VecDeque::new()),
            next_listener_id: AtomicU32::new(0),
            #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
            idle_allocator: idle_allocator::shared(),
            #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
            shutting_down: AtomicBool::new(false),
        }
    }
}

struct ListenerEntry {
    router_scoped: bool,
    configured_endpoint_index: Option<usize>,
    addr: SocketAddr,
    receiver: Mutex<Option<mpsc::Receiver<ConnectionId>>>,
    _sender: mpsc::Sender<ConnectionId>,
    tasks: Vec<JoinHandle<()>>,
    #[allow(dead_code)]
    http3_addr: Option<SocketAddr>,
    http3_endpoint: Option<QuinnEndpoint>,
    #[allow(dead_code)]
    config_state: Arc<ListenerConfigState>,
}

struct ListenerConfigState {
    endpoint_config: RwLock<Arc<config::EndpointRuntimeConfig>>,
    tls_acceptor: RwLock<Option<TlsAcceptor>>,
}

impl ListenerConfigState {
    fn new(
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        tls_acceptor: Option<TlsAcceptor>,
    ) -> Self {
        Self {
            endpoint_config: RwLock::new(endpoint_config),
            tls_acceptor: RwLock::new(tls_acceptor),
        }
    }

    fn endpoint_config(&self) -> Arc<config::EndpointRuntimeConfig> {
        self.endpoint_config
            .read()
            .unwrap_or_else(|poison| poison.into_inner())
            .clone()
    }

    fn tls_acceptor(&self) -> Option<TlsAcceptor> {
        self.tls_acceptor
            .read()
            .unwrap_or_else(|poison| poison.into_inner())
            .clone()
    }

    fn update(
        &self,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        tls_acceptor: Option<TlsAcceptor>,
    ) {
        {
            let mut guard = self
                .endpoint_config
                .write()
                .unwrap_or_else(|poison| poison.into_inner());
            *guard = endpoint_config;
        }
        {
            let mut guard = self
                .tls_acceptor
                .write()
                .unwrap_or_else(|poison| poison.into_inner());
            *guard = tls_acceptor;
        }
    }
}

struct ConnectionEntry {
    #[allow(dead_code)]
    listener_id: ListenerId,
    #[allow(dead_code)]
    peer_addr: SocketAddr,
    protocol: ConnectionProtocol,
    websocket_protocol: Option<String>,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    stats: Option<Arc<HttpConnectionStats>>,
    record: ConnectionRecord,
}

const MQTT_OUTBOUND_QUEUE_MAX_CHUNKS: usize = 512;
const MQTT_OUTBOUND_QUEUE_MAX_BYTES: usize = 8 * 1024 * 1024;

type MqttOutboundChunk = (Bytes, OwnedSemaphorePermit);

struct MqttOutboundQueue {
    sender: mpsc::Sender<MqttOutboundChunk>,
    byte_budget: Arc<Semaphore>,
}

impl MqttOutboundQueue {
    fn new(configured_capacity: usize) -> (Self, mpsc::Receiver<MqttOutboundChunk>) {
        let (sender, receiver) =
            mpsc::channel(configured_capacity.min(MQTT_OUTBOUND_QUEUE_MAX_CHUNKS));
        (
            Self {
                sender,
                byte_budget: Arc::new(Semaphore::new(MQTT_OUTBOUND_QUEUE_MAX_BYTES)),
            },
            receiver,
        )
    }

    fn enqueue(&self, connection_id: ConnectionId, bytes: Bytes) -> Result<(), Error> {
        if bytes.len() > MQTT_OUTBOUND_QUEUE_MAX_BYTES {
            return Err(Error::SendQueueFull(connection_id));
        }
        let permit = self
            .byte_budget
            .clone()
            .try_acquire_many_owned(bytes.len() as u32)
            .map_err(|_| Error::SendQueueFull(connection_id))?;
        match self.sender.try_send((bytes, permit)) {
            Ok(()) => Ok(()),
            Err(TrySendError::Full(_)) => Err(Error::SendQueueFull(connection_id)),
            Err(TrySendError::Closed(_)) => Err(Error::ConnectionNotFound(connection_id)),
        }
    }
}

struct MqttInbound {
    receiver: mpsc::Receiver<Bytes>,
    pending: Option<Bytes>,
}

impl MqttInbound {
    fn new(receiver: mpsc::Receiver<Bytes>) -> Self {
        Self {
            receiver,
            pending: None,
        }
    }

    fn try_recv_limited(&mut self, max_bytes: usize) -> Result<Bytes, TryRecvError> {
        let mut bytes = match self.pending.take() {
            Some(bytes) => bytes,
            None => self.receiver.try_recv()?,
        };
        if bytes.len() > max_bytes {
            self.pending = Some(bytes.split_off(max_bytes));
            return Ok(bytes);
        }
        let mut total = bytes.len();
        let mut combined = None;
        while total < max_bytes {
            let mut next = match self.receiver.try_recv() {
                Ok(next) => next,
                Err(TryRecvError::Empty | TryRecvError::Disconnected) => break,
            };
            let remaining = max_bytes - total;
            if next.len() > remaining {
                self.pending = Some(next.split_off(remaining));
            }
            let buffer = combined.get_or_insert_with(|| {
                let mut buffer = BytesMut::with_capacity(max_bytes.min(4096));
                buffer.extend_from_slice(&bytes);
                buffer
            });
            buffer.extend_from_slice(&next);
            total += next.len();
            if self.pending.is_some() {
                break;
            }
        }
        Ok(combined.map(BytesMut::freeze).unwrap_or(bytes))
    }

    #[inline]
    fn poll_with_wake_reset<F: FnOnce()>(
        &mut self,
        max_bytes: usize,
        notification_pending: &AtomicBool,
        after_reset: F,
    ) -> Option<Bytes> {
        match self.try_recv_limited(max_bytes) {
            Ok(bytes) => Some(bytes),
            Err(TryRecvError::Empty) => {
                // Retry after clearing the flag so a producer racing this
                // empty observation cannot leave bytes asleep in the queue.
                notification_pending.store(false, Ordering::Release);
                after_reset();
                self.try_recv_limited(max_bytes).ok()
            }
            Err(TryRecvError::Disconnected) => None,
        }
    }
}

enum ConnectionRecord {
    RawSocket {
        _serializer: rawsocket::Serializer,
        max_exponent: u32,
        supports_file_segments: bool,
        frames: Arc<Mutex<mpsc::Receiver<wamp::ParsedMessage>>>,
        reader_abort: AbortHandle,
        writer_abort: AbortHandle,
        heartbeat_abort: Option<AbortHandle>,
        send_tx: mpsc::Sender<OutboundFrame>,
    },
    Mqtt {
        version: u8,
        chunks: Arc<Mutex<MqttInbound>>,
        notification_pending: Arc<AtomicBool>,
        outbound: MqttOutboundQueue,
        wakeup: Arc<Mutex<Option<extern "C" fn(i32)>>>,
        reader_abort: AbortHandle,
        writer_abort: AbortHandle,
    },
    WebSocketPending {
        handshake: Mutex<Option<protocol::WebSocketHandshake>>,
    },
    WebSocket {
        _serializer: rawsocket::Serializer,
        frames: Arc<Mutex<mpsc::Receiver<wamp::ParsedMessage>>>,
        reader_abort: AbortHandle,
        writer_abort: AbortHandle,
        writer_runtime: tokio::runtime::Handle,
        heartbeat_abort: Option<AbortHandle>,
        send_tx: mpsc::Sender<OutboundFrame>,
    },
    HttpPending {
        pending_requests: Mutex<VecDeque<QueuedHttpRequest>>,
    },
    Http2Pending {
        handshake: Mutex<Option<protocol::Http2Handshake>>,
        pending_requests: Mutex<VecDeque<QueuedHttpRequest>>,
    },
    Http3Pending {
        handshake: Mutex<Option<protocol::Http3Handshake>>,
        connection: Mutex<Option<Arc<quinn::Connection>>>,
        streams: Arc<Http3StreamChannels>,
        pending_requests: Mutex<VecDeque<QueuedHttpRequest>>,
    },
}

struct Http3StreamChannels {
    streams: Mutex<VecDeque<Http3BidiStream>>,
}

impl Http3StreamChannels {
    fn new() -> Self {
        Self {
            streams: Mutex::new(VecDeque::new()),
        }
    }

    fn try_recv(&self) -> Option<Http3BidiStream> {
        self.streams.lock().unwrap().pop_front()
    }
}

struct QueuedHttpRequest {
    summary: HttpRequestSummary,
    response: HttpResponseHandle,
}

impl RuntimeManager {
    fn global() -> &'static Self {
        RUNTIME_MANAGER.get_or_init(|| RuntimeManager {
            state: Mutex::new(None),
        })
    }

    fn with_state<F, T>(&self, f: F) -> Result<T, Error>
    where
        F: FnOnce(&RuntimeView) -> Result<T, Error>,
    {
        let view = {
            let guard = self
                .state
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            let state = guard.as_ref().ok_or(Error::RuntimeNotStarted)?;
            state.view()
        };
        f(&view)
    }
}

impl RuntimeState {
    fn from_runtime_parts(
        runtime: Runtime,
        mqtt_runtime: Result<Option<Runtime>, Error>,
    ) -> Result<Self, Error> {
        let mqtt_runtime = match mqtt_runtime {
            Ok(runtime) => runtime,
            Err(error) => {
                // Startup can run inside another executor; do not block it on drop.
                runtime.shutdown_background();
                return Err(error);
            }
        };
        let handle = runtime.handle().clone();
        let registry = Arc::new(ListenerRegistry {
            mqtt_handle: mqtt_runtime
                .as_ref()
                .map(|runtime| runtime.handle().clone()),
            ..ListenerRegistry::default()
        });
        Ok(Self {
            runtime,
            mqtt_runtime,
            handle,
            registry,
        })
    }

    fn view(&self) -> RuntimeView {
        RuntimeView {
            handle: self.handle.clone(),
            registry: Arc::clone(&self.registry),
        }
    }

    fn shutdown(self) {
        self.registry.shutdown();
        let runtime = self.runtime;
        let mqtt_runtime = self.mqtt_runtime;
        let _ = std::thread::spawn(move || {
            if let Some(mqtt_runtime) = mqtt_runtime {
                mqtt_runtime.shutdown_timeout(Duration::from_secs(1));
            }
            runtime.shutdown_timeout(Duration::from_secs(1));
        })
        .join();
    }
}

impl ListenerRegistry {
    fn next_listener_id(&self) -> ListenerId {
        let id = self.next_listener_id.fetch_add(1, Ordering::SeqCst);
        ListenerId(id + 1)
    }

    fn next_connection_id(&self) -> Result<ConnectionId, Error> {
        allocate_connection_id(&NEXT_CONNECTION_ID)
    }

    fn insert(&self, id: ListenerId, entry: ListenerEntry) {
        self.listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(id, entry);
    }

    fn local_addr(&self, id: ListenerId) -> Result<SocketAddr, Error> {
        self.listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&id)
            .map(|entry| entry.addr)
            .ok_or(Error::ListenerNotFound(id))
    }

    fn http3_addr(&self, id: ListenerId) -> Result<Option<SocketAddr>, Error> {
        self.listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&id)
            .map(|entry| entry.http3_addr)
            .ok_or(Error::ListenerNotFound(id))
    }

    fn take_receiver(&self, id: ListenerId) -> Result<mpsc::Receiver<ConnectionId>, Error> {
        let listeners = self
            .listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = listeners.get(&id).ok_or(Error::ListenerNotFound(id))?;
        let mut guard = entry.receiver.lock().unwrap();
        guard.take().ok_or(Error::AcceptChannelAlreadyTaken(id))
    }

    fn reload_tls(&self) -> Result<u32, Error> {
        let cfg = config::current_config();
        self.reload_tls_selected(None, cfg.as_deref())
    }

    fn reload_tls_selected(
        &self,
        selected: Option<&[ListenerId]>,
        cfg: Option<&config::RouterConfig>,
    ) -> Result<u32, Error> {
        let listeners = self
            .listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entries = match selected {
            Some(ids) => {
                let mut seen = HashSet::new();
                let mut entries = Vec::with_capacity(ids.len());
                for id in ids {
                    if !seen.insert(*id) {
                        return Err(Error::RouterConfigInvalid("duplicate listener id".into()));
                    }
                    let entry = listeners.get(id).ok_or(Error::ListenerNotFound(*id))?;
                    if !entry.router_scoped {
                        return Err(Error::RouterConfigInvalid(
                            "scoped reload requires router-scoped listeners".into(),
                        ));
                    }
                    entries.push((id, entry));
                }
                entries
            }
            None => listeners
                .iter()
                .filter(|(_, entry)| !entry.router_scoped)
                .collect(),
        };
        // Build every TLS/QUIC identity before updating any running listener.
        let mut prepared = Vec::with_capacity(entries.len());
        for (listener_id, entry) in entries {
            let current = entry.config_state.endpoint_config();
            let endpoint_cfg = cfg
                .and_then(|cfg| match entry.configured_endpoint_index {
                    Some(index) => {
                        config::find_endpoint_at_in(cfg, index, &current.host, current.port)
                    }
                    None => config::find_endpoint_in(cfg, &current.host, current.port),
                })
                .ok_or_else(|| Error::EndpointNotConfigured(current.host.clone(), current.port))?;
            let next = Arc::new(config::EndpointRuntimeConfig::try_from_endpoint(
                &endpoint_cfg,
            )?);
            if next.tls_mode != current.tls_mode {
                return Err(Error::RouterConfigInvalid(format!(
                    "listener {:?} tls_mode changed ({:?} -> {:?}); restart required",
                    listener_id, current.tls_mode, next.tls_mode
                )));
            }
            let current_http3 = current.supports_protocol(TransportProtocol::Http3);
            let next_http3 = next.supports_protocol(TransportProtocol::Http3);
            if current_http3 != next_http3 {
                return Err(Error::RouterConfigInvalid(format!(
                    "listener {:?} http3 enablement changed; restart required",
                    listener_id
                )));
            }

            let tls_acceptor = tls::build_tls_acceptor(&next)?;
            let http3 = if current_http3 {
                let endpoint = entry.http3_endpoint.as_ref().ok_or_else(|| {
                    Error::RouterConfigInvalid(format!(
                        "listener {:?} missing http3 endpoint during reload",
                        listener_id
                    ))
                })?;
                let server_config = build_http3_server_config(&next)?;
                Some((endpoint, server_config))
            } else {
                None
            };
            prepared.push((entry, next, tls_acceptor, http3));
        }
        let count = prepared.len() as u32;
        for (entry, next, tls_acceptor, http3) in prepared {
            entry.config_state.update(next, tls_acceptor);
            if let Some((endpoint, server_config)) = http3 {
                endpoint.set_server_config(Some(server_config));
            }
        }
        Ok(count)
    }

    fn close_listener(&self, listener_id: ListenerId) -> Result<(), Error> {
        let mut entry = self
            .listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .remove(&listener_id)
            .ok_or(Error::ListenerNotFound(listener_id))?;

        for task in entry.tasks {
            task.abort();
        }
        if let Some(endpoint) = entry.http3_endpoint.take() {
            endpoint.close(VarInt::from_u32(0), b"listener closed");
        }
        Ok(())
    }

    fn shutdown(&self) {
        #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
        self.shutting_down.store(true, Ordering::Release);
        let listener_entries: Vec<ListenerEntry> = self
            .listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .drain()
            .map(|(_, entry)| entry)
            .collect();
        for mut entry in listener_entries {
            for task in entry.tasks {
                task.abort();
            }
            if let Some(endpoint) = entry.http3_endpoint.take() {
                endpoint.close(VarInt::from_u32(0), b"shutdown");
            }
        }

        let connection_entries: Vec<ConnectionEntry> = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .drain()
            .map(|(_, entry)| entry)
            .collect();
        for entry in connection_entries {
            match entry.record {
                ConnectionRecord::Mqtt {
                    wakeup,
                    reader_abort,
                    writer_abort,
                    ..
                } => {
                    *wakeup.lock().unwrap() = None;
                    reader_abort.abort();
                    writer_abort.abort();
                }
                ConnectionRecord::RawSocket {
                    reader_abort,
                    writer_abort,
                    heartbeat_abort,
                    ..
                } => {
                    reader_abort.abort();
                    writer_abort.abort();
                    if let Some(abort) = heartbeat_abort {
                        abort.abort();
                    }
                }
                ConnectionRecord::WebSocket {
                    reader_abort,
                    writer_abort,
                    heartbeat_abort,
                    ..
                } => {
                    reader_abort.abort();
                    writer_abort.abort();
                    if let Some(abort) = heartbeat_abort {
                        abort.abort();
                    }
                }
                ConnectionRecord::WebSocketPending { .. }
                | ConnectionRecord::HttpPending { .. }
                | ConnectionRecord::Http2Pending { .. }
                | ConnectionRecord::Http3Pending { .. } => {}
            }
        }
    }

    fn close_connection(self: &Arc<Self>, connection_id: ConnectionId) -> Result<(), Error> {
        let result = self.remove_connection(connection_id);
        // Peer disconnects and heartbeat failures close from Tokio tasks rather
        // than the public FFI wrapper. They must also return idle allocator pages.
        #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
        if let Ok(handle) = tokio::runtime::Handle::try_current() {
            self.schedule_idle_allocator_release(&handle, idle_allocator::release_unused_pages);
        }
        result
    }

    fn remove_connection(&self, connection_id: ConnectionId) -> Result<(), Error> {
        let entry = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .remove(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match entry.record {
            ConnectionRecord::Mqtt {
                wakeup,
                reader_abort,
                writer_abort,
                ..
            } => {
                *wakeup.lock().unwrap() = None;
                reader_abort.abort();
                writer_abort.abort();
            }
            ConnectionRecord::RawSocket {
                reader_abort,
                writer_abort,
                heartbeat_abort,
                ..
            } => {
                reader_abort.abort();
                writer_abort.abort();
                if let Some(abort) = heartbeat_abort {
                    abort.abort();
                }
            }
            ConnectionRecord::WebSocket {
                reader_abort,
                writer_abort,
                heartbeat_abort,
                send_tx,
                writer_runtime,
                ..
            } => {
                reader_abort.abort();
                if let Some(abort) = heartbeat_abort {
                    abort.abort();
                }
                drop(send_tx);
                let deadline = time::Instant::now() + WEBSOCKET_CLOSE_GRACE;
                writer_runtime.spawn(async move {
                    time::sleep_until(deadline).await;
                    // Capture this task, never a recyclable connection lookup.
                    // Aborting an already finished writer is harmless.
                    writer_abort.abort();
                });
            }
            ConnectionRecord::WebSocketPending { .. }
            | ConnectionRecord::HttpPending { .. }
            | ConnectionRecord::Http2Pending { .. }
            | ConnectionRecord::Http3Pending { .. } => {}
        }
        Ok(())
    }

    #[cfg(any(test, all(target_os = "linux", target_env = "gnu")))]
    fn schedule_idle_allocator_release(
        self: &Arc<Self>,
        handle: &tokio::runtime::Handle,
        release: impl FnOnce() + Send + 'static,
    ) {
        let idle = !self.shutting_down.load(Ordering::Acquire)
            && self
                .connections
                .lock()
                .unwrap_or_else(|poison| poison.into_inner())
                .is_empty();
        let Some(reservation) = self.idle_allocator.reserve(idle) else {
            return;
        };
        let registry = Arc::downgrade(self);
        handle.spawn(async move {
            time::sleep(idle_allocator::IDLE_DELAY).await;
            // Allocator locks and page release must not occupy an I/O worker.
            tokio::task::spawn_blocking(move || {
                if let Some(registry) = registry.upgrade() {
                    let idle = !registry.shutting_down.load(Ordering::Acquire)
                        && registry
                            .connections
                            .lock()
                            .unwrap_or_else(|poison| poison.into_inner())
                            .is_empty();
                    reservation.release_if_due(idle, Instant::now(), release);
                }
            });
        });
    }

    fn register_rawsocket_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        negotiated: rawsocket::NegotiatedSession,
        peer_addr: SocketAddr,
    ) {
        let (frame_tx, frame_rx) = mpsc::channel(1024);
        let (send_tx, send_rx) = mpsc::channel(endpoint_config.outbound_send_queue_capacity);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel::<ConnectionTaskSignal>();
        let serializer = negotiated.serializer;
        let max_exponent = negotiated.max_message_size_exponent;
        let supports_file_segments = cfg!(any(unix, windows));
        let (pong_tx, pong_rx) = mpsc::unbounded_channel::<Bytes>();
        let heartbeat_abort = endpoint_config.heartbeat_interval.map(|interval| {
            let timeout = endpoint_config
                .heartbeat_timeout
                .unwrap_or_else(|| interval.checked_mul(2).unwrap_or(Duration::from_secs(30)));
            spawn_connection_heartbeat(
                handle.clone(),
                Arc::clone(&self),
                connection_id,
                interval,
                timeout,
                send_tx.clone(),
                pong_rx,
            )
        });
        let pong_tx = heartbeat_abort.as_ref().map(|_| pong_tx);

        let reader_abort = spawn_connection_reader(
            handle.clone(),
            connection_id,
            Arc::clone(&endpoint_config),
            negotiated.reader,
            serializer,
            max_exponent,
            frame_tx,
            send_tx.clone(),
            pong_tx,
            close_tx.clone(),
        );
        let close_watch_handle = handle.clone();
        let writer_abort = spawn_connection_writer(
            handle,
            connection_id,
            negotiated.writer,
            negotiated.file_sender,
            max_exponent,
            send_rx,
            close_tx,
        );

        let registry = Arc::clone(&self);
        close_watch_handle.spawn(async move {
            let _ = close_rx.recv().await;
            let _ = registry.close_connection(connection_id);
        });

        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::RawSocket,
                    websocket_protocol: None,
                    endpoint_config,
                    stats: None,
                    record: ConnectionRecord::RawSocket {
                        _serializer: serializer,
                        max_exponent,
                        supports_file_segments,
                        frames: Arc::new(Mutex::new(frame_rx)),
                        reader_abort,
                        writer_abort,
                        heartbeat_abort,
                        send_tx,
                    },
                },
            );
    }

    fn register_websocket_connection(
        &self,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        handshake: protocol::WebSocketHandshake,
        peer_addr: SocketAddr,
    ) {
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::WebSocket,
                    websocket_protocol: None,
                    endpoint_config,
                    stats: None,
                    record: ConnectionRecord::WebSocketPending {
                        handshake: Mutex::new(Some(handshake)),
                    },
                },
            );
    }

    fn register_mqtt_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        handshake: protocol::MqttHandshake,
        peer_addr: SocketAddr,
    ) -> Result<(), Error> {
        let version = handshake.version;
        self.register_mqtt_stream_connection(
            handle,
            listener_id,
            connection_id,
            endpoint_config,
            handshake.into_stream(),
            version,
            peer_addr,
            false,
        )
    }

    #[allow(clippy::too_many_arguments)]
    async fn register_mqtt_websocket_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        handshake: protocol::WebSocketHandshake,
        peer_addr: SocketAddr,
    ) -> Result<(), Error> {
        if handshake.sec_websocket_version.as_deref() != Some("13")
            || Base64Engine
                .decode(handshake.sec_websocket_key.as_bytes())
                .map_or(true, |decoded| decoded.len() != 16)
        {
            return Err(Error::Io(io::Error::new(
                io::ErrorKind::InvalidData,
                "invalid MQTT WebSocket upgrade",
            )));
        }
        let accept_value = websocket_accept_value(&handshake.sec_websocket_key);
        let mut stream = handshake.into_stream();
        write_websocket_handshake_response(&mut stream, &accept_value, Some("mqtt")).await?;
        // Keep sparse publications independent of delayed TCP acknowledgments.
        // Queued frame coalescing must not rely on the Nagle timer.
        if stream.is_plain_tcp() {
            let _ = stream.set_nodelay(true);
        }
        self.register_mqtt_stream_connection(
            handle,
            listener_id,
            connection_id,
            endpoint_config,
            stream,
            0,
            peer_addr,
            true,
        )?;
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    fn register_mqtt_stream_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        stream: IoStream,
        version: u8,
        peer_addr: SocketAddr,
        websocket: bool,
    ) -> Result<(), Error> {
        let handle = self
            .mqtt_handle
            .as_ref()
            .filter(|_| stream.is_plain_tcp())
            .cloned()
            .unwrap_or(handle);
        let stream = stream.into_runtime(&handle)?;
        // Bound unsent MQTT bytes without disabling the kernel's TCP window
        // autotuning for high-latency links.
        #[cfg(target_os = "linux")]
        if let Ok(Some(fd)) = stream.try_clone_plain_fd() {
            use std::os::fd::AsRawFd;
            let lowat: u32 = 128 * 1024;
            // SAFETY: fd owns a live TCP socket; lowat points to a valid u32
            // for the duration of this synchronous socket-option call.
            let _ = unsafe {
                libc::setsockopt(
                    fd.as_raw_fd(),
                    libc::IPPROTO_TCP,
                    libc::TCP_NOTSENT_LOWAT,
                    (&lowat as *const u32).cast(),
                    std::mem::size_of_val(&lowat) as libc::socklen_t,
                )
            };
        }
        // Linux reactor wakeups dominate small cleartext MQTT WS traffic.
        // Other platforms and TLS retain immediate flushing.
        let coalesce_bursts = cfg!(target_os = "linux") && stream.is_plain_tcp();
        let (reader, writer) = tokio::io::split(stream);
        let (chunk_tx, chunk_rx) = mpsc::channel(64);
        let notification_pending = Arc::new(AtomicBool::new(false));
        let reader_notification_pending = Arc::clone(&notification_pending);
        let wakeup: Arc<Mutex<Option<extern "C" fn(i32)>>> = Arc::new(Mutex::new(None));
        let reader_wakeup = Arc::clone(&wakeup);
        let (outbound, send_rx) =
            MqttOutboundQueue::new(endpoint_config.outbound_send_queue_capacity);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel::<ConnectionTaskSignal>();
        let reader_close = close_tx.clone();
        let (reader_abort, writer_abort) = if websocket {
            let (control_tx, control_rx) = mpsc::channel(16);
            let reader_abort = spawn_mqtt_websocket_reader(
                handle.clone(),
                coalesce_bursts,
                connection_id,
                reader,
                chunk_tx,
                reader_notification_pending,
                reader_wakeup,
                control_tx,
                reader_close,
            );
            let writer_abort = spawn_mqtt_websocket_writer(
                handle.clone(),
                writer,
                send_rx,
                control_rx,
                close_tx.clone(),
            );
            (reader_abort, writer_abort)
        } else {
            let reader_task = handle.spawn(async move {
                let mut reader = reader;
                loop {
                    let mut buffer = BytesMut::with_capacity(64 * 1024);
                    match reader.read_buf(&mut buffer).await {
                        Ok(0) | Err(_) => break,
                        Ok(_) => {
                            if chunk_tx.send(buffer.freeze()).await.is_err() {
                                break;
                            }
                            // One wake is enough until Dart drains the queue.
                            if !reader_notification_pending.swap(true, Ordering::AcqRel) {
                                if let Some(notify) = *reader_wakeup.lock().unwrap() {
                                    notify(connection_id.0 as i32);
                                }
                            }
                        }
                    }
                }
                let _ = reader_close.send(ConnectionTaskSignal::ReaderClosed);
            });
            let writer_abort =
                spawn_mqtt_tcp_writer(handle.clone(), writer, send_rx, close_tx.clone());
            (reader_task.abort_handle(), writer_abort)
        };
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::Mqtt,
                    websocket_protocol: websocket.then(|| "mqtt".to_string()),
                    endpoint_config,
                    stats: None,
                    record: ConnectionRecord::Mqtt {
                        version,
                        chunks: Arc::new(Mutex::new(MqttInbound::new(chunk_rx))),
                        notification_pending,
                        outbound,
                        wakeup,
                        reader_abort,
                        writer_abort,
                    },
                },
            );
        let registry = Arc::clone(&self);
        handle.spawn(async move {
            if matches!(
                close_rx.recv().await,
                Some(ConnectionTaskSignal::ReaderGracefulClose)
            ) {
                let _ = time::timeout(WEBSOCKET_CLOSE_GRACE, close_rx.recv()).await;
            }
            let _ = registry.close_connection(connection_id);
        });
        Ok(())
    }

    fn accept_websocket_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        connection_id: ConnectionId,
        handshake: protocol::WebSocketHandshake,
        serializer: rawsocket::Serializer,
        protocol: Option<&str>,
    ) -> Result<(), Error> {
        let accept_value = websocket_accept_value(&handshake.sec_websocket_key);
        let mut stream = handshake.into_stream();
        runtime_block_on(
            &handle,
            write_websocket_handshake_response(&mut stream, &accept_value, protocol),
        )
        .map_err(Error::Io)?;
        let _ = stream.set_nodelay(true);
        let (reader, writer) = tokio::io::split(stream);
        let (listener_id, peer_addr, endpoint_config) = {
            let connections = self
                .connections
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            let entry = connections
                .get(&connection_id)
                .ok_or(Error::ConnectionNotFound(connection_id))?;
            (
                entry.listener_id,
                entry.peer_addr,
                Arc::clone(&entry.endpoint_config),
            )
        };
        self.register_established_websocket_connection(
            handle,
            listener_id,
            connection_id,
            endpoint_config,
            peer_addr,
            serializer,
            protocol.map(|value| value.to_string()),
            reader,
            writer,
            true,
            false,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn register_established_websocket_connection(
        self: Arc<Self>,
        handle: tokio::runtime::Handle,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        peer_addr: SocketAddr,
        serializer: rawsocket::Serializer,
        selected_protocol: Option<String>,
        reader: IoReadHalf,
        writer: IoWriteHalf,
        expect_masked_frames: bool,
        mask_outbound_frames: bool,
    ) -> Result<(), Error> {
        let (frame_tx, frame_rx) = mpsc::channel(1024);
        let (send_tx, send_rx) = mpsc::channel(endpoint_config.outbound_send_queue_capacity);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel::<ConnectionTaskSignal>();
        let (pong_tx, pong_rx) = mpsc::unbounded_channel::<Bytes>();
        let heartbeat_abort = endpoint_config.heartbeat_interval.map(|interval| {
            let timeout = endpoint_config
                .heartbeat_timeout
                .unwrap_or_else(|| interval.checked_mul(2).unwrap_or(Duration::from_secs(30)));
            spawn_connection_heartbeat(
                handle.clone(),
                Arc::clone(&self),
                connection_id,
                interval,
                timeout,
                send_tx.clone(),
                pong_rx,
            )
        });
        let pong_tx = heartbeat_abort.as_ref().map(|_| pong_tx);

        let reader_abort = spawn_websocket_reader(
            handle.clone(),
            connection_id,
            serializer,
            endpoint_config.clone(),
            reader,
            frame_tx,
            send_tx.clone(),
            pong_tx,
            close_tx.clone(),
            expect_masked_frames,
        );
        let writer_abort = spawn_websocket_writer(
            handle.clone(),
            connection_id,
            serializer,
            writer,
            send_rx,
            close_tx,
            mask_outbound_frames,
        );

        let registry = Arc::clone(&self);
        handle.spawn(async move {
            if matches!(
                close_rx.recv().await,
                Some(ConnectionTaskSignal::ReaderGracefulClose)
            ) {
                let grace = time::sleep(Duration::from_millis(100));
                tokio::pin!(grace);
                loop {
                    tokio::select! {
                        signal = close_rx.recv() => match signal {
                            Some(ConnectionTaskSignal::WriterClosed) | None => break,
                            Some(ConnectionTaskSignal::ReaderClosed | ConnectionTaskSignal::ReaderGracefulClose) => {}
                        },
                        _ = &mut grace => break,
                    }
                }
            }
            let _ = registry.close_connection(connection_id);
        });

        let mut connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        connections.insert(
            connection_id,
            ConnectionEntry {
                listener_id,
                peer_addr,
                protocol: ConnectionProtocol::WebSocket,
                websocket_protocol: selected_protocol,
                endpoint_config,
                stats: None,
                record: ConnectionRecord::WebSocket {
                    _serializer: serializer,
                    frames: Arc::new(Mutex::new(frame_rx)),
                    reader_abort,
                    writer_abort,
                    writer_runtime: handle.clone(),
                    heartbeat_abort,
                    send_tx,
                },
            },
        );
        Ok(())
    }

    fn reject_websocket_connection(
        &self,
        handle: tokio::runtime::Handle,
        connection_id: ConnectionId,
        handshake: protocol::WebSocketHandshake,
        status: StatusCode,
        reason: Option<&str>,
    ) -> Result<(), Error> {
        let mut stream = handshake.into_stream();
        let body = reason.unwrap_or("websocket upgrade rejected");
        let response = format!(
            "HTTP/1.1 {} {}\r\nConnection: close\r\nContent-Length: {}\r\n\r\n{}",
            status.as_u16(),
            status.canonical_reason().unwrap_or(""),
            body.len(),
            body
        );
        runtime_block_on(&handle, async {
            stream.write_all(response.as_bytes()).await?;
            stream.flush().await?;
            let _ = stream.shutdown().await;
            Ok::<(), io::Error>(())
        })
        .map_err(Error::Io)?;
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .remove(&connection_id);
        Ok(())
    }

    fn finish_http_connection(
        &self,
        connection_id: ConnectionId,
        reason: HttpConnectionCloseReason,
        detail: Option<String>,
    ) {
        #[cfg(feature = "ffi-test")]
        if ffi_test_debug_logs_enabled() {
            eprintln!(
                "registry: finish_http_connection {:?} reason {:?} detail {:?}",
                connection_id, reason, detail
            );
        }
        let entry = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .remove(&connection_id);
        if let Some(entry) = entry {
            if let Some(stats) = entry.stats {
                let event = stats.finalize(connection_id, reason, detail);
                self.push_connection_event(entry.listener_id, event);
            }
        }
    }

    fn push_connection_event(&self, listener_id: ListenerId, event: HttpConnectionEvent) {
        record_http_metrics(listener_id, &event);
        self.connection_events
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .push_back(event);
    }

    fn poll_http_connection_event(&self) -> Option<HttpConnectionEvent> {
        self.connection_events
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .pop_front()
    }

    fn register_http_connection(
        &self,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        peer_addr: SocketAddr,
    ) {
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::Http,
                    websocket_protocol: None,
                    endpoint_config,
                    stats: None,
                    record: ConnectionRecord::HttpPending {
                        pending_requests: Mutex::new(VecDeque::new()),
                    },
                },
            );
    }

    fn register_http2_connection(
        &self,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        handshake: protocol::Http2Handshake,
        peer_addr: SocketAddr,
    ) {
        let stats = HttpConnectionStats::new(ConnectionProtocol::Http2);
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::Http2,
                    websocket_protocol: None,
                    endpoint_config,
                    stats: Some(Arc::clone(&stats)),
                    record: ConnectionRecord::Http2Pending {
                        handshake: Mutex::new(Some(handshake)),
                        pending_requests: Mutex::new(VecDeque::new()),
                    },
                },
            );
    }

    fn register_http3_connection(
        &self,
        listener_id: ListenerId,
        connection_id: ConnectionId,
        endpoint_config: Arc<config::EndpointRuntimeConfig>,
        handshake: protocol::Http3Handshake,
        connection: Option<Arc<QuinnConnection>>,
        peer_addr: SocketAddr,
    ) -> Arc<Http3StreamChannels> {
        let stats = HttpConnectionStats::new(ConnectionProtocol::Http3);
        let streams = Arc::new(Http3StreamChannels::new());
        {
            let mut guard = self
                .connections
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            guard.insert(
                connection_id,
                ConnectionEntry {
                    listener_id,
                    peer_addr,
                    protocol: ConnectionProtocol::Http3,
                    websocket_protocol: None,
                    endpoint_config,
                    stats: Some(Arc::clone(&stats)),
                    record: ConnectionRecord::Http3Pending {
                        handshake: Mutex::new(Some(handshake)),
                        connection: Mutex::new(connection),
                        streams: Arc::clone(&streams),
                        pending_requests: Mutex::new(VecDeque::new()),
                    },
                },
            );
            #[cfg(feature = "ffi-test")]
            {
                if ffi_test_debug_logs_enabled() {
                    let snapshot: Vec<String> = guard
                        .iter()
                        .map(|(id, entry)| format!("{:?}:{:?}", id, entry.protocol))
                        .collect();
                    eprintln!(
                        "registry: registered http3 connection {:?} for listener {:?}, peers {:?}, connections={:?}",
                        connection_id, listener_id, peer_addr, snapshot
                    );
                }
            }
        }
        streams
    }

    fn connection_config(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Arc<config::EndpointRuntimeConfig>, Error> {
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&connection_id)
            .map(|entry| Arc::clone(&entry.endpoint_config))
            .ok_or(Error::ConnectionNotFound(connection_id))
    }

    fn connection_stats(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Option<Arc<HttpConnectionStats>>, Error> {
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&connection_id)
            .map(|entry| entry.stats.clone())
            .ok_or(Error::ConnectionNotFound(connection_id))
    }

    fn listener_config(
        &self,
        listener_id: ListenerId,
    ) -> Result<Arc<config::EndpointRuntimeConfig>, Error> {
        self.listeners
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&listener_id)
            .map(|entry| entry.config_state.endpoint_config())
            .ok_or(Error::ListenerNotFound(listener_id))
    }

    fn connection_exponent(&self, connection_id: ConnectionId) -> Result<u32, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket { max_exponent, .. } => Ok(*max_exponent),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn connection_supports_file_segments(
        &self,
        connection_id: ConnectionId,
    ) -> Result<bool, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket {
                supports_file_segments,
                ..
            } => Ok(*supports_file_segments),
            ConnectionRecord::WebSocket { .. } => Ok(cfg!(any(unix, windows))),
            _ => Ok(false),
        }
    }

    fn connection_protocol(
        &self,
        connection_id: ConnectionId,
    ) -> Result<ConnectionProtocol, Error> {
        self.connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .get(&connection_id)
            .map(|entry| entry.protocol)
            .ok_or(Error::ConnectionNotFound(connection_id))
    }

    fn connection_serializer(
        &self,
        connection_id: ConnectionId,
    ) -> Result<rawsocket::Serializer, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket { _serializer, .. }
            | ConnectionRecord::WebSocket { _serializer, .. } => Ok(*_serializer),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn connection_websocket_protocol(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Option<String>, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match entry.protocol {
            ConnectionProtocol::WebSocket => Ok(entry.websocket_protocol.clone()),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn poll_message(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Option<wamp::ParsedMessage>, Error> {
        let frames = self.message_frames(connection_id)?;
        let mut receiver = frames.lock().unwrap();
        match receiver.try_recv() {
            Ok(message) => Ok(Some(message)),
            Err(TryRecvError::Empty) => Ok(None),
            Err(TryRecvError::Disconnected) => Ok(None),
        }
    }

    fn mqtt_version(&self, connection_id: ConnectionId) -> Result<u8, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Mqtt { version, .. } => Ok(*version),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn set_mqtt_wakeup(
        &self,
        connection_id: ConnectionId,
        callback: Option<extern "C" fn(i32)>,
    ) -> Result<(), Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Mqtt { wakeup, .. } => {
                *wakeup.lock().unwrap() = callback;
                Ok(())
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn poll_mqtt_chunk(
        &self,
        connection_id: ConnectionId,
        max_bytes: usize,
    ) -> Result<Option<Bytes>, Error> {
        let (chunks, notification_pending) = {
            let connections = self
                .connections
                .lock()
                .unwrap_or_else(|poison| poison.into_inner());
            let entry = connections
                .get(&connection_id)
                .ok_or(Error::ConnectionNotFound(connection_id))?;
            match &entry.record {
                ConnectionRecord::Mqtt {
                    chunks,
                    notification_pending,
                    ..
                } => (Arc::clone(chunks), Arc::clone(notification_pending)),
                _ => return Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
            }
        };
        let mut receiver = chunks.lock().unwrap();
        Ok(receiver.poll_with_wake_reset(max_bytes, &notification_pending, || {}))
    }

    fn enqueue_mqtt_chunk(&self, connection_id: ConnectionId, bytes: Bytes) -> Result<(), Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Mqtt { outbound, .. } => outbound.enqueue(connection_id, bytes),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn message_frames(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Arc<Mutex<mpsc::Receiver<wamp::ParsedMessage>>>, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket { frames, .. }
            | ConnectionRecord::WebSocket { frames, .. } => Ok(Arc::clone(frames)),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn enqueue_frame(
        &self,
        connection_id: ConnectionId,
        frame: OutboundFrame,
    ) -> Result<(), Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket { send_tx, .. }
            | ConnectionRecord::WebSocket { send_tx, .. }
                if cfg!(any(unix, windows)) =>
            {
                match send_tx.try_send(frame) {
                    Ok(()) => Ok(()),
                    Err(TrySendError::Full(_)) => Err(Error::SendQueueFull(connection_id)),
                    Err(TrySendError::Closed(_)) => Err(Error::ConnectionNotFound(connection_id)),
                }
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn enqueue_file_frame(
        &self,
        connection_id: ConnectionId,
        frame: OutboundFrame,
    ) -> Result<(), Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::RawSocket {
                supports_file_segments: true,
                send_tx,
                ..
            }
            | ConnectionRecord::WebSocket { send_tx, .. } => match send_tx.try_send(frame) {
                Ok(()) => Ok(()),
                Err(TrySendError::Full(_)) => Err(Error::SendQueueFull(connection_id)),
                Err(TrySendError::Closed(_)) => Err(Error::ConnectionNotFound(connection_id)),
            },
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn take_websocket_handshake(
        &self,
        connection_id: ConnectionId,
    ) -> Result<protocol::WebSocketHandshake, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::WebSocketPending { handshake } => {
                let mut guard = handshake.lock().unwrap();
                guard
                    .take()
                    .ok_or(Error::HandshakeAlreadyTaken(connection_id))
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn take_http2_handshake(
        &self,
        connection_id: ConnectionId,
    ) -> Result<protocol::Http2Handshake, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Http2Pending { handshake, .. } => {
                let mut guard = handshake.lock().unwrap();
                guard
                    .take()
                    .ok_or(Error::HandshakeAlreadyTaken(connection_id))
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn take_http3_handshake(
        &self,
        connection_id: ConnectionId,
    ) -> Result<protocol::Http3Handshake, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        #[cfg(feature = "ffi-test")]
        {
            if ffi_test_debug_logs_enabled() {
                let snapshot: Vec<String> = connections
                    .iter()
                    .map(|(id, entry)| format!("{:?}:{:?}", id, entry.protocol))
                    .collect();
                eprintln!(
                    "registry: take_http3_handshake {:?}, connections={:?}",
                    connection_id, snapshot
                );
            }
        }
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Http3Pending { handshake, .. } => {
                let mut guard = handshake.lock().unwrap();
                guard
                    .take()
                    .ok_or(Error::HandshakeAlreadyTaken(connection_id))
            }
            _ => {
                #[cfg(feature = "ffi-test")]
                if ffi_test_debug_logs_enabled() {
                    eprintln!(
                        "registry: take_http3_handshake {:?} unsupported protocol {:?}",
                        connection_id, entry.protocol
                    );
                }
                Err(Error::UnsupportedProtocol(connection_id, entry.protocol))
            }
        }
    }

    fn http3_connection(&self, connection_id: ConnectionId) -> Result<Arc<QuinnConnection>, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Http3Pending { connection, .. } => {
                let guard = connection.lock().unwrap();
                guard
                    .as_ref()
                    .cloned()
                    .ok_or(Error::ConnectionHandleUnavailable(connection_id))
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn poll_http3_stream(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Option<Http3BidiStream>, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::Http3Pending { streams, .. } => Ok(streams.try_recv()),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn enqueue_http_request(
        &self,
        connection_id: ConnectionId,
        request: QueuedHttpRequest,
    ) -> Result<(), Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::HttpPending { pending_requests }
            | ConnectionRecord::Http2Pending {
                pending_requests, ..
            }
            | ConnectionRecord::Http3Pending {
                pending_requests, ..
            } => {
                let stats = entry.stats.clone();
                let mut guard = pending_requests.lock().unwrap();
                let depth_before = guard.len();
                guard.push_back(request);
                if depth_before > 0 {
                    if let Some(stats) = stats.as_ref() {
                        stats.record_backpressure(depth_before + 1);
                    }
                }
                Ok(())
            }
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }

    fn poll_http_request(
        &self,
        connection_id: ConnectionId,
    ) -> Result<Option<(HttpRequestSummary, HttpResponseHandle)>, Error> {
        let connections = self
            .connections
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        let entry = connections
            .get(&connection_id)
            .ok_or(Error::ConnectionNotFound(connection_id))?;
        match &entry.record {
            ConnectionRecord::HttpPending { pending_requests }
            | ConnectionRecord::Http2Pending {
                pending_requests, ..
            }
            | ConnectionRecord::Http3Pending {
                pending_requests, ..
            } => Ok(pending_requests
                .lock()
                .unwrap()
                .pop_front()
                .map(|entry| (entry.summary, entry.response))),
            _ => Err(Error::UnsupportedProtocol(connection_id, entry.protocol)),
        }
    }
}

fn start_http3_listener(
    listener_id: ListenerId,
    addr: SocketAddr,
    config_state: Arc<ListenerConfigState>,
    registry: Arc<ListenerRegistry>,
    sender: mpsc::Sender<ConnectionId>,
    handle: tokio::runtime::Handle,
    max_pending_handshakes: usize,
) -> Result<(QuinnEndpoint, JoinHandle<()>, SocketAddr), Error> {
    let runtime_config = config_state.endpoint_config();
    let server_config = build_http3_server_config(&runtime_config)?;
    let endpoint = {
        // Quinn's synchronous constructor needs our reactor, not nested blocking.
        let _runtime = handle.enter();
        QuinnEndpoint::server(server_config, addr).map_err(Error::Io)?
    };
    let local_addr = endpoint.local_addr().map_err(Error::Io)?;

    let registry_for_task = Arc::clone(&registry);
    let config_for_task = Arc::clone(&config_state);
    let sender_for_task = sender.clone();
    let endpoint_for_task = endpoint.clone();
    let listener = handle.spawn(async move {
        // A stalled unauthenticated peer must not serialize the whole listener.
        // Own the bounded tasks here so listener cancellation aborts them too.
        let mut handshakes = JoinSet::new();
        loop {
            while handshakes.try_join_next().is_some() {}
            tokio::select! {
                _ = sender_for_task.closed() => break,
                Some(_) = handshakes.join_next(), if !handshakes.is_empty() => {},
                incoming = endpoint_for_task.accept() => {
                    let Some(incoming) = incoming else { break };
                    #[cfg(feature = "ffi-test")]
                    if ffi_test_debug_logs_enabled() {
                        eprintln!(
                            "http3 incoming on {:?} at {} from {}, pending handshakes {} of {}",
                            listener_id, local_addr, incoming.remote_address(),
                            handshakes.len(), max_pending_handshakes
                        );
                    }
                    if handshakes.len() >= max_pending_handshakes {
                        incoming.refuse();
                        continue;
                    }
                    let registry_for_task = Arc::clone(&registry_for_task);
                    let config_for_task = Arc::clone(&config_for_task);
                    let sender_for_task = sender_for_task.clone();
                    let deadline = config_for_task.endpoint_config().handshake_timeout;
                    handshakes.spawn(async move {
                        let connection = match time::timeout(deadline, async { incoming.await }).await {
                            Ok(Ok(connection)) => connection,
                            failure => {
                                // Failed unauthenticated handshakes must not amplify logs.
                                #[cfg(feature = "ffi-test")]
                                if ffi_test_debug_logs_enabled() {
                                    eprintln!("http3 handshake failed for listener {:?}: {:?}", listener_id, failure);
                                }
                                let _ = failure;
                                return;
                            }
                        };
                        let peer_addr = connection.remote_address();
                        let runtime_for_task = config_for_task.endpoint_config();
                        let handshake = Http3Handshake::from_endpoint(&runtime_for_task);
                        let Ok(connection_id) = registry_for_task.next_connection_id() else {
                            connection.close(quinn::VarInt::from_u32(0), b"connection capacity exhausted");
                            return;
                        };
                        #[cfg(feature = "ffi-test")]
                        if ffi_test_debug_logs_enabled() {
                            eprintln!(
                                "http3 connection accepted on {:?} from {} (id {:?})",
                                listener_id, peer_addr, connection_id
                            );
                        }
                        let connection = Arc::new(connection);
                        let streams = registry_for_task.register_http3_connection(
                            listener_id,
                            connection_id,
                            Arc::clone(&runtime_for_task),
                            handshake,
                            Some(Arc::clone(&connection)),
                            peer_addr,
                        );
                        #[cfg(feature = "ffi-test")]
                        if ffi_test_debug_logs_enabled() {
                            eprintln!(
                                "http3 registry stored {:?} with protocol {:?}",
                                connection_id,
                                registry_for_task.connection_protocol(connection_id)
                            );
                        }
                        let registry_for_connection = Arc::clone(&registry_for_task);
                        let endpoint_for_connection = Arc::clone(&runtime_for_task);
                        tokio::spawn(async move {
                            serve_http3_requests(
                                listener_id,
                                connection_id,
                                endpoint_for_connection,
                                registry_for_connection,
                                connection,
                                streams,
                            )
                            .await;
                        });
                        let _ = sender_for_task.send(connection_id).await;
                    });
                }
            }
        }
        endpoint_for_task.close(VarInt::from_u32(0), b"listener stopped");
    });

    Ok((endpoint, listener, local_addr))
}

fn build_http3_server_config(
    endpoint: &config::EndpointRuntimeConfig,
) -> Result<QuinnServerConfig, Error> {
    let (certs, key) = load_http3_identity(endpoint)?;
    let provider = rustls::crypto::ring::default_provider();
    let client_auth_verifier = tls::build_client_cert_verifier(endpoint, &provider)?;
    let builder = match client_auth_verifier {
        Some(verifier) => RustlsServerConfig::builder().with_client_cert_verifier(verifier),
        None => RustlsServerConfig::builder().with_no_client_auth(),
    };
    let mut crypto = builder.with_single_cert(certs, key).map_err(|err| {
        Error::RouterConfigInvalid(format!(
            "endpoint {}:{} http3 certificate invalid: {}",
            endpoint.host, endpoint.port, err
        ))
    })?;
    let mut alpn = endpoint
        .http_settings()
        .map(|settings| {
            settings
                .alpn
                .iter()
                .filter(|token| token.eq_ignore_ascii_case("h3") || token.starts_with("h3-"))
                .map(|token| token.as_bytes().to_vec())
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    if alpn.is_empty() {
        alpn.push(b"h3".to_vec());
    }
    crypto.alpn_protocols = alpn;
    let mut server = QuinnServerConfig::with_crypto(Arc::new(
        QuinnRustlsServerConfig::try_from(crypto).map_err(|err| {
            Error::RouterConfigInvalid(format!(
                "endpoint {}:{} http3 rustls config invalid: {}",
                endpoint.host, endpoint.port, err
            ))
        })?,
    ));
    let transport = Arc::get_mut(&mut server.transport).expect("fresh http3 transport config");
    apply_http3_transport_tuning(transport);
    Ok(server)
}

fn http2_server_builder() -> h2_server::Builder {
    let mut builder = h2_server::Builder::new();
    apply_http2_transport_tuning(&mut builder);
    builder
}

fn apply_http2_transport_tuning(builder: &mut h2_server::Builder) {
    builder
        .max_concurrent_streams(HTTP2_MAX_CONCURRENT_STREAMS)
        .initial_window_size(HTTP2_INITIAL_STREAM_WINDOW)
        .initial_connection_window_size(HTTP2_INITIAL_CONNECTION_WINDOW)
        .max_frame_size(HTTP2_MAX_FRAME_SIZE)
        .max_header_list_size(HTTP2_MAX_HEADER_LIST_SIZE)
        .max_concurrent_reset_streams(HTTP2_MAX_CONCURRENT_RESET_STREAMS)
        .max_send_buffer_size(HTTP2_MAX_SEND_BUFFER_SIZE);
}

fn apply_http3_transport_tuning(transport: &mut quinn::TransportConfig) {
    transport
        .max_concurrent_bidi_streams(VarInt::from_u32(HTTP3_MAX_BIDI_STREAMS))
        .max_concurrent_uni_streams(VarInt::from_u32(HTTP3_MAX_UNI_STREAMS))
        .stream_receive_window(VarInt::from_u32(HTTP3_STREAM_RECEIVE_WINDOW))
        .receive_window(VarInt::from_u32(HTTP3_CONNECTION_RECEIVE_WINDOW))
        .send_window(HTTP3_SEND_WINDOW)
        .datagram_receive_buffer_size(Some(HTTP3_DATAGRAM_BUFFER_BYTES))
        .datagram_send_buffer_size(HTTP3_DATAGRAM_BUFFER_BYTES)
        .keep_alive_interval(Some(HTTP3_KEEP_ALIVE_INTERVAL));
}

fn load_http3_identity(
    endpoint: &config::EndpointRuntimeConfig,
) -> Result<(Vec<CertificateDer<'static>>, PrivateKeyDer<'static>), Error> {
    let cert_entry = endpoint.sni_certificates.first().ok_or_else(|| {
        Error::RouterConfigInvalid(format!(
            "endpoint {}:{} requires SNI certificate for http3",
            endpoint.host, endpoint.port
        ))
    })?;
    let mut cert_reader = Cursor::new(cert_entry.certificate_chain_pem.as_bytes());
    let certs = load_certs(&mut cert_reader)
        .collect::<Result<Vec<_>, _>>()
        .map_err(|err| {
            Error::RouterConfigInvalid(format!(
                "endpoint {}:{} failed to parse http3 certificate: {}",
                endpoint.host, endpoint.port, err
            ))
        })?;
    if certs.is_empty() {
        return Err(Error::RouterConfigInvalid(format!(
            "endpoint {}:{} http3 certificate chain empty",
            endpoint.host, endpoint.port
        )));
    }

    let private_key = {
        let mut key_reader = Cursor::new(cert_entry.private_key_pem.as_bytes());
        let mut keys = pkcs8_private_keys(&mut key_reader)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|err| {
                Error::RouterConfigInvalid(format!(
                    "endpoint {}:{} failed to parse pkcs8 key for http3: {}",
                    endpoint.host, endpoint.port, err
                ))
            })?
            .into_iter()
            .map(|der| der.into())
            .collect::<Vec<_>>();
        if keys.is_empty() {
            let mut rsa_reader = Cursor::new(cert_entry.private_key_pem.as_bytes());
            keys = rsa_private_keys(&mut rsa_reader)
                .collect::<Result<Vec<_>, _>>()
                .map_err(|err| {
                    Error::RouterConfigInvalid(format!(
                        "endpoint {}:{} failed to parse rsa key for http3: {}",
                        endpoint.host, endpoint.port, err
                    ))
                })?
                .into_iter()
                .map(|der| der.into())
                .collect();
        }
        keys.into_iter().next().ok_or_else(|| {
            Error::RouterConfigInvalid(format!(
                "endpoint {}:{} http3 private key missing",
                endpoint.host, endpoint.port
            ))
        })?
    };

    Ok((certs, private_key))
}

#[derive(Debug)]
enum FrameReadError {
    Io(io::Error),
    Protocol(String),
}

impl From<io::Error> for FrameReadError {
    fn from(value: io::Error) -> Self {
        FrameReadError::Io(value)
    }
}

impl std::fmt::Display for FrameReadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FrameReadError::Io(err) => write!(f, "io error: {}", err),
            FrameReadError::Protocol(msg) => write!(f, "protocol error: {}", msg),
        }
    }
}

impl std::error::Error for FrameReadError {}

enum InboundFrame {
    Message(Bytes),
    Ping(Bytes),
    Pong(Bytes),
}

#[derive(Debug)]
struct OutboundFileSegment {
    file: Arc<File>,
    offset: u64,
    len: usize,
    encoding: FileSegmentEncoding,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FileSegmentEncoding {
    Identity,
    Base64,
}

impl FileSegmentEncoding {
    fn wire_len(self, source_len: usize) -> Option<usize> {
        match self {
            Self::Identity => Some(source_len),
            Self::Base64 => source_len
                .checked_add(2)
                .map(|value| value / 3)
                .and_then(|groups| groups.checked_mul(4)),
        }
    }
}

struct OutboundFrame {
    frame_type: u8,
    payload_len: usize,
    segments: Vec<Bytes>,
    deferred_segment: Option<Box<dyn FnOnce() -> Result<Bytes, String> + Send + 'static>>,
    file_segment: Option<OutboundFileSegment>,
    suffix_segments: Vec<Bytes>,
    completion: Option<WriteGuard>,
}

impl OutboundFrame {
    fn tracked(mut self) -> (Self, WriteReceipt) {
        let (guard, receipt) = WriteGuard::new();
        self.completion = Some(guard);
        (self, receipt)
    }

    fn barrier() -> Self {
        Self::control(0xff, Bytes::new())
    }

    fn message(payload: Bytes) -> Self {
        let len = payload.len();
        Self {
            frame_type: 0,
            payload_len: len,
            segments: vec![payload],
            completion: None,
            deferred_segment: None,
            file_segment: None,
            suffix_segments: Vec::new(),
        }
    }

    fn message_segments(segments: Vec<Bytes>) -> Self {
        let payload_len = segments.iter().map(|segment| segment.len()).sum();
        Self {
            frame_type: 0,
            payload_len,
            segments,
            completion: None,
            deferred_segment: None,
            file_segment: None,
            suffix_segments: Vec::new(),
        }
    }

    fn message_deferred_segment<F>(
        prefix: Bytes,
        deferred_len: usize,
        prepare: F,
    ) -> Result<Self, Error>
    where
        F: FnOnce() -> Result<Bytes, String> + Send + 'static,
    {
        Self::message_deferred_segment_with_suffix(prefix, deferred_len, Bytes::new(), prepare)
    }

    fn message_deferred_segment_with_suffix<F>(
        prefix: Bytes,
        deferred_len: usize,
        suffix: Bytes,
        prepare: F,
    ) -> Result<Self, Error>
    where
        F: FnOnce() -> Result<Bytes, String> + Send + 'static,
    {
        let payload_len = prefix
            .len()
            .checked_add(deferred_len)
            .and_then(|value| value.checked_add(suffix.len()))
            .ok_or(Error::InvalidDeferredSegment("payload length overflow"))?;
        Ok(Self {
            frame_type: 0,
            payload_len,
            segments: vec![prefix],
            completion: None,
            deferred_segment: Some(Box::new(prepare)),
            file_segment: None,
            suffix_segments: if suffix.is_empty() {
                Vec::new()
            } else {
                vec![suffix]
            },
        })
    }

    fn message_file_segment(
        prefix: Bytes,
        file: Arc<File>,
        offset: u64,
        len: usize,
        suffix: Bytes,
        encoding: FileSegmentEncoding,
    ) -> Result<Self, Error> {
        let wire_len = encoding
            .wire_len(len)
            .ok_or(Error::InvalidFileSegment("encoded file length overflow"))?;
        let payload_len = prefix
            .len()
            .checked_add(wire_len)
            .and_then(|value| value.checked_add(suffix.len()))
            .ok_or(Error::InvalidFileSegment("payload length overflow"))?;
        Ok(Self {
            frame_type: 0,
            payload_len,
            segments: vec![prefix],
            completion: None,
            deferred_segment: None,
            file_segment: Some(OutboundFileSegment {
                file,
                offset,
                len,
                encoding,
            }),
            suffix_segments: vec![suffix],
        })
    }

    fn control(frame_type: u8, payload: Bytes) -> Self {
        let len = payload.len();
        Self {
            frame_type,
            payload_len: len,
            segments: vec![payload],
            completion: None,
            deferred_segment: None,
            file_segment: None,
            suffix_segments: Vec::new(),
        }
    }

    fn close(code: Option<u16>, reason: &str) -> Self {
        Self::control(0x03, encode_websocket_close_payload(code, reason))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ConnectionTaskSignal {
    ReaderClosed,
    ReaderGracefulClose,
    WriterClosed,
}

fn spawn_connection_reader(
    handle: tokio::runtime::Handle,
    connection_id: ConnectionId,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    mut reader: IoReadHalf,
    serializer: rawsocket::Serializer,
    max_message_size_exponent: u32,
    frame_tx: mpsc::Sender<wamp::ParsedMessage>,
    send_tx: mpsc::Sender<OutboundFrame>,
    pong_tx: Option<UnboundedSender<Bytes>>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let max_payload = 1u64 << max_message_size_exponent;
        let upgraded_protocol = max_message_size_exponent > 24;
        let idle_timeout = endpoint_config.idle_timeout;

        loop {
            let read_future = read_inbound_frame(&mut reader, max_payload, upgraded_protocol);
            let frame = if let Some(timeout) = idle_timeout {
                match time::timeout(timeout, read_future).await {
                    Ok(result) => result,
                    Err(_) => {
                        eprintln!(
                            "connection {:?} idle for {:?}, closing",
                            connection_id, timeout
                        );
                        break;
                    }
                }
            } else {
                read_future.await
            };

            let frame = match frame {
                Ok(frame) => frame,
                Err(FrameReadError::Io(err)) => {
                    if !is_benign_socket_shutdown(err.kind()) {
                        eprintln!("connection {:?} io error: {}", connection_id, err);
                    }
                    break;
                }
                Err(FrameReadError::Protocol(reason)) => {
                    eprintln!(
                        "connection {:?} protocol violation: {}",
                        connection_id, reason
                    );
                    break;
                }
            };

            match frame {
                InboundFrame::Message(payload) => match wamp::parse_message(serializer, payload) {
                    Ok(parsed) => {
                        if frame_tx.send(parsed).await.is_err() {
                            break;
                        }
                    }
                    Err(err) => {
                        eprintln!(
                            "connection {:?} failed to parse WAMP message: {:?}",
                            connection_id, err
                        );
                        break;
                    }
                },
                InboundFrame::Ping(payload) => {
                    if send_tx
                        .send(OutboundFrame::control(0x02, payload))
                        .await
                        .is_err()
                    {
                        break;
                    }
                }
                InboundFrame::Pong(payload) => {
                    if let Some(tx) = &pong_tx {
                        let _ = tx.send(payload);
                    }
                }
            }
        }
        let _ = close_tx.send(ConnectionTaskSignal::ReaderClosed);
    });
    task.abort_handle()
}

async fn resolve_deferred_segment(mut frame: OutboundFrame) -> Result<OutboundFrame, String> {
    let Some(prepare) = frame.deferred_segment.take() else {
        return Ok(frame);
    };
    let segment = tokio::task::spawn_blocking(prepare)
        .await
        .map_err(|err| format!("preparation task failed: {err}"))??;
    let actual_len = frame
        .segments
        .iter()
        .chain(std::iter::once(&segment))
        .chain(frame.suffix_segments.iter())
        .try_fold(
            frame
                .file_segment
                .as_ref()
                .and_then(|file| file.encoding.wire_len(file.len))
                .unwrap_or(0usize),
            |sum, part| sum.checked_add(part.len()),
        )
        .ok_or_else(|| "prepared payload length overflow".to_string())?;
    if actual_len != frame.payload_len {
        return Err(format!(
            "prepared payload length {actual_len} did not match expected {}",
            frame.payload_len
        ));
    }
    frame.segments.push(segment);
    Ok(frame)
}

fn spawn_connection_writer<W: AsyncWrite + Unpin + Send + 'static>(
    handle: tokio::runtime::Handle,
    connection_id: ConnectionId,
    mut writer: W,
    file_sender: Option<rawsocket::RawSocketFileSender>,
    max_message_size_exponent: u32,
    mut rx: mpsc::Receiver<OutboundFrame>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let upgraded_protocol = max_message_size_exponent > 24;
        let mut file_scratch = Vec::new();
        let mut encoded_file_scratch = Vec::new();
        'writer: while let Some(frame) = rx.recv().await {
            let mut frame = match resolve_deferred_segment(frame).await {
                Ok(frame) => frame,
                Err(err) => {
                    eprintln!(
                        "connection {:?} failed to prepare deferred frame: {}",
                        connection_id, err
                    );
                    break;
                }
            };
            if frame.frame_type == 0xff {
                if writer.flush().await.is_err() {
                    break;
                }
                if let Some(completion) = frame.completion.take() {
                    completion.written();
                }
                continue;
            }
            if frame.frame_type > 2 {
                continue;
            }
            let header =
                match encode_frame_header(frame.frame_type, frame.payload_len, upgraded_protocol) {
                    Ok(header) => header,
                    Err(err) => {
                        eprintln!(
                            "connection {:?} failed to encode outbound frame header: {}",
                            connection_id, err
                        );
                        continue;
                    }
                };

            if let Err(err) = writer.write_all(header.as_bytes()).await {
                if err.kind() != io::ErrorKind::BrokenPipe {
                    eprintln!(
                        "connection {:?} failed to write frame header: {}",
                        connection_id, err
                    );
                }
                break;
            }

            for segment in frame.segments {
                if segment.is_empty() {
                    continue;
                }
                if let Err(err) = writer.write_all(&segment).await {
                    if err.kind() != io::ErrorKind::BrokenPipe {
                        eprintln!(
                            "connection {:?} failed to write frame payload: {}",
                            connection_id, err
                        );
                    }
                    break 'writer;
                }
            }

            if let Some(segment) = frame.file_segment {
                let result =
                    if segment.encoding == FileSegmentEncoding::Identity && file_sender.is_some() {
                        let sender = file_sender.as_ref().expect("checked above");
                        sender
                            .send_file_segment(&segment.file, segment.offset, segment.len)
                            .await
                    } else {
                        write_file_segment_buffered(
                            &mut writer,
                            &segment,
                            &mut file_scratch,
                            &mut encoded_file_scratch,
                        )
                        .await
                    };
                if let Err(err) = result {
                    if !is_benign_socket_shutdown(err.kind()) {
                        eprintln!(
                            "connection {:?} failed to send file segment: {}",
                            connection_id, err
                        );
                    }
                    break;
                }
            }

            for segment in frame.suffix_segments {
                if segment.is_empty() {
                    continue;
                }
                if let Err(err) = writer.write_all(&segment).await {
                    if !is_benign_socket_shutdown(err.kind()) {
                        eprintln!(
                            "connection {:?} failed to write frame suffix: {}",
                            connection_id, err
                        );
                    }
                    break 'writer;
                }
            }
            if let Err(err) = writer.flush().await {
                if !is_benign_socket_shutdown(err.kind()) {
                    eprintln!(
                        "connection {:?} failed to flush frame: {}",
                        connection_id, err
                    );
                }
                break;
            }
            if let Some(completion) = frame.completion.take() {
                completion.written();
            }
        }
        let _ = close_tx.send(ConnectionTaskSignal::WriterClosed);
    });
    task.abort_handle()
}

fn spawn_connection_heartbeat(
    handle: tokio::runtime::Handle,
    registry: Arc<ListenerRegistry>,
    connection_id: ConnectionId,
    interval: Duration,
    timeout: Duration,
    send_tx: mpsc::Sender<OutboundFrame>,
    mut pong_rx: UnboundedReceiver<Bytes>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let mut ticker = time::interval(interval);
        ticker.set_missed_tick_behavior(time::MissedTickBehavior::Delay);

        let mut next_nonce: u64 = 1;
        let mut awaiting = false;
        let mut last_ping_at = Instant::now();
        let mut last_payload = Bytes::new();

        loop {
            tokio::select! {
                _ = ticker.tick() => {
                    if awaiting {
                        if last_ping_at.elapsed() >= timeout {
                            eprintln!(
                                "connection {:?} heartbeat timeout after {:?}, closing",
                                connection_id, timeout
                            );
                            let _ = registry.close_connection(connection_id);
                            break;
                        }
                        continue;
                    }

                    let payload = Bytes::copy_from_slice(&next_nonce.to_be_bytes());
                    next_nonce = next_nonce.wrapping_add(1);
                    last_payload = payload.clone();
                    last_ping_at = Instant::now();
                    awaiting = true;
                    if send_tx
                        .send(OutboundFrame::control(0x01, payload))
                        .await
                        .is_err()
                    {
                        let _ = registry.close_connection(connection_id);
                        break;
                    }
                }
                received = pong_rx.recv() => {
                    let Some(payload) = received else {
                        break;
                    };
                    if awaiting && payload == last_payload {
                        awaiting = false;
                    } else {
                        // Treat any pong as liveness; payload mismatch might come from
                        // other intermediaries. We'll resync on the next ping.
                        awaiting = false;
                    }
                }
            }
        }
    });
    task.abort_handle()
}

fn spawn_mqtt_tcp_writer<W: AsyncWrite + Unpin + Send + 'static>(
    handle: tokio::runtime::Handle,
    mut writer: W,
    mut send_rx: mpsc::Receiver<MqttOutboundChunk>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        while let Some((bytes, _permit)) = send_rx.recv().await {
            if writer.write_all(&bytes).await.is_err() {
                break;
            }
        }
        let _ = close_tx.send(ConnectionTaskSignal::WriterClosed);
    });
    task.abort_handle()
}

#[allow(clippy::too_many_arguments)]
fn spawn_mqtt_websocket_reader<R: AsyncRead + Unpin + Send + 'static>(
    handle: tokio::runtime::Handle,
    coalesce_bursts: bool,
    connection_id: ConnectionId,
    reader: R,
    chunk_tx: mpsc::Sender<Bytes>,
    notification_pending: Arc<AtomicBool>,
    wakeup: Arc<Mutex<Option<extern "C" fn(i32)>>>,
    control_tx: mpsc::Sender<(u8, Bytes)>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        // Most MQTT publishes occupy small WebSocket frames. Read ahead so
        // their headers and masks do not each require a socket read.
        let mut reader = BufReader::with_capacity(16 * 1024, reader);
        let mut pending = BytesMut::new();
        let pool = Arc::new(WebSocketBufferPool::default());
        let mut accumulator = WebSocketMessageAccumulator::new(Arc::clone(&pool));
        let mut graceful = false;
        let mut pending_messages = 0;
        'read: loop {
            if pending.is_empty() {
                pending_messages = 0;
            }
            let result = if coalesce_bursts
                && pending_messages >= 2
                && !websocket_buffer_contains_complete_frame(reader.buffer())
            {
                let mut next = std::pin::pin!(read_websocket_frame_mode(&mut reader, &pool, true));
                // Keep the same future across the yield and flush: it may
                // already own a partial frame header, mask or payload.
                let first = std::future::poll_fn(|cx| {
                    Poll::Ready(std::future::Future::poll(next.as_mut(), cx))
                })
                .await;
                match first {
                    Poll::Ready(result) => result,
                    Poll::Pending => {
                        // Give already-woken I/O one scheduler turn without
                        // imposing a millisecond timer on the tail of a burst.
                        tokio::task::yield_now().await;
                        match std::future::poll_fn(|cx| {
                            Poll::Ready(std::future::Future::poll(next.as_mut(), cx))
                        })
                        .await
                        {
                            Poll::Ready(result) => result,
                            Poll::Pending => {
                                if !flush_mqtt_websocket_inbound(
                                    &mut pending,
                                    &chunk_tx,
                                    &notification_pending,
                                    &wakeup,
                                    connection_id,
                                )
                                .await
                                {
                                    break;
                                }
                                pending_messages = 0;
                                next.await
                            }
                        }
                    }
                }
            } else {
                read_websocket_frame_mode(&mut reader, &pool, true).await
            };
            let frame = match result {
                Ok(frame) => frame,
                Err(error) => {
                    if !flush_mqtt_websocket_inbound(
                        &mut pending,
                        &chunk_tx,
                        &notification_pending,
                        &wakeup,
                        connection_id,
                    )
                    .await
                    {
                        break;
                    }
                    if let Some(code) = error.close_code() {
                        graceful = control_tx
                            .send((0x8, Bytes::copy_from_slice(&code.to_be_bytes())))
                            .await
                            .is_ok();
                    }
                    break;
                }
            };
            if !matches!(
                &frame,
                WebSocketFrame::Data {
                    opcode: 0x2 | 0x0,
                    ..
                }
            ) && !flush_mqtt_websocket_inbound(
                &mut pending,
                &chunk_tx,
                &notification_pending,
                &wakeup,
                connection_id,
            )
            .await
            {
                break;
            }
            match frame {
                WebSocketFrame::Data {
                    opcode,
                    fin,
                    payload,
                } => {
                    if opcode == 0x1 {
                        let _ = control_tx
                            .send((0x8, Bytes::from_static(&[0x03, 0xeb])))
                            .await;
                        graceful = true;
                        break;
                    }
                    if let Err(error) = accumulator.push(opcode, fin, payload) {
                        if !flush_mqtt_websocket_inbound(
                            &mut pending,
                            &chunk_tx,
                            &notification_pending,
                            &wakeup,
                            connection_id,
                        )
                        .await
                        {
                            break;
                        }
                        // Accumulator failures are framing errors and always
                        // warrant a protocol close, including future variants.
                        let code = error.close_code().unwrap_or(1002);
                        graceful = control_tx
                            .send((0x8, Bytes::copy_from_slice(&code.to_be_bytes())))
                            .await
                            .is_ok();
                        break;
                    }
                    if let Some(message) = accumulator.take_complete() {
                        let segments = match message {
                            CompletedWebSocketMessage::Single(bytes) => vec![bytes],
                            CompletedWebSocketMessage::Segmented { segments, .. } => segments,
                        };
                        let nonempty =
                            coalesce_bursts && segments.iter().any(|segment| !segment.is_empty());
                        for segment in segments {
                            let mut offset = 0;
                            while offset < segment.len() {
                                if pending.is_empty() && segment.len() - offset >= 64 * 1024 {
                                    let end = offset + 64 * 1024;
                                    if !send_mqtt_websocket_inbound(
                                        segment.slice(offset..end),
                                        &chunk_tx,
                                        &notification_pending,
                                        &wakeup,
                                        connection_id,
                                    )
                                    .await
                                    {
                                        break 'read;
                                    }
                                    offset = end;
                                    continue;
                                }
                                let end = (offset + 64 * 1024 - pending.len()).min(segment.len());
                                pending.extend_from_slice(&segment[offset..end]);
                                offset = end;
                                if pending.len() == 64 * 1024 {
                                    if !flush_mqtt_websocket_inbound(
                                        &mut pending,
                                        &chunk_tx,
                                        &notification_pending,
                                        &wakeup,
                                        connection_id,
                                    )
                                    .await
                                    {
                                        break 'read;
                                    }
                                    pending_messages = 0;
                                }
                            }
                        }
                        if nonempty && !pending.is_empty() {
                            pending_messages += 1;
                        }
                    }
                }
                WebSocketFrame::Ping(payload) => {
                    if control_tx.send((0xA, payload)).await.is_err() {
                        break;
                    }
                }
                WebSocketFrame::Pong(_) => {}
                WebSocketFrame::Close(code, reason) => {
                    let mut payload = Vec::new();
                    if let Some(code) = code {
                        payload.extend_from_slice(&code.to_be_bytes());
                        payload.extend_from_slice(reason.as_bytes());
                    }
                    let _ = control_tx.send((0x8, Bytes::from(payload))).await;
                    graceful = true;
                    break;
                }
            }
            if !websocket_buffer_contains_complete_frame(reader.buffer())
                && (!coalesce_bursts || pending_messages < 2)
                && !flush_mqtt_websocket_inbound(
                    &mut pending,
                    &chunk_tx,
                    &notification_pending,
                    &wakeup,
                    connection_id,
                )
                .await
            {
                break;
            }
        }
        let _ = flush_mqtt_websocket_inbound(
            &mut pending,
            &chunk_tx,
            &notification_pending,
            &wakeup,
            connection_id,
        )
        .await;
        let _ = close_tx.send(if graceful {
            ConnectionTaskSignal::ReaderGracefulClose
        } else {
            ConnectionTaskSignal::ReaderClosed
        });
    });
    task.abort_handle()
}

async fn send_mqtt_websocket_inbound(
    bytes: Bytes,
    chunk_tx: &mpsc::Sender<Bytes>,
    notification_pending: &AtomicBool,
    wakeup: &Mutex<Option<extern "C" fn(i32)>>,
    connection_id: ConnectionId,
) -> bool {
    if chunk_tx.send(bytes).await.is_err() {
        return false;
    }
    if !notification_pending.swap(true, Ordering::AcqRel) {
        if let Some(notify) = *wakeup.lock().unwrap() {
            notify(connection_id.0 as i32);
        }
    }
    true
}

async fn flush_mqtt_websocket_inbound(
    pending: &mut BytesMut,
    chunk_tx: &mpsc::Sender<Bytes>,
    notification_pending: &AtomicBool,
    wakeup: &Mutex<Option<extern "C" fn(i32)>>,
    connection_id: ConnectionId,
) -> bool {
    pending.is_empty()
        || send_mqtt_websocket_inbound(
            pending.split().freeze(),
            chunk_tx,
            notification_pending,
            wakeup,
            connection_id,
        )
        .await
}

fn websocket_buffer_contains_complete_frame(buffer: &[u8]) -> bool {
    if buffer.len() < 2 {
        return false;
    }
    let length_code = buffer[1] & 0x7f;
    let extended_length = match length_code {
        126 => 2,
        127 => 8,
        _ => 0,
    };
    let header_length = 2 + extended_length + if buffer[1] & 0x80 != 0 { 4 } else { 0 };
    if buffer.len() < header_length {
        return false;
    }
    let payload_length = match length_code {
        126 => u16::from_be_bytes([buffer[2], buffer[3]]) as u64,
        127 => u64::from_be_bytes(buffer[2..10].try_into().unwrap()),
        _ => length_code as u64,
    };
    payload_length <= (buffer.len() - header_length) as u64
}

fn spawn_mqtt_websocket_writer<W: AsyncWrite + Unpin + Send + 'static>(
    handle: tokio::runtime::Handle,
    mut writer: W,
    mut send_rx: mpsc::Receiver<MqttOutboundChunk>,
    mut control_rx: mpsc::Receiver<(u8, Bytes)>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let mut mask_scratch = Vec::new();
        let mut controls_open = true;
        loop {
            let (opcode, bytes, _permit) = tokio::select! {
                biased;
                control = control_rx.recv(), if controls_open => match control {
                    Some((opcode, bytes)) => (opcode, bytes, None),
                    None => { controls_open = false; continue; }
                },
                outbound = send_rx.recv() => match outbound {
                    Some((bytes, permit)) => (0x2, bytes, Some(permit)),
                    None => break,
                },
            };
            if write_websocket_frame_mode(
                &mut writer,
                opcode,
                bytes.len(),
                std::slice::from_ref(&bytes),
                &[],
                false,
                &mut mask_scratch,
            )
            .await
            .is_err()
                || writer.flush().await.is_err()
            {
                break;
            }
            if opcode == 0x8 {
                break;
            }
        }
        let _ = close_tx.send(ConnectionTaskSignal::WriterClosed);
    });
    task.abort_handle()
}

fn spawn_websocket_reader(
    handle: tokio::runtime::Handle,
    connection_id: ConnectionId,
    serializer: rawsocket::Serializer,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    mut reader: IoReadHalf,
    frame_tx: mpsc::Sender<wamp::ParsedMessage>,
    send_tx: mpsc::Sender<OutboundFrame>,
    pong_tx: Option<UnboundedSender<Bytes>>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
    expect_masked_frames: bool,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let idle_timeout = endpoint_config.idle_timeout;
        let buffer_pool = Arc::new(WebSocketBufferPool::default());
        let mut accumulator = WebSocketMessageAccumulator::new(Arc::clone(&buffer_pool));
        let mut graceful_close_requested = false;
        loop {
            let read_future =
                read_websocket_frame_mode(&mut reader, &buffer_pool, expect_masked_frames);
            let frame = if let Some(timeout) = idle_timeout {
                match time::timeout(timeout, read_future).await {
                    Ok(result) => result,
                    Err(_) => {
                        eprintln!(
                            "connection {:?} idle for {:?}, closing",
                            connection_id, timeout
                        );
                        break;
                    }
                }
            } else {
                read_future.await
            };

            let frame = match frame {
                Ok(frame) => frame,
                Err(err) => {
                    if err.is_peer_disconnect() {
                        break;
                    }
                    eprintln!("connection {:?} websocket error: {}", connection_id, err);
                    if let Some(code) = err.close_code() {
                        graceful_close_requested = send_tx
                            .send(OutboundFrame::close(Some(code), ""))
                            .await
                            .is_ok();
                    }
                    break;
                }
            };

            match frame {
                WebSocketFrame::Data {
                    opcode,
                    fin,
                    payload,
                } => {
                    if let Err(err) = accumulator.push(opcode, fin, payload) {
                        eprintln!(
                            "connection {:?} websocket framing error: {}",
                            connection_id, err
                        );
                        if let Some(code) = err.close_code() {
                            graceful_close_requested = send_tx
                                .send(OutboundFrame::close(Some(code), ""))
                                .await
                                .is_ok();
                        }
                        break;
                    }
                    if let Some(message) = accumulator.take_complete() {
                        if let Err(err) =
                            handle_websocket_message(serializer, message, &buffer_pool, &frame_tx)
                                .await
                        {
                            eprintln!(
                                "connection {:?} failed to parse WAMP message: {}",
                                connection_id, err
                            );
                            break;
                        }
                    }
                }
                WebSocketFrame::Ping(payload) => {
                    let _ = send_tx.send(OutboundFrame::control(0x02, payload)).await;
                }
                WebSocketFrame::Pong(payload) => {
                    if let Some(tx) = &pong_tx {
                        let _ = tx.send(payload);
                    }
                }
                WebSocketFrame::Close(code, reason) => {
                    graceful_close_requested = send_tx
                        .send(OutboundFrame::close(code, &reason))
                        .await
                        .is_ok();
                    break;
                }
            }
        }
        let signal = if graceful_close_requested {
            ConnectionTaskSignal::ReaderGracefulClose
        } else {
            ConnectionTaskSignal::ReaderClosed
        };
        let _ = close_tx.send(signal);
    });
    task.abort_handle()
}

fn spawn_websocket_writer<W: AsyncWrite + Unpin + Send + 'static>(
    handle: tokio::runtime::Handle,
    connection_id: ConnectionId,
    serializer: rawsocket::Serializer,
    mut writer: W,
    mut rx: mpsc::Receiver<OutboundFrame>,
    close_tx: UnboundedSender<ConnectionTaskSignal>,
    mask_outbound_frames: bool,
) -> AbortHandle {
    let task = handle.spawn(async move {
        let mut close_sent = false;
        let mut write_failed = false;
        let mut mask_scratch = Vec::new();
        let mut file_scratch = Vec::new();
        let mut encoded_file_scratch = Vec::new();
        while let Some(frame) = rx.recv().await {
            let mut frame = match resolve_deferred_segment(frame).await {
                Ok(frame) => frame,
                Err(err) => {
                    eprintln!(
                        "connection {:?} failed to prepare deferred websocket frame: {}",
                        connection_id, err
                    );
                    write_failed = true;
                    break;
                }
            };
            if frame.frame_type == 0xff {
                if writer.flush().await.is_err() {
                    write_failed = true;
                    break;
                }
                if let Some(completion) = frame.completion.take() {
                    completion.written();
                }
                continue;
            }
            let is_close_frame = frame.frame_type == 3;
            let opcode = match frame.frame_type {
                0 => match serializer {
                    rawsocket::Serializer::Json => 0x1,
                    _ => 0x2,
                },
                1 => 0x9,
                2 => 0xA,
                3 => 0x8,
                _ => continue,
            };
            let result = if let Some(file_segment) = frame.file_segment.as_ref() {
                write_websocket_file_frame_mode(
                    &mut writer,
                    opcode,
                    frame.payload_len,
                    &frame.segments,
                    file_segment,
                    &frame.suffix_segments,
                    mask_outbound_frames,
                    &mut mask_scratch,
                    &mut file_scratch,
                    &mut encoded_file_scratch,
                )
                .await
            } else {
                write_websocket_frame_mode(
                    &mut writer,
                    opcode,
                    frame.payload_len,
                    &frame.segments,
                    &frame.suffix_segments,
                    mask_outbound_frames,
                    &mut mask_scratch,
                )
                .await
            };
            if let Err(err) = result {
                if !is_benign_socket_shutdown(err.kind()) {
                    eprintln!(
                        "connection {:?} failed to write websocket frame: {}",
                        connection_id, err
                    );
                }
                write_failed = true;
                break;
            }
            if let Err(err) = writer.flush().await {
                if !is_benign_socket_shutdown(err.kind()) {
                    eprintln!(
                        "connection {:?} failed to flush websocket frame: {}",
                        connection_id, err
                    );
                }
                write_failed = true;
                break;
            }
            if let Some(completion) = frame.completion.take() {
                completion.written();
            }
            if is_close_frame {
                close_sent = true;
                break;
            }
        }
        if !close_sent && !write_failed {
            let close_frame = OutboundFrame::close(Some(1000), "");
            if let Err(err) = write_websocket_frame_mode(
                &mut writer,
                0x8,
                close_frame.payload_len,
                &close_frame.segments,
                &close_frame.suffix_segments,
                mask_outbound_frames,
                &mut mask_scratch,
            )
            .await
            {
                if !is_benign_socket_shutdown(err.kind()) {
                    eprintln!(
                        "connection {:?} failed to write websocket close frame: {}",
                        connection_id, err
                    );
                }
            }
        }
        let _ = close_tx.send(ConnectionTaskSignal::WriterClosed);
    });
    task.abort_handle()
}

async fn read_inbound_frame(
    stream: &mut IoReadHalf,
    max_payload: u64,
    upgraded_protocol: bool,
) -> Result<InboundFrame, FrameReadError> {
    let (frame_type, length_u64) = if upgraded_protocol {
        let mut header = [0u8; 5];
        stream.read_exact(&mut header).await?;
        if header[0] & !0x07 != 0 {
            return Err(FrameReadError::Protocol(
                "reserved bits must be zero".into(),
            ));
        }
        let frame_type = header[0] & 0x07;
        let length = u32::from_be_bytes([header[1], header[2], header[3], header[4]]) as u64;
        (frame_type, length)
    } else {
        let mut header = [0u8; 4];
        stream.read_exact(&mut header).await?;

        let reserved = header[0] >> 4;
        if reserved != 0 {
            return Err(FrameReadError::Protocol(
                "reserved bits must be zero".into(),
            ));
        }

        let length_hi = (header[0] >> 3) & 0x01;
        let frame_type = header[0] & 0x07;

        let mut length = ((header[1] as u32) << 16) | ((header[2] as u32) << 8) | header[3] as u32;
        if length_hi == 1 {
            if length != 0 {
                return Err(FrameReadError::Protocol(
                    "extended length bit set with non-zero length bytes".into(),
                ));
            }
            length = 1 << 24;
        }

        (frame_type, length as u64)
    };

    if length_u64 > max_payload {
        return Err(FrameReadError::Protocol(format!(
            "frame length {} exceeds negotiated maximum {}",
            length_u64, max_payload
        )));
    }
    if !upgraded_protocol && length_u64 > MAX_FRAME_LEN {
        return Err(FrameReadError::Protocol(format!(
            "frame length {} exceeds supported maximum {}",
            length_u64, MAX_FRAME_LEN
        )));
    }

    let payload = read_exact_frame_payload(stream, length_u64 as usize).await?;

    match frame_type {
        0 => Ok(InboundFrame::Message(payload)),
        1 => Ok(InboundFrame::Ping(payload)),
        2 => Ok(InboundFrame::Pong(payload)),
        _ => Err(FrameReadError::Protocol(format!(
            "unsupported frame type {}",
            frame_type
        ))),
    }
}

async fn read_exact_frame_payload<R>(stream: &mut R, length: usize) -> io::Result<Bytes>
where
    R: AsyncRead + Unpin,
{
    let mut payload = BytesMut::with_capacity(length);
    while payload.len() < length {
        let read = stream.read_buf(&mut payload).await?;
        if read == 0 {
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before RawSocket frame payload completed",
            ));
        }
    }
    Ok(payload.freeze())
}

#[derive(Debug)]
enum WebSocketFrame {
    Data {
        opcode: u8,
        fin: bool,
        payload: Bytes,
    },
    Ping(Bytes),
    Pong(Bytes),
    Close(Option<u16>, String),
}

#[derive(Debug)]
struct WebSocketFrameError {
    message: String,
    close_code: Option<u16>,
    io_kind: Option<io::ErrorKind>,
}

impl WebSocketFrameError {
    fn io(err: io::Error) -> Self {
        Self {
            message: err.to_string(),
            close_code: None,
            io_kind: Some(err.kind()),
        }
    }

    fn protocol(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            close_code: Some(1002),
            io_kind: None,
        }
    }

    fn invalid_payload(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            close_code: Some(1007),
            io_kind: None,
        }
    }

    fn message_too_big(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
            close_code: Some(1009),
            io_kind: None,
        }
    }

    fn close_code(&self) -> Option<u16> {
        self.close_code
    }

    fn is_peer_disconnect(&self) -> bool {
        matches!(
            self.io_kind,
            Some(
                io::ErrorKind::UnexpectedEof
                    | io::ErrorKind::BrokenPipe
                    | io::ErrorKind::ConnectionReset
                    | io::ErrorKind::ConnectionAborted
            )
        )
    }
}

impl std::fmt::Display for WebSocketFrameError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.message)
    }
}

impl std::error::Error for WebSocketFrameError {}

const MAX_POOLED_WEBSOCKET_BUFFERS: usize = 32;

#[derive(Debug, Default)]
struct WebSocketBufferPool {
    buffers: Mutex<Vec<Vec<u8>>>,
}

impl WebSocketBufferPool {
    fn acquire(self: &Arc<Self>, len: usize) -> PooledWebSocketBuffer {
        let mut buffer = self.take_buffer(len);
        buffer.resize(len, 0);
        PooledWebSocketBuffer {
            pool: Arc::clone(self),
            buffer,
        }
    }

    fn acquire_capacity(self: &Arc<Self>, capacity: usize) -> PooledWebSocketBuffer {
        let buffer = self.take_buffer(capacity);
        PooledWebSocketBuffer {
            pool: Arc::clone(self),
            buffer,
        }
    }

    fn take_buffer(&self, min_capacity: usize) -> Vec<u8> {
        let mut buffers = self
            .buffers
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        if let Some(index) = buffers
            .iter()
            .position(|buffer| buffer.capacity() >= min_capacity)
        {
            return buffers.swap_remove(index);
        }
        Vec::with_capacity(min_capacity)
    }

    fn recycle(&self, mut buffer: Vec<u8>) {
        buffer.clear();
        let mut buffers = self
            .buffers
            .lock()
            .unwrap_or_else(|poison| poison.into_inner());
        if buffers.len() < MAX_POOLED_WEBSOCKET_BUFFERS {
            buffers.push(buffer);
        }
    }

    #[cfg(test)]
    fn available_buffers(&self) -> usize {
        self.buffers
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .len()
    }
}

#[derive(Debug)]
struct PooledWebSocketBuffer {
    pool: Arc<WebSocketBufferPool>,
    buffer: Vec<u8>,
}

impl PooledWebSocketBuffer {
    fn as_mut_slice(&mut self) -> &mut [u8] {
        self.buffer.as_mut_slice()
    }

    fn extend_from_bytes(&mut self, bytes: &Bytes) {
        self.buffer.extend_from_slice(bytes.as_ref());
    }

    fn into_bytes(self) -> Bytes {
        Bytes::from_owner(self)
    }
}

impl AsRef<[u8]> for PooledWebSocketBuffer {
    fn as_ref(&self) -> &[u8] {
        self.buffer.as_ref()
    }
}

impl Drop for PooledWebSocketBuffer {
    fn drop(&mut self) {
        let buffer = std::mem::take(&mut self.buffer);
        if buffer.capacity() > 0 {
            self.pool.recycle(buffer);
        }
    }
}

#[derive(Debug)]
enum WebSocketMessageStorage {
    Single(Bytes),
    Segmented { segments: Vec<Bytes>, len: usize },
}

#[derive(Debug)]
enum CompletedWebSocketMessage {
    Single(Bytes),
    Segmented { segments: Vec<Bytes>, len: usize },
}

impl CompletedWebSocketMessage {
    fn into_bytes(self, pool: &Arc<WebSocketBufferPool>) -> Bytes {
        match self {
            CompletedWebSocketMessage::Single(bytes) => bytes,
            CompletedWebSocketMessage::Segmented { segments, len } => {
                let mut pooled = pool.acquire_capacity(len);
                for segment in segments {
                    if segment.is_empty() {
                        continue;
                    }
                    pooled.extend_from_bytes(&segment);
                }
                pooled.into_bytes()
            }
        }
    }
}

struct WebSocketMessageAccumulator {
    opcode: Option<u8>,
    storage: Option<WebSocketMessageStorage>,
    complete: bool,
}

impl WebSocketMessageAccumulator {
    fn new(_pool: Arc<WebSocketBufferPool>) -> Self {
        Self {
            opcode: None,
            storage: None,
            complete: false,
        }
    }

    fn push(&mut self, opcode: u8, fin: bool, payload: Bytes) -> Result<(), WebSocketFrameError> {
        if opcode == 0x0 {
            if self.opcode.is_none() {
                return Err(WebSocketFrameError::protocol(
                    "received continuation frame without initial opcode",
                ));
            }
        } else if opcode == 0x1 || opcode == 0x2 {
            if self.opcode.is_some() {
                return Err(WebSocketFrameError::protocol(
                    "received new data frame before finishing continuation",
                ));
            }
            self.opcode = Some(opcode);
        } else {
            return Err(WebSocketFrameError::protocol("unsupported data opcode"));
        }

        if self.len() + payload.len() > MAX_WEBSOCKET_MESSAGE_LEN {
            return Err(WebSocketFrameError::message_too_big(
                "websocket message exceeds supported length",
            ));
        }

        match self.storage.take() {
            None => {
                self.storage = Some(WebSocketMessageStorage::Single(payload));
            }
            Some(WebSocketMessageStorage::Single(existing)) => {
                let len = existing.len() + payload.len();
                self.storage = Some(WebSocketMessageStorage::Segmented {
                    segments: vec![existing, payload],
                    len,
                });
            }
            Some(WebSocketMessageStorage::Segmented {
                mut segments,
                mut len,
            }) => {
                len += payload.len();
                segments.push(payload);
                self.storage = Some(WebSocketMessageStorage::Segmented { segments, len });
            }
        }
        if fin {
            self.complete = true;
        }
        Ok(())
    }

    fn take_complete(&mut self) -> Option<CompletedWebSocketMessage> {
        if self.complete {
            self.opcode = None;
            self.complete = false;
            self.storage.take().map(|storage| match storage {
                WebSocketMessageStorage::Single(bytes) => CompletedWebSocketMessage::Single(bytes),
                WebSocketMessageStorage::Segmented { segments, len } => {
                    CompletedWebSocketMessage::Segmented { segments, len }
                }
            })
        } else {
            None
        }
    }

    fn len(&self) -> usize {
        match &self.storage {
            Some(WebSocketMessageStorage::Single(bytes)) => bytes.len(),
            Some(WebSocketMessageStorage::Segmented { len, .. }) => *len,
            None => 0,
        }
    }
}

#[cfg(test)]
async fn read_websocket_frame(
    reader: &mut IoReadHalf,
    buffer_pool: &Arc<WebSocketBufferPool>,
) -> Result<WebSocketFrame, WebSocketFrameError> {
    read_websocket_frame_mode(reader, buffer_pool, true).await
}

async fn read_websocket_frame_mode<R: AsyncRead + Unpin>(
    reader: &mut R,
    buffer_pool: &Arc<WebSocketBufferPool>,
    expect_masked: bool,
) -> Result<WebSocketFrame, WebSocketFrameError> {
    let mut header = [0u8; 2];
    reader
        .read_exact(&mut header)
        .await
        .map_err(WebSocketFrameError::io)?;
    if header[0] & 0x70 != 0 {
        return Err(WebSocketFrameError::protocol(
            "websocket reserved bits must be zero",
        ));
    }
    let fin = header[0] & 0x80 != 0;
    let opcode = header[0] & 0x0F;
    let masked = header[1] & 0x80 != 0;
    if masked != expect_masked {
        return Err(WebSocketFrameError::protocol(if expect_masked {
            "client websocket frames must be masked"
        } else {
            "server websocket frames must not be masked"
        }));
    }
    let is_control_frame = opcode & 0x08 != 0;
    if is_control_frame && !fin {
        return Err(WebSocketFrameError::protocol(
            "websocket control frames must not be fragmented",
        ));
    }
    let mut len = (header[1] & 0x7F) as u64;
    if len == 126 {
        let mut extended = [0u8; 2];
        reader
            .read_exact(&mut extended)
            .await
            .map_err(WebSocketFrameError::io)?;
        len = u16::from_be_bytes(extended) as u64;
    } else if len == 127 {
        let mut extended = [0u8; 8];
        reader
            .read_exact(&mut extended)
            .await
            .map_err(WebSocketFrameError::io)?;
        len = u64::from_be_bytes(extended);
    }
    if is_control_frame && len > 125 {
        return Err(WebSocketFrameError::protocol(
            "websocket control frames must not exceed 125 bytes",
        ));
    }
    if len as usize > MAX_WEBSOCKET_MESSAGE_LEN {
        return Err(WebSocketFrameError::message_too_big(
            "websocket frame exceeds supported length",
        ));
    }
    let mut mask = [0u8; 4];
    if masked {
        reader
            .read_exact(&mut mask)
            .await
            .map_err(WebSocketFrameError::io)?;
    }
    let mut payload = if len == 0 {
        None
    } else {
        Some(buffer_pool.acquire(len as usize))
    };
    if len > 0 {
        reader
            .read_exact(
                payload
                    .as_mut()
                    .expect("payload buffer exists for non-empty websocket frame")
                    .as_mut_slice(),
            )
            .await
            .map_err(WebSocketFrameError::io)?;
        if masked {
            xor_websocket_mask(
                payload
                    .as_mut()
                    .expect("payload buffer exists for masked websocket frame")
                    .as_mut_slice(),
                &mask,
                0,
            );
        }
    }
    let payload = payload
        .map(PooledWebSocketBuffer::into_bytes)
        .unwrap_or_else(Bytes::new);
    match opcode {
        0x0 | 0x1 | 0x2 => Ok(WebSocketFrame::Data {
            opcode,
            fin,
            payload,
        }),
        0x8 => parse_websocket_close_frame_payload(&payload)
            .map(|(code, reason)| WebSocketFrame::Close(code, reason)),
        0x9 => Ok(WebSocketFrame::Ping(payload)),
        0xA => Ok(WebSocketFrame::Pong(payload)),
        _ => Err(WebSocketFrameError::protocol(
            "unsupported websocket opcode",
        )),
    }
}

fn parse_websocket_close_frame_payload(
    payload: &[u8],
) -> Result<(Option<u16>, String), WebSocketFrameError> {
    if payload.is_empty() {
        return Ok((None, String::new()));
    }
    if payload.len() == 1 {
        return Err(WebSocketFrameError::protocol(
            "websocket close frame payload must be empty or include a 2-byte status code",
        ));
    }
    let code = u16::from_be_bytes([payload[0], payload[1]]);
    let reason = std::str::from_utf8(&payload[2..])
        .map_err(|_| {
            WebSocketFrameError::invalid_payload("websocket close reason must be valid UTF-8")
        })?
        .to_string();
    Ok((Some(code), reason))
}

fn encode_websocket_close_payload(code: Option<u16>, reason: &str) -> Bytes {
    let Some(code) = code else {
        return Bytes::new();
    };
    let mut payload = Vec::with_capacity(125.min(reason.len() + 2));
    payload.extend_from_slice(&code.to_be_bytes());
    let reason_bytes = reason.as_bytes();
    let remaining = 125usize.saturating_sub(payload.len());
    payload.extend_from_slice(&reason_bytes[..reason_bytes.len().min(remaining)]);
    Bytes::from(payload)
}

#[cfg(test)]
async fn write_websocket_frame<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    payload_len: usize,
    segments: &[Bytes],
) -> io::Result<()> {
    let mut mask_scratch = Vec::new();
    write_websocket_frame_mode(
        writer,
        opcode,
        payload_len,
        segments,
        &[],
        false,
        &mut mask_scratch,
    )
    .await
}

#[cfg(test)]
async fn write_websocket_frame_client<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    payload_len: usize,
    segments: &[Bytes],
) -> io::Result<()> {
    let mut mask_scratch = Vec::with_capacity(WEBSOCKET_MASK_CHUNK_SIZE);
    write_websocket_frame_mode(
        writer,
        opcode,
        payload_len,
        segments,
        &[],
        true,
        &mut mask_scratch,
    )
    .await
}

async fn write_websocket_frame_mode<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    payload_len: usize,
    segments: &[Bytes],
    suffix_segments: &[Bytes],
    mask_payload: bool,
    mask_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let combined_segments;
    let segments = if suffix_segments.is_empty() {
        segments
    } else {
        combined_segments = segments
            .iter()
            .chain(suffix_segments)
            .cloned()
            .collect::<Vec<_>>();
        combined_segments.as_slice()
    };
    let is_data_frame = matches!(opcode, 0x1 | 0x2);
    if is_data_frame
        && segments
            .iter()
            .filter(|segment| !segment.is_empty())
            .count()
            > 1
    {
        return write_websocket_continuation_frames(
            writer,
            opcode,
            segments,
            mask_payload,
            mask_scratch,
        )
        .await;
    }

    let payload = segments
        .iter()
        .find(|segment| !segment.is_empty())
        .map(Bytes::as_ref)
        .unwrap_or(&[]);
    write_websocket_frame_fragment_mode(
        writer,
        opcode,
        true,
        payload_len.min(payload.len()),
        payload,
        mask_payload,
        mask_scratch,
    )
    .await
}

async fn write_websocket_continuation_frames<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    segments: &[Bytes],
    mask_payload: bool,
    mask_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let non_empty_count = segments
        .iter()
        .filter(|segment| !segment.is_empty())
        .count();
    if non_empty_count <= 1 {
        let payload = segments
            .iter()
            .find(|segment| !segment.is_empty())
            .map(Bytes::as_ref)
            .unwrap_or(&[]);
        return write_websocket_frame_fragment_mode(
            writer,
            opcode,
            true,
            payload.len(),
            payload,
            mask_payload,
            mask_scratch,
        )
        .await;
    }

    let last_index = segments
        .iter()
        .enumerate()
        .rev()
        .find_map(|(index, segment)| (!segment.is_empty()).then_some(index))
        .expect("non-empty segment exists when continuation frames are requested");
    let mut sent_first = false;
    mask_scratch.clear();
    for (index, segment) in segments.iter().enumerate() {
        if segment.is_empty() {
            continue;
        }
        let frame_opcode = if sent_first { 0x0 } else { opcode };
        sent_first = true;
        let (header, mask) = websocket_frame_header(
            frame_opcode,
            index == last_index,
            segment.len(),
            mask_payload,
        );
        let frame_len = header.len() + segment.len();
        if frame_len > WEBSOCKET_COALESCE_FRAME_SIZE {
            flush_websocket_frame_batch(writer, mask_scratch).await?;
            write_websocket_frame_fragment_mode(
                writer,
                frame_opcode,
                index == last_index,
                segment.len(),
                segment.as_ref(),
                mask_payload,
                mask_scratch,
            )
            .await?;
            mask_scratch.clear();
            continue;
        }
        if mask_scratch.len() + frame_len > WEBSOCKET_COALESCE_FRAME_SIZE {
            flush_websocket_frame_batch(writer, mask_scratch).await?;
        }
        mask_scratch.extend_from_slice(&header);
        let payload_start = mask_scratch.len();
        mask_scratch.extend_from_slice(segment.as_ref());
        if let Some(mask) = mask.as_ref() {
            record_websocket_mask_copy(segment.len());
            xor_websocket_mask(&mut mask_scratch[payload_start..], mask, 0);
        } else {
            record_websocket_coalesce_copy(segment.len());
        }
    }
    flush_websocket_frame_batch(writer, mask_scratch).await
}

async fn flush_websocket_frame_batch<W: AsyncWrite + Unpin>(
    writer: &mut W,
    write_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    if write_scratch.is_empty() {
        return Ok(());
    }
    writer.write_all(write_scratch).await?;
    write_scratch.clear();
    Ok(())
}

async fn write_websocket_frame_fragment_mode<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    fin: bool,
    payload_len: usize,
    payload: &[u8],
    mask_payload: bool,
    mask_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let (header, mask) = websocket_frame_header(opcode, fin, payload_len, mask_payload);
    if let Some(mask) = mask.as_ref() {
        return write_masked_websocket_frame(writer, &header, payload, mask, mask_scratch).await;
    }
    write_unmasked_websocket_frame(writer, &header, payload, mask_scratch).await
}

async fn write_unmasked_websocket_frame<W: AsyncWrite + Unpin>(
    writer: &mut W,
    header: &[u8],
    payload: &[u8],
    write_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    if payload.is_empty() {
        return writer.write_all(header).await;
    }
    if writer.is_write_vectored() {
        let mut header_offset = 0usize;
        let mut payload_offset = 0usize;
        while header_offset < header.len() || payload_offset < payload.len() {
            let slices = [
                io::IoSlice::new(&header[header_offset..]),
                io::IoSlice::new(&payload[payload_offset..]),
            ];
            let written = writer.write_vectored(&slices).await?;
            if written == 0 {
                return Err(io::Error::new(
                    io::ErrorKind::WriteZero,
                    "failed to write WebSocket frame",
                ));
            }
            let header_remaining = header.len() - header_offset;
            if written < header_remaining {
                header_offset += written;
            } else {
                header_offset = header.len();
                payload_offset += written - header_remaining;
            }
        }
        return Ok(());
    }
    if payload.len() <= WEBSOCKET_COALESCE_FRAME_SIZE {
        let frame_len = header.len() + payload.len();
        if write_scratch.len() < frame_len {
            write_scratch.resize(frame_len, 0);
        }
        write_scratch[..header.len()].copy_from_slice(header);
        write_scratch[header.len()..frame_len].copy_from_slice(payload);
        record_websocket_coalesce_copy(payload.len());
        return writer.write_all(&write_scratch[..frame_len]).await;
    }
    writer.write_all(header).await?;
    writer.write_all(payload).await
}

async fn write_masked_websocket_frame<W: AsyncWrite + Unpin>(
    writer: &mut W,
    header: &[u8],
    payload: &[u8],
    mask: &[u8; 4],
    mask_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    if payload.is_empty() {
        return writer.write_all(header).await;
    }

    // Masking already requires a scratch copy, so include the header in the
    // first write rather than scheduling a separate async write per frame.
    let first_chunk_len = payload.len().min(WEBSOCKET_MASK_CHUNK_SIZE);
    let first_write_len = header.len() + first_chunk_len;
    if mask_scratch.len() < first_write_len {
        mask_scratch.resize(first_write_len, 0);
    }
    mask_scratch[..header.len()].copy_from_slice(header);
    mask_scratch[header.len()..first_write_len].copy_from_slice(&payload[..first_chunk_len]);
    record_websocket_mask_copy(first_chunk_len);
    xor_websocket_mask(&mut mask_scratch[header.len()..first_write_len], mask, 0);
    writer.write_all(&mask_scratch[..first_write_len]).await?;

    let mut payload_offset = first_chunk_len;
    let mut remaining = &payload[first_chunk_len..];
    while !remaining.is_empty() {
        let chunk_len = remaining.len().min(WEBSOCKET_MASK_CHUNK_SIZE);
        if mask_scratch.len() < chunk_len {
            mask_scratch.resize(chunk_len, 0);
        }
        mask_scratch[..chunk_len].copy_from_slice(&remaining[..chunk_len]);
        record_websocket_mask_copy(chunk_len);
        xor_websocket_mask(&mut mask_scratch[..chunk_len], mask, payload_offset);
        writer.write_all(&mask_scratch[..chunk_len]).await?;
        payload_offset += chunk_len;
        remaining = &remaining[chunk_len..];
    }
    Ok(())
}

fn websocket_frame_header(
    opcode: u8,
    fin: bool,
    payload_len: usize,
    mask_payload: bool,
) -> (Vec<u8>, Option<[u8; 4]>) {
    let mut header = Vec::with_capacity(2);
    header.push((if fin { 0x80 } else { 0x00 }) | (opcode & 0x0F));
    if payload_len < 126 {
        header.push(payload_len as u8);
    } else if payload_len <= 0xFFFF {
        header.push(126);
        header.extend_from_slice(&(payload_len as u16).to_be_bytes());
    } else {
        header.push(127);
        header.extend_from_slice(&(payload_len as u64).to_be_bytes());
    }
    let mask = if mask_payload {
        let mut mask = [0u8; 4];
        header[1] |= 0x80;
        rand::thread_rng().fill_bytes(&mut mask);
        header.extend_from_slice(&mask);
        Some(mask)
    } else {
        None
    };
    (header, mask)
}

fn xor_websocket_mask(payload: &mut [u8], mask: &[u8; 4], offset: usize) {
    let mask_offset = offset & 3;
    let mut mask_bytes = [0u8; 16];
    for (index, byte) in mask_bytes.iter_mut().enumerate() {
        *byte = mask[(mask_offset + index) & 3];
    }
    let mask_word = u128::from_ne_bytes(mask_bytes);
    let mut chunks = payload.chunks_exact_mut(16);
    for chunk in chunks.by_ref() {
        let value = u128::from_ne_bytes(
            chunk
                .try_into()
                .expect("websocket mask chunk has the fixed vector width"),
        );
        chunk.copy_from_slice(&(value ^ mask_word).to_ne_bytes());
    }
    for (index, byte) in chunks.into_remainder().iter_mut().enumerate() {
        *byte ^= mask[(mask_offset + index) & 3];
    }
}

async fn write_websocket_payload<W: AsyncWrite + Unpin>(
    writer: &mut W,
    payload: &[u8],
    mask: Option<&[u8; 4]>,
    payload_offset: &mut usize,
    mask_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let Some(mask) = mask else {
        if !payload.is_empty() {
            writer.write_all(payload).await?;
        }
        *payload_offset += payload.len();
        return Ok(());
    };
    let mut remaining = payload;
    while !remaining.is_empty() {
        let chunk_len = remaining.len().min(WEBSOCKET_MASK_CHUNK_SIZE);
        if mask_scratch.len() < chunk_len {
            mask_scratch.resize(chunk_len, 0);
        }
        mask_scratch[..chunk_len].copy_from_slice(&remaining[..chunk_len]);
        record_websocket_mask_copy(chunk_len);
        xor_websocket_mask(&mut mask_scratch[..chunk_len], mask, *payload_offset);
        writer.write_all(&mask_scratch[..chunk_len]).await?;
        *payload_offset += chunk_len;
        remaining = &remaining[chunk_len..];
    }
    Ok(())
}

async fn write_file_segment_buffered<W: AsyncWrite + Unpin>(
    writer: &mut W,
    segment: &OutboundFileSegment,
    file_scratch: &mut Vec<u8>,
    encoded_file_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let mut remaining = segment.len;
    let mut file_offset = segment.offset;
    while remaining > 0 {
        let chunk_len = match segment.encoding {
            FileSegmentEncoding::Identity => remaining.min(FILE_SEGMENT_BUFFER_SIZE),
            FileSegmentEncoding::Base64 => remaining.min(BASE64_FILE_SEGMENT_INPUT_SIZE),
        };
        read_file_chunk_at(&segment.file, file_offset, chunk_len, file_scratch).await?;
        match segment.encoding {
            FileSegmentEncoding::Identity => {
                writer.write_all(&file_scratch[..chunk_len]).await?;
            }
            FileSegmentEncoding::Base64 => {
                let encoded_len =
                    FileSegmentEncoding::Base64
                        .wire_len(chunk_len)
                        .ok_or_else(|| {
                            io::Error::new(io::ErrorKind::InvalidInput, "base64 length overflow")
                        })?;
                encoded_file_scratch.resize(encoded_len, 0);
                let written = Base64Engine
                    .encode_slice(
                        &file_scratch[..chunk_len],
                        &mut encoded_file_scratch[..encoded_len],
                    )
                    .map_err(|err| io::Error::new(io::ErrorKind::InvalidData, err.to_string()))?;
                writer.write_all(&encoded_file_scratch[..written]).await?;
            }
        }
        file_offset = file_offset
            .checked_add(chunk_len as u64)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "file offset overflow"))?;
        remaining -= chunk_len;
    }
    record_buffered_file_segment(segment.len);
    Ok(())
}

async fn read_file_chunk_at(
    file: &Arc<File>,
    offset: u64,
    chunk_len: usize,
    scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let file = Arc::clone(file);
    let mut buffer = std::mem::take(scratch);
    buffer.resize(chunk_len, 0);
    let result = tokio::task::spawn_blocking(move || {
        read_file_exact_at(file.as_ref(), offset, &mut buffer[..chunk_len])?;
        Ok::<Vec<u8>, io::Error>(buffer)
    })
    .await
    .map_err(|err| {
        io::Error::new(
            io::ErrorKind::Other,
            format!("file read task failed: {err}"),
        )
    })?;
    *scratch = result?;
    Ok(())
}

#[cfg(unix)]
fn read_file_exact_at(file: &File, mut offset: u64, mut buffer: &mut [u8]) -> io::Result<()> {
    use std::os::unix::fs::FileExt;

    while !buffer.is_empty() {
        match file.read_at(buffer, offset) {
            Ok(0) => {
                return Err(io::Error::new(
                    io::ErrorKind::UnexpectedEof,
                    "file ended before the queued segment",
                ));
            }
            Ok(read) => {
                offset = offset.checked_add(read as u64).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "file offset overflow")
                })?;
                buffer = &mut buffer[read..];
            }
            Err(err) if err.kind() == io::ErrorKind::Interrupted => continue,
            Err(err) => return Err(err),
        }
    }
    Ok(())
}

#[cfg(windows)]
fn read_file_exact_at(file: &File, mut offset: u64, mut buffer: &mut [u8]) -> io::Result<()> {
    use std::os::windows::fs::FileExt;

    while !buffer.is_empty() {
        match file.seek_read(buffer, offset) {
            Ok(0) => {
                return Err(io::Error::new(
                    io::ErrorKind::UnexpectedEof,
                    "file ended before the queued segment",
                ));
            }
            Ok(read) => {
                offset = offset.checked_add(read as u64).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "file offset overflow")
                })?;
                buffer = &mut buffer[read..];
            }
            Err(err) if err.kind() == io::ErrorKind::Interrupted => continue,
            Err(err) => return Err(err),
        }
    }
    Ok(())
}

#[cfg(not(any(unix, windows)))]
fn read_file_exact_at(_file: &File, _offset: u64, _buffer: &mut [u8]) -> io::Result<()> {
    Err(io::Error::new(
        io::ErrorKind::Unsupported,
        "file-backed WAMP frames require positional file reads",
    ))
}

#[allow(clippy::too_many_arguments)]
async fn write_websocket_file_frame_mode<W: AsyncWrite + Unpin>(
    writer: &mut W,
    opcode: u8,
    payload_len: usize,
    prefix_segments: &[Bytes],
    file_segment: &OutboundFileSegment,
    suffix_segments: &[Bytes],
    mask_payload: bool,
    mask_scratch: &mut Vec<u8>,
    file_scratch: &mut Vec<u8>,
    encoded_file_scratch: &mut Vec<u8>,
) -> io::Result<()> {
    let (header, mask) = websocket_frame_header(opcode, true, payload_len, mask_payload);
    writer.write_all(&header).await?;
    let mut payload_offset = 0usize;
    for segment in prefix_segments {
        write_websocket_payload(
            writer,
            segment,
            mask.as_ref(),
            &mut payload_offset,
            mask_scratch,
        )
        .await?;
    }

    let mut remaining = file_segment.len;
    let mut file_offset = file_segment.offset;
    while remaining > 0 {
        let chunk_len = match file_segment.encoding {
            FileSegmentEncoding::Identity => remaining.min(FILE_SEGMENT_BUFFER_SIZE),
            FileSegmentEncoding::Base64 => remaining.min(BASE64_FILE_SEGMENT_INPUT_SIZE),
        };
        read_file_chunk_at(&file_segment.file, file_offset, chunk_len, file_scratch).await?;
        match file_segment.encoding {
            FileSegmentEncoding::Identity => {
                if let Some(mask) = mask.as_ref() {
                    xor_websocket_mask(&mut file_scratch[..chunk_len], mask, payload_offset);
                }
                writer.write_all(&file_scratch[..chunk_len]).await?;
                payload_offset += chunk_len;
            }
            FileSegmentEncoding::Base64 => {
                let encoded_len =
                    FileSegmentEncoding::Base64
                        .wire_len(chunk_len)
                        .ok_or_else(|| {
                            io::Error::new(io::ErrorKind::InvalidInput, "base64 length overflow")
                        })?;
                encoded_file_scratch.resize(encoded_len, 0);
                let written = Base64Engine
                    .encode_slice(
                        &file_scratch[..chunk_len],
                        &mut encoded_file_scratch[..encoded_len],
                    )
                    .map_err(|err| io::Error::new(io::ErrorKind::InvalidData, err.to_string()))?;
                if let Some(mask) = mask.as_ref() {
                    xor_websocket_mask(&mut encoded_file_scratch[..written], mask, payload_offset);
                }
                writer.write_all(&encoded_file_scratch[..written]).await?;
                payload_offset += written;
            }
        }
        file_offset = file_offset
            .checked_add(chunk_len as u64)
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "file offset overflow"))?;
        remaining -= chunk_len;
    }
    record_buffered_file_segment(file_segment.len);

    for segment in suffix_segments {
        write_websocket_payload(
            writer,
            segment,
            mask.as_ref(),
            &mut payload_offset,
            mask_scratch,
        )
        .await?;
    }
    if payload_offset != payload_len {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "file-backed websocket payload length changed while writing",
        ));
    }
    Ok(())
}

async fn handle_websocket_message(
    serializer: rawsocket::Serializer,
    data: CompletedWebSocketMessage,
    buffer_pool: &Arc<WebSocketBufferPool>,
    frame_tx: &mpsc::Sender<wamp::ParsedMessage>,
) -> Result<(), String> {
    let parsed = match data {
        CompletedWebSocketMessage::Single(data) => {
            let payload = match serializer {
                rawsocket::Serializer::Json => {
                    if std::str::from_utf8(data.as_ref()).is_err() {
                        return Err("websocket text frame payload is not valid UTF-8".into());
                    }
                    data
                }
                _ => data,
            };
            wamp::parse_message(serializer, payload)
        }
        CompletedWebSocketMessage::Segmented { segments, len } => match serializer {
            rawsocket::Serializer::Json => {
                let payload =
                    CompletedWebSocketMessage::Segmented { segments, len }.into_bytes(buffer_pool);
                if std::str::from_utf8(payload.as_ref()).is_err() {
                    return Err("websocket text frame payload is not valid UTF-8".into());
                }
                wamp::parse_message(serializer, payload)
            }
            _ => wamp::parse_message_segments(serializer, segments),
        },
    };
    match parsed {
        Ok(parsed) => frame_tx
            .send(parsed)
            .await
            .map_err(|_| "failed to enqueue websocket message".into()),
        Err(err) => Err(format!("failed to parse WAMP message: {:?}", err)),
    }
}

struct EncodedFrameHeader {
    bytes: [u8; 5],
    len: usize,
}

impl EncodedFrameHeader {
    fn as_bytes(&self) -> &[u8] {
        &self.bytes[..self.len]
    }
}

fn encode_frame_header(
    frame_type: u8,
    payload_len: usize,
    upgraded_protocol: bool,
) -> Result<EncodedFrameHeader, FrameReadError> {
    if frame_type > 0x07 {
        return Err(FrameReadError::Protocol(format!(
            "invalid frame type {}",
            frame_type
        )));
    }
    if upgraded_protocol {
        let length = u32::try_from(payload_len).map_err(|_| {
            FrameReadError::Protocol(format!(
                "payload length {} exceeds supported maximum {}",
                payload_len,
                u32::MAX
            ))
        })?;
        let mut header = [0u8; 5];
        header[0] = frame_type & 0x07;
        header[1..5].copy_from_slice(&length.to_be_bytes());
        return Ok(EncodedFrameHeader {
            bytes: header,
            len: 5,
        });
    }
    if payload_len > MAX_FRAME_LEN as usize {
        return Err(FrameReadError::Protocol(format!(
            "payload length {} exceeds supported maximum {}",
            payload_len, MAX_FRAME_LEN as usize
        )));
    }

    let mut header = [0u8; 5];
    let mut first = frame_type & 0x07;
    if payload_len == (MAX_FRAME_LEN as usize) {
        first |= 0x08;
    } else {
        header[1] = ((payload_len >> 16) & 0xFF) as u8;
        header[2] = ((payload_len >> 8) & 0xFF) as u8;
        header[3] = (payload_len & 0xFF) as u8;
    }
    header[0] = first;
    Ok(EncodedFrameHeader {
        bytes: header,
        len: 4,
    })
}

/// Initialises the multi-threaded tokio runtime if it has not been started yet.
pub fn start_runtime() -> Result<(), Error> {
    let manager = RuntimeManager::global();
    let mut guard = manager
        .state
        .lock()
        .unwrap_or_else(|poison| poison.into_inner());
    if guard.is_some() {
        return Err(Error::RuntimeAlreadyStarted);
    }

    // Ensure the platform allows native runtime creation.
    PlatformRuntime::new().map_err(|_| Error::UnsupportedPlatform)?;

    let worker_threads = runtime_worker_threads_from_env()?;
    let mut builder = tokio::runtime::Builder::new_multi_thread();
    builder.thread_name("connectanum-rt").enable_all();
    if let Some(worker_threads) = worker_threads {
        builder.worker_threads(worker_threads);
    }
    let runtime = builder.build()?;

    let mqtt_runtime = build_mqtt_runtime(
        worker_threads,
        std::env::var_os("TOKIO_WORKER_THREADS").is_some(),
    );
    let state = RuntimeState::from_runtime_parts(runtime, mqtt_runtime)?;
    *guard = Some(state);
    Ok(())
}

fn build_mqtt_runtime(
    native_workers: Option<usize>,
    tokio_override_present: bool,
) -> Result<Option<Runtime>, Error> {
    if native_workers.is_some() || tokio_override_present {
        return Ok(None);
    }
    Ok(Some(
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(1)
            .thread_name("connectanum-mqtt")
            .enable_all()
            .build()?,
    ))
}

fn runtime_worker_threads_from_env() -> Result<Option<usize>, Error> {
    parse_runtime_worker_threads(std::env::var(NATIVE_RUNTIME_THREADS_ENV).ok().as_deref())
}

fn parse_runtime_worker_threads(raw: Option<&str>) -> Result<Option<usize>, Error> {
    let Some(raw) = raw.map(str::trim).filter(|value| !value.is_empty()) else {
        return Ok(None);
    };
    let parsed = raw
        .parse::<usize>()
        .map_err(|_| Error::InvalidRuntimeThreadCount(raw.to_string()))?;
    if parsed == 0 {
        return Err(Error::InvalidRuntimeThreadCount(raw.to_string()));
    }
    Ok(Some(parsed))
}

/// Applies the router configuration JSON produced on the Dart side.
pub fn apply_router_config(bytes: &[u8]) -> Result<(), Error> {
    config::apply_router_config_bytes(bytes)
}

/// Rebuilds TLS configuration for legacy listeners using the process-wide default.
/// Router-scoped listeners are unaffected; use `reload_router_tls` for those.
pub fn reload_tls() -> Result<u32, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.reload_tls())
}

/// Reloads only the supplied router-scoped listeners, without changing defaults.
pub fn reload_router_tls(config: &[u8], listener_ids: &[ListenerId]) -> Result<u32, Error> {
    let config = config::parse_router_config_bytes(config)?;
    RuntimeManager::global().with_state(|state| {
        state
            .registry
            .reload_tls_selected(Some(listener_ids), Some(&config))
    })
}

/// Gracefully shuts down the runtime and aborts all listener tasks.
pub fn shutdown() -> Result<(), Error> {
    let manager = RuntimeManager::global();
    let mut guard = manager
        .state
        .lock()
        .unwrap_or_else(|poison| poison.into_inner());
    if let Some(state) = guard.take() {
        state.shutdown();
    }
    Ok(())
}

async fn negotiate_accepted_connection(
    stream: tokio::net::TcpStream,
    addr: SocketAddr,
    listener_id: ListenerId,
    config_state: Arc<ListenerConfigState>,
    registry: Arc<ListenerRegistry>,
    runtime_handle: tokio::runtime::Handle,
    tx: mpsc::Sender<ConnectionId>,
) {
    let _ = stream.set_nodelay(true);
    let endpoint = config_state.endpoint_config();
    let tls_acceptor = config_state.tls_acceptor();
    let io_stream = match tls_acceptor.as_ref() {
        Some(acceptor) => {
            let ktls_requested = ktls::server_runtime_requested(endpoint.as_ref());
            let ktls_required = ktls::server_runtime_required(endpoint.as_ref());
            if ktls_requested {
                match time::timeout(
                    endpoint.handshake_timeout,
                    ktls::accept_server_stream(acceptor.config().clone(), stream),
                )
                .await
                {
                    Ok(Ok(io_stream)) => io_stream,
                    Ok(Err(err)) => {
                        eprintln!(
                            "{} kTLS handoff failed for connection from {}: {}",
                            if ktls_required {
                                "required"
                            } else {
                                "optional"
                            },
                            addr,
                            err
                        );
                        return;
                    }
                    Err(_) => {
                        eprintln!(
                            "{} kTLS handshake timed out for connection from {}",
                            if ktls_required {
                                "required"
                            } else {
                                "optional"
                            },
                            addr
                        );
                        return;
                    }
                }
            } else {
                let handshake = acceptor.accept(stream);
                match time::timeout(endpoint.handshake_timeout, handshake).await {
                    Ok(Ok(tls_stream)) => IoStream::tls(tls_stream),
                    Ok(Err(err)) => {
                        eprintln!("tls handshake failed for connection from {}: {}", addr, err);
                        return;
                    }
                    Err(_) => {
                        eprintln!("tls handshake timed out for connection from {}", addr);
                        return;
                    }
                }
            }
        }
        None => IoStream::plain(stream),
    };

    match protocol::negotiate_connection(io_stream, endpoint.as_ref()).await {
        Ok(protocol::NegotiatedConnection::RawSocket(negotiated)) => {
            let Ok(connection_id) = registry.next_connection_id() else {
                return;
            };
            Arc::clone(&registry).register_rawsocket_connection(
                runtime_handle.clone(),
                listener_id,
                connection_id,
                Arc::clone(&endpoint),
                negotiated,
                addr,
            );
            let _ = tx.send(connection_id).await;
        }
        Ok(protocol::NegotiatedConnection::Mqtt(handshake)) => {
            let next_id = registry.next_connection_id();
            with_mqtt_connection_id(next_id, |connection_id| async move {
                if Arc::clone(&registry)
                    .register_mqtt_connection(
                        runtime_handle.clone(),
                        listener_id,
                        connection_id,
                        Arc::clone(&endpoint),
                        handshake,
                        addr,
                    )
                    .is_ok()
                {
                    let _ = tx.send(connection_id).await;
                }
            })
            .await;
        }
        Ok(protocol::NegotiatedConnection::WebSocket(handshake)) => {
            let Ok(connection_id) = registry.next_connection_id() else {
                return;
            };
            if endpoint.supports_protocol(TransportProtocol::Mqtt)
                && handshake
                    .sec_websocket_protocols
                    .iter()
                    .any(|protocol| protocol == "mqtt")
            {
                if let Err(error) = Arc::clone(&registry)
                    .register_mqtt_websocket_connection(
                        runtime_handle.clone(),
                        listener_id,
                        connection_id,
                        Arc::clone(&endpoint),
                        handshake,
                        addr,
                    )
                    .await
                {
                    eprintln!("MQTT WebSocket upgrade failed: {error}");
                    return;
                }
            } else {
                registry.register_websocket_connection(
                    listener_id,
                    connection_id,
                    Arc::clone(&endpoint),
                    handshake,
                    addr,
                );
            }
            let _ = tx.send(connection_id).await;
        }
        Ok(protocol::NegotiatedConnection::Http2(handshake)) => {
            let (stream, metadata) = handshake.split();
            let Ok(connection_id) = registry.next_connection_id() else {
                return;
            };
            registry.register_http2_connection(
                listener_id,
                connection_id,
                Arc::clone(&endpoint),
                metadata,
                addr,
            );
            let registry_for_connection = Arc::clone(&registry);
            let endpoint_for_connection = Arc::clone(&endpoint);
            runtime_handle.spawn(async move {
                serve_http2_connection(
                    listener_id,
                    connection_id,
                    stream,
                    endpoint_for_connection,
                    registry_for_connection,
                )
                .await;
            });
            let _ = tx.send(connection_id).await;
        }
        Ok(protocol::NegotiatedConnection::Http3(handshake)) => {
            let Ok(connection_id) = registry.next_connection_id() else {
                return;
            };
            registry.register_http3_connection(
                listener_id,
                connection_id,
                Arc::clone(&endpoint),
                handshake,
                None,
                addr,
            );
            let _ = tx.send(connection_id).await;
        }
        Ok(protocol::NegotiatedConnection::Http(handshake)) => {
            let Ok(connection_id) = registry.next_connection_id() else {
                return;
            };
            registry.register_http_connection(
                listener_id,
                connection_id,
                Arc::clone(&endpoint),
                addr,
            );
            let registry_for_connection = Arc::clone(&registry);
            let endpoint_for_connection = Arc::clone(&endpoint);
            runtime_handle.spawn(async move {
                serve_http_connection(
                    listener_id,
                    connection_id,
                    handshake,
                    endpoint_for_connection,
                    registry_for_connection,
                )
                .await;
            });
            let _ = tx.send(connection_id).await;
        }
        Err(protocol::NegotiationError::Timeout) => {
            eprintln!(
                "protocol negotiation timed out for connection from {}",
                addr
            );
        }
        Err(protocol::NegotiationError::Protocol(msg)) => {
            eprintln!(
                "protocol negotiation failed for connection from {}: {}",
                addr, msg
            );
        }
        Err(protocol::NegotiationError::Io(err)) => {
            eprintln!(
                "protocol negotiation IO error for connection from {}: {}",
                addr, err
            );
        }
    }
}

/// Starts listening on the provided address and returns the allocated listener id.
pub fn listen(addr: &str, port: u16, backlog: i32) -> Result<ListenerId, Error> {
    listen_endpoint(addr, port, backlog, None, None)
}

/// Opens a particular configured endpoint, including distinct port-zero listeners.
pub fn listen_configured_endpoint(
    addr: &str,
    port: u16,
    backlog: i32,
    endpoint_index: usize,
) -> Result<ListenerId, Error> {
    listen_endpoint(addr, port, backlog, Some(endpoint_index), None)
}

/// Opens an endpoint from an explicit router configuration snapshot.
pub fn listen_router_endpoint(
    config: &[u8],
    endpoint_index: usize,
    backlog: i32,
) -> Result<ListenerId, Error> {
    let config = config::parse_router_config_bytes(config)?;
    let endpoint = config
        .endpoints
        .get(endpoint_index)
        .ok_or_else(|| Error::RouterConfigInvalid("endpoint index out of range".into()))?;
    listen_endpoint(
        &endpoint.host,
        endpoint.port,
        backlog,
        Some(endpoint_index),
        Some(Arc::new(endpoint.clone())),
    )
}

fn listen_endpoint(
    addr: &str,
    port: u16,
    backlog: i32,
    endpoint_index: Option<usize>,
    explicit_config: Option<Arc<config::EndpointConfig>>,
) -> Result<ListenerId, Error> {
    if backlog <= 0 {
        return Err(Error::InvalidBacklog);
    }
    let manager = RuntimeManager::global();
    manager
        .with_state(|view| {
            let socket_addr = resolve_socket_addr(addr, port)?;
            let router_scoped = explicit_config.is_some();
            let endpoint_config = explicit_config
                .or_else(|| match endpoint_index {
                    Some(index) => config::find_endpoint_at(index, addr, port),
                    None => config::find_endpoint(addr, port),
                })
                .ok_or_else(|| Error::EndpointNotConfigured(addr.to_string(), port))?;
            let runtime_config = Arc::new(config::EndpointRuntimeConfig::try_from_endpoint(
                &endpoint_config,
            )?);
            let tls_acceptor = tls::build_tls_acceptor(&runtime_config)?;
            let config_state = Arc::new(ListenerConfigState::new(
                Arc::clone(&runtime_config),
                tls_acceptor,
            ));
            let std_listener = create_listener(socket_addr, backlog as u32)?;
            let local_addr = std_listener.local_addr()?;

            let (sender, receiver) = mpsc::channel(1024);
            let listener_id = view.registry.next_listener_id();
            let accept_registry = Arc::clone(&view.registry);
            let async_sender = sender.clone();
            let config_state_for_task = Arc::clone(&config_state);
            let runtime_handle = view.handle.clone();
            let task = runtime_handle.clone().spawn(async move {
                let listener = tokio::net::TcpListener::from_std(std_listener)
                    .expect("failed to convert listener to tokio");
                let tx = async_sender;
                let mut negotiation_tasks = JoinSet::new();
                loop {
                    if tx.is_closed() {
                        break;
                    }
                    while negotiation_tasks.try_join_next().is_some() {}
                    if negotiation_tasks.len() >= backlog as usize {
                        let _ = negotiation_tasks.join_next().await;
                        continue;
                    }
                    match listener.accept().await {
                        Ok((stream, addr)) => {
                            let accept_registry = Arc::clone(&accept_registry);
                            let config_state_for_task = Arc::clone(&config_state_for_task);
                            let runtime_handle = runtime_handle.clone();
                            let tx = tx.clone();
                            negotiation_tasks.spawn(negotiate_accepted_connection(
                                stream,
                                addr,
                                listener_id,
                                config_state_for_task,
                                accept_registry,
                                runtime_handle,
                                tx,
                            ));
                        }
                        Err(_) => break,
                    }
                }
            });

            let mut listener_tasks = vec![task];
            let mut http3_addr = None;
            let mut http3_endpoint = None;
            if runtime_config.supports_protocol(TransportProtocol::Http3) {
                let mut desired_addr = local_addr;
                if let Some(http_settings) = runtime_config.http_settings() {
                    if let Some(http3_settings) = &http_settings.http3 {
                        if let Some(port) = http3_settings.port {
                            desired_addr.set_port(port);
                        }
                    }
                }
                match start_http3_listener(
                    listener_id,
                    desired_addr,
                    Arc::clone(&config_state),
                    Arc::clone(&view.registry),
                    sender.clone(),
                    view.handle.clone(),
                    backlog as usize,
                ) {
                    Ok((endpoint, task, bound_addr)) => {
                        http3_addr = Some(bound_addr);
                        http3_endpoint = Some(endpoint);
                        listener_tasks.push(task);
                    }
                    Err(err) => {
                        eprintln!(
                            "failed to start http3 listener on {}: {}",
                            desired_addr, err
                        );
                    }
                }
            }

            let entry = ListenerEntry {
                router_scoped,
                configured_endpoint_index: endpoint_index,
                addr: local_addr,
                receiver: Mutex::new(Some(receiver)),
                _sender: sender,
                tasks: listener_tasks,
                http3_addr,
                http3_endpoint,
                config_state,
            };
            view.registry.insert(listener_id, entry);

            Ok(listener_id)
        })
        .map_err(|err| match err {
            Error::RuntimeNotStarted => err,
            other => other,
        })
}

/// Returns the bound socket address for the given listener.
pub fn local_addr(listener_id: ListenerId) -> Result<SocketAddr, Error> {
    let manager = RuntimeManager::global();
    manager
        .with_state(|state| state.registry.local_addr(listener_id))
        .map_err(|err| match err {
            Error::RuntimeNotStarted => err,
            other => other,
        })
}

/// Returns the bound HTTP/3 port for the given listener, if available.
pub fn listener_http3_port(listener_id: ListenerId) -> Result<Option<u16>, Error> {
    let manager = RuntimeManager::global();
    manager
        .with_state(|state| state.registry.http3_addr(listener_id))
        .map(|addr| addr.map(|socket| socket.port()))
        .map_err(|err| match err {
            Error::RuntimeNotStarted => err,
            other => other,
        })
}

/// Stops accepting new connections on the provided listener and releases any
/// listener-specific accept tasks. Existing connections remain active.
pub fn close_listener(listener_id: ListenerId) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager
        .with_state(|state| state.registry.close_listener(listener_id))
        .map_err(|err| match err {
            Error::RuntimeNotStarted => err,
            other => other,
        })
}

/// Returns the channel that streams accepted connection identifiers.
pub fn accept_channel(listener_id: ListenerId) -> Result<mpsc::Receiver<ConnectionId>, Error> {
    let manager = RuntimeManager::global();
    manager
        .with_state(|state| state.registry.take_receiver(listener_id))
        .map_err(|err| match err {
            Error::RuntimeNotStarted => err,
            other => other,
        })
}

/// Returns the runtime-ready endpoint configuration associated with a connection.
pub fn connection_runtime_config(
    connection_id: ConnectionId,
) -> Result<Arc<config::EndpointRuntimeConfig>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.connection_config(connection_id))
}

/// Convenience helper exposing the RawSocket max message size exponent for a connection.
pub fn connection_rawsocket_max_exponent(connection_id: ConnectionId) -> Result<u32, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.connection_exponent(connection_id))
}

/// Reports whether a connection can enqueue file-backed frames.
pub fn connection_supports_file_segments(connection_id: ConnectionId) -> Result<bool, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        state
            .registry
            .connection_supports_file_segments(connection_id)
    })
}

/// Returns the negotiated transport protocol for a connection.
pub fn connection_protocol(connection_id: ConnectionId) -> Result<ConnectionProtocol, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.connection_protocol(connection_id))
}

/// MQTT protocol level selected from the accepted CONNECT preamble.
pub fn connection_mqtt_version(connection_id: ConnectionId) -> Result<u8, Error> {
    RuntimeManager::global().with_state(|state| state.registry.mqtt_version(connection_id))
}

/// Registers a native-thread callback for MQTT read-queue wakeups. Clearing or
/// closing a connection waits for any in-flight callback before returning.
pub fn set_mqtt_wakeup(
    connection_id: ConnectionId,
    callback: Option<extern "C" fn(i32)>,
) -> Result<(), Error> {
    RuntimeManager::global()
        .with_state(|state| state.registry.set_mqtt_wakeup(connection_id, callback))
}

/// Retrieves a bounded raw MQTT byte chunk without WAMP packet conversion.
pub fn poll_mqtt_chunk(
    connection_id: ConnectionId,
    max_bytes: usize,
) -> Result<Option<Bytes>, Error> {
    RuntimeManager::global()
        .with_state(|state| state.registry.poll_mqtt_chunk(connection_id, max_bytes))
}

/// Enqueues encoded MQTT bytes for the native TCP/TLS writer.
pub fn send_mqtt_chunk(connection_id: ConnectionId, bytes: Bytes) -> Result<(), Error> {
    RuntimeManager::global()
        .with_state(|state| state.registry.enqueue_mqtt_chunk(connection_id, bytes))
}

/// The serializer actually selected by an established WAMP connection.
pub fn connection_serializer(connection_id: ConnectionId) -> Result<rawsocket::Serializer, Error> {
    RuntimeManager::global().with_state(|state| state.registry.connection_serializer(connection_id))
}

/// Returns the negotiated WebSocket subprotocol for a connection, if available.
pub fn connection_websocket_protocol(connection_id: ConnectionId) -> Result<Option<String>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.connection_websocket_protocol(connection_id))
}

/// Retrieves and consumes a pending WebSocket handshake for a connection.
pub fn connection_take_websocket_handshake(
    connection_id: ConnectionId,
) -> Result<protocol::WebSocketHandshake, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.take_websocket_handshake(connection_id))
}

pub fn connection_accept_websocket(
    connection_id: ConnectionId,
    handshake: protocol::WebSocketHandshake,
    serializer: rawsocket::Serializer,
    protocol: Option<&str>,
) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        Arc::clone(&state.registry).accept_websocket_connection(
            state.handle.clone(),
            connection_id,
            handshake,
            serializer,
            protocol,
        )
    })
}

pub fn connection_reject_websocket(
    connection_id: ConnectionId,
    handshake: protocol::WebSocketHandshake,
    status: StatusCode,
    reason: Option<&str>,
) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        state.registry.reject_websocket_connection(
            state.handle.clone(),
            connection_id,
            handshake,
            status,
            reason,
        )
    })
}

/// Retrieves and consumes a pending HTTP/2 handshake for a connection.
pub fn connection_take_http2_handshake(
    connection_id: ConnectionId,
) -> Result<protocol::Http2Handshake, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.take_http2_handshake(connection_id))
}

/// Retrieves and consumes a pending HTTP/3 handshake for a connection.
pub fn connection_take_http3_handshake(
    connection_id: ConnectionId,
) -> Result<protocol::Http3Handshake, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.take_http3_handshake(connection_id))
}

/// Registers a pending HTTP/3 handshake for testing and diagnostics.
pub fn register_http3_pending(
    listener_id: ListenerId,
    connection_id: ConnectionId,
    handshake: protocol::Http3Handshake,
    peer_addr: SocketAddr,
) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let endpoint_config = state.registry.listener_config(listener_id)?;
        state.registry.register_http3_connection(
            listener_id,
            connection_id,
            endpoint_config,
            handshake,
            None,
            peer_addr,
        );
        Ok(())
    })
}

/// Provides a shared handle to the HTTP/3 connection for a given connection id.
pub fn connection_http3_connection(
    connection_id: ConnectionId,
) -> Result<Arc<QuinnConnection>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.http3_connection(connection_id))
}

/// Attempts to retrieve the next pending HTTP/3 bidirectional stream.
pub fn connection_http3_poll_stream(
    connection_id: ConnectionId,
) -> Result<Option<Http3BidiStream>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.poll_http3_stream(connection_id))
}

/// Attempts to retrieve the next pending HTTP request metadata.
pub fn connection_http_poll_request(
    connection_id: ConnectionId,
) -> Result<Option<(HttpRequestSummary, HttpResponseHandle)>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.poll_http_request(connection_id))
}

/// Attempts to retrieve the next pending HTTP/3 request metadata.
pub fn connection_http3_poll_request(
    connection_id: ConnectionId,
) -> Result<Option<(HttpRequestSummary, HttpResponseHandle)>, Error> {
    connection_http_poll_request(connection_id)
}

/// Attempts to retrieve connection lifecycle events for HTTP/2 and HTTP/3.
pub fn connection_poll_http_event() -> Option<HttpConnectionEvent> {
    let manager = RuntimeManager::global();
    manager
        .with_state(|state| Ok(state.registry.poll_http_connection_event()))
        .ok()
        .flatten()
}

#[cfg(feature = "ffi-test")]
pub fn register_http_request(
    connection_id: ConnectionId,
    request: HttpRequestSummary,
) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let (tx, rx) = oneshot::channel::<HttpResponseDispatch>();
        let handle = state.handle.clone();
        handle.spawn(async move {
            let _ = rx.await;
        });
        let queued = QueuedHttpRequest {
            summary: request,
            response: HttpResponseHandle::new(connection_id, tx),
        };
        state.registry.enqueue_http_request(connection_id, queued)
    })
}

#[cfg(feature = "ffi-test")]
pub fn push_http_connection_event(listener_id: ListenerId, event: HttpConnectionEvent) {
    let manager = RuntimeManager::global();
    let _ = manager.with_state(|state| {
        state.registry.push_connection_event(listener_id, event);
        Ok(())
    });
}

/// Attempts to retrieve the next parsed WAMP message for a connection.
pub fn poll_connection_message(
    connection_id: ConnectionId,
) -> Result<Option<wamp::ParsedMessage>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.poll_message(connection_id))
}

/// Waits for the next parsed WAMP message for a connection.
pub fn wait_connection_message(
    connection_id: ConnectionId,
    timeout: Option<Duration>,
) -> Result<Option<wamp::ParsedMessage>, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let frames = state.registry.message_frames(connection_id)?;
        let mut receiver = frames.lock().unwrap();
        let receive = receiver.recv();
        let message = match timeout {
            Some(deadline) => runtime_block_on(&state.handle, async move {
                match time::timeout(deadline, receive).await {
                    Ok(result) => result,
                    Err(_) => None,
                }
            }),
            None => runtime_block_on(&state.handle, receive),
        };
        Ok(message)
    })
}

/// Closes a connection and releases its native consumers.
///
/// RawSocket cancels pending writes immediately. WebSocket lets its writer drain
/// and send Close(1000), then cancels it after one second if the peer is stalled.
/// Await tracked write receipts or a drain barrier before close when successful
/// local delivery is required. Independent caller-owned views remain valid.
/// On glibc Linux, an empty registry also schedules bounded idle allocator cleanup.
pub fn close_connection(connection_id: ConnectionId) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let result = state.registry.close_connection(connection_id);
        #[cfg(all(target_os = "linux", target_env = "gnu"))]
        state
            .registry
            .schedule_idle_allocator_release(&state.handle, idle_allocator::release_unused_pages);
        result
    })
}

/// Opens an outbound RawSocket client connection and registers it in the runtime.
pub fn connect_rawsocket(
    host: &str,
    port: u16,
    use_tls: bool,
    allow_insecure: bool,
    serializer: rawsocket::Serializer,
    desired_exponent: u32,
    heartbeat_interval: Option<Duration>,
    heartbeat_timeout: Option<Duration>,
) -> Result<ConnectionId, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let connection_id = state.registry.next_connection_id()?;
        let endpoint_config = Arc::new(build_client_endpoint_config(
            host,
            port,
            use_tls,
            TransportProtocol::Rawsocket,
            desired_exponent,
            heartbeat_interval,
            heartbeat_timeout,
        ));
        let (stream, peer_addr) = runtime_block_on(
            &state.handle,
            connect_io_stream(host, port, use_tls, allow_insecure, &[]),
        )?;
        let negotiated = runtime_block_on(
            &state.handle,
            rawsocket::connect(
                stream,
                serializer,
                endpoint_config.max_rawsocket_size_exponent,
                endpoint_config.handshake_timeout,
            ),
        )
        .map_err(handshake_error_to_io)?;
        Arc::clone(&state.registry).register_rawsocket_connection(
            state.handle.clone(),
            ListenerId(0),
            connection_id,
            endpoint_config,
            negotiated,
            peer_addr,
        );
        Ok(connection_id)
    })
}

/// Opens an outbound WebSocket client connection and registers it in the runtime.
pub fn connect_websocket(
    host: &str,
    port: u16,
    target: &str,
    use_tls: bool,
    allow_insecure: bool,
    serializer: rawsocket::Serializer,
    headers: &[(String, String)],
    heartbeat_interval: Option<Duration>,
    heartbeat_timeout: Option<Duration>,
) -> Result<ConnectionId, Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        let subprotocol = websocket_subprotocol(serializer)?;
        let connection_id = state.registry.next_connection_id()?;
        let endpoint_config = Arc::new(build_client_endpoint_config(
            host,
            port,
            use_tls,
            TransportProtocol::Websocket,
            config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            heartbeat_interval,
            heartbeat_timeout,
        ));
        let alpn_protocols = if use_tls {
            vec![b"http/1.1".to_vec()]
        } else {
            Vec::new()
        };
        let (mut stream, peer_addr) = runtime_block_on(
            &state.handle,
            connect_io_stream(host, port, use_tls, allow_insecure, &alpn_protocols),
        )?;
        runtime_block_on(
            &state.handle,
            perform_websocket_client_handshake(
                &mut stream,
                host,
                port,
                use_tls,
                target,
                subprotocol,
                headers,
                endpoint_config.handshake_timeout,
            ),
        )?;
        let _ = stream.set_nodelay(true);
        let (reader, writer) = tokio::io::split(stream);
        Arc::clone(&state.registry).register_established_websocket_connection(
            state.handle.clone(),
            ListenerId(0),
            connection_id,
            endpoint_config,
            peer_addr,
            serializer,
            Some(subprotocol.to_string()),
            reader,
            writer,
            false,
            true,
        )?;
        Ok(connection_id)
    })
}

/// Enqueues a WAMP message to be sent to the connection.
pub fn send_wamp_message(connection_id: ConnectionId, payload: Bytes) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        state
            .registry
            .enqueue_frame(connection_id, OutboundFrame::message(payload))
    })
}

/// Enqueues a frame and observes local full-frame write plus flush.
/// Queue rejection is an error; completion never implies peer acknowledgement
/// or the release of other retained payload references.
pub fn send_wamp_message_tracked(
    connection_id: ConnectionId,
    payload: Bytes,
) -> Result<WriteReceipt, Error> {
    let (frame, receipt) = OutboundFrame::message(payload).tracked();
    RuntimeManager::global()
        .with_state(|state| state.registry.enqueue_frame(connection_id, frame))?;
    Ok(receipt)
}

/// Observe full-frame write and flush without concatenating payload segments.
pub fn send_wamp_segments_tracked(
    connection_id: ConnectionId,
    segments: Vec<Bytes>,
) -> Result<WriteReceipt, Error> {
    let (frame, receipt) = OutboundFrame::message_segments(segments).tracked();
    RuntimeManager::global()
        .with_state(|state| state.registry.enqueue_frame(connection_id, frame))?;
    Ok(receipt)
}

/// A FIFO local flush barrier, without emitting an additional protocol frame.
/// Shutdown or a failed earlier write abandons this receipt.
pub fn drain_wamp_writes(connection_id: ConnectionId) -> Result<WriteReceipt, Error> {
    let (frame, receipt) = OutboundFrame::barrier().tracked();
    RuntimeManager::global()
        .with_state(|state| state.registry.enqueue_frame(connection_id, frame))?;
    Ok(receipt)
}

/// Sends an HTTP response to the client. Currently unsupported.
pub fn send_http_response(
    connection_id: ConnectionId,
    status: i32,
    headers: &[(String, String)],
    body: &[u8],
) -> Result<(), Error> {
    let _ = (status, headers, body);
    Err(Error::UnsupportedProtocol(
        connection_id,
        ConnectionProtocol::Http,
    ))
}

/// Enqueues a WAMP message composed of multiple payload segments.
pub fn send_wamp_segments(connection_id: ConnectionId, segments: Vec<Bytes>) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    manager.with_state(|state| {
        state
            .registry
            .enqueue_frame(connection_id, OutboundFrame::message_segments(segments))
    })
}

/// Enqueues a WAMP message whose final segment is prepared off the async runtime.
pub fn send_wamp_deferred_segment<F>(
    connection_id: ConnectionId,
    prefix: Bytes,
    deferred_len: usize,
    prepare: F,
) -> Result<(), Error>
where
    F: FnOnce() -> Result<Bytes, String> + Send + 'static,
{
    let frame = OutboundFrame::message_deferred_segment(prefix, deferred_len, prepare)?;
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.enqueue_frame(connection_id, frame))
}

/// Enqueues a WAMP message whose middle segment is prepared off the async runtime.
pub fn send_wamp_deferred_segment_with_suffix<F>(
    connection_id: ConnectionId,
    prefix: Bytes,
    deferred_len: usize,
    suffix: Bytes,
    prepare: F,
) -> Result<(), Error>
where
    F: FnOnce() -> Result<Bytes, String> + Send + 'static,
{
    let frame =
        OutboundFrame::message_deferred_segment_with_suffix(prefix, deferred_len, suffix, prepare)?;
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.enqueue_frame(connection_id, frame))
}

/// Enqueues one WAMP frame containing a file-backed payload segment.
pub fn send_wamp_file_segment(
    connection_id: ConnectionId,
    prefix: Bytes,
    file: Arc<File>,
    offset: u64,
    len: usize,
    suffix: Bytes,
) -> Result<(), Error> {
    let end = offset
        .checked_add(len as u64)
        .ok_or(Error::InvalidFileSegment("file range overflow"))?;
    if end > file.metadata()?.len() {
        return Err(Error::InvalidFileSegment(
            "file range exceeds the current file length",
        ));
    }
    let frame = OutboundFrame::message_file_segment(
        prefix,
        file,
        offset,
        len,
        suffix,
        FileSegmentEncoding::Identity,
    )?;
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.enqueue_file_frame(connection_id, frame))
}

/// Enqueues a WAMP message with a file-backed segment encoded as RFC 4648 base64.
pub fn send_wamp_base64_file_segment(
    connection_id: ConnectionId,
    prefix: Bytes,
    file: Arc<File>,
    offset: u64,
    len: usize,
    suffix: Bytes,
) -> Result<(), Error> {
    let end = offset
        .checked_add(len as u64)
        .ok_or(Error::InvalidFileSegment("file range overflow"))?;
    if end > file.metadata()?.len() {
        return Err(Error::InvalidFileSegment(
            "file range exceeds the current file length",
        ));
    }
    let frame = OutboundFrame::message_file_segment(
        prefix,
        file,
        offset,
        len,
        suffix,
        FileSegmentEncoding::Base64,
    )?;
    let manager = RuntimeManager::global();
    manager.with_state(|state| state.registry.enqueue_file_frame(connection_id, frame))
}

pub fn spawn_http_response(
    handshake: protocol::HttpHandshake,
    status: i32,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
) -> Result<(), Error> {
    let manager = RuntimeManager::global();
    let version = handshake.version();
    manager.with_state(|state| {
        let handle = state.handle.clone();
        handle.spawn(async move {
            let stream = handshake.into_stream();
            if let Err(err) =
                protocol::write_http_response(stream, version, status, headers, body).await
            {
                if should_log_http_response_send_error(err.kind()) {
                    eprintln!("failed to send http response: {}", err);
                }
            }
        });
        Ok(())
    })
}

#[derive(Clone, Copy)]
enum HttpTransportAuthFailure {
    BearerRequired,
    TlsRequired,
    MutualTlsRequired,
}

fn evaluate_http_transport_auth_string_headers(
    requirements: &config::HttpRouteTransportAuthRuntime,
    endpoint_config: &config::EndpointRuntimeConfig,
    method: &str,
    headers: &[(String, String)],
) -> Option<HttpTransportAuthFailure> {
    if requirements.require_mtls
        && endpoint_config
            .client_auth
            .as_ref()
            .map(|client_auth| client_auth.mode == config::ClientAuthMode::Required)
            != Some(true)
    {
        return Some(HttpTransportAuthFailure::MutualTlsRequired);
    }
    if requirements.require_tls && endpoint_config.tls_mode == config::TlsMode::Disabled {
        return Some(HttpTransportAuthFailure::TlsRequired);
    }
    let bearerless_preflight = requirements.allow_unauthenticated_cors_preflight
        && is_cors_preflight_string(method, headers);
    if requirements.require_bearer && !bearerless_preflight && !has_bearer_header_string(headers) {
        return Some(HttpTransportAuthFailure::BearerRequired);
    }
    None
}

fn evaluate_http_transport_auth_bytes_headers(
    requirements: &config::HttpRouteTransportAuthRuntime,
    endpoint_config: &config::EndpointRuntimeConfig,
    method: &str,
    headers: &[(Arc<[u8]>, Arc<[u8]>)],
) -> Option<HttpTransportAuthFailure> {
    if requirements.require_mtls
        && endpoint_config
            .client_auth
            .as_ref()
            .map(|client_auth| client_auth.mode == config::ClientAuthMode::Required)
            != Some(true)
    {
        return Some(HttpTransportAuthFailure::MutualTlsRequired);
    }
    if requirements.require_tls && endpoint_config.tls_mode == config::TlsMode::Disabled {
        return Some(HttpTransportAuthFailure::TlsRequired);
    }
    let bearerless_preflight = requirements.allow_unauthenticated_cors_preflight
        && is_cors_preflight_bytes(method, headers);
    if requirements.require_bearer && !bearerless_preflight && !has_bearer_header_bytes(headers) {
        return Some(HttpTransportAuthFailure::BearerRequired);
    }
    None
}

fn is_cors_preflight_string(method: &str, headers: &[(String, String)]) -> bool {
    method.eq_ignore_ascii_case("OPTIONS")
        && has_non_empty_header_string(headers, "origin")
        && has_non_empty_header_string(headers, "access-control-request-method")
}

fn is_cors_preflight_bytes(method: &str, headers: &[(Arc<[u8]>, Arc<[u8]>)]) -> bool {
    method.eq_ignore_ascii_case("OPTIONS")
        && has_non_empty_header_bytes(headers, b"origin")
        && has_non_empty_header_bytes(headers, b"access-control-request-method")
}

fn has_non_empty_header_string(headers: &[(String, String)], target: &str) -> bool {
    headers
        .iter()
        .any(|(name, value)| name.eq_ignore_ascii_case(target) && !value.trim().is_empty())
}

fn has_non_empty_header_bytes(headers: &[(Arc<[u8]>, Arc<[u8]>)], target: &[u8]) -> bool {
    let target = std::str::from_utf8(target).unwrap_or("");
    headers.iter().any(|(name, value)| {
        std::str::from_utf8(name.as_ref())
            .map(|header_name| header_name.eq_ignore_ascii_case(target))
            .unwrap_or(false)
            && std::str::from_utf8(value.as_ref())
                .map(|header_value| !header_value.trim().is_empty())
                .unwrap_or(false)
    })
}

fn has_bearer_header_string(headers: &[(String, String)]) -> bool {
    headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("authorization")
            && value.len() > 7
            && value
                .get(..7)
                .map(|prefix| prefix.eq_ignore_ascii_case("bearer "))
                .unwrap_or(false)
            && !value[7..].trim().is_empty()
    })
}

fn should_log_http1_read_error(err: &protocol::NegotiationError) -> bool {
    !matches!(err, protocol::NegotiationError::Timeout)
}

fn has_bearer_header_bytes(headers: &[(Arc<[u8]>, Arc<[u8]>)]) -> bool {
    headers.iter().any(|(name, value)| {
        std::str::from_utf8(name.as_ref())
            .map(|header_name| header_name.eq_ignore_ascii_case("authorization"))
            .unwrap_or(false)
            && std::str::from_utf8(value.as_ref())
                .map(|header_value| {
                    header_value.len() > 7
                        && header_value
                            .get(..7)
                            .map(|prefix| prefix.eq_ignore_ascii_case("bearer "))
                            .unwrap_or(false)
                        && !header_value[7..].trim().is_empty()
                })
                .unwrap_or(false)
    })
}

#[cfg(test)]
mod http2_security_tests;

#[cfg(test)]
mod http_metrics_tests;

#[cfg(test)]
mod http_transport_auth_tests;

#[cfg(test)]
mod connection_registry_tests;

#[cfg(test)]
mod rawsocket_reader_tests;

#[cfg(test)]
mod rawsocket_writer_tests;

#[cfg(test)]
mod websocket_writer_tests;

#[cfg(test)]
mod websocket_client_handshake_tests;

#[cfg(test)]
mod http1_response_tests;
#[cfg(test)]
mod http_response_headers_tests;

#[cfg(test)]
mod stats_tests {
    use super::*;

    #[test]
    fn http_connection_stats_capture_idle_timeout() {
        let stats = HttpConnectionStats::new(ConnectionProtocol::Http2);
        stats.record_request();
        stats.record_idle_timeout(Some("idle timeout".into()));
        let event = stats.finalize(ConnectionId(42), HttpConnectionCloseReason::Graceful, None);
        assert_eq!(event.connection_id, ConnectionId(42));
        assert_eq!(event.protocol, ConnectionProtocol::Http2);
        assert_eq!(event.request_count, 1);
        assert_eq!(event.idle_timeouts, 1);
        assert_eq!(event.reason, HttpConnectionCloseReason::IdleTimeout);
        assert_eq!(event.backpressure_events, 0);
        assert_eq!(event.max_backpressure_depth, 0);
        assert_eq!(event.goaway_events, 0);
        assert_eq!(event.detail.as_deref(), Some("idle timeout"));
    }

    #[test]
    fn http_connection_stats_capture_backpressure_and_goaway() {
        let stats = HttpConnectionStats::new(ConnectionProtocol::Http2);
        stats.record_request();
        stats.record_backpressure(3);
        stats.record_backpressure(7);
        stats.record_goaway(Some("remote goaway".into()));
        let event = stats.finalize(ConnectionId(7), HttpConnectionCloseReason::Graceful, None);
        assert_eq!(event.connection_id, ConnectionId(7));
        assert_eq!(event.protocol, ConnectionProtocol::Http2);
        assert_eq!(event.request_count, 1);
        assert_eq!(event.backpressure_events, 2);
        assert_eq!(event.max_backpressure_depth, 7);
        assert_eq!(event.goaway_events, 1);
        assert_eq!(event.reason, HttpConnectionCloseReason::GoAway);
        assert_eq!(event.detail.as_deref(), Some("remote goaway"));
    }
}

async fn serve_http_connection(
    listener_id: ListenerId,
    connection_id: ConnectionId,
    handshake: protocol::HttpHandshake,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    registry: Arc<ListenerRegistry>,
) {
    let (mut stream, request, body_phase, prefetched) = handshake.into_parts();
    let initial_version = request.version;
    if !prefetched.is_empty() {
        // Preserve parser-prefetched bytes on the underlying stream so the
        // body reader or the next pipelined request can drain them directly.
        stream.buffer_front(prefetched.as_ref());
    }
    let _ = stream.set_nodelay(true);
    let (read_half, mut write_half) = tokio::io::split(stream);
    let mut reader = Some(BufReader::new(read_half));
    let mut pending = Some((request, body_phase));
    let mut pending_reclaim: Option<Http1BodyReclaim> = None;
    let read_timeout = endpoint_config
        .idle_timeout
        .unwrap_or(endpoint_config.handshake_timeout);

    loop {
        let (request, body_phase) = match pending.take() {
            Some(value) => value,
            None => {
                if reader.is_none() {
                    if let Some(reclaim) = pending_reclaim.take() {
                        match reclaim.wait().await {
                            Ok(read_half) => {
                                reader = Some(BufReader::new(read_half));
                            }
                            Err(_) => break,
                        }
                    } else {
                        break;
                    }
                }
                match protocol::read_http_request(reader.as_mut().unwrap(), &endpoint_config).await
                {
                    Ok(Some(value)) => value,
                    Ok(None) => break,
                    Err(err) => {
                        if let protocol::NegotiationError::Protocol(detail) = &err {
                            if let Some(status) = protocol::classify_http_error_status(detail) {
                                let _ = send_http_simple_response(
                                    &mut write_half,
                                    initial_version,
                                    StatusCode::from_u16(status as u16).unwrap(),
                                    false,
                                    b"invalid HTTP request",
                                    &[],
                                )
                                .await;
                                let _ = write_half.shutdown().await;
                            }
                        }
                        if should_log_http1_read_error(&err) {
                            eprintln!(
                                "http/1 connection read error for listener {:?}: {:?}",
                                listener_id, err
                            );
                        }
                        break;
                    }
                }
            }
        };

        let (body_handle, new_reclaim) = match body_phase {
            HttpBodyPhase::Buffered(bytes) => (HttpBodyHandle::from_inline(bytes), None),
            HttpBodyPhase::Finished => (HttpBodyHandle::empty(), None),
            HttpBodyPhase::NeedsStreaming {
                prefix,
                remaining_len,
            } => {
                let reader_half = match reader.take() {
                    Some(buf) => buf.into_inner(),
                    None => {
                        eprintln!(
                            "http/1 streaming requested without active reader for listener {:?}",
                            listener_id
                        );
                        break;
                    }
                };
                let (state, reclaim) =
                    spawn_http1_streaming_body(prefix, reader_half, remaining_len, read_timeout);
                (HttpBodyHandle::streaming(state), Some(reclaim))
            }
        };
        if let Some(reclaim) = new_reclaim {
            pending_reclaim = Some(reclaim);
        }

        let protocol::HttpRequest {
            method,
            target,
            version,
            headers,
        } = request;
        let normalized_method = method.to_uppercase();
        let (path, query) = protocol::split_http_target(&target);
        let normalized_path = if path.is_empty() { "/" } else { path };
        let normalized_path_string = normalized_path.to_string();
        let query_owned = query.map(|value| value.to_string());
        let keep_alive = should_keep_alive(version, &headers);
        let protocol_label = format!("http/1.{}", version);

        match endpoint_config.match_http_route(
            &normalized_path_string,
            query,
            &normalized_method,
            &protocol_label,
        ) {
            HttpRouteMatch::Resolved(resolution) => {
                if let Some(failure) = evaluate_http_transport_auth_string_headers(
                    &resolution.transport_auth,
                    &endpoint_config,
                    &normalized_method,
                    &headers,
                ) {
                    let response = match failure {
                        HttpTransportAuthFailure::BearerRequired => {
                            send_http_simple_response(
                                &mut write_half,
                                version,
                                StatusCode::UNAUTHORIZED,
                                keep_alive,
                                b"bearer token required",
                                &[("WWW-Authenticate", "Bearer")],
                            )
                            .await
                        }
                        HttpTransportAuthFailure::TlsRequired => {
                            send_http_simple_response(
                                &mut write_half,
                                version,
                                StatusCode::FORBIDDEN,
                                keep_alive,
                                b"tls required",
                                &[],
                            )
                            .await
                        }
                        HttpTransportAuthFailure::MutualTlsRequired => {
                            send_http_simple_response(
                                &mut write_half,
                                version,
                                StatusCode::FORBIDDEN,
                                keep_alive,
                                b"mutual tls required",
                                &[],
                            )
                            .await
                        }
                    };
                    if let Err(err) = response {
                        if should_log_http_response_send_error(err.kind()) {
                            eprintln!(
                                "failed to send transport-auth rejection for listener {:?}: {}",
                                listener_id, err
                            );
                        }
                        break;
                    }
                    continue;
                }
                let (tx, rx) = oneshot::channel::<HttpResponseDispatch>();
                let summary_headers = headers
                    .iter()
                    .map(|(name, value)| {
                        (
                            http_bytes_from_slice(name.as_bytes()),
                            http_bytes_from_slice(value.as_bytes()),
                        )
                    })
                    .collect();
                let summary = HttpRequestSummary::new(
                    method,
                    target,
                    normalized_path_string.clone(),
                    query_owned,
                    protocol_label.clone(),
                    version,
                    summary_headers,
                    body_handle,
                    Some(resolution.realm.clone()),
                    Some(resolution.procedure.clone()),
                    Some(resolution),
                );
                let queued = QueuedHttpRequest {
                    summary,
                    response: HttpResponseHandle::new(connection_id, tx),
                };
                if let Err(err) = registry.enqueue_http_request(connection_id, queued) {
                    eprintln!(
                        "failed to enqueue http request for listener {:?}: {}",
                        listener_id, err
                    );
                    break;
                }
                match rx.await {
                    Ok(mut dispatch) => {
                        if let Err(err) =
                            send_http_dispatch(&mut write_half, version, keep_alive, &mut dispatch)
                                .await
                        {
                            if should_log_http_response_send_error(err.kind()) {
                                eprintln!(
                                    "failed to send http response for listener {:?}: {}",
                                    listener_id, err
                                );
                            }
                            break;
                        }
                    }
                    Err(_) => {
                        let _ = send_http_simple_response(
                            &mut write_half,
                            version,
                            StatusCode::INTERNAL_SERVER_ERROR,
                            keep_alive,
                            b"http request cancelled",
                            &[],
                        )
                        .await;
                        break;
                    }
                }
            }
            HttpRouteMatch::MethodNotAllowed { allowed_methods } => {
                let allow_value = allowed_methods.join(", ");
                if let Err(err) = send_http_simple_response(
                    &mut write_half,
                    version,
                    StatusCode::METHOD_NOT_ALLOWED,
                    keep_alive,
                    b"method not allowed",
                    &[("Allow", allow_value.as_str())],
                )
                .await
                {
                    if should_log_http_response_send_error(err.kind()) {
                        eprintln!(
                            "failed to send 405 response for listener {:?}: {}",
                            listener_id, err
                        );
                    }
                    break;
                }
            }
            HttpRouteMatch::ProtocolNotAllowed { allowed_protocols } => {
                let upgrade_value = allowed_protocols.join(", ");
                if let Err(err) = send_http_simple_response(
                    &mut write_half,
                    version,
                    StatusCode::UPGRADE_REQUIRED,
                    keep_alive,
                    b"protocol not allowed",
                    &[("Upgrade", upgrade_value.as_str())],
                )
                .await
                {
                    if should_log_http_response_send_error(err.kind()) {
                        eprintln!(
                            "failed to send 426 response for listener {:?}: {}",
                            listener_id, err
                        );
                    }
                    break;
                }
            }
            HttpRouteMatch::NotFound => {
                if let Err(err) = send_http_simple_response(
                    &mut write_half,
                    version,
                    StatusCode::NOT_FOUND,
                    keep_alive,
                    b"route not found",
                    &[],
                )
                .await
                {
                    if should_log_http_response_send_error(err.kind()) {
                        eprintln!(
                            "failed to send 404 response for listener {:?}: {}",
                            listener_id, err
                        );
                    }
                    break;
                }
            }
        }

        if reader.is_none() {
            if let Some(reclaim) = pending_reclaim.take() {
                match reclaim.wait().await {
                    Ok(read_half) => {
                        reader = Some(BufReader::new(read_half));
                    }
                    Err(_) => break,
                }
            } else {
                break;
            }
        }

        if !keep_alive {
            break;
        }
    }
}

async fn send_http_dispatch(
    writer: &mut IoWriteHalf,
    version: u8,
    keep_alive: bool,
    dispatch: &mut HttpResponseDispatch,
) -> io::Result<()> {
    ensure_connection_header(&mut dispatch.headers, keep_alive, version);
    match &mut dispatch.body {
        HttpResponseBody::Buffered(body) => {
            protocol::write_http_response_shared(
                writer,
                version,
                dispatch.status,
                &dispatch.headers,
                body,
            )
            .await
        }
        HttpResponseBody::Streaming(reader) => {
            strip_content_length(&mut dispatch.headers);
            ensure_chunked_transfer_encoding(&mut dispatch.headers);
            write_http1_chunked_response(
                writer,
                version,
                dispatch.status,
                &dispatch.headers,
                reader,
            )
            .await
        }
    }
}

async fn send_http_simple_response(
    writer: &mut IoWriteHalf,
    version: u8,
    status: StatusCode,
    keep_alive: bool,
    body: &[u8],
    extra_headers: &[(&str, &str)],
) -> io::Result<()> {
    let mut headers: Vec<(String, String)> = extra_headers
        .iter()
        .map(|(name, value)| (name.to_string(), value.to_string()))
        .collect();
    ensure_connection_header(&mut headers, keep_alive, version);
    protocol::write_http_response_shared(writer, version, status.as_u16() as i32, &headers, body)
        .await
}

fn ensure_connection_header(headers: &mut Vec<(String, String)>, keep_alive: bool, version: u8) {
    if headers
        .iter()
        .any(|(name, _)| name.eq_ignore_ascii_case("connection"))
    {
        return;
    }
    if keep_alive && version >= 1 {
        headers.push(("Connection".into(), "keep-alive".into()));
    } else {
        headers.push(("Connection".into(), "close".into()));
    }
}

fn ensure_chunked_transfer_encoding(headers: &mut Vec<(String, String)>) {
    headers.retain(|(name, _)| !name.eq_ignore_ascii_case("transfer-encoding"));
    headers.push(("Transfer-Encoding".into(), "chunked".into()));
}

fn strip_content_length(headers: &mut Vec<(String, String)>) {
    headers.retain(|(name, _)| !name.eq_ignore_ascii_case("content-length"));
}

async fn write_http1_chunked_response<W: AsyncWrite + Unpin>(
    writer: &mut W,
    version: u8,
    status: i32,
    headers: &[(String, String)],
    reader: &mut ResponseStreamReader,
) -> io::Result<()> {
    const MAX_BATCH_CHUNKS: usize = 64;
    const MAX_BATCH_BYTES: usize = 16 * 1024;

    let clamped = status.clamp(100, 599) as u16;
    let status_code = StatusCode::from_u16(clamped).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    let reason = status_code.canonical_reason().unwrap_or("");
    let mut response = Vec::with_capacity(128 + headers.len() * 32);
    write!(
        &mut response,
        "HTTP/1.{} {} {}\r\n",
        version,
        status_code.as_u16(),
        reason
    )?;
    for (name, value) in headers {
        write!(&mut response, "{}: {}\r\n", name, value)?;
    }
    response.extend_from_slice(b"\r\n");
    if let Err(err) = writer.write_all(&response).await {
        reader.close();
        return Err(err);
    }
    if let Err(err) = writer.flush().await {
        reader.close();
        return Err(err);
    }

    let mut batched_chunks = 0usize;
    let mut batched_bytes = 0usize;
    let mut next = reader.next().await;
    loop {
        match next {
            Ok(ResponseStreamFrame::Chunk { bytes, .. }) => {
                if bytes.is_empty() {
                    next = reader.next().await;
                    continue;
                }
                let header = format!("{:X}\r\n", bytes.len());
                if let Err(err) = writer.write_all(header.as_bytes()).await {
                    reader.close();
                    return Err(err);
                }
                if let Err(err) = writer.write_all(&bytes).await {
                    reader.close();
                    return Err(err);
                }
                if let Err(err) = writer.write_all(b"\r\n").await {
                    reader.close();
                    return Err(err);
                }

                batched_chunks += 1;
                batched_bytes = batched_bytes.saturating_add(bytes.len());
                if batched_chunks >= MAX_BATCH_CHUNKS || batched_bytes >= MAX_BATCH_BYTES {
                    if let Err(err) = writer.flush().await {
                        reader.close();
                        return Err(err);
                    }
                    batched_chunks = 0;
                    batched_bytes = 0;
                    next = reader.next().await;
                    continue;
                }

                match reader.try_next() {
                    Ok(Some(frame)) => next = Ok(frame),
                    Ok(None) => {
                        if let Err(err) = writer.flush().await {
                            reader.close();
                            return Err(err);
                        }
                        batched_chunks = 0;
                        batched_bytes = 0;
                        next = reader.next().await;
                    }
                    Err(err) => next = Err(err),
                }
            }
            Ok(ResponseStreamFrame::Finished { .. }) => {
                if let Err(err) = writer.write_all(b"0\r\n\r\n").await {
                    reader.close();
                    return Err(err);
                }
                // Complete the TLS record before waiting for the next request.
                let result = writer.flush().await;
                if result.is_err() {
                    reader.close();
                }
                return result;
            }
            Err(err) => {
                reader.close();
                return Err(io::Error::other(format!(
                    "http/1.x streaming response failed: {}",
                    err
                )));
            }
        }
    }
}

fn runtime_block_on<F>(handle: &tokio::runtime::Handle, future: F) -> F::Output
where
    F: std::future::Future,
{
    if tokio::runtime::Handle::try_current().is_ok() {
        tokio::task::block_in_place(|| handle.block_on(future))
    } else {
        handle.block_on(future)
    }
}

fn build_client_endpoint_config(
    host: &str,
    port: u16,
    use_tls: bool,
    protocol: TransportProtocol,
    max_rawsocket_size_exponent: u32,
    heartbeat_interval: Option<Duration>,
    heartbeat_timeout: Option<Duration>,
) -> config::EndpointRuntimeConfig {
    let exponent = max_rawsocket_size_exponent.clamp(
        config::MIN_RAWSOCKET_SIZE_EXPONENT,
        config::CONNECTANUM_MAX_RAWSOCKET_SIZE_EXPONENT,
    );
    config::EndpointRuntimeConfig {
        host: host.to_string(),
        port,
        tls_mode: if use_tls {
            config::TlsMode::Native
        } else {
            config::TlsMode::Disabled
        },
        client_auth: None,
        protocols: vec![protocol],
        idle_timeout: None,
        heartbeat_interval,
        heartbeat_timeout: heartbeat_timeout
            .or_else(|| heartbeat_interval.and_then(|interval| interval.checked_mul(2))),
        handshake_timeout: config::DEFAULT_HANDSHAKE_TIMEOUT,
        max_http_content_length: None,
        max_rawsocket_size_exponent: exponent,
        max_rawsocket_size: 1u64 << exponent,
        max_upgrade_exponent: (exponent > 24).then_some(exponent),
        outbound_send_queue_capacity: config::DEFAULT_OUTBOUND_SEND_QUEUE_CAPACITY,
        websocket_path: None,
        sni_certificates: Vec::new(),
        http_routes: Vec::new(),
        http: None,
    }
}

fn handshake_error_to_io(err: rawsocket::HandshakeError) -> Error {
    match err {
        rawsocket::HandshakeError::Protocol(reason) => {
            Error::Io(io::Error::new(io::ErrorKind::InvalidData, reason))
        }
        rawsocket::HandshakeError::Io(err) => Error::Io(err),
    }
}

async fn connect_io_stream(
    host: &str,
    port: u16,
    use_tls: bool,
    allow_insecure: bool,
    alpn_protocols: &[Vec<u8>],
) -> Result<(IoStream, SocketAddr), Error> {
    let stream = tokio::net::TcpStream::connect((host, port)).await?;
    let peer_addr = stream.peer_addr()?;
    let io_stream = if use_tls {
        let connector = tls::build_client_connector(allow_insecure, alpn_protocols)?;
        let server_name = server_name_from_host(host)?;
        let tls_stream = connector
            .connect(server_name, stream)
            .await
            .map_err(|err| io::Error::new(io::ErrorKind::ConnectionAborted, err.to_string()))?;
        IoStream::tls_client(tls_stream)
    } else {
        IoStream::plain(stream)
    };
    let _ = io_stream.set_nodelay(true);
    Ok((io_stream, peer_addr))
}

fn server_name_from_host(host: &str) -> Result<ServerName<'static>, Error> {
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(ServerName::IpAddress(ip.into()));
    }
    ServerName::try_from(host.to_string()).map_err(|err| {
        Error::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("invalid tls server name {host}: {err}"),
        ))
    })
}

fn websocket_subprotocol(serializer: rawsocket::Serializer) -> Result<&'static str, Error> {
    match serializer {
        rawsocket::Serializer::Json => Ok("wamp.2.json"),
        rawsocket::Serializer::MessagePack => Ok("wamp.2.msgpack"),
        rawsocket::Serializer::Cbor => Ok("wamp.2.cbor"),
        rawsocket::Serializer::Flatbuffers => Ok("wamp.2.flatbuffers"),
        _ => Err(Error::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("websocket serializer {serializer:?} is unsupported"),
        ))),
    }
}

fn websocket_host_header(host: &str, port: u16, use_tls: bool) -> String {
    let default_port = if use_tls { 443 } else { 80 };
    let base = if host.contains(':') && !host.starts_with('[') {
        format!("[{host}]")
    } else {
        host.to_string()
    };
    if port == default_port {
        base
    } else {
        format!("{base}:{port}")
    }
}

async fn perform_websocket_client_handshake(
    stream: &mut IoStream,
    host: &str,
    port: u16,
    use_tls: bool,
    target: &str,
    subprotocol: &str,
    headers: &[(String, String)],
    timeout: Duration,
) -> Result<(), Error> {
    let mut nonce_bytes = [0u8; 16];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Base64Engine.encode(nonce_bytes);
    let mut request = format!(
        "GET {} HTTP/1.1\r\nHost: {}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {}\r\nSec-WebSocket-Protocol: {}\r\n",
        if target.is_empty() { "/" } else { target },
        websocket_host_header(host, port, use_tls),
        nonce,
        subprotocol,
    );
    for (name, value) in headers {
        if name.eq_ignore_ascii_case("host")
            || name.eq_ignore_ascii_case("upgrade")
            || name.eq_ignore_ascii_case("connection")
            || name.eq_ignore_ascii_case("sec-websocket-version")
            || name.eq_ignore_ascii_case("sec-websocket-key")
            || name.eq_ignore_ascii_case("sec-websocket-protocol")
        {
            continue;
        }
        request.push_str(name);
        request.push_str(": ");
        request.push_str(value);
        request.push_str("\r\n");
    }
    request.push_str("\r\n");
    time::timeout(timeout, async {
        stream.write_all(request.as_bytes()).await?;
        stream.flush().await
    })
    .await
    .map_err(|_| {
        Error::Io(io::Error::new(
            io::ErrorKind::TimedOut,
            "websocket client handshake timed out",
        ))
    })??;

    let header_block = read_http_header_block(stream, timeout).await?;
    let header_text = std::str::from_utf8(&header_block).map_err(|err| {
        Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("websocket handshake response is not valid utf-8: {err}"),
        ))
    })?;
    let mut lines = header_text.split("\r\n");
    let status_line = lines.next().ok_or_else(|| {
        Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            "websocket handshake response missing status line",
        ))
    })?;
    if !status_line.starts_with("HTTP/1.1 101 ") && !status_line.starts_with("HTTP/1.0 101 ") {
        return Err(Error::Io(io::Error::new(
            io::ErrorKind::ConnectionRefused,
            format!("websocket upgrade failed: {status_line}"),
        )));
    }

    let mut response_headers = Vec::<(String, String)>::new();
    for line in lines {
        if line.is_empty() {
            break;
        }
        let Some((name, value)) = line.split_once(':') else {
            return Err(Error::Io(io::Error::new(
                io::ErrorKind::InvalidData,
                format!("invalid websocket handshake header: {line}"),
            )));
        };
        response_headers.push((name.trim().to_string(), value.trim().to_string()));
    }

    let upgrade = response_headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case("upgrade"))
        .map(|(_, value)| value.as_str())
        .unwrap_or_default();
    if !upgrade.eq_ignore_ascii_case("websocket") {
        return Err(Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            "websocket handshake missing Upgrade: websocket",
        )));
    }
    let connection = response_headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case("connection"))
        .map(|(_, value)| value.as_str())
        .unwrap_or_default();
    if !header_has_token(connection, "upgrade") {
        return Err(Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            "websocket handshake missing Connection: Upgrade",
        )));
    }
    let accept = response_headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case("sec-websocket-accept"))
        .map(|(_, value)| value.as_str())
        .ok_or_else(|| {
            Error::Io(io::Error::new(
                io::ErrorKind::InvalidData,
                "websocket handshake missing Sec-WebSocket-Accept",
            ))
        })?;
    if accept != websocket_accept_value(&nonce) {
        return Err(Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            "websocket handshake accept value mismatch",
        )));
    }
    let negotiated_protocol = response_headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case("sec-websocket-protocol"))
        .map(|(_, value)| value.as_str());
    if negotiated_protocol != Some(subprotocol) {
        return Err(Error::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "websocket handshake negotiated unexpected protocol {:?}",
                negotiated_protocol
            ),
        )));
    }
    Ok(())
}

async fn read_http_header_block(
    stream: &mut IoStream,
    timeout: Duration,
) -> Result<Vec<u8>, Error> {
    const HEADER_LIMIT: usize = 64 * 1024;
    let mut buffer = Vec::with_capacity(1024);
    loop {
        if let Some(end) = buffer.windows(4).position(|window| window == b"\r\n\r\n") {
            let header_end = end + 4;
            if buffer.len() > header_end {
                stream.buffer_front(&buffer[header_end..]);
            }
            buffer.truncate(header_end);
            return Ok(buffer);
        }
        if buffer.len() >= HEADER_LIMIT {
            return Err(Error::Io(io::Error::new(
                io::ErrorKind::InvalidData,
                "http header block exceeded limit",
            )));
        }
        let mut chunk = [0u8; 1024];
        let read = time::timeout(timeout, stream.read(&mut chunk))
            .await
            .map_err(|_| {
                Error::Io(io::Error::new(
                    io::ErrorKind::TimedOut,
                    "http header read timed out",
                ))
            })??;
        if read == 0 {
            return Err(Error::Io(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed before http headers completed",
            )));
        }
        buffer.extend_from_slice(&chunk[..read]);
    }
}

fn websocket_accept_value(key: &str) -> String {
    let mut sha1 = Sha1::new();
    sha1.update(key.as_bytes());
    sha1.update(WEBSOCKET_GUID.as_bytes());
    Base64Engine.encode(sha1.finalize())
}

async fn write_websocket_handshake_response<W>(
    stream: &mut W,
    accept_value: &str,
    protocol: Option<&str>,
) -> io::Result<()>
where
    W: AsyncWrite + Unpin,
{
    let mut response = format!(
        "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {}\r\n",
        accept_value
    );
    if let Some(protocol) = protocol {
        response.push_str(&format!("Sec-WebSocket-Protocol: {}\r\n", protocol));
    }
    response.push_str("\r\n");
    stream.write_all(response.as_bytes()).await?;
    stream.flush().await?;
    Ok(())
}

fn should_keep_alive(version: u8, headers: &[(String, String)]) -> bool {
    let directive = headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case("connection"))
        .map(|(_, value)| value.as_str());
    match version {
        0 => directive
            .map(|value| header_has_token(value, "keep-alive"))
            .unwrap_or(false),
        _ => directive
            .map(|value| !header_has_token(value, "close"))
            .unwrap_or(true),
    }
}

fn is_benign_socket_shutdown(kind: io::ErrorKind) -> bool {
    matches!(
        kind,
        io::ErrorKind::UnexpectedEof
            | io::ErrorKind::BrokenPipe
            | io::ErrorKind::ConnectionReset
            | io::ErrorKind::ConnectionAborted
    )
}

fn should_log_http_response_send_error(kind: io::ErrorKind) -> bool {
    !is_benign_socket_shutdown(kind)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Http2AcceptErrorClass {
    BenignShutdown,
    GoAway,
    ProtocolError,
}

fn classify_http2_accept_error_parts(
    is_go_away: bool,
    io_kind: Option<io::ErrorKind>,
) -> Http2AcceptErrorClass {
    if is_go_away {
        Http2AcceptErrorClass::GoAway
    } else if io_kind.is_some_and(is_benign_socket_shutdown) {
        Http2AcceptErrorClass::BenignShutdown
    } else {
        Http2AcceptErrorClass::ProtocolError
    }
}

fn classify_http2_accept_error(err: &H2Error) -> Http2AcceptErrorClass {
    classify_http2_accept_error_parts(err.is_go_away(), err.get_io().map(io::Error::kind))
}

fn header_has_token(value: &str, needle: &str) -> bool {
    value
        .split(',')
        .map(|token| token.trim())
        .any(|token| token.eq_ignore_ascii_case(needle))
}

async fn serve_http3_requests(
    listener_id: ListenerId,
    connection_id: ConnectionId,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    registry: Arc<ListenerRegistry>,
    connection: Arc<QuinnConnection>,
    streams: Arc<Http3StreamChannels>,
) {
    let mut h3_conn = match h3::server::builder()
        .build(H3QuinnConnection::new(connection.deref().clone()))
        .await
    {
        Ok(conn) => conn,
        Err(err) => {
            if err.is_h3_no_error() {
                registry.finish_http_connection(
                    connection_id,
                    HttpConnectionCloseReason::Graceful,
                    None,
                );
            } else {
                eprintln!(
                    "http3 handshake failed for listener {:?}: {}",
                    listener_id, err
                );
                registry.finish_http_connection(
                    connection_id,
                    HttpConnectionCloseReason::ProtocolError,
                    Some(err.to_string()),
                );
            }
            return;
        }
    };

    let connection_stats = registry
        .connection_stats(connection_id)
        .ok()
        .and_then(|stats| stats);
    let mut closed = false;

    loop {
        match h3_conn.accept().await {
            Ok(Some(resolver)) => match resolver.resolve_request().await {
                Ok((request, stream)) => {
                    #[cfg(feature = "ffi-test")]
                    if ffi_test_debug_logs_enabled() {
                        eprintln!(
                            "http3 request accepted on connection {:?}: {} {}",
                            connection_id,
                            request.method(),
                            request.uri()
                        );
                    }
                    if let Err(err) = process_http3_request(
                        connection_id,
                        Arc::clone(&connection),
                        request,
                        stream,
                        Arc::clone(&endpoint_config),
                        Arc::clone(&registry),
                    )
                    .await
                    {
                        eprintln!(
                            "http3 request error for listener {:?}: {}",
                            listener_id, err
                        );
                    }
                }
                Err(err) => {
                    eprintln!(
                        "http3 request resolve error for listener {:?}: {}",
                        listener_id, err
                    );
                }
            },
            Ok(None) => break,
            Err(err) => {
                let h3_no_error = err.is_h3_no_error();
                let err_description = err.to_string();
                let mut graceful_close = h3_no_error;
                if !graceful_close {
                    if let Some(code_segment) = err_description.rsplit(':').next() {
                        if code_segment.trim().eq_ignore_ascii_case("0x0") {
                            graceful_close = true;
                        }
                    }
                }
                let error_message = if graceful_close {
                    None
                } else {
                    Some(err_description)
                };
                if !graceful_close {
                    if let Some(message) = error_message.as_ref() {
                        #[cfg(feature = "ffi-test")]
                        {
                            if ffi_test_debug_logs_enabled() {
                                eprintln!(
                                    "http3 accept loop stopped for listener {:?}: {}",
                                    listener_id, message
                                );
                            }
                        }
                        #[cfg(not(feature = "ffi-test"))]
                        eprintln!(
                            "http3 accept loop stopped for listener {:?}: {}",
                            listener_id, message
                        );
                    }
                }
                let reason = if graceful_close {
                    HttpConnectionCloseReason::Graceful
                } else {
                    HttpConnectionCloseReason::ProtocolError
                };
                if let Some(stats) = connection_stats.as_ref() {
                    stats.set_close_reason(reason, error_message.clone());
                }
                registry.finish_http_connection(connection_id, reason, error_message);
                closed = true;
                break;
            }
        }
    }

    drop(streams);
    if !closed {
        registry.finish_http_connection(connection_id, HttpConnectionCloseReason::Graceful, None);
    }
}

async fn serve_http2_connection(
    listener_id: ListenerId,
    connection_id: ConnectionId,
    stream: IoStream,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    registry: Arc<ListenerRegistry>,
) {
    let builder = http2_server_builder();
    let write_tracker = Arc::new(Http2ConnectionWriteTracker::default());
    let mut connection = match builder
        .handshake(InstrumentedHttp2IoStream {
            inner: stream,
            write_tracker: Arc::clone(&write_tracker),
        })
        .await
    {
        Ok(connection) => connection,
        Err(err) => {
            eprintln!(
                "http/2 handshake failed for listener {:?}: {}",
                listener_id, err
            );
            registry.finish_http_connection(
                connection_id,
                HttpConnectionCloseReason::ProtocolError,
                Some(err.to_string()),
            );
            return;
        }
    };

    let connection_stats = registry
        .connection_stats(connection_id)
        .ok()
        .and_then(|stats| stats);
    let mut closed = false;

    while let Some(result) = connection.accept().await {
        match result {
            Ok((request, respond)) => {
                if let Err(err) = handle_http2_request(
                    connection_id,
                    request,
                    respond,
                    Arc::clone(&endpoint_config),
                    Arc::clone(&registry),
                    Arc::clone(&write_tracker),
                )
                .await
                {
                    eprintln!(
                        "http/2 request error for listener {:?}: {}",
                        listener_id, err
                    );
                }
            }
            Err(err) => {
                let err_detail = err.to_string();
                let (reason, detail) = match classify_http2_accept_error(&err) {
                    Http2AcceptErrorClass::BenignShutdown => {
                        (HttpConnectionCloseReason::Graceful, None)
                    }
                    Http2AcceptErrorClass::GoAway => {
                        let detail = Some(err_detail);
                        if let Some(stats) = connection_stats.as_ref() {
                            stats.record_goaway(detail.clone());
                        }
                        (HttpConnectionCloseReason::GoAway, detail)
                    }
                    Http2AcceptErrorClass::ProtocolError => {
                        eprintln!(
                            "http/2 accept error for listener {:?}: {}",
                            listener_id, err_detail
                        );
                        let detail = Some(err_detail);
                        if let Some(stats) = connection_stats.as_ref() {
                            stats.set_close_reason(
                                HttpConnectionCloseReason::ProtocolError,
                                detail.clone(),
                            );
                        }
                        (HttpConnectionCloseReason::ProtocolError, detail)
                    }
                };
                registry.finish_http_connection(connection_id, reason, detail);
                closed = true;
                break;
            }
        }
    }

    if !closed {
        registry.finish_http_connection(connection_id, HttpConnectionCloseReason::Graceful, None);
    }
}

async fn handle_http2_request(
    connection_id: ConnectionId,
    request: Http2Request<H2RecvStream>,
    respond: H2SendResponse<Bytes>,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    registry: Arc<ListenerRegistry>,
    write_tracker: Arc<Http2ConnectionWriteTracker>,
) -> Result<(), String> {
    let (parts, body_stream) = request.into_parts();
    let method = parts.method.as_str().to_string();
    let normalized_method = method.to_uppercase();
    let target = parts
        .uri
        .path_and_query()
        .map(|pq| pq.as_str().to_string())
        .unwrap_or_else(|| parts.uri.path().to_string());
    let (path, query) = split_target_components(&target);
    let authority = parts
        .uri
        .authority()
        .map(|authority| authority.as_str().to_string());
    let headers = flatten_http2_headers(&parts.headers, authority.as_deref());
    let content_length = parse_content_length(&headers);
    let max_body = endpoint_config
        .max_http_content_length
        .unwrap_or(HTTP3_DEFAULT_BODY_LIMIT);

    let stats = registry
        .connection_stats(connection_id)
        .map_err(|err| err.to_string())?;
    if let Some(ref stats_arc) = stats {
        stats_arc.record_request();
    }
    let state = StreamingBodyState::new(content_length.map(|len| len as usize).unwrap_or(0));
    let (idle_timeout, total_timeout) = http_stream_timeouts(&endpoint_config);
    // Apply a generous floor for endpoints that use the default idle timeout so multi-MB tests
    // don't flake; explicit config keeps full control over the timeout values.
    let (idle_timeout, total_timeout) = if endpoint_config.idle_timeout.is_none() {
        (
            idle_timeout.max(Duration::from_secs(30)),
            total_timeout.max(Duration::from_secs(60)),
        )
    } else {
        (idle_timeout, total_timeout)
    };
    spawn_http2_stream_reader(
        stats.clone(),
        Arc::clone(&state),
        body_stream,
        max_body,
        content_length,
        idle_timeout,
        total_timeout,
    );
    let body_handle = HttpBodyHandle::streaming(state);
    let query_owned = query.clone();

    match endpoint_config.match_http_route(&path, query.as_deref(), &normalized_method, "http2") {
        HttpRouteMatch::Resolved(resolution) => {
            if let Some(failure) = evaluate_http_transport_auth_bytes_headers(
                &resolution.transport_auth,
                &endpoint_config,
                &normalized_method,
                &headers,
            ) {
                return match failure {
                    HttpTransportAuthFailure::BearerRequired => {
                        send_http2_plain_response(
                            respond,
                            StatusCode::UNAUTHORIZED,
                            b"bearer token required",
                            &[("www-authenticate", "Bearer")],
                        )
                        .await
                    }
                    HttpTransportAuthFailure::TlsRequired => {
                        send_http2_plain_response(
                            respond,
                            StatusCode::FORBIDDEN,
                            b"tls required",
                            &[],
                        )
                        .await
                    }
                    HttpTransportAuthFailure::MutualTlsRequired => {
                        send_http2_plain_response(
                            respond,
                            StatusCode::FORBIDDEN,
                            b"mutual tls required",
                            &[],
                        )
                        .await
                    }
                };
            }
            let (tx, rx) = oneshot::channel::<HttpResponseDispatch>();
            let summary = HttpRequestSummary::new(
                normalized_method,
                target,
                path,
                query_owned,
                "http/2".to_string(),
                2,
                headers,
                body_handle,
                Some(resolution.realm.clone()),
                Some(resolution.procedure.clone()),
                Some(resolution),
            );
            let queued = QueuedHttpRequest {
                summary,
                response: HttpResponseHandle::new(connection_id, tx),
            };
            registry
                .enqueue_http_request(connection_id, queued)
                .map_err(|err| err.to_string())?;
            tokio::spawn(async move {
                match rx.await {
                    Ok(dispatch) => {
                        if let Err(err) =
                            send_http2_response_from_dispatch(respond, dispatch, write_tracker)
                                .await
                        {
                            eprintln!(
                                "failed to send http/2 response for connection {:?}: {}",
                                connection_id, err
                            );
                        }
                    }
                    Err(_) => {
                        let _ = send_http2_plain_response(
                            respond,
                            StatusCode::INTERNAL_SERVER_ERROR,
                            b"http/2 request cancelled",
                            &[],
                        )
                        .await;
                    }
                }
            });
            Ok(())
        }
        HttpRouteMatch::MethodNotAllowed { allowed_methods } => {
            let allow_value = allowed_methods.join(", ");
            send_http2_plain_response(
                respond,
                StatusCode::METHOD_NOT_ALLOWED,
                b"method not allowed",
                &[("allow", allow_value.as_str())],
            )
            .await
        }
        HttpRouteMatch::ProtocolNotAllowed { .. } => {
            send_http2_plain_response(
                respond,
                StatusCode::UPGRADE_REQUIRED,
                b"protocol not allowed",
                &[],
            )
            .await
        }
        HttpRouteMatch::NotFound => {
            send_http2_plain_response(respond, StatusCode::NOT_FOUND, b"route not found", &[]).await
        }
    }
}

fn spawn_http2_stream_reader(
    stats: Option<Arc<HttpConnectionStats>>,
    state: Arc<StreamingBodyState>,
    stream: H2RecvStream,
    max_body: u64,
    content_length: Option<u64>,
    idle_timeout: Duration,
    total_timeout: Duration,
) {
    tokio::spawn(async move {
        if let Err(err) = run_http2_stream_reader(
            stats,
            state,
            stream,
            max_body,
            content_length,
            idle_timeout,
            total_timeout,
        )
        .await
        {
            eprintln!("http/2 body reader error: {}", err);
        }
    });
}

fn http2_recv_flow_control_sample(stream: &mut H2RecvStream) -> HttpRequestBodyFlowControlSample {
    let flow_control = stream.flow_control();
    HttpRequestBodyFlowControlSample {
        available_capacity: flow_control.available_capacity() as i64,
        used_capacity: flow_control.used_capacity() as u64,
    }
}

async fn run_http2_stream_reader(
    stats: Option<Arc<HttpConnectionStats>>,
    state: Arc<StreamingBodyState>,
    mut stream: H2RecvStream,
    max_body: u64,
    content_length: Option<u64>,
    idle_timeout: Duration,
    total_timeout: Duration,
) -> Result<(), String> {
    let metrics = http_request_body_stream_metrics();
    metrics.record_streaming_request();
    let reader_started_at = Instant::now();
    let mut first_chunk_at = None;
    let mut second_chunk_at = None;
    let mut remaining_tail_data_wait_us = 0;
    let mut remaining_tail_data_wait_max = HttpRequestBodyTailDataWaitMax::default();
    let mut bytes_read: u64 = 0;
    let mut data_event_index: u64 = 0;
    let total_deadline = Instant::now() + total_timeout;
    loop {
        if state.finish_requested() {
            metrics.record_reader_finished(
                reader_started_at,
                Instant::now(),
                second_chunk_at,
                remaining_tail_data_wait_us,
                remaining_tail_data_wait_max,
            );
            state.mark_finished();
            return Ok(());
        }

        if Instant::now() >= total_deadline {
            if let Some(stats_ref) = stats.as_ref() {
                stats_ref.record_body_timeout(Some("http/2 body total timeout".into()));
                stats_ref.record_goaway(Some("http/2 body total timeout".into()));
            }
            state.mark_error("http/2 body total timeout exceeded".into());
            return Err("http/2 body total timeout".into());
        }

        let data_wait_started_at = Instant::now();
        let bytes_before_wait = bytes_read;
        let should_sample_tail_flow = second_chunk_at.is_some();
        let flow_before_wait = if should_sample_tail_flow {
            http2_recv_flow_control_sample(&mut stream)
        } else {
            HttpRequestBodyFlowControlSample::default()
        };
        let data_future = stream.data();
        let chunk = match time::timeout(idle_timeout, data_future).await {
            Ok(value) => value,
            Err(_) => {
                if let Some(stats_ref) = stats.as_ref() {
                    stats_ref.record_idle_timeout(Some("http/2 body idle timeout".into()));
                    stats_ref.record_goaway(Some("http/2 body idle timeout".into()));
                }
                let message = format!("http/2 body idle timeout after {} bytes", bytes_read);
                state.mark_error(message.clone());
                return Err(message);
            }
        };
        let data_received_at = Instant::now();
        let data_wait_us = saturating_instant_delta_us(data_wait_started_at, data_received_at);
        data_event_index = data_event_index.saturating_add(1);
        let flow_after_data = if should_sample_tail_flow {
            http2_recv_flow_control_sample(&mut stream)
        } else {
            HttpRequestBodyFlowControlSample::default()
        };

        match chunk {
            Some(Ok(bytes)) => {
                let is_remaining_tail_chunk = second_chunk_at.is_some();
                let len = bytes.len();
                let bytes_after_wait = bytes_before_wait.saturating_add(len as u64);
                metrics.record_data_chunk_wait_us(data_wait_us);
                if is_remaining_tail_chunk {
                    remaining_tail_data_wait_us =
                        remaining_tail_data_wait_us.saturating_add(data_wait_us);
                }
                if first_chunk_at.is_none() {
                    first_chunk_at = Some(data_received_at);
                    metrics.record_first_chunk_wait(reader_started_at, data_received_at);
                } else if second_chunk_at.is_none() {
                    let first_at = first_chunk_at.expect("first chunk set");
                    second_chunk_at = Some(data_received_at);
                    metrics.record_second_chunk_wait(first_at, data_received_at);
                }
                bytes_read = bytes_after_wait;
                if bytes_read > max_body
                    || content_length
                        .map(|limit| bytes_read > limit)
                        .unwrap_or(false)
                {
                    state.mark_error("http/2 body exceeded configured limit".into());
                    return Ok(());
                }
                if content_length.is_none() {
                    state.extend_total_len(len);
                }
                if !state.finish_requested() {
                    state.enqueue_bytes(bytes);
                }
                let release_result = stream.flow_control().release_capacity(len);
                let flow_after_release = if should_sample_tail_flow {
                    http2_recv_flow_control_sample(&mut stream)
                } else {
                    HttpRequestBodyFlowControlSample::default()
                };
                if let Err(err) = release_result {
                    state.mark_error(format!("http/2 flow control error: {}", err));
                    return Err(err.to_string());
                }
                if is_remaining_tail_chunk {
                    remaining_tail_data_wait_max.observe(
                        data_wait_us,
                        data_event_index,
                        bytes_before_wait,
                        bytes_after_wait,
                        false,
                        flow_before_wait,
                        flow_after_data,
                        flow_after_release,
                    );
                }
            }
            Some(Err(err)) => {
                if let Some(stats_ref) = stats.as_ref() {
                    stats_ref.set_close_reason(
                        HttpConnectionCloseReason::ProtocolError,
                        Some(format!("http/2 body read failed: {}", err)),
                    );
                }
                state.mark_error(format!("http/2 body read failed: {}", err));
                return Err(err.to_string());
            }
            None => {
                if let Some(expected) = content_length {
                    if bytes_read != expected {
                        state.mark_error("http/2 body ended before declared Content-Length".into());
                        return Ok(());
                    }
                }
                if second_chunk_at.is_some() {
                    remaining_tail_data_wait_us =
                        remaining_tail_data_wait_us.saturating_add(data_wait_us);
                    remaining_tail_data_wait_max.observe(
                        data_wait_us,
                        data_event_index,
                        bytes_before_wait,
                        bytes_before_wait,
                        true,
                        flow_before_wait,
                        flow_after_data,
                        flow_after_data,
                    );
                }
                metrics.record_reader_finished(
                    reader_started_at,
                    Instant::now(),
                    second_chunk_at,
                    remaining_tail_data_wait_us,
                    remaining_tail_data_wait_max,
                );
                state.mark_finished();
                return Ok(());
            }
        }
    }
}

async fn send_http2_plain_response(
    mut respond: H2SendResponse<Bytes>,
    status: StatusCode,
    body: &[u8],
    extra_headers: &[(&str, &str)],
) -> Result<(), String> {
    let http2_status = Http2StatusCode::from_u16(status.as_u16())
        .unwrap_or(Http2StatusCode::INTERNAL_SERVER_ERROR);
    let mut builder = Http2Response::builder().status(http2_status);
    {
        let header_map = builder.headers_mut().expect("headers available");
        for (name, value) in extra_headers {
            if let (Ok(name), Ok(val)) = (
                Http2HeaderName::from_bytes(name.as_bytes()),
                Http2HeaderValue::from_str(value),
            ) {
                header_map.append(name, val);
            }
        }
        if let Ok(value) = Http2HeaderValue::from_str(&body.len().to_string()) {
            header_map.insert(Http2HeaderName::from_static("content-length"), value);
        }
    }
    let response = builder.body(()).map_err(|err| err.to_string())?;
    let end_of_stream = body.is_empty();
    let mut send_stream = respond
        .send_response(response, end_of_stream)
        .map_err(|err| err.to_string())?;
    if !body.is_empty() {
        send_stream
            .send_data(Bytes::copy_from_slice(body), true)
            .map_err(|err| err.to_string())?;
    }
    Ok(())
}

async fn send_http2_response_from_dispatch(
    mut respond: H2SendResponse<Bytes>,
    dispatch: HttpResponseDispatch,
    write_tracker: Arc<Http2ConnectionWriteTracker>,
) -> Result<(), String> {
    let HttpResponseDispatch {
        status,
        mut headers,
        body,
    } = dispatch;
    let clamped = status.clamp(100, 599) as u16;
    let status_code = StatusCode::from_u16(clamped).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    let http2_status = Http2StatusCode::from_u16(status_code.as_u16())
        .unwrap_or(Http2StatusCode::INTERNAL_SERVER_ERROR);
    let mut builder = Http2Response::builder().status(http2_status);
    match body {
        HttpResponseBody::Buffered(body_bytes) => {
            {
                let header_map = builder.headers_mut().expect("headers available");
                for (name, value) in &headers {
                    if let (Ok(name), Ok(value)) = (
                        Http2HeaderName::from_bytes(name.as_bytes()),
                        Http2HeaderValue::from_str(value),
                    ) {
                        header_map.append(name, value);
                    }
                }
                if let Ok(len_value) = Http2HeaderValue::from_str(&body_bytes.len().to_string()) {
                    header_map.insert(Http2HeaderName::from_static("content-length"), len_value);
                }
            }
            let response = builder.body(()).map_err(|err| err.to_string())?;
            let end_of_stream = body_bytes.is_empty();
            let mut send_stream = respond
                .send_response(response, end_of_stream)
                .map_err(|err| err.to_string())?;
            if !body_bytes.is_empty() {
                send_stream
                    .send_data(Bytes::from(body_bytes), true)
                    .map_err(|err| err.to_string())?;
            }
            Ok(())
        }
        HttpResponseBody::Streaming(mut reader) => {
            http_response_stream_metrics().record_streaming_response();
            strip_content_length(&mut headers);
            {
                let header_map = builder.headers_mut().expect("headers available");
                for (name, value) in &headers {
                    if let (Ok(name), Ok(value)) = (
                        Http2HeaderName::from_bytes(name.as_bytes()),
                        Http2HeaderValue::from_str(value),
                    ) {
                        header_map.append(name, value);
                    }
                }
            }
            let response = builder.body(()).map_err(|err| err.to_string())?;
            let stream_opened_at = reader.opened_at();
            let headers_send_call_started_at = Instant::now();
            let mut send_stream = respond
                .send_response(response, false)
                .map_err(|err| err.to_string())?;
            let headers_sent_at = Instant::now();
            let pending_headers = write_tracker.note_headers_sent(headers_sent_at);
            http_response_stream_metrics().record_headers_sent(
                stream_opened_at,
                headers_send_call_started_at,
                headers_sent_at,
            );
            if should_yield_for_pending_http2_responses(pending_headers) {
                // Only yield when multiple responses have queued headers but none
                // has reached the shared connection writer yet. This preserves
                // the multiplex benefit without adding a single-stream header
                // delay on uncontended connections.
                tokio::task::yield_now().await;
            }
            let mut first_chunk_sent_at = None;
            let mut last_chunk_sent_at = None;
            let mut tail_chunk_recorded = false;
            loop {
                match reader.next().await {
                    Ok(ResponseStreamFrame::Chunk { bytes, queued_at }) => {
                        let send_call_started_at = Instant::now();
                        if let Err(err) = send_stream.send_data(bytes, false) {
                            reader.close();
                            return Err(err.to_string());
                        }
                        let send_call_finished_at = Instant::now();
                        last_chunk_sent_at = Some(send_call_finished_at);
                        if first_chunk_sent_at.is_none() {
                            http_response_stream_metrics().record_first_chunk(
                                queued_at,
                                headers_sent_at,
                                send_call_started_at,
                                send_call_started_at,
                                send_call_finished_at,
                            );
                            first_chunk_sent_at = Some(send_call_finished_at);
                            if should_yield_for_pending_http2_responses(pending_headers) {
                                // On multiplexed connections, let the shared
                                // driver move the first chunk before this task
                                // drains the rest of a buffered response.
                                tokio::task::yield_now().await;
                            }
                        } else {
                            http_response_stream_metrics().record_tail_chunk(
                                queued_at,
                                send_call_started_at,
                                send_call_started_at,
                                send_call_finished_at,
                            );
                            tail_chunk_recorded = true;
                        }
                    }
                    Ok(ResponseStreamFrame::Finished { .. }) => {
                        if tail_chunk_recorded {
                            if let (Some(first_sent_at), Some(last_sent_at)) =
                                (first_chunk_sent_at, last_chunk_sent_at)
                            {
                                http_response_stream_metrics()
                                    .record_first_to_last_chunk_send(first_sent_at, last_sent_at);
                            }
                        }
                        if let Err(err) = send_stream.send_data(Bytes::new(), true) {
                            return Err(err.to_string());
                        }
                        return Ok(());
                    }
                    Err(err) => {
                        reader.close();
                        return Err(format!("http/2 streaming response failed: {}", err));
                    }
                }
            }
        }
    }
}

async fn process_http3_request(
    connection_id: ConnectionId,
    connection: Arc<QuinnConnection>,
    request: HttpRequest<()>,
    stream: H3ServerBidiStream,
    endpoint_config: Arc<config::EndpointRuntimeConfig>,
    registry: Arc<ListenerRegistry>,
) -> Result<(), String> {
    #[cfg(feature = "ffi-test")]
    if ffi_test_debug_logs_enabled() {
        eprintln!(
            "http3 processing request {:?}: {} {}",
            connection_id,
            request.method(),
            request.uri()
        );
    }
    let method = request.method().as_str().to_string();
    let normalized_method = method.to_uppercase();
    let target = request
        .uri()
        .path_and_query()
        .map(|pq| pq.as_str().to_string())
        .unwrap_or_else(|| request.uri().path().to_string());
    let (path, query) = split_target_components(&target);
    let authority = request
        .uri()
        .authority()
        .map(|authority| authority.as_str().to_string());
    let headers = flatten_headers(request.headers(), authority.as_deref());

    let max_body = endpoint_config
        .max_http_content_length
        .unwrap_or(HTTP3_DEFAULT_BODY_LIMIT);
    let content_length = parse_content_length(&headers);
    let stats = registry
        .connection_stats(connection_id)
        .map_err(|err| err.to_string())?;
    if let Some(ref stats_arc) = stats {
        stats_arc.record_request();
    }
    let (mut send_stream, recv_stream) = stream.split();
    let body_state = StreamingBodyState::new(content_length.map(|len| len as usize).unwrap_or(0));
    let (idle_timeout, total_timeout) = http_stream_timeouts(&endpoint_config);
    // Apply a generous floor for endpoints that use the default idle timeout so multi-MB tests
    // don't flake; explicit config keeps full control over the timeout values.
    let (idle_timeout, total_timeout) = if endpoint_config.idle_timeout.is_none() {
        (
            idle_timeout.max(Duration::from_secs(30)),
            total_timeout.max(Duration::from_secs(60)),
        )
    } else {
        (idle_timeout, total_timeout)
    };
    spawn_http3_stream_reader(
        stats.clone(),
        Arc::clone(&body_state),
        connection,
        recv_stream,
        max_body,
        0,
        content_length,
        idle_timeout,
        total_timeout,
    );
    let body_handle = HttpBodyHandle::streaming(body_state);

    match endpoint_config.match_http_route(&path, query.as_deref(), &normalized_method, "http3") {
        HttpRouteMatch::Resolved(resolution) => {
            if let Some(failure) = evaluate_http_transport_auth_bytes_headers(
                &resolution.transport_auth,
                &endpoint_config,
                &normalized_method,
                &headers,
            ) {
                return match failure {
                    HttpTransportAuthFailure::BearerRequired => {
                        send_http3_plain_response(
                            &mut send_stream,
                            StatusCode::UNAUTHORIZED,
                            b"bearer token required",
                            &[("www-authenticate", "Bearer")],
                        )
                        .await
                    }
                    HttpTransportAuthFailure::TlsRequired => {
                        send_http3_plain_response(
                            &mut send_stream,
                            StatusCode::FORBIDDEN,
                            b"tls required",
                            &[],
                        )
                        .await
                    }
                    HttpTransportAuthFailure::MutualTlsRequired => {
                        send_http3_plain_response(
                            &mut send_stream,
                            StatusCode::FORBIDDEN,
                            b"mutual tls required",
                            &[],
                        )
                        .await
                    }
                };
            }
            let (tx, rx) = oneshot::channel::<HttpResponseDispatch>();
            let summary = HttpRequestSummary::new(
                normalized_method,
                target,
                path,
                query,
                "http/3".to_string(),
                3,
                headers,
                body_handle,
                Some(resolution.realm.clone()),
                Some(resolution.procedure.clone()),
                Some(resolution),
            );
            let queued = QueuedHttpRequest {
                summary,
                response: HttpResponseHandle::new(connection_id, tx),
            };
            registry
                .enqueue_http_request(connection_id, queued)
                .map_err(|err| err.to_string())?;
            tokio::spawn(async move {
                match rx.await {
                    Ok(dispatch) => {
                        if let Err(err) =
                            send_http3_response_from_dispatch(&mut send_stream, dispatch).await
                        {
                            eprintln!(
                                "failed to send http3 response for connection {:?}: {}",
                                connection_id, err
                            );
                        }
                    }
                    Err(_) => {
                        let _ = send_http3_plain_response(
                            &mut send_stream,
                            StatusCode::INTERNAL_SERVER_ERROR,
                            b"http/3 request cancelled",
                            &[],
                        )
                        .await;
                    }
                }
            });
            Ok(())
        }
        HttpRouteMatch::MethodNotAllowed { allowed_methods } => {
            let allow_value = allowed_methods.join(", ");
            send_http3_plain_response(
                &mut send_stream,
                StatusCode::METHOD_NOT_ALLOWED,
                b"method not allowed",
                &[("allow", allow_value.as_str())],
            )
            .await
        }
        HttpRouteMatch::ProtocolNotAllowed { .. } => {
            send_http3_plain_response(
                &mut send_stream,
                StatusCode::UPGRADE_REQUIRED,
                b"protocol not allowed",
                &[],
            )
            .await
        }
        HttpRouteMatch::NotFound => {
            send_http3_plain_response(
                &mut send_stream,
                StatusCode::NOT_FOUND,
                b"route not found",
                &[],
            )
            .await
        }
    }
}

fn append_authority_host_header(
    headers: &mut Vec<(Arc<[u8]>, Arc<[u8]>)>,
    authority: Option<&str>,
) {
    if headers
        .iter()
        .any(|(name, _)| name.eq_ignore_ascii_case(b"host"))
    {
        return;
    }
    let Some(authority) = authority.map(str::trim).filter(|value| !value.is_empty()) else {
        return;
    };
    headers.push((
        http_bytes_from_slice(b"host"),
        http_bytes_from_slice(authority.as_bytes()),
    ));
}

fn flatten_headers(
    headers: &http::HeaderMap,
    authority: Option<&str>,
) -> Vec<(Arc<[u8]>, Arc<[u8]>)> {
    let mut flattened = headers
        .iter()
        .map(|(name, value)| {
            (
                http_bytes_from_slice(name.as_str().as_bytes()),
                http_bytes_from_slice(value.as_bytes()),
            )
        })
        .collect();
    append_authority_host_header(&mut flattened, authority);
    flattened
}

fn flatten_http2_headers(
    headers: &http::HeaderMap,
    authority: Option<&str>,
) -> Vec<(Arc<[u8]>, Arc<[u8]>)> {
    let mut flattened = headers
        .iter()
        .map(|(name, value)| {
            (
                http_bytes_from_slice(name.as_str().as_bytes()),
                http_bytes_from_slice(value.as_bytes()),
            )
        })
        .collect();
    append_authority_host_header(&mut flattened, authority);
    flattened
}

fn split_target_components(target: &str) -> (String, Option<String>) {
    match target.split_once('?') {
        Some((path, query)) => (path.to_string(), Some(query.to_string())),
        None => (target.to_string(), None),
    }
}

fn parse_content_length(headers: &[(Arc<[u8]>, Arc<[u8]>)]) -> Option<u64> {
    headers
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case(CONTENT_LENGTH.as_str().as_bytes()))
        .and_then(|(_, value)| std::str::from_utf8(value.as_ref()).ok())
        .and_then(|value| value.trim().parse::<u64>().ok())
}

fn spawn_http3_stream_reader(
    stats: Option<Arc<HttpConnectionStats>>,
    state: Arc<StreamingBodyState>,
    connection: Arc<QuinnConnection>,
    stream: H3ServerRecvStream,
    max_body: u64,
    bytes_read: u64,
    content_length: Option<u64>,
    idle_timeout: Duration,
    total_timeout: Duration,
) {
    tokio::spawn(async move {
        let stats_for_reader = stats.clone();
        if let Err(err) = run_http3_stream_reader(
            stats_for_reader,
            state,
            connection,
            stream,
            max_body,
            bytes_read,
            content_length,
            idle_timeout,
            total_timeout,
        )
        .await
        {
            #[cfg(feature = "ffi-test")]
            eprintln!(
                "http/3 body reader failed: {} (max_body {}, idle {:?}, total {:?})",
                err, max_body, idle_timeout, total_timeout
            );
            if let Some(stats_ref) = stats.as_ref() {
                stats_ref
                    .set_close_reason(HttpConnectionCloseReason::ProtocolError, Some(err.clone()));
            }
        }
    });
}

async fn run_http3_stream_reader(
    stats: Option<Arc<HttpConnectionStats>>,
    state: Arc<StreamingBodyState>,
    connection: Arc<QuinnConnection>,
    mut stream: H3ServerRecvStream,
    max_body: u64,
    mut bytes_read: u64,
    content_length: Option<u64>,
    idle_timeout: Duration,
    total_timeout: Duration,
) -> Result<(), String> {
    let total_deadline = Instant::now() + total_timeout;
    loop {
        if state.finish_requested() {
            state.mark_finished();
            return Ok(());
        }
        if Instant::now() >= total_deadline {
            if let Some(stats_ref) = stats.as_ref() {
                stats_ref.record_body_timeout(Some("http/3 body total timeout".into()));
                stats_ref.record_goaway(Some("http/3 body total timeout".into()));
            }
            state.mark_error("http/3 body total timeout exceeded".into());
            connection.close(VarInt::from_u32(0), b"http/3 body total timeout exceeded");
            return Err("http/3 body total timeout".into());
        }
        let recv_future = stream.recv_data();
        let chunk = match time::timeout(idle_timeout, recv_future).await {
            Ok(value) => value,
            Err(_) => {
                if let Some(stats_ref) = stats.as_ref() {
                    stats_ref.record_idle_timeout(Some("http/3 body idle timeout".into()));
                    stats_ref.record_goaway(Some("http/3 body idle timeout".into()));
                }
                state.mark_error("http/3 body idle timeout".into());
                connection.close(VarInt::from_u32(0), b"http/3 body idle timeout");
                return Err("http/3 body idle timeout".into());
            }
        };
        match chunk {
            Ok(Some(mut chunk)) => {
                while chunk.has_remaining() {
                    let len = chunk.remaining();
                    let bytes = chunk.copy_to_bytes(len);
                    bytes_read += len as u64;
                    if bytes_read > max_body
                        || content_length
                            .map(|limit| bytes_read > limit)
                            .unwrap_or(false)
                    {
                        state.mark_error("http/3 body exceeded configured limit".into());
                        return Ok(());
                    }
                    if content_length.is_none() {
                        state.extend_total_len(len);
                    }
                    if !state.finish_requested() {
                        state.enqueue_bytes(bytes);
                    }
                }
            }
            Ok(None) => {
                if let Some(expected) = content_length {
                    if bytes_read != expected {
                        state.mark_error("http/3 body ended before declared Content-Length".into());
                        return Ok(());
                    }
                }
                state.mark_finished();
                return Ok(());
            }
            Err(err) => {
                if let Some(stats_ref) = stats.as_ref() {
                    stats_ref.set_close_reason(
                        HttpConnectionCloseReason::ProtocolError,
                        Some(format!("http/3 body read failed: {}", err)),
                    );
                }
                // `h3-quinn` keeps the underlying recv stream inside an in-flight
                // future while `recv_data()` is being polled. Calling
                // `stop_sending()` on every shutdown path can therefore panic
                // under load if the stream is dropped mid-poll. Marking the body
                // state and letting the request stream drop avoids the panic while
                // preserving timeout/connection-close handling above.
                state.mark_error(format!("http/3 body read failed: {}", err));
                return Err(err.to_string());
            }
        }
    }
}
#[allow(dead_code)]
fn http_summary_from_handshake(
    handshake: &protocol::HttpHandshake,
    route: &config::HttpRouteResolution,
) -> HttpRequestSummary {
    let (path, query) = protocol::split_http_target(&handshake.request.target);
    let normalized_path = if path.is_empty() { "/" } else { path };
    let body_handle = match &handshake.body {
        HttpBodyPhase::Buffered(bytes) => HttpBodyHandle::from_inline(bytes.clone()),
        HttpBodyPhase::Finished => HttpBodyHandle::empty(),
        HttpBodyPhase::NeedsStreaming { .. } => HttpBodyHandle::empty(),
    };
    HttpRequestSummary::new(
        handshake.request.method.clone(),
        handshake.request.target.clone(),
        normalized_path.to_string(),
        query.map(|value| value.to_string()),
        format!("http/1.{}", handshake.request.version),
        handshake.request.version,
        handshake
            .request
            .headers
            .iter()
            .map(|(name, value)| {
                (
                    http_bytes_from_slice(name.as_bytes()),
                    http_bytes_from_slice(value.as_bytes()),
                )
            })
            .collect(),
        body_handle,
        Some(route.realm.clone()),
        Some(route.procedure.clone()),
        Some(route.clone()),
    )
}

async fn send_http3_plain_response(
    stream: &mut H3ServerSendStream,
    status: StatusCode,
    body: &[u8],
    headers: &[(&str, &str)],
) -> Result<(), String> {
    let mut builder = HttpResponse::builder().status(status);
    {
        let header_map = builder.headers_mut().expect("headers available");
        for (name, value) in headers {
            if let (Ok(name), Ok(value)) = (
                HeaderName::from_bytes(name.as_bytes()),
                HeaderValue::from_str(value),
            ) {
                header_map.append(name, value);
            }
        }
        if let Ok(len_value) = HeaderValue::from_str(&body.len().to_string()) {
            header_map.insert(CONTENT_LENGTH, len_value);
        }
    }
    let response = builder.body(()).map_err(|err| err.to_string())?;
    stream
        .send_response(response)
        .await
        .map_err(|err| err.to_string())?;
    if !body.is_empty() {
        stream
            .send_data(Bytes::copy_from_slice(body))
            .await
            .map_err(|err| err.to_string())?;
    }
    stream.finish().await.map_err(|err| err.to_string())?;
    Ok(())
}

async fn send_http3_response_from_dispatch(
    stream: &mut H3ServerSendStream,
    dispatch: HttpResponseDispatch,
) -> Result<(), String> {
    let HttpResponseDispatch {
        status,
        mut headers,
        body,
    } = dispatch;
    let clamped = status.clamp(100, 599) as u16;
    let status_code = StatusCode::from_u16(clamped).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    match body {
        HttpResponseBody::Buffered(body_bytes) => {
            let mut builder = HttpResponse::builder().status(status_code);
            {
                let header_map = builder.headers_mut().expect("headers available");
                for (name, value) in &headers {
                    if let (Ok(name), Ok(value)) = (
                        HeaderName::from_bytes(name.as_bytes()),
                        HeaderValue::from_str(value),
                    ) {
                        header_map.append(name, value);
                    }
                }
                if let Ok(len_value) = HeaderValue::from_str(&body_bytes.len().to_string()) {
                    header_map.insert(CONTENT_LENGTH, len_value);
                }
            }
            let response = builder.body(()).map_err(|err| err.to_string())?;
            stream
                .send_response(response)
                .await
                .map_err(|err| err.to_string())?;
            if !body_bytes.is_empty() {
                stream
                    .send_data(Bytes::from(body_bytes))
                    .await
                    .map_err(|err| err.to_string())?;
            }
            stream.finish().await.map_err(|err| err.to_string())
        }
        HttpResponseBody::Streaming(mut reader) => {
            http_response_stream_metrics().record_streaming_response();
            strip_content_length(&mut headers);
            let mut builder = HttpResponse::builder().status(status_code);
            {
                let header_map = builder.headers_mut().expect("headers available");
                for (name, value) in &headers {
                    if let (Ok(name), Ok(value)) = (
                        HeaderName::from_bytes(name.as_bytes()),
                        HeaderValue::from_str(value),
                    ) {
                        header_map.append(name, value);
                    }
                }
            }
            let response = builder.body(()).map_err(|err| err.to_string())?;
            let stream_opened_at = reader.opened_at();
            let headers_send_call_started_at = Instant::now();
            stream
                .send_response(response)
                .await
                .map_err(|err| err.to_string())?;
            let headers_sent_at = Instant::now();
            http_response_stream_metrics().record_headers_sent(
                stream_opened_at,
                headers_send_call_started_at,
                headers_sent_at,
            );
            let mut first_chunk_sent_at = None;
            let mut last_chunk_sent_at = None;
            let mut tail_chunk_recorded = false;
            loop {
                match reader.next().await {
                    Ok(ResponseStreamFrame::Chunk { bytes, queued_at }) => {
                        let send_call_started_at = Instant::now();
                        stream
                            .send_data(bytes)
                            .await
                            .map_err(|err| err.to_string())?;
                        let send_call_finished_at = Instant::now();
                        last_chunk_sent_at = Some(send_call_finished_at);
                        if first_chunk_sent_at.is_none() {
                            http_response_stream_metrics().record_first_chunk(
                                queued_at,
                                headers_sent_at,
                                send_call_started_at,
                                send_call_started_at,
                                send_call_finished_at,
                            );
                            first_chunk_sent_at = Some(send_call_finished_at);
                        } else {
                            http_response_stream_metrics().record_tail_chunk(
                                queued_at,
                                send_call_started_at,
                                send_call_started_at,
                                send_call_finished_at,
                            );
                            tail_chunk_recorded = true;
                        }
                    }
                    Ok(ResponseStreamFrame::Finished { .. }) => {
                        if tail_chunk_recorded {
                            if let (Some(first_sent_at), Some(last_sent_at)) =
                                (first_chunk_sent_at, last_chunk_sent_at)
                            {
                                http_response_stream_metrics()
                                    .record_first_to_last_chunk_send(first_sent_at, last_sent_at);
                            }
                        }
                        reader.close();
                        return stream.finish().await.map_err(|err| err.to_string());
                    }
                    Err(err) => {
                        reader.close();
                        return Err(format!("http/3 streaming response failed: {}", err));
                    }
                }
            }
        }
    }
}

fn resolve_socket_addr(addr: &str, port: u16) -> Result<SocketAddr, Error> {
    let mut addrs = (addr, port)
        .to_socket_addrs()
        .map_err(|_| Error::AddressResolution(addr.to_string(), port))?;
    addrs
        .next()
        .ok_or_else(|| Error::AddressResolution(addr.to_string(), port))
}

fn create_listener(
    addr: SocketAddr,
    backlog: u32,
) -> Result<std::net::TcpListener, std::io::Error> {
    use socket2::{Domain, Socket, Type};

    let domain = if addr.is_ipv4() {
        Domain::IPV4
    } else {
        Domain::IPV6
    };
    let socket = Socket::new(domain, Type::STREAM, None)?;
    socket.set_reuse_address(true)?;
    socket.bind(&addr.into())?;
    socket.listen(backlog as i32)?;
    socket.set_nonblocking(true)?;
    Ok(socket.into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use rcgen::{
        BasicConstraints, CertificateParams, ExtendedKeyUsagePurpose, IsCa, KeyPair,
        KeyUsagePurpose,
    };
    use rustls::{pki_types::ServerName, ClientConfig as RustlsClientConfig};
    use rustls_pemfile::pkcs8_private_keys;
    use serde_json::json;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::sync::mpsc::error::TryRecvError;
    use tokio_rustls::TlsConnector;

    #[test]
    fn mqtt_inbound_chunks_fit_legacy_and_large_poll_buffers() {
        let (sender, receiver) = mpsc::channel(2);
        let payload: Vec<u8> = (0..64 * 1024).map(|index| (index / 251) as u8).collect();
        sender.try_send(Bytes::copy_from_slice(&payload)).unwrap();
        let mut inbound = MqttInbound::new(receiver);
        let mut received = Vec::new();
        for _ in 0..4 {
            let chunk = inbound.try_recv_limited(16 * 1024).unwrap();
            assert_eq!(chunk.len(), 16 * 1024);
            received.extend_from_slice(&chunk);
        }
        assert_eq!(received, payload);
        assert!(inbound.pending.is_none());
        assert!(matches!(
            inbound.try_recv_limited(16 * 1024),
            Err(TryRecvError::Empty)
        ));

        sender.try_send(Bytes::copy_from_slice(&payload)).unwrap();
        assert_eq!(
            inbound.try_recv_limited(64 * 1024).unwrap(),
            Bytes::copy_from_slice(&payload)
        );
        assert!(inbound.pending.is_none());
    }

    #[test]
    fn mqtt_registry_apis_reject_a_non_mqtt_connection() {
        assert_eq!(protocol_sort_key(ConnectionProtocol::Mqtt), 5);
        let registry = ListenerRegistry::default();
        let connection_id = ConnectionId(42);
        registry.connections.lock().unwrap().insert(
            connection_id,
            ConnectionEntry {
                listener_id: ListenerId(1),
                peer_addr: "127.0.0.1:12345".parse().unwrap(),
                protocol: ConnectionProtocol::Http,
                websocket_protocol: None,
                endpoint_config: Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Http,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                stats: None,
                record: ConnectionRecord::HttpPending {
                    pending_requests: Mutex::new(VecDeque::new()),
                },
            },
        );
        for result in [
            registry.mqtt_version(connection_id).map(|_| ()),
            registry.set_mqtt_wakeup(connection_id, None),
            registry.poll_mqtt_chunk(connection_id, 64).map(|_| ()),
            registry.enqueue_mqtt_chunk(connection_id, Bytes::from_static(b"x")),
        ] {
            assert!(matches!(
                result,
                Err(Error::UnsupportedProtocol(id, ConnectionProtocol::Http)) if id == connection_id
            ));
        }
    }

    #[tokio::test]
    async fn mqtt_registry_shutdown_clears_wakeup_and_aborts_both_tasks() {
        extern "C" fn wakeup(_: i32) {}

        let registry = ListenerRegistry::default();
        let connection_id = ConnectionId(43);
        let reader = tokio::spawn(std::future::pending::<()>());
        let writer = tokio::spawn(std::future::pending::<()>());
        let (chunk_tx, chunk_rx) = mpsc::channel(1);
        let (outbound, _outbound_rx) = MqttOutboundQueue::new(1);
        let wakeup = Arc::new(Mutex::new(Some(wakeup as extern "C" fn(i32))));
        registry.connections.lock().unwrap().insert(
            connection_id,
            ConnectionEntry {
                listener_id: ListenerId(1),
                peer_addr: "127.0.0.1:12345".parse().unwrap(),
                protocol: ConnectionProtocol::Mqtt,
                websocket_protocol: None,
                endpoint_config: Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                stats: None,
                record: ConnectionRecord::Mqtt {
                    version: 5,
                    chunks: Arc::new(Mutex::new(MqttInbound::new(chunk_rx))),
                    notification_pending: Arc::new(AtomicBool::new(true)),
                    outbound,
                    wakeup: Arc::clone(&wakeup),
                    reader_abort: reader.abort_handle(),
                    writer_abort: writer.abort_handle(),
                },
            },
        );
        let _producer = chunk_tx;

        registry.shutdown();

        assert!(wakeup.lock().unwrap().is_none());
        assert!(registry.connections.lock().unwrap().is_empty());
        assert!(time::timeout(Duration::from_secs(5), reader)
            .await
            .unwrap()
            .unwrap_err()
            .is_cancelled());
        assert!(time::timeout(Duration::from_secs(5), writer)
            .await
            .unwrap()
            .unwrap_err()
            .is_cancelled());
    }

    #[tokio::test]
    async fn mqtt_tcp_reader_notifies_registered_wakeup_for_inbound_bytes() {
        static WAKEUP_COUNT: AtomicU64 = AtomicU64::new(0);
        extern "C" fn wakeup(_: i32) {
            WAKEUP_COUNT.fetch_add(1, Ordering::AcqRel);
        }

        WAKEUP_COUNT.store(0, Ordering::Release);
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (server, peer_addr) = listener.accept().await.unwrap();
        let registry = Arc::new(ListenerRegistry::default());
        let connection_id = ConnectionId(45);
        Arc::clone(&registry)
            .register_mqtt_stream_connection(
                tokio::runtime::Handle::current(),
                ListenerId(1),
                connection_id,
                Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                IoStream::plain(server),
                5,
                peer_addr,
                false,
            )
            .unwrap();
        registry
            .set_mqtt_wakeup(connection_id, Some(wakeup))
            .unwrap();

        client.write_all(b"inbound").await.unwrap();
        time::timeout(Duration::from_secs(5), async {
            while WAKEUP_COUNT.load(Ordering::Acquire) == 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap();
        assert_eq!(WAKEUP_COUNT.load(Ordering::Acquire), 1);
        assert_eq!(
            registry.poll_mqtt_chunk(connection_id, 64).unwrap(),
            Some(Bytes::from_static(b"inbound"))
        );
        registry.shutdown();
    }

    #[tokio::test]
    async fn websocket_reader_closes_when_no_frame_arrives_before_idle_timeout() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(server));
        let mut endpoint = build_client_endpoint_config(
            "127.0.0.1",
            0,
            false,
            TransportProtocol::Websocket,
            config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            None,
            None,
        );
        endpoint.idle_timeout = Some(Duration::from_millis(20));
        let (frame_tx, _frame_rx) = mpsc::channel(1);
        let (send_tx, _send_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_websocket_reader(
            tokio::runtime::Handle::current(),
            ConnectionId(46),
            rawsocket::Serializer::Json,
            Arc::new(endpoint),
            reader,
            frame_tx,
            send_tx,
            None,
            close_tx,
            true,
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderClosed)
        );
        reader_abort.abort();
        drop(client);
    }

    #[tokio::test]
    async fn websocket_reader_handles_frame_before_idle_timeout() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (server, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(server));
        let mut endpoint = build_client_endpoint_config(
            "127.0.0.1",
            0,
            false,
            TransportProtocol::Websocket,
            config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            None,
            None,
        );
        endpoint.idle_timeout = Some(Duration::from_secs(1));
        let (frame_tx, _frame_rx) = mpsc::channel(1);
        let (send_tx, mut send_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_websocket_reader(
            tokio::runtime::Handle::current(),
            ConnectionId(49),
            rawsocket::Serializer::Json,
            Arc::new(endpoint),
            reader,
            frame_tx,
            send_tx,
            None,
            close_tx,
            true,
        );
        client.write_all(&[0x88, 0x80, 1, 2, 3, 4]).await.unwrap();
        assert!(time::timeout(Duration::from_secs(5), send_rx.recv())
            .await
            .unwrap()
            .is_some());
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderGracefulClose)
        );
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_tcp_reader_stops_when_inbound_receiver_is_dropped() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (server, peer_addr) = listener.accept().await.unwrap();
        let registry = Arc::new(ListenerRegistry::default());
        let connection_id = ConnectionId(47);
        Arc::clone(&registry)
            .register_mqtt_stream_connection(
                tokio::runtime::Handle::current(),
                ListenerId(1),
                connection_id,
                Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                IoStream::plain(server),
                5,
                peer_addr,
                false,
            )
            .unwrap();
        let entry = registry
            .connections
            .lock()
            .unwrap()
            .remove(&connection_id)
            .unwrap();
        let reader_abort = match &entry.record {
            ConnectionRecord::Mqtt { reader_abort, .. } => reader_abort.clone(),
            _ => unreachable!(),
        };
        drop(entry);
        client.write_all(b"receiver dropped").await.unwrap();
        time::timeout(Duration::from_secs(5), async {
            while !reader_abort.is_finished() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap();
        registry.shutdown();
    }

    #[tokio::test]
    async fn mqtt_registry_reports_no_chunk_after_inbound_disconnect() {
        let registry = ListenerRegistry::default();
        let connection_id = ConnectionId(44);
        let (chunk_tx, chunk_rx) = mpsc::channel(1);
        drop(chunk_tx);
        let (outbound, _outbound_rx) = MqttOutboundQueue::new(1);
        let reader = tokio::spawn(std::future::pending::<()>());
        let writer = tokio::spawn(std::future::pending::<()>());
        registry.connections.lock().unwrap().insert(
            connection_id,
            ConnectionEntry {
                listener_id: ListenerId(1),
                peer_addr: "127.0.0.1:12345".parse().unwrap(),
                protocol: ConnectionProtocol::Mqtt,
                websocket_protocol: None,
                endpoint_config: Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                stats: None,
                record: ConnectionRecord::Mqtt {
                    version: 5,
                    chunks: Arc::new(Mutex::new(MqttInbound::new(chunk_rx))),
                    notification_pending: Arc::new(AtomicBool::new(true)),
                    outbound,
                    wakeup: Arc::new(Mutex::new(None)),
                    reader_abort: reader.abort_handle(),
                    writer_abort: writer.abort_handle(),
                },
            },
        );

        assert!(registry
            .poll_mqtt_chunk(connection_id, 64)
            .unwrap()
            .is_none());
        registry.shutdown();
        assert!(time::timeout(Duration::from_secs(5), reader)
            .await
            .unwrap()
            .unwrap_err()
            .is_cancelled());
        assert!(time::timeout(Duration::from_secs(5), writer)
            .await
            .unwrap()
            .unwrap_err()
            .is_cancelled());
    }

    #[test]
    fn mqtt_inbound_coalesces_queued_small_chunks_with_bounded_pending_tail() {
        let (sender, receiver) = mpsc::channel(4);
        sender.try_send(Bytes::from_static(b"ab")).unwrap();
        sender.try_send(Bytes::from_static(b"cdef")).unwrap();
        sender.try_send(Bytes::from_static(b"gh")).unwrap();
        drop(sender);

        let mut inbound = MqttInbound::new(receiver);
        assert_eq!(
            inbound.try_recv_limited(5).unwrap(),
            Bytes::from_static(b"abcde")
        );
        assert_eq!(inbound.pending.as_ref().unwrap(), &Bytes::from_static(b"f"));
        assert_eq!(
            inbound.try_recv_limited(5).unwrap(),
            Bytes::from_static(b"fgh")
        );
        assert!(inbound.pending.is_none());
        assert!(matches!(
            inbound.try_recv_limited(5),
            Err(TryRecvError::Disconnected)
        ));
    }

    #[test]
    fn mqtt_empty_poll_rechecks_chunk_sent_after_wake_reset() {
        let (sender, receiver) = mpsc::channel(1);
        let mut inbound = MqttInbound::new(receiver);
        let notification_pending = AtomicBool::new(true);
        let bytes = inbound.poll_with_wake_reset(64, &notification_pending, || {
            sender
                .try_send(Bytes::from_static(b"racing chunk"))
                .unwrap();
        });
        assert_eq!(bytes, Some(Bytes::from_static(b"racing chunk")));
        assert!(!notification_pending.load(Ordering::Acquire));
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_buffers_many_masked_frames_in_order() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let (start_tx, start_rx) = oneshot::channel();
        let server = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            start_rx.await.unwrap();
            let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
            let (chunk_tx, mut chunk_rx) = mpsc::channel(32);
            let (control_tx, mut control_rx) = mpsc::channel(4);
            let (close_tx, mut close_rx) = mpsc::unbounded_channel();
            let reader_abort = spawn_mqtt_websocket_reader(
                tokio::runtime::Handle::current(),
                true,
                ConnectionId(17),
                reader,
                chunk_tx,
                Arc::new(AtomicBool::new(false)),
                Arc::new(Mutex::new(None)),
                control_tx,
                close_tx,
            );
            let mut received = Vec::with_capacity(300 * 64);
            let mut chunk_count = 0;
            while received.len() < 300 * 64 {
                let chunk = time::timeout(Duration::from_secs(5), chunk_rx.recv())
                    .await
                    .unwrap()
                    .unwrap();
                received.extend_from_slice(&chunk);
                chunk_count += 1;
            }
            assert!(
                chunk_count <= 4,
                "expected buffered WS frames, got {chunk_count} chunks"
            );
            for index in 0..300u16 {
                let mut expected = vec![index as u8; 64];
                expected[..2].copy_from_slice(&index.to_be_bytes());
                let start = index as usize * 64;
                assert_eq!(&received[start..start + 64], expected);
            }
            assert_eq!(
                time::timeout(Duration::from_secs(5), close_rx.recv())
                    .await
                    .unwrap(),
                Some(ConnectionTaskSignal::ReaderClosed)
            );
            assert!(control_rx.try_recv().is_err());
            reader_abort.abort();
        });

        let mut wire = Vec::new();
        let mask = [0x11, 0x22, 0x33, 0x44];
        for index in 0..300u16 {
            let mut payload = vec![index as u8; 64];
            payload[..2].copy_from_slice(&index.to_be_bytes());
            wire.extend_from_slice(&[0x82, 0xc0]);
            wire.extend_from_slice(&mask);
            wire.extend(
                payload
                    .iter()
                    .enumerate()
                    .map(|(offset, byte)| byte ^ mask[offset & 3]),
            );
        }
        assert!(wire.len() > 16 * 1024);
        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        client.write_all(&wire).await.unwrap();
        client.shutdown().await.unwrap();
        start_tx.send(()).unwrap();
        server.await.unwrap();
    }

    #[tokio::test]
    async fn mqtt_websocket_ready_yield_coalesces_input_after_one_pending_poll() {
        struct ReadyAfterPending {
            wire: Vec<u8>,
            offset: usize,
            first_chunk_end: usize,
            pending_once: bool,
        }
        impl AsyncRead for ReadyAfterPending {
            fn poll_read(
                self: std::pin::Pin<&mut Self>,
                cx: &mut std::task::Context<'_>,
                buffer: &mut tokio::io::ReadBuf<'_>,
            ) -> Poll<std::io::Result<()>> {
                let reader = self.get_mut();
                if reader.offset == reader.first_chunk_end && !reader.pending_once {
                    reader.pending_once = true;
                    cx.waker().wake_by_ref();
                    return Poll::Pending;
                }
                let limit = if reader.pending_once {
                    reader.wire.len()
                } else {
                    reader.first_chunk_end
                };
                let end = (reader.offset + buffer.remaining()).min(limit);
                buffer.put_slice(&reader.wire[reader.offset..end]);
                reader.offset = end;
                Poll::Ready(Ok(()))
            }
        }
        for payload_size in [3, 128, 65536] {
            let prefix_limit = match payload_size {
                3 => 8,
                128 => 10,
                _ => 16,
            };
            for prefix in 0..=prefix_limit {
                let mut wire = masked_mqtt_websocket_test_frame(2, true, b"abc");
                wire.extend(masked_mqtt_websocket_test_frame(2, true, b"def"));
                let first_chunk_end = wire.len() + prefix;
                let payload = vec![b'x'; payload_size];
                wire.extend(masked_mqtt_websocket_test_frame(2, true, &payload));
                let mut expected = b"abcdef".to_vec();
                expected.extend_from_slice(&payload);
                let (chunk_tx, mut chunk_rx) = mpsc::channel(4);
                let (control_tx, mut control_rx) = mpsc::channel(4);
                let (close_tx, mut close_rx) = mpsc::unbounded_channel();
                let reader_abort = spawn_mqtt_websocket_reader(
                    tokio::runtime::Handle::current(),
                    true,
                    ConnectionId(193),
                    ReadyAfterPending {
                        wire,
                        offset: 0,
                        first_chunk_end,
                        pending_once: false,
                    },
                    chunk_tx,
                    Arc::new(AtomicBool::new(false)),
                    Arc::new(Mutex::new(None)),
                    control_tx,
                    close_tx,
                );
                let first = chunk_rx.recv().await.unwrap();
                assert_eq!(first.len(), expected.len().min(64 * 1024));
                let mut received = first.to_vec();
                while received.len() < expected.len() {
                    received.extend_from_slice(&chunk_rx.recv().await.unwrap());
                }
                assert_eq!(received, expected);
                assert_eq!(
                    close_rx.recv().await,
                    Some(ConnectionTaskSignal::ReaderClosed)
                );
                assert!(chunk_rx.try_recv().is_err());
                assert!(control_rx.try_recv().is_err());
                reader_abort.abort();
            }
        }
    }

    #[tokio::test(start_paused = true)]
    async fn mqtt_websocket_ready_yield_preserves_partial_next_frame() {
        for coalesce_bursts in [false, true] {
            for prefix in [0, 1, 2, 4, 7, 8] {
                let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
                let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
                    .await
                    .unwrap();
                let (stream, _) = listener.accept().await.unwrap();
                let next = masked_mqtt_websocket_test_frame(2, true, b"xyz");
                let mut wire = masked_mqtt_websocket_test_frame(2, true, b"abc");
                wire.extend(masked_mqtt_websocket_test_frame(2, true, b"def"));
                wire.extend_from_slice(&next[..prefix]);
                let mut stream = IoStream::plain(stream);
                stream.buffer_front(&wire);
                let (reader, _writer) = tokio::io::split(stream);
                let (chunk_tx, mut chunk_rx) = mpsc::channel(4);
                let (control_tx, mut control_rx) = mpsc::channel(4);
                let (close_tx, mut close_rx) = mpsc::unbounded_channel();
                let started = time::Instant::now();
                let reader_abort = spawn_mqtt_websocket_reader(
                    tokio::runtime::Handle::current(),
                    coalesce_bursts,
                    ConnectionId(191),
                    reader,
                    chunk_tx,
                    Arc::new(AtomicBool::new(false)),
                    Arc::new(Mutex::new(None)),
                    control_tx,
                    close_tx,
                );
                tokio::task::yield_now().await;
                assert_eq!(time::Instant::now(), started);
                let first = if coalesce_bursts {
                    let mut first = None;
                    for _ in 0..4 {
                        tokio::task::yield_now().await;
                        if let Ok(chunk) = chunk_rx.try_recv() {
                            first = Some(chunk);
                            break;
                        }
                    }
                    first.expect("ready batch must not require advancing the timer")
                } else {
                    chunk_rx
                        .try_recv()
                        .expect("non-burst policy must flush immediately")
                };
                assert_eq!(time::Instant::now(), started);
                assert_eq!(first.as_ref(), b"abcdef");
                client.write_all(&next[prefix..]).await.unwrap();
                client.shutdown().await.unwrap();
                assert_eq!(chunk_rx.recv().await.unwrap().as_ref(), b"xyz");
                assert_eq!(
                    close_rx.recv().await,
                    Some(ConnectionTaskSignal::ReaderClosed)
                );
                assert!(control_rx.try_recv().is_err());
                reader_abort.abort();
            }
        }
    }

    #[tokio::test(start_paused = true)]
    async fn mqtt_websocket_ready_yield_stops_when_consumer_closes() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let _client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let mut wire = masked_mqtt_websocket_test_frame(2, true, b"abc");
        wire.extend(masked_mqtt_websocket_test_frame(2, true, b"def"));
        let mut stream = IoStream::plain(stream);
        stream.buffer_front(&wire);
        let (reader, _writer) = tokio::io::split(stream);
        let (chunk_tx, chunk_rx) = mpsc::channel(1);
        drop(chunk_rx);
        let (control_tx, mut control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(192),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        let started = time::Instant::now();
        for _ in 0..4 {
            tokio::task::yield_now().await;
        }
        assert_eq!(
            close_rx.try_recv().unwrap(),
            ConnectionTaskSignal::ReaderClosed
        );
        assert_eq!(time::Instant::now(), started);
        assert!(control_rx.try_recv().is_err());
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_flushes_before_partial_next_frame() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, mut chunk_rx) = mpsc::channel(4);
        let (control_tx, mut control_rx) = mpsc::channel(4);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(18),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        client
            .write_all(&[
                0x82,
                0x83,
                1,
                2,
                3,
                4,
                b'a' ^ 1,
                b'b' ^ 2,
                b'c' ^ 3,
                0x82,
                0x83,
                1,
                2,
                3,
                4,
                b'x' ^ 1,
            ])
            .await
            .unwrap();
        let first = time::timeout(Duration::from_secs(2), chunk_rx.recv())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(first.as_ref(), b"abc");
        client.write_all(&[b'y' ^ 2, b'z' ^ 3]).await.unwrap();
        client.shutdown().await.unwrap();
        let second = time::timeout(Duration::from_secs(2), chunk_rx.recv())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(second.as_ref(), b"xyz");
        assert_eq!(
            time::timeout(Duration::from_secs(2), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderClosed)
        );
        assert!(control_rx.try_recv().is_err());
        reader_abort.abort();
    }

    fn masked_mqtt_websocket_test_frame(opcode: u8, fin: bool, payload: &[u8]) -> Vec<u8> {
        let mut wire = Vec::new();
        wire.push(opcode | if fin { 0x80 } else { 0 });
        match payload.len() {
            0..=125 => wire.push(0x80 | payload.len() as u8),
            126..=65535 => {
                wire.push(0xfe);
                wire.extend_from_slice(&(payload.len() as u16).to_be_bytes());
            }
            _ => {
                wire.push(0xff);
                wire.extend_from_slice(&(payload.len() as u64).to_be_bytes());
            }
        }
        let mask = [1, 2, 3, 4];
        wire.extend_from_slice(&mask);
        wire.extend(
            payload
                .iter()
                .enumerate()
                .map(|(index, byte)| byte ^ mask[index & 3]),
        );
        wire
    }

    #[test]
    fn mqtt_websocket_read_ahead_recognizes_complete_and_partial_headers() {
        assert!(!websocket_buffer_contains_complete_frame(&[]));
        assert!(!websocket_buffer_contains_complete_frame(&[0x82]));
        let small = masked_mqtt_websocket_test_frame(0x2, true, b"abc");
        assert!(!websocket_buffer_contains_complete_frame(&small[..5]));
        assert!(!websocket_buffer_contains_complete_frame(&small[..8]));
        assert!(websocket_buffer_contains_complete_frame(&small));
        let medium = masked_mqtt_websocket_test_frame(0x2, true, &[0x41; 126]);
        assert!(!websocket_buffer_contains_complete_frame(&medium[..7]));
        assert!(!websocket_buffer_contains_complete_frame(
            &medium[..medium.len() - 1]
        ));
        assert!(websocket_buffer_contains_complete_frame(&medium));
        let large = masked_mqtt_websocket_test_frame(0x2, true, &[0x42; 65536]);
        assert!(!websocket_buffer_contains_complete_frame(&large[..13]));
        assert!(!websocket_buffer_contains_complete_frame(
            &large[..large.len() - 1]
        ));
        assert!(websocket_buffer_contains_complete_frame(&large));
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_preserves_large_masked_frame_chunks() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, mut chunk_rx) = mpsc::channel(4);
        let (control_tx, mut control_rx) = mpsc::channel(4);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(20),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        let payload = (0..64 * 1024 + 17)
            .map(|index| (index % 251) as u8)
            .collect::<Vec<_>>();
        client
            .write_all(&masked_mqtt_websocket_test_frame(0x2, true, &payload))
            .await
            .unwrap();
        client.shutdown().await.unwrap();
        let first = time::timeout(Duration::from_secs(5), chunk_rx.recv())
            .await
            .unwrap()
            .unwrap();
        let second = time::timeout(Duration::from_secs(5), chunk_rx.recv())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(first.as_ref(), &payload[..64 * 1024]);
        assert_eq!(second.as_ref(), &payload[64 * 1024..]);
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderClosed)
        );
        assert!(control_rx.try_recv().is_err());
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_stops_when_its_bounded_inbound_queue_closes() {
        let small = masked_mqtt_websocket_test_frame(0x2, true, b"abc");
        let mut malformed = small.clone();
        malformed.extend_from_slice(&[0x82, 0x00]);
        let mut ping = small.clone();
        ping.extend(masked_mqtt_websocket_test_frame(0x9, true, b"p"));
        let mut continuation = small.clone();
        continuation.extend(masked_mqtt_websocket_test_frame(0x0, true, b"x"));
        let large = masked_mqtt_websocket_test_frame(0x2, true, &[0x43; 65536]);
        let mut fragmented = Vec::new();
        for index in 0..4 {
            fragmented.extend(masked_mqtt_websocket_test_frame(
                if index == 0 { 0x2 } else { 0x0 },
                index == 3,
                &[0x44; 16384],
            ));
        }
        for wire in [malformed, ping, continuation, small, large, fragmented] {
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
                .await
                .unwrap();
            let (stream, _) = listener.accept().await.unwrap();
            client.write_all(&wire).await.unwrap();
            client.shutdown().await.unwrap();
            let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
            let (chunk_tx, chunk_rx) = mpsc::channel(1);
            drop(chunk_rx);
            let (control_tx, _control_rx) = mpsc::channel(4);
            let (close_tx, mut close_rx) = mpsc::unbounded_channel();
            let reader_abort = spawn_mqtt_websocket_reader(
                tokio::runtime::Handle::current(),
                true,
                ConnectionId(19),
                reader,
                chunk_tx,
                Arc::new(AtomicBool::new(false)),
                Arc::new(Mutex::new(None)),
                control_tx,
                close_tx,
            );
            assert_eq!(
                time::timeout(Duration::from_secs(5), close_rx.recv())
                    .await
                    .unwrap(),
                Some(ConnectionTaskSignal::ReaderClosed)
            );
            reader_abort.abort();
        }
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_routes_ping_and_echoes_coded_close() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, mut chunk_rx) = mpsc::channel(1);
        let (control_tx, mut control_rx) = mpsc::channel(4);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(20),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        let mut wire = masked_mqtt_websocket_test_frame(0x9, true, b"hi");
        wire.extend(masked_mqtt_websocket_test_frame(0xA, true, b"ignored"));
        wire.extend(masked_mqtt_websocket_test_frame(
            0x8,
            true,
            &[0x03, 0xe8, b'b', b'y', b'e'],
        ));
        client.write_all(&wire).await.unwrap();
        client.shutdown().await.unwrap();

        assert_eq!(
            time::timeout(Duration::from_secs(5), control_rx.recv())
                .await
                .unwrap(),
            Some((0xA, Bytes::from_static(b"hi")))
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), control_rx.recv())
                .await
                .unwrap(),
            Some((0x8, Bytes::from_static(&[0x03, 0xe8, b'b', b'y', b'e'])))
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderGracefulClose)
        );
        assert!(chunk_rx.try_recv().is_err());
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_stops_when_pong_channel_closes() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, _chunk_rx) = mpsc::channel(1);
        let (control_tx, control_rx) = mpsc::channel(1);
        drop(control_rx);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(21),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        client
            .write_all(&masked_mqtt_websocket_test_frame(0x9, true, b"hi"))
            .await
            .unwrap();
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderClosed)
        );
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_rejects_orphan_continuation_frame() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, mut chunk_rx) = mpsc::channel(1);
        let (control_tx, mut control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(48),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        client
            .write_all(&masked_mqtt_websocket_test_frame(0x0, true, b"orphan"))
            .await
            .unwrap();
        assert_eq!(
            time::timeout(Duration::from_secs(5), control_rx.recv())
                .await
                .unwrap(),
            Some((0x8, Bytes::from_static(&[0x03, 0xea])))
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderGracefulClose)
        );
        assert!(chunk_rx.try_recv().is_err());
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_reader_closes_on_truncated_frame_without_control_reply() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (reader, _writer) = tokio::io::split(IoStream::plain(stream));
        let (chunk_tx, _chunk_rx) = mpsc::channel(1);
        let (control_tx, mut control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let reader_abort = spawn_mqtt_websocket_reader(
            tokio::runtime::Handle::current(),
            true,
            ConnectionId(22),
            reader,
            chunk_tx,
            Arc::new(AtomicBool::new(false)),
            Arc::new(Mutex::new(None)),
            control_tx,
            close_tx,
        );
        client.write_all(&[0x82, 0x84, 0x11, 0x22]).await.unwrap();
        client.shutdown().await.unwrap();
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::ReaderClosed)
        );
        assert!(control_rx.try_recv().is_err());
        reader_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_writer_stops_after_both_queues_close() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let _client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (_reader, writer) = tokio::io::split(IoStream::plain(stream));
        let (outbound, send_rx) = MqttOutboundQueue::new(1);
        let (control_tx, control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let writer_abort = spawn_mqtt_websocket_writer(
            tokio::runtime::Handle::current(),
            writer,
            send_rx,
            control_rx,
            close_tx,
        );
        drop(control_tx);
        drop(outbound);
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::WriterClosed)
        );
        writer_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_tcp_writer_signals_close_when_the_peer_rejects_a_write() {
        let (writer, peer) = tokio::io::duplex(16);
        drop(peer);
        let (outbound, send_rx) = MqttOutboundQueue::new(1);
        outbound
            .enqueue(ConnectionId(46), Bytes::from_static(b"mqtt"))
            .unwrap();
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let writer_abort =
            spawn_mqtt_tcp_writer(tokio::runtime::Handle::current(), writer, send_rx, close_tx);
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::WriterClosed)
        );
        writer_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_writer_signals_close_when_the_peer_rejects_a_frame() {
        let (writer, peer) = tokio::io::duplex(16);
        drop(peer);
        let (outbound, send_rx) = MqttOutboundQueue::new(1);
        outbound
            .enqueue(ConnectionId(47), Bytes::from_static(b"mqtt"))
            .unwrap();
        let (control_tx, control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let writer_abort = spawn_mqtt_websocket_writer(
            tokio::runtime::Handle::current(),
            writer,
            send_rx,
            control_rx,
            close_tx,
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::WriterClosed)
        );
        drop(control_tx);
        writer_abort.abort();
    }

    #[tokio::test]
    async fn mqtt_websocket_writer_signals_close_when_flush_fails() {
        struct FailingFlushWriter;

        impl AsyncWrite for FailingFlushWriter {
            fn poll_write(
                self: Pin<&mut Self>,
                _: &mut Context<'_>,
                bytes: &[u8],
            ) -> Poll<io::Result<usize>> {
                Poll::Ready(Ok(bytes.len()))
            }

            fn poll_flush(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<io::Result<()>> {
                Poll::Ready(Err(io::Error::new(
                    io::ErrorKind::BrokenPipe,
                    "flush failed",
                )))
            }

            fn poll_shutdown(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<io::Result<()>> {
                Poll::Ready(Ok(()))
            }
        }

        let (outbound, send_rx) = MqttOutboundQueue::new(1);
        outbound
            .enqueue(ConnectionId(48), Bytes::from_static(b"mqtt"))
            .unwrap();
        let (_control_tx, control_rx) = mpsc::channel(1);
        let (close_tx, mut close_rx) = mpsc::unbounded_channel();
        let writer_abort = spawn_mqtt_websocket_writer(
            tokio::runtime::Handle::current(),
            FailingFlushWriter,
            send_rx,
            control_rx,
            close_tx,
        );
        assert_eq!(
            time::timeout(Duration::from_secs(5), close_rx.recv())
                .await
                .unwrap(),
            Some(ConnectionTaskSignal::WriterClosed)
        );
        writer_abort.abort();
    }

    fn test_guard() -> std::sync::MutexGuard<'static, ()> {
        static GUARD: OnceLock<Mutex<()>> = OnceLock::new();
        // Recover the guard after a prior test panic so one flaky runtime test
        // does not cascade into unrelated PoisonError failures.
        GUARD
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    async fn assert_accepted_connection(
        receiver: &mut mpsc::Receiver<ConnectionId>,
    ) -> ConnectionId {
        let received = tokio::time::timeout(Duration::from_secs(2), receiver.recv()).await;
        assert!(received.is_ok());
        let connection = received.unwrap();
        assert!(connection.is_some());
        connection.unwrap()
    }

    #[tokio::test]
    async fn accepted_connection_assertion_preserves_connection_identity() {
        let (sender, mut receiver) = mpsc::channel(1);
        assert!(sender.send(ConnectionId(42)).await.is_ok());
        assert_eq!(
            assert_accepted_connection(&mut receiver).await,
            ConnectionId(42)
        );
    }

    #[tokio::test]
    #[should_panic(expected = "assertion failed: connection.is_some()")]
    async fn accepted_connection_assertion_rejects_closed_channel() {
        let (sender, mut receiver) = mpsc::channel(1);
        drop(sender);
        assert_accepted_connection(&mut receiver).await;
    }

    #[tokio::test]
    #[should_panic(expected = "assertion failed: received.is_ok()")]
    async fn accepted_connection_assertion_bounds_idle_channel() {
        let (_sender, mut receiver) = mpsc::channel(1);
        assert_accepted_connection(&mut receiver).await;
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn deferred_segment_resolves_off_runtime_with_exact_length() {
        let runtime_thread = std::thread::current().id();
        let frame =
            OutboundFrame::message_deferred_segment(Bytes::from_static(b"prefix"), 7, move || {
                assert_ne!(std::thread::current().id(), runtime_thread);
                Ok(Bytes::from_static(b"payload"))
            })
            .unwrap();

        let resolved = resolve_deferred_segment(frame).await.unwrap();
        assert_eq!(resolved.payload_len, 13);
        assert_eq!(resolved.segments.len(), 2);
        assert_eq!(resolved.segments[0].as_ref(), b"prefix");
        assert_eq!(resolved.segments[1].as_ref(), b"payload");
        assert!(resolved.deferred_segment.is_none());
    }

    #[tokio::test]
    async fn deferred_segment_preserves_suffix_and_accounts_for_its_length() {
        let frame = OutboundFrame::message_deferred_segment_with_suffix(
            Bytes::from_static(b"prefix"),
            7,
            Bytes::from_static(b"suffix"),
            || Ok(Bytes::from_static(b"payload")),
        )
        .unwrap();

        let resolved = resolve_deferred_segment(frame).await.unwrap();
        assert_eq!(resolved.payload_len, 19);
        assert_eq!(resolved.segments[1].as_ref(), b"payload");
        assert_eq!(resolved.suffix_segments[0].as_ref(), b"suffix");
    }

    #[tokio::test]
    async fn deferred_segment_rejects_prepared_length_mismatch() {
        let frame =
            OutboundFrame::message_deferred_segment(Bytes::from_static(b"prefix"), 7, || {
                Ok(Bytes::from_static(b"short"))
            })
            .unwrap();

        let err = match resolve_deferred_segment(frame).await {
            Ok(_) => panic!("expected deferred length mismatch"),
            Err(err) => err,
        };
        assert!(err.contains("prepared payload length 11 did not match expected 13"));
    }

    #[tokio::test]
    async fn deferred_segment_propagates_preparation_error() {
        let frame =
            OutboundFrame::message_deferred_segment(Bytes::from_static(b"prefix"), 7, || {
                Err("encryption failed".to_string())
            })
            .unwrap();

        let err = match resolve_deferred_segment(frame).await {
            Ok(_) => panic!("expected deferred preparation error"),
            Err(err) => err,
        };
        assert_eq!(err, "encryption failed");
    }

    #[test]
    fn deferred_segment_rejects_payload_length_overflow() {
        let result =
            OutboundFrame::message_deferred_segment(Bytes::from_static(b"x"), usize::MAX, || {
                Ok(Bytes::new())
            });
        assert!(matches!(
            result,
            Err(Error::InvalidDeferredSegment("payload length overflow"))
        ));
    }

    #[tokio::test]
    async fn exact_frame_payload_read_handles_fragmented_input_without_padding() {
        let (mut writer, mut reader) = tokio::io::duplex(4);
        let write = tokio::spawn(async move {
            writer.write_all(b"abc").await.unwrap();
            writer.write_all(b"defghi").await.unwrap();
        });

        let payload = read_exact_frame_payload(&mut reader, 9).await.unwrap();
        write.await.unwrap();
        assert_eq!(payload.as_ref(), b"abcdefghi");
    }

    #[tokio::test]
    async fn exact_frame_payload_read_reports_truncated_input() {
        let (mut writer, mut reader) = tokio::io::duplex(4);
        writer.write_all(b"abc").await.unwrap();
        drop(writer);

        let error = read_exact_frame_payload(&mut reader, 4)
            .await
            .expect_err("truncated frame must fail");
        assert_eq!(error.kind(), io::ErrorKind::UnexpectedEof);
    }

    #[test]
    fn parse_runtime_worker_threads_defaults_to_auto() {
        assert_eq!(parse_runtime_worker_threads(None).unwrap(), None);
        assert_eq!(parse_runtime_worker_threads(Some("")).unwrap(), None);
        assert_eq!(parse_runtime_worker_threads(Some("   ")).unwrap(), None);
    }

    #[tokio::test]
    async fn mqtt_runtime_partial_startup_failure_cleans_up_inside_another_runtime() {
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .unwrap();
        let pending = runtime.handle().spawn(std::future::pending::<()>());
        let result = RuntimeState::from_runtime_parts(
            runtime,
            Err(Error::Io(io::Error::other("MQTT worker startup failed"))),
        );
        assert!(matches!(result, Err(Error::Io(_))));
        assert!(time::timeout(Duration::from_secs(5), pending)
            .await
            .unwrap()
            .unwrap_err()
            .is_cancelled());
    }

    #[test]
    fn mqtt_reactor_migration_preserves_replay_bytes_after_old_runtime_shutdown() {
        use std::io::{Read, Write};
        let original = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let target = build_mqtt_runtime(None, false).unwrap().unwrap();
        assert_eq!(target.metrics().num_workers(), 1);
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        listener.set_nonblocking(true).unwrap();
        let mut client = std::net::TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        client
            .set_read_timeout(Some(Duration::from_secs(5)))
            .unwrap();
        let (server, _) = original.block_on(async {
            tokio::net::TcpListener::from_std(listener)
                .unwrap()
                .accept()
                .await
                .unwrap()
        });
        let mut stream = IoStream::plain(server);
        stream.buffer_front(b"prefix");
        original.block_on(async {
            let mut prefix = [0; 2];
            stream.read_exact(&mut prefix).await.unwrap();
            assert_eq!(&prefix, b"pr");
        });
        let mut stream = stream.into_runtime(target.handle()).unwrap();
        original.shutdown_timeout(Duration::from_secs(1));
        client.write_all(b"DATA").unwrap();
        target.block_on(async {
            let mut bytes = [0; 8];
            time::timeout(Duration::from_secs(5), stream.read_exact(&mut bytes))
                .await
                .unwrap()
                .unwrap();
            assert_eq!(&bytes, b"efixDATA");
            stream.write_all(b"ACK").await.unwrap();
        });
        let mut ack = [0; 3];
        client.read_exact(&mut ack).unwrap();
        assert_eq!(&ack, b"ACK");
    }

    #[test]
    fn mqtt_reactor_migration_failure_does_not_register_a_connection() {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let target = build_mqtt_runtime(None, false).unwrap().unwrap();
        let handle = target.handle().clone();
        target.shutdown_timeout(Duration::from_secs(1));
        runtime.block_on(async {
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let _client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
                .await
                .unwrap();
            let (server, peer_addr) = listener.accept().await.unwrap();
            let registry = Arc::new(ListenerRegistry {
                mqtt_handle: Some(handle),
                ..ListenerRegistry::default()
            });
            let result = Arc::clone(&registry).register_mqtt_stream_connection(
                tokio::runtime::Handle::current(),
                ListenerId(1),
                ConnectionId(77),
                Arc::new(build_client_endpoint_config(
                    "127.0.0.1",
                    0,
                    false,
                    TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
                    None,
                    None,
                )),
                IoStream::plain(server),
                5,
                peer_addr,
                false,
            );
            assert!(matches!(result, Err(Error::Io(_))));
            assert!(registry.connections.lock().unwrap().is_empty());
        });
    }

    #[tokio::test]
    async fn mqtt_websocket_upgrade_preserves_tcp_nodelay_for_sparse_publications() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap())
            .await
            .unwrap();
        let (server, peer_addr) = listener.accept().await.unwrap();
        let server = server.into_std().unwrap();
        // A duplicated descriptor observes the actual connection's options
        // without taking ownership from the registered reader/writer tasks.
        let observer = server.try_clone().unwrap();
        let server = tokio::net::TcpStream::from_std(server).unwrap();
        let mut endpoint = build_client_endpoint_config(
            "127.0.0.1",
            0,
            false,
            TransportProtocol::Mqtt,
            config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            None,
            None,
        );
        endpoint.protocols.push(TransportProtocol::Websocket);
        client.write_all(b"GET /mqtt HTTP/1.1\r\nHost: localhost\r\nConnection: Upgrade\r\nUpgrade: websocket\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: mqtt\r\n\r\n").await.unwrap();
        let registry = Arc::new(ListenerRegistry::default());
        let config_state = Arc::new(ListenerConfigState::new(Arc::new(endpoint), None));
        let (sender, mut accepted) = mpsc::channel(1);
        time::timeout(
            Duration::from_secs(5),
            negotiate_accepted_connection(
                server,
                peer_addr,
                ListenerId(1),
                config_state,
                Arc::clone(&registry),
                tokio::runtime::Handle::current(),
                sender,
            ),
        )
        .await
        .unwrap();
        let id = time::timeout(Duration::from_secs(5), accepted.recv())
            .await
            .unwrap()
            .unwrap();
        assert!(
            observer.nodelay().unwrap(),
            "MQTT WS must not re-enable Nagle after upgrade"
        );
        registry.close_connection(id).unwrap();
    }

    #[test]
    fn mqtt_failed_reactor_transfer_never_announces_an_accepted_connection() {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let target = build_mqtt_runtime(None, false).unwrap().unwrap();
        let dead_handle = target.handle().clone();
        target.shutdown_timeout(Duration::from_secs(1));
        runtime.block_on(async {
            for websocket in [false, true] {
                let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
                let mut client = tokio::net::TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
                let (server, peer_addr) = listener.accept().await.unwrap();
                let mut endpoint = build_client_endpoint_config(
                    "127.0.0.1", 0, false, TransportProtocol::Mqtt,
                    config::DEFAULT_RAWSOCKET_SIZE_EXPONENT, None, None,
                );
                if websocket {
                    endpoint.protocols.push(TransportProtocol::Websocket);
                    client.write_all(b"GET /mqtt HTTP/1.1\r\nHost: localhost\r\nConnection: Upgrade\r\nUpgrade: websocket\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: mqtt\r\n\r\n").await.unwrap();
                } else {
                    client.write_all(&[0x10, 0x0e, 0, 4, b'M', b'Q', b'T', b'T', 5, 2, 0, 60, 0, 0, 1, b'c']).await.unwrap();
                }
                let registry = Arc::new(ListenerRegistry {
                    mqtt_handle: Some(dead_handle.clone()), ..ListenerRegistry::default()
                });
                let config_state = Arc::new(ListenerConfigState::new(Arc::new(endpoint), None));
                let (sender, mut accepted) = mpsc::channel(1);
                time::timeout(Duration::from_secs(5), negotiate_accepted_connection(
                    server, peer_addr, ListenerId(1), config_state, Arc::clone(&registry),
                    tokio::runtime::Handle::current(), sender,
                )).await.unwrap();
                assert!(time::timeout(Duration::from_secs(5), accepted.recv()).await.unwrap().is_none());
                assert!(registry.connections.lock().unwrap().is_empty());
                if websocket {
                    let mut response = Vec::new();
                    time::timeout(Duration::from_secs(5), client.read_to_end(&mut response)).await.unwrap().unwrap();
                    assert!(response.starts_with(b"HTTP/1.1 101 "));
                }
            }
        });
    }

    #[test]
    fn mqtt_reactor_isolation_preserves_worker_overrides_and_shuts_down_both_pools() {
        for workers in [1, 2, 4, 64] {
            for tokio in [false, true] {
                assert!(build_mqtt_runtime(Some(workers), tokio).unwrap().is_none());
            }
        }
        assert!(build_mqtt_runtime(None, true).unwrap().is_none());
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .unwrap();
        let mqtt_runtime = build_mqtt_runtime(None, false).unwrap();
        let primary_handle = runtime.handle().clone();
        let mqtt_handle = mqtt_runtime.as_ref().unwrap().handle().clone();
        assert_ne!(mqtt_handle.id(), primary_handle.id());
        assert_eq!(primary_handle.metrics().num_workers(), 2);
        let primary_task = primary_handle.spawn(std::future::pending::<()>());
        let mqtt_task = mqtt_handle.spawn(std::future::pending::<()>());
        let state = RuntimeState {
            runtime,
            mqtt_runtime,
            handle: primary_handle,
            registry: Arc::new(ListenerRegistry {
                mqtt_handle: Some(mqtt_handle),
                ..ListenerRegistry::default()
            }),
        };
        state.shutdown();
        let observer = tokio::runtime::Builder::new_current_thread()
            .build()
            .unwrap();
        assert!(observer.block_on(primary_task).unwrap_err().is_cancelled());
        assert!(observer.block_on(mqtt_task).unwrap_err().is_cancelled());
    }

    #[test]
    fn parse_runtime_worker_threads_accepts_positive_values() {
        assert_eq!(parse_runtime_worker_threads(Some("1")).unwrap(), Some(1));
        assert_eq!(parse_runtime_worker_threads(Some(" 4 ")).unwrap(), Some(4));
    }

    #[test]
    fn parse_runtime_worker_threads_rejects_zero_and_invalid_values() {
        assert!(matches!(
            parse_runtime_worker_threads(Some("0")),
            Err(Error::InvalidRuntimeThreadCount(_))
        ));
        assert!(matches!(
            parse_runtime_worker_threads(Some("abc")),
            Err(Error::InvalidRuntimeThreadCount(_))
        ));
    }

    #[test]
    fn http1_read_error_logging_skips_expected_idle_timeouts() {
        assert!(!should_log_http1_read_error(
            &protocol::NegotiationError::Timeout
        ));
        assert!(should_log_http1_read_error(
            &protocol::NegotiationError::Protocol("bad request".into())
        ));
        assert!(should_log_http1_read_error(
            &protocol::NegotiationError::Io(io::Error::new(
                io::ErrorKind::ConnectionReset,
                "reset",
            ))
        ));
    }

    #[test]
    fn http2_connection_write_tracker_records_headers_to_first_connection_write() {
        let before = http_response_stream_metrics_snapshot();
        let tracker = Http2ConnectionWriteTracker::default();
        let headers_sent_at = Instant::now();
        assert_eq!(tracker.note_headers_sent(headers_sent_at), 1);
        std::thread::sleep(Duration::from_millis(2));
        tracker.record_connection_write(Instant::now());
        let after = http_response_stream_metrics_snapshot();
        assert!(
            after.headers_to_first_connection_write_samples_total
                > before.headers_to_first_connection_write_samples_total
        );
        assert!(
            after.headers_to_first_connection_write_us_total
                > before.headers_to_first_connection_write_us_total
        );
        assert!(
            after.headers_to_first_connection_write_ge_1ms_total
                > before.headers_to_first_connection_write_ge_1ms_total
        );
    }

    #[test]
    fn http2_connection_write_tracker_counts_pending_headers() {
        let tracker = Http2ConnectionWriteTracker::default();
        assert_eq!(tracker.note_headers_sent(Instant::now()), 1);
        assert_eq!(tracker.note_headers_sent(Instant::now()), 2);
        tracker.record_connection_write(Instant::now());
        assert_eq!(tracker.note_headers_sent(Instant::now()), 1);
    }

    #[tokio::test]
    async fn http2_instrumented_stream_tracks_only_nonempty_socket_writes() {
        time::timeout(Duration::from_secs(5), async {
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let address = listener.local_addr().unwrap();
            let (client, server) =
                tokio::join!(tokio::net::TcpStream::connect(address), listener.accept());
            let mut peer = client.unwrap();
            let tracker = Arc::new(Http2ConnectionWriteTracker::default());
            let mut stream = InstrumentedHttp2IoStream {
                inner: IoStream::plain(server.unwrap().0),
                write_tracker: Arc::clone(&tracker),
            };
            assert_eq!(tracker.note_headers_sent(Instant::now()), 1);
            assert_eq!(tracker.note_headers_sent(Instant::now()), 2);
            peer.write_all(b"ack").await.unwrap();
            let mut ack = [0; 3];
            stream.read_exact(&mut ack).await.unwrap();
            assert_eq!(&ack, b"ack");
            assert_eq!(stream.write(&[]).await.unwrap(), 0);
            stream.flush().await.unwrap();
            assert_eq!(tracker.pending_headers_sent_at.lock().unwrap().len(), 2);

            stream.write_all(b"response").await.unwrap();
            assert!(tracker.pending_headers_sent_at.lock().unwrap().is_empty());
            let mut received = [0; 8];
            peer.read_exact(&mut received).await.unwrap();
            assert_eq!(&received, b"response");

            assert_eq!(tracker.note_headers_sent(Instant::now()), 1);
            stream.flush().await.unwrap();
            stream.shutdown().await.unwrap();
            assert_eq!(tracker.pending_headers_sent_at.lock().unwrap().len(), 1);
            assert_eq!(peer.read(&mut received).await.unwrap(), 0);
        })
        .await
        .expect("instrumented HTTP2 socket exchange timed out");
    }

    #[test]
    fn http2_response_yield_requires_multiple_pending_headers() {
        assert!(!should_yield_for_pending_http2_responses(0));
        assert!(!should_yield_for_pending_http2_responses(1));
        assert!(should_yield_for_pending_http2_responses(2));
    }

    #[test]
    fn http_response_stream_metrics_record_tail_chunks() {
        let before = http_response_stream_metrics_snapshot();
        let metrics = http_response_stream_metrics();
        let queued_at = Instant::now();
        let dequeue_at = queued_at + Duration::from_millis(2);
        let send_finished_at = dequeue_at + Duration::from_millis(3);
        metrics.record_tail_chunk(queued_at, dequeue_at, dequeue_at, send_finished_at);
        metrics.record_first_to_last_chunk_send(queued_at, send_finished_at);
        let after = http_response_stream_metrics_snapshot();
        assert!(
            after.tail_chunk_channel_wait_samples_total
                > before.tail_chunk_channel_wait_samples_total
        );
        assert!(
            after.tail_chunk_send_call_samples_total > before.tail_chunk_send_call_samples_total
        );
        assert!(
            after.first_to_last_chunk_send_samples_total
                > before.first_to_last_chunk_send_samples_total
        );
        assert!(
            after.tail_chunk_channel_wait_ge_1ms_total
                > before.tail_chunk_channel_wait_ge_1ms_total
        );
        assert!(after.tail_chunk_send_call_ge_1ms_total > before.tail_chunk_send_call_ge_1ms_total);
        assert!(
            after.first_to_last_chunk_send_ge_5ms_total
                > before.first_to_last_chunk_send_ge_5ms_total
        );
    }

    #[test]
    fn http_request_body_stream_metrics_record_reader_chunks() {
        let before = http_request_body_stream_metrics_snapshot();
        let metrics = http_request_body_stream_metrics();
        let started_at = Instant::now();
        let first_at = started_at + Duration::from_millis(1);
        let second_at = first_at + Duration::from_millis(2);
        let finished_at = second_at + Duration::from_millis(3);
        metrics.record_streaming_request();
        metrics.record_data_chunk_wait_us(1_000);
        metrics.record_first_chunk_wait(started_at, first_at);
        metrics.record_data_chunk_wait_us(2_000);
        metrics.record_second_chunk_wait(first_at, second_at);
        metrics.record_reader_finished(
            started_at,
            finished_at,
            Some(second_at),
            2_000,
            HttpRequestBodyTailDataWaitMax {
                wait_us: 1_500,
                event_index: 4,
                bytes_before: 131_072,
                bytes_after: 196_608,
                eof: false,
                flow_before_wait: HttpRequestBodyFlowControlSample {
                    available_capacity: -16_384,
                    used_capacity: 65_536,
                },
                flow_after_data: HttpRequestBodyFlowControlSample {
                    available_capacity: -32_768,
                    used_capacity: 131_072,
                },
                flow_after_release: HttpRequestBodyFlowControlSample {
                    available_capacity: 32_768,
                    used_capacity: 65_536,
                },
            },
        );
        let after = http_request_body_stream_metrics_snapshot();
        assert!(after.streaming_requests_total > before.streaming_requests_total);
        assert!(after.data_chunk_samples_total > before.data_chunk_samples_total);
        assert!(after.first_chunk_wait_samples_total > before.first_chunk_wait_samples_total);
        assert!(after.second_chunk_wait_samples_total > before.second_chunk_wait_samples_total);
        assert!(after.remaining_tail_read_samples_total > before.remaining_tail_read_samples_total);
        assert!(
            after.remaining_tail_data_wait_samples_total
                > before.remaining_tail_data_wait_samples_total
        );
        assert!(after.remaining_tail_data_wait_us_total > before.remaining_tail_data_wait_us_total);
        assert!(
            after.remaining_tail_data_wait_max_us_total
                > before.remaining_tail_data_wait_max_us_total
        );
        assert!(
            after.remaining_tail_data_wait_max_event_index_total
                > before.remaining_tail_data_wait_max_event_index_total
        );
        assert!(
            after.remaining_tail_data_wait_max_bytes_before_total
                > before.remaining_tail_data_wait_max_bytes_before_total
        );
        assert!(
            after.remaining_tail_data_wait_max_bytes_after_total
                > before.remaining_tail_data_wait_max_bytes_after_total
        );
        assert!(
            after.remaining_tail_data_wait_max_available_capacity_before_total
                < before.remaining_tail_data_wait_max_available_capacity_before_total
        );
        assert!(
            after.remaining_tail_data_wait_max_used_capacity_before_total
                > before.remaining_tail_data_wait_max_used_capacity_before_total
        );
        assert!(
            after.remaining_tail_data_wait_max_available_capacity_after_data_total
                < before.remaining_tail_data_wait_max_available_capacity_after_data_total
        );
        assert!(
            after.remaining_tail_data_wait_max_used_capacity_after_data_total
                > before.remaining_tail_data_wait_max_used_capacity_after_data_total
        );
        assert!(
            after.remaining_tail_data_wait_max_available_capacity_after_release_total
                > before.remaining_tail_data_wait_max_available_capacity_after_release_total
        );
        assert!(
            after.remaining_tail_data_wait_max_used_capacity_after_release_total
                > before.remaining_tail_data_wait_max_used_capacity_after_release_total
        );
        assert!(after.total_read_samples_total > before.total_read_samples_total);
        assert!(after.total_read_us_total > before.total_read_us_total);
    }

    struct GeneratedTlsMaterial {
        ca_pem: String,
        server_chain_pem: String,
        server_key_pem: String,
        client_chain_pem: String,
        client_key_pem: String,
    }

    fn generate_tls_material() -> GeneratedTlsMaterial {
        let mut ca_params = CertificateParams::new(Vec::new()).expect("ca params");
        ca_params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
        ca_params.key_usages = vec![
            KeyUsagePurpose::KeyCertSign,
            KeyUsagePurpose::CrlSign,
            KeyUsagePurpose::DigitalSignature,
        ];
        let ca_key = KeyPair::generate().expect("ca key");
        let ca = ca_params.self_signed(&ca_key).expect("ca cert");
        let ca_pem = ca.pem();

        let mut server_params =
            CertificateParams::new(vec!["localhost".to_string()]).expect("server params");
        server_params.extended_key_usages = vec![ExtendedKeyUsagePurpose::ServerAuth];
        server_params.key_usages = vec![
            KeyUsagePurpose::DigitalSignature,
            KeyUsagePurpose::KeyEncipherment,
        ];
        let server_key = KeyPair::generate().expect("server key");
        let server = server_params
            .signed_by(&server_key, &ca, &ca_key)
            .expect("server cert");
        let server_chain_pem = format!("{}\n{}", server.pem(), ca_pem.as_str());
        let server_key_pem = server_key.serialize_pem();

        let mut client_params = CertificateParams::new(Vec::new()).expect("client params");
        client_params.extended_key_usages = vec![ExtendedKeyUsagePurpose::ClientAuth];
        client_params.key_usages = vec![
            KeyUsagePurpose::DigitalSignature,
            KeyUsagePurpose::KeyEncipherment,
        ];
        let client_key = KeyPair::generate().expect("client key");
        let client = client_params
            .signed_by(&client_key, &ca, &ca_key)
            .expect("client cert");
        let client_chain_pem = format!("{}\n{}", client.pem(), ca_pem.as_str());
        let client_key_pem = client_key.serialize_pem();

        GeneratedTlsMaterial {
            ca_pem,
            server_chain_pem,
            server_key_pem,
            client_chain_pem,
            client_key_pem,
        }
    }

    #[test]
    fn mqtt_outbound_queue_buffers_one_window_and_caps_chunk_count() {
        let (queue, mut receiver) = MqttOutboundQueue::new(1024);
        let connection_id = ConnectionId(7);
        for _ in 0..512 {
            queue
                .enqueue(connection_id, Bytes::from_static(b"publish"))
                .expect("one 512-message window fits");
        }
        assert!(matches!(
            queue.enqueue(connection_id, Bytes::from_static(b"extra")),
            Err(Error::SendQueueFull(id)) if id == connection_id
        ));
        drop(receiver.try_recv().expect("first queued chunk"));
        queue
            .enqueue(connection_id, Bytes::from_static(b"next"))
            .expect("released slot accepts the next chunk");
    }

    #[test]
    fn mqtt_outbound_queue_caps_bytes_and_releases_writer_credit() {
        let (queue, mut receiver) = MqttOutboundQueue::new(1024);
        let connection_id = ConnectionId(8);
        let packet = Bytes::from(vec![0; 1024 * 1024]);
        for _ in 0..8 {
            queue
                .enqueue(connection_id, packet.clone())
                .expect("8 MiB budget accepts eight packets");
        }
        assert!(matches!(
            queue.enqueue(connection_id, packet.clone()),
            Err(Error::SendQueueFull(id)) if id == connection_id
        ));
        drop(receiver.try_recv().expect("first queued packet"));
        queue
            .enqueue(connection_id, packet)
            .expect("writer release returns byte credit");
    }

    #[test]
    fn mqtt_outbound_queue_rejects_oversize_and_releases_closed_channel_credit() {
        let (queue, receiver) = MqttOutboundQueue::new(1024);
        let connection_id = ConnectionId(9);
        assert!(matches!(
            queue.enqueue(
                connection_id,
                Bytes::from(vec![0; MQTT_OUTBOUND_QUEUE_MAX_BYTES + 1])
            ),
            Err(Error::SendQueueFull(id)) if id == connection_id
        ));
        assert_eq!(
            queue.byte_budget.available_permits(),
            MQTT_OUTBOUND_QUEUE_MAX_BYTES
        );
        drop(receiver);
        assert!(matches!(
            queue.enqueue(connection_id, Bytes::from_static(b"closed")),
            Err(Error::ConnectionNotFound(id)) if id == connection_id
        ));
        assert_eq!(
            queue.byte_budget.available_permits(),
            MQTT_OUTBOUND_QUEUE_MAX_BYTES
        );
    }

    #[test]
    fn enqueue_frame_returns_send_queue_full_when_outbound_queue_saturated() {
        let _guard = test_guard();

        let registry = ListenerRegistry::default();
        let connection_id = ConnectionId(1);
        let listener_id = ListenerId(1);
        let peer_addr: SocketAddr = "127.0.0.1:12345".parse().unwrap();

        let (frame_tx, frame_rx) = mpsc::channel(1);
        let _ = frame_tx;

        let (send_tx, send_rx) = mpsc::channel(1);
        let _send_rx = send_rx;

        send_tx
            .try_send(OutboundFrame::message(Bytes::from_static(b"one")))
            .expect("first send fills the queue");

        let rt = Runtime::new().unwrap();
        let reader_abort = rt.spawn(async {}).abort_handle();
        let writer_abort = rt.spawn(async {}).abort_handle();

        let exponent = config::DEFAULT_RAWSOCKET_SIZE_EXPONENT;
        let endpoint_config = Arc::new(config::EndpointRuntimeConfig {
            host: "127.0.0.1".to_string(),
            port: 0,
            tls_mode: config::TlsMode::Disabled,
            client_auth: None,
            protocols: vec![TransportProtocol::Rawsocket],
            idle_timeout: None,
            heartbeat_interval: None,
            heartbeat_timeout: None,
            handshake_timeout: config::DEFAULT_HANDSHAKE_TIMEOUT,
            max_http_content_length: None,
            max_rawsocket_size_exponent: exponent,
            max_rawsocket_size: 1u64 << exponent,
            max_upgrade_exponent: None,
            outbound_send_queue_capacity: 1,
            websocket_path: None,
            sni_certificates: Vec::new(),
            http_routes: Vec::new(),
            http: None,
        });

        registry.connections.lock().unwrap().insert(
            connection_id,
            ConnectionEntry {
                listener_id,
                peer_addr,
                protocol: ConnectionProtocol::RawSocket,
                websocket_protocol: None,
                endpoint_config,
                stats: None,
                record: ConnectionRecord::RawSocket {
                    _serializer: rawsocket::Serializer::Json,
                    max_exponent: exponent,
                    supports_file_segments: false,
                    frames: Arc::new(Mutex::new(frame_rx)),
                    reader_abort,
                    writer_abort,
                    heartbeat_abort: None,
                    send_tx,
                },
            },
        );

        let prepared = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let prepared_by_closure = Arc::clone(&prepared);
        let deferred = OutboundFrame::message_deferred_segment(Bytes::new(), 3, move || {
            prepared_by_closure.store(true, Ordering::SeqCst);
            Ok(Bytes::from_static(b"two"))
        })
        .unwrap();
        match registry.enqueue_frame(connection_id, deferred) {
            Err(Error::SendQueueFull(id)) => assert_eq!(id, connection_id),
            other => panic!("expected SendQueueFull, got {other:?}"),
        }
        assert!(!prepared.load(Ordering::SeqCst));
    }

    #[test]
    fn http_body_handle_from_inline_bytes_reuses_backing_storage() {
        let bytes = Bytes::from(vec![1u8, 2, 3, 4]);
        let ptr = bytes.as_ptr();
        let handle = HttpBodyHandle::from_inline(bytes);
        let slice = handle.slice(1, 2).expect("body slice available");
        assert_eq!(slice.ptr, unsafe { ptr.add(1) });
        assert_eq!(slice.len, 2);
        assert_eq!(
            unsafe { std::slice::from_raw_parts(slice.ptr, slice.len) },
            &[2, 3]
        );
    }

    #[test]
    fn flatten_headers_preserves_raw_http1_bytes() {
        let mut headers = http::HeaderMap::new();
        headers.insert(
            HeaderName::from_static("x-binary"),
            HeaderValue::from_bytes(b"abc\xff").expect("header value"),
        );

        let flattened = flatten_headers(&headers, None);
        assert_eq!(flattened.len(), 1);
        assert_eq!(flattened[0].0.as_ref(), b"x-binary");
        assert_eq!(flattened[0].1.as_ref(), b"abc\xff");
    }

    #[test]
    fn flatten_headers_synthesizes_host_from_authority() {
        let headers = http::HeaderMap::new();

        let flattened = flatten_headers(&headers, Some("127.0.0.1:9443"));
        assert_eq!(flattened.len(), 1);
        assert_eq!(flattened[0].0.as_ref(), b"host");
        assert_eq!(flattened[0].1.as_ref(), b"127.0.0.1:9443");
    }

    #[test]
    fn flatten_http2_headers_preserves_raw_bytes() {
        let mut headers = http::HeaderMap::new();
        headers.insert(
            Http2HeaderName::from_static("x-binary"),
            Http2HeaderValue::from_bytes(b"abc\xff").expect("header value"),
        );

        let flattened = flatten_http2_headers(&headers, None);
        assert_eq!(flattened.len(), 1);
        assert_eq!(flattened[0].0.as_ref(), b"x-binary");
        assert_eq!(flattened[0].1.as_ref(), b"abc\xff");
    }

    #[test]
    fn flatten_http2_headers_keeps_existing_host() {
        let mut headers = http::HeaderMap::new();
        headers.insert(
            Http2HeaderName::from_static("host"),
            Http2HeaderValue::from_static("example.test"),
        );

        let flattened = flatten_http2_headers(&headers, Some("127.0.0.1:9443"));
        assert_eq!(flattened.len(), 1);
        assert_eq!(flattened[0].0.as_ref(), b"host");
        assert_eq!(flattened[0].1.as_ref(), b"example.test");
    }

    #[test]
    fn parse_content_length_reads_byte_backed_headers() {
        let headers = vec![(
            http_bytes_from_slice(b"content-length"),
            http_bytes_from_slice(b" 42 "),
        )];
        assert_eq!(parse_content_length(&headers), Some(42));
    }

    #[test]
    fn http3_identity_rejections_preserve_valid_configuration_recovery() {
        let tls = generate_tls_material();
        let other_tls = generate_tls_material();
        let valid_identity = config::SniCertificate {
            hostname: "localhost".to_string(),
            certificate_chain_pem: tls.server_chain_pem.clone(),
            private_key_pem: tls.server_key_pem.clone(),
        };
        let cases = [
            (None, None, "requires SNI certificate for http3"),
            (
                Some(""),
                Some(tls.server_key_pem.as_str()),
                "http3 certificate chain empty",
            ),
            (
                Some("-----BEGIN CERTIFICATE-----\n!invalid!\n-----END CERTIFICATE-----\n"),
                Some(tls.server_key_pem.as_str()),
                "failed to parse http3 certificate:",
            ),
            (
                Some(tls.server_chain_pem.as_str()),
                Some(""),
                "http3 private key missing",
            ),
            (
                Some(tls.server_chain_pem.as_str()),
                Some("-----BEGIN PRIVATE KEY-----\n!invalid!\n-----END PRIVATE KEY-----\n"),
                "failed to parse pkcs8 key for http3:",
            ),
            (
                Some("-----BEGIN CERTIFICATE-----\nAA==\n-----END CERTIFICATE-----\n"),
                Some(tls.server_key_pem.as_str()),
                "http3 certificate invalid:",
            ),
            (
                Some(tls.server_chain_pem.as_str()),
                Some(other_tls.server_key_pem.as_str()),
                "http3 certificate invalid:",
            ),
        ];
        let mut endpoint = build_client_endpoint_config(
            "localhost",
            8443,
            true,
            TransportProtocol::Http,
            config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            None,
            None,
        );
        for (certificate, key, reason) in cases {
            endpoint.sni_certificates = certificate
                .map(|certificate| config::SniCertificate {
                    hostname: "localhost".to_string(),
                    certificate_chain_pem: certificate.to_string(),
                    private_key_pem: key.expect("test key fixture").to_string(),
                })
                .into_iter()
                .collect();
            match build_http3_server_config(&endpoint) {
                Err(Error::RouterConfigInvalid(message)) => assert!(
                    message.starts_with(&format!("endpoint localhost:8443 {reason}")),
                    "incorrect rejection category for {reason}: {message}",
                ),
                Err(error) => panic!("incorrect error type for {reason}: {error:?}"),
                Ok(_) => panic!("accepted invalid HTTP/3 identity: {reason}"),
            }
            endpoint.sni_certificates = vec![valid_identity.clone()];
            let (certificates, key) = load_http3_identity(&endpoint).expect("restored identity");
            assert_eq!(certificates.len(), 2, "preserve leaf and CA certificates");
            assert!(!key.secret_der().is_empty());
            assert!(
                build_http3_server_config(&endpoint).is_ok(),
                "recovery after {reason}"
            );
        }
    }

    #[test]
    fn http3_server_config_applies_transport_tuning() {
        let tls = generate_tls_material();
        let endpoint = config::EndpointRuntimeConfig {
            host: "localhost".to_string(),
            port: 8443,
            tls_mode: config::TlsMode::Native,
            client_auth: None,
            protocols: vec![TransportProtocol::Http],
            idle_timeout: None,
            heartbeat_interval: None,
            heartbeat_timeout: None,
            handshake_timeout: config::DEFAULT_HANDSHAKE_TIMEOUT,
            max_http_content_length: None,
            max_rawsocket_size_exponent: config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            max_rawsocket_size: 1u64 << config::DEFAULT_RAWSOCKET_SIZE_EXPONENT,
            max_upgrade_exponent: None,
            outbound_send_queue_capacity: config::DEFAULT_OUTBOUND_SEND_QUEUE_CAPACITY,
            websocket_path: None,
            sni_certificates: vec![config::SniCertificate {
                hostname: "localhost".to_string(),
                certificate_chain_pem: tls.server_chain_pem,
                private_key_pem: tls.server_key_pem,
            }],
            http_routes: Vec::new(),
            http: None,
        };

        let server = build_http3_server_config(&endpoint).expect("http3 server config");
        let transport_debug = format!("{:?}", server.transport);
        assert!(transport_debug.contains("max_concurrent_bidi_streams: 1024"));
        assert!(transport_debug.contains("max_concurrent_uni_streams: 256"));
        assert!(transport_debug.contains("stream_receive_window: 8388608"));
        assert!(transport_debug.contains("receive_window: 67108864"));
        assert!(transport_debug.contains("send_window: 67108864"));
        assert!(transport_debug.contains("keep_alive_interval: Some(5s)"));
        assert!(transport_debug.contains("datagram_receive_buffer_size: Some(8388608)"));
        assert!(transport_debug.contains("datagram_send_buffer_size: 8388608"));
    }

    fn build_tls_connector(
        ca_pem: &str,
        client_chain_pem: Option<&str>,
        client_key_pem: Option<&str>,
    ) -> TlsConnector {
        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let mut roots = rustls::RootCertStore::empty();
        let mut ca_reader = Cursor::new(ca_pem.as_bytes());
        let ca_certs = rustls_pemfile::certs(&mut ca_reader)
            .collect::<Result<Vec<_>, _>>()
            .expect("parse ca certs");
        for cert in ca_certs {
            roots.add(cert).expect("add ca cert");
        }

        let builder = RustlsClientConfig::builder_with_provider(Arc::clone(&provider))
            .with_protocol_versions(&[&rustls::version::TLS13])
            .unwrap()
            .with_root_certificates(roots);

        let client_config = match (client_chain_pem, client_key_pem) {
            (Some(chain_pem), Some(key_pem)) => {
                let mut chain_reader = Cursor::new(chain_pem.as_bytes());
                let certs = rustls_pemfile::certs(&mut chain_reader)
                    .collect::<Result<Vec<_>, _>>()
                    .expect("parse client cert chain");
                let mut key_reader = Cursor::new(key_pem.as_bytes());
                let key = pkcs8_private_keys(&mut key_reader)
                    .collect::<Result<Vec<_>, _>>()
                    .expect("parse client key")
                    .into_iter()
                    .next()
                    .expect("client key missing")
                    .into();
                builder
                    .with_client_auth_cert(certs, key)
                    .expect("client auth config")
            }
            _ => builder.with_no_client_auth(),
        };

        TlsConnector::from(Arc::new(client_config))
    }

    #[test]
    fn apply_router_config_stores_config() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":8080,"tls_mode":"disabled"}]}"#);
        assert!(applied.is_ok());
        let cfg = crate::config::current_config();
        assert!(cfg.is_some());
        let cfg = cfg.unwrap();
        assert_eq!(cfg.endpoints.len(), 1);
        let endpoint = crate::config::find_endpoint("127.0.0.1", 8080);
        assert!(endpoint.is_some());
        let endpoint = endpoint.unwrap();
        assert_eq!(endpoint.host, "127.0.0.1");
    }

    #[test]
    fn endpoint_lookup_requires_both_host_and_port_and_preserves_valid_config() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(br#"{"schema":"connectanum.router","version":1,"endpoints":[
            {"host":"EXAMPLE.COM","port":8080,"tls_mode":"disabled","max_rawsocket_size_exponent":9},
            {"host":"EXAMPLE.COM","port":8081,"tls_mode":"disabled","max_rawsocket_size_exponent":10},
            {"host":"other.example","port":8080,"tls_mode":"disabled","max_rawsocket_size_exponent":11}
        ]}"#);
        assert!(applied.is_ok());
        for (host, port, exponent) in [
            ("example.com", 8080, 9),
            ("example.com", 8081, 10),
            ("OTHER.EXAMPLE", 8080, 11),
        ] {
            let endpoint = crate::config::find_endpoint(host, port);
            assert!(endpoint.is_some());
            assert_eq!(
                endpoint.unwrap().max_rawsocket_size_exponent,
                Some(exponent)
            );
        }
        for (host, port) in [
            ("example.com", 9000),
            ("missing.example", 8080),
            ("other.example", 8081),
        ] {
            assert!(crate::config::find_endpoint(host, port).is_none());
        }
        assert!(super::apply_router_config(b"invalid json").is_err());
        let preserved = crate::config::find_endpoint("example.com", 8081);
        assert!(preserved.is_some());
        assert_eq!(preserved.unwrap().max_rawsocket_size_exponent, Some(10));
    }

    #[test]
    fn apply_router_config_rejects_invalid_rawsocket_exponent() {
        let _guard = test_guard();
        shutdown().ok();
        let result = super::apply_router_config(br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":8080,"tls_mode":"disabled","max_rawsocket_size_exponent":8}]}"#);
        assert!(matches!(result, Err(Error::RouterConfigInvalid(_))));

        let result = super::apply_router_config(br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":8080,"tls_mode":"disabled","max_rawsocket_size_exponent":31}]}"#);
        assert!(matches!(result, Err(Error::RouterConfigInvalid(_))));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn runtime_starts_only_once() {
        let _guard = test_guard();
        shutdown().ok();
        start_runtime().expect("first start succeeds");
        let err = start_runtime().expect_err("second start fails");
        assert!(matches!(err, Error::RuntimeAlreadyStarted));
        shutdown().expect("shutdown succeeds");
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn listen_accept_and_shutdown() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled"}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        assert!(addr.port() > 0);

        let mut receiver = accept_channel(listener_id).unwrap();
        let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        perform_handshake(&mut stream, 16, None).await;
        drop(stream);

        let connection_id = assert_accepted_connection(&mut receiver).await;
        assert!(connection_id.0 > 0);
        assert!(matches!(receiver.try_recv(), Err(TryRecvError::Empty)));

        shutdown().unwrap();
        // Runtime can be started again after shutdown.
        start_runtime().unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn http1_route_method_mismatch_returns_405_without_dispatch() {
        let _guard = test_guard();
        shutdown().ok();
        let config = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"disabled",
                "protocols":["http"],
                "http_routes":[{
                    "path":"/api/items",
                    "methods":{
                        "GET":{"type":"reserved_realm"},
                        "POST":{"type":"reserved_realm"}
                    }
                }]
            }]
        });
        let applied = super::apply_router_config(&serde_json::to_vec(&config).unwrap());
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        stream
            .write_all(
                b"DELETE /api/items HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nContent-Length: 0\r\n\r\n",
            )
            .await
            .unwrap();

        let mut response_bytes = Vec::new();
        let mut buf = [0u8; 256];
        loop {
            let read = tokio::time::timeout(Duration::from_secs(2), stream.read(&mut buf)).await;
            assert_eq!(read.is_ok(), true, "405 response should arrive: {read:?}");
            let read = read.unwrap();
            assert_eq!(read.is_ok(), true, "response read succeeds: {read:?}");
            let read = read.unwrap();
            assert_ne!(read, 0, "response closed before body was read");
            response_bytes.extend_from_slice(&buf[..read]);
            if response_bytes
                .windows(b"method not allowed".len())
                .any(|window| window == b"method not allowed")
            {
                break;
            }
            assert_eq!(
                response_bytes.len() < 1024,
                true,
                "unexpectedly large 405 response"
            );
        }
        let response = std::str::from_utf8(&response_bytes).expect("response is utf8");
        assert_eq!(
            response.starts_with("HTTP/1.1 405 Method Not Allowed"),
            true,
            "{response}"
        );
        assert_eq!(
            response.contains("\r\nAllow: GET, POST\r\n"),
            true,
            "{response}"
        );
        assert_eq!(response.ends_with("method not allowed"), true, "{response}");
        let connection_id = receiver
            .try_recv()
            .expect("http connection should be tracked");
        assert!(
            connection_http_poll_request(connection_id)
                .unwrap()
                .is_none(),
            "method mismatch should not enqueue a Dart-dispatched HTTP request"
        );
        drop(stream);

        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn listener_close_removes_entry() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled"}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();

        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        assert!(local_addr(listener_id).is_ok());
        close_listener(listener_id).unwrap();
        let err = local_addr(listener_id).expect_err("listener removed");
        assert!(matches!(err, Error::ListenerNotFound(_)));
        let err = close_listener(listener_id).expect_err("second close fails");
        assert!(matches!(err, Error::ListenerNotFound(_)));

        shutdown().unwrap();
    }

    #[test]
    fn http3_listener_starts_from_current_thread_runtime() {
        assert_http3_listener_starts_from_runtime(
            tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap(),
        );
    }

    #[test]
    fn http3_listener_starts_from_multi_thread_runtime() {
        assert_http3_listener_starts_from_runtime(
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(2)
                .enable_all()
                .build()
                .unwrap(),
        );
    }

    fn assert_http3_listener_starts_from_runtime(caller: tokio::runtime::Runtime) {
        let _guard = test_guard();
        shutdown().unwrap();
        // Keep UDP occupied at the TCP port: HTTP/3 port zero must request an
        // independent ephemeral socket, not reuse the TCP listener's port.
        let (tcp_reservation, udp_reservation) = (0..16)
            .find_map(|_| {
                let udp = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
                std::net::TcpListener::bind(udp.local_addr().unwrap())
                    .ok()
                    .map(|tcp| (tcp, udp))
            })
            .expect("reserve a TCP port with an occupied UDP counterpart");
        let tcp_port = tcp_reservation.local_addr().unwrap().port();
        let certified = rcgen::generate_simple_self_signed(vec!["localhost".into()]).unwrap();
        let config = json!({
            "schema": "connectanum.router",
            "version": 1,
            "endpoints": [{
                "host": "127.0.0.1",
                "port": tcp_port,
                "tls_mode": "native",
                "protocols": ["http3"],
                "http": {"http3": {"enabled": true, "port": 0}},
                "sni_certificates": [{
                    "hostname": "localhost",
                    "certificate_chain_pem": certified.cert.pem(),
                    "private_key_pem": certified.key_pair.serialize_pem()
                }]
            }]
        });
        let applied = apply_router_config(&serde_json::to_vec(&config).unwrap());
        assert_eq!(applied.is_ok(), true, "{applied:?}");
        start_runtime().unwrap();
        drop(tcp_reservation);
        // Clean up even when the regression triggers a nested-runtime panic.
        let started = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            caller.block_on(async {
                let before = tokio::runtime::Handle::current().runtime_flavor();
                let listener = listen("127.0.0.1", tcp_port, 128);
                assert_eq!(tokio::runtime::Handle::current().runtime_flavor(), before);
                listener
            })
        }));
        drop(caller);
        let port = started
            .as_ref()
            .ok()
            .and_then(|result| result.as_ref().ok())
            .map(|listener| listener_http3_port(*listener));
        let handshake = if let Some(Ok(Some(port))) = port {
            let mut roots = rustls::RootCertStore::empty();
            roots.add(certified.cert.der().clone()).unwrap();
            let mut crypto = RustlsClientConfig::builder_with_provider(Arc::new(
                rustls::crypto::ring::default_provider(),
            ))
            .with_protocol_versions(&[&rustls::version::TLS13])
            .unwrap()
            .with_root_certificates(roots)
            .with_no_client_auth();
            crypto.alpn_protocols = vec![b"h3".to_vec()];
            let crypto = quinn::crypto::rustls::QuicClientConfig::try_from(crypto).unwrap();
            let client_config = quinn::ClientConfig::new(Arc::new(crypto));
            let probe = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();
            Some(probe.block_on(async move {
                let mut endpoint = QuinnEndpoint::client("127.0.0.1:0".parse().unwrap())
                    .map_err(|error| error.to_string())?;
                endpoint.set_default_client_config(client_config);
                let connecting = endpoint
                    .connect(SocketAddr::from(([127, 0, 0, 1], port)), "localhost")
                    .map_err(|error| error.to_string())?;
                let connection = tokio::time::timeout(Duration::from_secs(2), connecting)
                    .await
                    .map_err(|error| error.to_string())?
                    .map_err(|error| error.to_string())?;
                connection.close(0u32.into(), b"test complete");
                endpoint.close(0u32.into(), b"test complete");
                Ok::<(), String>(())
            }))
        } else {
            None
        };
        shutdown().unwrap();
        assert_eq!(udp_reservation.local_addr().unwrap().port(), tcp_port);
        assert!(started.is_ok());
        let listener = started.unwrap();
        assert_eq!(listener.is_ok(), true, "{listener:?}");
        assert!(matches!(port, Some(Ok(Some(port))) if port > 0 && port != tcp_port));
        assert_eq!(handshake, Some(Ok(())));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn tls_accepts_rawsocket_connections() {
        let _guard = test_guard();
        shutdown().ok();
        let cert_pem = include_str!("../../../bench/bench_tls.crt");
        let key_pem = include_str!("../../../bench/bench_tls.key");

        let config = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"native",
                "max_rawsocket_size_exponent":16,
                "sni_certificates":[{
                    "hostname":"localhost",
                    "certificate_chain_pem":cert_pem,
                    "private_key_pem":key_pem
                }]
            }]
        });
        let bytes = serde_json::to_vec(&config).unwrap();
        let applied = super::apply_router_config(&bytes);
        assert!(applied.is_ok());

        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        #[derive(Debug)]
        struct NoCertificateVerification {
            schemes: Vec<rustls::SignatureScheme>,
        }

        impl rustls::client::danger::ServerCertVerifier for NoCertificateVerification {
            fn verify_server_cert(
                &self,
                _end_entity: &rustls::pki_types::CertificateDer<'_>,
                _intermediates: &[rustls::pki_types::CertificateDer<'_>],
                _server_name: &ServerName<'_>,
                _ocsp_response: &[u8],
                _now: rustls::pki_types::UnixTime,
            ) -> Result<rustls::client::danger::ServerCertVerified, rustls::Error> {
                Ok(rustls::client::danger::ServerCertVerified::assertion())
            }

            fn verify_tls12_signature(
                &self,
                _message: &[u8],
                _cert: &rustls::pki_types::CertificateDer<'_>,
                _dss: &rustls::DigitallySignedStruct,
            ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error>
            {
                Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
            }

            fn verify_tls13_signature(
                &self,
                _message: &[u8],
                _cert: &rustls::pki_types::CertificateDer<'_>,
                _dss: &rustls::DigitallySignedStruct,
            ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error>
            {
                Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
            }

            fn supported_verify_schemes(&self) -> Vec<rustls::SignatureScheme> {
                self.schemes.clone()
            }
        }

        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let verifier = Arc::new(NoCertificateVerification {
            schemes: provider
                .signature_verification_algorithms
                .supported_schemes(),
        });
        let client_config = RustlsClientConfig::builder_with_provider(Arc::clone(&provider))
            .with_protocol_versions(&[&rustls::version::TLS13])
            .unwrap()
            .dangerous()
            .with_custom_certificate_verifier(verifier)
            .with_no_client_auth();
        let connector = TlsConnector::from(Arc::new(client_config));

        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let server_name = ServerName::try_from("localhost").unwrap();
        let mut tls_stream = connector.connect(server_name, tcp).await.unwrap();

        let handshake_byte = ((16u8 - 9) << 4) | 0x01;
        tls_stream
            .write_all(&[0x7F, handshake_byte, 0x00, 0x00])
            .await
            .unwrap();
        let mut response = [0u8; 4];
        let read = tls_stream.read_exact(&mut response).await;
        assert!(read.is_ok());
        assert_eq!(response[0], 0x7F);
        drop(tls_stream);

        let connection_id = assert_accepted_connection(&mut receiver).await;
        assert!(connection_id.0 > 0);
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn reload_tls_updates_client_auth_mode() {
        let _guard = test_guard();
        shutdown().ok();

        let tls = generate_tls_material();
        let optional_cfg = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"native",
                "max_rawsocket_size_exponent":16,
                "sni_certificates":[{
                    "hostname":"localhost",
                    "certificate_chain_pem":tls.server_chain_pem,
                    "private_key_pem":tls.server_key_pem
                }],
                "client_auth": {
                    "mode":"optional",
                    "ca_certificates_pem":tls.ca_pem
                }
            }]
        });
        let bytes = serde_json::to_vec(&optional_cfg).unwrap();
        let applied = super::apply_router_config(&bytes);
        assert!(applied.is_ok());

        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connector = build_tls_connector(&tls.ca_pem, None, None);
        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut tls_stream = connector
            .connect(ServerName::try_from("localhost").unwrap(), tcp)
            .await
            .unwrap();

        let handshake_byte = ((16u8 - 9) << 4) | 0x01;
        tls_stream
            .write_all(&[0x7F, handshake_byte, 0x00, 0x00])
            .await
            .unwrap();
        let mut response = [0u8; 4];
        let read = tls_stream.read_exact(&mut response).await;
        assert!(read.is_ok());
        assert_eq!(response[0], 0x7F);
        drop(tls_stream);

        let connection_id = assert_accepted_connection(&mut receiver).await;
        assert!(connection_id.0 > 0);

        let required_cfg = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"native",
                "max_rawsocket_size_exponent":16,
                "sni_certificates":[{
                    "hostname":"localhost",
                    "certificate_chain_pem":tls.server_chain_pem,
                    "private_key_pem":tls.server_key_pem
                }],
                "client_auth": {
                    "mode":"required",
                    "ca_certificates_pem":tls.ca_pem
                }
            }]
        });
        let bytes = serde_json::to_vec(&required_cfg).unwrap();
        let applied = super::apply_router_config(&bytes);
        assert!(applied.is_ok());
        reload_tls().unwrap();

        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        match connector
            .connect(ServerName::try_from("localhost").unwrap(), tcp)
            .await
        {
            Ok(mut stream) => {
                let result = stream.write_all(&[0x7F, handshake_byte, 0x00, 0x00]).await;
                if result.is_ok() {
                    let mut buf = [0u8; 4];
                    let read = stream.read_exact(&mut buf).await;
                    assert!(read.is_err(), "expected client auth failure");
                }
            }
            Err(_) => {}
        }

        let timeout = tokio::time::timeout(Duration::from_millis(150), receiver.recv()).await;
        assert!(timeout.is_err(), "unexpected connection delivered");

        let client_connector = build_tls_connector(
            &tls.ca_pem,
            Some(&tls.client_chain_pem),
            Some(&tls.client_key_pem),
        );
        let tcp = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut tls_stream = client_connector
            .connect(ServerName::try_from("localhost").unwrap(), tcp)
            .await
            .unwrap();
        tls_stream
            .write_all(&[0x7F, handshake_byte, 0x00, 0x00])
            .await
            .unwrap();
        let read = tls_stream.read_exact(&mut response).await;
        assert!(read.is_ok());
        assert_eq!(response[0], 0x7F);
        drop(tls_stream);

        let connection_id = assert_accepted_connection(&mut receiver).await;
        assert!(connection_id.0 > 0);
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connection_runtime_config_exposes_rawsocket_settings() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","max_rawsocket_size_exponent":30}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        perform_handshake(&mut stream, 24, Some(30)).await;

        let connection_id = assert_accepted_connection(&mut receiver).await;
        let config = connection_runtime_config(connection_id).expect("config available");
        assert_eq!(config.max_rawsocket_size_exponent, 30);
        assert_eq!(config.max_rawsocket_size, 1u64 << 30);
        assert_eq!(config.handshake_timeout, config::DEFAULT_HANDSHAKE_TIMEOUT);
        assert_eq!(
            connection_rawsocket_max_exponent(connection_id).unwrap(),
            30
        );

        let missing_err =
            connection_runtime_config(ConnectionId(9999)).expect_err("missing connection handled");
        assert!(matches!(
            missing_err,
            Error::ConnectionNotFound(ConnectionId(_))
        ));
        drop(stream);
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connect_rawsocket_registers_outbound_client_connection() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","max_rawsocket_size_exponent":30}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connected = connect_rawsocket(
            "127.0.0.1",
            addr.port(),
            false,
            false,
            RawSocketSerializer::Json,
            30,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let client_connection_id = connected.unwrap();
        let server_connection_id = assert_accepted_connection(&mut receiver).await;

        assert_eq!(
            connection_rawsocket_max_exponent(client_connection_id).unwrap(),
            30
        );
        assert_eq!(
            connection_rawsocket_max_exponent(server_connection_id).unwrap(),
            30
        );

        send_wamp_message(
            client_connection_id,
            Bytes::from_static(br#"[1,"realm",{}]"#),
        )
        .unwrap();
        let server_message = wait_for_polled_message(server_connection_id).await;
        match server_message.message {
            WampMessage::Hello { realm, .. } => assert_eq!(realm, "realm"),
            other => panic!("unexpected server message: {other:?}"),
        }

        send_wamp_message(server_connection_id, Bytes::from_static(br#"[2,4242,{}]"#)).unwrap();
        let client_message = wait_for_polled_message(client_connection_id).await;
        match client_message.message {
            WampMessage::Welcome { session_id, .. } => assert_eq!(session_id, 4242),
            other => panic!("unexpected client message: {other:?}"),
        }

        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn rawsocket_base64_file_segment_preserves_json_wire_bytes() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","max_rawsocket_size_exponent":30}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connected = connect_rawsocket(
            "127.0.0.1",
            addr.port(),
            false,
            false,
            RawSocketSerializer::Json,
            30,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let client_connection_id = connected.unwrap();
        let server_connection_id = assert_accepted_connection(&mut receiver).await;

        let file_bytes = (0..BASE64_FILE_SEGMENT_INPUT_SIZE + 7)
            .map(|index| (index % 251) as u8)
            .collect::<Vec<_>>();
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-json-file-{}-{nonce}.bin",
            std::process::id()
        ));
        std::fs::write(&path, &file_bytes).unwrap();
        let file = Arc::new(File::open(&path).unwrap());
        let prefix = Bytes::from_static(br#"[48,1,{},"files.set",["\u0000"#);
        let suffix = Bytes::from_static(b"\"]]");
        let metrics_before = file_segment_metrics_snapshot();

        for len in [0, 1, 2, 3, BASE64_FILE_SEGMENT_INPUT_SIZE + 7] {
            send_wamp_base64_file_segment(
                client_connection_id,
                prefix.clone(),
                Arc::clone(&file),
                0,
                len,
                suffix.clone(),
            )
            .unwrap();

            let parsed = wait_for_polled_message(server_connection_id).await;
            assert!(matches!(parsed.message, WampMessage::Call { .. }));
            let encoded = Base64Engine.encode(&file_bytes[..len]);
            let expected = [prefix.as_ref(), encoded.as_bytes(), suffix.as_ref()].concat();
            assert_eq!(parsed.raw.into_bytes().as_ref(), expected.as_slice());
        }
        let metrics_after = file_segment_metrics_snapshot();
        let expected_source_bytes = (1 + 2 + 3 + BASE64_FILE_SEGMENT_INPUT_SIZE + 7) as u64;
        assert!(
            metrics_after.buffered_file_segment_calls_total
                >= metrics_before.buffered_file_segment_calls_total + 4
        );
        assert!(
            metrics_after.buffered_file_segment_bytes_total
                >= metrics_before.buffered_file_segment_bytes_total + expected_source_bytes
        );

        std::fs::remove_file(path).unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connect_rawsocket_standard_cbor_peer_uses_extended_router_endpoint() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","max_rawsocket_size_exponent":30}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connected = connect_rawsocket(
            "127.0.0.1",
            addr.port(),
            false,
            false,
            RawSocketSerializer::Cbor,
            24,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let client_connection_id = connected.unwrap();
        send_wamp_message(
            client_connection_id,
            Bytes::from_static(&[0x83, 0x01, 0x65, b'r', b'e', b'a', b'l', b'm', 0xa0]),
        )
        .unwrap();

        let server_connection_id = assert_accepted_connection(&mut receiver).await;
        assert_eq!(
            connection_rawsocket_max_exponent(client_connection_id).unwrap(),
            24
        );
        assert_eq!(
            connection_rawsocket_max_exponent(server_connection_id).unwrap(),
            24
        );

        let server_message = wait_for_polled_message(server_connection_id).await;
        assert!(matches!(server_message.message, WampMessage::Hello { .. }));
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connect_rawsocket_supports_native_tls_client_connections() {
        let _guard = test_guard();
        shutdown().ok();
        let cert_pem = include_str!("../../../bench/bench_tls.crt");
        let key_pem = include_str!("../../../bench/bench_tls.key");
        let config = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"native",
                "max_rawsocket_size_exponent":24,
                "sni_certificates":[{
                    "hostname":"localhost",
                    "certificate_chain_pem":cert_pem,
                    "private_key_pem":key_pem
                }]
            }]
        });
        let applied = super::apply_router_config(&serde_json::to_vec(&config).unwrap());
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connected = connect_rawsocket(
            "localhost",
            addr.port(),
            true,
            true,
            RawSocketSerializer::Json,
            24,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let client_connection_id = connected.unwrap();
        let server_connection_id = assert_accepted_connection(&mut receiver).await;
        let tls_plaintext_before =
            transport_copy_metrics_snapshot().tls_plaintext_accepted_bytes_total;
        let rustls_copies_before = rustls_copy_metrics_snapshot();

        assert!(connection_supports_file_segments(client_connection_id).unwrap());
        assert!(connection_supports_file_segments(server_connection_id).unwrap());

        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-tls-file-{}-{nonce}.bin",
            std::process::id()
        ));
        let realm_bytes = vec![b'r'; FILE_SEGMENT_BUFFER_SIZE + 7];
        std::fs::write(&path, &realm_bytes).unwrap();
        let file = Arc::new(File::open(&path).unwrap());
        send_wamp_file_segment(
            client_connection_id,
            Bytes::from_static(b"[1,\""),
            file,
            0,
            realm_bytes.len(),
            Bytes::from_static(b"\",{}]"),
        )
        .unwrap();
        let server_message = wait_for_polled_message(server_connection_id).await;
        match server_message.message {
            WampMessage::Hello { realm, .. } => {
                assert_eq!(realm.len(), realm_bytes.len());
                assert!(realm.bytes().all(|byte| byte == b'r'));
            }
            other => panic!("unexpected tls server message: {other:?}"),
        }
        let tls_plaintext_after =
            transport_copy_metrics_snapshot().tls_plaintext_accepted_bytes_total;
        assert!(
            tls_plaintext_after > tls_plaintext_before,
            "Rustls must report plaintext accepted after the handshake"
        );
        let rustls_copies_after = rustls_copy_metrics_snapshot();
        assert!(
            rustls_copies_after.outbound_chunk_copy_bytes
                > rustls_copies_before.outbound_chunk_copy_bytes,
            "the real native TLS send must observe outbound chunk copies"
        );
        assert!(
            rustls_copies_after.record_append_copy_bytes
                > rustls_copies_before.record_append_copy_bytes,
            "the real native TLS records must observe appended bytes"
        );

        std::fs::remove_file(path).unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn native_tls_rawsocket_flushes_concurrent_file_frame_tails() {
        let _guard = test_guard();
        shutdown().ok();
        let cert_pem = include_str!("../../../bench/bench_tls.crt");
        let key_pem = include_str!("../../../bench/bench_tls.key");
        let config = json!({
            "schema":"connectanum.router",
            "version":1,
            "endpoints":[{
                "host":"127.0.0.1",
                "port":0,
                "tls_mode":"native",
                "max_rawsocket_size_exponent":24,
                "sni_certificates":[{
                    "hostname":"localhost",
                    "certificate_chain_pem":cert_pem,
                    "private_key_pem":key_pem
                }]
            }]
        });
        let applied = super::apply_router_config(&serde_json::to_vec(&config).unwrap());
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connected = connect_rawsocket(
            "localhost",
            addr.port(),
            true,
            true,
            RawSocketSerializer::Json,
            24,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let first_client = connected.unwrap();
        let first_server = assert_accepted_connection(&mut receiver).await;
        let connected = connect_rawsocket(
            "localhost",
            addr.port(),
            true,
            true,
            RawSocketSerializer::Json,
            24,
            None,
            None,
        );
        assert_eq!(connected.is_ok(), true, "{connected:?}");
        let second_client = connected.unwrap();
        let second_server = assert_accepted_connection(&mut receiver).await;

        const FRAME_COUNT: usize = 8;
        const FRAME_BYTES: usize = 8 * 1024 * 1024;
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-tls-concurrent-file-{}-{nonce}.bin",
            std::process::id()
        ));
        std::fs::write(&path, vec![b'r'; FRAME_BYTES]).unwrap();
        let file = Arc::new(File::open(&path).unwrap());

        for _ in 0..FRAME_COUNT {
            for connection_id in [first_client, second_client] {
                send_wamp_file_segment(
                    connection_id,
                    Bytes::from_static(b"[1,\""),
                    Arc::clone(&file),
                    0,
                    FRAME_BYTES,
                    Bytes::from_static(b"\",{}]"),
                )
                .unwrap();
            }
        }

        for connection_id in [first_server, second_server] {
            for _ in 0..FRAME_COUNT {
                let parsed = wait_for_polled_message(connection_id).await;
                match parsed.message {
                    WampMessage::Hello { realm, .. } => {
                        assert_eq!(realm.len(), FRAME_BYTES);
                        assert!(realm.bytes().all(|byte| byte == b'r'));
                    }
                    other => panic!("unexpected tls server message: {other:?}"),
                }
            }
        }

        std::fs::remove_file(path).unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn positional_file_reads_do_not_share_or_change_the_file_cursor() {
        use std::io::{Seek, SeekFrom};

        let file_bytes = (0..256 * 1024)
            .map(|index| (index % 251) as u8)
            .collect::<Vec<_>>();
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-positional-read-{}-{nonce}.bin",
            std::process::id()
        ));
        std::fs::write(&path, &file_bytes).unwrap();
        let mut file = File::open(&path).unwrap();
        file.seek(SeekFrom::Start(11)).unwrap();
        let file = Arc::new(file);
        let mut first = Vec::new();
        let mut second = Vec::new();

        let (first_result, second_result) = tokio::join!(
            read_file_chunk_at(&file, 17, 64 * 1024, &mut first),
            read_file_chunk_at(&file, 128 * 1024 + 23, 64 * 1024, &mut second),
        );
        first_result.unwrap();
        second_result.unwrap();
        assert_eq!(first.as_slice(), &file_bytes[17..17 + 64 * 1024]);
        assert_eq!(
            second.as_slice(),
            &file_bytes[128 * 1024 + 23..128 * 1024 + 23 + 64 * 1024]
        );

        let mut file = Arc::try_unwrap(file).unwrap();
        assert_eq!(file.stream_position().unwrap(), 11);
        std::fs::remove_file(path).unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_file_backed_frame_round_trips_from_masked_client() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["websocket"]}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connect = tokio::task::spawn_blocking(move || {
            connect_websocket(
                "127.0.0.1",
                addr.port(),
                "/wamp",
                false,
                false,
                RawSocketSerializer::MessagePack,
                &[],
                None,
                None,
            )
        });

        let server_connection_id = assert_accepted_connection(&mut receiver).await;
        let handshake = connection_take_websocket_handshake(server_connection_id).unwrap();
        connection_accept_websocket(
            server_connection_id,
            handshake,
            RawSocketSerializer::MessagePack,
            Some("wamp.2.msgpack"),
        )
        .unwrap();
        let client_connection_id = connect.await.unwrap().unwrap();

        assert!(connection_supports_file_segments(client_connection_id).unwrap());
        assert!(connection_supports_file_segments(server_connection_id).unwrap());

        let file_bytes = (0..FILE_SEGMENT_BUFFER_SIZE + 7)
            .map(|index| (index % 251) as u8)
            .collect::<Vec<_>>();
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-websocket-file-{}-{nonce}.bin",
            std::process::id()
        ));
        std::fs::write(&path, &file_bytes).unwrap();
        let file = Arc::new(File::open(&path).unwrap());

        let mut prefix = vec![0x96, 0x30, 0x01, 0x80, 0xa9];
        prefix.extend_from_slice(b"files.set");
        prefix.extend_from_slice(&[0x91, 0xc6]);
        prefix.extend_from_slice(&(file_bytes.len() as u32).to_be_bytes());
        let suffix = Bytes::from_static(&[0x81, 0xa4, b'd', b'o', b'n', b'e', 0xc3]);
        let expected = [prefix.as_slice(), file_bytes.as_slice(), suffix.as_ref()].concat();
        send_wamp_file_segment(
            client_connection_id,
            Bytes::from(prefix),
            file,
            0,
            file_bytes.len(),
            suffix,
        )
        .unwrap();

        let parsed = wait_for_polled_message(server_connection_id).await;
        match &parsed.message {
            WampMessage::Call {
                request_id,
                procedure,
                ..
            } => {
                assert_eq!(*request_id, 1);
                assert_eq!(procedure, "files.set");
            }
            other => panic!("unexpected websocket file message: {other:?}"),
        }
        assert_eq!(parsed.raw.into_bytes().as_ref(), expected.as_slice());

        std::fs::remove_file(path).unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_base64_file_segment_round_trips_from_masked_client() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["websocket"]}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connect = tokio::task::spawn_blocking(move || {
            connect_websocket(
                "127.0.0.1",
                addr.port(),
                "/wamp",
                false,
                false,
                RawSocketSerializer::Json,
                &[],
                None,
                None,
            )
        });
        let server_connection_id = assert_accepted_connection(&mut receiver).await;
        let handshake = connection_take_websocket_handshake(server_connection_id).unwrap();
        connection_accept_websocket(
            server_connection_id,
            handshake,
            RawSocketSerializer::Json,
            Some("wamp.2.json"),
        )
        .unwrap();
        let client_connection_id = connect.await.unwrap().unwrap();

        let file_bytes = (0..BASE64_FILE_SEGMENT_INPUT_SIZE + 7)
            .map(|index| (index % 251) as u8)
            .collect::<Vec<_>>();
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "connectanum-websocket-json-file-{}-{nonce}.bin",
            std::process::id()
        ));
        std::fs::write(&path, &file_bytes).unwrap();
        let file = Arc::new(File::open(&path).unwrap());
        let prefix = Bytes::from_static(br#"[48,1,{},"files.set",["\u0000"#);
        let suffix = Bytes::from_static(b"\"]]");
        let encoded = Base64Engine.encode(&file_bytes);
        let expected = [prefix.as_ref(), encoded.as_bytes(), suffix.as_ref()].concat();

        send_wamp_base64_file_segment(
            client_connection_id,
            prefix,
            file,
            0,
            file_bytes.len(),
            suffix,
        )
        .unwrap();

        let parsed = wait_for_polled_message(server_connection_id).await;
        assert!(matches!(parsed.message, WampMessage::Call { .. }));
        assert_eq!(parsed.raw.into_bytes().as_ref(), expected.as_slice());

        std::fs::remove_file(path).unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connect_websocket_registers_outbound_client_connection() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["websocket"]}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let connect = tokio::task::spawn_blocking(move || {
            connect_websocket(
                "127.0.0.1",
                addr.port(),
                "/wamp",
                false,
                false,
                RawSocketSerializer::Json,
                &[("X-Test".to_string(), "1".to_string())],
                None,
                None,
            )
        });

        let server_connection_id = assert_accepted_connection(&mut receiver).await;
        let handshake = connection_take_websocket_handshake(server_connection_id).unwrap();
        assert_eq!(handshake.http.request.header("X-Test"), Some("1"));
        assert!(handshake
            .sec_websocket_protocols
            .iter()
            .any(|value| value == "wamp.2.json"));
        connection_accept_websocket(
            server_connection_id,
            handshake,
            RawSocketSerializer::Json,
            Some("wamp.2.json"),
        )
        .unwrap();

        let client_connection_id = connect.await.unwrap().unwrap();
        assert_eq!(
            connection_websocket_protocol(client_connection_id).unwrap(),
            Some("wamp.2.json".to_string())
        );

        send_wamp_message(
            client_connection_id,
            Bytes::from_static(br#"[1,"realm",{}]"#),
        )
        .unwrap();
        let server_message = wait_for_polled_message(server_connection_id).await;
        match server_message.message {
            WampMessage::Hello { realm, .. } => assert_eq!(realm, "realm"),
            other => panic!("unexpected websocket server message: {other:?}"),
        }

        send_wamp_message(server_connection_id, Bytes::from_static(br#"[2,5150,{}]"#)).unwrap();
        let client_message = wait_for_polled_message(client_connection_id).await;
        match client_message.message {
            WampMessage::Welcome { session_id, .. } => assert_eq!(session_id, 5150),
            other => panic!("unexpected websocket client message: {other:?}"),
        }

        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn close_connection_sends_websocket_close_frame_for_outbound_client() {
        let _guard = test_guard();
        shutdown().ok();
        start_runtime().unwrap();

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let (socket, _) = listener.accept().await.unwrap();
            let mut stream = IoStream::plain(socket);
            let headers = read_http_header_block(&mut stream, Duration::from_secs(1))
                .await
                .unwrap();
            let header_text = std::str::from_utf8(&headers).unwrap();
            let key = header_text
                .split("\r\n")
                .find_map(|line| {
                    let (name, value) = line.split_once(':')?;
                    if name.eq_ignore_ascii_case("sec-websocket-key") {
                        Some(value.trim().to_string())
                    } else {
                        None
                    }
                })
                .expect("sec-websocket-key present");
            let accept = websocket_accept_value(&key);
            write_websocket_handshake_response(&mut stream, &accept, Some("wamp.2.json"))
                .await
                .unwrap();
            let (mut reader, _) = tokio::io::split(stream);
            let pool = Arc::new(WebSocketBufferPool::default());
            let close_frame = time::timeout(
                Duration::from_secs(1),
                read_websocket_frame(&mut reader, &pool),
            )
            .await
            .expect("close frame arrives in time")
            .unwrap();
            match close_frame {
                WebSocketFrame::Close(code, reason) => {
                    assert_eq!(code, Some(1000));
                    assert!(reason.is_empty());
                }
                other => panic!("unexpected websocket frame: {other:?}"),
            }
        });

        let client_connection_id = tokio::task::spawn_blocking(move || {
            connect_websocket(
                "127.0.0.1",
                addr.port(),
                "/wamp",
                false,
                false,
                RawSocketSerializer::Json,
                &[],
                None,
                None,
            )
        })
        .await
        .unwrap()
        .unwrap();

        close_connection(client_connection_id).unwrap();
        server.await.unwrap();
        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn connection_messages_can_be_polled() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","max_rawsocket_size_exponent":16}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        perform_handshake(&mut client, 16, None).await;
        let hello = json!([1, "realm", {"roles": {"dealer": {}}}]);
        let payload = serde_json::to_vec(&hello).unwrap();
        send_json_frame(&mut client, &payload).await;

        let connection_id = assert_accepted_connection(&mut receiver).await;

        let mut attempts = 0;
        let parsed = loop {
            if let Some(msg) = poll_connection_message(connection_id).expect("poll succeeds") {
                break msg;
            }
            attempts += 1;
            if attempts > 20 {
                panic!("message not delivered in time");
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        };

        match parsed.message {
            WampMessage::Hello { realm, .. } => assert_eq!(realm, "realm"),
            other => panic!("unexpected message: {:?}", other),
        }

        shutdown().unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn handshake_timeout_rejects_idle_clients() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled","handshake_timeout_ms":100,"max_rawsocket_size_exponent":16}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let addr = local_addr(listener_id).unwrap();
        let mut receiver = accept_channel(listener_id).unwrap();

        let stream = tokio::net::TcpStream::connect(addr).await.unwrap();
        // Intentionally do not send handshake bytes.
        tokio::time::sleep(Duration::from_millis(150)).await;
        drop(stream);

        assert!(matches!(receiver.try_recv(), Err(TryRecvError::Empty)));
        shutdown().unwrap();
    }

    async fn wait_for_polled_message(connection_id: ConnectionId) -> super::ParsedMessage {
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            match poll_connection_message(connection_id).unwrap() {
                Some(message) => return message,
                None if Instant::now() < deadline => {
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
                None => panic!("timed out waiting for message on {connection_id:?}"),
            }
        }
    }

    async fn perform_handshake(
        stream: &mut tokio::net::TcpStream,
        exponent: u32,
        upgrade: Option<u32>,
    ) {
        let clamped = exponent.clamp(9, 24);
        let handshake_byte = ((clamped - 9) as u8).min(15) << 4 | 0x01;
        stream
            .write_all(&[0x7F, handshake_byte, 0x00, 0x00])
            .await
            .expect("handshake write");
        let mut response = [0u8; 4];
        let read = stream.read_exact(&mut response).await;
        assert_eq!(read.is_ok(), true, "{read:?}");
        assert_eq!(response[0], 0x7F);
        if let Some(upgrade_exponent) = upgrade {
            let nibble = (upgrade_exponent.saturating_sub(25)).min(15) as u8;
            stream
                .write_all(&[0x3F, nibble])
                .await
                .expect("upgrade request");
            let mut upgrade_response = [0u8; 2];
            let read = stream.read_exact(&mut upgrade_response).await;
            assert_eq!(read.is_ok(), true, "{read:?}");
            assert_eq!(upgrade_response[0], 0x3F);
        }
    }

    async fn send_json_frame(stream: &mut tokio::net::TcpStream, payload: &[u8]) {
        assert!(payload.len() <= super::MAX_FRAME_LEN as usize);
        let mut header = [0u8; 4];
        if payload.len() == super::MAX_FRAME_LEN as usize {
            header[0] = 0x08;
        } else {
            header[0] = 0x00;
            header[1] = ((payload.len() >> 16) & 0xFF) as u8;
            header[2] = ((payload.len() >> 8) & 0xFF) as u8;
            header[3] = (payload.len() & 0xFF) as u8;
        }
        stream.write_all(&header).await.unwrap();
        if !payload.is_empty() {
            stream.write_all(payload).await.unwrap();
        }
    }

    async fn read_websocket_frame_from_bytes(
        frame: &[u8],
    ) -> Result<WebSocketFrame, WebSocketFrameError> {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let payload = frame.to_vec();
        let pool = Arc::new(WebSocketBufferPool::default());

        let reader = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let io = IoStream::plain(stream);
            let (mut reader, _) = tokio::io::split(io);
            read_websocket_frame(&mut reader, &pool).await
        });

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        client.write_all(&payload).await.unwrap();
        client.shutdown().await.unwrap();

        reader.await.unwrap()
    }

    async fn write_websocket_frame_to_bytes(opcode: u8, segments: Vec<Bytes>) -> Vec<u8> {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let payload_len = segments.iter().map(Bytes::len).sum();

        let writer = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let io = IoStream::plain(stream);
            let (_, mut writer) = tokio::io::split(io);
            write_websocket_frame(&mut writer, opcode, payload_len, &segments)
                .await
                .unwrap();
        });

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut bytes = Vec::new();
        client.read_to_end(&mut bytes).await.unwrap();
        writer.await.unwrap();
        bytes
    }

    async fn write_websocket_frame_with_suffix_to_bytes(
        opcode: u8,
        segments: Vec<Bytes>,
        suffix_segments: Vec<Bytes>,
    ) -> Vec<u8> {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let payload_len = segments
            .iter()
            .chain(suffix_segments.iter())
            .map(Bytes::len)
            .sum();

        let writer = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let io = IoStream::plain(stream);
            let (_, mut writer) = tokio::io::split(io);
            let mut mask_scratch = Vec::new();
            write_websocket_frame_mode(
                &mut writer,
                opcode,
                payload_len,
                &segments,
                &suffix_segments,
                false,
                &mut mask_scratch,
            )
            .await
            .unwrap();
        });

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut bytes = Vec::new();
        client.read_to_end(&mut bytes).await.unwrap();
        writer.await.unwrap();
        bytes
    }

    async fn write_websocket_frame_client_to_bytes(opcode: u8, segments: Vec<Bytes>) -> Vec<u8> {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let payload_len = segments.iter().map(Bytes::len).sum();

        let writer = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let io = IoStream::plain(stream);
            let (_, mut writer) = tokio::io::split(io);
            write_websocket_frame_client(&mut writer, opcode, payload_len, &segments)
                .await
                .unwrap();
        });

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut bytes = Vec::new();
        client.read_to_end(&mut bytes).await.unwrap();
        writer.await.unwrap();
        bytes
    }

    async fn read_websocket_frames_from_bytes_mode(
        frame: &[u8],
        expect_masked: bool,
    ) -> Vec<WebSocketFrame> {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let payload = frame.to_vec();
        let pool = Arc::new(WebSocketBufferPool::default());

        let reader = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            let io = IoStream::plain(stream);
            let (mut reader, _) = tokio::io::split(io);
            let mut frames = Vec::new();
            loop {
                match read_websocket_frame_mode(&mut reader, &pool, expect_masked).await {
                    Ok(frame) => frames.push(frame),
                    Err(err) if err.is_peer_disconnect() => break frames,
                    Err(err) => panic!("unexpected websocket frame read error: {err}"),
                }
            }
        });

        let mut client = tokio::net::TcpStream::connect(addr).await.unwrap();
        client.write_all(&payload).await.unwrap();
        client.shutdown().await.unwrap();

        reader.await.unwrap()
    }

    #[test]
    fn websocket_buffer_pool_recycles_owner_backed_bytes() {
        let pool = Arc::new(WebSocketBufferPool::default());
        let mut buffer = pool.acquire(4);
        buffer.as_mut_slice().copy_from_slice(b"ping");
        let bytes = buffer.into_bytes();
        assert_eq!(pool.available_buffers(), 0);
        assert_eq!(bytes.as_ref(), b"ping");
        drop(bytes);
        assert_eq!(pool.available_buffers(), 1);
    }

    #[test]
    fn websocket_mask_xor_handles_offsets_and_vector_tails() {
        let mask = [0x13, 0x57, 0x9b, 0xdf];
        let lengths = [0, 1, 3, 4, 5, 15, 16, 17, 31, 32, 33, 127, 128, 4097];
        for offset in 0..8 {
            for len in lengths {
                let original = (0..len)
                    .map(|index| ((index * 37 + 11) & 0xff) as u8)
                    .collect::<Vec<_>>();
                let expected = original
                    .iter()
                    .enumerate()
                    .map(|(index, byte)| byte ^ mask[(offset + index) & 3])
                    .collect::<Vec<_>>();
                let mut actual = original.clone();

                xor_websocket_mask(&mut actual, &mask, offset);
                assert_eq!(actual, expected, "offset={offset}, len={len}");

                xor_websocket_mask(&mut actual, &mask, offset);
                assert_eq!(actual, original, "offset={offset}, len={len}");
            }
        }
    }

    #[test]
    fn websocket_accumulator_returns_single_frame_without_copy() {
        let pool = Arc::new(WebSocketBufferPool::default());
        let mut accumulator = WebSocketMessageAccumulator::new(pool);
        let payload = Bytes::from_static(b"single-frame");
        let ptr = payload.as_ptr();
        accumulator
            .push(0x1, true, payload)
            .expect("single websocket frame accepted");
        let assembled = accumulator.take_complete().expect("message assembled");
        match assembled {
            CompletedWebSocketMessage::Single(bytes) => {
                assert_eq!(bytes.as_ptr(), ptr);
                assert_eq!(bytes.as_ref(), b"single-frame");
            }
            CompletedWebSocketMessage::Segmented { .. } => {
                panic!("single websocket frame should stay single-segment")
            }
        }
    }

    #[tokio::test]
    async fn websocket_client_writer_masks_large_contiguous_payload_in_chunks() {
        let first = vec![0x41; WEBSOCKET_MASK_CHUNK_SIZE * 2 + 137];
        let second = vec![0x42; WEBSOCKET_MASK_CHUNK_SIZE + 19];
        let expected = [first.as_slice(), second.as_slice()].concat();
        let bytes =
            write_websocket_frame_client_to_bytes(0x2, vec![Bytes::from(expected.clone())]).await;
        let frame = read_websocket_frame_from_bytes(&bytes)
            .await
            .expect("masked client frame should decode");
        match frame {
            WebSocketFrame::Data {
                opcode,
                fin,
                payload,
            } => {
                assert_eq!(opcode, 0x2);
                assert!(fin);
                assert_eq!(payload.as_ref(), expected.as_slice());
            }
            other => panic!("expected websocket data frame, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn websocket_client_writer_masks_empty_payload() {
        let bytes = write_websocket_frame_client_to_bytes(0x2, vec![Bytes::new()]).await;
        let frame = read_websocket_frame_from_bytes(&bytes)
            .await
            .expect("masked empty client frame should decode");
        match frame {
            WebSocketFrame::Data {
                opcode,
                fin,
                payload,
            } => {
                assert_eq!(opcode, 0x2);
                assert!(fin);
                assert!(payload.is_empty());
            }
            other => panic!("expected websocket data frame, got {other:?}"),
        }
    }

    #[test]
    fn websocket_accumulator_keeps_fragment_handles_until_completion() {
        let pool = Arc::new(WebSocketBufferPool::default());
        let mut accumulator = WebSocketMessageAccumulator::new(Arc::clone(&pool));
        let first = Bytes::from_static(b"first-");
        let second = Bytes::from_static(b"second");
        let first_ptr = first.as_ptr();
        let second_ptr = second.as_ptr();
        accumulator
            .push(0x1, false, first)
            .expect("first fragment accepted");
        accumulator
            .push(0x0, true, second)
            .expect("continuation fragment accepted");
        let assembled = accumulator.take_complete().expect("message assembled");
        match assembled {
            CompletedWebSocketMessage::Single(_) => {
                panic!("fragmented websocket message should stay segmented until flatten")
            }
            CompletedWebSocketMessage::Segmented { segments, len } => {
                assert_eq!(len, 12);
                assert_eq!(segments.len(), 2);
                assert_eq!(segments[0].as_ptr(), first_ptr);
                assert_eq!(segments[1].as_ptr(), second_ptr);
                assert_eq!(pool.available_buffers(), 0);
            }
        }
    }

    #[test]
    fn websocket_fragmented_message_flattens_once_and_recycles_after_drop() {
        let pool = Arc::new(WebSocketBufferPool::default());
        let mut accumulator = WebSocketMessageAccumulator::new(Arc::clone(&pool));
        accumulator
            .push(0x1, false, Bytes::from_static(b"first-"))
            .expect("first fragment accepted");
        accumulator
            .push(0x0, true, Bytes::from_static(b"second"))
            .expect("continuation fragment accepted");
        let assembled = accumulator
            .take_complete()
            .expect("message assembled")
            .into_bytes(&pool);
        assert_eq!(assembled.as_ref(), b"first-second");
        assert_eq!(pool.available_buffers(), 0);
        drop(assembled);
        assert_eq!(pool.available_buffers(), 1);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_writer_serializes_segmented_payload() {
        let before = transport_copy_metrics_snapshot();
        let bytes = write_websocket_frame_to_bytes(
            0x1,
            vec![
                Bytes::from_static(b"hello"),
                Bytes::new(),
                Bytes::from_static(b"-world"),
            ],
        )
        .await;
        assert_eq!(
            bytes,
            [
                0x01, 0x05, b'h', b'e', b'l', b'l', b'o', 0x80, 0x06, b'-', b'w', b'o', b'r', b'l',
                b'd',
            ]
        );
        let after = transport_copy_metrics_snapshot();
        assert!(
            after.websocket_coalesce_copy_bytes_total - before.websocket_coalesce_copy_bytes_total
                >= 11
        );
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_writer_serializes_deferred_suffix_segments() {
        let bytes = write_websocket_frame_with_suffix_to_bytes(
            0x1,
            vec![Bytes::from_static(b"hello"), Bytes::from_static(b"-world")],
            vec![Bytes::from_static(b"!")],
        )
        .await;
        assert_eq!(
            bytes,
            [
                0x01, 0x05, b'h', b'e', b'l', b'l', b'o', 0x00, 0x06, b'-', b'w', b'o', b'r', b'l',
                b'd', 0x80, 0x01, b'!',
            ]
        );
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_client_writer_serializes_segmented_payload_as_continuations() {
        let before = transport_copy_metrics_snapshot();
        let bytes = write_websocket_frame_client_to_bytes(
            0x2,
            vec![
                Bytes::from_static(b"hello"),
                Bytes::new(),
                Bytes::from_static(b"-world"),
            ],
        )
        .await;
        let frames = read_websocket_frames_from_bytes_mode(&bytes, true).await;
        assert_eq!(frames.len(), 2);
        let after = transport_copy_metrics_snapshot();
        assert!(
            after.websocket_mask_copy_bytes_total - before.websocket_mask_copy_bytes_total >= 11
        );
        match &frames[0] {
            WebSocketFrame::Data {
                opcode,
                fin,
                payload,
            } => {
                assert_eq!(*opcode, 0x2);
                assert!(!fin);
                assert_eq!(payload.as_ref(), b"hello");
            }
            other => panic!("expected first segmented websocket data frame, got {other:?}"),
        }
        match &frames[1] {
            WebSocketFrame::Data {
                opcode,
                fin,
                payload,
            } => {
                assert_eq!(*opcode, 0x0);
                assert!(*fin);
                assert_eq!(payload.as_ref(), b"-world");
            }
            other => panic!("expected continuation websocket frame, got {other:?}"),
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_frame_requires_masking() {
        let frame = [0x81, 0x01, b'x'];
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("unmasked client frame rejected");
        assert_eq!(err.close_code(), Some(1002));
        assert!(err.to_string().contains("must be masked"));
        assert!(!err.is_peer_disconnect());
    }

    #[test]
    fn websocket_io_disconnects_are_classified_as_peer_shutdowns() {
        let err =
            WebSocketFrameError::io(io::Error::new(io::ErrorKind::UnexpectedEof, "early eof"));
        assert!(err.is_peer_disconnect());
        assert!(is_benign_socket_shutdown(io::ErrorKind::ConnectionReset));
        assert!(!is_benign_socket_shutdown(io::ErrorKind::InvalidData));
    }

    #[test]
    fn http2_accept_broken_pipe_is_classified_as_graceful_shutdown() {
        assert_eq!(
            classify_http2_accept_error_parts(false, Some(io::ErrorKind::BrokenPipe)),
            Http2AcceptErrorClass::BenignShutdown
        );
        assert_eq!(
            classify_http2_accept_error_parts(false, Some(io::ErrorKind::ConnectionReset)),
            Http2AcceptErrorClass::BenignShutdown
        );
        assert_eq!(
            classify_http2_accept_error_parts(true, Some(io::ErrorKind::BrokenPipe)),
            Http2AcceptErrorClass::GoAway
        );
        assert_eq!(
            classify_http2_accept_error_parts(false, Some(io::ErrorKind::InvalidData)),
            Http2AcceptErrorClass::ProtocolError
        );
    }

    #[test]
    fn http1_response_peer_disconnects_do_not_emit_error_diagnostics() {
        assert!(!should_log_http_response_send_error(
            io::ErrorKind::BrokenPipe
        ));
        assert!(!should_log_http_response_send_error(
            io::ErrorKind::ConnectionReset
        ));
        assert!(!should_log_http_response_send_error(
            io::ErrorKind::ConnectionAborted
        ));
        assert!(!should_log_http_response_send_error(
            io::ErrorKind::UnexpectedEof
        ));
        assert!(should_log_http_response_send_error(
            io::ErrorKind::InvalidData
        ));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_frame_rejects_reserved_bits() {
        let frame = [0xC1, 0x80, 0x00, 0x00, 0x00, 0x00];
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("reserved bits rejected");
        assert_eq!(err.close_code(), Some(1002));
        assert!(err.to_string().contains("reserved bits"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_frame_rejects_fragmented_control_frames() {
        let frame = [0x09, 0x81, 0x00, 0x00, 0x00, 0x00, b'x'];
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("fragmented ping rejected");
        assert_eq!(err.close_code(), Some(1002));
        assert!(err.to_string().contains("must not be fragmented"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_frame_rejects_oversized_control_payloads() {
        let mut frame = vec![0x89, 0xFE, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00];
        frame.extend(std::iter::repeat_n(0u8, 126));
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("oversized ping rejected");
        assert_eq!(err.close_code(), Some(1002));
        assert!(err.to_string().contains("must not exceed 125 bytes"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_frame_rejects_oversized_messages() {
        let len = super::MAX_WEBSOCKET_MESSAGE_LEN as u64 + 1;
        let mut frame = vec![0x82, 0xFF];
        frame.extend_from_slice(&len.to_be_bytes());
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("oversized websocket message rejected");
        assert_eq!(err.close_code(), Some(1009));
        assert!(err.to_string().contains("exceeds supported length"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_close_frame_rejects_single_byte_payload() {
        let frame = [0x88, 0x81, 0x00, 0x00, 0x00, 0x00, 0x01];
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("1-byte close payload rejected");
        assert_eq!(err.close_code(), Some(1002));
        assert!(err.to_string().contains("2-byte status code"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_close_frame_rejects_invalid_utf8_reason() {
        let frame = [0x88, 0x83, 0x00, 0x00, 0x00, 0x00, 0x03, 0xE8, 0xFF];
        let err = read_websocket_frame_from_bytes(&frame)
            .await
            .expect_err("invalid close reason rejected");
        assert_eq!(err.close_code(), Some(1007));
        assert!(err.to_string().contains("valid UTF-8"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn websocket_close_frame_allows_empty_payload() {
        let frame = [0x88, 0x80, 0x00, 0x00, 0x00, 0x00];
        let parsed = read_websocket_frame_from_bytes(&frame)
            .await
            .expect("empty close payload accepted");
        match parsed {
            WebSocketFrame::Close(None, reason) => assert!(reason.is_empty()),
            other => panic!("unexpected frame: {other:?}"),
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn accept_channel_only_once() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled"}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let listener = listen("127.0.0.1", 0, 128);
        assert!(listener.is_ok());
        let listener_id = listener.unwrap();
        let _receiver = accept_channel(listener_id).unwrap();
        let err = accept_channel(listener_id).expect_err("second take fails");
        assert!(matches!(
            err,
            Error::AcceptChannelAlreadyTaken(ListenerId(_))
        ));
        shutdown().unwrap();
    }

    #[test]
    fn listen_without_runtime_fails() {
        let _guard = test_guard();
        shutdown().ok();
        let err = listen("127.0.0.1", 0, 128).expect_err("runtime missing");
        assert!(matches!(err, Error::RuntimeNotStarted));
    }

    #[test]
    fn configured_ephemeral_listeners_preserve_identity_and_reload() {
        let _guard = test_guard();
        shutdown().ok();
        let config = br#"{"schema":"connectanum.router","version":1,"endpoints":[
          {"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["websocket"],"websocket_path":"/ws"},
          {"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["http"]}
        ]}"#;
        apply_router_config(config).unwrap();
        assert!(config::find_endpoint("127.0.0.1", 0).is_none());
        assert!(config::find_endpoint_at(2, "127.0.0.1", 0).is_none());
        assert!(config::find_endpoint_at(0, "localhost", 0).is_none());
        assert!(config::find_endpoint_at(0, "127.0.0.1", 1).is_none());
        start_runtime().unwrap();
        assert!(matches!(
            listen("127.0.0.1", 0, 128),
            Err(Error::EndpointNotConfigured(_, 0))
        ));
        assert!(listen_configured_endpoint("127.0.0.1", 0, 0, 0).is_err());
        assert!(listen_configured_endpoint("127.0.0.1", 0, 128, 2).is_err());
        let ws = listen_configured_endpoint("127.0.0.1", 0, 128, 0).unwrap();
        let http = listen_configured_endpoint("127.0.0.1", 0, 128, 1).unwrap();
        assert_ne!(
            local_addr(ws).unwrap().port(),
            local_addr(http).unwrap().port()
        );
        assert_eq!(reload_tls().unwrap(), 2);
        RuntimeManager::global()
            .with_state(|view| {
                let listeners = view.registry.listeners.lock().unwrap();
                assert_eq!(
                    listeners[&ws].config_state.endpoint_config().protocols,
                    vec![TransportProtocol::Websocket]
                );
                assert_eq!(
                    listeners[&http].config_state.endpoint_config().protocols,
                    vec![TransportProtocol::Http]
                );
                Ok(())
            })
            .unwrap();
        close_listener(ws).unwrap();
        let reopened = listen_configured_endpoint("127.0.0.1", 0, 128, 0).unwrap();
        assert_ne!(
            local_addr(reopened).unwrap().port(),
            local_addr(http).unwrap().port()
        );
        assert_eq!(reload_tls().unwrap(), 2);
        shutdown().unwrap();

        let invalid = br#"{"schema":"connectanum.router","version":1,"endpoints":[
          {"host":"LOCALHOST","port":8080,"tls_mode":"disabled"},
          {"host":"localhost","port":8080,"tls_mode":"disabled"}
        ]}"#;
        assert!(matches!(
            apply_router_config(invalid),
            Err(Error::RouterConfigInvalid(_))
        ));
        // Rejected replacement must leave the previous configuration intact.
        assert!(config::find_endpoint_at(1, "127.0.0.1", 0).is_some());
    }

    #[test]
    fn router_scoped_listeners_isolate_config_and_reload_failures() {
        let _guard = test_guard();
        shutdown().ok();
        let tls = generate_tls_material();
        let endpoint = json!({
            "host":"127.0.0.1", "port":0, "tls_mode":"native",
            "protocols":["rawsocket"], "max_rawsocket_size_exponent":16,
            "sni_certificates":[{
                "hostname":"localhost",
                "certificate_chain_pem":tls.server_chain_pem,
                "private_key_pem":tls.server_key_pem,
            }],
        });
        let mut cfg = json!({
            "schema":"connectanum.router", "version":1,
            "endpoints":[endpoint.clone(), endpoint.clone()],
        });
        let bytes = serde_json::to_vec(&cfg).unwrap();
        let sibling_cfg = br#"{"schema":"connectanum.router","version":1,"endpoints":[
          {"host":"127.0.0.1","port":0,"tls_mode":"disabled","protocols":["websocket"]}
        ]}"#;
        apply_router_config(sibling_cfg).unwrap();
        start_runtime().unwrap();
        let a = listen_router_endpoint(&bytes, 0, 128).unwrap();
        let a2 = listen_router_endpoint(&bytes, 1, 128).unwrap();
        let b = listen_router_endpoint(sibling_cfg, 0, 128).unwrap();
        let legacy = listen("127.0.0.1", 0, 128).unwrap();
        assert_ne!(local_addr(a).unwrap(), local_addr(b).unwrap());
        assert_eq!(reload_tls().unwrap(), 1);
        assert_eq!(reload_router_tls(&bytes, &[a, a2]).unwrap(), 2);

        let assert_config = |first_exponent| {
            RuntimeManager::global()
                .with_state(|view| {
                    let listeners = view.registry.listeners.lock().unwrap();
                    assert_eq!(
                        listeners[&a]
                            .config_state
                            .endpoint_config()
                            .max_rawsocket_size_exponent,
                        first_exponent
                    );
                    assert_eq!(
                        listeners[&a2]
                            .config_state
                            .endpoint_config()
                            .max_rawsocket_size_exponent,
                        16
                    );
                    assert_eq!(
                        listeners[&b].config_state.endpoint_config().protocols,
                        vec![TransportProtocol::Websocket]
                    );
                    Ok(())
                })
                .unwrap();
        };
        cfg["endpoints"][0]["max_rawsocket_size_exponent"] = json!(17);
        cfg["endpoints"][1]["sni_certificates"][0]["private_key_pem"] = json!("invalid key");
        let invalid = serde_json::to_vec(&cfg).unwrap();
        assert!(matches!(
            reload_router_tls(&invalid, &[a, a2]),
            Err(Error::RouterConfigInvalid(_))
        ));
        assert_config(16);
        cfg["endpoints"][1] = endpoint;
        let valid = serde_json::to_vec(&cfg).unwrap();
        for ids in [vec![a, a], vec![a, ListenerId(u32::MAX)], vec![a, legacy]] {
            assert!(reload_router_tls(&valid, &ids).is_err());
            assert_config(16);
        }
        assert!(reload_router_tls(sibling_cfg, &[a2]).is_err());
        assert_config(16);
        assert_eq!(reload_router_tls(&valid, &[a, a2]).unwrap(), 2);
        assert_config(17);
        assert_eq!(reload_router_tls(&valid, &[]).unwrap(), 0);
        assert!(listen_router_endpoint(&valid, 2, 128).is_err());
        assert!(listen_router_endpoint(&valid, 0, 0).is_err());
        close_listener(a).unwrap();
        assert!(matches!(
            reload_router_tls(&valid, &[a]),
            Err(Error::ListenerNotFound(_))
        ));
        assert_eq!(reload_router_tls(sibling_cfg, &[b]).unwrap(), 1);
        assert!(config::find_endpoint_at(0, "127.0.0.1", 0)
            .unwrap()
            .protocols
            .contains(&TransportProtocol::Websocket));
        shutdown().unwrap();
    }

    #[test]
    fn invalid_backlog_is_rejected() {
        let _guard = test_guard();
        shutdown().ok();
        let applied = super::apply_router_config(
            br#"{"schema":"connectanum.router","version":1,"endpoints":[{"host":"127.0.0.1","port":0,"tls_mode":"disabled"}]}"#,
        );
        assert!(applied.is_ok());
        start_runtime().unwrap();
        let err = listen("127.0.0.1", 0, 0).expect_err("invalid backlog");
        assert!(matches!(err, Error::InvalidBacklog));
        shutdown().unwrap();
    }

    #[test]
    fn unknown_listener_errors() {
        let _guard = test_guard();
        shutdown().ok();
        start_runtime().unwrap();
        let err = local_addr(ListenerId(999)).expect_err("missing listener");
        assert!(matches!(err, Error::ListenerNotFound(ListenerId(_))));
        shutdown().unwrap();
    }
}

#[cfg(test)]
mod flatbuffers_websocket_profile_tests {
    use super::*;
    #[test]
    fn websocket_profile_maps_flatbuffers_with_existing_encodings() {
        for (serializer, expected) in [
            (rawsocket::Serializer::Json, "wamp.2.json"),
            (rawsocket::Serializer::MessagePack, "wamp.2.msgpack"),
            (rawsocket::Serializer::Cbor, "wamp.2.cbor"),
            (rawsocket::Serializer::Flatbuffers, "wamp.2.flatbuffers"),
        ] {
            assert_eq!(websocket_subprotocol(serializer).unwrap(), expected);
        }
    }
}

#[cfg(test)]
mod connection_id_lifetime_tests {
    use super::*;

    #[tokio::test]
    async fn mqtt_id_gate_skips_registration_when_capacity_is_exhausted() {
        let accepted = AtomicU32::new(0);
        with_mqtt_connection_id(
            Err(Error::Io(io::Error::other("connection id exhausted"))),
            |id| {
                accepted.store(id.0, Ordering::SeqCst);
                std::future::ready(())
            },
        )
        .await;
        assert_eq!(accepted.load(Ordering::SeqCst), 0);

        with_mqtt_connection_id(Ok(ConnectionId(7)), |id| {
            accepted.store(id.0, Ordering::SeqCst);
            std::future::ready(())
        })
        .await;
        assert_eq!(accepted.load(Ordering::SeqCst), 7);
    }

    #[test]
    fn recreated_registries_cannot_reuse_connection_ids() {
        let first = ListenerRegistry::default().next_connection_id().unwrap();
        let second = ListenerRegistry::default().next_connection_id().unwrap();
        assert!(second.0 > first.0);
    }

    #[test]
    fn connection_ids_stop_at_the_positive_ffi_boundary() {
        let sequence = AtomicU32::new(i32::MAX as u32);
        assert_eq!(
            allocate_connection_id(&sequence).unwrap(),
            ConnectionId(i32::MAX as u32)
        );
        assert!(allocate_connection_id(&sequence).is_err());
        assert!(allocate_connection_id(&sequence).is_err());
        assert_eq!(sequence.load(Ordering::SeqCst), i32::MAX as u32 + 1);
    }

    #[test]
    fn invalid_connection_id_sequences_never_wrap_or_advance() {
        for value in [0, i32::MAX as u32 + 1, u32::MAX] {
            let sequence = AtomicU32::new(value);
            assert!(allocate_connection_id(&sequence).is_err());
            assert_eq!(sequence.load(Ordering::SeqCst), value);
        }
    }

    #[test]
    fn concurrent_connection_allocations_are_unique() {
        let sequence = Arc::new(AtomicU32::new(1));
        let workers: Vec<_> = (0..8)
            .map(|_| {
                let sequence = Arc::clone(&sequence);
                std::thread::spawn(move || {
                    (0..64)
                        .map(|_| allocate_connection_id(&sequence).unwrap().0)
                        .collect::<Vec<_>>()
                })
            })
            .collect();
        let mut ids: Vec<_> = workers
            .into_iter()
            .flat_map(|worker| worker.join().unwrap())
            .collect();
        ids.sort_unstable();
        assert_eq!(ids, (1..=512).collect::<Vec<_>>());
    }
}
