from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import tempfile
import unittest
from unittest.mock import patch

import native_perf_input_census as census


def digest(data):
    return hashlib.sha256(data).hexdigest()


class InputCensusTests(unittest.TestCase):
    """OWN tiny synthetic files only. Never executes ELF/RLIB, builds or admits data."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ct-input-census-', dir='/tmp')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.root.chmod(0o700)
        self.addCleanup(self.retain_fixture)
        self.files = {}
        def put(role, data):
            path = self.root / (role.replace('/', '-') + '.fixture')
            path.write_bytes(data)
            path.chmod(0o600)
            self.files[role] = {'path': str(path), 'sha256': digest(data)}
        self.put = put
        for role in ('source_archive', 'canonical_log', 'canonical_native', 'production_log'):
            put(role, ('OWN synthetic ' + role).encode())
        elf = bytearray(64)
        elf[:7] = b'\x7fELF\x02\x01\x01'
        struct.pack_into('<HHI', elf, 16, 3, 62, 1)
        struct.pack_into('<H', elf, 52, 64)
        put('native_elf', bytes(elf) + b'OWN native header fixture only')
        put('driver_elf', bytes(elf) + b'OWN driver header fixture only')
        put('static_rlib', b'!<arch>\nOWN rlib header fixture only')
        locks = {}
        for phase in ('canonical', 'execution'):
            locks[phase] = {}
            for lock in ('pub', 'transport', 'bench'):
                data = b'OWN shared pub fixture' if lock == 'pub' else ('OWN ' + phase + ' ' + lock).encode()
                role = phase + '/' + lock
                put(role, data)
                locks[phase][lock] = digest(data)
        for phase in ('canonical', 'execution'):
            put('config/' + phase, json.dumps({'configVersion': 2, 'packages': [], 'fixture': phase}).encode())
        self.context = census.CensusContext('b' * 32, 'a' * 40, '601108ea6216464bd00ae29c16cfaf0a59c71db6',
            os.geteuid(), 62, locks, {'canonical': '3.13.1', 'execution': '3.13.5'})
        self.bindings = {phase: {'server': 'config/' + phase, 'client': 'config/' + phase}
                         for phase in ('canonical', 'execution')}
        common = {'census_id': self.context.census_id, 'source_commit': self.context.source_commit,
                  'runtime_commit': self.context.runtime_commit,
                  'source_archive_sha256': self.files['source_archive']['sha256']}
        self.canonical = {**common, 'kind': 'own-canonical-v1', 'sdk': '3.13.1',
            'log_sha256': self.files['canonical_log']['sha256'], 'native_sha256': self.files['canonical_native']['sha256'],
            'lock_hashes': locks['canonical'], 'package_configs': {'server': self.files['config/canonical']['sha256'],
                'client': self.files['config/canonical']['sha256']},
            'commands': [{'argv': ['bin/verify'], 'exit': 0}]}
        self.production = {**common, 'kind': 'own-production-v1', 'sdk': '3.13.5',
            'log_sha256': self.files['production_log']['sha256'], 'lock_hashes': locks['execution'],
            'package_configs': {'server': self.files['config/execution']['sha256'],
                'client': self.files['config/execution']['sha256']},
            'outputs': {role: self.files[role]['sha256'] for role in ('native_elf', 'driver_elf', 'static_rlib')},
            'features': [], 'commands': [{'argv': ['cargo', 'build', '--release'], 'exit': 0}]}
        self.save_receipts()
        self.manifest = {'context': common | {'source_archive_sha256': common['source_archive_sha256']},
                         'files': self.files, 'bindings': self.bindings}
    def save_receipts(self):
        self.put('canonical_receipt', json.dumps(self.canonical, sort_keys=True).encode())
        self.put('production_receipt', json.dumps(self.production, sort_keys=True).encode())
    def verify(self):
        return census.verify_census(self.manifest, self.context)
    def retain_fixture(self):
        target = os.environ.get('CONNECTANUM_PERF_CENSUS_FIXTURE_EVIDENCE')
        if target:
            destination = Path(target) / self._testMethodName
            inventory = {str(p.relative_to(self.root)): {'mode': p.lstat().st_mode,
                         'device': p.lstat().st_dev, 'inode': p.lstat().st_ino}
                         for p in self.root.rglob('*')}
            def skip_special(directory, names):
                return [name for name in names if not (Path(directory, name).is_dir()
                    or Path(directory, name).is_symlink() or stat.S_ISREG(Path(directory, name).lstat().st_mode))]
            shutil.copytree(self.root, destination, symlinks=True, ignore=skip_special)
            (destination / 'fixture-node-inventory.json').write_text(json.dumps(inventory))
            if hasattr(self, 'manifest'):
                (destination / 'fixture-manifest.json').write_text(json.dumps(self.manifest, indent=2))
    def test_valid_files_are_checks_only_not_live_admission(self):
        result = self.verify()
        self.assertEqual(result.scope, 'file_checks_only')
        self.assertFalse(hasattr(result, 'ready'))
        self.assertEqual(result.files['native_elf']['sha256'], self.files['native_elf']['sha256'])
        self.assertEqual(result.bindings['execution']['server'], result.bindings['execution']['client'])
    def test_fifo_refuses_without_blocking_or_reading(self):
        p = Path(self.files['native_elf']['path'])
        p.rename(self.root / 'native-original')
        os.mkfifo(p, 0o600)
        with self.assertRaisesRegex(census.CensusError, 'regular'):
            self.verify()
        self.assertTrue(p.is_fifo())
    def test_symlink_refuses_without_following(self):
        p = Path(self.files['native_elf']['path'])
        target = self.root / 'native-original'
        p.rename(target)
        p.symlink_to(target)
        with self.assertRaisesRegex(census.CensusError, 'symlink|canonical'):
            self.verify()
        self.assertTrue(p.is_symlink())
    def test_group_writable_input_refuses(self):
        Path(self.files['native_elf']['path']).chmod(0o620)
        with self.assertRaisesRegex(census.CensusError, 'permission'):
            self.verify()
    def test_empty_required_input_refuses(self):
        Path(self.files['static_rlib']['path']).write_bytes(b'')
        with self.assertRaisesRegex(census.CensusError, 'size'):
            self.verify()
    def test_conflicting_role_inode_alias_refuses(self):
        canonical = Path(self.files['canonical_log']['path'])
        production = Path(self.files['production_log']['path'])
        production.rename(self.root / 'production-log-original')
        os.link(canonical, production)
        self.files['production_log']['sha256'] = digest(production.read_bytes())
        self.production['log_sha256'] = self.files['production_log']['sha256']
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'alias'):
            self.verify()
    def test_shared_pub_lock_alias_is_explicit_and_keeps_both_cohorts(self):
        canonical = Path(self.files['canonical/pub']['path'])
        execution = Path(self.files['execution/pub']['path'])
        execution.rename(self.root / 'execution-pub-original')
        os.link(canonical, execution)
        result = self.verify()
        self.assertIn(('canonical/pub', 'execution/pub'), result.aliases)
        self.assertNotEqual(self.context.lock_hashes['canonical']['transport'], self.context.lock_hashes['execution']['transport'])
    def test_old_runtime_canonical_receipt_refuses_even_if_its_hash_is_declared(self):
        self.canonical['source_commit'] = self.context.runtime_commit
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'source|context'):
            self.verify()
    def test_wrong_census_nonce_refuses(self):
        self.production['census_id'] = 'd' * 32
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'context'):
            self.verify()
    def test_cross_cohort_lock_substitution_refuses(self):
        data = Path(self.files['canonical/transport']['path']).read_bytes()
        self.put('execution/transport', data)
        self.production['lock_hashes']['transport'] = digest(data)
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'cohort|lock'):
            self.verify()
    def test_canonical_log_truncation_cannot_be_hidden_by_manifest_rehash(self):
        data = b'truncated OWN log'
        self.put('canonical_log', data)
        with self.assertRaisesRegex(census.CensusError, 'log'):
            self.verify()
    def test_boolean_exit_is_not_zero_success(self):
        self.canonical['commands'][0]['exit'] = False
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'command|exit'):
            self.verify()
    def test_ffi_test_production_feature_refuses(self):
        self.production['features'] = ['ct_ffi/ffi-test']
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'ffi-test|production'):
            self.verify()
    def test_elf_machine_mismatch_refuses(self):
        data = bytearray(Path(self.files['native_elf']['path']).read_bytes())
        struct.pack_into('<H', data, 18, 183)
        self.put('native_elf', bytes(data))
        self.production['outputs']['native_elf'] = digest(data)
        self.save_receipts()
        with self.assertRaisesRegex(census.CensusError, 'ELF'):
            self.verify()
    def test_duplicate_json_key_is_retained_refusal(self):
        data = json.dumps(self.production).encode()
        data = data[:-1] + b',"kind":"own-production-v1"}'
        self.put('production_receipt', data)
        with self.assertRaisesRegex(census.CensusError, 'duplicate'):
            self.verify()
    def test_unknown_or_missing_roles_refuse(self):
        self.manifest['files'] = dict(self.files)
        del self.manifest['files']['static_rlib']
        with self.assertRaisesRegex(census.CensusError, 'role'):
            self.verify()
    def test_config_binding_cannot_point_at_a_log(self):
        self.bindings['execution']['client'] = 'production_log'
        with self.assertRaisesRegex(census.CensusError, 'config'):
            self.verify()
    def test_actual_file_mutation_during_read_refuses(self):
        target = Path(self.files['native_elf']['path'])
        inode = target.stat().st_ino
        original = os.read
        changed = []
        def mutate(fd, size):
            data = original(fd, size)
            if os.fstat(fd).st_ino == inode and not changed:
                changed.append(True)
                with target.open('ab') as out:
                    out.write(b'OWN mutation')
            return data
        with patch.object(census.os, 'read', side_effect=mutate):
            with self.assertRaisesRegex(census.CensusError, 'changed'):
                self.verify()
        self.assertTrue(changed)
