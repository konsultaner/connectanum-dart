require 'yaml'; require 'json'; require 'digest'
v=JSON.parse(File.read(ARGV[0])); base=File.binread(v.fetch('parent_path')); raise unless Digest::SHA256.hexdigest(base)==v.fetch('parent_sha256')
doc=YAML.load(base); jobs=doc.fetch('jobs'); raise unless jobs.size==15
oldkey='flatbuffers-c-runtime-transitive-inputs'; newkey='flatbuffers-c-tool-search-environment'; raise if jobs.key?(newkey)
job=jobs.fetch(oldkey); oldcollector=v.fetch('old_collector'); newcollector=v.fetch('new_collector')
scripts=job.fetch('steps').select{|s| s['run'].is_a?(String) && s['run'].include?(oldcollector)}; raise unless scripts.size==1
scripts[0]['run']=scripts[0]['run'].sub(oldcollector){newcollector}
def transform(x)
 case x
 when Hash; x.each_with_object({}){|(k,v),h| h[k]=transform(v)}
 when Array; x.map{|v|transform(v)}
 when String; x.gsub('flatbuffers_c_runtime_transitive_inputs','flatbuffers_c_tool_search_environment').gsub('flatbuffers-c-runtime-transitive-inputs','flatbuffers-c-tool-search-environment').gsub('native-perf-c-runtime-transitive-inputs','native-perf-c-tool-search-environment').gsub('FlatBuffers transitive C-runtime reference inputs (no execution)','FlatBuffers C-tool search environment inputs (no execution)')
 else;x
 end
end
job=transform(job); block=YAML.dump({newkey=>job}).sub(/\A---\s*\n/,'').lines.map{|l| '  '+l}.join
choice="          - flatbuffers_c_runtime_transitive_inputs\n"; raise unless base.scan(choice).size==1
addition="          - flatbuffers_c_tool_search_environment\n"; candidate=base.sub(choice){choice+addition}; candidate+="\n"+block
File.open(v.fetch('candidate_path'),'wb'){|f|f.write(candidate)}; File.open(v.fetch('job_block_path'),'wb'){|f|f.write(block)}
puts JSON.generate({'new_job_key'=>newkey,'parent_jobs'=>15,'new_job_count'=>16,'candidate_bytes'=>candidate.bytesize,'candidate_sha256'=>Digest::SHA256.hexdigest(candidate)})
