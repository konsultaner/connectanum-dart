require 'yaml';require 'json'
v=JSON.parse(File.read(ARGV[0]));old=YAML.load(File.read(v.fetch('parent_path')));fresh=YAML.load(File.read(v.fetch('candidate_path')))
oldjobs=old.fetch('jobs');newjobs=fresh.fetch('jobs');raise unless oldjobs.size==15 && newjobs.size==16
raise unless oldjobs.all?{|k,x|newjobs.fetch(k)==x}; job=newjobs.fetch('flatbuffers-c-tool-search-environment')
scripts=job.fetch('steps').select{|s|s['run'].is_a?(String) && s['run'].include?(v.fetch('new_collector'))};raise unless scripts.size==1
u=job.fetch('steps').select{|s| s['uses'].is_a?(String) && s['uses'].start_with?('actions/upload-artifact@')};raise unless u.size==1
raise unless u[0].fetch('with').fetch('path')=='${{ runner.temp }}/native-perf-c-tool-search-environment'
key=fresh.key?('on') ? 'on' : true;choices=fresh.fetch(key).fetch('workflow_dispatch').fetch('inputs').fetch('campaign').fetch('options');raise unless choices.count('flatbuffers_c_tool_search_environment')==1
puts JSON.generate({'old_jobs_unchanged'=>15,'new_job_count'=>16,'new_job_key'=>'flatbuffers-c-tool-search-environment','exact_collector_embedding'=>true,'explicit_runner_temp_uploader_sink_match'=>true,'YAML_pass'=>true})
