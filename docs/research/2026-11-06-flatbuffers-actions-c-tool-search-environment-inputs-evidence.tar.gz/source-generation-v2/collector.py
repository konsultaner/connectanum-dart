import hashlib
import json
import os
import pathlib
import sys
import time

references = ["GCC_EXEC_PREFIX","COMPILER_PATH","LIBRARY_PATH","LD_LIBRARY_PATH"]
root = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-c-tool-search-environment"
root.mkdir()
journal = open(root / "operations.jsonl", "x", encoding="utf-8")
owned = []

def event(operation, **fields):
    journal.write(json.dumps({"operation": operation, "monotonic_ns": time.monotonic_ns(),
                              **fields}, sort_keys=True) + "\n")
    journal.flush()

try:
    observations = []
    for name in references:
        present = name in os.environ
        observations.append({"source_environment_name": name,
                             "present_in_this_collector_environment": present,
                             "value": os.environ[name] if present else None,
                             "empty_value_when_present": os.environ[name] == "" if present else None})
        event("environment_name_observed", name=name, present=present)
    report = {
        "workflow_revision": os.environ["GITHUB_SHA"], "run_id": os.environ["GITHUB_RUN_ID"],
        "reference_basis": "ALL four environment names actually present in the selected configuration "
                           "text of retained original gcc/cc/ld candidates; no environment mutation "
                           "or native candidate/query execution.",
        "source_environment_names": references, "observations": observations,
        "collector_credentials": {"uid": os.getuid(), "gid": os.getgid(), "groups": os.getgroups()},
        "collector_cwd": os.getcwd(), "collector_argv": list(sys.argv),
        "collector_interpreter_reference": sys.executable,
        "native_information_queries": 0, "candidate_executions": 0, "environment_mutations": 0,
        "all_admission_flags": False,
        "qualification": "Only this collector process's four source-named environment inputs. "
                         "Absent and present-empty are distinct point observations. Not global absence, "
                         "effective Cargo/target/linker/default compiler/header or sysroot resolution, "
                         "actual compiler-build defaults, original driver credentials/argv/environment, "
                         "loaded-runtime/ABI/cohort/transitive actor FD/continuous physical EX/crash admission. "
                         "No build, bootstrap, dependency resolution, driver, broker, profiler, benchmark "
                         "or numerical campaign; actual Actions setup is separate and unadmitted."
    }
    raw = (json.dumps(report, sort_keys=True, indent=2) + "\n").encode()
    path = root / "c-tool-search-environment.json"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    owned.append(fd)
    try:
        event("report_open_return_before_write", fd=fd, path=str(path))
        offset = 0
        while offset < len(raw):
            event("report_write_attempt", fd=fd, offset=offset, requested_bytes=len(raw)-offset)
            count = os.write(fd, raw[offset:])
            event("report_write_return", fd=fd, offset=offset, written_bytes=count)
            if count <= 0:
                raise OSError("report write made no progress; partial report quarantined")
            offset += count
        event("report_bytes_written", fd=fd, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    finally:
        try:
            event("close_attempt", fd=fd, role="report")
        finally:
            os.close(fd)
        owned.remove(fd)
        event("close_return", fd=fd, role="report")
    event("report_saved", references=len(references), native_information_queries=0,
          candidate_executions=0, environment_mutations=0)
finally:
    journal.close()
