import pathlib,sys,json,hashlib,importlib.util,os,stat,struct,ast,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_ALL4_saved_regular_math_static_interiors_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-gcc-math-regular-inputs-v1/Actions-v1';P=B/'2026-11-07-actions-gcc-math-regular-interiors-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v['declaration'],indent=2));save('controller.py',sys.argv[2]);save('available_new_startup_tool_context.json',json.dumps(v['actual_startup_context'],ensure_ascii=False,indent=2))
 bindings=[];ranges=[]
 def state(fd):
  s=os.fstat(fd);return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
 def bound(path,role,expected=None,interpret=None):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);row={'role':role,'path':str(path),'open_return_fd':fd};bindings.append(row)
  try:
   before=state(fd);row['before']=before;assert stat.S_ISREG(before['mode']);h=hashlib.sha256();count=0;prefix=b'';small=[]
   while True:
    chunk=os.read(fd,65536)
    if not chunk:break
    if len(prefix)<64:prefix=(prefix+chunk)[:64]
    if role in ['member_index','report_mapping'] or before['size']<=64:small.append(chunk)
    h.update(chunk);count+=len(chunk)
   row.update(bytes=count,sha256=h.hexdigest(),read_EOF=True)
   if expected is not None:assert count==expected['bytes'] and h.hexdigest()==expected['sha256']
   result=interpret(fd,before['size'],prefix,b''.join(small)) if interpret else b''.join(small)
   after=state(fd);row['after']=after;assert before==after and count==before['size']
   return result
  finally:
   os.close(fd);row['close_return_fd']=fd
 def pread(fd,offset,count,size,role):
  assert 0<=offset<=size and 0<=count<=size-offset
  parts=[];done=0
  while done<count:
   data=os.pread(fd,min(65536,count-done),offset+done)
   if not data:raise RuntimeError('Unexpected saved-FD EOF; partial interpretation quarantined')
   parts.append(data);done+=len(data)
  raw=b''.join(parts);ranges.append({'role':role,'offset':offset,'bytes':count,'sha256':hashlib.sha256(raw).hexdigest()});return raw
 def literal(raw):
  return {'hex':raw.hex(),'utf8_surrogateescape':raw.decode('utf-8','surrogateescape')}
 def interpret(fd,size,prefix,small):
  if not prefix.startswith(b'\x7fELF'):
   result={'format':'non_ELF_prefix','prefix':literal(prefix)}
   if size<=64:
    result['ALL_saved_small_bytes']=literal(small)
    try:text=small.decode('utf-8')
    except UnicodeDecodeError:result['text_decode']='non_UTF8'
    else:
     result.update(text_bytes=size,terminal_LF=small.endswith(b'\n'),literal_line_count=len(text.splitlines()))
     try:tree=ast.parse(text)
     except SyntaxError as error:result['Python_AST_parse_error']={'line':error.lineno,'offset':error.offset,'message':error.msg}
     else:result.update(Python_AST_statement_count=len(tree.body),Python_AST_import_count=sum(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(tree)),Python_AST_call_count=sum(isinstance(n,ast.Call) for n in ast.walk(tree)))
   return result
  if len(prefix)<16:return {'format':'ELF_ident_incomplete','prefix':literal(prefix)}
  cls,data=prefix[4],prefix[5];result={'format':'ELF','ELF_class_literal':cls,'ELF_data_literal':data,'ident_hex':prefix[:16].hex()}
  if cls not in (1,2) or data not in (1,2):result['unexpanded_reason']='Unsupported literal class/encoding; no host guess';return result
  endian='<' if data==1 else '>';fmt='HHIQQQIHHHHHH' if cls==2 else 'HHIIIIIHHHHHH';minimum=64 if cls==2 else 52
  if size<minimum:result['unexpanded_reason']='Header exceeds saved file';return result
  raw=pread(fd,0,minimum,size,'ELF_header');head=struct.unpack_from(endian+fmt,raw,16);phoff,shoff,phent,phnum,shent=head[4],head[5],head[8],head[9],head[10]
  result.update(type_literal=head[0],machine_literal=head[1],version_literal=head[2],entry_literal=head[3],phoff=phoff,phentsize=phent,phnum_literal=phnum,shoff=shoff,shentsize=shent)
  if phnum==65535:
   shmin=64 if cls==2 else 40
   if shent<shmin or shoff>size or shent>size-shoff:result['unexpanded_reason']='Extended count section-zero out of saved bounds';return result
   sec=pread(fd,shoff,shmin,size,'extended_PH_count_section0');phnum=struct.unpack(endian+('IIQQQQIIQQ' if cls==2 else 'IIIIIIIIII'),sec)[7];result['extended_phnum']=phnum
  phmin=56 if cls==2 else 32
  if (phnum and phent<phmin) or phoff>size or phnum*phent>size-phoff:result['unexpanded_reason']='Program header table outside saved file or short entry';return result
  headers=[];result['ALL_program_headers']=headers
  for i in range(phnum):
   raw=pread(fd,phoff+i*phent,phent,size,'program_header_'+str(i));x=struct.unpack_from(endian+('IIQQQQQQ' if cls==2 else 'IIIIIIII'),raw)
   if cls==2:p={'ordinal':i,'type':x[0],'flags':x[1],'offset':x[2],'vaddr':x[3],'paddr':x[4],'filesz':x[5],'memsz':x[6],'align':x[7]}
   else:p={'ordinal':i,'type':x[0],'flags':x[6],'offset':x[1],'vaddr':x[2],'paddr':x[3],'filesz':x[4],'memsz':x[5],'align':x[7]}
   p['extra_entry_bytes_hex']=raw[phmin:].hex();p['file_range_in_bounds']=p['offset']<=size and p['filesz']<=size-p['offset'];headers.append(p)
  result['ALL_INTERP_records']=[]
  for p in headers:
   if p['type']==3:
    item={'program_header_ordinal':p['ordinal'],'file_range_in_bounds':p['file_range_in_bounds']};result['ALL_INTERP_records'].append(item)
    if p['file_range_in_bounds']:item['literal_bytes']=literal(pread(fd,p['offset'],p['filesz'],size,'PT_INTERP'))
  dynamic=[];result['ALL_DYNAMIC_segments']=dynamic
  for p in headers:
   if p['type']!=2:continue
   seg={'program_header_ordinal':p['ordinal'],'file_range_in_bounds':p['file_range_in_bounds'],'ALL_ordered_entries':[]};dynamic.append(seg)
   if not p['file_range_in_bounds']:continue
   step=16 if cls==2 else 8;seg['tail_bytes_hex']=pread(fd,p['offset']+p['filesz']//step*step,p['filesz']%step,size,'PT_DYNAMIC_tail').hex();active=True
   for j in range(p['filesz']//step):
    tag,val=struct.unpack(endian+('qQ' if cls==2 else 'iI'),pread(fd,p['offset']+j*step,step,size,'dynamic_entry_'+str(j)))
    seg['ALL_ordered_entries'].append({'ordinal':j,'tag':tag,'value':val,'before_first_NULL':active})
    if tag==0:active=False
   entries=[x for x in seg['ALL_ordered_entries'] if x['before_first_NULL']];tabs=[x for x in entries if x['tag']==5];sizes=[x for x in entries if x['tag']==10];seg['ALL_literal_string_requests']=[]
   for item in entries:
    if item['tag'] not in (1,14,15,29):continue
    request={'dynamic_ordinal':item['ordinal'],'tag':item['tag'],'string_offset':item['value'],'ALL_file_backed_table_bindings':[]};seg['ALL_literal_string_requests'].append(request)
    for tab in tabs:
     for length in sizes:
      for load in headers:
       delta=tab['value']-load['vaddr']
       if load['type']!=1 or delta<0 or delta+length['value']>load['filesz'] or not load['file_range_in_bounds'] or item['value']>=length['value']:continue
       start=load['offset']+delta+item['value'];limit=length['value']-item['value'];parts=[];used=0;terminated=False
       while used<limit:
        chunk=pread(fd,start+used,min(4096,limit-used),size,'dynamic_string_window');zero=chunk.find(b'\0')
        if zero>=0:parts.append(chunk[:zero]);terminated=True;break
        parts.append(chunk);used+=len(chunk)
       request['ALL_file_backed_table_bindings'].append({'STRTAB_dynamic_ordinal':tab['ordinal'],'STRSZ_dynamic_ordinal':length['ordinal'],'LOAD_program_header_ordinal':load['ordinal'],'literal_string':literal(b''.join(parts)),'NUL_terminated_in_declared_STRSZ':terminated})
  return result
 index=json.loads(bound(A/'actual-new-artifact-member-index.json','member_index'));assert len({x['name'] for x in index})==len(index)
 def locate(name):
  rows=[x for x in index if pathlib.PurePosixPath(x['name']).name==name];assert len(rows)==1;p=pathlib.PurePosixPath(rows[0]['name']);assert not p.is_absolute() and '..' not in p.parts;return rows[0],A/'artifact-members'/p
 rm,rp=locate('gcc-math-regular-inputs.json');report=json.loads(bound(rp,'report_mapping',rm));assert str(report['run_id'])=='42336634982' and report['workflow_revision']=='d64668e660cc72efc53379245022e798aac4680c'
 assert report['source_regular_references']==v['declaration']['ALL4_source_regular_references'] and len(report['observations'])==4
 results=[]
 for row in report['observations']:
  assert 'absent_at_open_only' not in row;member,path=locate(row['saved_member']);assert member['bytes']==row['bytes'] and member['sha256']==row['sha256'];begin=len(ranges)
  result=bound(path,'FIRST_new_body_semantics',member,interpret);result.update(source_reference=row['source_reference'],saved_member=member['name'],saved_bytes=member['bytes'],saved_sha256=member['sha256'],range_ledger_start=begin,range_ledger_end=len(ranges));results.append(result)
 assert len(results)==4
 qualification='FIRST bounded ELF program-header/DYNAMIC NEEDED-SONAME-RPATH-RUNPATH literals and small-text interpretation of ALL4 NEW saved math regular inputs only, not whole program semantics/actual installed compiler version/selection/Cargo/CFG/flavor/header-sysroot/ABI/loadedruntime/cohort/driveraccess/ownership/execution authority. ALL tags/headers/bindings retained; no host-language-version-ABI filtering or guessing one binding; multiple/unresolved mappings remain explicit. Actualreport/index ONLYlocate savedmembers. New saved read bindings not old stream comparison/installedSDK hash refresh. No source reopen/nativequery/candidateexec/import/recursivepathresolution/download/build/numerical/Source20-runtime adoption. ALL4originalsource-linkhex/latelexicalepochs/ALL9paths-BOTHlibc/5priorrefs14INTERP exclusions/76NEEDED15sources19records3plugins/unexpanded12plugin/v6deferred/prior4flavors-BOTHcfg/11installer-BOTHLLVM/974rows remain protected metadata, not reread/revalidated. PointFD/hash/stat/close NOTatomicABA-origin-auth/globalnativeactorFD/continuousofficialphysicalEX-crash proof. Unparsed body ranges remain UNINSPECTED. AllsetupUNADMITTED/flagsFALSE/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.'
 result={'phase':'FIRST_ALL4_saved_math_regular_bounded_interpretation_COMPLETE_CONSUMED_NOT_admitted','source_run':42336634982,'source_commit':report['workflow_revision'],'ALL4_bounded_interpretations':results,'preserved_prior_source_metadata_NOT_newly_revalidated':v['declaration']['preserved_prior_source_metadata'],'read_binding_count':len(bindings),'new_body_read_bytes':sum(x['bytes'] for x in bindings if x['role']=='FIRST_new_body_semantics'),'reader_tool_separate_launcher_PID_pipe_EOF':None,'remaining_body_ranges_UNINSPECTED':True,'qualification':qualification,'all_admission_flags':False}
 save('FIRST-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('ALL-static-range-bindings-PRIVATE.json',json.dumps(ranges,indent=2));save('ROOT-FIRST-ALL4-bounded-static-interpretation-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2)+'\n')
 summaries=[]
 for r in results:
  names=[{'tag':x['tag'],'literal':b['literal_string']['utf8_surrogateescape'],'NUL_terminated':b['NUL_terminated_in_declared_STRSZ']} for seg in r.get('ALL_DYNAMIC_segments',[]) for x in seg.get('ALL_literal_string_requests',[]) for b in x['ALL_file_backed_table_bindings']]
  summaries.append({'source_reference':r['source_reference'],'format':r['format'],'class_literal':r.get('ELF_class_literal'),'machine_literal':r.get('machine_literal'),'program_header_count':len(r.get('ALL_program_headers',[])),'INTERP':r.get('ALL_INTERP_records',[]),'ALL_needed_SONAME_RPATH_RUNPATH_bindings':names,'small_bytes':r.get('ALL_saved_small_bytes'),'Python_AST_statement_count':r.get('Python_AST_statement_count'),'unexpanded_reason':r.get('unexpanded_reason')})
 summary={k:value for k,value in result.items() if k!='ALL4_bounded_interpretations'};summary['ALL4_summaries']=summaries;save('ROOT-FIRST-ALL4-summary.json',json.dumps(summary,ensure_ascii=True,indent=2)+'\n')
 cp=B/'current-task-checkpoint.json';raw=cp.read_bytes();save('checkpoint-before-FIRST-reader.json',raw);d=json.loads(raw);d['actions_gcc_math_regular_interiors_v1']={'directory':str(P),**summary,'full_assessment':str(P/'ROOT-FIRST-ALL4-bounded-static-interpretation-PRIVATE.json'),'public_documentation_pending':True};d['actions_gcc_math_regular_inputs_v1']['all_new_saved_body_interiors_UNINSPECTED']=False;d['active_turn_status']['next']='FIRSTboundedALL4saved-math-body ELF-PH-DYNAMIC-NEEDED-SONAME-RPATH-RUNPATH question COMPLETE_CONSUMED; allotherbodyranges uninspected. Summarize newfindings/publish; no old/newbody-hash-parser/model/SDK/query/Actions/archive replay or automaticstring-resolution-import-download-executionauthority. AllflagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True);lease.verify_identity()
