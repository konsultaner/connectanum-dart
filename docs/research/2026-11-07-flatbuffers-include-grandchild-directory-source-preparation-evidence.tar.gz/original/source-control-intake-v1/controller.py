import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-grandchild-directory-inputs-v1';Q=P/'source-control-intake-v1';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':'FIRST NEW190directory collector/workflow source-locator metadata intake ONLY. Owncurrentcheckpoint pointFDsize exactrange declaredBEFOREcontentIO; ALLpriorreference ledgers/stat-times/epochs preserved/no oldCPscalarcomparison-model-sourcecheck-Actions-SDKquery replay. Locate exactsavedprep collector/workflow/control sources BEFOREtheirfutureIO, no guessedfilesystempaths. No SDK/Source20/runtime edits-import-adoption/build/cleanup.','path':str(CP),'all_admission_flags':False,'ownership':None},indent=2));save('controller.py',sys.argv[1])
 fd=os.open(CP,os.O_RDONLY|os.O_NOFOLLOW);binding={'fd':fd,'close_return_fd':None}
 try:
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);save('checkpoint-range-BEFORE-contentIO.json',json.dumps({'path':str(CP),'range':[0,s.st_size],'same_open_fd':fd},indent=2));parts=[];count=0
  while count<s.st_size:
   part=os.read(fd,min(65536,s.st_size-count));assert part;parts.append(part);count+=len(part)
  raw=b''.join(parts);z=os.fstat(fd);ks=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding.update(before={k:getattr(s,k) for k in ks},after={k:getattr(z,k) for k in ks},bytes=count,sha256=hashlib.sha256(raw).hexdigest());assert binding['before']==binding['after'];save('current-checkpoint-source-locators-PRIVATE.json',raw);cp=json.loads(raw)
 finally:os.close(fd);binding['close_return_fd']=fd
 save('checkpoint-read-binding.json',json.dumps(binding,indent=2))
 output={}
 for key in ['actions_include_child_directory_inputs_v1','actions_include_grandchild_regular_inputs_v1']:
  node=cp[key];output[key]={'keys':list(node),'path_and_source_metadata':{k:v for k,v in node.items() if any(x in k.lower() for x in ['path','directory','source','validation'])}}
 save('FIRST-prep-source-locator-metadata.json',json.dumps(output,indent=2));print(json.dumps(output),flush=True);lease.verify_identity()
