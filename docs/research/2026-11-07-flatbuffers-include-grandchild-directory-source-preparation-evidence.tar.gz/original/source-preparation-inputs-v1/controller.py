import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,ast,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-grandchild-directory-inputs-v1';Q=P/'source-preparation-inputs-v1'
SourceDir=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-07-actions-include-child-directory-scope-v1/new63-source-generation-v1')
W=B/'2026-11-07-actions-include-grandchild-regular-inputs-v1/source-generation-v1/candidate-wamp-profile-benchmarks.yml'
C=B/'2026-11-07-actions-include-grandchild-directory-scope-v1/ALL190-new-exact-public-safe-scope-BEFORE-INPUT-IO.json'
O1229=B/'2026-11-07-actions-include-grandchild-regular-inputs-v1/Actions-v1/ROOT-NEW-ALL1229-regular-grandchild-input-assessment-PRIVATE.json'
O1199=B/'2026-11-07-actions-include-child-regular-inputs-v1/Actions-v1/ROOT-NEW-ALL1199-regular-child-input-assessment-PRIVATE.json'
O63=B/'2026-11-07-actions-include-child-directory-scope-v1/new63-FIRST-remaining-static-binding-Actions-v1/ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST NEW190directory collector-workflow preparation saved-source/control intake andNEW190fullreference comparison againstapplicable prioractualreference ledgers. ExactOWNsavedsource-directory/name metadata ONLYlocateoriginal875694Bcollector byknownsize beforeselectedfiledeclaration; no SDKdirectory query. Exactoriginalcollector[0,875694)0af55b3c077386bb7d3fce9bd11c244df9644e62d62235acca27c023eb7e0038 withcontrolregion[633508,875694) declaredBEFOREcontentIO; prefixopaque bytepreservation/notoldfullsource syntaxvalidation or targetexecution. ALLremaininginputs exactranges-SHA declaredBEFOREcontentIO. Originalworkflow33jobs/functions-metadata-guards-fields/privatefullscope/stat-times/epochs/190DEFERRED6UNEXPANDED/priorledgers/oldtopncursesrawhexNOTsavedNULL unchanged. New190refs vsbounded1229actualBODY/1199actualBODY/160immutableBODY/63actualdirectory/49immutable-directory references andcapturedstaticmetadata; NOToldjournal-streamhash/CPscalar/model/query replay. No guessedSDKpaths/include-resolution-follow-recursion/aliasdedup/favorableABI-languagefilter/SDK-Action-bodyqueries/import-headercompile/bootstrap-build-native-driver-perf-numerical/Source20-runtime adoption/cleanup. PointFD notglobalownership-physicalEX-admission; allflagsFALSE ownershipNone.',
 'saved_source_directory_METADATA_ONLY':str(SourceDir),'selected_original_source_bytes':875694,'selected_original_source_sha256':'0af55b3c077386bb7d3fce9bd11c244df9644e62d62235acca27c023eb7e0038','selected_original_control_region':[633508,875694],
 'exact_saved_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':sha} for r,p,n,sha in [
 ('workflow33',W,481119,'3b34a6bcf525d24880334f8b556f47c1001dccff132a80e5b684472c20774858'),
 ('NEW190scope',C,1774384,'36f6fa44cdf0e79c41decd92ce87ee44535be0b4f3174a1efc4af99f702db05f'),
 ('original1229actualledger',O1229,14412328,'1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331'),
 ('original1199actualledger',O1199,8247935,'da9687e243a235c51a8c161f4a9012b0b105ace2ff7fc00f3b7930e9f7bfb8c5'),
 ('original63actualledger',O63,13814766,'85e36d181b234b30d651ff094f1b979d578dea0e564755c4392aac077fc44b3e')]],'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 names=os.listdir(SourceDir);entries=[{'literal_name':n,'stat_no_follow':os.stat(SourceDir/n,follow_symlinks=False)} for n in names]
 listed=[{'literal_name':r['literal_name'],'stat_no_follow':{k:getattr(r['stat_no_follow'],k) for k in ['st_mode','st_uid','st_gid','st_size','st_ino','st_dev','st_mtime_ns','st_ctime_ns']}} for r in entries];save('source-locator-directory-entries-PRIVATE.json',json.dumps(listed,indent=2))
 found=[r['literal_name'] for r in entries if stat.S_ISREG(r['stat_no_follow'].st_mode) and r['stat_no_follow'].st_size==875694];assert len(found)==1
 S=SourceDir/found[0];save('selected-source-exact-range-BEFORE-contentIO.json',json.dumps({'path':str(S),'range':[0,875694],'sha256':declaration['selected_original_source_sha256'],'control_region':[633508,875694],'directorymetadata_ONLYlocator':True},indent=2))
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and h.hexdigest()==expected;raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw


 source=read_bounded(S,875694,declaration['selected_original_source_sha256'],'original63collector_NEWin190sourceprep');save('original63collector-opaque-bound.py',source);body=source[633508:];save('original63collector-control-region-bound.py',body)
 raws={}
 for row in declaration['exact_saved_inputs']:
  raw=read_bounded(pathlib.Path(row['path']),row['range'][1],row['sha256'],row['role']);raws[row['role']]=raw;save(row['role']+'-bound-PRIVATE',raw)
 scope=json.loads(raws['NEW190scope']);refs=scope['ALL190_new_literal_directory_references'];assert len(refs)==190 and len(scope['ALL1425_original_safe_separate_entry_metadata'])==1425
 r1229=json.loads(raws['original1229actualledger']);r1199=json.loads(raws['original1199actualledger']);r63=json.loads(raws['original63actualledger'])
 assert r1229['run_id']==42369382026 and r1199['run_id']==42357611946 and r63['run_id']==42365704161
 ledgers=[{'role':'original1229actualBODY','source_run_id':42369382026,'literal_values':[r['source_reference'] for r in r1229['ALL1229_new_stream_bindings']]},{'role':'original1199actualBODY','source_run_id':42357611946,'literal_values':r1199['ALL1199_source_refs']},{'role':'original160immutableBODY_METADATA_NOTrevalidated','source_run_id':42350609933,'literal_values':r1199['ALL_preserved_static_report_fields']['original_ALL160_regular_reference_metadata_NOT_requeried']},{'role':'original63actualdirectory','source_run_id':42365704161,'literal_values':r63['ALL63_source_refs']},{'role':'original49immutabledirectory_METADATA_NOTrevalidated','source_run_id':42355093028,'literal_values':r63['ALL_preserved_static_report_fields']['prior_ALL49_directory_references_NOT_requeried']}]
 assert [len(r['literal_values']) for r in ledgers]==[1229,1199,160,63,49]
 literals=[]
 def walk(x,path):
  if isinstance(x,str):literals.append({'location':path,'literal':x})
  elif isinstance(x,dict):
   for k,z in x.items():walk(z,path+[k])
  elif isinstance(x,list):
   for i,z in enumerate(x):walk(z,path+[i])
 for label,old in [('original1229',r1229),('original1199',r1199),('original63',r63)]:walk(old['ALL_preserved_static_report_fields'],[label,'ALL_preserved_static_report_fields'])
 comparisons=[]
 for ordinal,ref in enumerate(refs,1):
  hits=[{'ledger_role':row['role'],'position_ZERO_based':i,'literal':old} for row in ledgers for i,old in enumerate(row['literal_values']) if old==ref];mh=[r for r in literals if r['literal']==ref]
  comparisons.append({'NEW190_scope_position_ONE_based':ordinal,'NEW_literal_reference_TEXT':ref,'ALL_prior_actual_reference_ledger_matches_PRIVATE':hits,'ALL_prior_static_metadata_literal_matches_PRIVATE':mh,'prior_actual_ledger_match_count':len(hits),'prior_static_metadata_match_count':len(mh),'query_permission_from_matches_or_nonmatches':None,'alias_identity':None})
 result={'NEW190_reference_count':190,'ALL_prior_actual_reference_ledger_groups':ledgers,'ALL_prior_captured_static_metadata_strings_PRIVATE':literals,'ALL190_NEW_fullreference_comparisons_PRIVATE':comparisons,'candidate_records_with_actual_ledger_matches':sum(bool(r['prior_actual_ledger_match_count']) for r in comparisons),'candidate_records_with_prior_static_metadata_matches':sum(bool(r['prior_static_metadata_match_count']) for r in comparisons),'qualification':'Bounded actualpriorreference-consumption ledgers pluscapturedstaticmetadata only; historical160/49 NOTrevalidated/oldacquisitionjournal-streamhash/bodyread-modelchecks NOTreplayed. Nonmatches NOTglobalabsence-newness-previousqueryabsence-alias-bodycoverage-ABI-access-originaldrivercredentials-ownership-permission-queryauthority/globalnoreplayproof. Originalmetadata/stat-times/epochs/DEFERRED-unfollowedflags unchanged. No SDK-Action-inputquery.','all_admission_flags':False,'ownership':None}
 save('FIRST-NEW190-actual-reference-ledger-intake-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2))
 assert result['candidate_records_with_actual_ledger_matches']==result['candidate_records_with_prior_static_metadata_matches']==0,'Literaloverlap terminal/no selectivecohort retry'
 assert body.startswith(b'OUT = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-include-child-directory-inputs"')
 tree=ast.parse(body.decode());rows=[]
 for node in tree.body:
  if isinstance(node,ast.Try):
   for sub in node.body:
    if isinstance(sub,ast.Assign):
     targets=[ast.unparse(t) for t in sub.targets];val=ast.get_source_segment(body.decode(),sub.value)
     rows.append({'line':sub.lineno,'targets':targets,'value':val if len(val)<8000 else '[OPAQUE_LONG_ASSIGNMENT_EXCLUDED_ONLY_CONTROL_DISPLAY fullsource_saved]'})
    elif isinstance(sub,(ast.Assert,ast.For)):rows.append({'line':sub.lineno,'kind':type(sub).__name__,'selected':ast.get_source_segment(body.decode(),sub).splitlines()[0]})
  elif isinstance(node,ast.Assign):rows.append({'line':node.lineno,'targets':[ast.unparse(t) for t in node.targets],'value':ast.get_source_segment(body.decode(),node.value)})
 selection={'original_source_path':str(S),'source_bytes':len(source),'source_sha256':hashlib.sha256(source).hexdigest(),'control_range':[633508,875694],'control_bytes':len(body),'control_sha256':hashlib.sha256(body).hexdigest(),'selected_control_assignments_asserts_loop_headers':rows,'all_opaque_prefix_bytes_preserved_notparsed':True,'new190_prior_actual_ledger_group_counts':[len(r['literal_values']) for r in ledgers],'prior_static_string_count':len(literals),'new190_prior_actual_ledger_match_candidates':0,'new190_prior_static_match_candidates':0,'new_saved_read_bindings':len(bindings),'new_SDK_or_Actions_queries':0,'all_admission_flags':False,'ownership':None}
 save('ALL-six-saved-input-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('FIRST-new190-source-control-selection.json',json.dumps(selection,ensure_ascii=True,indent=2));print(json.dumps(selection),flush=True);lease.verify_identity()
