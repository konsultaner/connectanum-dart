import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-grandchild-directory-inputs-v1';Q=P/'source-control-boundary-v1'
S=P/'source-preparation-inputs-v1/original63collector-opaque-bound.py';L=P/'source-preparation-inputs-v1/FIRST-NEW190-actual-reference-ledger-intake-PRIVATE.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST distinct bounded saved-source boundary afterNEW190sourcecontrol offset633508 guardfailed. Originalsourcepreparation namespace foreverterminal; sixfullsavedinputreads andNEW190ledgercomparison consumed/notreplayed. Actualassertion provesbody[633508:] doesnotstart expectedOUTanchor ONLY; offsetcause unmeasured untilthisNEWboundedsavedtail. Alloriginalrawsources/bindings savedBEFOREassert notmissing/reconstructed. FIRSTnewsavedsource tail[860000,875694) no fullsourcebody reread/no SDKquery-Actions-acquisition-model-oldASTcheck replay. Firstnewledger-result metadatabinding pointFDsize declaredBEFOREcontentIO; locatecounts only no recompare. No candidatewriter-import-SDK-bodyquery-build-Source20/runtime adoption; minimalcontrollerselector ONLY ifsupported, alloriginalgates remain.','sources':[{'path':str(S),'file_bytes_POINT_EXPECTED':875694,'range':[860000,875694],'prior_fullfile_sha256_NOT_revalidated':'0af55b3c077386bb7d3fce9bd11c244df9644e62d62235acca27c023eb7e0038'},{'path':str(L),'range':'openedFDpointsize declaredBEFOREcontentIO','purpose':'FIRSTread actualNEW190savedledgerresult counts only'}],'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def bounded(path,start,end,expected_file_size,role):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding={'role':role,'fd':fd,'close_return_fd':None};bindings.append(binding);primary=None;raw=None
  try:
   s=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(s,k) for k in keys};assert stat.S_ISREG(s.st_mode)
   if end is None:
    end=s.st_size;save('ledger-result-range-BEFORE-contentIO.json',json.dumps({'path':str(path),'range':[0,end],'same_open_FD':fd},indent=2))
   if expected_file_size is not None:assert s.st_size==expected_file_size
   assert 0<=start<=end<=s.st_size;binding['declared_range']=[start,end];os.lseek(fd,start,os.SEEK_SET);parts=[];count=0
   while count<end-start:
    piece=os.read(fd,min(65536,end-start-count));assert piece;parts.append(piece);count+=len(piece)
   raw=b''.join(parts);z=os.fstat(fd);binding.update(after={k:getattr(z,k) for k in keys},bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),file_EOF_probe=None);assert binding['before']==binding['after']
  except BaseException as e:primary=e;binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as e:
   binding['close_unknown_error']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-read-binding.json',json.dumps(binding,indent=2))
  if primary is not None:raise primary
  return raw
 raw=bounded(S,860000,875694,875694,'NEWdistinctsavedsource-tail');save('FIRST-distinct-saved-source-tail.py',raw)
 ledgerraw=bounded(L,0,None,None,'NEWsaved190ledger-result');save('original-new190-ledger-result-bound-PRIVATE.json',ledgerraw);ledger=json.loads(ledgerraw)
 anchor=b'OUT = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-include-child-directory-inputs"';offsets=[];start=0
 while True:
  at=raw.find(anchor,start)
  if at<0:break
  offsets.append(at);start=at+1
 assert len(offsets)==1,'NEWboundedtail notunique/permanentquarantine'
 at=offsets[0];control=raw[at:];save('FIRST-actual-OUT-control-region.py',control)
 result={'original_actual_failure_tool_exit_code':1,'original_failure_location':'assert body.startswith(expectedOUTanchor) atdeclaredabsolute633508 AFTERsixsavedinputbindings andNEW190ledgercomparison savedBEFOREassert/BEFOREnewcandidatewrite','original_failednamespace_forever_terminal':True,'original_fullsource_and_readbindings_saved_BEFOREassert':True,'first_NEW_distinct_source_range':[860000,875694],'new_actual_OUT_relative_tail_offset':at,'new_actual_OUT_absolute_offset':860000+at,'new_control_region':[860000+at,875694],'new_control_bytes':len(control),'new_control_sha256':hashlib.sha256(control).hexdigest(),'prior_source_offset633508_not_actual_new63collector_control_offset':860000+at!=633508,'NEW190ledger_group_counts':[len(r['literal_values']) for r in ledger['ALL_prior_actual_reference_ledger_groups']],'NEWprior_static_string_count':len(ledger['ALL_prior_captured_static_metadata_strings_PRIVATE']),'NEW190_actual_ledger_match_candidates':ledger['candidate_records_with_actual_ledger_matches'],'NEW190_static_match_candidates':ledger['candidate_records_with_prior_static_metadata_matches'],'NEW190_all_reference_relationships_PRIVATE_saved_unchanged':True,'minimal_selector_correction_candidate':'Use actualsupported OUT controlstart forFIRSTremaininggeneration; preserve originalwhole-sourceuniqueanchor+allgates/byteexactreverse; no originalreader-ledgercomparison retry','new_SDK_or_Actions_queries':0,'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipeEOF':None}
 save('FIRST-actual-failure-boundary.json',json.dumps(result,indent=2));cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-fault-boundary.json',before);d=json.loads(before);d['actions_include_grandchild_directory_inputs_v1']={'directory':str(P),'phase':'NEW190_sourcecontrol_selector_FAILED_foreverterminal_FIRST_distinct_saved_boundary_complete_debug_pending_NOT_candidate_generated_queried','original_sourcecontrol_namespace':str(P/'source-preparation-inputs-v1'),'actual_failure_boundary':result,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_include_grandchild_directory_inputs='FIRSTsource_selector_fault_newboundedboundary_complete_debug_pending',next='FIRSTboundeddebug NEW190actualsourcecontrol selector failure; sixoriginalsavedinputbindings/NEW190ledgercomparison consumed/notreplayed. Newdistinctsavedtail identifiesactualOUTcontrolregion; minimal supportedselector-only correction forFIRSTremaininggeneration retainsuniqueguard/allsource-workflow-gates. No SDK-Actionquery/Source20-runtime adoption/build/numerical.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result),flush=True);print(control.decode(),flush=True);lease.verify_identity()
