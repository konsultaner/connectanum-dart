import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owned-preflight')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads((P/'fixed-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/test_native_perf_build_producer.py';source=path.read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='OwnedPreflightTests')
 at=sum(len(x) for x in source.splitlines(keepends=True)[:node.end_lineno]);source=source[:at]+"\n\n    def test_registry_capacity_refuses_new_attempt_without_discarding_owners(self):\n        nonce=digest((str(self.base)+'capacity').encode())[:32];rejected=False;owner=None\n        with mock.patch.object(producer,'_PREFLIGHT_OWNER_LIMIT',0,create=True):\n            try:\n                owner=producer.start_owned_preflight('fixture',owner_id=nonce,\n                    **self.arguments(lambda:(_ for _ in ()).throw(RuntimeError('synthetic capacity before failure'))))\n            except producer.ProducerError:rejected=True\n        if owner is not None:self.owners.append(owner);owner.observe(2)\n        self.assertTrue(rejected)\n        self.assertNotIn(nonce,producer._PREFLIGHT_OWNERS)\n\n    def test_thread_object_setup_failure_retains_returned_quarantine(self):\n        nonce=digest((str(self.base)+'thread-setup').encode())[:32];caught=None;owner=None\n        with mock.patch.object(self.threading,'Thread',side_effect=OSError('synthetic thread object allocation failure')):\n            try:owner=producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments())\n            except OSError as error:caught=error;owner=producer._PREFLIGHT_OWNERS[nonce]\n        self.owners.append(owner)\n        self.assertIsNone(caught)\n        view=owner.observe(0);self.assertTrue(view['failed']);self.assertFalse(view['call_done'])\n        self.assertEqual('start_uncertain',view['call_state']);self.assertIsNone(owner._thread)\n        self.assertFalse(view['retained_operation'])\n        with self.assertRaises(producer.ProducerError):owner.continue_wait(0)\n"+'\n'+source[at:];ast.parse(source);path.write_text(source)
 summary=runtests('last-before',['OwnedPreflightTests.test_registry_capacity_refuses_new_attempt_without_discarding_owners','OwnedPreflightTests.test_thread_object_setup_failure_retains_returned_quarantine'])
 lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
