import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owned-preflight')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads((P/'repr-before-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/native_perf_build_producer.py';source=path.read_text()
 source=source.replace("self._state='reserved';self._failed=False;self._first_error=None","self._state='reserved';self._failed=False;self._first_error=None;self._first_error_object=None",1)
 old="        if self._first_error is None:\n            try:self._first_error=repr(error)[:4096]\n            except BaseException:self._first_error=type(error).__name__"
 new="        if self._first_error is None:\n            self._first_error=type(error).__name__;self._first_error_object=error"
 assert source.count(old)==1;source=source.replace(old,new,1)
 source=source.replace("        if isinstance(value,Path):return value","        if type(value) is type(Path()):return value",1)
 old="        with self._lock:\n            if (threading.current_thread() is not self._thread or self._action!='construct'\n                or self._operation is not None or type(operation) is not CommandProducer\n                or _PREFLIGHT_OWNERS.get(self.owner_id) is not self):"
 new="        with self._lock:\n            with _PREFLIGHT_OWNERS_LOCK:registered=_PREFLIGHT_OWNERS.get(self.owner_id) is self\n            if (threading.current_thread() is not self._thread or self._action!='construct'\n                or self._operation is not None or type(operation) is not CommandProducer or not registered):"
 assert source.count(old)==1;source=source.replace(old,new,1);ast.parse(source);path.write_text(source)
 path=R/'tool/test_native_perf_build_producer.py';source=path.read_text()
 start=source.index('    def test_postspawn_primary_failure_keeps_same_known_child_until_natural_exit')
 end=source.index('    def test_actual_thread_start_then_error',start)
 piece=source[start:end].replace("if kind=='command_start':","if kind=='command_spawned':").replace("        self.drive(owner);run=owner._operation\n        self.assertIs(child,run.process)","        self.assertIs(child,owner._operation.process)\n        self.drive(owner);run=owner._operation\n        self.assertEqual(child.pid,run.result['commands'][0]['pid'])\n        self.assertEqual(0,child.returncode)")
 source=source[:start]+piece+source[end:];ast.parse(source);path.write_text(source)
 summary=runtests('fixed',['OwnedPreflightTests',
 'ProducerTests.test_postspawn_journal_error_keeps_owned_child_waitable',
 'ProducerTests.test_production_recipe_factory_only_synthetic_argv_observation',
 'ProducerTests.test_canonical_recipe_factory_only_synthetic_argv_observation'])
 writej(P/'intermediate-qualification.json',dict(
 initial_before8_errors='Missing new API only, NOT8production defects',
 first11_tests=dict(passes=10,failures=1,cause='New fixture injected command_start BEFOREspawn, contrary to its postspawn label; actual process was None and no child created; all raw failure retained'),
 separate_new_repr_guard=dict(tests=1,failures=1,scope='Actual new owner called custom exception repr during snapshot publication; source risk of blocking observer, no measured timing/RAM claim'),
 corrections=['Inject actual command_spawned after retained Popen/pending; assert same actual handle before continuation, pid+status0+EOF after natural completion','Publish only exception type; retain exact exception object privately, never call custom repr/str','Registry lookup also uses registry lock; accept exact immutable actual-host Path type'],
 no_old_proof_repeated=True))
 lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
