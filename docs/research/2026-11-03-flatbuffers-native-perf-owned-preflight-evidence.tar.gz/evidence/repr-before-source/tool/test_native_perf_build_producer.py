"""OWN non-benchmark producer fixtures; never real canonical/build admission."""
from pathlib import Path
import hashlib
import base64
import json
import os
import signal
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import native_perf_build_producer as producer


def digest(data):
    return hashlib.sha256(data).hexdigest()


class ProducerTests(unittest.TestCase):
    def setUp(self):
        evidence = os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:
            Path(evidence).mkdir(exist_ok=True)
        self.base = Path(tempfile.mkdtemp(prefix='producer-', dir=evidence)).resolve()
        self.git_path=shutil.which('git')
        self.repo = self.base / 'repo'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.email', 'fixture@example.invalid')
        self.git('config', 'user.name', 'Owned Fixture')
        (self.repo / '.gitignore').write_text('inputs/\n')
        (self.repo / 'worker.py').write_text("""import os,sys,time,signal
from pathlib import Path
mode=sys.argv[1]
if mode=='sleep':
    Path(sys.argv[2]).write_text('running')
    time.sleep(0.12)
elif mode=='drift':
    Path(sys.argv[2]).write_text('changed')
    time.sleep(0.08)
    Path(sys.argv[3]).write_text('natural-exit')
elif mode=='large':
    os.write(1,b'A'*9000);os.write(2,b'B'*7000)
elif mode=='nonzero':
    print('failed-with-bytes',flush=True);sys.exit(7)
elif mode=='signal':
    print('before-signal',flush=True);os.kill(os.getpid(),signal.SIGTERM)
elif mode=='environment':
    assert os.environ['PERF_FIXTURE_SECRET']=='preserved-value'
    print('environment-preserved')
else:
    print('fixture-ok')
""")
        self.git('add', '.')
        self.git('commit', '-qm', 'tiny owned fixture')
        self.head = self.git('rev-parse', 'HEAD').decode().strip()
        self.archive_sha = digest(self.git('archive', '--format=tar', self.head))
        self.inputs = {}
        for name in ('pub', 'transport', 'bench', 'package_config'):
            path = self.repo / 'inputs' / name
            path.parent.mkdir(exist_ok=True)
            path.write_text('fixture-' + name)
            self.inputs['inputs/' + name] = digest(path.read_bytes())
        self.runs = []

    def tearDown(self):
        for run in self.runs:
            if run.pending:
                if run.finished:
                    status=run.process.wait(2)
                    run._end_command(status)
                    if run.events is not None:run.events.close();run.events=None
                    (self.base/'fixture-fallback-reaped.json').write_text(json.dumps({'pid':run.child_pid,'status':status,'scope':'OWN finite fixture teardown only; no live controller workaround'}))
                else:
                    run.wait(2)
        # Evidence deliberately remains, including failed/partial source archives.

    def git(self, *args):
        return subprocess.check_output(['git', '-C', str(self.repo), *args], stderr=subprocess.PIPE)

    def start(self, *modes, **overrides):
        kwargs = dict(repo=self.repo, source_commit=self.head, runtime_commit=self.head,
                      run_dir=self.base / 'run', expected_archive_sha256=self.archive_sha,
                      inputs=self.inputs, commands=[[sys.executable, 'worker.py', *mode] for mode in modes],
                      lease_check=lambda: None)
        kwargs.update(overrides)
        run = producer.start_fixture(**kwargs)
        self.runs.append(run)
        return run

    def finish(self, run):
        result = run.result if run.finished else None
        while result is None:result = run.wait(2)
        self.assertIsNotNone(result)
        return result

    def test_positive_exact_source_commands_and_output_bytes(self):
        run = self.start(('large',), ('ok',))
        result = self.finish(run)
        self.assertEqual('fixture-command-evidence-v1', result['kind'])
        self.assertEqual('success', result['status'])
        self.assertEqual(2, len(result['commands']))
        raw = (self.base / 'run' / 'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000, raw)
        self.assertEqual(digest(raw), result['commands'][0]['log_sha256'])
        self.assertEqual(self.archive_sha, result['source_archive_sha256'])
        self.assertFalse(result['capture_ready'])

    def test_existing_run_directory_is_terminal_before_any_command(self):
        directory=self.base/'run';directory.mkdir();(directory/'partial').write_bytes(b'keep')
        with self.assertRaises(FileExistsError): self.start(('ok',))
        self.assertEqual(['partial'], [p.name for p in directory.iterdir()])

    def test_completed_run_cannot_run_again(self):
        run=self.start(('ok',));self.finish(run)
        before={p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()}
        with self.assertRaises(producer.ProducerError):run.wait(0)
        with self.assertRaises(FileExistsError):self.start(('ok',))
        self.assertEqual(before,{p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()})

    def test_nonzero_exit_preserves_log_and_prevents_next_command(self):
        result=self.finish(self.start(('nonzero',),('ok',)))
        self.assertEqual('failed',result['status']);self.assertEqual(7,result['commands'][0]['returncode'])
        self.assertEqual(1,len(result['commands']));self.assertIn(b'failed-with-bytes',(self.base/'run'/'command-000.log').read_bytes())

    def test_negative_signal_status_is_not_success(self):
        result=self.finish(self.start(('signal',)))
        self.assertEqual(-signal.SIGTERM,result['commands'][0]['returncode']);self.assertEqual('failed',result['status'])
        self.assertIn(b'before-signal',(self.base/'run'/'command-000.log').read_bytes())

    def test_spawn_failure_retains_null_status_no_retry(self):
        run=self.start(('ok',),commands=[['/nonexistent/owned-fixture-command']])
        result=run.result
        self.assertEqual('failed',result['status']);self.assertIsNone(result['commands'][0]['returncode'])
        self.assertIn('FileNotFoundError',result['commands'][0]['spawn_error'])

    def test_timeout_only_waits_same_owned_process(self):
        run=self.start(('sleep',str(self.base/'started')))
        pid=run.child_pid;self.assertIsNone(run.wait(0));self.assertEqual(pid,run.child_pid)
        result=self.finish(run);self.assertEqual('success',result['status']);self.assertEqual(1,len(result['commands']))

    def test_input_drift_waits_for_natural_child_exit(self):
        done=self.base/'done'
        result=self.finish(self.start(('drift',str(self.repo/'inputs/pub'),str(done))))
        self.assertEqual('natural-exit',done.read_text());self.assertEqual('failed',result['status'])
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertIn('input',result['error'])

    def test_dirty_source_refused_before_command(self):
        (self.repo/'worker.py').write_text('raise SystemExit(99)')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'failure.json').is_file())

    def test_wrong_archive_refused_before_command(self):
        with self.assertRaises(producer.ProducerError):self.start(('ok',),expected_archive_sha256='0'*64)
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'source.tar').is_file())

    def test_head_drift_refused_before_command(self):
        (self.repo/'extra').write_text('new');self.git('add','.');self.git('commit','-qm','new')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_input_symlink_refused(self):
        p=self.repo/'inputs/pub';p.rename(self.repo/'inputs/old');p.symlink_to('old')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_lease_refusal_before_reservation(self):
        def refuse():raise RuntimeError('lease unavailable')
        with self.assertRaisesRegex(RuntimeError,'lease unavailable'):self.start(('ok',),lease_check=refuse)
        self.assertFalse((self.base/'run').exists())

    def test_environment_inherited_without_values_in_metadata(self):
        old=os.environ.get('PERF_FIXTURE_SECRET');os.environ['PERF_FIXTURE_SECRET']='preserved-value'
        try: result=self.finish(self.start(('environment',)))
        finally:
            if old is None:os.environ.pop('PERF_FIXTURE_SECRET')
            else:os.environ['PERF_FIXTURE_SECRET']=old
        self.assertEqual('success',result['status'])
        for p in (self.base/'run').glob('*.json*'):self.assertNotIn('preserved-value',p.read_text())

    def test_source_archive_members_match_committed_bytes(self):
        result=self.finish(self.start(('ok',)))
        self.assertEqual(self.head,result['source_commit'])
        self.assertEqual(2,result['source_entries'])
        self.assertEqual(self.git('archive','--format=tar',self.head),(self.base/'run'/'source.tar').read_bytes())

    def test_mutating_caller_input_dictionary_does_not_change_snapshot(self):
        run=self.start(('sleep',str(self.base/'started')))
        self.inputs.clear()
        self.assertEqual('success',self.finish(run)['status'])

    def test_production_factory_refuses_nonlinux_before_reservation(self):
        if sys.platform=='linux':self.skipTest('Darwin negative only')
        with self.assertRaises(producer.ProducerError):
            producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=self.inputs,lease_check=lambda:None)
        self.assertFalse((self.base/'run').exists())

    def test_postspawn_journal_error_keeps_owned_child_waitable(self):
        original_event=producer.CommandProducer._event
        original_spawn=producer.CommandProducer._spawn
        observed=[]
        def spawn(run):
            observed.append(run)
            return original_spawn(run)
        def event(run,kind,**kwargs):
            if kind=='command_spawned':raise OSError('injected post-spawn journal fault')
            return original_event(run,kind,**kwargs)
        try:
            with mock.patch.object(producer.CommandProducer,'_spawn',spawn),mock.patch.object(producer.CommandProducer,'_event',event):
                run=self.start(('sleep',str(self.base/'started')))
            self.assertTrue(run.pending)
            result=self.finish(run)
            self.assertEqual('failed',result['status'])
            self.assertIn('injected post-spawn',result['error'])
            self.assertEqual(0,result['commands'][0]['returncode'])
        finally:
            # Actual first counterexample must retain/reap its OWN finite child.
            for run in observed:
                if run not in self.runs:self.runs.append(run)

    def test_single_wait_budget_decreases_across_commands(self):
        run=self.start(('sleep',str(self.base/'one')),('sleep',str(self.base/'two')))
        original=producer.subprocess.Popen.wait;timeouts=[]
        def waiting(child,timeout=None):
            if child.args and child.args[0]==sys.executable:timeouts.append(timeout)
            return original(child,timeout=timeout)
        with mock.patch.object(producer.subprocess.Popen,'wait',waiting):self.finish(run)
        self.assertEqual(2,len(timeouts))
        self.assertLess(timeouts[1],timeouts[0])

    def test_log_hashing_does_not_load_whole_output_into_memory(self):
        run=self.start(('large',));original=Path.read_bytes
        def read(path):
            if path.name.startswith('command-') and path.suffix=='.log':raise AssertionError('whole log read forbidden')
            return original(path)
        with mock.patch.object(Path,'read_bytes',read):result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(16000,result['commands'][0]['log_bytes'])

    def test_wait_status_retained_before_uncertain_log_close(self):
        run=self.start(('ok',));original=run.log;calls=[]
        class Fault:
            def flush(self):return original.flush()
            def fileno(self):return original.fileno()
            def close(self):
                calls.append('close');original.close();raise OSError('injected ambiguous log close')
        run.log=Fault()
        with self.assertRaisesRegex(OSError,'ambiguous log close'):run.wait(2)
        self.assertEqual(0,run.records[0]['returncode'])
        self.assertEqual(['close'],calls);self.assertIsNone(run.log)
        with self.assertRaises(producer.ProducerError):run.wait(0)
        self.assertEqual(['close'],calls)

    def test_production_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer.sys,'platform','linux'),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            result=producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'},lease_check=lambda:None)
        self.assertEqual('fixture-placeholder',result)
        kwargs=cls.call_args.kwargs
        self.assertEqual([['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],kwargs['commands'])
        self.assertEqual({'CARGO_TARGET_DIR':str(self.base/'run/target')},kwargs['env_delta'])
        self.assertFalse((self.base/'run').exists())

    def test_canonical_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            producer.start_canonical(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'},lease_check=lambda:None)
        self.assertEqual([['bin/verify']],cls.call_args.kwargs['commands'])
        self.assertFalse((self.base/'run').exists())

    def make_tool(self,version='1.0',mutate=False):
        directory=self.base/'tools';directory.mkdir(exist_ok=True)
        target=self.base/'real-python3'
        body="#!/bin/sh\nprintf 'Fixture %s "+version+"\\n' \"${0##*/}\"\n"
        if mutate:body+="printf '#changed\\n' >> \"$0\"\n"
        target.write_text(body);target.chmod(0o755)
        entry=directory/'python3';entry.symlink_to(target)
        return directory,entry,target

    def test_tool_entry_basename_and_fixed_version_argv_preserved(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('success',result['status'])
        self.assertEqual([str(entry),'--version'],result['commands'][0]['argv'])
        self.assertEqual('tool_version',result['commands'][0]['kind'])
        self.assertEqual('recipe',result['commands'][1]['kind'])
        self.assertEqual(str(target),result['tools']['python3']['target'])
        self.assertEqual(b'Fixture python3 1.0\n',(self.base/'run/command-000.log').read_bytes())

    def test_tool_wrong_version_preserves_raw_and_blocks_recipe(self):
        directory,entry,target=self.make_tool(version='9.0')
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('version',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])
        self.assertIn(b'9.0',(self.base/'run/command-000.log').read_bytes())

    def test_tool_path_lookup_drift_refuses_before_any_probe(self):
        directory,entry,target=self.make_tool()
        alternative=self.base/'different';alternative.mkdir();(alternative/'python3').symlink_to(target)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            with mock.patch.dict(os.environ,{'PATH':str(alternative)+os.pathsep+os.environ['PATH']}):
                with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_symlink_retarget_even_equal_bytes_refuses(self):
        directory,entry,target=self.make_tool();other=self.base/'equal-bytes';other.write_bytes(target.read_bytes());other.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            entry.unlink();entry.symlink_to(other)
            with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_mutation_during_probe_blocks_following_recipe(self):
        directory,entry,target=self.make_tool(mutate=True)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('tool',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])

    def test_tool_caller_spec_mutation_does_not_change_pinned_snapshot(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0');tools={'python3':spec}
            run=self.start(('ok',),tools=tools);spec['sha256']='0'*64;tools.clear()
            result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(hashlib.sha256(target.read_bytes()).hexdigest(),result['tools']['python3']['sha256'])

    def test_tool_unknown_name_and_empty_version_rejected(self):
        with self.assertRaises(producer.ProducerError):producer.describe_tool('untrusted-build-command','anything')
        with self.assertRaises(producer.ProducerError):producer.describe_tool('python3','')

    def test_tool_review_intent_is_durable_before_version_child(self):
        directory,entry,target=self.make_tool()
        text=target.read_text();text=text.replace('#!/bin/sh\n','#!/bin/sh\nif [ ! -s "$PRODUCER_INTENT" ]; then printf missing-intent >&2; exit 55; fi\n');target.write_text(text)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH'],'PRODUCER_INTENT':str(self.base/'run/intent.json')}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('success',result['status'])
        intent=json.loads((self.base/'run/intent.json').read_text())
        self.assertEqual({'python3':spec},intent['tools'])
        self.assertEqual(self.inputs,intent['inputs']);self.assertEqual(self.archive_sha,intent['expected_archive_sha256'])

    def test_tool_review_numeric_prefix_collision_blocks_recipe(self):
        directory,entry,target=self.make_tool(version='1.00')
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('version',result['error'])
        self.assertEqual(1,len(result['commands']))

    def test_tool_review_boolean_identity_schema_rejected_before_reservation(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0');spec['entry_uid']=False
            with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run').exists())

    def receipt_fixture(self,phase='canonical',dart='3.13.1',config='3.13.1'):
        real_git=self.git_path
        (self.repo/'.gitignore').write_text('inputs/\npubspec.lock\nnative/\n.dart_tool/\n')
        self.git('add','.gitignore');self.git('commit','-qm','receipt fixture ignores generated input roles')
        self.head=self.git('rev-parse','HEAD').decode().strip();self.archive_sha=digest(self.git('archive','--format=tar',self.head))
        inputs={}
        for relative in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'):
            path=self.repo/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('OWN synthetic lock '+relative);inputs[relative]=digest(path.read_bytes())
        path=self.repo/'.dart_tool/package_config.json';path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps({'configVersion':2,'generator':'pub','generatorVersion':config,'packages':[{'name':'owned_fixture','rootUri':'../','packageUri':'lib/'}]}))
        inputs['.dart_tool/package_config.json']=digest(path.read_bytes())
        bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'}
        directory=self.base/'receipt-tools';directory.mkdir()
        versions={'dart':'Dart SDK version: '+dart+' (stable) fixture','git':'Fixture git 1','bash':'Fixture bash 1','python3':'Fixture python3 1','cargo':'Fixture cargo 1','rustc':'Fixture rustc 1'}
        for name,line in versions.items():
            path=directory/name
            path.write_text('#!/bin/sh\nif [ "$1" = "--version" ]; then printf "%s\\n" "'+line+'"; exit 0; fi\nexec "'+real_git+'" "$@"\n')
            path.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            tools={name:producer.describe_tool(name,'Dart SDK version: ' if name=='dart' else versions[name]) for name in versions}
            roles=['canonical_native'] if phase=='canonical' else ['native_elf','driver_elf','static_rlib']
            outputs={}
            for role in roles:
                blob=self.base/(role+'.synthetic');blob.write_bytes(('OWN synthetic '+role).encode());outputs[role]=blob
            run=self.start(('ok',),inputs=inputs,tools=tools,outputs=outputs,census_id='a'*32,expected_sdk='3.13.1',config_bindings=bindings)
            result=self.finish(run)
        return run,result,inputs,bindings

    def test_receipt_fixture_canonical_links_actual_logs_and_inputs(self):
        run,result,inputs,bindings=self.receipt_fixture()
        receipt=producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual('fixture-canonical-v1',receipt['kind']);self.assertEqual('3.13.1',receipt['sdk'])
        self.assertEqual('a'*32,receipt['census_id']);self.assertEqual(self.archive_sha,receipt['source_archive_sha256'])
        self.assertEqual({k:inputs[p] for k,p in bindings.items()},receipt['package_configs'])
        raw=b''.join((self.base/f'run/command-{i:03}.log').read_bytes() for i in range(len(result['commands'])))
        self.assertEqual(raw,(self.base/'run/complete-command.log').read_bytes());self.assertEqual(digest(raw),receipt['log_sha256'])
        self.assertTrue((self.base/'run/receipt-binding.json').is_file())

    def test_receipt_fixture_production_keeps_fixture_kind_and_output_links(self):
        run,result,_,_=self.receipt_fixture('execution');receipt=producer.emit_fixture_receipt(run,'execution')
        self.assertEqual('fixture-production-v1',receipt['kind']);self.assertEqual([],receipt['features'])
        self.assertEqual({k:v['sha256'] for k,v in result['outputs'].items()},receipt['outputs'])

    def test_receipt_live_emitter_rejects_fixture_without_publication(self):
        run,_,_,_=self.receipt_fixture()
        with self.assertRaises(producer.ProducerError):producer.emit_receipt(run)
        self.assertFalse((self.base/'run/receipt-attempt.json').exists())
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_declared_sdk_mismatch_blocks_recipe(self):
        run,result,_,_=self.receipt_fixture(dart='3.13.5')
        self.assertEqual('failed',result['status']);self.assertIn('SDK',result['error'])
        self.assertFalse(any(r['kind']=='recipe' for r in result['commands']))

    def test_receipt_config_generator_mismatch_refuses_before_child(self):
        with self.assertRaises(producer.ProducerError):self.receipt_fixture(config='3.13.5')
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_receipt_partial_publication_is_terminal_without_second_read(self):
        run,_,_,_=self.receipt_fixture();original=producer._write_json;attempts=[]
        def write(path,value):
            if Path(path).name=='input-receipt.json':
                attempts.append('write');Path(path).write_bytes(b'OWN-partial');raise OSError(28,'injected ENOSPC')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):
            with self.assertRaises(OSError):producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual(b'OWN-partial',(self.base/'run/input-receipt.json').read_bytes())
        with mock.patch.object(producer,'_regular_hash',side_effect=AssertionError('second read forbidden')):
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual(['write'],attempts);self.assertFalse((self.base/'run/receipt-binding.json').exists())

    def test_receipt_sealed_result_tamper_refuses(self):
        run,_,_,_=self.receipt_fixture();path=self.base/'run/result.json';path.with_suffix('.before').write_bytes(path.read_bytes());path.write_bytes(path.read_bytes()+b' ')
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertTrue((self.base/'run/receipt-attempt.json').is_file());self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_log_tamper_refuses(self):
        run,_,_,_=self.receipt_fixture();path=self.base/'run/command-000.log';path.with_suffix('.before').write_bytes(path.read_bytes());path.write_bytes(path.read_bytes()+b'changed')
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_nonce_mutation_cannot_relabel_completed_run(self):
        run,_,_,_=self.receipt_fixture();run.census_id='b'*32
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_binding_dictionary_mutation_does_not_relabel_context(self):
        run,_,inputs,bindings=self.receipt_fixture();bindings.clear()
        receipt=producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual({'server':inputs['.dart_tool/package_config.json'],'client':inputs['.dart_tool/package_config.json']},receipt['package_configs'])

    def test_receipt_pending_child_cannot_be_published(self):
        run=self.start(('sleep',str(self.base/'started')))
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertTrue(run.pending);self.assertFalse((self.base/'run/receipt-attempt.json').exists())

    def test_receipt_review_mutable_retagging_stops_at_provenance_boundary(self):
        run,_,_,_=self.receipt_fixture();run.provenance='canonical_recipe'
        with self.assertRaisesRegex(producer.ProducerError,'provenance'):producer.emit_receipt(run)
        self.assertFalse((self.base/'run/receipt-attempt.json').exists())

    def package_observation(self):
        nonce='c'*32
        config=json.dumps({'configVersion':2,'generator':'pub','generatorVersion':'3.13.1','packages':[{'name':'one','rootUri':'../one/','packageUri':'lib/'},{'name':'two','rootUri':'../two/','packageUri':'lib/'}]}).encode()
        value={'kind':'dart-package-config-observation-v1','script':'file:///owned/probe.dart','sdk':'3.13.1 (stable) fixture',
               'config_uri':'file:///owned/.dart_tool/package_config.json','config_b64':base64.b64encode(config).decode(),
               'mappings':[{'name':'one','uri':'file:///owned/one/lib/'},{'name':'two','uri':None}],
               'missing_name':'__native_perf_absent_'+nonce,'missing_uri':None}
        context={'expected_sdk':'3.13.1','expected_script_uri':value['script'],'expected_config_uri':value['config_uri'],'expected_config_bytes':config,'nonce':nonce}
        return value,context

    def test_package_observation_preserves_all_mappings_and_null_without_readiness(self):
        value,context=self.package_observation();record=producer.validate_package_observation(value,**context)
        self.assertEqual((('one','file:///owned/one/lib/'),('two',None)),record['mappings'])
        self.assertEqual(2,record['package_count']);self.assertEqual(1,record['other_or_null'])
        self.assertFalse(record['capture_ready']);self.assertEqual('helper_package_config_observation_only',record['scope'])

    def test_package_observation_null_config_negative(self):
        value,context=self.package_observation();value.update(config_uri=None,config_b64=None,mappings=[]);context.update(expected_config_uri=None,expected_config_bytes=None)
        record=producer.validate_package_observation(value,**context);self.assertEqual(0,record['package_count'])
        self.assertIsNone(record['config_sha256']);self.assertFalse(record['capture_ready'])

    def test_package_observation_sdk_and_script_context_mismatch(self):
        value,context=self.package_observation()
        for key,bad in [('sdk','3.13.5 (stable) other'),('script','file:///other/probe.dart')]:
            with self.subTest(key=key):
                changed={**value,key:bad}
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation(changed,**context)

    def test_package_observation_exact_config_uri_and_bytes(self):
        value,context=self.package_observation()
        for change in [{'config_uri':'file:///different/package_config.json'},{'config_b64':base64.b64encode(context['expected_config_bytes']+b' ').decode()}]:
            with self.subTest(change=change):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,**change},**context)

    def test_package_observation_subset_or_reordering_refused(self):
        value,context=self.package_observation()
        for mappings in [value['mappings'][:1],list(reversed(value['mappings']))]:
            with self.subTest(mappings=mappings):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,'mappings':mappings},**context)

    def test_package_observation_absent_query_must_be_null(self):
        value,context=self.package_observation()
        for bad in ['file:///exists/lib/','https://example.invalid/pkg/']:
            with self.subTest(bad=bad):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,'missing_uri':bad},**context)

    def test_package_observation_nonce_replay_refused(self):
        value,context=self.package_observation();context['nonce']='d'*32
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_observation_unresolved_or_invalid_uri_refused_other_schemes_retained(self):
        value,context=self.package_observation()
        for bad in ['package:one/',False,'file:///bad/%GG']:
            changed={**value,'mappings':[{'name':'one','uri':bad},value['mappings'][1]]}
            with self.subTest(bad=bad):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation(changed,**context)
        changed={**value,'mappings':[{'name':'one','uri':'https://example.invalid/source/'},value['mappings'][1]]}
        record=producer.validate_package_observation(changed,**context);self.assertEqual(2,record['other_or_null'])
        self.assertEqual('https://example.invalid/source/',record['mappings'][0][1])

    def test_package_observation_duplicate_config_entries_refused(self):
        value,context=self.package_observation();config=json.loads(context['expected_config_bytes']);config['packages'][1]['name']='one';raw=json.dumps(config).encode();context['expected_config_bytes']=raw;value['config_b64']=base64.b64encode(raw).decode()
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_review_base64_length_refuses_before_decoder(self):
        value,context=self.package_observation();value['config_b64']+='AAAA'
        with mock.patch('base64.b64decode',side_effect=AssertionError('decoder must not receive wrong-length payload')):
            with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_review_extra_authority_field_is_not_admitted(self):
        value,context=self.package_observation();value['capture_ready']=True
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)




class CanonicalOutputPathTests(unittest.TestCase):
    """Synthetic platform/path guards; never execute a build or emit a receipt."""

    def setUp(self):
        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:Path(evidence).mkdir(exist_ok=True)
        self.base=Path(tempfile.mkdtemp(prefix='canonical-path-',dir=evidence)).resolve()
        self.repo=self.base/'repo';self.repo.mkdir()
        self.kwargs=dict(repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,
            run_dir=self.base/'run',expected_archive_sha256='b'*64,
            inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock',
                'native/bench/Cargo.lock','.dart_tool/package_config.json')},
            tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,
            expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json',
                'client':'.dart_tool/package_config.json'},lease_check=lambda:None)

    def factory(self,platform='darwin',environment=None):
        with mock.patch.dict(os.environ,environment or {},clear=True),\
                mock.patch.object(producer.sys,'platform',platform),\
                mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            result=producer.start_canonical(**self.kwargs)
        self.assertEqual('fixture-placeholder',result)
        self.assertFalse((self.base/'run').exists())
        return cls.call_args.kwargs

    def shell_path(self,platform):
        import re
        root=Path(__file__).resolve().parents[1]
        common=(root/'bin/common.sh').read_bytes()
        names=('native_lib_file_name','native_ffi_test_lib_path')
        functions=[]
        for name in names:
            matches=re.findall(rb'(?ms)^'+name.encode()+rb'\(\) \{\n.*?^\}',common)
            self.assertEqual(1,len(matches));functions.append(matches[0])
        script=(b'set -euo pipefail\nROOT_DIR="$1"\nfixture_platform="$2"\n'
            b'uname() { printf "%s\\n" "$fixture_platform"; }\n'+b'\n'.join(functions)+
            b'\nnative_ffi_test_lib_path\n')
        path=self.base/'selected-functions.sh';path.write_bytes(script)
        argv=['/bin/bash',str(path),str(self.repo),platform]
        result=subprocess.run(argv,capture_output=True,check=False)
        (self.base/'bash.stdout').write_bytes(result.stdout)
        (self.base/'bash.stderr').write_bytes(result.stderr)
        (self.base/'bash-result.json').write_text(json.dumps(dict(
            scope='OWN extracted path functions with SYNTHETIC uname; no build',
            argv=argv,returncode=result.returncode,both_output_eof=True,
            common_sha256=digest(common),script_sha256=digest(script))))
        self.assertEqual(0,result.returncode);self.assertEqual(b'',result.stderr)
        return Path(result.stdout.decode().strip())

    def test_darwin_factory_matches_exact_selected_shell_functions(self):
        self.assertEqual(self.shell_path('Darwin'),self.factory()['outputs']['canonical_native'])

    def test_linux_factory_matches_exact_selected_shell_functions(self):
        self.assertEqual(self.shell_path('Linux'),self.factory('linux')['outputs']['canonical_native'])

    def test_configured_own_ffi_test_path_is_accepted(self):
        expected=self.repo/'native/transport/target/ffi-test/release/libct_ffi.dylib'
        actual=self.factory(environment={'CONNECTANUM_NATIVE_LIB':str(expected)})
        self.assertEqual(expected,actual['outputs']['canonical_native'])

    def test_configured_standard_release_path_refused_before_constructor(self):
        standard=self.repo/'native/transport/target/release/libct_ffi.dylib'
        with mock.patch.dict(os.environ,{'CONNECTANUM_NATIVE_LIB':str(standard)},clear=True),\
                mock.patch.object(producer.sys,'platform','darwin'),\
                mock.patch.object(producer,'CommandProducer') as cls:
            with self.assertRaises(producer.ProducerError):
                producer.start_canonical(**self.kwargs)
        cls.assert_not_called();self.assertFalse((self.base/'run').exists())

    def test_ci_artifact_override_refused_before_constructor(self):
        with mock.patch.dict(os.environ,{'CONNECTANUM_CI_NATIVE_DIR':'retained-artifacts'},clear=True),\
                mock.patch.object(producer,'CommandProducer') as cls:
            with self.assertRaises(producer.ProducerError):
                producer.start_canonical(**self.kwargs)
        cls.assert_not_called();self.assertFalse((self.base/'run').exists())

    def test_empty_ci_override_preserves_fixed_recipe(self):
        for environment in ({},{'CONNECTANUM_CI_NATIVE_DIR':''}):
            with self.subTest(environment=environment):
                actual=self.factory(environment=environment)
                self.assertEqual([['bin/verify']],actual['commands'])
                self.assertEqual('canonical_recipe',actual['provenance'])



class OwnedOutputLocationTests(unittest.TestCase):
    """Pure location predicates only; do not produce/adopt live evidence."""

    def setUp(self):
        from types import SimpleNamespace
        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:Path(evidence).mkdir(exist_ok=True)
        self.base=Path(tempfile.mkdtemp(prefix='output-location-',dir=evidence)).resolve()
        self.run=SimpleNamespace(repo=self.base/'repo',directory=self.base/'run')

    def test_canonical_ffi_test_locations_for_two_synthetic_platforms(self):
        for platform,filename in (('darwin','libct_ffi.dylib'),('linux','libct_ffi.so')):
            with self.subTest(platform=platform),mock.patch.object(producer.sys,'platform',platform):
                path=self.run.repo/'native/transport/target/ffi-test/release'/filename
                producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)
        self.assertFalse(self.run.directory.exists())

    def test_canonical_rejects_standard_release_and_foreign_output(self):
        with mock.patch.object(producer.sys,'platform','darwin'):
            for path in (self.run.repo/'native/transport/target/release/libct_ffi.dylib',
                    self.base/'foreign/native/transport/target/ffi-test/release/libct_ffi.dylib'):
                with self.subTest(path=str(path)),self.assertRaises(producer.ProducerError):
                    producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)

    def test_three_production_locations_preserved(self):
        for role,suffix in (('native_elf','libct_ffi.so'),('driver_elf','http_stream'),
                ('static_rlib','deps/libct_core-Ab09_.rlib')):
            with self.subTest(role=role):
                producer._validate_owned_output_path(self.run,'execution',role,
                    self.run.directory/'target/release'/suffix)

    def test_production_rejects_wrong_targets_and_rlib_names(self):
        cases=(('native_elf',self.run.repo/'native/transport/target/release/libct_ffi.so'),
            ('driver_elf',self.base/'foreign/target/release/http_stream'),
            ('static_rlib',self.run.directory/'target/release/deps/libct_core-.rlib'),
            ('static_rlib',self.run.directory/'target/release/deps/libct_core-x.y.rlib'),
            ('static_rlib',self.run.directory/'target/release/libct_core-Ab09.rlib'))
        for role,path in cases:
            with self.subTest(role=role,path=str(path)),self.assertRaises(producer.ProducerError):
                producer._validate_owned_output_path(self.run,'execution',role,path)

    def test_phase_and_role_mismatches_refused(self):
        for phase,role in (('canonical','native_elf'),('execution','canonical_native'),
                ('unknown','driver_elf'),('execution','unknown')):
            with self.subTest(phase=phase,role=role),self.assertRaises(producer.ProducerError):
                producer._validate_owned_output_path(self.run,phase,role,
                    self.run.directory/'target/release/http_stream')



class OwnedPreflightTests(unittest.TestCase):
    """Retained phase workers over OWN finite fixtures; no live admission."""
    git=ProducerTests.git

    def setUp(self):
        import threading
        ProducerTests.setUp(self)
        self.owners=[];self.releases=[];self.threading=threading;self.sequence=0

    def tearDown(self):
        for event in self.releases:event.set()
        for owner in self.owners:
            view=owner.observe(2)
            if view['initialized'] and not view['failed'] and not view['producer_finished']:
                self.drive(owner)
            owner.observe(2)
        ProducerTests.tearDown(self)

    def arguments(self,lease_check=lambda:None):
        return dict(repo=self.repo,source_commit=self.head,runtime_commit=self.head,
            run_dir=self.base/('run-'+str(self.sequence)),expected_archive_sha256=self.archive_sha,
            inputs=self.inputs,commands=[[sys.executable,'worker.py','ok']],lease_check=lease_check)

    def start_owned(self,lease_check=lambda:None):
        self.sequence+=1
        nonce=digest((str(self.base)+str(self.sequence)).encode())[:32]
        owner=producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments(lease_check))
        self.owners.append(owner)
        return owner

    def drive(self,owner):
        for _ in range(100):
            view=owner.observe(1)
            if not view['call_done']:continue
            self.assertFalse(view['failed'],view)
            if view['producer_finished'] and not view['producer_pending']:return view
            owner.continue_wait(.2)
        self.fail('OWN finite worker did not complete within declared fixture observations')

    def blocked_lease(self,raise_after=False):
        entered=self.threading.Event();release=self.threading.Event();self.releases.append(release)
        def check():
            entered.set();release.wait()
            if raise_after:raise RuntimeError('synthetic early lease failure')
        return check,entered,release

    def test_early_lease_failure_retains_uninitialized_exact_operation(self):
        def check():raise RuntimeError('synthetic lease failure before IO')
        owner=self.start_owned(check);view=owner.observe(2)
        self.assertEqual('raised',view['call_state']);self.assertTrue(view['failed'])
        self.assertTrue(view['retained_operation']);self.assertFalse(view['initialized'])
        self.assertIsNone(view['producer_pending']);self.assertIsNone(view['actor_ownership_complete'])
        self.assertFalse(owner._operation.__dict__.get('pending',False))
        self.assertNotIn('pending',owner._operation.__dict__)
        self.assertFalse((self.base/'run-1').exists())

    def test_blocked_constructor_observation_and_overlap_refusal(self):
        check,entered,release=self.blocked_lease()
        owner=self.start_owned(check)
        try:
            self.assertTrue(entered.wait(2))
            view=owner.observe(0)
            self.assertFalse(view['call_done']);self.assertTrue(view['retained_operation'])
            self.assertFalse(view['initialized']);self.assertFalse(owner._thread.daemon)
            self.assertNotIn('pending',owner._operation.__dict__)
            with self.assertRaises(TypeError):view['call_done']=True
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
            with self.assertRaises(producer.ProducerError):owner.emit('canonical')
        finally:release.set()
        self.drive(owner)

    def test_postspawn_primary_failure_keeps_same_known_child_until_natural_exit(self):
        original=producer.CommandProducer._event;observed=[]
        def event(run,kind,**kwargs):
            if kind=='command_start':
                observed.append(run.process)
                raise OSError('synthetic postspawn publication failure')
            return original(run,kind,**kwargs)
        with mock.patch.object(producer.CommandProducer,'_event',event):
            owner=self.start_owned();owner.observe(2)
        self.assertTrue(observed);child=observed[0]
        self.drive(owner);run=owner._operation
        self.assertIs(child,run.process)
        self.assertEqual('failed',run.result['status'])
        self.assertEqual(0,run.result['commands'][0]['returncode'])
        self.assertTrue(run.result['commands'][0]['output_eof'])
        self.assertIsNone(owner.observe(0)['actor_ownership_complete'])

    def test_actual_thread_start_then_error_retains_slot_without_restart(self):
        check,entered,release=self.blocked_lease(raise_after=True)
        original=self.threading.Thread.start;calls=[]
        def start(thread):
            calls.append(thread);original(thread)
            self.assertTrue(entered.wait(2))
            raise RuntimeError('synthetic launch return uncertainty after actual thread start')
        with mock.patch.object(self.threading.Thread,'start',start):
            owner=self.start_owned(check)
        try:
            view=owner.observe(0)
            self.assertTrue(view['retained_operation']);self.assertTrue(view['failed'])
            self.assertFalse(view['call_done']);self.assertEqual('start_uncertain',view['call_state'])
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        finally:release.set()
        view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed']);self.assertEqual(1,len(calls))
        self.assertIs(calls[0],owner._thread);self.assertFalse(owner._thread.is_alive())
        self.assertFalse((self.base/'run-1').exists())

    def test_caller_mutation_does_not_change_frozen_commands_or_inputs(self):
        check,entered,release=self.blocked_lease()
        self.sequence+=1;kwargs=self.arguments(check)
        nonce=digest((str(self.base)+'copy').encode())[:32]
        owner=producer.start_owned_preflight('fixture',owner_id=nonce,**kwargs);self.owners.append(owner)
        try:
            self.assertTrue(entered.wait(2))
            kwargs['commands'][0][-1]='nonzero';kwargs['inputs'].clear()
            self.assertIs(check,owner._kwargs['lease_check'])
        finally:release.set()
        self.drive(owner)
        self.assertEqual('success',owner._operation.result['status'])
        self.assertEqual('ok',owner._operation.result['commands'][0]['argv'][-1])

    def test_emit_attempt_is_terminal_and_keeps_first_error(self):
        owner=self.start_owned();self.drive(owner)
        owner.emit('canonical');view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed']);self.assertTrue(view['owner_emit_attempted'])
        first=view['first_error'];self.assertTrue(first)
        with self.assertRaises(producer.ProducerError):owner.emit('canonical')
        self.assertEqual(first,owner.observe(0)['first_error'])
        self.assertTrue((self.base/'run-1/receipt-attempt.json').exists())

    def test_invalid_wait_values_and_forged_entry_hook_refuse(self):
        owner=self.start_owned();owner.observe(2)
        for value in (True,float('nan'),float('inf'),-1,61,'0'):
            with self.subTest(value=repr(value)),self.assertRaises(producer.ProducerError):
                owner.observe(value)
            with self.subTest(wait_value=repr(value)),self.assertRaises(producer.ProducerError):
                owner.continue_wait(value)
        called=[]
        with self.assertRaises(producer.ProducerError):
            producer.CommandProducer(**self.arguments(lambda:called.append(True)),
                provenance='fixture',_preflight_owner=object())
        self.assertEqual([],called)
        with self.assertRaises(producer.ProducerError):
            producer.start_owned_preflight('fixture',owner_id='c'*32,
                **self.arguments(),_preflight_owner=object())
        self.drive(owner)

    def test_duplicate_owner_id_is_permanently_retained(self):
        owner=self.start_owned(lambda:(_ for _ in ()).throw(RuntimeError('synthetic refusal')))
        owner.observe(2);nonce=owner.observe(0)['owner_id']
        with self.assertRaises(producer.ProducerError):
            producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments())
        self.assertIs(owner,producer._PREFLIGHT_OWNERS[nonce])


    def test_exception_representation_is_not_executed_by_observer_publication(self):
        called=[]
        class Error(RuntimeError):
            def __repr__(self):
                called.append(True)
                return 'synthetic dynamic representation'
        def check():raise Error('retained actual exception')
        owner=self.start_owned(check);view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed'])
        self.assertEqual([],called)


if __name__=='__main__':unittest.main()


class CommandOutputCompletionTests(unittest.TestCase):
    """Actual finite OWN direct children; no orphan descendants or benchmark."""
    def setUp(self):
        self.fixture=ProducerTests('runTest');self.fixture.setUp()
        self.base=self.fixture.base
        self.extra=[];self.release=self.base/'release-output-writer'
        self.ready=self.base/'output-writer-ready'

    def tearDown(self):
        self.release.touch(exist_ok=True)
        statuses=[]
        for child in self.extra:
            statuses.append({'pid':child.pid,'returncode':child.wait(5),'role':'OWN separately parented command-output writer'})
        self.fixture.tearDown()
        for run in self.fixture.runs:
            statuses.append({'pid':run.child_pid,'returncode':run.process.returncode,'role':'OWN recipe direct child'})
        (self.base/'owned-output-actors.json').write_text(json.dumps({'scope':'finite OWN direct Popen actors only, not descendants/kernel/capture','actors':statuses}))

    def start_with_writer(self,mode='ok',next_command=True):
        real_popen=producer.subprocess.Popen
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:])
ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-stdout\\n');os.write(2,b'late-owned-stderr\\n')
"""
        def popen(argv,*args,**kwargs):
            if list(argv)==[sys.executable,'worker.py',mode]:
                child=real_popen([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=kwargs['stdout'],stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,close_fds=True)
                self.extra.append(child)
            return real_popen(argv,*args,**kwargs)
        with mock.patch.object(producer.subprocess,'Popen',popen):
            run=self.fixture.start((mode,),('ok',)) if next_command else self.fixture.start((mode,))
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        return run

    def test_command_output_exit_before_eof_blocks_next_and_receipt(self):
        run=self.start_with_writer()
        self.assertEqual(0,run.process.wait(2))
        self.assertIsNone(run.wait(0),'direct exit cannot finalize while an actual OWN output writer holds stdout')
        self.assertTrue(run.pending);self.assertEqual(1,len(run.records))
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'receipt-attempt.json').exists())
        self.release.touch()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertEqual(2,len(result['commands']))
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertIn(b'late-owned-stdout',raw);self.assertIn(b'late-owned-stderr',raw)
        self.assertTrue(result['commands'][0]['output_eof'])
        self.assertFalse(result['commands'][0]['whole_descendant_exit_proven'])

    def test_command_output_nonzero_waits_writer_without_next_command(self):
        run=self.start_with_writer('nonzero')
        self.assertEqual(7,run.process.wait(2))
        self.assertIsNone(run.wait(0))
        self.assertEqual(7,run.records[0]['returncode'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn(b'late-owned-stderr',(run.directory/'command-000.log').read_bytes())

    def test_command_output_large_pipe_drains_without_wait_deadlock(self):
        code="import os;data=b'A'*65536;[os.write(1,data) for _ in range(40)];os.write(2,b'END')"
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code]])
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status'])
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(40*65536+3,len(raw));self.assertEqual(digest(raw),result['commands'][0]['log_sha256'])
        self.assertTrue(result['commands'][0]['output_eof'])

    def test_command_output_eof_before_exit_keeps_child_owned(self):
        code="""import os,sys,time
from pathlib import Path
os.close(1);os.close(2)
ready,release=map(Path,sys.argv[1:]);ready.write_text('closed')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
"""
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code,str(self.ready),str(self.release)]])
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        self.assertIsNone(run.wait(.03));self.assertIsNone(run.process.returncode);self.assertTrue(run.pending)
        self.assertTrue(run.records[0]['output_eof'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertEqual('success',result['status'])


    def test_command_output_later_read_error_preserves_first_journal_failure(self):
        original=producer.CommandProducer._event
        def event(run,kind,**fields):
            if kind=='command_spawned':raise OSError(13,'PRIMARY postspawn journal fault')
            return original(run,kind,**fields)
        with mock.patch.object(producer.CommandProducer,'_event',event):run=self.fixture.start(('ok',),('ok',))
        original_read=producer.os.read;fd=run.output_fd
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY pipe read fault')
            return original_read(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn('PRIMARY',result['error'])
        self.assertTrue(any('SECONDARY' in x for x in result['commands'][0]['secondary_errors']))
        self.assertFalse(result['commands'][0]['log_complete'])

    def test_command_output_short_writes_keep_bytes_and_fd_flags(self):
        run=self.fixture.start(('large',));original=run.output_log
        self.assertFalse(os.get_inheritable(run.output_fd));self.assertFalse(os.get_blocking(run.output_fd))
        class Short:
            def write(self,data):return original.write(data[:17])
        run.output_log=Short()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertIsNone(run.output_fd)
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000,raw)
        self.assertTrue(result['commands'][0]['parent_output_write_close_confirmed'])

    def test_command_output_eof_close_error_consumes_fd_once(self):
        run=self.fixture.start(('ok',));fd=run.output_fd;original_close=producer.os.close;calls=[]
        def close(target):
            if target==fd:
                calls.append(target);original_close(target);raise OSError(5,'uncertain EOF descriptor close')
            return original_close(target)
        with mock.patch.object(producer.os,'close',close):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual([fd],calls);self.assertIsNone(run.output_fd)
        self.assertEqual('failed',result['status']);self.assertEqual(0,run.records[0]['returncode'])
        self.assertIn('uncertain EOF descriptor close',result['error'])

    def test_command_output_write_failure_quarantines_without_replay(self):
        run=self.fixture.start(('large',));original=run.output_log;calls=[]
        class Fault:
            def write(self,data):calls.append(len(data));raise OSError(28,'injected log-space fault')
        run.output_log=Fault()
        try:
            self.assertIsNone(run.wait(2));fd=run.output_fd
            self.assertTrue(run.output_write_uncertain);self.assertTrue(run.output_buffer)
            self.assertIsNone(run.wait(0));self.assertEqual(1,len(calls))
            self.assertEqual(fd,run.output_fd);self.assertTrue(run.pending)
            self.assertFalse(run.evidence_complete);self.assertFalse((run.directory/'result.json').exists())
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
            raw=json.loads((run.directory/'failure.json').read_text())
            self.assertEqual(run.output_buffer,base64.b64decode(raw['unwritten_output_base64']))
        finally:
            # Tiny finite OWN child fits available pipe capacity: no kill/cancel,
            # no producer recovery, no live cleanup workaround or success receipt.
            status=run.process.wait(3)
            (self.base/'fixture-quarantined-output.json').write_text(json.dumps({
                'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit; producer stays quarantined/unadmitted',
                'pid':run.child_pid,'returncode':status,'unwritten_sha256':digest(run.output_buffer),
                'unwritten_base64':base64.b64encode(run.output_buffer).decode('ascii')}))
            self.extra.append(run.process)
            fd=run.output_fd;run.output_fd=None
            if fd is not None:os.close(fd)
            original.close();run.log=None;run.output_log=None
            if run.events is not None:run.events.close();run.events=None
            self.fixture.runs.remove(run)


    def test_command_output_partial_failure_evidence_never_retried(self):
        original_event=producer.CommandProducer._event;original_write=producer._write_json;calls=[]
        def event(run,event_name,**fields):
            if event_name=='command_spawned':raise OSError(13,'PRIMARY journal fault')
            return original_event(run,event_name,**fields)
        def write(path,value):
            if Path(path).name=='failure.json':
                calls.append(str(path))
                if len(calls)==1:
                    with Path(path).open('xb') as f:f.write(b'PARTIAL-ORIGINAL-FAILURE')
                    raise OSError(28,'secondary failure-publication space error')
            return original_write(path,value)
        with mock.patch.object(producer.CommandProducer,'_event',event),mock.patch.object(producer,'_write_json',write):
            run=self.fixture.start(('ok',),('ok',));fd=run.output_fd;real_read=producer.os.read
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY stream fault')
                return real_read(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
            result=self.fixture.finish(run)
        self.assertEqual(1,len(calls));self.assertIn('PRIMARY',result['error'])
        self.assertEqual(b'PARTIAL-ORIGINAL-FAILURE',(run.directory/'failure.json').read_bytes())
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))


class GitOutputTests(unittest.TestCase):
    """Actual OWN Git/extra finite writers, separate output endpoints, no orphan."""
    def setUp(self):
        self.f=ProducerTests('runTest');self.f.setUp();self.base=self.f.base
        self.actors=[];self.release=self.base/'release-git-writer';self.ready=self.base/'git-writer-ready'
        self.threads=[];self.parent=None;self.operations=[]

    def tearDown(self):
        self.release.touch(exist_ok=True)
        for thread in self.threads:
            thread.join(6)
            self.assertFalse(thread.is_alive(),'OWN finite observer thread must finish naturally')
        for operation in self.operations:
            if operation.pending:self.finish_auxiliary(operation)
            if operation.process is not None:self.actors.append(operation.process)
        statuses=[{'pid':child.pid,'returncode':child.wait(5)} for child in self.actors]
        self.f.tearDown()
        if self.parent is not None and self.parent.events is not None:self.parent.events.close();self.parent.events=None
        (self.base/'owned-git-output-actors.json').write_text(json.dumps({'scope':'OWN main-parented finite Popen actors only; no descendants/kernel/capture','statuses':statuses}))

    def gate_observation(self,call,match):
        import threading,time
        real=producer.subprocess.Popen;selected=[];outcome={};done=threading.Event()
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:]);ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-git-output\\n');os.write(2,b'late-owned-git-stderr\\n')
"""
        def popen(argv,*args,**kw):
            if not selected and match(list(argv)):
                writer=real([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=kw['stdout'],stderr=kw['stderr'],stdin=subprocess.DEVNULL,close_fds=True)
                self.actors.append(writer)
                child=real(argv,*args,**kw);selected.append(child);self.actors.append(child)
                return child
            return real(argv,*args,**kw)
        def observe():
            try:outcome['value']=call()
            except BaseException as error:outcome['error']=error
            finally:done.set()
        with mock.patch.object(producer.subprocess,'Popen',popen):
            thread=threading.Thread(target=observe);self.threads.append(thread);thread.start()
            try:
                end=time.monotonic()+2
                while (not self.ready.exists() or not selected) and time.monotonic()<end:time.sleep(.005)
                self.assertTrue(selected);self.assertTrue(self.ready.exists())
                self.assertEqual(0,selected[0].wait(2))
                self.assertFalse(done.wait(.10),'Git observation completed before actual retained stdout/stderr writer EOF')
            finally:
                self.release.touch(exist_ok=True);thread.join(6)
        self.assertFalse(thread.is_alive())
        return outcome

    def test_git_initial_observer_waits_both_real_output_writers(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'direct';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb')
        outcome=self.gate_observation(lambda:run._git('rev-parse','HEAD'),lambda argv:argv[-2:]==['rev-parse','HEAD'])
        if 'error' in outcome:raise outcome['error']
        self.assertIn(b'late-owned-git-output',outcome['value'])
        self.assertIn(b'late-owned-git-stderr',(run.directory/'git-000.stderr').read_bytes())

    def test_git_receipt_observer_refuses_late_dirty_status_bytes(self):
        run=self.f.receipt_fixture()[0]
        outcome=self.gate_observation(lambda:producer.emit_fixture_receipt(run,'canonical'),
            lambda argv:argv[-3:]==['status','--porcelain','--untracked-files=normal'])
        self.assertIsInstance(outcome.get('error'),producer.ProducerError)
        self.assertIn('not clean',str(outcome['error']))
        self.assertFalse((run.directory/'input-receipt.json').exists())
        self.assertTrue((run.directory/'receipt-failure.json').exists())


    def make_auxiliary(self,code,**kw):
        directory=self.base/'auxiliary';directory.mkdir(mode=0o700)
        op=producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c',code],
            cwd=self.f.repo,environment=dict(os.environ),lease_check=lambda:None,**kw)
        self.operations.append(op)
        return op

    def finish_auxiliary(self,op):
        import time
        end=time.monotonic()+6
        result=op.result
        while result is None and time.monotonic()<end:result=op.wait(2)
        self.assertIsNotNone(result,'OWN finite observation must complete naturally')
        return result

    def test_git_auxiliary_intent_and_owner_before_spawn(self):
        op=self.make_auxiliary("print('owned')");real=producer.subprocess.Popen;observed=[]
        def popen(*args,**kwargs):
            self.assertIn(op,self.operations)
            self.assertEqual(op.intent_sha256,digest((op.directory/'probe-intent.json').read_bytes()))
            self.assertTrue((op.directory/'probe-started.json').is_file());observed.append(True)
            return real(*args,**kwargs)
        with mock.patch.object(producer.subprocess,'Popen',popen):op.start()
        self.assertEqual([True],observed)
        self.assertFalse(os.get_inheritable(op.streams['stdout']['fd']))
        self.assertFalse(os.get_blocking(op.streams['stderr']['fd']))
        result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status']);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_git_auxiliary_declaration_drift_is_prechild_terminal(self):
        op=self.make_auxiliary("print('original')")
        op.argv=(sys.executable,'-c',"print('changed')");op.intent['argv']=list(op.argv)
        op.start()
        self.assertIsNone(op.process);self.assertEqual('failed',op.result['status'])
        self.assertIn('plan changed',op.result['primary_error'])
        with self.assertRaises(producer.ProducerError):op.start()

    def test_git_auxiliary_drains_two_capacity_streams(self):
        op=self.make_auxiliary("import os;[os.write(1,b'A'*65536) for _ in range(20)];[os.write(2,b'B'*65536) for _ in range(17)]")
        op.start();result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status'])
        for role,raw in [('stdout',b'A'*(20*65536)),('stderr',b'B'*(17*65536))]:
            self.assertEqual(raw,(op.directory/('probe.'+role)).read_bytes())
            self.assertEqual(digest(raw),result['outputs'][role]['stream_sha256'])
            self.assertTrue(result['outputs'][role]['eof']);self.assertTrue(result['outputs'][role]['snapshot_matches_stream'])

    def test_git_auxiliary_postspawn_first_error_and_secondary_retained(self):
        op=self.make_auxiliary("print('finite-owned')");original=producer._write_json
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(28,'PRIMARY postspawn observation publication')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):op.start()
        self.assertTrue(op.pending);self.assertIsNotNone(op.process)
        real=producer.os.read;fd=op.streams['stdout']['fd']
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY output read')
            return real(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
        result=self.finish_auxiliary(op)
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIn('PRIMARY',result['primary_error']);self.assertTrue(any('SECONDARY' in x for x in result['secondary_errors']))

    def test_git_auxiliary_eof_close_ownership_consumed_once(self):
        op=self.make_auxiliary("print('finite')");op.start();fd=op.streams['stdout']['fd'];real=producer.os.close;calls=[]
        def close(target):
            if target==fd and not calls:
                calls.append(target);real(target);raise OSError(5,'ambiguous read-end close')
            return real(target)
        with mock.patch.object(producer.os,'close',close):result=self.finish_auxiliary(op)
        self.assertEqual([fd],calls);self.assertIsNone(op.streams['stdout']['fd'])
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        with self.assertRaises(producer.ProducerError):op.wait(0)

    def test_git_auxiliary_ambiguous_write_quarantines_without_replay(self):
        op=self.make_auxiliary("import os;os.write(1,b'tiny-raw')");op.start();original=op.streams['stdout']['log'];calls=[]
        class Fault:
            def write(self,data):calls.append(bytes(data));raise OSError(28,'injected auxiliary space fault')
        op.streams['stdout']['log']=Fault()
        try:
            self.assertIsNone(op.wait(2));self.assertTrue(op.streams['stdout']['quarantined'])
            self.assertIsNone(op.wait(0));self.assertEqual([b'tiny-raw'],calls)
            self.assertTrue(op.pending);self.assertIsNone(op.result)
            raw=json.loads((op.directory/'probe-failure.json').read_text())
            self.assertEqual(b'tiny-raw',base64.b64decode(raw['unwritten_base64']['stdout']))
        finally:
            status=op.process.wait(3)
            (self.base/'fixture-auxiliary-quarantine-cleanup.json').write_text(json.dumps({'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit, NO producer recovery/admission',
                'pid':op.process.pid,'returncode':status,'unwritten_base64':base64.b64encode(op.streams['stdout']['buffer']).decode('ascii')}))
            self.actors.append(op.process);self.operations.remove(op)
            for stream in op.streams.values():
                for name in ('fd','writer'):
                    fd=stream[name];stream[name]=None
                    if fd is not None:os.close(fd)
                if stream['log'] is not None and stream['log'] is not op.streams['stdout']['log']:stream['log'].close()
                stream['log']=None
            original.close()

    def test_git_auxiliary_eof_before_child_exit_remains_pending(self):
        code="import os,time;from pathlib import Path;os.close(1);os.close(2);p=Path("+repr(str(self.ready))+");p.write_text('ready');r=Path("+repr(str(self.release))+");end=time.monotonic()+4\nwhile not r.exists() and time.monotonic()<end:time.sleep(.005)"
        op=self.make_auxiliary(code);op.start()
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists());self.assertIsNone(op.wait(.03));self.assertIsNone(op.status)
        self.assertTrue(all(s['eof'] for s in op.streams.values()));self.release.touch()
        self.assertEqual('success',self.finish_auxiliary(op)['status'])

    def test_git_auxiliary_boolean_bounds_refuse_before_io(self):
        directory=self.base/'invalid';directory.mkdir()
        with self.assertRaises(producer.ProducerError):producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c','pass'],cwd=self.f.repo,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=True)
        self.assertEqual([],list(directory.iterdir()))

    def test_git_auxiliary_partial_failure_evidence_has_one_attempt(self):
        op=self.make_auxiliary("print('finite')");original=producer._write_json;calls=[]
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(13,'PRIMARY postspawn')
            if Path(path).name=='probe-failure.json':
                calls.append(True)
                with Path(path).open('xb') as f:f.write(b'PARTIAL-OWN-FAILURE')
                raise OSError(28,'secondary publication space failure')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):
            op.start();real=producer.os.read;fd=op.streams['stdout']['fd']
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY read')
                return real(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
            result=self.finish_auxiliary(op)
        self.assertEqual([True],calls);self.assertIn('PRIMARY',result['primary_error'])
        self.assertEqual(b'PARTIAL-OWN-FAILURE',(op.directory/'probe-failure.json').read_bytes())
        self.assertEqual('failed',result['status'])


    def test_git_consume_initial_rejects_changed_bytes_after_snapshot(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'consume';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb');original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            path=owner.directory/(name+'.stdout');raw=path.read_bytes()
            with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
            self.assertNotEqual(b'0'*40+b'\n',raw);path.write_bytes(b'0'*40+b'\n')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):run._git('rev-parse','HEAD')

    def test_git_consume_receipt_rejects_forged_empty_dirty_status(self):
        run=self.f.receipt_fixture()[0]
        (self.f.repo/'OWN-new-untracked-input').write_text('OWN synthetic dirty source control')
        original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            if argv[-3:]==['status','--porcelain','--untracked-files=normal']:
                path=owner.directory/(name+'.stdout');raw=path.read_bytes();self.assertTrue(raw)
                with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
                path.write_bytes(b'')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'input-receipt.json').exists())
