import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owned-preflight')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads((P/'last-before-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/native_perf_build_producer.py';source=path.read_text()
 source=source.replace('_PREFLIGHT_OWNERS={}\n','_PREFLIGHT_OWNERS={}\n_PREFLIGHT_OWNER_LIMIT=64\n',1)
 old="            thread=threading.Thread(target=self._work,args=(action,value,self._event),daemon=False)\n            self._thread=thread;self._snapshot=self._snapshot_locked()"
 new="            try:thread=threading.Thread(target=self._work,args=(action,value,self._event),daemon=False)\n            except BaseException as error:\n                self._thread=None;self._state='start_uncertain';self._error_locked(error)\n                self._snapshot=self._snapshot_locked();return self\n            self._thread=thread;self._snapshot=self._snapshot_locked()"
 assert source.count(old)==1;source=source.replace(old,new,1)
 old="    frozen=_copy_preflight_kwargs(kwargs)\n    owner=_RetainedPreflightOwner(kind,owner_id,frozen)\n    with _PREFLIGHT_OWNERS_LOCK:\n        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')\n        _PREFLIGHT_OWNERS[owner_id]=owner"
 new="    with _PREFLIGHT_OWNERS_LOCK:\n        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')\n        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')\n    frozen=_copy_preflight_kwargs(kwargs)\n    owner=_RetainedPreflightOwner(kind,owner_id,frozen)\n    with _PREFLIGHT_OWNERS_LOCK:\n        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')\n        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')\n        _PREFLIGHT_OWNERS[owner_id]=owner"
 assert source.count(old)==1;source=source.replace(old,new,1);ast.parse(source);path.write_text(source)
 summary=runtests('final',['OwnedPreflightTests',
 'ProducerTests.test_postspawn_journal_error_keeps_owned_child_waitable',
 'ProducerTests.test_production_recipe_factory_only_synthetic_argv_observation',
 'ProducerTests.test_canonical_recipe_factory_only_synthetic_argv_observation'])
 lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
