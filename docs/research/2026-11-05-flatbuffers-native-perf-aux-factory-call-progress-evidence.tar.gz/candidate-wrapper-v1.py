def _observe_auxiliary(owner,name,argv,stdout_max=1024**3):
    _auxiliary_factory_guard(owner)
    record=_AuxiliaryFactoryAttempt(owner,name,argv,stdout_max)
    _AUXILIARY_FACTORY_ATTEMPTS.append(record) # Before owner field lookup/class call.
    _AUXILIARY_FACTORY_LAST[id(owner)]=(owner,record) # Strong owner ref; grouping DATA only.
    return record.run()
