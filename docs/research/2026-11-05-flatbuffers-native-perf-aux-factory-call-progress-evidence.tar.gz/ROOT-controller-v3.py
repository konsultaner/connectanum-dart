import sys,pathlib,json,ast,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-factory-call-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'candidate-v2.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'aux_factory_call_regressions.py').read_bytes()
 old=(P/'before-producer.py').read_text();ot=ast.parse(old);ct=ast.parse(source)
 original=ast.get_source_segment(old,next(n for n in ot.body if isinstance(n,ast.FunctionDef) and n.name=='_observe_auxiliary'))
 extra=(P/'candidate-extra-v2.py').read_text();wrapper=(P/'candidate-wrapper-v1.py').read_text().rstrip()
 assert source.replace(extra+'\n\n','',1).replace(wrapper,original,1)==old
 before=json.loads((P/'before-units/result.json').read_text());assert(before['tests'],before['failures'],before['passes'],before['errors'])==(7,6,1,0)
 after=json.loads((P/'after-selected/result.json').read_text());assert(after['tests'],after['failures'],after['errors'])==(21,0,0)
 def views(path):
  found={}
  for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')):
   v=json.loads(f.read_text())
   if 'Source_attempt_present' in v:found[v['mode']]=(v,f.parent)
  return found
 b=views(P/'before-units/fixtures');a=views(P/'after-selected/fixtures');assert len(a)==len(b)==7
 for mode,(v,base) in a.items():
  assert v['Source_attempt_present'] and v['Source_render_before_unitasserts']==[]
  assert all(row['raw_None'] for row in v['leases'])
  if mode=='normal':
   assert v['received_type'] is None and v['Source_completed'] and v['result_returned']
   assert v['Source_constructor_returned'] is True and v['Source_raw_is_ROOT_allocated']
   assert v['original_owner_count']==v['current_owner_count']==v['process_returns']==1
   assert bytes.fromhex(v['stdout_hex'])==b'declared-original' and bytes.fromhex(v['stderr_hex'])==b'OWN-factory-stderr'
   assert next(e for e in v['events'] if e['kind']=='start_attempt')['original_collection_contains']
  else:
   assert v['original_owner_count']==v['current_owner_count']==v['process_returns']==0 and not v['Source_completed']
   assert v['Source_first_received'] and v['guard_first_is_received'] and not v['result_returned']
   assert v['stdout_hex'] is None and v['stderr_hex'] is None and not any(e['kind']=='start_attempt' for e in v['events'])
   if mode in ('constructor_error','outside_init_False'):
    assert v['Source_constructor_returned'] is None and v['Source_raw_None'] and not v['Source_raw_is_ROOT_allocated']
   else:assert v['Source_constructor_returned'] is True
 assert b['env_drift'][0]['process_returns']==b['list_alias'][0]['process_returns']==1
 assert bytes.fromhex(b['env_drift'][0]['stdout_hex'])==b'ROOT-changed-before-copy'
 assert b['list_alias'][0]['original_owner_count']==0 and b['list_alias'][0]['current_owner_count']==1
 for mode in ('return_None','return_False'):assert b[mode][0]['current_owner_count']==1 and b[mode][0]['received_type']=='AttributeError'
 assert b['constructor_error'][0]['received_original'] and b['outside_init_False'][0]['received_type']=='TypeError'
 waits={};leasecounts={}
 for phase,values in [('before',b),('after',a)]:
  rows=[row for v,base in values.values() for row in json.loads((base/'ROOT-unit-cleanup.json').read_text())]
  assert len(rows)==(3 if phase=='before' else 1) and all(type(row['status']) is int and row['status']==0 for row in rows)
  waits[phase]=rows;leasecounts[phase]=sum(len(v['leases']) for v,base in values.values())
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'Same original public classcall; known returnedobject retained before append/start. Hidden allocation/initializer completion never fills unknown constructor raw. Known None/False separate from UNKNOWN/0.',
 'Strongownerref/id grouping and native argv/environment/context snapshots are DATA, not credentials/kernelidentity/ABA/physicalEX/admission. No freeze/restore/recovery.',
 'Negatives do not call Source start/wait/reobserve afterfault, only pureguard preserving first before pending/metadata. No methodauthority from fields.',
 'Before/after SAMEprocess actualCURRENT officialDarwinEX, not independent fullEX/originalLinuxcredentials; known finite ROOT waits0 cachedpossible UNITdata not EXrelease/livecontinuation/actorcensus.',
 'Legacysetup/FD/interpreter/delegate/descendant APIreturns notall serialized. Earlier prep exec API display truncated and notseparatelysaved; omittedreturn/status not reconstructed. Later SAMEsession review result saved.',
 'Owner getter/append lookup-exception/rawfalse/subclass/argumentbinding/metadatadamage/repeated normal owner/suffix native-negative seams SOURCEonly/unexecuted.',
 'Allrecords/owner-env-argv/sharedrefs/closures/tracebacks retained PROCESSLIFE; growth UNMEASURED/no heapRSSbound/leak/timing/cause/reset-evict-delete authority.',
 'Candidate v1-v2 UNEXECUTED before edit; v2 stage avoids suffixfault attachment to successful context row. GLM tokenlimit fullpartialfinalABSENT/no unchangedrepeat/unavailableapproval.',
 'ROOT v2 projectback assertion omitted the exact two assembly separator newlines; failed before views-Git-ROOToutputs. v3 removes exact inserted extra plus two separator newlines; Source/tests/models unchanged, no rerun.',
 'ROOT controller preparation v1 JavaScript String.index TypeError BEFORE controller construction/files/Source-tests-models-Git calls; v2 corrects indexOf only/no invented Source failure.',
 'All20 helpers uncommitted/uncanonical/unadmitted; production601exact; no actualSDK-build-canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictdispatch. Provider absent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.']
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 before=dict(tests=7,failures=6,passes=1,errors=0,interpretation='2actual context-drift child launches;2known invalid constructor returns appended;2stronger intent/raw/privatefirst policies where old first already escapes. NOT6 native/kernel bugs or RAM cause.'),after=after,
 ROOT=dict(whole_final_source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,original_Auxiliary_Popen_frozenpredicates_exact=True,original_start_result_wait60_status_suffix_AST_exact=True,new_views=14,new_same_bounded_ROOT_waits=waits,cached_possible=True,current_EX_facade_verify_None_counts=leasecounts,ordinary_actualpublic_classcall=True,allocation_initializer_vs_constructor_raw_separate=True),
 models=dict(Qwen=dict(pid=2805,status=0,stdout_size=3496,stderr_size=481,fullanswer=True),GLM_review=dict(pid=3607,status=1,stdout_size=0,stderr_size=1612,full_partial_final='ABSENT/not reconstructed',reason='token limit'),all_reaped_advisory_ROOTqualified_NOT_wholecurrentapproval=True),
 scope='ONLY original _observe_auxiliary public classcall rawreturn/context and original owner append stop barriers; legacy suffix API progress remains incomplete',limits=limits,
 remaining=['pernative earlier initializer/writer/hash negative API seams','actual FileIO backingwriters/internalFD errors','enclosingproducer cleanup/reporting and legacy factory suffix intent/raw barriers','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedjournalwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_call_progress'];n.update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False);c['active_turn_status']='Auxiliary_factory_call_selected21PASS_ROOTqualified_DOCS_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],tests=21,git4_0_BOTH_EOF=True,new_views=14,leasecounts=leasecounts,free_bytes=free,full_admission=False)))
