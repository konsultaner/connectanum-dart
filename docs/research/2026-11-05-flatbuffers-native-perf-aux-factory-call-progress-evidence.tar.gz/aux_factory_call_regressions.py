"""NEW original factory-call/context units; no metadata grants method authority."""
from pathlib import Path
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock
import native_perf_build_producer as producer


class AuxiliaryFactoryCallProgressTests(unittest.TestCase):
    def _factory_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-factory-'+mode+'-',dir=os.environ.get('CONNECTANUM_AUX_FACTORY_FIXTURES',tempfile.gettempdir()))).resolve()
        original_list=[];other_list=[]
        environment=dict(os.environ);environment['AUX_FACTORY_OWN_UNIT_SENTINEL']='declared-original'
        owner=types.SimpleNamespace(directory=base,repo=base,environment=environment,lease_check=None,auxiliary_operations=original_list)
        events=[];actors=[];leases=[];seen={};render=[]
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after original initializer')
        cls=producer.AuxiliaryCommand;native_new=cls.__new__;native_init=cls.__init__;native_start=cls.start;native_allocate=cls._allocate_process
        def verify():
            raw=official_ex_verify();leases.append(dict(returned=True,raw_None=raw is None));return raw
        owner.lease_check=verify
        def newing(actual_class,*args,**kwargs):
            raw=native_new(actual_class,*args,**kwargs);seen['allocated']=raw
            events.append(dict(kind='actual_new_return',same_class=type(raw) is cls))
            if mode=='list_alias':owner.auxiliary_operations=other_list
            if mode=='return_False':events.append(dict(kind='ROOT_new_returns_False'));return False
            if mode=='return_None':events.append(dict(kind='ROOT_new_returns_None'));return None
            return raw
        def initializing(a,*args,**kwargs):
            events.append(dict(kind='init_attempt'))
            if mode=='env_drift':kwargs['environment']['AUX_FACTORY_OWN_UNIT_SENTINEL']='ROOT-changed-before-copy'
            raw=native_init(a,*args,**kwargs)
            events.append(dict(kind='actual_init_return',raw_None=raw is None))
            if mode=='constructor_error':raise first
            if mode=='outside_init_False':return False
            return raw
        def starting(a):
            events.append(dict(kind='start_attempt',original_collection_contains=any(x is a for x in original_list),current_collection_is_original=owner.auxiliary_operations is original_list))
            return native_start(a)
        def allocating(a,record):
            raw=native_allocate(a,record);actors.append(dict(process=raw,bound_wait=raw.wait))
            events.append(dict(kind='process_return',pid=raw.pid));return raw

        argv=[sys.executable,'-c',"import os;os.write(1,os.environ['AUX_FACTORY_OWN_UNIT_SENTINEL'].encode());os.write(2,b'OWN-factory-stderr')"]
        received=None;guard_error=None;result=None
        try:
            with mock.patch.object(cls,'__new__',staticmethod(newing)),mock.patch.object(cls,'__init__',initializing),mock.patch.object(cls,'start',starting),mock.patch.object(cls,'_allocate_process',allocating):
                try:result=producer._observe_auxiliary(owner,'factory-call',argv,stdout_max=1024)
                except BaseException as error:received=error
                guard=getattr(producer,'_auxiliary_factory_guard',None)
                if mode!='normal' and guard is not None:
                    try:guard(owner)
                    except BaseException as error:guard_error=error
            records=getattr(producer,'_AUXILIARY_FACTORY_ATTEMPTS',None)
            found=[] if type(records) is not list else [r for r in records if getattr(r,'owner',None) is owner]
            attempt=found[-1] if found else None
            out=base/'factory-call.stdout';err=base/'factory-call.stderr'
            stdout=out.read_bytes() if out.exists() else None;stderr=err.read_bytes() if err.exists() else None
            raw=None if attempt is None else attempt.constructor_raw_return
            view=dict(mode=mode,events=events,leases=leases,received_type=None if received is None else type(received).__name__,received_original=received is first,
                guard_first_is_received=received is not None and guard_error is received,
                original_owner_count=len(original_list),current_owner_count=len(owner.auxiliary_operations),owner_list_is_original=owner.auxiliary_operations is original_list,
                current_owner_values=[type(x).__name__ for x in owner.auxiliary_operations],process_returns=len(actors),result_returned=result is not None,
                stdout_hex=None if stdout is None else stdout.hex(),stderr_hex=None if stderr is None else stderr.hex(),
                Source_attempt_present=attempt is not None,Source_constructor_returned=None if attempt is None else attempt.constructor_returned,
                Source_raw_None=raw is None,Source_raw_False=raw is False,Source_raw_is_ROOT_allocated=raw is seen.get('allocated'),
                Source_completed=False if attempt is None else attempt.completed,
                Source_first_received=attempt is not None and received is not None and attempt.first_error is received,
                Source_render_before_unitasserts=list(render),
                limits='Ctor/raw/context/append observations only, not origin/credentials/partialPopen/ownership/physicalEX/admission; allocation/initializer completion cannot fill unknown factory raw')
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n')
            if stdout is not None:(base/'observed-stdout.bin').write_bytes(stdout)
            if stderr is not None:(base/'observed-stderr.bin').write_bytes(stderr)
            self.assertEqual([],render)
            self.assertTrue(all(x['raw_None'] for x in leases))
            if mode=='normal':
                self.assertTrue(received is None)
                self.assertEqual('success',result['status'])
                self.assertEqual(b'declared-original',stdout);self.assertEqual(b'OWN-factory-stderr',stderr)
                self.assertEqual(1,len(original_list))
                self.assertTrue(next(e['original_collection_contains'] for e in events if e['kind']=='start_attempt'))
                if attempt is not None:self.assertTrue(attempt.completed)
            else:
                if mode=='constructor_error':self.assertTrue(received is first)
                elif mode=='outside_init_False':self.assertTrue(type(received) is TypeError)
                else:self.assertTrue(type(received) is producer.ProducerError,'invalid context/return advanced instead of refusing')
                self.assertEqual(0,len(original_list));self.assertEqual(0,len(owner.auxiliary_operations))
                self.assertEqual([],actors)
                self.assertFalse(any(e['kind']=='start_attempt' for e in events))
                self.assertTrue(attempt is not None,'Source factory intent/raw refs not retained')
                self.assertTrue(attempt.first_error is received)
                self.assertTrue(guard_error is received)
                self.assertFalse(attempt.completed)
                if mode in ('constructor_error','outside_init_False'):
                    self.assertIsNone(attempt.constructor_returned)
                    self.assertIsNone(attempt.constructor_raw_return,'hidden initialized object was adopted')
                else:
                    self.assertTrue(attempt.constructor_returned is True)
                    if mode=='return_False':self.assertTrue(attempt.constructor_raw_return is False)
                    elif mode=='return_None':self.assertIsNone(attempt.constructor_raw_return)
                    else:self.assertTrue(attempt.constructor_raw_return is seen['allocated'])
                count=len(events)
                try:producer._auxiliary_factory_guard(owner)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('pure factory guard accepted failed attempt')
                self.assertEqual(count,len(events))
        finally:
            cleanup=[]
            for actor in actors:
                raw=actor['bound_wait'](10)
                cleanup.append(dict(kind='ROOT_bounded_same_finite_wait',pid=actor['process'].pid,status=raw,cached_possible=True))
                self.assertTrue(type(raw) is int and raw==0)
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_constructor_with_owner_list_alias_drift_stops_before_append_start(self):self._factory_case('list_alias')
    def test_actual_constructor_consumes_env_drift_but_refuses_child_launch(self):self._factory_case('env_drift')
    def test_actual_initializer_None_then_classcall_error_keeps_raw_UNKNOWN(self):self._factory_case('constructor_error')
    def test_actual_allocation_then_classcall_False_is_known_invalid_not_zero(self):self._factory_case('return_False')
    def test_actual_allocation_then_classcall_None_is_known_invalid_not_unknown(self):self._factory_case('return_None')
    def test_native_classcall_TypeError_keeps_unknown_raw_and_first(self):self._factory_case('outside_init_False')
    def test_normal_original_factory_keeps_full_bytes_and_append_before_start(self):self._factory_case('normal')
