import sys,pathlib,json,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-call-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();old=(P/'before-producer.py').read_bytes();oldtests=(P/'before-tests.py').read_bytes()
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==old and (R/'tool/test_native_perf_build_producer.py').read_bytes()==oldtests
 proof=json.loads((P/'candidate-ROOT-projection.json').read_text());assert proof['wholeSource_BYTE_projectsback']
 source=(P/'candidate-v2.py').read_bytes();tests=oldtests+b'\n\n'+(P/'aux_factory_call_regressions.py').read_bytes()
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(tests)
 before=json.loads((P/'before-hashes.json').read_text());h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in before}
 assert sorted(k for k in before if h[k]!=before[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').write_bytes(source);(P/'after-tests.py').write_bytes(tests);(P/'after-edit-hashes.json').write_text(json.dumps(h,indent=2))
 value=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],other18_helpers3bins_unchanged=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,Auxiliary_Popen_code_and_frozenpredicates_unchanged=True,original_start_wait60_status_suffix_AST_exact=True)
 (P/'edit-result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_call_progress'];n.update(source_UNCHANGED=False,candidate_UNIMPLEMENTED=False,edit=value,model_pending=False,after_pending=True);c['active_turn_status']='Auxiliary_factory_NEW7_before6FAIL1PASS_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(value))
