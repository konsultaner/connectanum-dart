# Factory-call progress is DATA, not constructor-origin/owner/EX authority.
_AUXILIARY_FACTORY_ATTEMPTS = []
_AUXILIARY_FACTORY_LAST = {}


def _auxiliary_factory_guard(owner):
    last=_AUXILIARY_FACTORY_LAST.get(id(owner))
    if last is None:return
    if type(last) is not tuple or len(last)!=2 or last[0] is not owner:
        raise ProducerError('auxiliary factory owner binding changed')
    record=last[1]
    record.guard() # Exact received first precedes pending/metadata checks.
    if record.completed is not True:
        raise ProducerError('auxiliary factory observation is pending or unknown')


class _AuxiliaryFactoryAttempt(_JSONWriteAttempt):
    def __init__(self,owner,name,argv,stdout_max):
        super().__init__(None,None)
        self.owner=owner
        self.name=name
        self.argv=argv
        self.stdout_max=stdout_max
        self.constructor=None
        self.constructor_attempted=False
        self.constructor_returned=None
        self.constructor_raw_return=None
        self.context_refs=None
        self.input_values=None
        self.original_members=None
        self.operation=None
        self.append_returned=None
        self.append_raw_return=None
        self.stage='before_constructor'

    def _context(self,owner):
        values=[]
        for name in ('directory','repo','environment','lease_check','auxiliary_operations'):
            values.append(self._step('owner_'+name,lambda:getattr,(owner,name)))
        return tuple(values)

    def _values(self,argv,environment):
        # Exact native shape/value comparisons; never call foreign equality.
        if type(argv) is not list or any(type(value) is not str for value in argv):
            raise ProducerError('unknown auxiliary factory argv shape')
        if type(environment) is not dict or any(type(k) is not str or type(v) is not str for k,v in environment.items()):
            raise ProducerError('unknown auxiliary factory environment shape')
        return (tuple(argv),tuple(environment.items()))

    def _check_context(self,owner,context,values,argv,expected_members,constructor):
        actual=self._context(owner)
        if any(a is not b for a,b in zip(actual,context)):
            raise ProducerError('auxiliary factory owner context changed')
        if AuxiliaryCommand is not constructor:
            raise ProducerError('auxiliary factory constructor binding changed')
        if self._values(argv,context[2])!=values:
            raise ProducerError('auxiliary factory input values changed')
        operations=context[4]
        if type(operations) is not list or len(operations)!=len(expected_members):
            raise ProducerError('auxiliary factory owner ledger changed')
        if any(actual is not expected for actual,expected in zip(operations,expected_members)):
            raise ProducerError('auxiliary factory owner members changed')

    def run(self):
        call=self._step
        fail=self._fail
        owner=self.owner
        name=self.name
        argv=self.argv
        stdout_max=self.stdout_max
        try:
            constructor=call('constructor_lookup',lambda:lambda:AuxiliaryCommand)
            self.constructor=constructor
            context=self._context(owner)
            self.context_refs=context
            if type(context[4]) is not list:
                raise ProducerError('unknown auxiliary factory owner ledger')
            members=tuple(context[4]);self.original_members=members
            values=self._values(argv,context[2]);self.input_values=values
            arguments=dict(directory=context[0],name=name,argv=argv,cwd=context[1],
                environment=context[2],lease_check=context[3],stdout_max=stdout_max)
            self.constructor_attempted=True
            raw=call('constructor',lambda:constructor,(),arguments)
            self.constructor_raw_return=raw # Before type/context checks or append.
            self.constructor_returned=True
            if type(raw) is not constructor:
                raise ProducerError('unknown auxiliary factory constructor return')
            operation=raw
            self.operation=operation # Known actual return, never a hidden init object.
            self._check_context(owner,context,values,argv,members,constructor)
            appended=call('owner_append',lambda:context[4].append,(operation,))
            self.append_raw_return=appended
            self.append_returned=True
            if appended is not None:raise ProducerError('unknown auxiliary owner append return')
            self._check_context(owner,context,values,argv,members+(operation,),constructor)
            self.stage='legacy_suffix' # Suffix API progress remains separate/incomplete.
            # Retain before actual launch, as the original factory already did.
            operation.start()
            result=operation.result
            while result is None:result=operation.wait(60)
            if result['status']!='success':raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+str(result['primary_error']))
            self.completed=True # Helper return only, never EX/ownership completion.
            return result
        except BaseException as error:
            fail(error,None if self.stage=='legacy_suffix' else self.steps[-1] if self.steps else None)
