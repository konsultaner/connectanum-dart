import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-glob-coverage-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();private=(P/'glob_coverage-v1.py').read_bytes()
 assert source==(P/'before-producer.py').read_bytes() and tests==(P/'before-tests.py').read_bytes()+b'\n\n'+private
 def cls(t):return next(x for x in ast.parse(t).body if isinstance(x,ast.ClassDef) and x.name=='ProducerGlobCoverageTests')
 assert ast.dump(cls(private),include_attributes=False)==ast.dump(cls(tests),include_attributes=False)
 assert [k for k in h if h[k]!=oldh[k]]==['tool/test_native_perf_build_producer.py']
 r=json.loads((P/'coverage-units/result.json').read_text());assert(r['tests'],r['failures'],r['errors'],r['passes'])==(7,0,0,7)
 assert len(r['leases'])==14 and all(x['raw_None'] for x in r['leases'])
 views={v['mode']:(v,f.parent) for f in sorted((P/'coverage-units/fixtures').glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())]};assert len(views)==7
 for mode,(v,d) in views.items():
  assert v['public_producer_returned'] and not v['Source_pending'] and v['Source_finished'] and v['Source_returncode']==0 and v['record_original_journal']
  assert all(x['raw_None'] for x in v['leases']) and not v['Source_glob_return_serialized'] and not v['Source_sorted_list_serialized']
  assert v['ROOT_native_iterator_count']==1 and not any(x['kind'] in ('forbidden_preserver','repr_first','note_first') for x in v['calls'])
  if mode.startswith('normal'):
   assert v['wait_returned'] and v['result_status']=='success' and v['record_completed'] and v['Source_evidence_complete'] and v['ROOT_yield_names']==['one-1.bin']
   expected=['one-1.bin']+(['direct-b.dat','direct-a.dat'] if mode=='normal_multi' else [])
   assert [x['name'] for x in v['calls'] if x['kind']=='output_hash_attempt']==expected
   assert v['output_roles']==(['glob','direct_b','direct_a'] if mode=='normal_multi' else ['glob'])
  else:
   assert not v['wait_returned'] and v['pure_guard_same_received'] and v['record_primary_received'] and not v['record_completed']
   assert v['Source_result_None'] and not v['Source_evidence_complete'] and not v['failure_exists'] and not v['result_exists'] and not v['original_journal_closed']
   assert [x['stage'] for x in v['Source_steps']]==['output_pattern'] and v['Source_steps'][0]['returned']
   assert not any(x['kind'] in ('output_hash_attempt','result_write_attempt','finished_event_attempt') for x in v['calls'])
   if mode in ('glob_enter_unknown','glob_yield_unknown'):assert v['received_first']
   elif mode=='glob_False':assert v['received_type']=='TypeError' and not v['received_first']
   else:assert v['received_type']=='ProducerError' and not v['received_first']
   assert len(v['ROOT_yield_names'])==(1 if mode=='glob_yield_unknown' else (2 if mode=='glob_two' else 0))
 cleanup=[x for v,d in views.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text())];waits=[x for x in cleanup if x.get('kind')=='ROOT_same_original_bound_wait']
 assert len(waits)==7 and all(type(x['status']) is int and x['status']==0 for x in waits)
 for x in cleanup:
  if x.get('kind') in ('ROOT_known_log','ROOT_known_journal'):assert x['raw_closed_after']
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]};assert all(x['status']==0 for x in models.values())
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'CoverageONLY currentproducer410d61UNCHANGED/test-onlyASTequivalentappend. PrivateNEW7 executesONCE beforeappend/7PASS0FAIL0ERROR=5negative2newdistinctnormal. No afterappend run/unchangedcaller-suite/numerical/modelrepeat/newSourcefix/productiondefect/BEFOREfailingrepairregression/aggregate/fullcurrent20canonical/admission. Historical24at410d61-0075d8 separateepoch nevercombinedascurrentacceptance.',
 'ActualnativePath.glob returnsopaqueiterator thenROOTfirst/Sourceunknown entry; partialnativeiterator yieldsactualPath thenROOTfirst whileactualsorted consumes. Sourceonlyoutput_pattern stepreturnedTrue; glob/sorted percallraw andpartialmatchlist notserialized, neverfilledROOTknowniterator-yields orreconstructedfromtraceback/locals. False actualnativeiteratorreturn changedtoFalse =>actualnative sorted(False) TypeError Sourcefirst; actual0-2matches =>originalselectionProducerError Sourcefirst. ROOTFirst neverraisedinthose3modes. Privateguardkeepssameactualerror/no Sourcepreserver-repr-note-laterhash-writer-event-close-retry-replay-reset.',
 'Normalactualoneglob andinsertionorderedmixed3outputs glob-directB-directA preservefullunitfilebytes/nativeSHA/resolvedpaths/artifacthashcallorder/fullGLOB-outGLOB-err. These nativeunitfiles notbenchmarkfreshbody/Dartbroker/SDK/current20canonical/admission. Nativeglobclasspatch boundedAFTERpublicstart/ownparent-patternonly/restored, no instancepatch/globalPathconstructor replacement/builtins.sorted mock.',
 '7views/14parentCURRENT officialDarwinEXverifyNone plusSourcecallbacksNone UNITnotindependentfullactualEX-originalLinuxcredentials/allFD-interpreter-delegate-descendantclosure.7SAMEoriginalRootboundwait10 signed0/cachedpossible. ROOTknownFD-log-journal devino cleanup AFTERviews/assertions UNITnotSourcecleanup-liveownership-EXrelease. Nativepartialiterator lifecycle/openFDnotfullcensus/closed-exhaustedproof; no generatorcancellation-reset-recovery/fullactorclosureclaim. Some setup/internalFD/APIreturnsnotallserialized/no reconstruction-globalPIDscan-kill-fullreap-globalabsence.',
 'Qwen47336status0/full3155stdout564stderr/fullanswer ROOTqualified/rejectinstancepatch reconstructedparent/secondnegativeSourcecall/Sourcepartiallist-sortedmock/globalhashcount4/closecontextmask claims. GLM47698status0/full1903stdout677stderr/fullanswer ROOTqualified/rejectFalseiterable-emptylist/incorrectglobinsidestep/groupwrappingfreshfirst/deadnative_str. ActualsortedFalseTypeError confirmed/privateguardexactfirst; Sourceglobexpressionoutside_step/currentSourceoutput_patternTrue. Cleanupno-close-without-evidence receipt intentional; partialiteratorclosure notclaimed. Modelv1 seesfinalprivatev1 BEFOREfirstprivate execution/no rerun/ROOTwholeSource-tests-AST qualified NOTwholecurrentapproval.',
 'Sourcefields/refs/digests/closed/finished/nativeTypeError-helpercompleted DATA notsemanticimageauth-ABA-originalcredentials-ownership-EXrelease-admission. Strongowner/groups/rows/iterator-yieldrefs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact. Other19helpers+3bins unchanged/23hashes/4NEWGit0-BOTH/601-ownbranch20untracked-productionempty DATA; notcurrentcompiledcanonical.',
 'Onlyselectedglob/mixedoutputunitcoverage complete; percallglob-Pathsuboperation intent/rawbarriers/earlierattributes-bindings-metadata-returnshapes-globalconcurrentABA/enclosing-publicunknownCtor/historical-transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission incomplete. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-adoption-RAMrepair-strictacceptance. Storagefloors/recheck notbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.'
 ]
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],coverage_result=r,producer_UNCHANGED=True,Sourcefix=False,BEFOREfailingrepairregression=False,afterappend_run=False,
 ROOT=dict(wholeSource_BYTE_unchanged=True,oldtests_BYTES_PREFIX_exact=True,appended_class_AST_equivalent=True,other19helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=7,parent_EXverify_None=14,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup),models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True),limits=limits,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_glob_coverage'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],ROOT_pending=False,docs_pending=True,afterappend_run=False);c['active_turn_status']='Producer_glob_privateNEW7PASS_testonlyappend_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],private7PASS=True,producer_UNCHANGED=True,afterappend_run=False,views=7,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
