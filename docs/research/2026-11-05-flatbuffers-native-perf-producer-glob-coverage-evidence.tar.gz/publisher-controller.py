import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-glob-coverage-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-glob-coverage'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='d8da37c5f4b6f35c6da17a1113988f756bdd843e'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Native glob and mixed-output coverage without a producer change\n\nSeven new controls run once on unchanged producer410d61:5negative+2distinctnormal, all7PASS/0FAIL/0ERROR. They cover actual glob entry then ROOT first, native partial yield then ROOT first during sorted, native iterator replaced by False with actual sorted TypeError, real zero/two matches, one matching glob and insertion-ordered glob/directB/directA outputs. Current finish keeps the actual first and stops before hash/publication in the negatives. Normals preserve full unit-file bytes/native SHA/resolved paths/hash-call order/full log bytes. Source glob/sorted per-call returns and partial match lists are not serialized or filled from ROOT-known iterator/yields.\n\nOnly test coverage is appended: finaltest2b57de keeps oldtest0075d8 as an exact prefix and its new class AST-equivalent to the once-executed private class. No after-append run, Source fix, BEFORE-failing repair regression, unchanged caller/numerical/model replay or aggregate/current20canonical/admission result. Earlier24at410d61/0075d8 remains historical. Seven views/14currentDarwinEX observations and7same-boundROOTwait0/cached possible remain UNIT facts, not independent full EX/originalLinuxcredentials/all FD/interpreter/delegate/descendant closure. Native partial-iterator lifecycle is not full FD/exhaustion/closed proof and is not cancelled or recovered. Qwen47336/GLM47698 complete0/fullanswers are ROOTqualified; False is not iterable, glob/sorted is outside step, fresh group keeps first identity and native_str is used. ROOT qualifies unchanged whole Source/tests/AST/23hashes/other19helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty. Per-call glob/Path barriers, other metadata, historical/transitive/fullEX/immutableCOMPLETE runtime admission remain incomplete. No SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-glob-coverage'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: record native glob and mixed-output unit coverage'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_glob_coverage'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Remaining_percallglob-Pathsuboperation intent/rawbarriers/earlierfinishattributes-bindings-metadata-returnshapes-globalconcurrentABA; otherendAPIs-calleeinteriorintent/enclosingreporting-publicunknownCtorretention; writer-hash-init/nativeFD seams; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Currentproducer410d61UNCHANGED/test2b57de ONLYprivateNEW7coveragePASS=5negative2distinctnormal, executedonce BEFOREtest-onlyASTequivalentappend/no afterappendrun/no Sourcefix-BEFOREfailingrepairregression/unchangedcaller-suite/numerical-modelrepeat/aggregate-current20canonical-admission. Nativeglobentry/partialyieldRootfirst/FalseactualsortedTypeError/real0-2matchesselectionProducerError retainactualfirst/pureguardonly/noSource laterhash-publication-report-close-retry-replay. Normaloneglob/mixed3insertionorder-glob-directB-directA/allbytes-SHA-resolvedpaths-hashorder/fullGLOB-outGLOB-err preserved. Sourceglob-sorted percallraw/partiallist notserialized/UNKNOWNneverROOTiterator-yieldadopted/reconstructed.7views/EX14DarwinNone/7sameboundRootwait0cached UNITnotfullEX-originalLinux/fullFD-interpreter-delegate-descendantclosure; partialiterator lifecycle/openFD/closed-exhausted notcomplete/no cancellation-reset-recovery. Qwen47336-GLM47698=0/fullanswers/ROOTqualified/rejectFalseiterable-emptylist/globinsidestep/groupwrapping/deadnative_str/instancepatch-secondSourcecall-sortedmock/globalhashcount4-closecontextmask. Modelv1 finalprivatev1beforefirstexecution/no replay/ROOTwholeSource-tests-ASTqualified NOTwholecurrentapproval. WholeSourceBYTEunchanged/oldtestPREFIX/ASTequivalentappend/other19helpers3bins23hashes4NEWGit0-BOTH/601-ownbranch20untracked-productionempty DATA. Historical24at410d61-0075d8 separate/notcombinedcurrentacceptance. Allpriorepochshistorical/unknownPopenCtorpermanentrefusal/no partialPopenmethods-fieldderivedownerclose; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_glob_private7PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
