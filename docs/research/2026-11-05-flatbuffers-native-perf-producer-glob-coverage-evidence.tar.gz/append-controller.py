import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-glob-coverage-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in oldh.items())
 r=json.loads((P/'coverage-units/result.json').read_text());assert(r['tests'],r['failures'],r['errors'])==(7,0,0)
 for d in ('test-planning','candidate-review'):assert json.loads((P/d/'result.json').read_text())['status']==0
 old=(P/'before-tests.py').read_bytes();private=(P/'glob_coverage-v1.py').read_bytes();new=old+b'\n\n'+private;ast.parse(new)
 def c(raw):return next(x for x in ast.parse(raw).body if isinstance(x,ast.ClassDef) and x.name=='ProducerGlobCoverageTests')
 assert ast.dump(c(private),include_attributes=False)==ast.dump(c(new),include_attributes=False)
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==(P/'before-producer.py').read_bytes() and (R/'tool/test_native_perf_build_producer.py').read_bytes()==old
 (R/'tool/test_native_perf_build_producer.py').write_bytes(new);(P/'after-tests.py').open('xb').write(new)
 h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert [k for k in h if h[k]!=oldh[k]]==['tool/test_native_perf_build_producer.py']
 (P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2));v=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],producer_UNCHANGED=True,other19helpers3bins_unchanged=True,oldtests_BYTES_PREFIX_exact=True,appended_class_AST_equivalent_to_once_executed_private=True,afterappend_run=False,Sourcefix=False,BEFOREfailingrepairregression=False,not_aggregate_fullcurrent20canonical_admission=True)
 (P/'append-result.json').open('x').write(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c0=json.loads(cp.read_text());c0['native_perf_only_diagnostic_design']['producer_glob_coverage'].update(test_append=v,model_pending=False,before_pending=False,after_pending=False,ROOT_pending=True,Source_UNCHANGED=True);c0['active_turn_status']='Producer_glob_privateNEW7PASS_testonlyASTappend_NO_rerun_ROOTpending';cp.write_text(json.dumps(c0,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
