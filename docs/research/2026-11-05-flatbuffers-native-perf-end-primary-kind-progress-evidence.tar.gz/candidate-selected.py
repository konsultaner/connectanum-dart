def _end_command_group(owner):
    previous=_END_COMMAND_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('end-command owner mismatch')
        previous[1]()
        return previous
    primary=[None]
    def guard():
        if primary[0] is not None:raise primary[0]
    def refuse(error,record,row=None):
        if primary[0] is None:primary[0]=error
        try:
            owner.finished=True
            group=_failure_preservation_group(owner,primary[0])
            returned_primary=group[3]
            if not isinstance(returned_primary,BaseException):raise ProducerError('unknown failure preservation primary')
            primary[0]=returned_primary
            record['primary_error']=primary[0]
            group[2](error,row)
        finally:raise primary[0]
    group=(owner,guard,refuse)
    _END_COMMAND_GROUPS[id(owner)]=group
    return group