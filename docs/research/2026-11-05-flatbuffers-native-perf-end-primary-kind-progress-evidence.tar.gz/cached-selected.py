def _failure_preservation_group(owner,error):
    key=id(owner)
    previous=_FAILURE_PRESERVATION_GROUPS.get(key)
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        previous[1]()
        return previous
    primary=error
    quarantined=[False]
    secondary=[]

    def guard():
        if quarantined[0]:raise primary

    def refuse(received,row=None):
        quarantined[0]=True # Private terminal first BEFORE secondary metadata.
        try:
            if received is not primary:secondary.append(received)
            if row is not None:row['error']=received
        finally:
            raise primary

    group=(owner,guard,refuse,primary,secondary)
    _FAILURE_PRESERVATION_GROUPS[key]=group # Strong owner/first, process lifetime.
    return group

def _end_command_group(owner):
    previous=_END_COMMAND_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('end-command owner mismatch')
        previous[1]()
        return previous
    primary=[None]
    def guard():
        if primary[0] is not None:raise primary[0]
    def refuse(error,record,row=None):
        if primary[0] is None:primary[0]=error
        try:
            owner.finished=True
            group=_failure_preservation_group(owner,primary[0])
            primary[0]=group[3]
            record['primary_error']=primary[0]
            group[2](error,row)
        finally:raise primary[0]
    group=(owner,guard,refuse)
    _END_COMMAND_GROUPS[id(owner)]=group
    return group

def _end_command(self,status):
        group=_end_command_group(self);guard=group[1];refuse=group[2]
        attempt={'owner':self,'log':None,'events':None,'command_record':None,
                 'primary_error':None,'steps':[],'completed':False}
        _END_COMMAND_RECORDS.append(attempt)
        def step(stage,callback):
            guard();_failure_preservation_guard(self)
            row={'stage':stage,'returned':False,'raw':None,'error':None}
            attempt['steps'].append(row)
            try:
                raw=callback();row['raw']=raw;row['returned']=True
                return raw
            except BaseException as error:refuse(error,attempt,row)
        try:
            log=self.log;events=self.events;directory=self.directory;records=self.records
            record=records[-1];index=len(records)-1
            attempt.update(log=log,events=events,command_record=record,directory=directory,records=records,index=index)
            self.pending=False
            record['returncode']=status;record['ended_ns']=time.time_ns()
            self.log=None;self.output_log=None
            flush=log.flush;fileno=log.fileno;close=log.close
            fsync=os.fsync;snapshot=_file_snapshot;event=self._event
            def context():
                guard()
                if (self.directory is not directory or self.events is not events or self.records is not records
                    or len(records)!=index+1 or records[-1] is not record or self.pending is not False
                    or self.log is not None or self.output_log is not None):
                    raise ProducerError('end-command context changed')
            context()
            raw=step('log_flush',flush)
            if raw is not None:raise ProducerError('log flush returned an invalid result')
            context()
            fd=step('log_fileno',fileno)
            if type(fd) is not int or fd<0:raise ProducerError('log fileno returned an invalid descriptor')
            context()
            raw=step('log_fsync',lambda:fsync(fd))
            if raw is not None:raise ProducerError('log fsync returned an invalid result')
            context()
            step('log_close',close)
            context()
            data=step('log_snapshot',lambda:snapshot(directory/f'command-{index:03}.log'))
            if (type(data) is not dict or set(data)!= {'size','sha256'}
                or type(data['size']) is not int or data['size']<0
                or type(data['sha256']) is not str or re.fullmatch('[0-9a-f]{64}',data['sha256']) is None):
                raise ProducerError('log snapshot returned an invalid result')
            context()
            record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
            if record['spawn_error'] is None:
                if (record['output_eof'] is not True or self.output_fd is not None or self.output_buffer
                    or data!={'size':self.output_bytes,'sha256':self.output_hash.hexdigest()}):
                    raise ProducerError('output pipe bytes and final log snapshot differ')
                record['log_complete']=not self.output_write_uncertain and 'output_read_errors' not in record
            raw=step('command_end_event',lambda:event('command_end',index=index,**record))
            if raw is not None:raise ProducerError('command-end event returned an invalid result')
            context();attempt['completed']=True
        except BaseException as error:
            guard()
            refuse(error,attempt)