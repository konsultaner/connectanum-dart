import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-end-primary-kind-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-end-primary-kind-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='b7167a177eac07636d5f58b178071b6f0371967b'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Check end-command primary kind before replacing First\n\nFour new actual-wait cases give a before result of 2FAIL/2PASS/0ERROR. Known returned primary fields None and False overwrite the end-command group's captured First and turn both the wait failure and pure guard into TypeError. Native valid-primary and unknown-group-completion controls already preserve First. These are two controlled variants of one classification gap, not spontaneous kernel faults or a RAM-cause finding.\n\nThe helper now checks the returned primary is a BaseException before assigning its private first-error slot. Invalid fields preserve the captured First through the existing finally, leave unconfirmed metadata as None and skip the native refusal callback. Valid exception selection is preserved without forcing identity to the current error. Matching after is 4PASS/0FAIL/0ERROR once, including both actual-wait caller controls. The finish helper's similar field contract remains unproved and unchanged.\n\nOnly _end_command_group changes. Whole Source reverse projection, the old test prefix, other eighteen helpers, three root scripts and frozen predicates are exact. Actual log bytes are retained as file evidence; Source had already consumed and closed the pipe, so no raw pipe is reconstructed or reclosed. Scoped waits, FD closes and Darwin EX observations remain unit data. The twenty helpers remain uncommitted, uncanonical and unadmitted; original-runtime admission, RAM repair, final strict 48/50 and clean final CI remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-end-primary-kind-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: preserve end-command First on invalid primary'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['end_primary_kind_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Next NEWpredeclared question: analogous primary-field contract in CommandProducer._finish.refuse, valid earlier-primary/multiowner histories/bindings-interiors-concurrentABA/historical-transitive immutableoriginalruntimepreflight. Prospective/SourceeditonlyactualBEFOREfail. Currentf96d3e/c55068 matchingNEW4PASS=knownNone/Falseprimary+nativevalidprimary/unknowngroupcompletion actualwaitcallercontrols, once. BEFORE4atf39cf8/bdcaf8=2FAIL2PASS0ERROR exact4. HealthySourceCtor returnsowner; oneSource.wait10 realdrain/nativewait/logclose/actualnative_filesnapshot18BsizeSHA ROOTcomplete thenFirst beforeSourceget (notCtorSnapshot). End-refuse capturesFirst BEFOREGroup; nativegroup5tupleROOT/knownSourcefield3None-False/nativevalidFirst; unknownRootnativecompletionthenSecond beforeSourceget. BeforeNone helperattempt2/return1 andFalse1/1 poisonFirst->publicwait+pureguardTypeError; controls alreadyFirst. NewONLYreturned_primary kindisinstanceBaseException BEFOREprivateprimaryassign; invalidSourceProducerError remainscontext/knownFirstfinally/pureguardFirst/no metadatafill/nativeRefusecall. ValidBaseException selectionNOTidentity-auth-earlier-primaryclosure. AFTERallhelperattempt1/nativeRootreturn1; invalidunknownSourceattemptprimaryNone/notRootfilled; nativecontrolprimaryFirst. SourcependingFalse-finishedTrue-logNone-outputfdNone-status0-EOFTrue DATAunchanged/notliveness-EXrelease. WholeSourceBYTEprojectback-oldPREFIXexact/other18helpers3bins-oldauxpredicates-owner_emit_attempted exact; other_finish_fieldcontractunproved.8views4+4/24Rootoriginalwaitrowsperphase0cachedpossible/parentafter24SAME.28setupGitperphase0-BOTH/fullrawSHA-size. Sourcepipe+logalreadyclosedBEFOREfault, noRootclosedFDread/reclose/rawpipe reconstruction. RootownlogreaderFDregisteredBEFOREread/full18B+EOF/SHA-size/4ownreadercloses+4Sourceeventfileclosesperphase AFTERevidence/0pipecloses; collectALLknownwaitsBEFOREwaitassert/unknownNone. EX8before8afterNone UNITnotphysicalEX-originalLinux/ABA/fullFD-interpreter-delegate-descendantclosure/admission; beforeview-waitreadcleanup incomplete/no PIDscan-kill-fullreap/missingAPI-reconstruction. Qwen40213=0/1657out391err;GLM41118=0/6193out1105err/fullanswers-BOTH EOF-naturalreaped-ROOTqualified NOTwholeapproval. RejectGLMoverlookcaptureFirst-beforetry/replaceFirstwithclassificationerror-fillmetadata/guardneedsupdate/unknownmodeownermismatch-IDreuse/lostcontext; validdifferentexception-sourcehistoriesunproved/notextraoldtestreplay. Rootv1EXrefusedbeforebody/noSourcehash-Git-assessment-namespace; terminal/rawsaved/notbackendunavailable. Freshv2firstSource23hashes/4Git0-BOTH/HEAD601ownbranch20untracked-prodempty DATA/notcompiledcanonical/no Source-unit-model-replay. Free266282565632B/floorsDATA-recheck/no buildcapturecleanupauthority/causeUNMEASURED. GroupsclosuresrawchunksprocesslifeNOTfixedmemory/heapRSSgrowth-allocvolume-timing-causeUNMEASURED/no RAMrepair-memorybound-trim-reset-evict-deleteauthority. All20uncommitteduncanonicalunadmitted/providerABSENT/gatealwaysrefuses/controllerCLOSED/ownershipNone/all3flagsFalse/noSourcecommit-push-adoption-SDKbuild-kernel-broker-benchmarkcapture-strictdispatch/RAMrepair-finalstrict48/50-cleanCI incomplete. UnknownCtorPERMANENT/no partialmethods-RootTupleadoption-Sourcefieldrestore/fields-status-EOF-closedFD DATAneverownership-EXrelease-admission.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='End_primary_kind_BEFORE4_2FAIL2PASS_AFTER4PASS_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
