import sys,pathlib,json,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-end-primary-kind-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();parts=json.loads((P/'projection-parts.json').read_text())
 assert source==(P/'candidate-producer-v1.py').read_text() and tests==(P/'candidate-tests-v1.py').read_text();assert source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text();assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'end_primary_kind_regressions-v1.py').read_text()
 before=json.loads((P/'before-NEW4/result.json').read_text());after=json.loads((P/'after-NEW4/result.json').read_text())
 assert (before['tests'],before['failures'],before['errors'],before['passes'])==(4,2,0,2) and (after['tests'],after['failures'],after['errors'],after['passes'])==(4,0,0,4)
 assert len(before['leases'])==len(after['leases'])==8 and all(x['raw_None'] for x in before['leases']+after['leases'])
 controls={};expected=b'EP-v1-outEP-v1-err';digest=hashlib.sha256(expected).hexdigest()
 for label,folder in [('BEFORE',P/'before-NEW4/fixtures'),('AFTER',P/'after-NEW4/new-fixtures')]:
  views=[];waits=[];pipes=files=readers=setup_count=0
  for d in sorted(folder.iterdir()):
   v=json.loads((d/'view-before-ROOT-wait.json').read_text());c=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text());assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup);setup_count+=len(setup)
   for i,x in enumerate(setup):
    for stream in ('stdout','stderr'):
     raw=(d/f'setup-{i}-{stream}.bin').read_bytes();assert len(raw)==x[stream+'_size'] and hashlib.sha256(raw).hexdigest()==x[stream+'_sha256']
   w=[r for r in c['rows'] if r['kind']=='same_original_bound_wait'];assert len(w)==6 and all(r['status']==0 and r['signed_native_int'] for r in w);waits+=w
   saved=json.loads((d/'ROOT-all-known-waits-before-assert.json').read_text());assert saved['all_statuses_known'] and saved['rows']==w
   pipes+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='creatorFD');files+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='file');readers+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='ROOT_log_reader')
   raw=(d/'ROOT-actual-log.bin').read_bytes();tail=(d/'ROOT-log-tail.bin').read_bytes();r=json.loads((d/'ROOT-log-read-result.json').read_text());assert raw==expected and tail==b'' and r['size']==18 and r['sha256']==digest and r['EOF'] and r['actual_log_file_NOT_raw_pipe_reconstruction']
   assert v['healthy_constructor_returned'] and v['native_snapshot_completed_ROOT'] and v['snapshot_raw']==dict(size=18,sha256=digest)
   assert not v['Source_pending_DATA'] and v['Source_finished_DATA'] and v['Source_log_None_DATA'] and v['Source_output_fd_None_DATA'] and v['Source_command_status_DATA']==0 and v['Source_output_eof_DATA'] and not v['Source_attempt_completed'] and not v['result_returned']
   assert v['ROOT_native_tuple_NOT_filled_called_adopted'] and v['one_Source_wait_only_pure_guard_no_IO'] and v['native_group_returns_ROOT']==1
   mode=v['end_primary_kind']
   if mode in ('none','false'):
    assert v['invalid_primary_selected'] and (v['raw_primary_None'] if mode=='none' else v['raw_primary_False'])
    if label=='BEFORE':
     assert not v['received_First'] and v['received_type']=='TypeError' and not v['pure_guard_First'] and v['pure_guard_type']=='TypeError'
     assert v['Source_group_attempts']==(2 if mode=='none' else 1)
     assert v['Source_attempt_primary_None'] if mode=='none' else v['Source_attempt_primary_False']
    else:
     assert v['received_First'] and v['pure_guard_First'] and v['Source_group_attempts']==1 and v['Source_attempt_primary_None'] and v['First_context_type']=='ProducerError'
   else:
    assert mode in ('native','unknown') and v['received_First'] and v['pure_guard_First'] and v['Source_group_attempts']==1
    assert v['Source_attempt_primary_First'] if mode=='native' else v['Source_attempt_primary_None']
   views.append(v)
  assert len(views)==4 and len(waits)==24 and setup_count==28 and pipes==0 and files==4 and readers==4
  controls[label]=dict(views=views,wait_rows=waits,Root_pipe_closes=pipes,Root_Source_file_closes_AFTERevidence=files,Root_own_log_reader_closes_AFTERevidence=readers,separate_setupGit_rows=setup_count,raw_pipe_bytes_newly_retained=False,actual_log_bytes_NOT_pipe_reconstruction=True)
 parent=[r for x in after['root_original_waits'] for r in x['rows']];assert len(parent)==24 and all(x['status']==0 and x['signed_native_int'] for x in parent)
 models={}
 for name in ('planning','review'):
  r=json.loads((P/name/'result.json').read_text());assert r['status']==0 and r['both_separate_EOF'] and (P/name/'answer.txt').is_file()
  for stream in ('stdout','stderr'):
   raw=(P/name/(stream+'.bin')).read_bytes();assert len(raw)==r[stream+'_size'] and hashlib.sha256(raw).hexdigest()==r[stream+'_sha256']
  models[name]=r
 q=P/'ROOT-source-Git';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait(10);(q/f'{i}-stdout.bin').write_bytes(out);(q/f'{i}-stderr.bin').write_bytes(err);commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/'commands.json').write_text(json.dumps(commands,indent=2));assert status==0 and not err;return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 status=git(['status','--porcelain','--untracked-files=all']).decode().splitlines();assert len(status)==20 and all(x.startswith('?? tool/') for x in status) and {x[3:] for x in status}=={k for k in h if k.startswith('tool/')}
 assert git(['diff','601108ea6216464bd00ae29c16cfaf0a59c71db6','--stat','--','packages','native'])==b''
 free=shutil.disk_usage(R).free
 ass=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],BEFORE4=before,AFTER4=after,matching_NEW2_invalid_plus2_actual_wait_native_unknown_group_caller_controls=True,controls=controls,parent_after24_OVERLAPS_same_new24_NOTadditional_actors=True,models=models,model_ROOT_qualification=json.loads((P/'review-ROOT-qualification.json').read_text()),Source_whole_BYTEprojectback=True,oldtest_PREFIX_exact=True,only_end_command_group_changed_kind_check_BEFORE_private_primary_assignment=True,valid_BaseException_selection_not_forced_identity_with_current_error=True,invalid_unknown_Source_metadata_primary_None_NOTfilled=True,native_callback_quarantine_may_differ_because_invalid_field_refused_before_native_refuse_no_settlement=True,other_finish_helper_primary_field_binding_unproved=True,earlier_primary_multiowner_bindings_interiors_ABA_transitive_unproved=True,Source_fields_status_EOF_FDclosed_NOTliveness_ownership_EXrelease_admission=True,one_Source_wait_once_pure_guard_only_after_fault=True,Root_all_known_wait_outcomes_before_wait_asserts=True,unknown_beforeview_waitread_cleanup_incomplete=True,Root_log_reader_registered_BEFORE_read_not_all_internalFD_APIserialized=True,unit_NOTfull_physicalEX_originalLinux_fullFD_interpreter_delegate_descendant_closure=True,no_old4_7_6_5_27_completed25_old2bodies_old7suite_private2_models_campaigns_replayed=True,current23hashes_other18helpers3bins_SourceGit4zeroBOTH=True,SourceGit=commands,all20_uncommitted_uncanonical_unadmitted=True,stronggroups_rawchunks_processlife_NOTfixedmemory_heapRSSgrowth_allocvolume_timing_cause_UNMEASURED=True,no_Sourcecommit_push_adoption_SDKbuild_kernel_broker_benchmarkcapture_strictdispatch_RAMrepair_acceptance=True,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,outside_prior_cleanup_cause='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(ass,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['end_primary_kind_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256']);c.update(active_turn_status='End_primary_kind_BEFORE4_2FAIL2PASS_AFTER4PASS_ROOTqualified_DOCSpending',updated_utc=ass['utc']);cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps(dict(source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256'],BEFORE4='2FAIL2PASS0ERROR',AFTER4='4PASS0FAIL0ERROR',waits_per_phase=24,parent_after_same24=True,Root_closes_per_phase=dict(pipe=0,Source_event_file=4,ROOT_log_reader=4),current23hashes_SourceGit4zeroBOTH=True,free_bytes=free,full_admission=False)))
