import sys,pathlib,json,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-stream-read-progress-v1');s=(p/'source-before.py').read_text();c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');defer=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_defer')
 assert isinstance(defer.body[-1],ast.Raise) and not any(isinstance(x,ast.Return) for x in ast.walk(defer))
 extra=json.loads((p/'before-expected-drift/result.json').read_text());assert (extra['tests'],extra['failures'],extra['errors'])==(1,1,0)
 reports=[json.loads(path.read_text()) for path in (p/'before-expected-drift/fixtures').rglob('read-before-cleanup.json')];assert len(reports)==1
 d=reports[0];assert d['mode']=='expected-drift' and len(d['events'])==2 and all(x['stage']=='native_expected_read_error' for x in d['events']) and d['guard_absent'] is True and d['private_first_is_received'] is False
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),planning=json.loads((p/'test-planning/finish.json').read_text()),review=json.loads((p/'review/finish.json').read_text()),fullanswers_retained=True,selected_delta_whole8_helper_ctor_guard_actual_defer_NOTfullcurrent_source_approval=True,
 ROOT_rejections={
 'unbound_fallthrough':'Model self-corrects; actual original defer has no Return and raises boundfirst. No artificial nonraising-defer test, del-part or unconditional fallback status.',
 'journal_leak_claim':'Logical journal/error objects/tracebacks/sharedrefs can grow. No measured exactheap/RSS-bound/leak/timing/cause or release claim; no eviction/reset/trim authority inferred.',
 'self_process_property':'Actual class process is an instance field. No process property is defined here. Arbitrary foreign class/descriptor writes are not prevented/authenticated by this layer.',
 'no_stderr_path':'All actual fixtures include stderr EOF; pending includes actual stderr EAGAIN. Fault injections target stdout; no full stderr-fault-matrix claim.',
 'pipe_65536_cap':'No universal pipe write cap inferred. Original os.read request is fixed65536; oversized synthetic returned values unobserved, guarded by format, not a claim about kernel behavior.'
 },ROOT_independent_new_finding='Expected native EAGAIN after FD drift must retain earliest exception and stop caller. Privatev2 would raise retained BlockingIOError into old expected catch and permit continue; this is source-flow inference, never claimed candidate execution. Separate NEW oldsource control1FAIL0APIerrors; original8 not repeated. Privatev3 adds pure constructor guard before expected-error continue; no I/O/recovery/reset.',
 model_BEFORE_final_caller_guard_eighth_to_ninth_control_and_exactpassive_shape=True,passive_schema_sanitized_q_and_unique_localnames_beforeassembly=True,private_editor_v1_ambiguous_first_ifnotpart_projection_corrected_BEFOREexecution=True,
 both_private_candidates_UNEXECUTED_before_final_edit=True,extra_control=extra,extra_raw_reports=reports,only_finite_OWN_ROOT_cleanup_NOTlive_release=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True)
 with (p/'ROOT-review-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');data=json.loads(cp.read_text());v=data['native_perf_only_diagnostic_design']['auxiliary_stream_read_progress'];v.update(review_pending=False,model_review_status=0,ROOT_review_assessment=str(p/'ROOT-review-assessment.json'),separate_NEW_expected_drift1='1FAIL0APIerrors atf27909 source unchanged, original8 not repeated',final_model_hunks_UNREVIEWED_by_model_ROOT_pending=True);cp.write_text(json.dumps(data,indent=2)+'\n')
 l.verify_identity();print('review0 qualified; extra expected-drift1 FAIL0ERROR; final private v3 unexecuted/source unchanged')
