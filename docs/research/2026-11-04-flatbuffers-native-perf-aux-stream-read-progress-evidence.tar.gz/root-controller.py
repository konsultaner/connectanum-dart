import sys,pathlib,json,hashlib,subprocess,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-stream-read-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];slot=len(calls);row=dict(argv=argv,Popen_attempted=True,pid=None,status=None,stdout_eof=None,stderr_eof=None);calls.append(row)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  row['parent_pipe_FDstats']={name:dict(fd=stream.fileno(),dev=os.fstat(stream.fileno()).st_dev,ino=os.fstat(stream.fileno()).st_ino) for name,stream in [('stdout',child.stdout),('stderr',child.stderr)]}
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  out,err=child.communicate();status=child.wait();row.update(status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   path=q/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   st=path.stat();assert st.st_size==len(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest();row[label+'_pathstat']=dict(dev=st.st_dev,ino=st.st_ino,size=st.st_size)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not production
 h=json.loads((P/'after-edit-hashes.json').read_text());prior=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items()) and all(h[k]==v for k,v in prior.items() if 'build_producer.py' not in k)
 before=(P/'source-before.py').read_text();current=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert current==(P/'candidate-producer-v3.py').read_text() and current==(P/'after-producer.py').read_text()
 old=ast.parse(before);new=ast.parse(current);oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_stream_read_guard','_read_stream'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','wait','_constructor_guard','_complete'})
 methods=(P/'candidate-methods.py.txt').read_text();init=(P/'candidate-init.py.txt').read_text();schema=(P/'candidate-schema-v3.py.txt').read_text();fields=(P/'candidate-data-fields-v3.txt').read_text();full=(P/'candidate-complete-guard.txt').read_text()
 projected=current.replace(methods,'',1).replace(init,'',1).replace('        self._stream_read_guard()\n','',1).replace(full,'',1).replace(schema,'',1).replace(fields,'',1)
 projected=projected.replace("                try:part=self._read_stream(stream)","                try:part=os.read(stream['fd'],65536)",1)
 projected=projected.replace("                if not part:\n                    stream['eof']=True;self._close_slot(stream,'fd')","                if part:stream['buffer']=part\n                else:\n                    stream['eof']=True;self._close_slot(stream,'fd')",1)
 projected=projected.replace('                except (BlockingIOError,InterruptedError):self._constructor_guard();continue','                except (BlockingIOError,InterruptedError):continue',1)
 assert projected==before and tests==(P/'tests-before.py').read_text()+'\n\n'+(P/'new-tests-v2.py').read_text()
 def output_literal(node):
  return next(x for x in ast.walk(node) if isinstance(x,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='whole_descendant_exit_proven' for k in x.keys))
 assert ast.dump(output_literal(om['_complete']))==ast.dump(output_literal(nm['_complete']))
 forbidden={'repr','str','add_note','_write_json','close','_close_slot','wait','kill','_complete','select'}
 names_calls=[x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id if isinstance(x.func,ast.Name) else '' for x in ast.walk(nm['_read_stream']) if isinstance(x,ast.Call)]
 assert not (set(names_calls)&forbidden)
 body=ast.get_source_segment(current,nm['_read_stream'])
 assert body.index("check();row['lookup_attempted']=True;reader=os.read")<body.index("row['read_attempted']=True")<body.index("try:part=reader(fd,65536)")
 assert body.index("row['raw_return']=part;row['returned']=True")<body.index("if type(part) is not bytes")<body.index("row['value_valid']=True;check()")<body.index("stream['buffer']=part;row['buffer_committed']=True")<body.index("row['raw_return']=None;row['raw_consumed']=True")
 assert body.index("expected_error=received;row['expected_error']=received")<body.index("check();row['completed']=True")
 assert body.rfind("if expected_error is not None:raise expected_error")>body.index("except BaseException as error:")
 guard_calls=[]
 for name,node in nm.items():
  for call in ast.walk(node):
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='_stream_read_guard':guard_calls.append(dict(caller=name,keywords=[ast.unparse(x) for x in call.keywords]))
 assert {x['caller'] for x in guard_calls}=={'_constructor_guard','_complete'}
 waitbody=ast.get_source_segment(current,nm['wait']);assert 'except (BlockingIOError,InterruptedError):self._constructor_guard();continue' in waitbody
 v1=(P/'new-tests.py').read_text();v2=(P/'new-tests-v2.py').read_text()
 projected_test=v2.replace("\n    def test_actual_EAGAIN_then_FD_drift_preserves_first_and_stops_caller(self):self._read_case('expected-drift')\n",'',1)
 projected_test=projected_test.replace("if mode in ('pending','expected-drift'):\n                    code=","if mode=='pending':\n                    code=",1).replace("if mode not in ('pending','expected-drift'):self.assertEqual(0,source['bound_wait'](10))","if mode!='pending':self.assertEqual(0,source['bound_wait'](10))",1)
 projected_test=projected_test.replace("                        if fd==original_fd and known and mode=='expected-drift' and not fault_done:\n                            fault_done=True;stream['fd']=foreign_fd\n",'',1)
 projected_test=projected_test.replace("                elif mode=='expected-drift':\n                    self.assertEqual(1,len(events));self.assertEqual('native_expected_read_error',events[0]['stage'])\n                    self.assertTrue(expected_errors);self.assertIs(expected_errors[0],raised)\n                    self.assertTrue(report['row_expected_received']);self.assertTrue(report['row_expected_is_actual'])\n",'',1)
 projected_test=projected_test.replace("if mode in ('unknown-return','expected-drift'):self.assertIsNone(report['row_returned'])","if mode=='unknown-return':self.assertIsNone(report['row_returned'])",1)
 assert projected_test==v1
 invariant=dict(ROOT_whole_final_affected_methods_new9_helper_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,original8_testpaths_projectback_BYTEexact_excluding_new_mode_only_branches=True,
 other18helpers3bins_BYTEexact=True,old_factories_gates_defer_emit_freeze_auxpredicates_exact=True,original_result_literal_ASTexact=True,
 original_read65536_original_EOFclose_and_expectederror_semantics_preserved=True,normal_buffer_assignment_moved_sameorder_into_readhelper=True,
 original_Ctor_stream_readFD_log_process_buffer_refs_beforelookup=True,public_FD_mismatch_refuses_beforelookup_read=True,rawreturn_beforeformat_postchecks_buffercommit=True,
 known_buffer_transfer_rawduplicate_clear_AFTERactual_assignment_NOTdurability_release_or_heapbound=True,unknown_raw_buffers_first_retained_no_report_cleanup_restore_retry_replay=True,
 expected_EAGAIN_Interrupted_sameexception_OUTSIDEbroadcatch_no_EOF_exit_inferred=True,pure_ctor_guard_before_original_expectederror_continue_stops_quarantine=True,
 ordinary_latestrow_full_pre_finalization_and_passive_history=True,guard_calls=guard_calls,ctor_fields_FDnumbers_DATA_NOTkernel_identity_ABA_auth_partialPopen_authority_or_EXrelease=True,
 model_BEFORE_final_caller_guard_ninth_control_passive_exactshape_NOTcurrent_source_approval=True,select_lease_backingFD_init_generic_enclosing_historical_transitive_fullphysicalEX_originalruntimeadmission_INCOMPLETE=True)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 reports=[];journals=[]
 for stage in ('before','before-expected-drift','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('read-before-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
   assert d['original_process_retained'] is True and d['original_stream_retained'] is True
   if stage=='after-selected':
    assert d['row_present'] is True and d['row_original_fd'] is True
    if d['mode'] in ('foreign-before','fd-drift','buffer-drift','invalid-bool','unknown-return','expected-drift'):
     assert d['guard_raises_received_first'] is True and d['private_first_is_received'] is True and d['row_error_is_received'] is True
     assert d['pending'] is True and d['finished'] is False and d['result_is_None'] is True and d['source_eof'] is False and d['row_completed'] is False
     assert d['source_buffer_hex']==(b'ROOT-drift-buffer'.hex() if d['mode']=='buffer-drift' else '')
     if d['mode']=='foreign-before':assert not d['events'] and d['row_read_attempted'] is False
     else:
      assert len(d['events'])==1 and d['events'][0]['source_intent_before_native'] is True
      if d['mode']=='expected-drift':
       assert d['events'][0]['stage']=='native_expected_read_error' and d['row_expected_received'] is True and d['row_expected_is_actual'] is True and d['row_returned'] is None and d['row_raw_hex'] is None
      elif d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['row_returned'] is None and d['row_raw_hex'] is None
      elif d['mode']=='invalid-bool':assert d['row_returned'] is True and d['row_raw_is_False'] is True and d['row_value_valid'] is not True
      else:assert d['row_returned'] is True and d['row_raw_hex']==b'OWN-A-native-read'.hex() and d['row_buffer_committed'] is False
    elif d['mode']=='pending':
     assert d['guard_absent'] is True and d['row_expected_received'] is True and d['row_expected_is_actual'] is True and d['row_completed'] is True
     assert d['row_returned'] is None and d['row_raw_hex'] is None and d['source_eof'] is False and d['source_status'] is None and d['natural_wait_observed'] is False
     assert len(d['events'])==2 and all(x['stage']=='native_expected_read_error' for x in d['events'])
    elif d['mode']=='data':
     assert d['finished'] is True and d['row_returned'] is True and d['row_raw_size']==17 and d['row_buffer_committed'] is True and d['row_raw_consumed'] is True and d['row_raw_hex'] is None
    else:
     assert d['mode']=='empty' and d['finished'] is True and d['row_returned'] is True and d['row_raw_size']==0 and d['row_raw_hex']=='' and d['row_buffer_committed'] is False
  for path in sorted((P/stage/'fixtures').rglob('read-unit-cleanup.json')):
   raw=path.read_bytes();journals.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 assert len(reports)==18 and len(journals)==18
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(waits)==36 and all(type(row['status']) is int and row['status']==0 for row in waits)
 for name,data in [('new-precleanup-reports.json',reports),('new-unit-journals.json',journals)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 b=json.loads((P/'before/result.json').read_text());extra=json.loads((P/'before-expected-drift/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text())
 assert (b['tests'],b['failures'],b['errors'])==(8,5,0) and (extra['tests'],extra['failures'],extra['errors'])==(1,1,0) and (a['tests'],a['failures'],a['errors'])==(19,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 NEWbefore8=b,separate_NEW_expected_drift1=extra,AFTERselected19=a,not_aggregated_or_current20canonical_or_originalruntimeadmission=True,
 source_Git=dict(head=head,branch=branch,untracked20_exact=True,production_packages_native_diffempty=True,four_signed0_BOTHseparateEOF=True,DATA_only=True),
 planning=json.loads((P/'test-planning/finish.json').read_text()),review=json.loads((P/'review/finish.json').read_text()),ROOT_review_qualification=json.loads((P/'ROOT-review-assessment.json').read_text()),
 ROOT_independent_wholefinal_source_tests_AST_qualified_NOTmodel_fullapproval=True,candidates_UNEXECUTED_before_edit=True,model_BEFORE_final_caller_guard_ninth_control_exactpassive_shape=True,
 new_finite_journals=18,new_known_boundwait_rows=36,new_signed0_rows=36,cached_possible_NOTfreshsyscall=True,
 only_pureguardprobe_aftererror_NOsecond_source_read_wait_poll=True,two_actual_OWN_normal_SourceAux_commands_percase_not_other_task_actors=True,
 normal_ctor_FDnumber_refs_DATApreconditions_NOTkernelidentity_ABA_auth_methodauthority_or_EXrelease=True,bool_ROOTinjected_notspontaneouskernel_return=True,
 expected_EAGAIN_completed_observation_not_EOF_bytes_consumed_exit_or_release=True,
 ROOT_unit_cleanup_stat_errors=sum(row['kind']=='ROOT_known_parent_FD_stat_error_NOTclosureproof' for j in journals for row in j['data']),
 ROOT_unit_cleanup_identity_drifts=sum(row['kind']=='ROOT_known_parent_FD_identity_changed_NOTclosed' for j in journals for row in j['data']),
 finite8s_pendinggate_ROOTrelease_afterevidence_bounded10sSAMEwait_UNITnotbenchmarkfreeze=True,
 ROOTknown_parentFD_rawlog_cleanup_afterevidence_UNITonly_NOTliveEX=True,logical_history_error_tracebacks_sharedrefs_NOTexactheapRSS_bound_timing_or_cause=True,
 required_legacy_setup_actorFD_APIreturns_notallserialized_no_reconstruction=True,initial_checkpoint_read_without_official_lease_DATAonly_not_EX_or_runtimeproof=True,
 inlineartifact_APIreturns_notall_regularfiles=True,all_named_operational_controllers_BEFOREcalls=True,
 other18helpers3bins_BYTEexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,
 free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_old_cleanup_spacechange_cause_UNMEASURED=True,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,
 provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_OPEN_DRAFT_base130_issue103_milestoneOPEN=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_stream_read_progress']
 v.update(new_epoch_UNTESTED=False,ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True,final_model_hunks_UNREVIEWED_by_model_ROOT_pending=False)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW streamread postcomponent4Git0/BOTHseparateEOF/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Final649857/574940 nineteen selected PASS=9matchingNEW+10affected; ROOTqualified NOTmodelcurrentapproval/current20canonical/admission')
 c['active_turn_status']='Aux_stream_read649857_574940_selected19PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],NEWbefore8='5FAIL3normalPASS0APIerrors',separate_NEW1='1FAIL0APIerrors',AFTERselected19='PASS',new_unit_journals=18,new_boundwait_rows=36,signed0=36,free_bytes=free)))
