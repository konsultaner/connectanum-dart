class AuxiliaryStreamReadProgressTests(unittest.TestCase):
    """NEW actual pipe read boundaries; finite unit fixtures, no SDK admission."""
    def _read_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-stream-read-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        release=base/'finite-pending-release';actors=[];logs={};pipes=[];closed=[];cleanup=[];events=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_read=os.read
        real_allocate=producer.AuxiliaryCommand._allocate_process
        a=None;b=None;raised=None;guard_error=None;expected_errors=[];fault_done=False
        first=OSError(5,'OWN native read return hidden by ROOT fault')
        payload=b'OWN-A-native-read';foreign_payload=b'OWN-B-native-read'
        def allocate(current,record):
            value=real_allocate(current,record);actors.append(dict(name=current.name,process=value,bound_wait=value.wait));return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for name in ('read-source','read-foreign'):
                for role in ('stdout','stderr'):
                    if path==base/(name+'.'+role):logs[name+'.'+role]=value
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            st=os.fstat(fd);value=native_close(fd);closed.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None));return value
        def rows():
            journal=getattr(a,'_stream_read_journal',None)
            return journal if type(journal) is list else []
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                if mode in ('pending','expected-drift'):
                    code="import pathlib,time;p=pathlib.Path("+repr(str(release))+");end=time.monotonic()+8\nwhile not p.exists() and time.monotonic()<end: time.sleep(.005)"
                elif mode=='empty':code='pass'
                else:code="import os;os.write(1,"+repr(payload)+")"
                a=producer.AuxiliaryCommand(directory=base,name='read-source',argv=[sys.executable,'-c',code],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);a.start()
                b=producer.AuxiliaryCommand(directory=base,name='read-foreign',argv=[sys.executable,'-c',"import os;os.write(1,"+repr(foreign_payload)+")"],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);b.start()
                source=next(x for x in actors if x['name']=='read-source');foreign=next(x for x in actors if x['name']=='read-foreign')
                if mode not in ('pending','expected-drift'):self.assertEqual(0,source['bound_wait'](10))
                self.assertEqual(0,foreign['bound_wait'](10))
                stream=a.streams['stdout'];original_fd=stream['fd'];foreign_fd=b.streams['stdout']['fd']
                original_log=stream['log'];original_buffer=stream['buffer']
                st=os.fstat(original_fd);source_identity=(st.st_dev,st.st_ino)
                st=os.fstat(foreign_fd);foreign_identity=(st.st_dev,st.st_ino)
                observed_FDs={original_fd:source_identity,foreign_fd:foreign_identity}
                stderr_fd=a.streams['stderr']['fd'];st=os.fstat(stderr_fd);observed_FDs[stderr_fd]=(st.st_dev,st.st_ino)
                def reading(fd,count):
                    nonlocal fault_done
                    st=os.fstat(fd);known=observed_FDs.get(fd)==(st.st_dev,st.st_ino)
                    row=rows()[-1] if rows() else {}
                    intent=(row.get('stream') is stream and type(row.get('read_fd')) is int
                        and row.get('read_fd')==fd and row.get('read_attempted') is True and row.get('returned') is None)
                    try:value=native_read(fd,count)
                    except (BlockingIOError,InterruptedError) as error:
                        if known:expected_errors.append(error);events.append(dict(stage='native_expected_read_error',fd=fd,count=count,source_intent_before_native=intent,error_is_BlockingIOError=type(error) is BlockingIOError))
                        if fd==original_fd and known and mode=='expected-drift' and not fault_done:
                            fault_done=True;stream['fd']=foreign_fd
                        raise
                    if known:events.append(dict(stage='native_read',fd=fd,count=count,raw_hex=value.hex(),raw_size=len(value),source_intent_before_native=intent))
                    if fd==original_fd and known and not fault_done and mode in ('fd-drift','buffer-drift','invalid-bool','unknown-return'):
                        fault_done=True
                        if mode=='fd-drift':stream['fd']=foreign_fd
                        if mode=='buffer-drift':stream['buffer']=b'ROOT-drift-buffer'
                        if mode=='invalid-bool':return False
                        if mode=='unknown-return':raise first
                    return value
                if mode=='foreign-before':stream['fd']=foreign_fd
                with mock.patch.object(os,'read',reading):
                    try:a.wait(timeout=10 if mode in ('data','empty') else 0)
                    except BaseException as error:raised=error
                    if mode not in ('data','empty'):
                        # Pure guard only; never a second source native read/wait/poll after error.
                        try:a._constructor_guard()
                        except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            ownrows=[row for row in rows() if type(row) is dict and row.get('stream') is stream]
            row=ownrows[0] if ownrows else {}
            raw=row.get('raw_return')
            report=dict(mode=mode,events=events,raised_is_injected=raised is first,raised_is_ProducerError=type(raised) is producer.ProducerError,
                guard_raises_received_first=raised is not None and guard_error is raised,guard_absent=guard_error is None,
                private_first_is_received=raised is not None and getattr(a,'_deferred_primary_error',None) is raised,
                original_process_retained=a._constructor_quarantine.get('allocated_process') is source['process'],
                original_stream_retained=a._constructor_quarantine_binding[3] is stream,
                original_log_retained=stream['log'] is original_log,
                source_buffer_hex=stream['buffer'].hex() if type(stream['buffer']) is bytes else None,
                source_eof=stream['eof'],pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                source_status=a.status,natural_wait_observed=a._natural_wait_observed,
                row_present=bool(row),row_original_stream=row.get('stream') is stream,
                row_original_fd=type(row.get('read_fd')) is int and row.get('read_fd')==original_fd,
                row_buffer_before_is_original=row.get('buffer_before') is original_buffer,
                row_read_attempted=row.get('read_attempted'),row_returned=row.get('returned'),
                row_raw_hex=raw.hex() if type(raw) is bytes else None,row_raw_is_False=raw is False,
                row_raw_size=row.get('raw_size'),row_value_valid=row.get('value_valid'),
                row_buffer_committed=row.get('buffer_committed'),row_raw_consumed=row.get('raw_consumed'),
                row_expected_received=row.get('expected_received'),
                row_expected_is_actual=any(row.get('expected_error') is error for error in expected_errors),
                row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                known_ROOT_created_parent_pipes=pipes,known_ROOT_native_close_returns=closed,
                scope='TWO own finite SourceAux commands; actual os.read then ROOT fault injection; FD fields/source facts not kernel identity/ABA/auth/physicalEX/SDK')
            with (base/'read-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_process_retained']);self.assertTrue(report['original_stream_retained'])
            if mode in ('data','empty'):
                self.assertIsNone(raised);self.assertTrue(a.finished);self.assertFalse(a.pending);self.assertIsNotNone(a.result)
                self.assertEqual(payload if mode=='data' else b'',(base/'read-source.stdout').read_bytes())
            elif mode=='pending':
                self.assertIsNone(raised);self.assertIsNone(guard_error)
                self.assertTrue(expected_errors);self.assertTrue(all(x['stage']=='native_expected_read_error' for x in events))
                self.assertFalse(stream['eof']);self.assertEqual(b'',stream['buffer']);self.assertIsNone(a.status);self.assertFalse(a._natural_wait_observed)
            else:
                if mode=='foreign-before':self.assertEqual([],events);self.assertIs(type(raised),producer.ProducerError)
                elif mode=='expected-drift':
                    self.assertEqual(1,len(events));self.assertEqual('native_expected_read_error',events[0]['stage'])
                    self.assertTrue(expected_errors);self.assertIs(expected_errors[0],raised)
                    self.assertTrue(report['row_expected_received']);self.assertTrue(report['row_expected_is_actual'])
                else:
                    self.assertEqual(1,len(events));self.assertEqual('native_read',events[0]['stage']);self.assertEqual(payload.hex(),events[0]['raw_hex'])
                    if mode=='unknown-return':self.assertIs(first,raised)
                    else:self.assertIs(type(raised),producer.ProducerError)
                self.assertIs(raised,guard_error);self.assertTrue(report['private_first_is_received']);self.assertTrue(report['row_original_fd'])
                self.assertTrue(report['row_buffer_before_is_original']);self.assertTrue(report['row_error_is_received'])
                self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result);self.assertFalse(stream['eof'])
                self.assertEqual(b'ROOT-drift-buffer' if mode=='buffer-drift' else b'',stream['buffer'])
                if mode=='foreign-before':self.assertFalse(report['row_read_attempted'])
                else:
                    self.assertTrue(events[0]['source_intent_before_native'])
                    if mode in ('unknown-return','expected-drift'):self.assertIsNone(report['row_returned']);self.assertIsNone(report['row_raw_hex'])
                    else:
                        self.assertIs(report['row_returned'],True)
                        if mode=='invalid-bool':self.assertTrue(report['row_raw_is_False']);self.assertIsNot(report['row_value_valid'],True)
                        else:self.assertEqual(payload.hex(),report['row_raw_hex'])
        finally:
            try:
                if not release.exists():
                    with release.open('x') as f:f.write('OWN finite unit release only')
            finally:
                for actor in actors:
                    value=actor['bound_wait'](10);cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=0,cached_possible=True));self.assertIs(type(value),int);self.assertEqual(0,value)
                identities={(x['fd'],x['dev'],x['ino']) for x in closed}
                seen=set()
                for item in pipes:
                    key=(item['fd'],item['dev'],item['ino'])
                    if key in seen or key in identities:continue
                    seen.add(key);fd=item['fd']
                    try:st=os.fstat(fd)
                    except OSError as error:
                        cleanup.append(dict(kind='ROOT_known_parent_FD_stat_error_NOTclosureproof',fd=fd,errno=error.errno));continue
                    if (st.st_dev,st.st_ino)!=(item['dev'],item['ino']):
                        cleanup.append(dict(kind='ROOT_known_parent_FD_identity_changed_NOTclosed',fd=fd));continue
                    value=native_close(fd);cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
                for name,log in logs.items():
                    if not log.closed:
                        fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                        log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',name=name,fd=fd,returned=True))
                with (base/'read-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_foreign_read_FD_refuses_before_native_read(self):self._read_case('foreign-before')
    def test_actual_read_then_FD_drift_preserves_raw_without_buffer_publish(self):self._read_case('fd-drift')
    def test_actual_read_then_buffer_drift_refuses_overwrite(self):self._read_case('buffer-drift')
    def test_actual_read_then_False_is_not_EOF(self):self._read_case('invalid-bool')
    def test_actual_read_then_fault_retains_unknown_intent(self):self._read_case('unknown-return')
    def test_normal_actual_data_preserves_full_log_and_completion(self):self._read_case('data')
    def test_normal_actual_empty_EOF_preserved(self):self._read_case('empty')
    def test_actual_EAGAIN_preserves_pending_without_EOF(self):self._read_case('pending')

    def test_actual_EAGAIN_then_FD_drift_preserves_first_and_stops_caller(self):self._read_case('expected-drift')
