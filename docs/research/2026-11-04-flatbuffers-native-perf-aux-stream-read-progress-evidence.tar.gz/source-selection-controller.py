import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-stream-read-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW Aux per-native stream read original constructor stream/creator read FD/log/process/buffer refs and raw return progress; preserve actual normal EAGAIN/Interrupted semantics, no SDK/nativebuild/HEAD/tests/capture/cleanup',source_expected='f27909265db1733e99241e5fd7d61eeceaee30cc81ae8bbba2736c430302b344',tests_expected='239e6aaa9c6caf8d76a5937055afdc9a2fcbd35ffeb493a86194aa741bc500c0',prior_components_consumed_no_unchanged_repeats=True,initial_checkpoint_read_API_without_lease_DATAonly_not_source_HEAD_EX_or_proof=True,unretained_initial_APIbytes_not_reconstructed=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='f27909265db1733e99241e5fd7d61eeceaee30cc81ae8bbba2736c430302b344' and hashlib.sha256(tests).hexdigest()=='239e6aaa9c6caf8d76a5937055afdc9a2fcbd35ffeb493a86194aa741bc500c0'
 for name,body in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(body)
 s=source.decode();c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 selected={x.name:ast.get_source_segment(s,x) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in ('wait','_arm_constructor','_constructor_guard','_write_buffer','_close_slot')}
 with (P/'selected-source.json').open('x') as f:json.dump(selected,f,indent=2)
 l.verify_identity();print(selected['_arm_constructor']);print('selected_chars',sum(map(len,selected.values())))
