import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-stream-read-progress-v1');result=json.loads((p/'before/result.json').read_text());assert (result['tests'],result['failures'],result['errors'])==(8,5,0)
 reports=[];journals=[]
 for path in sorted((p/'before/fixtures').rglob('read-before-cleanup.json')):
  raw=path.read_bytes();d=json.loads(raw);reports.append(dict(path=str(path.relative_to(p)),sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),data=d))
  assert d['original_process_retained'] is True and d['original_stream_retained'] is True
  if d['mode']=='foreign-before':assert len(d['events'])==2 and d['source_buffer_hex']==b'OWN-B-native-read'.hex()
  if d['mode'] in ('fd-drift','buffer-drift'):assert len(d['events'])==2 and d['source_buffer_hex']==b'OWN-A-native-read'.hex() and d['raised_is_ProducerError'] is False
  if d['mode']=='invalid-bool':assert d['source_eof'] is True and d['finished'] is True and d['result_is_None'] is False
  if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['guard_raises_received_first'] is True and d['private_first_is_received'] is True and d['row_present'] is False
 for path in sorted((p/'before/fixtures').rglob('read-unit-cleanup.json')):
  raw=path.read_bytes();journals.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(reports)==8 and len(journals)==8 and len(waits)==16 and all(type(row['status']) is int and row['status']==0 for row in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),NEWbefore8='5FAIL3normalPASS0APIerrors',source_epoch='f27909/239e6a',foreign_FD_native_B_bytes_consumed=True,postread_FD_drift_and_buffer_drift_overwritten_without_refusal=True,injected_False_treated_as_EOF_and_completion=True,unknown_native_return_then_fault_original_waitcaller_ALREADYretains_first_NEWstronger_intent_policy_failure_NOTfifth_native_bug=True,normals_data_empty_actualEAGAIN_PASS=True,reports=reports,journals=journals,known_finite_SAMEboundwait_rows=16,signed0=16,cached_possible=True,selected_ROOT_parentFD_identity_cleanup_NOTfullphysicalEX=True,no_omission_reconstruction=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(cp.read_text());v=d['native_perf_only_diagnostic_design']['auxiliary_stream_read_progress'];v.update(planning_pending=False,planning_status=0,NEW_tests_UNEXECUTED=False,NEWbefore8='5FAIL3normalPASS0APIerrors',ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),candidate_UNIMPLEMENTED=True,review_pending=True);d['active_turn_status']='Aux_stream_read_NEWbefore8_5FAIL3PASS_candidateUNIMPLEMENTED_sourcef27909_unchanged';cp.write_text(json.dumps(d,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(NEWbefore8='5FAIL3normalPASS0APIerrors',normal_data_empty_EAGAIN_PASS=True,new_finite_boundwaits16_signed0=True)))
