import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-stream-read-progress-v1');before=(p/'source-before.py').read_text();s=before
 methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema-v2.py.txt').read_text();full=(p/'candidate-complete-guard.txt').read_text()
 needle='    def _wait_natural_status(self,timeout):';assert s.count(needle)==1;s=s.replace(needle,methods+needle,1)
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='        self._direct_wait_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._direct_wait_guard()\n        self._stream_read_guard()\n\n    def _constructor_record',1)
 c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_complete')
 body=ast.get_source_segment(s,node);needle='        self._constructor_guard()\n';assert body.count(needle)==1;s=s.replace(body,body.replace(needle,needle+full,1),1)
 oldread="                try:part=os.read(stream['fd'],65536)";newread="                try:part=self._read_stream(stream)"
 assert s.count(oldread)==1;s=s.replace(oldread,newread,1)
 oldbuffer="                if part:stream['buffer']=part\n                else:";newbuffer="                if not part:"
 assert s.count(oldbuffer)==1;s=s.replace(oldbuffer,newbuffer,1)
 needle="            wait_state=values.get('_direct_wait_state');wait_journal=values.get('_direct_wait_journal')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 fields="                stream_read_fields_valid=read_ok,stream_read_quarantined=read_quarantined,\n                stream_read_entries=len(read_journal) if type(read_journal) is list else None,\n                stream_read_returned=read_last.get('returned') if type(read_last.get('returned')) is bool else None,\n                stream_read_raw_size=read_last.get('raw_size') if type(read_last.get('raw_size')) is int else None,\n                stream_read_expected_received=read_last.get('expected_received') if type(read_last.get('expected_received')) is bool else None,\n                stream_read_completed=read_last.get('completed') if type(read_last.get('completed')) is bool else None,\n"
 needle='                direct_wait_fields_valid=wait_ok,direct_wait_quarantined=wait_quarantined,';assert s.count(needle)==1;s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer-v2.py',s),('candidate-data-fields-v2.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate-v2.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='f27909-before',tofile='NEW-stream-read-candidate')))
 l.verify_identity();print('private stream read candidate UNEXECUTED; source unchanged')
