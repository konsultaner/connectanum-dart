import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-deferred-failure-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts-v2.json').read_text())
 assert source==(P/'candidate-v2.py').read_text() and source.replace(parts['helper'],'',1).replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'deferred_regressions-v1.py').read_bytes();ast.parse(source);ast.parse(tests)
 assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(7,5,2,0);assert(a['tests'],a['failures'],a['errors'])==(8,0,0)
 assert len(b['leases'])==14 and len(a['leases'])==16 and all(r['raw_None'] for r in b['leases']+a['leases'])
 def views(path):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if 'record_original_process' in v}
 old=views(P/'before-units/fixtures');new=views(P/'after-selected/fixtures');assert len(old)==len(new)==7
 for mode in ('first_repr_fault','second_repr_fault','native_repr_fault','preserver_unknown'):assert old[mode][0]['received_secondary'] and not old[mode][0]['received_first']
 assert old['preserver_False'][0]['helper_returned']
 waits={};cleanup={}
 for phase,data in [('before',old),('after',new)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())];known=[r for r in rows if r['kind']=='ROOT_same_original_bound_wait']
  assert len(known)==7 and all(type(r['status']) is int and r['status']==0 for r in known);waits[phase]=known;cleanup[phase]=rows
  for r in rows:
   if r['kind'] in ('ROOT_known_log','ROOT_known_journal'):assert r['raw_closed_after']
 for mode,(v,d) in new.items():
  assert v['public_producer_returned'] and v['record_present'] and v['record_primary_first'] and v['record_original_journal'] and v['record_original_process']
  assert all(row['raw_None'] for row in v['leases']) and not any(c['kind'] in ('str_first','note_first') for c in v['calls'])
  rows=v['Source_steps']
  if mode in ('normal','normal_secondary'):
   assert v['helper_returned'] and v['helper_result_None'] and v['record_completed'] and v['final_status']=='failed' and v['Source_returncode']==0 and v['Source_evidence_complete']
   assert v['final_error']==v['Source_deferred_error'] and not v['Source_pending']
   if mode=='normal_secondary':assert len(v['Source_secondary_texts'])==1
  else:
   assert not v['helper_returned'] and v['received_first'] and v['pure_guard_first'] and not v['record_completed']
   assert v['Source_pending'] and not v['Source_finished'] and v['Source_returncode'] is None and not v['Source_evidence_complete']
   assert v['original_journal_open'] and v['original_log_open']
   if mode in ('first_repr_fault','native_repr_fault'):
    assert v['Source_deferred_error'] is None
   if mode in ('first_repr_fault','second_repr_fault','native_repr_fault'):
    row=next(r for r in rows if r['stage']=='error_repr');assert not row['returned'] and row['raw_None'] and row['error_is_secondary'] and not any(r['stage']=='failure_preserve' for r in rows)
   if mode=='native_repr_fault':assert v['native_repr_first_known']
   if mode=='preserver_unknown':
    row=next(r for r in rows if r['stage']=='failure_preserve');assert not row['returned'] and row['raw_None'] and row['error_is_secondary'] and v['failure_exists']
   if mode=='preserver_False':assert rows[-1]['stage']=='failure_preserve' and rows[-1]['returned'] and rows[-1]['raw_False'] and v['failure_exists']
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=7,failures=5,passes=2,errors=0,scope='4originalfirst replacements bysecondary +1knownFalseignored; controlledreportingpolicies not5nativekernelbugs/RAMcause'),after=a,
 ROOT=dict(whole_final_Source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=14,parent_BEFORE_EXverify_None=14,parent_AFTER_EXverify_None=16,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup,allotherSource_preservefailure_group_finish_endcommand_Aux_Popen_constructors_factories_frozenpredicates_exact=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM=json.loads((P/'candidate-review/result.json').read_text()),ROOT_qualified_NOTwholecurrentapproval=True,GLMv1_beforeROOTv2_expectedjournalcontext=True),
 limits=['ONLY_defer_failure body privatefirst-beforeformatting/context-nativeoriginalrefs/percallintent-raw/knowninvalidstop. Actualfullyreturnedfixture producer/confirmedPopen; negativepureguardonly/no Sourcewait/start-close-retry-replay afterunexpectedbodyfault. _finish/enclosing/publicunknownCtor retention unchanged/incomplete.',
 'Healthyfirst-secondarydeferredstrings/originalfailedresult/fullcombinedbytes preserved; normalcompleteddeferral maySourcewait, unexpectedbodyfault onlyRootknownboundwait. First/native_repr unknowntext remainsNone despiteROOTknownnativeStr/no fallbackplaceholder. Samegroup first retainedacrossseconddeferral error.',
 'Originalprocess/log/journal/record refs andmethodbindings DATA notsemanticimageauth-atomicABA-originalcredentials-ownership-EXrelease/admission. PendingTrue notkernel-livenessproof; closed/naturalstatusnotSourceownershipcomplete. PositivekindFIXTURE notliveadmission.',
 '14views/14BEFORE16AFTER parentCURRENT officialDarwinEXverifyNone plusSourcecallbacksNone UNITnotfullindependentEX-originalLinuxcredentials/allFD-interpreter-delegate-descendantclosure.7BEFORE7AFTER SAMEoriginalRootboundwait10 signed0/cachedpossible; knownreader reads-closes andlog-journal nativeRawclose AFTERevidence/devino UNITnotSourcecleanup/recovery-EXrelease. Some setup/internalFD/APIfactsnotallserialized/no globalabsence-fullreap/reconstruction.',
 'Qwen34920status0/full3125stdout573stderr ROOTqualified/rejectnoSourceedit advice/weakref-idcollision/nonpending-oldcontrolrepeat/partialPopenmock. GLM35537status0/full4292stdout864stderr ROOTqualified/rejectfallbacktext/trimming-hoistingbindingchecks/GCidcollision-leakcause claims. No growthheapRSS-timingcauseinference fromrows. Modelv1 BEFOREv2ROOTnormalnonpendingpostpreserverexpected-events compatibility (unexecutednonpendingnegative); bothcandidatesUNEXECUTEDbeforeedit.',
 'Privatev1UNEXECUTEDbeforefirstBEFORE;7BEFOREonce/7matchingNEW+1affectedpublicCtorpostspawnjournal AFTER=8selectedPASS. No unchanged7previouspreservation controls/models/numericalreplay; notaggregate/fullcurrent20canonical/admission. Inheritededitresult suffixcaller flag noauthorityonly; actualscope_defer_failure.',
 'Stronggroups/owner/rows/primary-secondary/refs/buffers/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. Metadata/globalbindings/empty-invalidrecords/nonpending/constructornegative/transitive-historical/controller-fullEX-runtimeimmutableCOMPLETEadmission incomplete.',
 'All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact; no Sourcecommit-push-adoption/actualSDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_deferred_failure_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Producer_deferred_failure_selected8PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected8PASS=True,views=14,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
