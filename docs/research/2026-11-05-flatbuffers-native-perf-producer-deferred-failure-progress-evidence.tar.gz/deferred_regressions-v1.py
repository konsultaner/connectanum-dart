"""NEW enclosing producer failure-publication controls; no Source recovery after refusal."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer


class ProducerDeferredFailureTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)

    def _defer_case(self,mode):
        calls=[];actors=[];seen={};leases=[];evidence_ready=False
        class Secondary(ValueError):pass
        secondary=Secondary('ROOT deferred reporting secondary')
        class First(OSError):
            def __repr__(self):
                calls.append(dict(kind='repr_first'))
                if mode=='first_repr_fault':raise secondary
                raw=BaseException.__repr__(self);seen['native_repr_first']=raw
                if mode=='native_repr_fault':raise secondary
                return raw
            def __str__(self):calls.append(dict(kind='str_first'));raise RuntimeError('ROOT forbidden firststr')
            def add_note(self,note):calls.append(dict(kind='note_first'));raise RuntimeError('ROOT forbidden firstnote')
        class Second(OSError):
            def __repr__(self):
                calls.append(dict(kind='repr_second'))
                if mode=='second_repr_fault':raise secondary
                return BaseException.__repr__(self)
        first=First('ROOT original deferred first');second=Second('ROOT secondary deferred input')
        native_allocate=producer.CommandProducer._allocate_command_process
        native_preserve=producer.CommandProducer._preserve_failure
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def preserving(p,error):
            calls.append(dict(kind='preserver_attempt',input_first=error is first,input_second=error is second))
            raw=native_preserve(p,error);calls.append(dict(kind='actual_preserver_return',raw_None=raw is None))
            if mode=='preserver_unknown':raise secondary
            if mode=='preserver_False':return False
            return raw
        p=None;received=None;guard_error=None;returned=False;result=object();final=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer.CommandProducer,'_preserve_failure',preserving):
                command=[sys.executable,'-c',"import os,time;os.write(1,b'defer-worker-out');os.write(2,b'defer-worker-err');time.sleep(0.12)"]
                p=self.start(('ok',),commands=[command],lease_check=verifying)
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                if mode in ('second_repr_fault','normal_secondary'):
                    setup=p._defer_failure(first);self.assertIsNone(setup)
                target=second if mode in ('second_repr_fault','normal_secondary') else first
                try:result=p._defer_failure(target);returned=True
                except BaseException as error:received=error
                guard=getattr(producer,'_deferred_failure_guard',None)
                if mode in ('normal','normal_secondary'):
                    final=p.wait(10);self.assertIsNotNone(final)
                elif guard is not None:
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in getattr(producer,'_DEFERRED_FAILURE_RECORDS',[]) if r.get('owner') is p]
            record=records[-1] if records else None;rows=[] if record is None else record['steps']
            view=dict(mode=mode,public_producer_returned=True,helper_returned=returned,helper_result_None=result is None,
                received_type=None if received is None else type(received).__name__,received_first=received is first,received_secondary=received is secondary,
                Source_pending=p.pending,Source_finished=p.finished,Source_deferred_error=p.deferred_error,
                Source_returncode=p.records[-1]['returncode'],Source_evidence_complete=p.evidence_complete,
                original_journal_open=not seen['journal']['obj'].closed,original_log_open=not seen['log']['obj'].closed,
                failure_exists=(p.directory/'failure.json').exists(),native_repr_first_known='native_repr_first' in seen,
                guard_present=guard is not None,pure_guard_first=guard_error is first,record_present=record is not None,
                record_primary_first=False if record is None else record.get('primary_error') is first,
                record_original_journal=False if record is None else record.get('events') is seen['journal']['obj'],
                record_original_process=False if record is None else record.get('process') is actors[0]['process'],
                record_completed=None if record is None else record.get('completed'),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,error_is_secondary=r.get('error') is secondary) for r in rows],
                Source_secondary_texts=p.records[-1].get('secondary_errors'),final_status=None if final is None else final['status'],
                final_error=None if final is None else final['error'],calls=list(calls),leases=leases,
                limits='Fullyreturnedactualfixture producer/confirmedPopen; negativepending fields DATA/notkernel-liveness/ownership. No Sourcewait afterbodyfault; ROOTknownboundwait+FDcleanup AFTERviews/assertions UNITnotSource recovery/EXrelease/fullactorclosure/admission.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases))
            if mode in ('normal','normal_secondary'):
                self.assertTrue(returned);self.assertIsNone(result);self.assertIsNone(received);self.assertEqual('failed',final['status'])
                self.assertEqual(BaseException.__repr__(first),p.deferred_error);self.assertEqual(p.deferred_error,final['error'])
                self.assertEqual(0,final['commands'][0]['returncode']);self.assertEqual(b'defer-worker-outdefer-worker-err',(p.directory/'command-000.log').read_bytes())
                if mode=='normal_secondary':self.assertEqual([BaseException.__repr__(second)],p.records[-1]['secondary_errors'])
                if record is not None:self.assertTrue(record['completed']);self.assertTrue(record['primary_error'] is first)
            else:
                self.assertFalse(returned);self.assertTrue(received is first);self.assertTrue(p.pending);self.assertFalse(p.finished)
                self.assertTrue(guard is not None);self.assertTrue(guard_error is first);self.assertTrue(record is not None)
                self.assertTrue(record['primary_error'] is first);self.assertTrue(record['events'] is seen['journal']['obj']);self.assertTrue(record['process'] is actors[0]['process']);self.assertFalse(record['completed'])
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is first)
                else:self.fail('deferred failure pure guard returned')
                self.assertEqual(count,len(calls))
            self.assertFalse(any(c['kind'] in ('str_first','note_first') for c in calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_pending_first_repr_failure_keeps_original_before_formatting(self):self._defer_case('first_repr_fault')
    def test_pending_second_repr_failure_keeps_original_first(self):self._defer_case('second_repr_fault')
    def test_actual_native_repr_then_error_keeps_unknown_Source_return(self):self._defer_case('native_repr_fault')
    def test_actual_preserver_then_error_keeps_unknown_return(self):self._defer_case('preserver_unknown')
    def test_actual_preserver_then_False_is_known_invalid(self):self._defer_case('preserver_False')
    def test_new_normal_first_deferral_then_natural_failed_result(self):self._defer_case('normal')
    def test_new_normal_secondary_deferral_then_natural_failed_result(self):self._defer_case('normal_secondary')
