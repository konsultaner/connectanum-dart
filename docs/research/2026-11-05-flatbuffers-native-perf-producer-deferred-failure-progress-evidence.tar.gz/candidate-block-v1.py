_DEFERRED_FAILURE_RECORDS=[]


def _deferred_failure_guard(owner):
    _failure_preservation_guard(owner)


    def _defer_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,
            process=None,events=None,log=None,completed=False,steps=[])
        _DEFERRED_FAILURE_RECORDS.append(record) # Before formatting/callee I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            process=call('process',lambda:getattr,(self,'process'));record['process']=process
            events=call('events',lambda:getattr,(self,'events'));record['events']=events
            log=call('log',lambda:getattr,(self,'log'));record['log']=log
            pending=call('pending',lambda:getattr,(self,'pending'))
            records=call('records',lambda:getattr,(self,'records'))
            deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
            if (type(pending) is not bool or type(records) is not list or not records
                or type(records[-1]) is not dict or any(type(k) is not str for k in records[-1])
                or (deferred is not None and type(deferred) is not str)):
                raise ProducerError('unknown deferred failure context')
            command_record=records[-1];record['command_record']=command_record
            preserver=call('preserver_lookup',lambda:lambda:self._preserve_failure)
            renderer=call('repr_lookup',lambda:lambda:repr)

            def check_context(expected):
                guard()
                if (self.directory is not directory or self.process is not process
                    or self.events is not events or self.log is not log or self.pending is not pending
                    or self.records is not records or not records or records[-1] is not command_record
                    or self.deferred_error is not expected):
                    raise ProducerError('deferred failure context changed')
                actual=call('preserver_binding',lambda:lambda:self._preserve_failure)
                if (type(actual) is not MethodType or type(preserver) is not MethodType
                    or actual.__self__ is not self or preserver.__self__ is not self
                    or actual.__func__ is not preserver.__func__):
                    raise ProducerError('deferred failure preserver binding changed')

            check_context(deferred)
            text=call('error_repr',lambda:renderer,(error,))
            if type(text) is not str:raise ProducerError('unknown deferred failure representation')
            check_context(deferred)
            if deferred is None:
                self.deferred_error=text;expected=text
            else:
                secondary=call('secondary_list',lambda:command_record.setdefault,('secondary_errors',[]))
                if type(secondary) is not list:raise ProducerError('unknown secondary failure ledger')
                appended=call('secondary_append',lambda:secondary.append,(text,))
                if appended is not None:raise ProducerError('unknown secondary append return')
                expected=deferred
            check_context(expected)
            raw=call('failure_preserve',lambda:preserver,(error,))
            if raw is not None:raise ProducerError('unknown failure preserver return')
            check_context(expected)
            record['completed']=True # Deferral body only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)
