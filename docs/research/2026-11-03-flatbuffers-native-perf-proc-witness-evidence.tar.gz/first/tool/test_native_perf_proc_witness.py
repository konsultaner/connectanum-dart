from __future__ import annotations

import errno
import fcntl
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from native_perf_guard import GuardError, PipeChannel, ProcessStat
from native_perf_proc_witness import ProcReader, identify_sampler, require_wrapper_private_channels_absent


def stat_text(pid, parent, start):
    fields = ["S", str(parent)] + ["0"] * 17 + [str(start)]
    return f"{pid} (owned (fixture) comm) " + " ".join(fields) + "\n"


class ProcWitnessTests(unittest.TestCase):
    """Owned file-backed procfs/pipe fixtures, never live Linux/root/perf proof."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.root = self.directory / "fixture-proc"
        self.root.mkdir()
        self.images = {}
        for name in ("sudo", "perf", "other"):
            p = self.directory / name
            p.write_bytes(b"\x7fELFowned non-executed synthetic image " + name.encode())
            self.images[name] = p
        self.pipefds = []
        self.control = self.pipe()
        self.ack = self.pipe()
        self.channel_control = PipeChannel.from_fds(*self.control)
        self.channel_ack = PipeChannel.from_fds(*self.ack)
        self.log = self.directory / "fixture-log"
        self.log.write_bytes(b"")
        self.argv = (str(self.images['perf']), 'record', '--pid', '300', '--delay=-1', '--control=fd:0,1')
        self.reader = ProcReader.fixture(self.root)
        self.make_process(100, 90, 1000, 'sudo', (str(self.images['sudo']),), children=(101,), uid=1001, gid=1001)
        self.make_process(101, 100, 1010, 'perf', self.argv, children=(), uid=0, gid=0)
        self.fd(101, 0, self.control[0])
        self.fd(101, 1, self.ack[1])
        self.regular_fd(101, 2, self.log)
        self.anchor = ProcessStat(100, 90, 1000)

    def pipe(self):
        pair = os.pipe()
        self.pipefds.extend(pair)
        for fd in pair:
            self.addCleanup(os.close, fd)
        return pair

    def make_process(self, pid, parent, start, image, argv, *, children=(), uid=0, gid=0):
        base = self.root / str(pid)
        (base / 'fd').mkdir(parents=True)
        (base / 'fdinfo').mkdir()
        task = base / 'task' / str(pid)
        task.mkdir(parents=True)
        (base / 'stat').write_text(stat_text(pid, parent, start))
        (task / 'stat').write_text(stat_text(pid, parent, start))
        (task / 'children').write_text(' '.join(str(v) for v in children))
        (base / 'status').write_text(f'Name:\tfixture\nUid:\t{uid}\t{uid}\t{uid}\t{uid}\nGid:\t{gid}\t{gid}\t{gid}\t{gid}\n')
        (base / 'cmdline').write_bytes(b'\0'.join(os.fsencode(v) for v in argv) + b'\0')
        (base / 'exe').symlink_to(self.images[image])

    def fd(self, pid, number, real_fd):
        prefix = '/proc/self/fd' if os.path.isdir('/proc/self/fd') else '/dev/fd'
        p = self.root / str(pid) / 'fd' / str(number)
        if p.is_symlink():
            p.unlink()
        p.symlink_to(f'{prefix}/{real_fd}')
        flags = fcntl.fcntl(real_fd, fcntl.F_GETFL)
        (self.root / str(pid) / 'fdinfo' / str(number)).write_text(f'pos:\t0\nflags:\t{flags:o}\n')

    def regular_fd(self, pid, number, target):
        (self.root / str(pid) / 'fd' / str(number)).symlink_to(target)
        (self.root / str(pid) / 'fdinfo' / str(number)).write_text('pos:\t0\nflags:\t0100001\n')

    def identify(self, tree=None, **changes):
        args = dict(expected_sha256=hashlib.sha256(self.images['perf'].read_bytes()).hexdigest(), expected_argv=self.argv,
                    expected_uid=0, expected_gid=0, control=self.channel_control, ack=self.channel_ack,
                    launcher_images=frozenset((hashlib.sha256(self.images['sudo'].read_bytes()).hexdigest(),)))
        args.update(changes)
        return identify_sampler(self.reader.owned_tree(self.anchor) if tree is None else tree, **args)

    def test_descendant_sampler_is_not_sudo_anchor(self):
        sampler = self.identify()
        self.assertEqual(sampler.instance.pid, 101)
        self.assertNotEqual(sampler.instance.pid, self.anchor.pid)
        self.assertEqual(sampler.uid, (0, 0, 0, 0))
        self.assertTrue(sampler.fixture_only)
        self.assertEqual(sampler.evidence_class, 'synthetic_fixture_snapshot')
        self.assertEqual(sampler.descriptor(2).kind, 'regular')
        self.assertTrue(self.reader.evidence)

    def test_sampler_may_be_anchor_when_sudo_execs(self):
        anchor = ProcessStat(101, 100, 1010)
        self.assertEqual(self.identify(self.reader.owned_tree(anchor)).instance.pid, 101)

    def test_reused_anchor_starttime_refuses(self):
        with self.assertRaisesRegex(GuardError, 'lineage'):
            self.reader.owned_tree(ProcessStat(100, 90, 999))

    def test_wrong_sampler_argv_is_not_selected_away(self):
        (self.root / '101/cmdline').write_bytes(b'wrong\0')
        with self.assertRaisesRegex(GuardError, 'launch policy'):
            self.identify()

    def test_wrong_effective_credentials_refuse(self):
        for key in ('expected_uid', 'expected_gid'):
            with self.subTest(key=key), self.assertRaisesRegex(GuardError, 'launch policy'):
                self.identify(**{key: 1001})

    def test_wrong_sampler_image_refuses(self):
        with self.assertRaisesRegex(GuardError, 'missing or ambiguous'):
            self.identify(expected_sha256='f' * 64)

    def test_two_sampler_images_refuse_even_if_only_one_has_right_argv(self):
        self.make_process(102, 100, 1020, 'perf', ('wrong',))
        (self.root / '100/task/100/children').write_text('101 102')
        with self.assertRaisesRegex(GuardError, 'ambiguous'):
            self.identify()

    def test_undeclared_non_sampler_image_refuses(self):
        self.make_process(102, 100, 1020, 'other', ('other',))
        (self.root / '100/task/100/children').write_text('101 102')
        with self.assertRaisesRegex(GuardError, 'undeclared'):
            self.identify()

    def test_other_owned_tree_ack_writer_refuses(self):
        self.fd(100, 6, self.ack[1])
        with self.assertRaisesRegex(GuardError, 'another owned-tree endpoint'):
            self.identify()

    def test_sampler_duplicate_private_endpoint_refuses(self):
        self.fd(101, 6, self.control[0])
        with self.assertRaisesRegex(GuardError, 'another owned-tree endpoint'):
            self.identify()

    def test_wrong_pipe_or_wrong_access_refuses(self):
        for actual in (self.control[1], self.ack[0]):
            self.fd(101, 1, actual)
            with self.subTest(actual=actual), self.assertRaisesRegex(GuardError, 'private endpoints'):
                self.identify()

    def test_fdinfo_flags_are_octal_and_malformed_evidence_retained(self):
        p = self.root / '101/fdinfo/1'
        p.write_text('flags:\t02000001\n')  # Octal O_CLOEXEC + O_WRONLY, not decimal low bits.
        self.assertEqual(self.identify().descriptor(1).flags, 0o2000001)
        for text in ('flags:\t8\n', 'flags:\t1\nflags:\t1\n'):
            p.write_text(text)
            with self.subTest(text=text), self.assertRaisesRegex(GuardError, 'descriptor flags'):
                self.identify()
            self.assertEqual(self.reader.evidence[-1]['data_base64'], __import__('base64').b64encode(text.encode()).decode())

    def test_reparented_child_refuses(self):
        (self.root / '101/stat').write_text(stat_text(101, 200, 1010))
        with self.assertRaisesRegex(GuardError, 'lineage'):
            self.reader.owned_tree(self.anchor)

    def test_cycle_refuses_without_global_pid_scan(self):
        (self.root / '101/task/101/children').write_text('100')
        with self.assertRaisesRegex(GuardError, 'cycle or limit'):
            self.reader.owned_tree(self.anchor)
        listed = [e['path'] for e in self.reader.evidence if e['operation'] == 'list']
        self.assertNotIn('.', listed)

    def test_task_thread_children_are_included(self):
        (self.root / '100/task/100/children').write_text('')
        other = self.root / '100/task/110'
        other.mkdir()
        (other / 'stat').write_text(stat_text(110, 90, 1001))
        (other / 'children').write_text('101')
        self.assertEqual(self.identify().instance.pid, 101)

    def test_duplicate_child_across_threads_refuses(self):
        other = self.root / '100/task/110'
        other.mkdir()
        (other / 'stat').write_text(stat_text(110, 90, 1001))
        (other / 'children').write_text('101')
        with self.assertRaisesRegex(GuardError, 'duplicated'):
            self.reader.owned_tree(self.anchor)

    def test_same_starttime_exe_replacement_is_detected(self):
        original = self.reader._image
        changed = False
        def replace_after_first(relative):
            nonlocal changed
            result = original(relative)
            if relative == Path('101/exe') and not changed:
                changed = True
                p = self.root / relative
                p.unlink()
                p.symlink_to(self.images['other'])
            return result
        with patch.object(self.reader, '_image', side_effect=replace_after_first):
            with self.assertRaisesRegex(GuardError, 'changed during snapshot'):
                self.reader.snapshot(101)
        images = [e for e in self.reader.evidence if e['operation'] == 'image']
        self.assertEqual(len(images), 2)
        self.assertNotEqual(images[0]['sha256'], images[1]['sha256'])

    def test_same_pid_starttime_change_between_stat_reads_detected(self):
        original = self.reader._read
        count = 0
        def mutate_stat(relative, maximum=131072):
            nonlocal count
            data = original(relative, maximum)
            if relative == Path('101/stat'):
                count += 1
                if count == 1:
                    (self.root / relative).write_text(stat_text(101, 100, 1009))
            return data
        with patch.object(self.reader, '_read', side_effect=mutate_stat):
            with self.assertRaisesRegex(GuardError, 'changed during snapshot'):
                self.reader.snapshot(101)

    def test_descriptor_replacement_between_observations_detected(self):
        original = self.reader._stat
        replaced = False
        def replace_fd(relative):
            nonlocal replaced
            value = original(relative)
            if relative == Path('101/fd/1') and not replaced:
                replaced = True
                self.fd(101, 1, self.control[1])
            return value
        with patch.object(self.reader, '_stat', side_effect=replace_fd):
            with self.assertRaisesRegex(GuardError, 'descriptor changed'):
                self.reader.snapshot(101)

    def test_missing_proc_entry_refuses_and_retains_error(self):
        (self.root / '101/status').unlink()
        with self.assertRaisesRegex(GuardError, 'unavailable'):
            self.reader.snapshot(101)
        self.assertEqual(self.reader.evidence[-1]['errno'], errno.ENOENT)
        self.assertEqual(self.reader.evidence[-1]['path'], '101/status')

    def test_read_permission_failure_is_terminal_not_skipped(self):
        original = Path.open
        def denied(path, *args, **kwargs):
            if str(path).endswith('101/status'):
                raise PermissionError(errno.EACCES, 'synthetic procfs denial')
            return original(path, *args, **kwargs)
        with patch.object(Path, 'open', denied), self.assertRaisesRegex(GuardError, 'unavailable'):
            self.reader.snapshot(101)
        self.assertEqual(self.reader.evidence[-1]['errno'], errno.EACCES)

    def test_oversized_command_retains_bounded_prefix_and_refuses(self):
        (self.root / '101/cmdline').write_bytes(b'x' * 65538)
        with self.assertRaisesRegex(GuardError, 'size limit'):
            self.reader.snapshot(101)
        entry = self.reader.evidence[-1]
        self.assertTrue(entry['limit_exceeded'])
        self.assertEqual(len(__import__('base64').b64decode(entry['data_base64'])), 65537)

    def test_bad_credential_or_cmdline_refuses_without_environ_read(self):
        (self.root / '101/status').write_text('Uid:\t0 0\nGid:\t0 0 0 0\n')
        with self.assertRaisesRegex(GuardError, 'credential'):
            self.reader.snapshot(101)
        paths = [e['path'] for e in self.reader.evidence]
        self.assertFalse(any(p.endswith('environ') for p in paths))

    def test_wrapper_private_endpoint_is_refused(self):
        wrapper = self.reader.snapshot(100)
        require_wrapper_private_channels_absent(wrapper, self.channel_control, self.channel_ack)
        self.fd(100, 4, self.control[1])
        with self.assertRaisesRegex(GuardError, 'wrapper inherited'):
            require_wrapper_private_channels_absent(self.reader.snapshot(100), self.channel_control, self.channel_ack)

    def test_unknown_nonpipe_fds_are_retained(self):
        p = self.root / '101/fd/42'
        p.symlink_to(os.devnull)
        (self.root / '101/fdinfo/42').write_text('flags:\t0\n')
        sampler = self.identify()
        self.assertEqual(sampler.descriptor(42).kind, 'other')
        self.assertIn('101/fd/42', [e['path'] for e in self.reader.evidence])

    def test_tree_and_thread_limits_refuse(self):
        with patch.object(self.reader, 'MAX_PROCESSES', 1), self.assertRaisesRegex(GuardError, 'limit'):
            self.reader.owned_tree(self.anchor)
        with patch.object(self.reader, 'MAX_THREADS', 0), self.assertRaisesRegex(GuardError, 'limit'):
            self.reader.children(100)

    def test_numeric_alias_entry_refuses(self):
        (self.root / '101/fd/01').symlink_to(os.devnull)
        with self.assertRaisesRegex(GuardError, 'numeric entry'):
            self.reader.snapshot(101)

    def test_live_mode_requires_privileged_linux_reader(self):
        for platform, uid in [('darwin', 0), ('linux', 1001)]:
            with self.subTest(platform=platform, uid=uid), patch('native_perf_proc_witness.sys.platform', platform), patch('native_perf_proc_witness.os.geteuid', return_value=uid):
                with self.assertRaisesRegex(GuardError, 'privileged Linux'):
                    ProcReader()

    def test_invalid_declaration_is_refused(self):
        tree = self.reader.owned_tree(self.anchor)
        for change in ({'expected_uid': False}, {'expected_gid': -1}, {'expected_argv': 'perf'}, {'expected_sha256': 'bad'}, {'ack': self.channel_control}):
            with self.subTest(change=change), self.assertRaisesRegex(GuardError, 'declaration'):
                self.identify(tree, **change)

    def test_invalid_elf_retains_original_prefix_evidence(self):
        self.images['perf'].write_bytes(b'NOTELF')
        with self.assertRaisesRegex(GuardError, 'ELF'):
            self.reader.snapshot(101)
        self.assertEqual(self.reader.evidence[-1]['magic_base64'], 'Tk9URQ==')

    def test_regular_log_growth_is_not_descriptor_replacement(self):
        original = self.reader._stat
        grown = False
        def grow_log(relative):
            nonlocal grown
            value = original(relative)
            if relative == Path('101/fd/2') and not grown:
                grown = True
                self.log.write_bytes(b'new owned fixture log bytes')
            return value
        with patch.object(self.reader, '_stat', side_effect=grow_log):
            self.assertEqual(self.reader.snapshot(101).descriptor(2).kind, 'regular')

    def test_changing_log_position_preserves_descriptor_identity(self):
        original = self.reader._read
        changed = False
        def change_position(relative, maximum=131072):
            nonlocal changed
            value = original(relative, maximum)
            if relative == Path('101/fdinfo/2') and not changed:
                changed = True
                (self.root / relative).write_text('pos:\t99\nflags:\t0100001\n')
            return value
        with patch.object(self.reader, '_read', side_effect=change_position):
            self.assertEqual(self.reader.snapshot(101).descriptor(2).flags, 0o100001)

    def test_empty_noninitial_argument_is_valid_exec_argv(self):
        argv = self.argv + ('',)
        (self.root / '101/cmdline').write_bytes(b'\0'.join(os.fsencode(v) for v in argv) + b'\0')
        self.assertEqual(self.identify(expected_argv=argv).argv, argv)
