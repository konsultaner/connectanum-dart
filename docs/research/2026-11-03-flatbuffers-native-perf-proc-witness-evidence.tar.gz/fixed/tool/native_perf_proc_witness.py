#!/usr/bin/env python3
"""Bounded read-only procfs witnesses; no perf/workload/capture entrypoint.

Synthetic procfs fixtures are explicitly labelled. Stable observations are not
an atomic kernel snapshot, global FD-owner census or proof against privileged
ABA changes. A trusted reader with sufficient procfs access is still required.
"""
from __future__ import annotations

import base64
import hashlib
import os
import re
import stat
import sys
from dataclasses import dataclass
from pathlib import Path

from native_perf_guard import GuardError, PipeChannel, PipeIdentity, ProcessInstance, ProcessStat, _digest, parse_process_stat


@dataclass(frozen=True)
class FdWitness:
    number: int
    kind: str
    device: int
    inode: int
    flags: int
    target: str

    @property
    def pipe(self):
        return PipeIdentity(self.device, self.inode) if self.kind == "pipe" else None

    @property
    def access(self):
        return self.flags & os.O_ACCMODE


@dataclass(frozen=True)
class ProcessWitness:
    process: ProcessStat
    instance: ProcessInstance
    uid: tuple[int, ...]
    gid: tuple[int, ...]
    argv: tuple[str, ...]
    image_identity: tuple[int, ...]
    image_target: str
    fds: tuple[FdWitness, ...]
    fixture_only: bool

    @property
    def evidence_class(self):
        return "synthetic_fixture_snapshot" if self.fixture_only else "bounded_procfs_snapshot"

    def descriptor(self, number):
        values = [fd for fd in self.fds if fd.number == number]
        if len(values) != 1:
            raise GuardError("missing declared process descriptor")
        return values[0]


def _file_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_ctime_ns, info.st_mode)


def _credentials(status, field):
    matches = re.findall(rb"^" + field + rb":[ \t]*([0-9]+)[ \t]+([0-9]+)[ \t]+([0-9]+)[ \t]+([0-9]+)[ \t]*$", status, re.M)
    if len(matches) != 1:
        raise GuardError("invalid process credential witness")
    return tuple(int(v) for v in matches[0])


def _flags(data):
    matches = re.findall(rb"^flags:[ \t]*([0-7]+)[ \t]*$", data, re.M)
    if len(matches) != 1:
        raise GuardError("invalid procfs descriptor flags")
    return int(matches[0], 8)


def _descriptor_identity(info):
    # Log position/size/timestamps can advance without replacing its descriptor.
    return info.st_dev, info.st_ino, stat.S_IFMT(info.st_mode)


class ProcReader:
    MAX_PROCESSES = 32
    MAX_DEPTH = 8
    MAX_THREADS = 128
    MAX_FDS = 512
    MAX_TOTAL_BYTES = 16 * 1024 * 1024
    MAX_IMAGE_BYTES = 512 * 1024 * 1024

    def __init__(self, root=Path("/proc"), *, fixture_only=False):
        if not fixture_only and (sys.platform != "linux" or Path(root) != Path("/proc") or os.geteuid() != 0):
            raise GuardError("live witnesses require a privileged Linux procfs reader")
        self.root = Path(root)
        self.fixture_only = fixture_only
        self.evidence = []
        self.total_bytes = 0

    @classmethod
    def fixture(cls, root):
        return cls(root, fixture_only=True)

    def _read(self, relative, maximum=131072):
        record = {"operation": "read", "path": str(relative)}
        self.evidence.append(record)
        try:
            with (self.root / relative).open("rb") as stream:
                data = stream.read(maximum + 1)
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs input unavailable") from error
        record["data_base64"] = base64.b64encode(data).decode("ascii")
        record["limit_exceeded"] = len(data) > maximum
        self.total_bytes += len(data)
        if len(data) > maximum or self.total_bytes > self.MAX_TOTAL_BYTES:
            raise GuardError("procfs evidence size limit")
        return data

    def _names(self, relative, maximum):
        record = {"operation": "list", "path": str(relative)}
        self.evidence.append(record)
        try:
            # Bound enumeration itself rather than materializing an arbitrary directory.
            with os.scandir(self.root / relative) as entries:
                names = []
                for entry in entries:
                    names.append(entry.name)
                    if len(names) > maximum:
                        record.update(names=names, limit_exceeded=True)
                        raise GuardError("procfs directory limit")
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs directory unavailable") from error
        record.update(names=names, limit_exceeded=False)
        if any(not name.isascii() or not name.isdecimal() or str(int(name)) != name for name in names):
            raise GuardError("invalid procfs numeric entry")
        return sorted(int(name) for name in names)

    def _stat(self, relative):
        record = {"operation": "stat", "path": str(relative)}
        self.evidence.append(record)
        try:
            info = (self.root / relative).stat()
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs stat unavailable") from error
        record["identity"] = _file_identity(info)
        return info

    def _link(self, relative):
        record = {"operation": "readlink", "path": str(relative)}
        self.evidence.append(record)
        try:
            value = os.readlink(self.root / relative)
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs link unavailable") from error
        record["target"] = value
        return value

    def _process_stat(self, relative, pid):
        try:
            parsed = parse_process_stat(self._read(relative).decode("ascii"))
        except UnicodeError as error:
            raise GuardError("invalid procfs stat encoding") from error
        if parsed.pid != pid:
            raise GuardError("procfs PID disagrees with path")
        return parsed

    def _image(self, relative):
        record = {"operation": "image", "path": str(relative)}
        self.evidence.append(record)
        try:
            fd = os.open(self.root / relative, os.O_RDONLY | os.O_CLOEXEC)
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs image unavailable") from error
        try:
            before = os.fstat(fd)
            record["identity"] = _file_identity(before)
            record["magic_base64"] = base64.b64encode(os.pread(fd, 4, 0)).decode("ascii")
            if (not stat.S_ISREG(before.st_mode) or before.st_size > self.MAX_IMAGE_BYTES
                    or before.st_size < 4 or os.pread(fd, 4, 0) != b"\x7fELF"):
                raise GuardError("procfs image is not bounded ELF")
            digest = hashlib.sha256()
            position = 0
            while chunk := os.pread(fd, 1024 * 1024, position):
                position += len(chunk)
                if position > self.MAX_IMAGE_BYTES:
                    raise GuardError("procfs image size limit")
                digest.update(chunk)
            identity = _file_identity(before)
            if position != before.st_size or _file_identity(os.fstat(fd)) != identity:
                raise GuardError("procfs image changed during read")
            record.update(identity=identity, sha256=digest.hexdigest())
            return identity, digest.hexdigest()
        except OSError as error:
            record.update(error=type(error).__name__, errno=error.errno)
            raise GuardError("procfs image read failed") from error
        finally:
            os.close(fd)

    def snapshot(self, pid):
        if type(pid) is not int or pid <= 0:
            raise GuardError("invalid procfs PID")
        base = Path(str(pid))
        before = self._process_stat(base / "stat", pid)
        status = self._read(base / "status")
        uid, gid = _credentials(status, b"Uid"), _credentials(status, b"Gid")
        command = self._read(base / "cmdline", 65536)
        if not command.endswith(b"\0") or not command.split(b"\0", 1)[0]:
            raise GuardError("invalid procfs command line")
        argv = tuple(os.fsdecode(v) for v in command[:-1].split(b"\0"))
        image_target = self._link(base / "exe")
        identity, digest = self._image(base / "exe")
        fds = []
        fd_numbers = self._names(base / "fd", self.MAX_FDS)
        for number in fd_numbers:
            relative = base / "fd" / str(number)
            target = self._link(relative)
            info = self._stat(relative)
            fdinfo = self._read(base / "fdinfo" / str(number))
            flags = _flags(fdinfo)
            kind = "pipe" if stat.S_ISFIFO(info.st_mode) else ("regular" if stat.S_ISREG(info.st_mode) else "other")
            if kind == "pipe" and not self.fixture_only and target != f"pipe:[{info.st_ino}]":
                raise GuardError("procfs pipe target disagrees with inode")
            if (_descriptor_identity(self._stat(relative)) != _descriptor_identity(info)
                    or self._link(relative) != target
                    or _flags(self._read(base / "fdinfo" / str(number))) != flags):
                raise GuardError("procfs descriptor changed during read")
            fds.append(FdWitness(number, kind, info.st_dev, info.st_ino, flags, target))
        after = self._process_stat(base / "stat", pid)
        later_status = self._read(base / "status")
        later_identity, later_digest = self._image(base / "exe")
        if (before != after or uid != _credentials(later_status, b"Uid")
                or gid != _credentials(later_status, b"Gid")
                or command != self._read(base / "cmdline", 65536)
                or self._link(base / "exe") != image_target
                or (identity, digest) != (later_identity, later_digest)
                or fd_numbers != self._names(base / "fd", self.MAX_FDS)):
            raise GuardError("procfs process changed during snapshot")
        instance = ProcessInstance(pid, before.start_ticks, digest, uid[1], gid[1])
        return ProcessWitness(before, instance, uid, gid, argv, identity, image_target,
                              tuple(fds), self.fixture_only)

    def children(self, pid):
        base = Path(str(pid)) / "task"
        tids = self._names(base, self.MAX_THREADS)
        if not tids or any(tid <= 0 for tid in tids):
            raise GuardError("missing procfs task witness")
        children = []
        for tid in tids:
            before = self._process_stat(base / str(tid) / "stat", tid)
            data = self._read(base / str(tid) / "children", 65536)
            fields = data.split()
            if any(not v.isdigit() or int(v) <= 0 for v in fields):
                raise GuardError("invalid procfs child list")
            children.extend(int(v) for v in fields)
            if len(children) > self.MAX_PROCESSES:
                raise GuardError("procfs child limit")
            if before != self._process_stat(base / str(tid) / "stat", tid):
                raise GuardError("procfs thread instance changed")
        if len(children) != len(set(children)) or tids != self._names(base, self.MAX_THREADS):
            raise GuardError("procfs task tree changed or duplicated")
        return tuple(sorted(children))

    def owned_tree(self, anchor):
        if not isinstance(anchor, ProcessStat):
            raise GuardError("missing owned anchor instance")
        pending = [(anchor.pid, None, 0)]
        snapshots, child_lists = {}, {}
        while pending:
            pid, parent, depth = pending.pop(0)
            if pid in snapshots or len(snapshots) >= self.MAX_PROCESSES or depth > self.MAX_DEPTH:
                raise GuardError("procfs owned tree cycle or limit")
            witness = self.snapshot(pid)
            if (parent is None and witness.process != anchor
                    or parent is not None and witness.process.parent_pid != parent):
                raise GuardError("procfs owned lineage changed")
            snapshots[pid] = witness
            child_lists[pid] = self.children(pid)
            pending.extend((child, pid, depth + 1) for child in child_lists[pid])
        # Repeat bounded identity/FD/child observations, not a global scan or atomicity claim.
        for pid, witness in snapshots.items():
            if self.snapshot(pid) != witness or self.children(pid) != child_lists[pid]:
                raise GuardError("procfs owned tree changed during collection")
        return snapshots


def identify_sampler(tree, *, expected_sha256, expected_argv, expected_uid, expected_gid,
                     control: PipeChannel, ack: PipeChannel, launcher_images: frozenset[str]):
    if (not tree or not _digest(expected_sha256) or isinstance(expected_argv, (str, bytes)) or not expected_argv
            or not expected_argv[0] or any(not isinstance(v, str) or "\0" in v for v in expected_argv)
            or type(expected_uid) is not int or expected_uid < 0
            or type(expected_gid) is not int or expected_gid < 0
            or type(launcher_images) is not frozenset
            or control.identities & ack.identities
            or any(not _digest(value) for value in launcher_images)):
        raise GuardError("invalid sampler witness declaration")
    candidates = [value for value in tree.values()
                  if value.instance.executable_sha256 == expected_sha256]
    if len(candidates) != 1:
        raise GuardError("sampler image is missing or ambiguous")
    sampler = candidates[0]
    if (sampler.argv != tuple(expected_argv)
            or (sampler.instance.effective_uid, sampler.instance.effective_gid) != (expected_uid, expected_gid)):
        raise GuardError("actual sampler launch policy differs")
    control_fd, ack_fd = sampler.descriptor(0), sampler.descriptor(1)
    if (control_fd.pipe != control.read_end or control_fd.access != os.O_RDONLY
            or ack_fd.pipe != ack.write_end or ack_fd.access != os.O_WRONLY):
        raise GuardError("actual sampler private endpoints differ")
    private = control.identities | ack.identities
    for witness in tree.values():
        if witness is not sampler and witness.instance.executable_sha256 not in launcher_images:
            raise GuardError("undeclared launcher-tree image")
        for fd in witness.fds:
            if fd.pipe in private and not (witness is sampler and fd.number in (0, 1)):
                raise GuardError("sampler channel has another owned-tree endpoint")
    return sampler


def require_wrapper_private_channels_absent(wrapper, control: PipeChannel, ack: PipeChannel):
    if any(fd.pipe in control.identities | ack.identities for fd in wrapper.fds):
        raise GuardError("wrapper inherited sampler endpoint")


if __name__ == "__main__":
    raise SystemExit("Read-only procfs witness component only; no capture entrypoint")
