import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-regular-inputs-v1';I=P/'source-preparation-inputs-v1';L=P/'FIRST-remaining-literal-ledgers-v1';v=json.loads(sys.argv[1]);CP=B/'current-task-checkpoint.json'
inputs=[
('NEW2279scope',I/'NEW2279scope-opaque-bound-PRIVATE',6409181,'601d18c6047db53f7159d16a9748ced542b69b89cf5b3b6da1e47c004e1a471c'),
('actual199DIRECTORYmetadata',I/'actual199DIRECTORYmetadata-opaque-bound-PRIVATE',71009093,'c2b323eed056e924be51db8dff6e2b73f5c41ac5c873adcff17f087e7e98c78c'),
('actual4868BODYmetadata',I/'actual4868BODYmetadata-opaque-bound-PRIVATE',63401479,'a49f18de7e725caedeebcae268c14669346acb1ea4de23f151f61c5d389854f0'),
('actual190DIRECTORYmetadata',I/'actual190DIRECTORYmetadata-opaque-bound-PRIVATE',21618013,'7d1b45c39fc32fe52e446610d2aa022ea3489b795f75941dff9ead67d47a9082'),
('actual1229BODYmetadata',I/'actual1229BODYmetadata-opaque-bound-PRIVATE',14412328,'1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331'),
('FIRSTnew2279selectedtail',I/'FIRST-new2279-selected-original4868-tail-2640103-2660103.txt',20000,'a455737e9db5a8bd037824ab7741f862ed6c49c078de805189877b2c9c9603c3')]
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();L.mkdir()
 def save(n,b):
  with (L/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':v['scope'],'exact_saved_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':h} for r,p,n,h in inputs],'root_original_range':[463594,463697],'root_original_sha256':'edc587eabec8066223786da87f7e2bad9f6cb882ba0c08dad712056aea7154a7','FIRST_control_sink_selector':'    scope_path = root / "NEW-great-grandchild-scope-BEFORE-INPUT-IO.json"\n','all_admission_flags':False,'ownership':None},indent=2));save('controller.py',sys.argv[2]);save('actual-new-context.json',json.dumps(v,indent=2));bindings=[];saved={}
 def read(path,size,sha,role):
  b={'role':role,'path':str(path),'range':[0,size],'expected_sha256':sha,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   a=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];b['before']={k:getattr(a,k) for k in keys};b['before_atime_ns_POINT_ONLY']=a.st_atime_ns;assert stat.S_ISREG(a.st_mode) and a.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    block=os.read(fd,min(65536,size-count));assert block,'earlyrangeend/FOREVERquarantine';parts.append(block);count+=len(block);h.update(block)
   z=os.fstat(fd);b.update(after={k:getattr(z,k) for k in keys},after_atime_ns_POINT_ONLY=z.st_atime_ns,bytes=count,sha256=h.hexdigest());assert b['before']==b['after'] and count==size and h.hexdigest()==sha;raw=b''.join(parts)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return raw
 for role,path,size,sha in inputs:saved[role]=read(path,size,sha,role)
 scope=json.loads(saved['NEW2279scope']);refs=scope['ALL2279_new_literal_regular_BODYINPUT_references'];objects={role:json.loads(saved[role]) for role in ['actual199DIRECTORYmetadata','actual4868BODYmetadata','actual190DIRECTORYmetadata','actual1229BODYmetadata']};groups=[];scalars=[]
 for role,key in [('actual199DIRECTORYmetadata','ALL199_source_refs'),('actual4868BODYmetadata','ALL4868_source_refs'),('actual190DIRECTORYmetadata','ALL190_source_refs'),('actual1229BODYmetadata','ALL1229_source_refs')]:
  values=objects[role][key];groups.append({'role':role,'original_metadata_location':[key],'literal_values':values,'qualification':'originalsavedactualreferencearray metadata NOTbody revalidation or originalruntime credentials/ABI/ownership admission'})
 def traverse(value,role,location):
  if isinstance(value,str):scalars.append({'ordinal_ZERO_based':len(scalars),'original_saved_input_role':role,'location':location,'literal':value})
  elif isinstance(value,list):
   for i,item in enumerate(value):traverse(item,role,location+[i])
  elif isinstance(value,dict):
   if 'literal_values' in value and isinstance(value['literal_values'],list) and all(isinstance(x,str) for x in value['literal_values']):
    groups.append({'role':role,'original_metadata_location':location+['literal_values'],'literal_values':value['literal_values'],'original_full_captured_group_PRIVATE':value,'qualification':'originalcapturedliteralgroup NOTrevalidated/duplicates-originalpositionsretained'})
   for key,item in value.items():traverse(item,role,location+[key])
 for role,obj in objects.items():traverse(obj,role,[])
 index={}
 for row in scalars:index.setdefault(row['literal'],[]).append(row['ordinal_ZERO_based'])
 def runs(total,excluded):
  answer=[];start=0
  for x in excluded:
   if x>start:answer.append([start,x])
   start=x+1
  if start<total:answer.append([start,total])
  return answer
 relationships=[]
 for ordinal,ref in enumerate(refs):
  gm=[]
  for gi,group in enumerate(groups):
   positions=[i for i,old in enumerate(group['literal_values']) if ref==old]
   gm.append({'original_group_position_ZERO_based':gi,'matching_original_reference_ordinals_ZERO_based':positions,'nonmatching_original_reference_ordinal_runs_ZERO_based_HALF_OPEN':runs(len(group['literal_values']),positions)})
  positions=index.get(ref,[])
  relationships.append({'NEW2279_scope_position_ONE_based':ordinal+1,'NEW_express_lexical_candidate_TEXT':ref,'ALL_original_ledger_groups_matching_nonmatching_positions':gm,'ALL_captured_scalar_exact_match_ordinals_ZERO_based':positions,'ALL_captured_scalar_nonmatching_ordinal_runs_ZERO_based_HALF_OPEN':runs(len(scalars),positions),'alias_identity':None,'query_permission':None})
 tail=saved['FIRSTnew2279selectedtail'];sink=b'    scope_path = root / "NEW-great-grandchild-scope-BEFORE-INPUT-IO.json"\n';locations=[];start=0
 while True:
  q=tail.find(sink,start)
  if q<0:break
  locations.append(q);start=q+1
 ledger={'qualification':v['scope'],'NEW_scope_count':len(refs),'ALL_prior_reference_ledger_groups':groups,'ALL_prior_captured_static_literals_PRIVATE':scalars,'prior_captured_static_metadata_string_count':len(scalars),'ALL2279_relationships':relationships,'candidate_records_with_prior_exact_ledger_matches':sum(any(g['matching_original_reference_ordinals_ZERO_based'] for g in row['ALL_original_ledger_groups_matching_nonmatching_positions']) for row in relationships),'candidate_records_with_prior_exact_static_metadata_matches':sum(bool(row['ALL_captured_scalar_exact_match_ordinals_ZERO_based']) for row in relationships),'all_original_saved_input_files_fullfields_PRIVATE_unchanged':True,'original_type_flags_fullstat_times_private_relationships_NOT_dropped':True,'all_admission_flags':False,'ownership':None}
 raw=(json.dumps(ledger,ensure_ascii=True,indent=2)+'\n').encode();save('FIRST-NEW2279-actual-reference-ledger-intake-PRIVATE.json',raw)
 selection={'root_range':[463594,463697],'root_sha256':'edc587eabec8066223786da87f7e2bad9f6cb882ba0c08dad712056aea7154a7','FIRST_selected_original4868_tail_range':[2640103,2660103],'FIRST_sink_occurrences_relative_to_selected_tail':locations,'selected_tail_sha256':hashlib.sha256(tail).hexdigest(),'NEW2279_count':len(refs),'original_group_counts':[len(g['literal_values']) for g in groups],'prior_captured_static_metadata_string_count':len(scalars),'ALL2279_exact_ledger_matched_candidates':ledger['candidate_records_with_prior_exact_ledger_matches'],'ALL2279_exact_static_matched_candidates':ledger['candidate_records_with_prior_exact_static_metadata_matches'],'saved_metadata_bindings':len(bindings),'ledger_result_bytes':len(raw),'ledger_result_sha256':hashlib.sha256(raw).hexdigest(),'all_admission_flags':False,'ownership':None}
 save('FIRST-new2279-source-control-and-ledger-BEFORE-gates.json',json.dumps(selection,indent=2))
 assert len(refs)==2279 and [len(g['literal_values']) for g in groups[:4]]==[199,4868,190,1229] and len(locations)==1
 assert ledger['candidate_records_with_prior_exact_ledger_matches']==ledger['candidate_records_with_prior_exact_static_metadata_matches']==0
 absolute=2640103+locations[0];control=tail[locations[0]:];save('FIRST-new2279-selected-sink-to-source-end-control.txt',control);selection.update(scope_sink_to_savedsource_end_range=[absolute,2660103],scope_sink_control_bytes=len(control),scope_sink_control_sha256=hashlib.sha256(control).hexdigest(),FIRST_unique_NEW2279_sink_selector_PASS=True,ALL2279_exact_reference_ledger_staticmetadata_gates_PASS=True)
 save('FIRST-new2279-source-control-and-ledger-descriptor.json',json.dumps(selection,indent=2))
 before=CP.read_bytes();save('checkpoint-before-literal-qualification.json',before);d=json.loads(before);node=d['actions_include_great_great_grandchild_regular_inputs_v1'];node.update(phase='FIRST_NEW2279_boundinput_controlselection_actual_reference_qualification_COMPLETE_CONSUMED_generation_pending_NOT_queried',source_control_and_ledger=selection,all_admission_flags=False,ownership=None);d['active_turn_status'].update(new_include_great_great_grandchild_regular_inputs='FIRSTnew2279seveninputbindings-controlinterpretation-ledgers_COMPLETE_CONSUMED_generation_PENDING',next='FIRSTnew2279 source writer fromboundoriginal4868collector/workflow36/exactscope6409181B/newledger exactbindings-FIRSTselectedsink. Preserveall36oldjobs/originalregularfunctions/old1199-1229-4868scopes separately/reversewholeoldbytes/new36SOURCEfalseconditions. No oldinputreader-comparison-controlselector replay.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(selection),flush=True);print(json.dumps({'FIRST_new2279_control_selection_FOR_ROOT_ONLY_opaque_old_qualification_lines_excluded': ''.join(line for line in control.decode().splitlines(keepends=True) if not (line.startswith('        "qualification": ') or line.startswith('        "prior_ALL'))),'full_original_control_saved_UNMODIFIED':True}),flush=True);lease.verify_identity()
