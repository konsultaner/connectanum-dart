def refuse(error,record,row=None):
        if primary[0] is None:primary[0]=error
        try:
            owner.finished=True
            group=_failure_preservation_group(owner,primary[0])
            primary[0]=group[3]
            record['primary_error']=primary[0]
            group[2](error,row)
        finally:raise primary[0]

def refuse(error,row=None):
            private_first[0]=error
            try:
                group=_failure_preservation_group(self,error)
                private_first[0]=group[3]
                record['primary_error']=private_first[0]
                group[2](error,row)
            finally:raise private_first[0]