# CommandProducer._defer_failure lines 3117..3155
            context(None)
            self.evidence_complete=True;record['completed']=True
            return self.result
        except BaseException as error:
            guard()
            refuse(error)

    def _defer_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,
            process=None,events=None,log=None,completed=False,steps=[])
        _DEFERRED_FAILURE_RECORDS.append(record) # Before formatting/callee I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            process=call('process',lambda:getattr,(self,'process'));record['process']=process
            events=call('events',lambda:getattr,(self,'events'));record['events']=events
            log=call('log',lambda:getattr,(self,'log'));record['log']=log
            pending=call('pending',lambda:getattr,(self,'pending'))
            records=call('records',lambda:getattr,(self,'records'))
            deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
            if (type(pending) is not bool or type(records) is not list or not records
                or type(records[-1]) is not dict or any(type(k) is not str for k in records[-1])
                or (deferred is not None and type(deferred) is not str)):
                raise ProducerError('unknown deferred failure context')
            command_record=records[-1];record['command_record']=command_record

# CommandProducer._preserve_failure lines 3185..3223
            raw=call('failure_preserve',lambda:preserver,(error,))
            if raw is not None:raise ProducerError('unknown failure preserver return')
            check_context(expected,None if not pending and events is not None else events)
            record['completed']=True # Deferral body only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)

    def _preserve_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,events=None,
            completed=False,steps=[])
        _FAILURE_PRESERVATION_RECORDS.append(record) # Before context lookup/I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            events=call('events',lambda:getattr,(self,'events'))
            record['events']=events # Original handle BEFORE representation/publication.
            pending=call('pending',lambda:getattr,(self,'pending'))
            attempted=call('failure_attempted',lambda:getattr,(self,'failure_attempted'))
            if type(pending) is not bool or type(attempted) is not bool:
                raise ProducerError('unknown failure preservation flags')
            if not attempted:
                self.failure_attempted=True # Original one terminal publication attempt.
                writer=call('failure_writer_lookup',lambda:lambda:_write_json)
                renderer=call('repr_lookup',lambda:lambda:repr)
                deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))

# _end_command_group.refuse lines 2545..2583
        return previous
    primary=[None]
    def guard():
        if primary[0] is not None:raise primary[0]
    def refuse(error,record,row=None):
        if primary[0] is None:primary[0]=error
        try:
            owner.finished=True
            group=_failure_preservation_group(owner,primary[0])
            primary[0]=group[3]
            record['primary_error']=primary[0]
            group[2](error,row)
        finally:raise primary[0]
    group=(owner,guard,refuse)
    _END_COMMAND_GROUPS[id(owner)]=group
    return group


def _end_command_guard(owner):
    previous=_END_COMMAND_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('end-command owner mismatch')
        previous[1]()


_WAIT_ENTRIES={}
_WAIT_ENTRY_RECORDS=[]


def _wait_entry_guard(owner):
    previous=_WAIT_ENTRIES.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('wait entry owner mismatch')
        previous[1]()


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,

# CommandProducer._finish.refuse lines 3031..3069
            if private_first[0] is not None:raise private_first[0]
        record={'owner':self,'events':original_events,'directory':directory,'result':result,'outputs':outputs,
                'primary_error':None,'steps':[],'completed':False}
        _FINISH_PUBLICATIONS[id(self)]=(self,guard)
        _FINISH_PUBLICATION_RECORDS.append(record)
        def refuse(error,row=None):
            private_first[0]=error
            try:
                group=_failure_preservation_group(self,error)
                private_first[0]=group[3]
                record['primary_error']=private_first[0]
                group[2](error,row)
            finally:raise private_first[0]
        def step(stage,callback,role=None):
            guard();_failure_preservation_guard(self)
            row={'stage':stage,'role':role,'returned':False,'raw':None,'error':None}
            record['steps'].append(row)
            try:
                raw=callback();row['raw']=raw;row['returned']=True
                return raw
            except BaseException as error:refuse(error,row)
        def context(expected_events):
            guard()
            if (self.directory is not directory or self.events is not expected_events
                or self.result is not result or self.outputs is not outputs):
                raise ProducerError('finish publication context changed')
        def digest(raw):
            if type(raw) is not str or re.fullmatch('[0-9a-f]{64}',raw) is None:
                raise ProducerError('finish publication digest is invalid')
            return raw
        try:
            self.finished=True
            writer=_write_json;hasher=_regular_hash;event=self._event;close=original_events.close
            output_hashes={}
            if status=='success':
                for role,path in outputs.items():
                    context(original_events)
                    pattern=step('output_pattern',lambda:str(path),role)
                    if type(pattern) is not str:raise ProducerError('output pattern is invalid')

# CommandProducer.__init__ lines 2636..2674
            self.intent_sha256=_regular_hash(self.directory/'intent.json')
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            try:group=_failure_preservation_group(self,error)
            except BaseException:raise error
            if type(group) is not tuple or len(group)!=5:raise error
            try:
                if self.pending:
                    # Preserve the actual owned child and return its waitable handle.
                    self._defer_failure(error)
                else:
                    self.finished=True
                    self._preserve_failure(error)
                    raise
            except BaseException as secondary:
                if secondary is error:raise
                group[2](secondary)

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        name=f'git-{index:03}';out=self.directory/(name+'.stdout')
        cmd=[self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv]
        result=_observe_auxiliary(self,name,cmd)
        stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
        if argv[0]=='archive':
            if _file_snapshot(out,1024**3)!=stdout:raise ProducerError('auxiliary archive output differs')