        except BaseException as error:
            try:group=_failure_preservation_group(self,error)
            except BaseException:raise error
            if type(group) is not tuple or len(group)!=5:raise error
            try:
                if self.pending:
                    # Preserve the actual owned child and return its waitable handle.
                    self._defer_failure(error)
                else:
                    self.finished=True
                    self._preserve_failure(error)
                    raise
            except BaseException as secondary:
                if secondary is error:raise
                group[2](secondary)