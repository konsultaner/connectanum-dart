import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-refusal-contract-audit-v1');C=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-shape-progress-v1/after-producer.py')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();P.mkdir();source=C.read_text();digest=hashlib.sha256(source.encode()).hexdigest();assert digest=='6e04cefc79c8c4725d72a19a931903fb2d1eb5b382b2916960c75c603fbc1706'
 tree=ast.parse(source);selected={};references=[]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name=='_failure_preservation_group':selected[node.name]=ast.get_source_segment(source,node)
  if isinstance(node,ast.ClassDef) and node.name=='CommandProducer':
   for f in node.body:
    if isinstance(f,ast.FunctionDef) and f.name in ('__init__','_defer_failure','_preserve_failure'):selected[node.name+'.'+f.name]=ast.get_source_segment(source,f)
 for node in ast.walk(tree):
  if isinstance(node,ast.Name) and node.id=='_failure_preservation_group':references.append(dict(line=node.lineno,context=type(node.ctx).__name__))
 assert len(selected)==4 and len(references)==3
 (P/'cached-selected.py').open('x').write('\n\n'.join(selected.values()));(P/'selected-symbols.json').open('x').write(json.dumps(selected,indent=2));(P/'static-references.json').open('x').write(json.dumps(references,indent=2))
 declaration=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_question='Does the constructor preserve known First if its already-returned five-tuple refusal field returns normally or raises a different exception after a later pending/defer/preserve error?',cached_input=str(C),cached_source_sha256=digest,scope='AST/selected cached bytes only; no runtime regression counterexample claimed',no_Source_tests_HEAD_current20_recensus_SDK_native_build_capture_adoption=True,prior_suites_models_archives_campaigns_NOT_replayed=True,prospective_refuse_contract_counterexamples_require_NEW_declaration_and_actual_BEFORE_before_Source_edit=True)
 (P/'declaration.json').open('x').write(json.dumps(declaration,indent=2))
 q=P/'summarize';q.mkdir();context='Summarize <=140words three precise source facts about the constructor exception path and the failure-group refusal callback. New cached-source question only: exact five-tuple shape is checked before pending, but handler calls group[2](secondary) outside its own try. What happens syntactically if that call returns normally or raises another error? Separate native refusal implementation (finally always raises primary) from unproved runtime alias/binding/field/callee completion contracts. Do not claim executed counterexamples, RAM cause, live resources, admission, or Source edits. No suggestions to reset/pop/evict, use partial Popen methods, replay tests or models.\n'+(P/'cached-selected.py').read_text()
 assert len(context)<24000
 (q/'context.txt').open('x').write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--model','gemma4:latest','--num-predict','1200','--max-input-chars','24000','--max-response-chars','10000','--timeout','180','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').open('x').write(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/'start.json').open('x').write(json.dumps(dict(pid=child.pid)))
 out,err=child.communicate();status=wait();inp.close();(q/'stdout.bin').open('xb').write(out);(q/'stderr.bin').open('xb').write(err)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True)
 (q/'result.json').open('x').write(json.dumps(result,indent=2));l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-500:])
