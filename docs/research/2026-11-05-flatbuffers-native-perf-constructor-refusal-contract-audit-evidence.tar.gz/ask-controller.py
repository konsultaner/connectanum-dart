import sys,pathlib,ast,json,hashlib,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-refusal-contract-audit-v2');C=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-shape-progress-v1/after-producer.py')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();s=C.read_text();assert hashlib.sha256(s.encode()).hexdigest()=='6e04cefc79c8c4725d72a19a931903fb2d1eb5b382b2916960c75c603fbc1706'
 tree=ast.parse(s);parents={child:parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)};rows=[];excerpts=[];lines=s.splitlines()
 for node in ast.walk(tree):
  if isinstance(node,ast.Name) and node.id=='_failure_preservation_group':
   chain=[];parent=node
   while parent in parents:
    parent=parents[parent]
    if isinstance(parent,(ast.FunctionDef,ast.ClassDef)):chain.append(parent.name)
   start=max(1,node.lineno-8);end=min(len(lines),node.lineno+30)
   rows.append(dict(line=node.lineno,qualified_scope='.'.join(reversed(chain)),syntax=ast.get_source_segment(s,parents[node]),excerpt_start=start,excerpt_end=end))
   excerpts.append('# '+'.'.join(reversed(chain))+' lines '+str(start)+'..'+str(end)+'\n'+'\n'.join(lines[start-1:end]))
 (P/'callsite-map.json').open('x').write(json.dumps(rows,indent=2));(P/'callsite-excerpts.py').open('x').write('\n\n'.join(excerpts))
 symbols=json.loads((P/'selected-symbols.json').read_text());ctor=symbols['CommandProducer.__init__'];ctor=ctor[ctor.index('        except BaseException as error:'):]
 (P/'constructor-handler.py').open('x').write(ctor)
 q=P/'ask';q.mkdir();context='Answer <=180words max3 qualified facts. NEW cached-source audit only, no runtime counterexample or Source/test execution. Constructor alreadychecks exactplain5tuple. Afterlater pending/defer/preserve Secondary its except handler invokes group[2](secondary) with no surrounding finally/backstop. Nativehelperrefuse alwaysraisesPrimary in finally; five-tuplekindarityalone cannot prove that binding/callee completion contract. Compare 5literal ASTreferences below (nominal syntax only, no allaliases/transitiveclosure). Does a substituted refusal callback returning normally permit __init__ fallthrough, and does a different thrown error escape instead of knownFirst? Are _end_command/_fail independent private-primary/finally backstops meaningfully different? Give at most ONE prospective controlled regression with realfinitePopen/ROOToriginalhandles-beforeIO, actualnativegroupONLYROOT thenrefusecall boundary injection and no partialPopen/sourcefieldrestore/borrowedcleanup. Neverrecommendreset-pop-evict-kill-testmodelrepeat orclaimmemory/RAM/physicalEX-admission. ActualBEFORErequired beforeanySourcefix. Gemma31909full0 summaryqualified: tuplekindaritycheck isconstructor nothelper; sourceguard/contextvalidation isnotresourceownership-cleanup-completeness; no primary-priority completion guarantee proved.\nNATIVEGROUP\n'+symbols['_failure_preservation_group']+'\nCTORHANDLER\n'+ctor+'\nNOMINALCALLS\n'+(P/'callsite-excerpts.py').read_text()
 assert len(context)<26000,len(context);(q/'context.txt').open('x').write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','ask','--model','qwen3.8:27b','--num-predict','1600','--max-input-chars','26000','--max-response-chars','12000','--timeout','180','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').open('x').write(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/'start.json').open('x').write(json.dumps(dict(pid=child.pid)))
 out,err=child.communicate();status=wait();inp.close();(q/'stdout.bin').open('xb').write(out);(q/'stderr.bin').open('xb').write(err)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True)
 (q/'result.json').open('x').write(json.dumps(result,indent=2));l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-500:])
