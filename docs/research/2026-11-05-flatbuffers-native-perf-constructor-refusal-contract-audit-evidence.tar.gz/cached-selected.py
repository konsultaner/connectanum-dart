def _failure_preservation_group(owner,error):
    key=id(owner)
    previous=_FAILURE_PRESERVATION_GROUPS.get(key)
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        previous[1]()
        return previous
    primary=error
    quarantined=[False]
    secondary=[]

    def guard():
        if quarantined[0]:raise primary

    def refuse(received,row=None):
        quarantined[0]=True # Private terminal first BEFORE secondary metadata.
        try:
            if received is not primary:secondary.append(received)
            if row is not None:row['error']=received
        finally:
            raise primary

    group=(owner,guard,refuse,primary,secondary)
    _FAILURE_PRESERVATION_GROUPS[key]=group # Strong owner/first, process lifetime.
    return group

def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None,tools=None,census_id=None,expected_sdk=None,config_bindings=None,_preflight_owner=None):
        if _preflight_owner is not None:
            if type(_preflight_owner) is not _RetainedPreflightOwner:raise ProducerError('foreign preflight entry hook')
            _preflight_owner._register_producer(self)
        self._receipt_primary_error_object=None;self._receipt_primary_error_stage=None
        self._receipt_secondary_error_objects=[]
        self._receipt_resources=[];self._receipt_resources_quarantined=False
        self._receipt_resource_directory=None;self._receipt_resource_lease=lease_check
        self._receipt_readers=[];self._receipt_reader_ledger=self._receipt_readers
        self._command_attempts=[];self._command_attempt=None
        self._command_history_primary_error=None;self._command_history_primary_stage=None
        self._command_history_secondary_errors=[]
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        if ((census_id is None)!=(expected_sdk is None) or (census_id is not None and
            (type(census_id) is not str or not re.fullmatch('[0-9a-f]{32}',census_id) or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)))):
            raise ProducerError('invalid pre-child census/SDK context')
        config_bindings={} if config_bindings is None else config_bindings
        if (type(config_bindings) is not dict or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}',k) or type(v) is not str or v not in inputs for k,v in config_bindings.items())
            or (config_bindings and (expected_sdk is None or not {'server','client'}<=set(config_bindings)))):
            raise ProducerError('unbound pre-child config context')
        self.census_id=census_id;self.expected_sdk=expected_sdk;self.config_bindings=MappingProxyType(dict(config_bindings))
        self.evidence_complete=False;self.receipt_attempted=False;self.intent_sha256=None;self.result_sha256=None;self.journal_sha256=None
        self.repo=Path(repo);self.directory=Path(run_dir)
        self._receipt_resource_directory=self.directory
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.tools=_tool_table(tools)
        self.task_kinds=tuple(('tool_version',name) for name in sorted(self.tools))+tuple(('recipe',None) for _ in commands)
        self.commands=tuple((self.tools[name]['entry'],*VERSION_ARGS[name]) for name in sorted(self.tools))+tuple(tuple(a) for a in commands)
        self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.environment={**os.environ,**self.env_delta};self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False;self.output_log=None;self.failure_attempted=False;self.auxiliary_operations=[]
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            _write_json(self.directory/'intent.json',{'kind':'build-preparation-intent-v1','source_commit':source_commit,'runtime_commit':runtime_commit,
                        'census_id':self.census_id,'expected_sdk':self.expected_sdk,'config_bindings':dict(self.config_bindings),
                        'expected_archive_sha256':expected_archive_sha256,'inputs':dict(self.inputs),'tools':{k:dict(v) for k,v in self.tools.items()},
                        'commands':[list(a) for a in self.commands],'task_kinds':self.task_kinds,'provenance':provenance,
                        'producer_file_sha256':_regular_hash(Path(__file__).resolve()),'environment_delta':self.env_delta})
            self.intent_sha256=_regular_hash(self.directory/'intent.json')
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            try:group=_failure_preservation_group(self,error)
            except BaseException:raise error
            if type(group) is not tuple or len(group)!=5:raise error
            try:
                if self.pending:
                    # Preserve the actual owned child and return its waitable handle.
                    self._defer_failure(error)
                else:
                    self.finished=True
                    self._preserve_failure(error)
                    raise
            except BaseException as secondary:
                if secondary is error:raise
                group[2](secondary)

def _defer_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,
            process=None,events=None,log=None,completed=False,steps=[])
        _DEFERRED_FAILURE_RECORDS.append(record) # Before formatting/callee I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            process=call('process',lambda:getattr,(self,'process'));record['process']=process
            events=call('events',lambda:getattr,(self,'events'));record['events']=events
            log=call('log',lambda:getattr,(self,'log'));record['log']=log
            pending=call('pending',lambda:getattr,(self,'pending'))
            records=call('records',lambda:getattr,(self,'records'))
            deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
            if (type(pending) is not bool or type(records) is not list or not records
                or type(records[-1]) is not dict or any(type(k) is not str for k in records[-1])
                or (deferred is not None and type(deferred) is not str)):
                raise ProducerError('unknown deferred failure context')
            command_record=records[-1];record['command_record']=command_record
            preserver=call('preserver_lookup',lambda:lambda:self._preserve_failure)
            renderer=call('repr_lookup',lambda:lambda:repr)

            def check_context(expected,expected_events=events):
                guard()
                if (self.directory is not directory or self.process is not process
                    or self.events is not expected_events or self.log is not log or self.pending is not pending
                    or self.records is not records or not records or records[-1] is not command_record
                    or self.deferred_error is not expected):
                    raise ProducerError('deferred failure context changed')
                actual=call('preserver_binding',lambda:lambda:self._preserve_failure)
                if (type(actual) is not MethodType or type(preserver) is not MethodType
                    or actual.__self__ is not self or preserver.__self__ is not self
                    or actual.__func__ is not preserver.__func__):
                    raise ProducerError('deferred failure preserver binding changed')

            check_context(deferred)
            text=call('error_repr',lambda:renderer,(error,))
            if type(text) is not str:raise ProducerError('unknown deferred failure representation')
            check_context(deferred)
            if deferred is None:
                self.deferred_error=text;expected=text
            else:
                secondary=call('secondary_list',lambda:command_record.setdefault,('secondary_errors',[]))
                if type(secondary) is not list:raise ProducerError('unknown secondary failure ledger')
                appended=call('secondary_append',lambda:secondary.append,(text,))
                if appended is not None:raise ProducerError('unknown secondary append return')
                expected=deferred
            check_context(expected)
            raw=call('failure_preserve',lambda:preserver,(error,))
            if raw is not None:raise ProducerError('unknown failure preserver return')
            check_context(expected,None if not pending and events is not None else events)
            record['completed']=True # Deferral body only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)

def _preserve_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,events=None,
            completed=False,steps=[])
        _FAILURE_PRESERVATION_RECORDS.append(record) # Before context lookup/I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            events=call('events',lambda:getattr,(self,'events'))
            record['events']=events # Original handle BEFORE representation/publication.
            pending=call('pending',lambda:getattr,(self,'pending'))
            attempted=call('failure_attempted',lambda:getattr,(self,'failure_attempted'))
            if type(pending) is not bool or type(attempted) is not bool:
                raise ProducerError('unknown failure preservation flags')
            if not attempted:
                self.failure_attempted=True # Original one terminal publication attempt.
                writer=call('failure_writer_lookup',lambda:lambda:_write_json)
                renderer=call('repr_lookup',lambda:lambda:repr)
                deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
                if deferred is not None and type(deferred) is not str:
                    raise ProducerError('unknown deferred failure text')
                text=deferred or call('error_repr',lambda:renderer,(error,))
                if type(text) is not str:raise ProducerError('unknown failure representation')
                uncertain=self.output_write_uncertain
                if type(uncertain) is not bool:raise ProducerError('unknown output write uncertainty')
                payload={'error':text,'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
                    'output_write_uncertain':uncertain,
                    'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if uncertain else None}
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation context changed')
                raw=call('failure_write',lambda:writer,(directory/'failure.json',payload))
                if raw is not None:raise ProducerError('unknown failure publication return')
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation publication context changed')
            if not pending and events is not None:
                if self.directory is not directory or self.events is not events or self.pending is not pending:
                    raise ProducerError('failure journal context changed')
                closer=call('journal_close_lookup',lambda:lambda:events.close)
                self.events=None # Preserve original clearing-before-close; handle retained.
                call('journal_close',lambda:closer) # Original ignored return, including False.
            record['completed']=True # Helper only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)