import pathlib,sys,json,hashlib,importlib.util,os,stat
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('pr132_FIRST_original_saved_include_result_publication_binding_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-entry-source-alias-intake-v1';Q=P/'saved-result-binding-v1';S=P/'intake-v1/ROOT-ALL210-intake-summary.json';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'question':'FIRST binding of DISTINCT ORIGINAL fullsaved summary for new include-intake summary/publication. Original intake controller saved ROOT-ALL210-intake-summary.json BEFORE consoleprint. Actual outerconsole27086tokens/budget24000 truncated remainsUNRETAINED/neverreconstructed-repolled-reexecuted; outertool0/separatePID-pipeEOFNULL. Functions JSON.parse on actual toolwarning failed, NOTnativeintake failure or Source bug/fix/retry authority. Read only originalsavedsummary, copyBYTEEXACT/retain allfields; publication wholeoriginalraw+JSON equality againstcopy preserves ALL210 records/gates with no rounding/normalization. This is originalsaveddata NOTomittedstdout/PID/status/raw reconstruction/general missingraw allowance.','source':'intake-v1/ROOT-ALL210-intake-summary.json','all_admission_flags':False},indent=2));save('controller.py',sys.argv[2]);save('actual-truncated-outer-tool-return.json',json.dumps(v['actual_outer_return'],ensure_ascii=False,indent=2));save('ROOT-functions-parser-boundary-qualification.json',json.dumps(v['parser_boundary_qualification'],indent=2))
 fd=os.open(S,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);a={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};parts=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   parts.append(b)
  raw=b''.join(parts);s=os.fstat(fd);z={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};assert a==z and len(raw)==a['size']
 finally:os.close(fd)
 d=json.loads(raw);assert d['source_run']==42311168556 and len(d['ALL210_safe_original_entry_metadata'])==210
 save('original-saved-result.json',raw);binding={'original_saved_result_bytes':len(raw),'original_saved_result_sha256':hashlib.sha256(raw).hexdigest(),'before':a,'after':z,'whole_original_fields_preserved_BYTEEXACT':True,'read_EOF':True,'outer_console_full_UNRETAINED_NOT_reconstructed':True,'functions_warning_JSON_parse_failure_NOT_native_failure':True,'separate_outer_PID_pipe_EOF':None,'all_admission_flags':False};save('original-saved-result-binding-PRIVATE.json',json.dumps(binding,indent=2))
 out={k:z for k,z in d.items() if k!='ALL210_safe_original_entry_metadata'};out.update(original_saved_result_bytes=len(raw),original_saved_result_sha256=hashlib.sha256(raw).hexdigest(),outer_console_full_UNRETAINED_NOT_reconstructed=True,ALL210_original_safe_metadata_preserved_BYTEEXACT_in_original_saved_result=True,ALL_entries_with_name_matches=[x for x in d['ALL210_safe_original_entry_metadata'] if x['matching_scalar_counts']['literal_entry_name']>0],ALL_original_symlink_string_records=[x for x in d['ALL210_safe_original_entry_metadata'] if x['saved_type_derived_from_original_mode']=='symlink'])
 save('ROOT-small-original-result-publication-metadata.json',json.dumps(out,indent=2));print(json.dumps(out),flush=True);lease.verify_identity()
