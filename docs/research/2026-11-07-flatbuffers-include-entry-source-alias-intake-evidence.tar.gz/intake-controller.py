import pathlib,sys,json,hashlib,importlib.util,os,stat,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('pr132_NEW_ALL210_include_entry_source_alias_intake_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-entry-source-alias-intake-v1';I=P/'intake-v1';A=B/'2026-11-06-actions-c-tool-child-directory-inputs-v1/Actions-v1/artifact-members';CP=B/'current-task-checkpoint.json';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();I.mkdir()
 def save(n,b):
  with (I/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 decl={'question':'FIRST NEW source/alias relationship intake for ALL210 literal /usr/include entry records. Exactly current CP plus saved report member named by actual index; index ONLYlocates savedreport, originalrecords supply NEW source/alias relations. No old7set interpretation/63slots recomputation, oldwritejournal comparison/installedSDK-imagehash refresh, currentdirectory/nativequery/entrybody-read/linkfollow/recursion/Actions/acquisition/model/archive/numerical replay. Keep ALL210 original full entries privately, safe derived mode/type/name/original namehex/UIDGID/readlink strings publicly; no favorableC-C++language-version-ABI/defaultcompiler filter. Compare separate literal names/namehex/readlinkstrings against priorCP metadata, retain ALLmatches/locations/offsets. DO NOTlexically join parent+entry, expand readlink or manufacture missing originalreadlink bytehex; originalmissingbytes stayNULL. Scoped matches/nonmatches NOTaliasidentity/bodycoverage/newness/permission.','source_parent_reference':'/usr/include','actual_saved_report_member':v['actual_report_member'],'source_directory':'2026-11-06-actions-c-tool-child-directory-inputs-v1/Actions-v1/artifact-members','all_admission_flags':False}
 save('declaration.json',json.dumps(decl,indent=2));save('controller.py',sys.argv[2]);save('available-actual-metadata-locator-returns.json',json.dumps(v['actual_locator_returns'],ensure_ascii=False,indent=2));bindings=[]
 def read(path,role,expected=None):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
  try:
   s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);a={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};chunks=[];h=hashlib.sha256();count=0
   while True:
    b=os.read(fd,65536)
    if not b:break
    chunks.append(b);count+=len(b);h.update(b)
   raw=b''.join(chunks);s=os.fstat(fd);z={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};assert a==z and count==a['size']
   if expected is not None:assert count==expected['bytes'] and h.hexdigest()==expected['sha256']
   bindings.append({'role':role,'path':str(path),'before':a,'after':z,'bytes':count,'sha256':h.hexdigest(),'read_EOF':True});return raw
  finally:os.close(fd)
 rawcp=read(CP,'prior_actions_reference_metadata_NEW_ALL210_relationships');d=json.loads(rawcp);member=pathlib.PurePosixPath(v['actual_report_member']['name']);assert not member.is_absolute() and '..' not in member.parts
 rawreport=read(A/member,'saved_report_NEW_include_relationship_metadata_NOT_oldinterpretation',v['actual_report_member']);report=json.loads(rawreport);assert str(report['run_id'])=='42311168556' and report['workflow_revision']=='67481dc3b8e828b5720e35d1543727ec60669360'
 groups=[x for x in report['observations'] if x['source_directory_reference']=='/usr/include'];assert len(groups)==1;group=groups[0];entries=group['entries'];assert len(entries)==210
 prior_nodes=[k for k in d if k.startswith('actions_') and k!='actions_include_entry_source_alias_intake_v1'];scalars=[]
 def walk(x,p):
  if isinstance(x,dict):
   for k,z in x.items():walk(z,p+[k])
  elif isinstance(x,list):
   for i,z in enumerate(x):walk(z,p+[i])
  elif isinstance(x,str):scalars.append((p,x))
 for key in prior_nodes:walk(d[key],[key])
 parent_matches=[{'JSON_location':p,'literal_scalar':text,'exact_scalar':text=='/usr/include'} for p,text in scalars if '/usr/include' in text]
 def savedtype(mode):
  return 'regular' if stat.S_ISREG(mode) else 'directory' if stat.S_ISDIR(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other'
 relationships=[];safe=[]
 for ordinal,entry in enumerate(entries):
  name=entry['name'];assert bytes.fromhex(entry['name_bytes_hex']).decode('utf-8','surrogateescape')==name;link=entry.get('separate_readlink_literal');needles=[('literal_entry_name',name),('original_name_bytes_hex',entry['name_bytes_hex'])]
  if link is not None:needles.append(('original_readlink_literal_UNEXPANDED',link))
  matches=[]
  for path,text in scalars:
   hits=[]
   for role,needle in needles:
    positions=[];start=0
    while True:
     at=text.find(needle,start)
     if at<0:break
     positions.append(at);start=at+len(needle)
    if positions:hits.append({'role':role,'exact_scalar':text==needle,'literal_substring_offsets':positions})
   if hits:matches.append({'JSON_location':path,'literal_scalar':text,'ALL_matches':hits})
  mode=entry['separate_lstat']['mode'];counts={role:sum(any(h['role']==role for h in x['ALL_matches']) for x in matches) for role,needle in needles}
  relationships.append({'ordinal':ordinal,'source_parent_reference':'/usr/include','original_complete_entry_record':entry,'ALL_prior_CP_matches':matches,'matching_scalar_counts':counts,'reference_NOT_lexically_joined_expanded_followed_resolved_or_executed':True})
  safe.append({'ordinal':ordinal,'source_parent_reference':'/usr/include','literal_entry_name':name,'original_name_bytes_hex':entry['name_bytes_hex'],'saved_mode':mode,'saved_type_derived_from_original_mode':savedtype(mode),'saved_uid':entry['separate_lstat']['uid'],'saved_gid':entry['separate_lstat']['gid'],'original_readlink_literal_UNEXPANDED':link,'original_raw_readlink_bytes_hex_NOT_saved':None,'matching_scalar_counts':counts,'reference_NOT_lexically_joined_expanded_followed_resolved_or_executed':True})
 totals={kind:sum(x['saved_type_derived_from_original_mode']==kind for x in safe) for kind in ['regular','directory','symlink','other']}
 result={'phase':'FIRST_ALL210_include_entry_source_alias_relationship_intake_COMPLETE_CONSUMED_NOT_admitted','source_run':42311168556,'source_commit':report['workflow_revision'],'source_parent_reference':'/usr/include','ALL210_relationships':relationships,'ALL_prior_parent_reference_matches':parent_matches,'prior_string_scalar_count':len(scalars),'prior_CP_actions_nodes':prior_nodes,'ALL210_safe_original_entry_metadata':safe,'derived_original_mode_type_counts_NOT_currentquery':totals,'ALL7_source_directory_references_preserved':report['source_directory_references'],'ALL11_positive_usr_entries_preserved':report['ALL11_positive_usr_entries'],'ALL4_explicit_pre_IO_exclusions_preserved':report['ALL4_explicit_pre_IO_exclusions'],'ALL9_historical_candidates_preserved':report['ALL9_historical_candidate_metadata'],'ALL20_source_relations_preserved':report['ALL20_reference_relations'],'ALL1124_original_report_rows_preserved_PRIVATE_NOT_old7set_reinterpretation':True,'qualification':'NEW ALL210 source/alias relationships, ALLnames/types/namehex/literalreadlinkstrings kept with no favorablelanguage-version-ABI/defaultcompiler selection. Parent/name remain separate, no lexicaljoin/pathguess/readlink expansion/follow/resolution. Missing originalreadlink bytehex NULL, neverreconstructed. ExistingCP/index ONLYlocate savedrecord/report; matching fullnewread binding is not oldjournalcomparison/currentSDK or installedheader-body/imagehash refresh. Scoped CPmatches/nonmatches NOTglobalabsence/newness/aliasidentity/bodycoverage/access/ownership/permission. No currentdirectory/headerbody/nativequery/recursivewalk/import/compilerexec/Actions/acquisition/model/archive/numerical/Source20-runtime adoption. ALL7sets1124rows/11source4exclusions9historical20relations/ALLmath-library-plugin-v6/4flavorsBOTHcfg/11installerBOTHLLVM/974rows remainprotected historicalmetadata NOTrevalidated. PointFD/read/stat/close NOTatomicABA-origin/globalactorFD/continuousofficialphysicalEX-crash admission. SetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.','separate_launcher_PID_pipe_EOF':None,'all_admission_flags':False}
 save('checkpoint-before-intake.json',rawcp);save('original-saved-report-PRIVATE.json',rawreport);save('metadata-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('ROOT-ALL210-source-alias-intake-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2)+'\n')
 summary={k:z for k,z in result.items() if k not in ['ALL210_relationships','ALL_prior_parent_reference_matches','prior_CP_actions_nodes','ALL210_safe_original_entry_metadata','ALL11_positive_usr_entries_preserved','ALL4_explicit_pre_IO_exclusions_preserved','ALL9_historical_candidates_preserved','ALL20_source_relations_preserved']}
 summary.update(ALL210_safe_original_entry_metadata=safe,parent_matching_scalar_count=len(parent_matches),entries_with_name_matches=sum(x['matching_scalar_counts']['literal_entry_name']>0 for x in safe),entries_without_name_matches=sum(x['matching_scalar_counts']['literal_entry_name']==0 for x in safe),entries_with_original_namehex_matches=sum(x['matching_scalar_counts']['original_name_bytes_hex']>0 for x in safe),ALL210_original_fields_retained_PRIVATE=True);save('ROOT-ALL210-intake-summary.json',json.dumps(summary,ensure_ascii=True,indent=2)+'\n')
 d['actions_include_entry_source_alias_intake_v1']={'directory':str(P),'intake_directory':str(I),**summary,'full_assessment':str(I/'ROOT-ALL210-source-alias-intake-PRIVATE.json'),'public_documentation_pending':True};d['active_turn_status']['next']='NEWALL210include sourcealiasrelationships COMPLETE_CONSUMED; no parent-name joins/bodyqueries/acquisition. Summarize/publish scope and all originaltypes/names/links before separatelydeclared input scope; CPnonmatches NOTnewness/aliases/bodycoverage/permission. AllsetupUNADMITTED/flagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True);lease.verify_identity()
