"""OWN file-backed procfs and synthetic pid handles, never Linux capability proof."""
import errno
import hashlib
import os
from pathlib import Path
import struct
import unittest
from unittest.mock import patch

from native_perf_mapped_images import MappedImageReader, match_mmap2
from native_perf_metadata import PerfMetadataReader

ROOT=Path(os.environ['CONNECTANUM_PERF_MAPPED_FIXTURES']).resolve()


def cookie(pid=300,start=900):
    return f'{pid} (fixture (name)) '+' '.join(['S','200']+['0']*17+[str(start)])+'\n'


class Handle:
    def __init__(self,pid):self.pid=pid;self.closed=False;self.alive=True
    def require_alive(self):
        if not self.alive:raise RuntimeError('synthetic pid exited')
    def close(self):self.closed=True


class MappedImagesTests(unittest.TestCase):
    def setUp(self):
        self.root=ROOT/self._testMethodName;self.root.mkdir(parents=True)
        self.proc=self.root/'proc';self.p=self.proc/'300';(self.p/'map_files').mkdir(parents=True)
        self.exe=self.root/'dart';self.native=self.root/'native.so'
        for p,body in [(self.exe,b'dart'),(self.native,b'native')]:
            p.write_bytes(b'\x7fELF\x02\x01'+bytes(58)+body);p.chmod(0o600)
        self.argv=(b'dart',b'--native-lib',os.fsencode(self.native),b'',b'\xff')
        (self.p/'stat').write_text(cookie());(self.p/'status').write_bytes(b'Uid:\t1001\t1001\t1001\t1001\nGid:\t1002\t1002\t1002\t1002\n')
        (self.p/'cmdline').write_bytes(b'\0'.join(self.argv)+b'\0');(self.p/'exe').symlink_to(self.exe)
        self.native_stat=self.native.stat();self.maps=self.mapline(0x1000,0x2000)+b'3000-4000 rw-p 00000000 00:00 0 [heap]\n'
        (self.p/'maps').write_bytes(self.maps);(self.p/'map_files'/'1000-2000').symlink_to(self.native)
        self.handles=[]
        def factory(pid):h=Handle(pid);self.handles.append(h);return h
        self.reader=MappedImageReader.fixture(self.proc,factory)
        self.args=dict(pid=300,start_ticks=900,executable_path=self.exe,executable_sha256=self.sha(self.exe),native_path=self.native,native_sha256=self.sha(self.native),expected_argv=self.argv,uid=1001,gid=1002)

    def sha(self,p):return hashlib.sha256(p.read_bytes()).hexdigest()

    def mapline(self,start,end,*,offset=0,path=b'/misleading\\012 (deleted)',perms=b'r-xp'):
        st=self.native.stat()
        return f'{start:x}-{end:x} '.encode()+perms+f' {offset:08x} {os.major(st.st_dev):x}:{os.minor(st.st_dev):x} {st.st_ino} '.encode()+path+b'\n'

    def observe(self,**changes):return self.reader.observe(**{**self.args,**changes})

    def test_positive_real_own_fds_synthetic_proc(self):
        r=self.observe();self.assertTrue(r['observed']);self.assertTrue(r['fixture_only']);self.assertFalse(r['capture_ready'])
        self.assertEqual(r['scope'],'mapped_backing_file_observation_only');self.assertEqual(r['process']['start_ticks'],'900')
        self.assertEqual(r['native_mappings'][0]['backing']['sha256'],self.sha(self.native));self.assertEqual(len(r['mappings']),2)
        self.assertEqual(r['mappings'][1]['classification'],'unclassified');self.assertTrue(self.handles[0].closed)
        self.assertEqual(r['native_mappings'][0]['mapping']['pathname_bytes_hex'],b'/misleading\\012 (deleted)'.hex())

    def test_page_rounded_extent_not_file_size(self):
        self.assertLess(self.native.stat().st_size,4096)
        self.assertTrue(self.observe()['observed'])

    def test_argv_exact_empty_and_nonutf8(self):
        self.assertTrue(self.observe()['observed'])
        self.assertFalse(self.observe(expected_argv=self.argv[:-1])['observed'])

    def test_wrong_start_uid_and_executable_refuse(self):
        for changes in [dict(start_ticks=901),dict(uid=0),dict(executable_sha256='a'*64)]:
            r=self.observe(**changes);self.assertFalse(r['observed']);self.assertTrue(r['raw_evidence']);self.assertFalse(r['capture_ready'])

    def test_pathname_only_cannot_select_native(self):
        st=self.native.stat();(self.p/'maps').write_bytes(self.maps.replace(str(st.st_ino).encode(),str(st.st_ino+1).encode()))
        r=self.observe();self.assertFalse(r['observed']);self.assertIn('no executable native mapping',r['error']['reason'])

    def test_same_bytes_different_backing_inode_refused(self):
        other=self.root/'other';other.write_bytes(self.native.read_bytes());other.chmod(0o600)
        target=self.p/'map_files'/'1000-2000';target.unlink();target.symlink_to(other)
        r=self.observe();self.assertFalse(r['observed']);self.assertIn('backing identity',r['error']['reason'])

    def test_permission_denied_terminal_retains_errno(self):
        real=os.open
        def denied(path,*args,**kwargs):
            if 'map_files' in str(path):raise PermissionError(errno.EACCES,'synthetic permission refusal')
            return real(path,*args,**kwargs)
        with patch('native_perf_mapped_images.os.open',side_effect=denied):r=self.observe()
        self.assertFalse(r['observed']);self.assertEqual(r['error']['errno'],errno.EACCES)
        self.assertTrue(any(x.get('errno')==errno.EACCES for x in r['raw_evidence']))

    def test_no_global_pid_scan_or_environ(self):
        with patch('native_perf_mapped_images.os.listdir',side_effect=AssertionError('global scan forbidden')):r=self.observe()
        self.assertTrue(r['observed']);self.assertFalse(any('environ' in x.get('path','') for x in r['raw_evidence']))

    def test_maps_changed_after_first_sweep_refused(self):
        original=self.reader._mapped_fd;done=False
        def changed(*args,**kwargs):
            nonlocal done
            value=original(*args,**kwargs)
            if not done:(self.p/'maps').write_bytes(self.maps+b'5000-6000 rw-p 0 00:00 0\n');done=True
            return value
        with patch.object(self.reader,'_mapped_fd',side_effect=changed):r=self.observe()
        self.assertFalse(r['observed']);self.assertIn('maps changed',r['error']['reason'])

    def test_late_map_link_replacement_refused_even_same_maps(self):
        other=self.root/'other';other.write_bytes(self.native.read_bytes());other.chmod(0o600)
        original=self.reader._mapped_fd;done=False
        def replaced(*args,**kwargs):
            nonlocal done
            value=original(*args,**kwargs)
            if not done:
                target=self.p/'map_files'/'1000-2000';target.unlink();target.symlink_to(other);done=True
            return value
        with patch.object(self.reader,'_mapped_fd',side_effect=replaced):r=self.observe()
        self.assertFalse(r['observed']);self.assertIn('backing identity',r['error']['reason'])

    def test_all_native_candidates_required(self):
        (self.p/'maps').write_bytes(self.mapline(0x1000,0x2000)+self.mapline(0x5000,0x6000))
        r=self.observe();self.assertFalse(r['observed']);self.assertEqual(r['error']['errno'],errno.ENOENT)

    def test_hash_short_reads_accumulated(self):
        real=os.pread
        with patch('native_perf_mapped_images.os.pread',side_effect=lambda fd,n,pos:real(fd,min(n,3),pos)):r=self.observe()
        self.assertTrue(r['observed'])

    def test_maps_malformed_retains_raw(self):
        (self.p/'maps').write_bytes(b'malformed\n')
        r=self.observe();self.assertFalse(r['observed']);self.assertTrue(any(x.get('data_base64')=='bWFsZm9ybWVkCg==' for x in r['raw_evidence']))

    def test_pid_exits_naturally_during_observation_refused(self):
        original=self.reader._mapped_fd
        def exited(*args,**kwargs):v=original(*args,**kwargs);self.handles[-1].alive=False;return v
        with patch.object(self.reader,'_mapped_fd',side_effect=exited):r=self.observe()
        self.assertFalse(r['observed']);self.assertTrue(self.handles[0].closed)

    def test_strict_input_types_before_any_proc_io(self):
        with patch.object(self.reader,'_read',side_effect=AssertionError('must not reach IO')):
            for changes in [dict(pid=True),dict(start_ticks=False),dict(uid=True),dict(expected_argv=('dart',)),dict(native_sha256='A'*64)]:
                r=self.observe(**changes);self.assertFalse(r['observed']);self.assertFalse(r['raw_evidence'])

    def test_match_real_decoder_mmap2_and_separate_context(self):
        from test_native_perf_metadata import image,record,sid
        st=self.native.stat();payload=struct.pack('<IIQQQIIQQII',300,301,4096,4096,0,os.major(st.st_dev),os.minor(st.st_dev),st.st_ino,0,5,2)+b'/different\0'+sid(pid=200)
        p=self.root/'synthetic.perf';p.write_bytes(image(record(10,payload)));p.chmod(0o600)
        with PerfMetadataReader(p) as decoder:rows=list(decoder.records());decoder.summary()
        report=self.observe();match=match_mmap2(rows[0],report,process_start_ticks='900')
        self.assertTrue(match['candidate_match']);self.assertFalse(match['capture_ready'])
        self.assertFalse(match_mmap2(rows[0],report,process_start_ticks='901')['candidate_match'])
        rows[0]['decoded'].pop('inode');self.assertFalse(match_mmap2(rows[0],report,process_start_ticks='900')['candidate_match'])

    def test_close_fault_preserves_identity_primary(self):
        real=os.close
        def uncertain(fd):real(fd);raise OSError(5,'synthetic close error')
        with patch('native_perf_mapped_images.os.close',side_effect=uncertain):r=self.observe(start_ticks=901)
        self.assertFalse(r['observed']);self.assertIn('process instance',r['error']['reason']);self.assertTrue(r['cleanup_errors'])


if __name__=='__main__':unittest.main()
