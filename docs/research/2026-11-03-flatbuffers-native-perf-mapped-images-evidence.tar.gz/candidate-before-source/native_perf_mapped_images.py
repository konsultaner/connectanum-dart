"""Direct process/mapped backing-file observations, never capture admission.

Live procfs access is an actual required operation, not inferred from UID0.
Fixture procfs and pid handles are explicitly synthetic. Private/COW code pages
are not read. Before/after observations do not establish atomicity or global ABA.
"""
from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path
import re
import select
import stat
import sys
import time

from native_perf_guard import GuardError, parse_process_stat


_MAP = re.compile(rb'([0-9a-f]+)-([0-9a-f]+) ([r-][w-][x-][ps]) ([0-9a-f]+) ([0-9a-f]+):([0-9a-f]+) ([0-9]+)(?: +(.*))?')
_DIGEST = re.compile(r'[0-9a-f]{64}')


def _number(value, minimum=0):
    return type(value) is int and minimum <= value < 2**64


def _identity(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mode, st.st_uid,
            st.st_gid, st.st_mtime_ns, st.st_ctime_ns)


def _error(exc):
    return {'type': type(exc).__name__, 'errno': getattr(exc, 'errno', None), 'reason': str(exc)}


class _PidHandle:
    def __init__(self, pid):
        if not hasattr(os, 'pidfd_open'):
            raise GuardError('pidfd support required')
        self.fd = os.pidfd_open(pid, 0)
        os.set_inheritable(self.fd, False)

    def require_alive(self):
        if select.select([self.fd], [], [], 0)[0]:
            raise GuardError('scoped process exited')

    def close(self):
        fd, self.fd = self.fd, None
        if fd is not None:
            os.close(fd)


class MappedImageReader:
    MAX_MAPS = 8192
    MAX_NATIVE_MAPS = 64
    MAX_EVIDENCE_BYTES = 8*1024**2
    MAX_IMAGE_BYTES = 512*1024**2
    MAX_HASH_BYTES = 4*1024**3

    def __init__(self, root, fixture_only, handle_factory):
        self.root = Path(root)
        self._fixture_only = fixture_only
        self._handle_factory = handle_factory

    @classmethod
    def live(cls):
        if sys.platform != 'linux' or os.geteuid() != 0:
            raise GuardError('live mapped-file witness requires privileged Linux procfs access')
        return cls(Path('/proc'), False, _PidHandle)

    @classmethod
    def fixture(cls, root, handle_factory):
        return cls(Path(root).resolve(strict=True), True, handle_factory)

    def _read(self, relative, maximum=131072):
        event = {'operation': 'read', 'path': str(relative)}
        self.evidence.append(event)
        raw = bytearray()
        fd = None
        try:
            fd = os.open(self.root/relative, os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
            self._fds.add(fd)
            while len(raw) <= maximum:
                chunk = os.read(fd, min(65536, maximum+1-len(raw)))
                if not chunk:
                    break
                raw.extend(chunk)
            self._evidence_bytes += len(raw)
            if len(raw) > maximum or self._evidence_bytes > self.MAX_EVIDENCE_BYTES:
                raise GuardError('bounded procfs evidence limit')
            return bytes(raw)
        except BaseException as exc:
            event['error'] = _error(exc)
            if isinstance(exc, OSError):
                event['errno'] = exc.errno
            raise
        finally:
            event['data_base64'] = base64.b64encode(raw).decode('ascii')
            if fd is not None:
                self._close_fd(fd)

    def _close_fd(self, fd):
        if fd in self._fds:
            self._fds.remove(fd)
            os.close(fd)

    def _open(self, path, *, follow):
        event = {'operation': 'open_backing' if follow else 'open_declared', 'path': str(path)}
        self.evidence.append(event)
        try:
            fd = os.open(path, os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC|(0 if follow else os.O_NOFOLLOW))
            self._fds.add(fd)
            os.set_inheritable(fd, False)
            return fd
        except BaseException as exc:
            event['error'] = _error(exc)
            if isinstance(exc, OSError):
                event['errno'] = exc.errno
            raise

    def _hash_fd(self, fd, expected=None):
        event = {'operation': 'hash_fd', 'fd': fd, 'bytes_read': 0}
        self.evidence.append(event)
        digest = hashlib.sha256()
        try:
            before = os.fstat(fd)
            if (not stat.S_ISREG(before.st_mode) or before.st_mode & 0o6022
                    or before.st_uid not in {0, os.getuid()}
                    or not 64 <= before.st_size <= self.MAX_IMAGE_BYTES):
                raise GuardError('backing object is not bounded owned regular image')
            if expected is not None and _identity(before) != expected['identity']:
                raise GuardError('backing identity differs from pinned artifact')
            pos = 0
            magic = bytearray()
            while pos < before.st_size:
                chunk = os.pread(fd, min(1024**2, before.st_size-pos), pos)
                if not chunk:
                    raise GuardError('short image EOF')
                pos += len(chunk)
                self._hash_bytes += len(chunk)
                digest.update(chunk)
                if len(magic) < 6:
                    magic.extend(chunk[:6-len(magic)])
                event['bytes_read'] = pos
                event['partial_sha256'] = digest.hexdigest()
                if self._hash_bytes > self.MAX_HASH_BYTES:
                    raise GuardError('bounded cumulative image hash limit')
            if bytes(magic) != b'\x7fELF\x02\x01':
                raise GuardError('not little-endian ELF64 backing file')
            identity, sha = _identity(before), digest.hexdigest()
            if _identity(os.fstat(fd)) != identity:
                raise GuardError('backing changed while hashing')
            if expected is not None and sha != expected['sha256']:
                raise GuardError('backing bytes differ from pinned artifact')
            event['sha256'] = sha
            return {'identity': identity, 'sha256': sha, 'size': before.st_size,
                    'device_major': os.major(before.st_dev), 'device_minor': os.minor(before.st_dev), 'inode': str(before.st_ino)}
        except BaseException as exc:
            event['error'] = _error(exc)
            raise

    def _pin(self, path, expected_sha):
        path = Path(path)
        if not path.is_absolute() or path != path.resolve(strict=True):
            raise GuardError('artifact path must be canonical')
        before = path.lstat()
        fd = self._open(path, follow=False)
        obj = self._hash_fd(fd)
        if obj['identity'] != _identity(before) or obj['sha256'] != expected_sha:
            raise GuardError('pinned artifact bytes or identity differ')
        return fd, obj, path

    def _process(self, pid, start, argv, uid, gid, executable):
        base = Path(str(pid))
        process = parse_process_stat(self._read(base/'stat').decode('ascii'))
        if process.pid != pid or process.start_ticks != start:
            raise GuardError('process instance differs')
        status = self._read(base/'status')
        for field, expected in [(b'Uid:', uid), (b'Gid:', gid)]:
            rows = [line.split()[1:] for line in status.splitlines() if line.startswith(field)]
            if len(rows) != 1 or len(rows[0]) != 4 or any(v != str(expected).encode() for v in rows[0]):
                raise GuardError('process credentials differ')
        command = self._read(base/'cmdline')
        if command != b'\0'.join(argv)+b'\0':
            raise GuardError('process argv bytes differ')
        fd = self._open(self.root/base/'exe', follow=True)
        self._hash_fd(fd, executable)
        self._close_fd(fd)
        return {'pid': pid, 'parent_pid': process.parent_pid, 'start_ticks': str(process.start_ticks),
                'uid': uid, 'gid': gid, 'argv_hex': [v.hex() for v in argv], 'executable_sha256': executable['sha256']}

    def _maps(self, raw):
        lines = raw.splitlines()
        if len(lines) > self.MAX_MAPS or not raw.endswith(b'\n'):
            raise GuardError('maps count or termination invalid')
        result = []
        for line in lines:
            m = _MAP.fullmatch(line)
            if m is None:
                raise GuardError('malformed maps record')
            first, last, perms, offset, major, minor, inode, pathname = m.groups()
            start, end, off, dev1, dev2, ino = (int(first,16),int(last,16),int(offset,16),int(major,16),int(minor,16),int(inode))
            if (not 0 <= start < end <= 2**64 or not 0 <= off < 2**64
                    or not 0 <= ino < 2**64 or dev1 >= 2**32 or dev2 >= 2**32):
                raise GuardError('maps numeric range invalid')
            result.append({'start': str(start), 'end': str(end), 'offset': str(off),
                           'perms': perms.decode('ascii'), 'device_major': dev1, 'device_minor': dev2,
                           'inode': str(ino), 'pathname_bytes_hex': (pathname or b'').hex(),
                           'classification': 'unclassified'})
        return result

    def _mapped_fd(self, pid, mapping, native):
        path = self.root/str(pid)/'map_files'/f"{int(mapping['start']):x}-{int(mapping['end']):x}"
        event = {'operation': 'readlink', 'path': str(path)}
        self.evidence.append(event)
        try:
            event['target_bytes_hex'] = os.readlink(os.fsencode(path)).hex()
        except OSError as exc:
            event['error'] = _error(exc)
            event['errno'] = exc.errno
            raise
        fd = self._open(path, follow=True)
        obj = self._hash_fd(fd, native)
        if int(mapping['offset']) >= obj['size']:
            raise GuardError('native mapping offset beyond backing file')
        return fd, obj

    def observe(self, *, pid, start_ticks, executable_path, executable_sha256,
                native_path, native_sha256, expected_argv, uid, gid):
        self.evidence, self._fds = [], set()
        self._evidence_bytes = self._hash_bytes = 0
        report = {'scope': 'mapped_backing_file_observation_only', 'capture_ready': False,
                  'fixture_only': self._fixture_only, 'observed': False,
                  'raw_evidence': self.evidence, 'cleanup_errors': []}
        handle = None
        try:
            if (not _number(pid,1) or not _number(start_ticks,1) or not _number(uid) or not _number(gid)
                    or not isinstance(executable_sha256,str) or _DIGEST.fullmatch(executable_sha256) is None
                    or not isinstance(native_sha256,str) or _DIGEST.fullmatch(native_sha256) is None
                    or type(expected_argv) is not tuple or not expected_argv or not expected_argv[0]
                    or any(type(arg) is not bytes or b'\0' in arg for arg in expected_argv)):
                raise GuardError('invalid exact observation inputs')
            report['monotonic_begin_ns'] = str(time.monotonic_ns())
            handle = self._handle_factory(pid)
            handle.require_alive()
            executable_fd, executable, executable_name = self._pin(executable_path, executable_sha256)
            native_fd, native, native_name = self._pin(native_path, native_sha256)
            process = self._process(pid, start_ticks, expected_argv, uid, gid, executable)
            raw_maps = self._read(Path(str(pid))/'maps',1024**2)
            mappings = self._maps(raw_maps)
            report.update(process=process, mappings=mappings, native_mappings=[])
            chosen = [m for m in mappings if 'x' in m['perms'] and m['inode'] == native['inode']
                      and (m['device_major'],m['device_minor']) == (native['device_major'],native['device_minor'])]
            if not chosen:
                raise GuardError('no executable native mapping matches declared backing identity')
            if len(chosen) > self.MAX_NATIVE_MAPS:
                raise GuardError('native mapping count limit')
            retained = []
            for mapping in chosen:
                fd, backing = self._mapped_fd(pid, mapping, native)
                retained.append((mapping, fd))
                report['native_mappings'].append({'mapping': dict(mapping), 'backing': backing})
            if self._read(Path(str(pid))/'maps',1024**2) != raw_maps:
                raise GuardError('maps changed during observation')
            for mapping, fd in retained:
                self._hash_fd(fd, native)
                second, _ = self._mapped_fd(pid, mapping, native)
                self._close_fd(second)
            if self._process(pid,start_ticks,expected_argv,uid,gid,executable) != process:
                raise GuardError('process observation changed')
            if self._read(Path(str(pid))/'maps',1024**2) != raw_maps:
                raise GuardError('maps changed after backing sweep')
            for fd, expected, name in [(executable_fd,executable,executable_name),(native_fd,native,native_name)]:
                self._hash_fd(fd,expected)
                if _identity(name.lstat()) != expected['identity']:
                    raise GuardError('declared artifact path changed')
            handle.require_alive()
            report.update(observed=True, monotonic_end_ns=str(time.monotonic_ns()),
                          limitations=['backing file bytes only, not private/COW executable memory pages',
                            'not atomic, global closed-world image ownership, role identity or source/compiled closure',
                            'perf clock equality, live transport authenticity and real kernel capability unproved'])
        except BaseException as exc:
            report['error'] = _error(exc)
        finally:
            for fd in list(self._fds):
                try:
                    self._close_fd(fd)
                except BaseException as exc:
                    report['cleanup_errors'].append(_error(exc))
            if handle is not None:
                try:
                    handle.close()
                except BaseException as exc:
                    report['cleanup_errors'].append(_error(exc))
            if report['cleanup_errors']:
                report['observed'] = False
        return report


def match_mmap2(record, observation, *, process_start_ticks):
    """Candidate field join only. No timestamp, role or trusted-admission claim."""
    result = {'scope': 'mmap2_backing_candidate_only', 'capture_ready': False,
              'candidate_match': False, 'reason': 'identity_or_layout_unmatched'}
    if (not isinstance(observation,dict) or observation.get('observed') is not True
            or observation.get('scope') != 'mapped_backing_file_observation_only'
            or not isinstance(record,dict) or type(record.get('type')) is not int or record['type'] != 10
            or record.get('issues') != [] or not isinstance(record.get('decoded'),dict)):
        return result
    process = observation.get('process', {})
    data = record['decoded']
    if (type(process_start_ticks) is not str or process_start_ticks != process.get('start_ticks')
            or type(data.get('pid')) is not int or data['pid'] != process.get('pid')
            or 'inode' not in data):
        return result
    for entry in observation.get('native_mappings', []):
        m = entry['mapping']
        if (data.get('addr') == m['start'] and data.get('length') == str(int(m['end'])-int(m['start']))
                and data.get('pgoff') == m['offset'] and data.get('inode') == m['inode']
                and (data.get('device_major'),data.get('device_minor')) == (m['device_major'],m['device_minor'])):
            result.update(candidate_match=True, reason='backing_fields_match_only',
                          fixture_only=observation['fixture_only'], backing_sha256=entry['backing']['sha256'])
            break
    return result
