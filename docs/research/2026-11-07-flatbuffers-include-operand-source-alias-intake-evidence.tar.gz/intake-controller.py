import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0753_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');OLD=B/'2026-11-07-actions-include-regular-interiors-v1/FIRST-physical-directive-reader-v1';P=B/'2026-11-07-actions-include-operand-source-alias-intake-v1'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 sources=[
 {'role':'NEW_ALL576_operand_source_relationships','path':str(OLD/'ALL160-physical-directive-candidates-PRIVATE.json'),'bytes':8971297,'sha256':'23d0632a95dd9f9f26582c3849f37fbc5b7de58ad07470146416a0a71ce94dde','range':[0,8971297]},
 {'role':'original_ALL210_separate_basename_namehex_metadata_NOT_currentquery','path':str(OLD/'ALL160-exact-body-declaration-BEFORE-body-IO.json'),'bytes':440141,'sha256':'f900f8e7c61f96b1e1eabdd8268f06ec6b2076ff1ec8c5babe539779e9182834','range':[0,440141]}]
 declaration={'question':'FIRST ALL576 physical include-operand source/alias relationship intake vs ALL210original separate basename/namehex fields; exact raw byte equality ONLY, no alias identity inference/dedup/normalization/pathbasename extraction/join/resolution/filter','sources_and_bounded_ranges_BEFORE_IO':sources,'ALL576':'ALL575raw-delimited+1macro-empty-other preserved originalorder/rawoperand/offset/fullphysicalrow/continuationflags/effective_include_requestNULL; macro has no fabricated rawname or zero comparison outcome','ALL210':'ALLnames-namehex-modes-types-UIDGID-links/originalseparateparentnameflags/newlexicalepochs preserved,49dirsDEFERRED noquery-recursion,ncurses.h-curses.h UNEXPANDED-UNFOLLOWED/rawreadlinkhexNOTsavedNULL','CPnonmatches':'NOTabsence/newness/bodycoverage/alias/access/permission','not_oldquestion':'New saved metadata relationships only; no body reparse/header reopen/SDKhashquery/Actions/acquisition/archive/numerical/model replay, Source20/runtime adoption or cleanup','all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def state(fd):
  s=os.fstat(fd);return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']}
 def bound(x):
  row={'role':x['role'],'path':x['path'],'bounded_range':x['range'],'before_open_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};bindings.append(row);fd=None;primary=None;raw=None
  try:
   fd=os.open(x['path'],os.O_RDONLY|os.O_NOFOLLOW);row['open_return_fd']=fd;before=state(fd);row['before']=before;assert stat.S_ISREG(before['st_mode']) and before['st_size']==x['bytes']
   pieces=[];h=hashlib.sha256();done=0
   while done<x['bytes']:
    chunk=os.pread(fd,min(65536,x['bytes']-done),done)
    if not chunk:raise RuntimeError('Unexpected savedmetadata EOF; partial relationships quarantined')
    pieces.append(chunk);done+=len(chunk);h.update(chunk)
   assert os.pread(fd,1,done)==b''
   row.update(bytes=done,sha256=h.hexdigest(),read_EOF=True);assert h.hexdigest()==x['sha256'];after=state(fd);row['after']=after;assert before==after;raw=b''.join(pieces)
  except BaseException as e:primary=e;row['primary_error']={'kind':type(e).__name__,'text':str(e)}
  if fd is not None:
   try:os.close(fd);row['close_return_fd']=fd
   except BaseException as e:
    row['close_error']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
  if primary is not None:raise primary
  return raw
 try:
  rawresult=bound(sources[0]);rawdecl=bound(sources[1]);original=json.loads(rawresult);beforedecl=json.loads(rawdecl);save('original-semantic-result-bound-PRIVATE.json',rawresult);save('original-before-body-declaration-bound-PRIVATE.json',rawdecl)
  ledgers=beforedecl['preserved_original_metadata_NOT_revalidated'];entries=ledgers['ALL210_include_original_safe_entry_metadata'];operands=original['ALL_ordered_include_operand_candidates'];assert len(entries)==210 and len(operands)==576
  assert original['summary']['source_run']==42350609933 and original['summary']['all_admission_flags'] is False
  for entry in entries:assert bytes.fromhex(entry['original_name_bytes_hex']).decode('utf-8','surrogateescape')==entry['literal_entry_name']
  physical={}
  for body in original['ALL160']:
   for row in body['ALL_ordered_physical_hash_candidates']:
    if 'include_operand_candidate' in row:
     key=(body['source_reference'],row['physical_line_1based'],row['offset']);assert key not in physical;physical[key]=row
  assert len(physical)==576
  relationships=[];entrycounts=[0]*210;forms={};compared=matched=unmatched=unknown=0;totalliteralrelations=0;matched_types={}
  for ordinal,operand in enumerate(operands):
   key=(operand['source_reference'],operand['physical_line_1based'],operand['offset']);parent=physical[key];assert parent['include_operand_candidate']==operand and operand['effective_include_request'] is None
   matches=[];namehex=operand.get('raw_name_hex');forms[operand['lexical_form']]=forms.get(operand['lexical_form'],0)+1
   if namehex is not None:
    name=bytes.fromhex(namehex);compared+=1
    for i,entry in enumerate(entries):
     if name==bytes.fromhex(entry['original_name_bytes_hex']):
      matches.append({'original_entry_ordinal':entry['ordinal'],'original_complete_safe_metadata':entry,'raw_byte_equality_ONLY_NOT_alias_identity':True});entrycounts[i]+=1;t=entry['saved_type_derived_from_original_mode'];matched_types[t]=matched_types.get(t,0)+1
    matched+=int(bool(matches));unmatched+=int(not matches);totalliteralrelations+=len(matches);outcome='literal_original_basename_byte_matches' if matches else 'no_literal_original_basename_byte_match_NOTabsence_newness_alias_bodycoverage_permission'
   else:unknown+=1;outcome='NO_literal_name_saved_in_macro_empty_other_form_comparison_NOT_performed'
   relationships.append({'ordinal':ordinal,'original_complete_operand_candidate':operand,'original_complete_physical_candidate':parent,'original_prior_physical_backslash_newline':parent['previous_physical_line_has_backslash_newline'],'original_current_physical_backslash_newline':parent['this_physical_line_has_backslash_newline'],'raw_name_bytes_hex_or_None':namehex,'comparison_outcome':outcome,'literal_match_count':len(matches) if namehex is not None else None,'ALL_literal_original_basename_matches':matches,'effective_include_request':None,'alias_identity':None,'resolution_or_execution_permission':None})
  assert len(relationships)==576 and compared==575 and unknown==1 and matched+unmatched==575 and forms=={'raw_delimited_candidate':575,'empty_or_macro_or_other_raw_form':1}
  allentrycounts=[{'original_complete_safe_metadata':entry,'ALL576_raw_operand_literal_match_count':n} for entry,n in zip(entries,entrycounts)]
  qualification='NEW ALL576 saved operand-to-original210basename exact-byte relationships ONLY;575raw-delimited compared,1macro-empty-other lacks raw_name and is unperformed/NULL not zero. All literal matches/nonmatches/duplicates retained, NOalias dedup/favorable language-version-ABI/defaultcompiler filter. Parent/name fields remain separate and originalsource-lexicalepochs unchanged; no path splitting/joining/normalization/include resolution/effectivecondition/preprocessing/import/compile/SDKquery/Actions/build/numerical/Source20-runtime adoption. Count-match NOTaliasidentity/newness/absence/bodycoverage/access/ownership/permission. ALL210 fullsafe metadata/namehex/modes/types/UIDGID/linkstrings/49dirsDEFERRED/ncurses.h-curses.h UNEXPANDED-UNFOLLOWED/readlinkhexNOTsavedNULL/allpriorledgers protectedNOTrevalidated. New readsameFD-countSHA-stat-close metadata binding NOTatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.'
  summary={'phase':'FIRST_ALL576_include_operand_source_alias_relationships_COMPLETE_CONSUMED_NOT_admitted','source_run':42350609933,'source_commit':original['summary']['source_commit'],'ALL576_count':576,'raw_delimited_compared':compared,'macro_empty_other_unperformed':unknown,'literal_matched_candidate_count':matched,'literal_unmatched_candidate_count':unmatched,'ALL_literal_match_relations':totalliteralrelations,'literal_match_relation_original_type_counts':matched_types,'ALL210_entries_with_raw_operand_name_match':sum(x>0 for x in entrycounts),'ALL210_entries_without_raw_operand_name_match':sum(x==0 for x in entrycounts),'raw_operand_form_counts':forms,'read_binding_count':len(bindings),'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':qualification}
  result={'summary':summary,'ALL576_relationships':relationships,'ALL210_original_metadata_match_counts':allentrycounts,'preserved_original_metadata_NOT_revalidated':ledgers}
  save('ROOT-FIRST-ALL576-source-alias-intake-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2)+'\n');save('FIRST-ALL576-summary.json',json.dumps(summary,indent=2)+'\n');save('FIRST-metadata-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2))
  # advisory selection keeps all210 rows; no body/parser replay or source filtering
  selection={'summary':summary,'ALL210_name_match_count_rows':[{'ordinal':e['ordinal'],'name':e['literal_entry_name'],'original_type':e['saved_type_derived_from_original_mode'],'literal_raw_operand_matches':n} for e,n in zip(entries,entrycounts)],'ALL_unperformed_macro_empty_other_original_records':[r for r in relationships if r['literal_match_count'] is None]};save('NEW-ALL576-derived-advisory-selection.json',json.dumps(selection,ensure_ascii=True,indent=2))
  cp=B/'current-task-checkpoint.json';cpraw=cp.read_bytes();save('checkpoint-before-intake.json',cpraw);d=json.loads(cpraw);d['actions_include_operand_source_alias_intake_v1']={'directory':str(P),**summary,'full_assessment':str(P/'ROOT-FIRST-ALL576-source-alias-intake-PRIVATE.json'),'public_documentation_pending':True};d['active_turn_status']['next']='FIRST ALL576 operand-source/alias literal byte relationships COMPLETE_CONSUMED; summarize NEW data/publish, no oldbody/grammar/model/query/hash/Actions/archive replay or effective-dependency/defaultsysroot/ABI inference. ALL49dirs deferred/ncurses.h-curses.h unexpanded/unfollowed/readlinkhexNULL/allpriorledgers protected; allsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True);lease.verify_identity()
 except BaseException as e:save('failure-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('failure.json',json.dumps({'kind':type(e).__name__,'text':str(e),'partial_unknowns_quarantined':True},indent=2));raise
