import sys,pathlib,json,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owner-error');D=pathlib.Path('/tmp/connectanum-native-perf-owner-error-design')
 root=pathlib.Path('/tmp/connectanum-native-perf-owner-error-root-assessment')
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 final=json.loads((P/'review-control-hashes.json').read_text())
 invariants=json.loads((root/'structural-qualification.json').read_text())
 stages={}
 for stage in ['before','implemented','review-control']:
  raw=(P/(stage+'-tests.json')).read_bytes();data=json.loads(raw)
  stages[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],report=stage+'-tests.json',sha256=sha(raw))
 models={name:json.loads((D/(name+'-finish.json')).read_text()) for name in ['tests','review']}
 models['history_freeze_summary']=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design/summary-finish.json').read_text())
 commands=[json.loads((root/('git-'+str(i)+'.json')).read_text()) for i in range(4)]
 branch=(root/'0-stdout.bin').read_text().strip();head=(root/'1-stdout.bin').read_text().strip()
 status=(root/'2-stdout.bin').read_text();diff=(root/'3-stdout.bin').read_bytes()
 assert set(status.splitlines())=={'?? '+rel for rel in final if rel.startswith('tool/')} and not diff
 fixtures=None
 put(root/'assessment-administrative-failure.json',dict(error='Wrong status-prefix assertion expected M while all20 helpers are untracked ??',after_AST_and_fullaffected_saved=True,after_four_Git_statuses_both_streams_saved=True,no_missing_Git_data=True,fixture_index_computed_not_serialized=None,no_AST_Git_test_model_rerun=True,no_fixture_index_reconstruction=True))
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='owner exception type-label prerequisite; not historical inventory or physical closure',
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],hashes=final,
  stages=stages,counts_qualification='BEFORE5FAIL, no missing APIs or RAM/SDK/canonical defect count. Implemented8PASS=5new+3required existing owner callers. Review-control1PASS separate after source unchanged; six new declared methods, not combined9/fullfinal9/canonical.',
  root_source_assessment='ROOT checked whole affected final methods/test classes plus byteexact AST/source invariants. Exact private first/call/join errors precede native label. Normal labels remain native class names. Owner first-object condition prevents later type-name publication from replacing earliest. Existing busy/startsettled/join/schedule/emit/freeze/aux predicates unchanged.',
  raw_limits='Five NEW controls use SYNTHETIC unregistered owner/operation and ACTUAL finite Python Threads, no Popen/SDK child. Constructor factory raises BEFORE producer or child; later wait has synthetic earlier primary and synthetic operation. Thread.join actually returns before injected fault; source preserves unknown join and retained exact handle, unit teardown naturally joins same thread, never source recovery. Setup Thread constructor seam mocked BEFORE any worker. Nonscalar metaclass native name hook is rejected. New views/lifecycle/private identity booleans/hook occurrences/uncaught errors type labels saved before assertions. Thread status has no signed process exit code. Three required existing owner callers use old finite Fixture paths; legacy setup/API/child/FD returns not all systematically serialized, no reconstruction/fullclosure claim. Actual officialEX spans known finite controls and legacy known children; private fixture cleanup never live release or retag. No raw concurrent observer/global atomicity/auth/writer/descendant proof.',
  models=models,ROOT_model_qualification='Gemma26124 prior history-freeze orientation invents history-only snapshot/owner_id details; ROOT corrects current+Aux-only inventory and independently selects prerequisite. Qwen27398 suggests ordinary/mock-only errors and joins; ROOT uses metaclass and real finite Thread/join controls. Qwen27664 P1 recommends restoring type(error).__name__ FALSE for required hook-free boundary; BEFORE5FAIL/current8PASS prove counterexample. P2 recommends trusting bounded join return FALSE: join(timeout) returns None with worker alive; NEW finite real-thread1PASS demonstrates retained handle/false joined until natural completion. No inferred leaks/latency/snapshot global atomicity from histories. Selected source review BEFORE final review test, source unchanged; ROOT final wholeaffected checks, not model full-current-source approval.',
  administrative_failures='Initial controller NameError testsCandidate after 2 preeditGit0+saved streams/original snapshot, before source mutation/test/worker. Empty candidate created by openx before NameError. Continuation FileExistsError preserves empty candidate, again before source/test/worker. Distinct v2candidate/actual controller succeeds. Full failed scripts saved; initial toolreturns chat and one exact toolreturn retained, second error summarized not reconstructed. ROOT assessment expected M rather than actual untracked ?? after complete AST/affected text and four Git0/signedstatus/both streams saved; data-only finalizer accepts retained actual ??, no Git/AST/test/model rerun. Computed fixture index not serialized before assertion remains NULL, raw fixtures retained, no reconstruction. Initial resume checkpoint/docs read used raw administrative shell outside officiallease; later source/model/test/publication use official leases; no execution waiver inferred.',
  invariants=invariants,fixture_report_index=fixtures,posttest_Git=commands,branch=branch,HEAD=head,
  all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,native_output_instructionclosure_not_proved=True,no_source_commit_push_adoption_strictdispatch=True,
  remaining='Independent frozen historical inventory/continuation/transitive genericFD/auditpartialactors/unknownstarts/sharedjournal-historicalwriter/interpreter-delegate-descendant/fullphysical officialEX controller incomplete. Parent-writer metadata and other unrelated error labels outside scoped fix. Existing freeze owner_emit_attempted and oldaux predicates unchanged. No status/EOF/join/closedobject/emptyledger/sourcefile data grants EXrelease/admission. Original PATH SDK/bootstrap/first3locks hiddenconfigs/current20canonical/newsourcepackage/OWN native-driver-staticRLIB/compiler-tool-kernel+actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage and ROOT-qualified immutable COMPLETEadmission required before diagnosticdata.',
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  no_actual_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,build_floor_bytes=12*1024**3,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['owner_error_component']=dict(cache=str(P),design=str(D),root_assessment=str(root),assessment=str(root/'assessment.json'),
  source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],stages={k:{x:s[x] for x in ['tests','failures','errors']} for k,s in stages.items()},
  publication_pending=True,all_known_own_model_test_calls_terminal=True,no_canonical_admission_or_history_freeze=True,never_repeat_unchanged=True)
 n['last_free_bytes']=assessment['free_after'];v['active_turn_status']='owner_error_ROOT_qualified_publication_pending'
 c.write_text(json.dumps(v,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],stages=n['owner_error_component']['stages'],free=assessment['free_after'])))
