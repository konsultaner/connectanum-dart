import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-owner-error-design')
 path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py');raw=path.read_bytes()
 source_sha=hashlib.sha256(raw).hexdigest()
 baseline=json.loads(pathlib.Path('/tmp/connectanum-native-perf-owner-error/implemented-hashes.json').read_text())
 assert source_sha==baseline['tool/native_perf_build_producer.py']
 text=raw.decode();tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_RetainedPreflightOwner')
 selected='\n\n'.join(ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('_error_locked','_work','observe'))
 test_raw=path.with_name('test_native_perf_build_producer.py').read_bytes();test_text=test_raw.decode()
 test_class=next(n for n in ast.parse(test_text).body if isinstance(n,ast.ClassDef) and n.name=='OwnerErrorLabelTests')
 selected+='\n\n'+ast.get_source_segment(test_text,test_class)
 context='NEW owner error type-label prerequisite. Original type(error).__name__ invoked custom metaclass BEFORE private retention/worker completion. Three methods only now store exact private first/call/join errors BEFORE native type descriptor label; first-object condition. All other owner/producer/aux/gates untouched. Five NEW controls BEFORE5FAIL -> implemented8PASS=5new+3required existing owner callers. NEW cases synthetic owners/operations with actual finite Threads; raising/nonscalar metaclass, earlierprimary/latercall, actual Thread.join returns THEN injected error, mocked Thread construction failure; no Popen/SDK child for these five. Required actual producer callers finite Fixture only. No physical EX release/admission/history freeze. Source parent-writer and other unrelated exception metadata remain outside scoped fix. Review selected current three methods/new test class max2 concrete source-supported bugs/max220words; no global auth/atomicity/kill/retry/automatic uncertain close suggestions. Advice ROOT verifies.\n\n'+selected
 assert len(context)<22000
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 with (work/'review-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','2100','--max-input-chars','23000','--max-response-chars','9000','--timeout','180','--save-output',str(work/'review.txt'),'--prompt','Review three owner error-label methods and focused new tests, max2 concrete bugs/max220words. No physical release/admission/history-freeze approval.']
 put('review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('review-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
