import sys,pathlib,json,ast,hashlib,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owner-error');D=pathlib.Path('/tmp/connectanum-native-perf-owner-error-design')
 root=pathlib.Path('/tmp/connectanum-native-perf-owner-error-root-assessment');root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 original=json.loads((P/'original-hashes.json').read_text());final=json.loads((P/'review-control-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in final.items())
 assert {rel for rel in final if final[rel]!=original[rel]}=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 def nodes(text):
  return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 def methods(text,name):
  cls=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name==name)
  return {n.name:ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef)}
 old=(P/'original-source/tool/native_perf_build_producer.py').read_text();new=(R/'tool/native_perf_build_producer.py').read_text()
 on=nodes(old);nn=nodes(new);assert set(on)==set(nn)
 assert all(nn[name]==body for name,body in on.items() if name!='_RetainedPreflightOwner')
 om=methods(old,'_RetainedPreflightOwner');nm=methods(new,'_RetainedPreflightOwner')
 assert set(om)==set(nm)
 changed={name for name in om if om[name]!=nm[name]};assert changed=={'_error_locked','_work','observe'}
 assert nm['_error_locked'].index('self._first_error_object=error')<nm['_error_locked'].index("self._first_error=type.__dict__")
 assert 'if self._first_error_object is None:' in nm['_error_locked']
 assert nm['_work'].index("record['_call_error_object']=error")<nm['_work'].index("record['call_error']=type.__dict__")
 assert nm['observe'].index("record['_join_error_object']=error")<nm['observe'].index("record['join_error']=type.__dict__")
 for name in changed:assert 'type(error).__name__' not in nm[name]
 oldtest=(P/'original-source/tool/test_native_perf_build_producer.py').read_text();newtest=(R/'tool/test_native_perf_build_producer.py').read_text()
 ot=nodes(oldtest);nt=nodes(newtest);assert all(nt[name]==body for name,body in ot.items())
 assert set(nt)-set(ot)=={'OwnerErrorLabelTests','OwnerErrorJoinReviewTests'}
 with (root/'final-affected-methods-and-tests.txt').open('x') as out:
  out.write('\n\n'.join(nm[name] for name in sorted(changed))+'\n\n'+nt['OwnerErrorLabelTests']+'\n\n'+nt['OwnerErrorJoinReviewTests'])
 invariants=dict(exact_three_owner_methods=sorted(changed),all_other_owner_methods_byteexact=True,CommandProducer_Auxiliary_functions_factories_gates_byteexact=True,
  first_private_call_join_objects_before_native_type_label=True,all_existing_test_classes_byteexact=True,other18tools_and3bins_byteexact=True,
  no_history_freeze_or_parent_writer_error_policy_change=True,privatecontrollers_outside_HELPERBUNDLE20=True)
 put(root/'structural-qualification.json',invariants)
 stages={}
 for stage in ['before','implemented','review-control']:
  raw=(P/(stage+'-tests.json')).read_bytes();data=json.loads(raw)
  stages[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],report=stage+'-tests.json',sha256=sha(raw))
 assert [(s['tests'],s['failures'],s['errors']) for s in stages.values()]==[(5,5,0),(8,0,0),(1,0,0)]
 models={name:json.loads((D/(name+'-finish.json')).read_text()) for name in ['tests','review']}
 models['history_freeze_summary']=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design/summary-finish.json').read_text())
 assert all(v['direct_status']==0 and v['reaped'] for v in models.values())
 fixtures=[]
 for stage in stages:
  for item in sorted((P/(stage+'-fixtures')).rglob('*.json')):
   raw=item.read_bytes();fixtures.append(dict(stage=stage,path=item.relative_to(P).as_posix(),size=len(raw),sha256=sha(raw)))
 commands=[]
 def git(*args):
  row=dict(argv=['git','-C',str(R),*args],pid=None,status=None);commands.append(row)
  child=subprocess.Popen(row['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  stdout,stderr=child.communicate();row['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (root/(str(len(commands)-1)+'-'+label+'.bin')).open('xb') as out:out.write(raw)
   row[label+'_eof']=True;row[label+'_size']=len(raw);row[label+'_sha256']=sha(raw)
  put(root/('git-'+str(len(commands)-1)+'.json'),row)
  assert row['status']==0 and not stderr
  return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain');diff=git('diff','--name-only','HEAD','--','packages','native')
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert set(status.splitlines())=={' M '+rel for rel in final if rel.startswith('tool/')} and not diff
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='owner exception type-label prerequisite; not historical inventory or physical closure',
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],hashes=final,
  stages=stages,counts_qualification='BEFORE5FAIL, no missing APIs or RAM/SDK/canonical defect count. Implemented8PASS=5new+3required existing owner callers. Review-control1PASS separate after source unchanged; six new declared methods, not combined9/fullfinal9/canonical.',
  root_source_assessment='ROOT checked whole affected final methods/test classes plus byteexact AST/source invariants. Exact private first/call/join errors precede native label. Normal labels remain native class names. Owner first-object condition prevents later type-name publication from replacing earliest. Existing busy/startsettled/join/schedule/emit/freeze/aux predicates unchanged.',
  raw_limits='Five NEW controls use SYNTHETIC unregistered owner/operation and ACTUAL finite Python Threads, no Popen/SDK child. Constructor factory raises BEFORE producer or child; later wait has synthetic earlier primary and synthetic operation. Thread.join actually returns before injected fault; source preserves unknown join and retained exact handle, unit teardown naturally joins same thread, never source recovery. Setup Thread constructor seam mocked BEFORE any worker. Nonscalar metaclass native name hook is rejected. New views/lifecycle/private identity booleans/hook occurrences/uncaught errors type labels saved before assertions. Thread status has no signed process exit code. Three required existing owner callers use old finite Fixture paths; legacy setup/API/child/FD returns not all systematically serialized, no reconstruction/fullclosure claim. Actual officialEX spans known finite controls and legacy known children; private fixture cleanup never live release or retag. No raw concurrent observer/global atomicity/auth/writer/descendant proof.',
  models=models,ROOT_model_qualification='Gemma26124 prior history-freeze orientation invents history-only snapshot/owner_id details; ROOT corrects current+Aux-only inventory and independently selects prerequisite. Qwen27398 suggests ordinary/mock-only errors and joins; ROOT uses metaclass and real finite Thread/join controls. Qwen27664 P1 recommends restoring type(error).__name__ FALSE for required hook-free boundary; BEFORE5FAIL/current8PASS prove counterexample. P2 recommends trusting bounded join return FALSE: join(timeout) returns None with worker alive; NEW finite real-thread1PASS demonstrates retained handle/false joined until natural completion. No inferred leaks/latency/snapshot global atomicity from histories. Selected source review BEFORE final review test, source unchanged; ROOT final wholeaffected checks, not model full-current-source approval.',
  administrative_failures='Initial controller NameError testsCandidate after 2 preeditGit0+saved streams/original snapshot, before source mutation/test/worker. Empty candidate created by openx before NameError. Continuation FileExistsError preserves empty candidate, again before source/test/worker. Distinct v2candidate/actual controller succeeds. Full failed scripts saved; initial toolreturns chat and one exact toolreturn retained, second error summarized not reconstructed. Initial resume checkpoint/docs read used raw administrative shell outside officiallease; later source/model/test/publication use official leases; no execution waiver inferred.',
  invariants=invariants,fixture_report_index=fixtures,posttest_Git=commands,branch=branch,HEAD=head,
  all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,native_output_instructionclosure_not_proved=True,no_source_commit_push_adoption_strictdispatch=True,
  remaining='Independent frozen historical inventory/continuation/transitive genericFD/auditpartialactors/unknownstarts/sharedjournal-historicalwriter/interpreter-delegate-descendant/fullphysical officialEX controller incomplete. Parent-writer metadata and other unrelated error labels outside scoped fix. Existing freeze owner_emit_attempted and oldaux predicates unchanged. No status/EOF/join/closedobject/emptyledger/sourcefile data grants EXrelease/admission. Original PATH SDK/bootstrap/first3locks hiddenconfigs/current20canonical/newsourcepackage/OWN native-driver-staticRLIB/compiler-tool-kernel+actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage and ROOT-qualified immutable COMPLETEadmission required before diagnosticdata.',
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  no_actual_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,build_floor_bytes=12*1024**3,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['owner_error_component']=dict(cache=str(P),design=str(D),root_assessment=str(root),assessment=str(root/'assessment.json'),
  source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],stages={k:{x:s[x] for x in ['tests','failures','errors']} for k,s in stages.items()},
  publication_pending=True,all_known_own_model_test_calls_terminal=True,no_canonical_admission_or_history_freeze=True,never_repeat_unchanged=True)
 n['last_free_bytes']=assessment['free_after'];v['active_turn_status']='owner_error_ROOT_qualified_publication_pending'
 c.write_text(json.dumps(v,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],stages=n['owner_error_component']['stages'],free=assessment['free_after'])))
