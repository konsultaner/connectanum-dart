import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-owner-error');a=pathlib.Path('/tmp/connectanum-native-perf-owner-error-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-owner-error-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-owner-error-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='5cdcdf5b5eba052fe87cfdc98a95884db0ca4bdf'
 assert git('status','--porcelain')==''
 h=json.loads((p/'review-control-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 assert before>=1024**3+256*1024**2
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  selected_method_test_coordinators_saved_before_execution=True))
 base='2026-11-04-flatbuffers-native-perf-owner-error';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'plan'),(a,'design'),(final_root,'root-final'),(pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design'),'history-freeze-design')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-owner-error-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Owner error retention before type-name publication\n\nA custom exception metaclass can intercept type(error).__name__. The old owner\nused that lookup before retaining its first/call/join error objects. A raising\nhook could replace the original error and interrupt worker completion; a hook\nreturning an object could put a non-scalar value into an observer row.\n\nThree owner methods now retain the exact private first/call/join error before\npublishing a class-name label through the native type descriptor. The first\nerror is selected by its retained object. Normal error labels remain class-name\nstrings. No exception repr/str/add_note/equality hook is added. Busy, settled\nstart, actual join, scheduling, emission, frozen inventory and auxiliary gates\nare unchanged. Other owner methods, CommandProducer, AuxiliaryCommand,\nmodule functions/factories/gates/emitters, old test classes, other18 helpers and\nthree selected bin scripts remain byteexact.\n\nFive new negative controls fail before the source change, with no missing API\nerrors. Eight selected controls then pass: those five plus three required\nexisting owner callers. A separate new review control passes with unchanged\nproducer source. There are six new methods, not a combined final9/canonical\nresult. These failures are unit fault models, not RAM, SDK or native defects.\n\nThe five negatives use synthetic, unregistered owners/operations and actual\nfinite Python Threads. Constructor failure precedes a producer or child.\nThe later-call control starts with an explicit synthetic earlier primary.\nThe join control actually joins before injecting the error; the source retains\nthe uncertain join and exact Thread handle. The constructor seam fault precedes\nany worker. Raising and non-scalar metaclass hooks, exact first/current error\nidentities, worker/event/cache facts and hook occurrences are saved before\nassertions. Thread joins have no signed process exit code. The final review\ncontrol observes a real worker still alive after a bounded join and later\nobserves the same worker's natural completion. No Popen or SDK child is\nrequested by these six new controls.\n\nThe three required old callers exercise finite Fixture producer paths. Their\nlegacy setup/API/child/FD returns are not all systematically serialized.\nNo missing history is reconstructed and no whole actor/FD closure is claimed.\nKnown same-Thread joins and old finite fixture cleanup remain unit teardown,\nnever a live recovery, source-state retag or physical lease-release procedure.\nActual official EX spans the known finite controls and required callers.\nPrivate data is not a raw concurrent observer API or a heap/RSS bound.\n\nGemma's earlier history-freeze orientation, Qwen test advice and selected\nthree-method review all complete directly with status0 and are reaped.\nThe orientation invents history-only snapshot details; ROOT corrects the\ncurrent-plus-auxiliary inventory and independently selects this prerequisite.\nROOT uses metaclass faults and real Threads instead of the suggested ordinary\nerrors and mock-only joins. The review recommends restoring the hook-prone\nlookup; the before/after controls demonstrate why that is wrong. It also\nrecommends trusting a bounded join return. The new real-thread control shows\nthat join(timeout) can return while the worker remains alive. No measured\nleak, latency or global snapshot atomicity follows from retained histories.\nThe review precedes the last new test; producer bytes are unchanged. ROOT\nchecks the whole final affected methods/tests and structural invariants,\nnot a model approval of the full current source.\n\nAdministrative failures are retained. The first controller leaves an empty\ncandidate file before an undefined-variable error; a continuation preserves\nthat file on an exclusive-create collision. Both precede source writes and\ntest/worker execution. A distinct candidate/controller performs the controls.\nROOT's first assessment expects modified-file status instead of the actual\ntwenty untracked helpers. Its structural checks and all four Git signed-status/\nseparate-stream records already exist. A data-only finalizer accepts the\nretained actual status without rerunning Git, AST, tests or models. A computed\nfixture index was not serialized before that assertion and stays null; raw\nfixture files remain. Initial resumed checkpoint/docs reads used an\nadministrative shell outside the official lease; later source/model/test/\npublication operations use the official leases. No waiver follows.\n\nFinal producer90f62576506fc3345d44275394953a2d9fc791c4083ca86830fe3376178c3aa1;\ntest952d96418842953bcab9286fd74cffdd68b074bc34f26b41e1aa589331d80419.\nFour new post-control Git queries observe the contracted branch, HEAD601,\ntwenty untracked helpers and an empty tracked production diff, with direct\nsigned0 and both separate EOF streams saved. Native output or loaded\ninstruction closure does not follow. All20 helpers remain uncommitted,\nuncanonical and unadmitted; production601 is unedited. Private controllers\nare retained artifacts outside HELPERBUNDLE20.\n\nHistorical frozen inventory/continuation, transitive generic FDs, audit partial\nactors, unknown starts, historical writers/interpreter/delegate/descendants\nand independent physical officialEX orchestration remain incomplete.\nParent-writer and unrelated exception metadata remain outside this scoped fix.\nExisting freeze owner_emit_attempted and old auxiliary predicates stay closed.\nNo status, EOF, join, closed object, empty ledger or source-file fact grants\nrelease or admission. Original PATH/SDK/bootstrap/first3locks/hiddenconfigs,\ncurrent20canonical/new source package/OWN native-driver-static RLIB/compiler-\ntool-kernel and actual original-host credentials/access/pidfd/FDexec/\ninheritance/arming/metadata/role/time/coverage remain required before\nROOT-qualified immutable COMPLETE admission and any diagnostic data.\nNo borrowed cohort/config/native transplant, favorable redo, SDK change or\npostGO as preproof.\n\nProvider absent, live gate always raises, controller closed, ownershipNone,\nall three admission flagsFalse. No actual SDK/native build/canonical/kernel/\nbroker/benchmark/capture, RAM cause/repair or strict acceptance. Latest\nassessment free11.77GB is below12GiB: build floor CLOSED; recheck before any\nbuild. Scoped tests use their separate1GiB floor. Cause unmeasured; no cleanup.\nPR132 remains OPEN DRAFT on130; issue103 and milestone stay OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Owner error objects retained before type labels\n\nThree owner methods retain exact first/call/join errors before native type-name publication, avoiding custom exception metaclass hooks and non-scalar observer labels. Five new controls fail before;8selected pass after (5new+3required), then a separate real-thread bounded-join control passes with unchanged producer, not combined9/canonical. Other source/gates remain byteexact. All20 helpers stay uncommitted/uncanonical/unadmitted; production601 unedited. Historical inventory/transitive ownership/full physical EX/original-runtime admission remain incomplete. Build floor remains CLOSED below12GiB; cause unmeasured/no cleanup.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-owner-error-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-owner-error-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-owner-error-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: retain owner errors before native type labels')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['owner_error_component'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['owner_error_GitHub_descriptions_pending']=True;n['owner_error_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
