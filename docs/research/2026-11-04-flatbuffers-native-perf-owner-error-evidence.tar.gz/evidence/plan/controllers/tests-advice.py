import sys,pathlib,json,hashlib,ast,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-owner-error-design');work.mkdir()
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 raw=(R/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()=='78ae89da207c41d6bf05baf51df7d431d6098e45d557cb87a587ed243557be16'
 s=raw.decode();c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='_RetainedPreflightOwner')
 context='ROOT selected prerequisite before historical inventory: owner _error_locked/_work/observe use type(error).__name__ before exact private retention. Custom exception metaclass can run under owner lock, raise masking error or return nonscalar. Proposed scoped fix: retain exact private error first; native type.__dict__["__name__"].__get__(type(error),type) label; test first ctor failure, later wait error with earlier retained first, join fault after actual real Thread.join, Thread construction fault. Synthetic owner/operation + ACTUAL finite Thread, no Popen/SDK child for new controls. Explicitly select only new methods plus required prior error lifecycle callers; no subclass inherited suites. Original private producer/aux/gates/spawn cleanup unchanged; no physical release/admission claim. Max3 concrete cases/max200words; no global auth or automatic unknownclose/kill/retry suggestion.\n\n'
 context+='\n\n'.join(ast.get_source_segment(s,n) for n in c.body if isinstance(n,ast.FunctionDef) and n.name in ('_error_locked','_work','observe'))
 put('declaration.json',dict(scope='NEW owner exception type-label prerequisite and focused regression design',source_sha256=hashlib.sha256(raw).hexdigest(),fullphysical_controller=False,SDK_or_build=False,history_freeze_unimplemented=True))
 with (work/'tests-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--num-predict','1200','--max-input-chars','10000','--max-response-chars','6500','--timeout','180','--save-output',str(work/'tests.txt'),'--prompt','Only focused owner exception type-label regression ideas max3/max200words. Advice ROOT verifies.']
 put('tests-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('tests-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('tests-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-6500:])
