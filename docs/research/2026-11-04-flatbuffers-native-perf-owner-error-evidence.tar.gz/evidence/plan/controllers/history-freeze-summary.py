import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design');work.mkdir()
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 put('declaration.json',dict(scope='NEW independent historical command inventory design; source read/model/admin only',source_epoch='78ae89da207c41d6bf05baf51df7d431d6098e45d557cb87a587ed243557be16',source_edit=False,SDK_build_capture_tests=False))
 raw=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='78ae89da207c41d6bf05baf51df7d431d6098e45d557cb87a587ed243557be16'
 text=raw.decode();tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_RetainedPreflightOwner')
 wanted={'__init__','_schedule','_work','_capture_known_actors','_cache_known_actor_rows','_freeze_known_actors','freeze_known_actors'}
 context='Summarize selected CURRENT retained owner source max350words. We plan independent history-only frozen inventory for failed registered owner initializedTrue ORFalse, retaining ALL available new CommandProducer._command_attempts refs BEFOREcallback/metadata. Existing freeze owner_emit_attempted refusal/oldauxpredicates must stay unchanged; no wait/spawn/audit/FDclose/producerretag/release/admission. Identify exact scheduling/busy/actualThreadjoin/startsettled/oneattempt gates and worker postcatch-cache refresh behavior needing a distinct action. New history fields not yet in old current+Aux inventory; no global actor inventory claim. Advice ROOT verifies; no invented methods.\n\n'
 context+='\n\n'.join(ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in wanted)
 assert len(context)<27000
 with (work/'summary-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--stdin','--num-predict','1100','--max-input-chars','28000','--max-response-chars','7000','--timeout','180','--save-output',str(work/'summary.txt'),'--prompt','Summarize selected owner gates/source only,max350words. No actorclosure/release/SDK/capture approval or invented APIs.']
 put('summary-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('summary-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('summary-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-7000:])
