
class OwnerErrorLabelTests(unittest.TestCase):
    """SYNTHETIC owners/operations with actual finite Threads, no SDK/child."""
    def setUp(self):
        self.saved_threads=[]
        root=Path(os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])
        self.evidence=Path(tempfile.mkdtemp(prefix='owner-label-',dir=root))
    def tearDown(self):
        rows=[]
        for thread in self.saved_threads:
            returned=producer.threading.Thread.join(thread,2)
            rows.append(dict(ident=thread.ident,join_return_is_None=returned is None,alive=thread.is_alive()))
        (self.evidence/'teardown.json').write_text(json.dumps(rows,indent=2)+'\n')
        self.assertTrue(all(not row['alive'] for row in rows))
    @staticmethod
    def native_name(value):
        return type.__dict__['__name__'].__get__(type(value),type)
    def safe(self,value):
        if value is None or type(value) in (str,int,bool,float):return value
        if type(value) in (tuple,list):return [self.safe(item) for item in value]
        if type(value) is dict:return {key:self.safe(item) for key,item in value.items()}
        return dict(nonprimitive_native_type=self.native_name(value))
    def save(self,name,owner,error,hooks,extra=None):
        view=owner._snapshot
        rows=[dict(row) for row in owner.worker_lifecycle()]
        records=owner._workers
        result=dict(scope='SYNTHETIC owner/operation; actual finite Thread only; no Popen SDK or release',
            hooks=list(hooks),view=self.safe(dict(view)),lifecycle=self.safe(rows),
            private_first_is_error=owner._first_error_object is error,
            private_call_is_error=bool(records) and records[-1]['_call_error_object'] is error,
            private_join_is_error=bool(records) and records[-1]['_join_error_object'] is error,
            busy=owner._busy,call_done=owner._call_done,event_set=owner._event.is_set(),
            first_label_native_type=self.native_name(owner._first_error),extra=self.safe(extra))
        (self.evidence/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    def error(self,hooks,return_marker=False):
        class NameHookFailure(RuntimeError):pass
        marker=object()
        class Meta(type):
            def __getattribute__(cls,name):
                if name=='__name__':
                    hooks.append('metaclass_name')
                    if return_marker:return marker
                    raise NameHookFailure('synthetic metadata hook')
                return type.__getattribute__(cls,name)
        class Error(RuntimeError,metaclass=Meta):
            def __repr__(self):hooks.append('repr');raise AssertionError('repr hook')
            def __str__(self):hooks.append('str');raise AssertionError('str hook')
            def add_note(self,note):hooks.append('add_note');raise AssertionError('note hook')
            def __eq__(self,other):hooks.append('equality');raise AssertionError('equality hook')
        return Error(),NameHookFailure
    def failed_worker(self,error,hooks,prior=None):
        from types import SimpleNamespace
        owner=producer._RetainedPreflightOwner('fixture','f'*32,{})
        uncaught=[]
        def fail(*args,**kwargs):raise error
        if prior is None:patch=mock.patch.object(producer,'start_fixture',side_effect=fail);action='construct';value=None
        else:
            owner._operation=SimpleNamespace(wait=fail,pending=True,finished=False)
            owner._initialized=True;owner._pending=True;owner._finished=False
            owner._error_locked(prior)
            patch=mock.patch.object(producer,'start_fixture',side_effect=AssertionError('unused factory'))
            action='wait';value=0
        with patch,mock.patch.object(producer.threading,'excepthook',side_effect=lambda args:uncaught.append(args.exc_value)):
            returned=owner._schedule(action,value);thread=owner._thread;self.saved_threads.append(thread)
            observed=owner.observe(.25)
        self.save('worker',owner,error,hooks,dict(returned_same=returned is owner,
            uncaught_types=[self.native_name(item) for item in uncaught],
            uncaught_is_original=[item is error for item in uncaught],thread_alive=thread.is_alive(),
            observed=self.safe(dict(observed)),prior_preserved=owner._first_error_object is prior))
        return owner,uncaught
    def test_constructor_metaclass_error_retained_before_label(self):
        hooks=[];error,_=self.error(hooks);owner,uncaught=self.failed_worker(error,hooks)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(error,owner._first_error_object);self.assertIs(error,owner._workers[-1]['_call_error_object'])
        self.assertEqual('Error',owner._first_error);self.assertTrue(owner._call_done)
        self.assertTrue(owner._event.is_set());self.assertFalse(owner._busy)
        self.assertTrue(owner._workers[-1]['worker_joined'])
    def test_later_call_metaclass_error_keeps_earliest_and_current(self):
        hooks=[];error,_=self.error(hooks);prior=ValueError('synthetic earlier primary')
        owner,uncaught=self.failed_worker(error,hooks,prior)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(prior,owner._first_error_object);self.assertEqual('ValueError',owner._first_error)
        self.assertIs(error,owner._workers[-1]['_call_error_object'])
        self.assertEqual('Error',owner._workers[-1]['call_error'])
        self.assertTrue(owner._call_done);self.assertTrue(owner._event.is_set());self.assertFalse(owner._busy)
    def test_nonscalar_metaclass_name_never_reaches_view(self):
        hooks=[];error,_=self.error(hooks,True);owner,uncaught=self.failed_worker(error,hooks)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(type(owner._snapshot['first_error']),str)
        self.assertEqual('Error',owner._snapshot['first_error'])
        self.assertIs(type(owner.worker_lifecycle()[-1]['call_error']),str)
    def test_actual_join_then_metaclass_error_retained_without_recovery(self):
        from types import SimpleNamespace
        hooks=[];error,_=self.error(hooks)
        owner=producer._RetainedPreflightOwner('fixture','e'*32,{})
        def factory(**kwargs):
            operation=SimpleNamespace(pending=False,finished=True)
            kwargs['_preflight_owner']._operation=operation
            return operation
        with mock.patch.object(producer,'start_fixture',side_effect=factory):owner._schedule('construct')
        thread=owner._thread;self.saved_threads.append(thread)
        real_join=producer.threading.Thread.join;native_returns=[];caught=None;observed=None
        def joined_then_fault(same,timeout=None):
            self.assertIs(thread,same);native_returns.append(real_join(same,timeout))
            raise error
        try:
            with mock.patch.object(producer.threading.Thread,'join',new=joined_then_fault):observed=owner.observe(2)
        except BaseException as failure:caught=failure
        self.save('join',owner,error,hooks,dict(native_join_returns=native_returns,
            caught_type=None if caught is None else self.native_name(caught),
            caught_is_original=caught is error,observed=None if observed is None else self.safe(dict(observed)),
            actual_thread_alive=thread.is_alive()))
        self.assertEqual([],hooks);self.assertIsNone(caught);self.assertEqual([None],native_returns)
        self.assertIs(error,owner._workers[-1]['_join_error_object'])
        self.assertEqual('Error',owner.worker_lifecycle()[-1]['join_error'])
        self.assertFalse(owner._workers[-1]['worker_joined'])
        self.assertIs(thread,owner._workers[-1]['_thread'])
        self.assertIsNone(owner._first_error_object)
    def test_thread_setup_metaclass_error_stays_start_uncertain(self):
        hooks=[];error,_=self.error(hooks)
        owner=producer._RetainedPreflightOwner('fixture','d'*32,{})
        returned=None;caught=None
        try:
            with mock.patch.object(producer.threading,'Thread',side_effect=error):returned=owner._schedule('construct')
        except BaseException as failure:caught=failure
        self.save('setup',owner,error,hooks,dict(returned_same=returned is owner,
            caught_type=None if caught is None else self.native_name(caught)))
        self.assertEqual([],hooks);self.assertIsNone(caught);self.assertIs(owner,returned)
        self.assertIs(error,owner._first_error_object);self.assertEqual('Error',owner._snapshot['first_error'])
        self.assertEqual('start_uncertain',owner._snapshot['call_state'])
        self.assertTrue(owner._busy);self.assertFalse(owner._call_done)
        self.assertFalse(owner._workers[-1]['thread_created']);self.assertTrue(owner._workers[-1]['start_settled'])
