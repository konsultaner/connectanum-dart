
import pathlib,hashlib,importlib.util,json,subprocess,sys
P=pathlib.Path('/tmp/connectanum-native-perf-native-bootstrap-source-contract-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q=P/'source-review';Q.mkdir()
 def save(name,obj):
  with (Q/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 names=['native_bootstrap_draft.h','native_bootstrap_draft.c','source-contract.md']
 context='\n\n'.join('FILE '+name+'\n'+(P/name).read_text() for name in names).encode();assert len(context)<20000
 with (Q/'context.txt').open('xb') as f:f.write(context)
 prompt='Review ONLY these NEW UNCOMPILED private source-contract artifacts. They are not a runnable native helper, source20 change, build recipe or permission to compile/run. Give at most four actual source/layout/contract risks and one smallest next static artifact, within 900 words. Distinguish uncompiled C assertions and DATA initializer from actual native ownership, process-shared atomics, signal-free prefix or admission. ct_draft_start deliberately returns UNIMPLEMENTED and no creator/publisher/prefix/refusal/wait/lease exists; do not propose enabling them from fields/magic/hash/schema. No compiler/tool/version/disassembly command, SDK call, extra flags/env/credentials/host, timeout kill, PID scan, partial methods, Source-field restoration or unknown ownership settlement. Parent/child journals are intended ownership, not memory isolation. Source shape can be reviewed, but do not claim compilation, tests or runtime proof.'
 argv=[sys.executable,str(h),'review','--provider','ollama','--model','qwen3.8:27b','--stdin','--prompt',prompt,'--num-predict','2048','--timeout','180','--max-input-chars','20000','--save-output',str(Q/'answer.txt')]
 save('command-before.json',dict(argv=argv,context_size=len(context),context_sha256=sha(context),source_files=names,Popen_attempted=True,pid=None))
 p=subprocess.Popen(argv,cwd='/tmp',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
 save('native-handles-before-IO.json',dict(pid=pid,original_bound_wait_streams_retained=True))
 out,err=p.communicate(input=context);status=wait(10)
 for role,b in [('stdout',out),('stderr',err)]:
  with (Q/(role+'.bin')).open('xb') as f:f.write(b)
 result=dict(pid=pid,status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err),complete_answer_exists=(Q/'answer.txt').is_file(),C_compiler_nativehelper_test_or_SDK_called=False)
 save('result.json',result);lease.verify_identity();print(json.dumps(result))
