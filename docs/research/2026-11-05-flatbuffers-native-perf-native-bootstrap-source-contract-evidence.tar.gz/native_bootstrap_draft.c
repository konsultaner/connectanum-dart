/* UNCOMPILED SOURCE CONTRACT ONLY. No main, syscalls or launcher exists. */
#include "native_bootstrap_draft.h"

/* Parent pre-creation initialization, not a post-clone signal-safe routine. */
static void ct_draft_store_le32(uint8_t out[4], uint32_t value) {
  out[0] = (uint8_t)(value);
  out[1] = (uint8_t)(value >> 8);
  out[2] = (uint8_t)(value >> 16);
  out[3] = (uint8_t)(value >> 24);
}

int ct_draft_initialize_data(struct ct_draft_mapping *mapping, size_t bytes) {
  static const uint8_t magic[8] = {'C','T','F','I','N','I','T','1'};
  if (mapping == NULL || bytes != CT_DRAFT_MAPPING_BYTES ||
      ((uintptr_t)mapping % CT_DRAFT_MAPPING_ALIGNMENT) != 0) {
    return CT_DRAFT_INVALID_SHAPE;
  }
  /*
   * No attempt to validate a foreign pointer or acquire ownership.
   * This loop may lower to a runtime helper; no generated code is bound.
   * It is forbidden after native creation and before child registration.
   */
  uint8_t *raw = (uint8_t *)mapping;
  for (size_t i = 0; i < CT_DRAFT_MAPPING_BYTES; ++i) {
    raw[i] = 0;
  }
  for (size_t i = 0; i < sizeof(magic); ++i) {
    mapping->magic[i] = magic[i];
  }
  ct_draft_store_le32(mapping->format_le, CT_DRAFT_FORMAT_VERSION);
  ct_draft_store_le32(mapping->mapping_size_le, CT_DRAFT_MAPPING_BYTES);
  mapping->decision_native = CT_DRAFT_WAIT; /* no concurrent access allowed */
  return CT_DRAFT_DATA_INITIALIZED; /* DATA, never admission/readiness */
}

int ct_draft_start(void) {
  return CT_DRAFT_UNIMPLEMENTED;
}
