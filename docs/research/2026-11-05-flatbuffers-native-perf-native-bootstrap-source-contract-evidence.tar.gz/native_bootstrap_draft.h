/* UNCOMPILED SOURCE CONTRACT. No native actor provider or admission API. */
#ifndef CT_NATIVE_BOOTSTRAP_DRAFT_H
#define CT_NATIVE_BOOTSTRAP_DRAFT_H
#include <limits.h>
#include <stddef.h>
#include <stdint.h>

#define CT_DRAFT_MAPPING_BYTES 512u
#define CT_DRAFT_MAPPING_ALIGNMENT 64u
#define CT_DRAFT_FORMAT_VERSION 1u

/* Private finite-fixture decisions. No SDK exec or driver GO value exists. */
enum ct_draft_decision {
  CT_DRAFT_WAIT = 0,
  CT_DRAFT_RUN_FINITE = 1,
  CT_DRAFT_REFUSE_FINITE = 2
};
enum ct_draft_result {
  CT_DRAFT_UNIMPLEMENTED = -1,
  CT_DRAFT_INVALID_SHAPE = -2,
  CT_DRAFT_DATA_INITIALIZED = 0
};

/*
 * Header integers below are byte arrays in little-endian format.
 * decision_native is a target-native shared word; its actual ABI, lock-free
 * lowering and process-shared behavior are UNBOUND. Tags are DATA, not auth.
 * Parent-only/child-only are proposed source ownership, not memory isolation.
 */
struct ct_draft_mapping {
  uint8_t magic[8];                    /* offset 0 */
  uint8_t format_le[4];                /* offset 8 */
  uint8_t mapping_size_le[4];          /* offset 12 */
  uint8_t fixture_flags_le[4];         /* offset 16: zero */
  uint8_t header_reserved[12];         /* offset 20 */
  uint8_t reserved_to_decision[32];    /* offset 32 */
  _Alignas(64) uint32_t decision_native;/* offset 64 */
  uint8_t decision_reserved[60];       /* offset 68 */
  uint8_t parent_journal[128];         /* offset 128: parent-owned proposal */
  _Alignas(64) uint8_t child_journal[128];/* offset 256: child-owned proposal */
  uint8_t final_reserved[128];         /* offset 384 */
};

/* These assertions have NOT been compiled. A compiler/ABI failure must refuse. */
_Static_assert(CHAR_BIT == 8, "draft requires 8-bit bytes");
_Static_assert(sizeof(uint32_t) == 4, "draft requires a 4-byte decision");
_Static_assert(offsetof(struct ct_draft_mapping, decision_native) == 64,
               "decision offset");
_Static_assert(offsetof(struct ct_draft_mapping, parent_journal) == 128,
               "parent journal offset");
_Static_assert(offsetof(struct ct_draft_mapping, child_journal) == 256,
               "child journal offset");
_Static_assert(offsetof(struct ct_draft_mapping, final_reserved) == 384,
               "reserved offset");
_Static_assert(sizeof(struct ct_draft_mapping) == CT_DRAFT_MAPPING_BYTES,
               "mapping size");
_Static_assert(_Alignof(struct ct_draft_mapping) == CT_DRAFT_MAPPING_ALIGNMENT,
               "mapping alignment");

/*
 * Pre-creation DATA initializer only. Caller must already own valid, writable
 * mapped storage for the entire object with no concurrent readers/writers.
 * Pointer/size/alignment checks do NOT prove that precondition, mapping
 * identity, lease ownership, actor identity or readiness.
 */
int ct_draft_initialize_data(struct ct_draft_mapping *mapping, size_t bytes);

/* Public draft entry always refuses; no creator or lease implementation. */
int ct_draft_start(void);

/*
 * Native creation, parent decision publication, child prefix, finite refusal,
 * native wait/collection and original-context exit intentionally have NO
 * declared callable implementation in this draft.
 */
#endif
