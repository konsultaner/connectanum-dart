
import pathlib,hashlib,importlib.util,json,os,stat,datetime
P=pathlib.Path('/tmp/connectanum-native-perf-native-bootstrap-source-contract-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def save(name,obj):
 with (P/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 drafts=json.loads((P/'source-generation-inputs.json').read_text());plan=json.loads((P/'declaration.json').read_text())['planned_files'];rows=[]
 for i,(name,text) in enumerate(drafts.items()):
  data=text.encode();assert len(data)==plan[name]['size'] and hashlib.sha256(data).hexdigest()==plan[name]['sha256']
  save(f'create-{i}-attempt-before.json',dict(path=str(P/name),O_EXCL=True,bytes_planned=len(data),fd=None,attempted=True))
  fd=os.open(P/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW,0o600)
  before=os.fstat(fd)
  save(f'create-{i}-fd-before-write.json',dict(fd=fd,dev=before.st_dev,ino=before.st_ino,uid=before.st_uid,gid=before.st_gid,regular=stat.S_ISREG(before.st_mode)))
  written=os.write(fd,data)
  save(f'create-{i}-write-return.json',dict(fd=fd,actual_return=written,expected=len(data),partial_means_terminal_no_retry=True))
  assert written==len(data)
  save(f'create-{i}-close-attempt-before.json',dict(fd=fd,attempted=True,no_repeat_on_uncertainty=True))
  os.close(fd)
  save(f'create-{i}-close-return.json',dict(fd=fd,returned_None=True))
  actual=(P/name).read_bytes();assert actual==data
  rows.append(dict(path=name,size=len(actual),sha256=hashlib.sha256(actual).hexdigest(),exact_planned_bytes=True))
 lease.verify_identity();receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Initial private draft source/data artifacts only under officialEX; not compiled or executed',files=rows,Source20_runtime_or_existing_source_edit=False,new_native_build_run_tests=0,compiler_or_helper_invoked=False,point_readback_not_atomic_ABA_or_origin_or_runtime_admission=True,full_admission=False)
 save('source-generation-receipt.json',receipt);print(json.dumps(receipt))
