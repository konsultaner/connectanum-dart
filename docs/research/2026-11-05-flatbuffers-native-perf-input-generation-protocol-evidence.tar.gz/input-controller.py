import sys,pathlib,json,hashlib,os,stat,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-input-generation-protocol-v1");source=pathlib.Path("/Users/konsultaner/.codex/worktrees/flatbuffers-native-preflight-runtime/connectanum-dart/bin/check-format")
def identity(s):return dict(dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,flags=getattr(s,'st_flags',None))
def save(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'check-format-acquisition';q.mkdir();save(q/'attempt-before.json',dict(path=str(source),operation='single regular nofollow capped file read',SDK_or_original_recipe_invoked=False))
 before=source.lstat();assert stat.S_ISREG(before.st_mode) and before.st_size<=256*1024
 fd=os.open(source,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 try:
  save(q/'opened-before-read.json',dict(fd=fd,registered=True));opened=os.fstat(fd);assert identity(opened)==identity(before)
  chunks=[];size=0
  while True:
   b=os.read(fd,65536)
   if not b:break
   chunks.append(b);size+=len(b);assert size<=256*1024
  after=os.fstat(fd);end=source.lstat();raw=b''.join(chunks);assert identity(before)==identity(after)==identity(end) and size==before.st_size
 finally:os.close(fd)
 copy=P/'retained-check-format.sh';copy.open('xb').write(raw);assert copy.read_bytes()==raw
 r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),path=str(source),size=size,sha256=hashlib.sha256(raw).hexdigest(),before=identity(before),opened=identity(opened),after=identity(after),path_after=identity(end),copy_full_BYTEEXACT=True,own_reader_fd_closed=True,no_current_HEAD_current20_SDK_census=True,historical_HEAD_NOT_current_binding=True,Source_test_edits=False,SDK_or_original_recipe_invoked=False,point_data_NOT_atomic_ABA_or_immutable_runtime=True)
 save(P/'check-format-input-result.json',r);l.verify_identity();print(json.dumps(dict(size=size,sha256=r['sha256'],Source_edited=False,SDK_invoked=False)));print(raw.decode())
