
import pathlib,hashlib,importlib.util,json,os,datetime
P=pathlib.Path('/tmp/connectanum-native-perf-native-operation-interfaces-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def save(name,obj):
 with (P/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();drafts=json.loads((P/'generation-inputs.json').read_text());plan=json.loads((P/'declaration.json').read_text())['planned_files'];rows=[]
 for i,(name,text) in enumerate(drafts.items()):
  b=text.encode();assert len(b)==plan[name]['size'] and hashlib.sha256(b).hexdigest()==plan[name]['sha256']
  save(f'create-{i}-attempt-before.json',dict(path=str(P/name),O_EXCL=True,fd=None,bytes_planned=len(b)))
  fd=os.open(P/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW,0o600);s=os.fstat(fd)
  save(f'create-{i}-fd-before-write.json',dict(fd=fd,dev=s.st_dev,ino=s.st_ino,uid=s.st_uid,gid=s.st_gid))
  n=os.write(fd,b);save(f'create-{i}-write-return.json',dict(fd=fd,actual_return=n,expected=len(b),no_partial_retry=True));assert n==len(b)
  save(f'create-{i}-close-attempt-before.json',dict(fd=fd,no_repeat_if_unknown=True));os.close(fd);save(f'create-{i}-close-return.json',dict(fd=fd,returned_None=True))
  actual=(P/name).read_bytes();assert actual==b;rows.append(dict(path=name,size=len(b),sha256=hashlib.sha256(b).hexdigest(),exact_planned_bytes=True))
 lease.verify_identity();receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW uncompiled operation-interface source specification artifacts only',files=rows,generated_under_official_EX=True,existing_Source20_runtime_prior_drafts_edited=False,C_compile_test_helper_or_SDK=False,point_readback_DATA_not_atomic_or_origin_auth=True,admission=False);save('source-generation-receipt.json',receipt);print(json.dumps(receipt))
