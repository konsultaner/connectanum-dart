
import pathlib,hashlib,importlib.util,json,subprocess,sys
P=pathlib.Path('/tmp/connectanum-native-perf-native-operation-interfaces-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q=P/'interface-review';Q.mkdir()
 def save(name,obj):
  with (Q/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 names=['native_bootstrap_operations.h','creator-collector-interface-contract.md','prospective-build-bindings.json']
 context='\n\n'.join('FILE '+name+'\n'+(P/name).read_text() for name in names).encode();assert len(context)<20000
 with (Q/'context.txt').open('xb') as f:f.write(context)
 prompt='Review ONLY these NEW UNCOMPILED operation-interface declarations/contract and UNBOUND prospective build packet. At most four concrete interface/state/ownership ambiguities and one next static binding action, within 900 words. No implementation or actual binding exists. Incomplete/const types, enum COMPLETE, caller flags, format/hash/JSON labels are not native identity/ownership/admission. The C API has NO lease acquire/release/dup/borrow or live receipt. Do not invent a runtime test/failure or authorize compiler/disassembly/helper/SDK calls, privilege/namespace/cgroup/host changes, token ownership, PID scan, retry/kill/partial methods/Source-field settlement. Missing return/error/First/raw-writer semantics may be real design gaps, but classify as unimplemented, not an observed bug. UNBOUND is not filesystem absence/backend unavailable. Only new files are reviewed; prior sources/models/campaigns are consumed.'
 argv=[sys.executable,str(h),'review','--provider','ollama','--model','qwen3.8:27b','--stdin','--prompt',prompt,'--num-predict','2048','--timeout','180','--max-input-chars','20000','--save-output',str(Q/'answer.txt')]
 save('command-before.json',dict(argv=argv,context_size=len(context),context_sha256=sha(context),source_files=names,Popen_attempted=True,pid=None))
 p=subprocess.Popen(argv,cwd='/tmp',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
 save('native-handles-before-IO.json',dict(pid=pid,original_bound_wait_streams_retained=True))
 out,err=p.communicate(input=context);status=wait(10)
 for role,b in [('stdout',out),('stderr',err)]:
  with (Q/(role+'.bin')).open('xb') as f:f.write(b)
 result=dict(pid=pid,status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err),complete_answer_exists=(Q/'answer.txt').is_file(),C_compiler_nativehelper_test_or_SDK_called=False)
 save('result.json',result);lease.verify_identity();print(json.dumps(result))
