/* UNCOMPILED INTERFACE CONTRACT. Declarations only; no native provider. */
#ifndef CT_NATIVE_BOOTSTRAP_OPERATIONS_DRAFT_H
#define CT_NATIVE_BOOTSTRAP_OPERATIONS_DRAFT_H
#include <stddef.h>
#include <stdint.h>

/*
 * Incomplete types restrict the draft API surface, not caller trust.
 * A pointer/type/const qualifier, label or source hash is not native origin,
 * ownership, complete admission or physical lease authority.
 */
struct ct_original_inputs_unadmitted;
struct ct_native_operation_plan;
struct ct_native_owner;
struct ct_native_raw_observation;
struct ct_native_raw_writer;

enum ct_finite_decision_draft {
  CT_FINITE_WAIT_DRAFT = 0,
  CT_FINITE_RUN_DRAFT = 1,
  CT_FINITE_REFUSE_DRAFT = 2
};

/*
 * RAW observation categories only. They are not proof, admission flags,
 * successful receipts, syscall return values or child exit statuses.
 */
enum ct_native_raw_outcome_draft {
  CT_NATIVE_RAW_NO_ATTEMPT_DRAFT = 0,
  CT_NATIVE_RAW_COMPLETE_RETURN_DRAFT = 1,
  CT_NATIVE_RAW_UNKNOWN_DRAFT = 2
};

/*
 * P0: Plan/reserve native operation, actor and per-owned-FD-copy records
 * BEFORE creator IO. All inputs stay UNADMITTED until independent proof.
 * No caller-supplied "owned"/"ready"/"complete" Boolean may import authority.
 * NO definition, allocation or native operation is supplied in this draft.
 */
int ct_native_prepare_operation_draft(
    const struct ct_original_inputs_unadmitted *inputs,
    const struct ct_native_operation_plan *plan,
    struct ct_native_owner **owner);

/*
 * P1: Actual implementation would retain the ORIGINAL creator-returned
 * process reference, pidfd and original pipe endpoint objects in the private
 * owner registry BEFORE any fallible publication. No later PID lookup,
 * partial constructor method, injected callback result or JSON fills it.
 * Native return uncertainty permanently quarantines this SAME operation.
 */
int ct_native_create_blocked_draft(
    struct ct_native_owner *owner,
    const struct ct_native_raw_observation **creation_raw);

/*
 * P2: One finite-only decision AFTER actual complete native registration
 * and independently established finite-body/refusal/collection obligations.
 * No SDK exec/driver GO value or live admission conversion API exists.
 * A failed/unknown store may not be repeated or changed to another decision.
 */
int ct_native_decide_finite_once_draft(
    struct ct_native_owner *owner,
    enum ct_finite_decision_draft decision,
    const struct ct_native_raw_observation **decision_raw);

/*
 * P3/P4: SAME original creator reference, natural native collection and
 * both complete streams. Preserve signed native status (including signals),
 * every raw byte/error and uncertain operation. EOF/status fields do not
 * settle unknown writers/descendants/FDs or physical ownership.
 * No close/relaunch/rearm/kill/global-scan/partial-method fallback exists.
 */
int ct_native_collect_same_draft(
    struct ct_native_owner *owner,
    struct ct_native_raw_writer *raw_writer,
    const struct ct_native_raw_observation **collection_raw);

/*
 * P5: Export RAW UNADMITTED observations, never a release certificate,
 * canonical receipt, compiled image/source proof or admission object.
 * Full raw streams and per-operation artifacts live outside any 512-byte
 * mapping: map regions cannot substitute for complete retained evidence.
 */
int ct_native_export_raw_draft(
    const struct ct_native_owner *owner,
    struct ct_native_raw_writer *raw_writer);

/*
 * Deliberately absent: implementation of all declarations, opaque type
 * layouts/factory, actual syscall/ABI veneer, child prefix/body/refusal,
 * original official EX acquisition/release or a "mark admitted" function.
 * The official Python keeper alone must retain its ORIGINAL context;
 * these declarations cannot acquire, duplicate, borrow, unlock or replace it.
 * No owner destroy/reset/evict/retry API is provided for uncertain outcomes.
 */
#endif
