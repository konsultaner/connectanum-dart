# Native creator/collector interface contract v1

Status: NEW UNCOMPILED declarations and prospective binding packet only. No native implementation, complete build input or execution authority. These interfaces are separate new specification artifacts. Existing source20, runtime checkout, prior C draft and original fixtures remain untouched and unimported.

The opaque owner/input/plan/raw-writer/raw-observation types are surface declarations, not native identities or a trust boundary. Const qualifiers and pointer values cannot establish creator provenance, writer authentication, mapping/FD ownership, physical EX or immutable admission. There is no implementation or native factory that could return an owner, and no positive receipt/admission/release API.

P0 prepare:
A future actual source-bound factory must reserve one native-operation entry and actual creator/actor/per-copy FD records before launch/fallible IO, using the exact independently declared input/ABI/tool/kernel/cohort policy. The plan is UNADMITTED data. No 'owned' or 'ready' Boolean, hash, type, test callback or shape-valid JSON can import authority. Unknown allocation/creation attempts remain terminal and never become NO_ATTEMPT just because an output pointer is null.

P1 create:
The actual original native creator-return path must capture the process reference, pidfd and pipe endpoints directly into the owner before logging/publication. A later numeric PID lookup, wrapper field, descriptor label or complete-shaped return is not that origin. Atomic reference acquisition, the child bootstrap/signal/implicit-call prefix, private mapping and parent/child FD copies still need implementation and actual independent proof. The owner must outlive all fallible publication. No native syscall is present in the header.

P2 decide:
Only after actual complete original reference registration and independent finite-only body/refusal/collection qualification could a single RUN_FINITE or REFUSE_FINITE be chosen. WAIT is the unreleased state. No original SDK/driver GO or live conversion exists. Controlled publication First after actual registration must preserve First/secondary/raw outcome; it does not repair unknown creation. Any uncertain decision/store outcome stays quarantined; no repeat, alternate decision, reset or field settlement. A private refusal branch implementation is absent and cannot be inferred from an enum name.

P3/P4 collect:
A future implementation must collect the SAME original native actor reference naturally, retain original signed wait status and both full streams, and preserve all raw operation/error bytes. Actual sampler and every delegate/writer completion obligations remain separate. Timeout is not a kill, release or relaunch license. Native exit/EOF or an exported observation does not by itself settle original ownership, close uncertainty or unknown descendants. No owner-reset/destructor API can hide unresolved work.

P5 export:
All observations remain RAW UNADMITTED. The 512-byte draft mapping and its 128-byte parent/child regions cannot stand in for complete raw streams or all operation artifacts. Exact raw writer/storage lifetime and ENOSPC/uncertain-write retention must be independently defined; no chunk trim, reset, eviction, truncated evidence or deletion authority is granted. Requested field sizes/counts are not actual heap/RSS, growth, allocator volume, timing or cause evidence.

Physical EX interface boundary:
There is deliberately NO C lease acquire/release/unlock/dup/borrow API. An independent owner must keep the original official Python lease context continuously held before native helper creation through all actual actors/FD writers and one qualified original-context exit. The C interface cannot reimplement the official helper, receive its internal FD as an ownership token, replace it with a new lease, or certify release from its own observations. Keeper/Root crash, unknown constructor and context-exit outcomes remain unproved. This absence is not an implemented lifetime mechanism.

Prospective build-binding packet:
The associated JSON records only actual known source artifact references and explicitly unbound compiler/toolchain/target/header/runtime/kernel/original-cohort/actor/lease inputs. UNBOUND means not established in this packet, not filesystem absence or backend unavailability. It is not a preflight execution result or accepted receipt. Manual pages, header syntax, source hashes and opaque interfaces do not fill those fields; future generator outputs cannot set their own expected policy authority. Original LOCAL/HOSTED cohorts remain distinct and no locks/config/native/driver/RLIB bytes may be borrowed or transplanted.

No compile/disassembly/helper/SDK call is proposed by these artifacts. Any such work needs its own NEW complete declared preflight, actual source/tool/interpreter/delegate/FD/ABI/runtime/credentials/access and original official EX lifetime qualification, plus fresh12GiB before builds/1GiB before tests. No original driver UID/GID/env/argv/PATH or --dart dart change, new host selection, cgroup/namespace/freeze/grant, SDK/GC/allocator/worker/body/window/sample/gate/schema/copy change or favorable redo.

C0-C3 remain prospective and X1-X2 static exclusions; ZERO tests/ZERO runnable native cases. The original SDK transitive registration mechanism and independent generated-output/original-cohort authority remain absent. Current provider/gate/controller/ownership/flags and PR draft/strict-acceptance blockers are unchanged. No source20 production fix is justified by this static header, no before/after runtime counterexample is claimed, and no completed source/model/archive/campaign is replayed.

Next: bind the prospective native owner factory and raw-writer/collector operation semantics to actual OWN input observations and a concrete original-cohort toolchain preflight. If actual original target/compiler/access is unavailable, record the specific missing binding rather than substituting the local administrative host or inferring an identity from historical hashes.
