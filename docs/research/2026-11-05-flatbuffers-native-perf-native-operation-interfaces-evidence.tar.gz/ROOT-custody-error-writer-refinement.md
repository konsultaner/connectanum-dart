# ROOT custody, error and raw-writer refinement

UNIMPLEMENTED static contract after Qwen's review; not reviewed by that model, not a native test/result or build authority. The original interface/header/binding packet remain unchanged. No numeric return/error ABI is chosen.

Custody:
A future source-bound custodian must hold the actual native owner, original process/pidfd/FD references, buffers, raw writer and original official context before their first fallible operations. Creation/P2/collection/export errors do not transfer or destroy custody. Unknown construction does not imply owner=NULL, absence of a native actor or permission to discard anything. No caller frees/discards owner or writer to complete a case. Retention under unresolved ownership is deliberate, not a measured leak magnitude or RAM cause. Actual allocation and custodian/Root/keeper crash continuity remain unimplemented and unproved.

Error/result layers:
- The C function's future library result is distinct from raw native syscall results, signed child wait status and actual stream EOF. None is a live admission or lease-release certificate.
- A no-attempt classification requires independent actual original operation evidence that creator IO was not attempted; a null pointer, error code, absent row or field is insufficient.
- A known creator return with publication/decision failure retains SAME original references and First/secondary/raw errors. It cannot be reclassified as unknown-free or retried with a new operation.
- Any unknown native return, close, decision/store, write or context-exit outcome remains quarantined and is never replaced with a synthetic known/zero/success-shaped result.
- Exact error codes and opaque object ABI remain UNBOUND. Naming enum tags would not resolve actual native origin, allocation or lifecycle; no runtime error lattice is claimed.

WAIT and single decision:
WAIT is initial shared state, not a valid finite decision request. A future implementation would reject a caller request for WAIT before any store. Only RUN_FINITE or REFUSE_FINITE could be selected once after all actual registration/finite-only prerequisites. An uncertain attempt cannot be undone, changed to WAIT or replaced with another decision. This is prospective semantics, not a changed header, executed validation or permission to implement a store.

Raw writer and export:
The raw writer must retain the exact bytes, including embedded NUL, with explicit lengths/offsets and separate stream identity; no C-string or NUL-termination assumption. Its original native sink handle, partial-prefix bytes, first primary and every secondary/error buffer must remain retained through any failed or uncertain IO. No discard/replacement writer, resend, truncation, deletion or fresh-namespace replay is allowed. A partial report is a one-read terminal observation under the existing policy, not a retry/recovery channel. Unknown writes never become complete because an index or digest exists.
The 512-byte mapping is not complete raw evidence storage. Source journal regions/cursors or copied snapshots do not prove every writer/descendant/FD authenticated or complete. Exact storage/ENOSPC/byte-retention mechanism is still absent. Export is RAW UNADMITTED and supplies no authority for original official-context release.
Const/opaque pointers do not imply thread safety, deep immutability, writer identity, signal safety or synchronization. Actual single-custodian execution and every signal/implicit callback path must be independently bound; no runtime race or leak was observed here.

Actual-binding frontier:
A new KEY-name-only index of native_perf_only_diagnostic_design found seven matching metadata keys after excluding recent draft nodes. These are NOT seven compiler bindings. They lead to consumed runtime_toolchain_inputs/administrative status and docs77f6aceb. The selected checkpoint node records historical SDK/lock/config FILEDATA and no bootstrap/build/SDK CLI. Its old paths were not opened, SDK bodies/scripts/stamps/archives/binaries were not re-audited, and no compiler/kernel/host was probed.
This narrow index does not prove a global absence of compiler facts; it does not bind a current original-cohort compiler/ABI or fill the new prospective packet. Every actual compiler/target/runtime/creator/collector/lease field remains UNBOUND. It is not backend unavailability or an original-host access failure.

Next: identify a concrete original-cohort compiler/input acquisition boundary using independently retained reference metadata, then declare exact OWN source/tool/header/runtime/ABI/credentials/access/FD and official-EX actor lifetime before any compile/disassembly/run. In parallel, native creator/collector/writer implementations and complete SDK transitive/output-cohort authority remain absent. Do not substitute the local administrative host, derive expected authority from the packet itself, or run an old recipe/campaign to fill a missing binding.
