import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-early-finish-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-early-finish-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='2791e2a9232e3886db17a8b1b7d32a204556f41a'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Guard output metadata before terminal publication\n\nOutput path/hash setup ran before the finish private-first barrier. It could enter another failure report after an unknown callback and accepted False/uppercase artifact digests into successful output metadata. The existing attempt/context/digest guard now starts before selected output callbacks, retaining original journal/outputs and per-call intent/raw values. Known-invalid digest refusal precedes payload creation; unknown completion raises the retained first before later reporting I/O. Normal artifact bytes/hash, two original path-string calls, failed-command output skipping and terminal suffix behavior stay intact. References/digests/finished/closed/helper fields remain DATA, never ownership or EX/admission.\n\nNEW6 atc20652/fa3a11 yields4FAIL/2normalPASS/0ERROR: two invalid-return acceptance gaps and two old-first-already-escaping continuation policies, not four spontaneous kernel bugs or a RAM cause. Final410d61/0075d8 passes24selected=6matchingNEW+18affected(8prior publication controls+10wait/finish callers), not aggregate/current20canonical/admission. No new harness errors or unchanged end-command/writer/hash suite or numerical/model replay. Twelve new views plus8affected views/12BEFORE48AFTER currentDarwinEX observations and same bound ROOT waits remain UNIT facts, not independent full EX/originalLinuxcredentials. Qwen44157/GLM44756 complete0/fullanswers are ROOTqualified: SourceProducerError is the first for known-invalid returns; ROOTFirst is never raised there; immediate callbacks are never stored/replayed; mutable output/glob snapshots are DATA. Candidate/privatev1 are unexecuted before edit/first BEFORE; ROOT qualifies final source/tests/AST/result-literal equivalence/byte projection,23hashes/other18helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty. Only _finish changes; end-command/wait/module helpers/nativehash-writer/factories/frozenpredicates stay exact. Other APIs/glob/multipleoutputs/earlier bindings/global ABA/historical/transitive/fullEX/immutableCOMPLETE runtime admission remain incomplete. No SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-early-finish-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: guard output metadata before terminal publication'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_early_finish_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Remaining_earlyfinish glob-multipleoutputs-Pathsuboperations/earlierattributes-bindings-metadata-returnshapes-globalconcurrentABA; endcommand otherAPI/calleeinteriorintent; enclosingreporting/publicunknownCtorretention; writer-hash-init/nativeFD seams; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Current410d61/0075d8 ONLY_finish selectedearlyoutputsetup+localsharedsuffixcontext/privateattempt-beforecallbacks/originaljournal-outputs/percallintent-raw/digestinvalidstop scopedcomplete24selectedPASS=6matchingNEW+18affected(8previousfinishcontrols10actualwait-finishcallers). FirstNEW6 atc20652/fa3a11=4FAIL2normalPASS0ERROR/2knownFalse-uppercase acceptedoutputdigests+2oldfirstalreadyescapes/enclosingcontinuation policies NOT4nativekernelbugs/RAMcause. No newharnessERROR. UnknownSourcePathstr/hash neverROOTadopted; knowninvalidfirst SourceProducerError notROOTFirst. Normalactualownartifact bytes/nativeSHA/path/2strcalls/1hash/fullEARLY-outEARLY-err andfiniteexit3 skipALLoutputsetup preserved.12newviews+8affected/EX12before48after/6+6newRootboundwait5zero1three perphase/8affectedseparate7zero1three UNITnotfullEX. Qwen44157-GLM44756=0/fullanswers/ROOTqualified/rejectprebarrierempty-recoverfinish-lenientdigest/inventedcallee-row-hypotheticalasync-latebinding/freeze-rehashownership claims. Modelv1 seesfinalcandidatev1/privatev1beforefirstBEFORE/ROOTwholefinalAST-resultliteralBYTEprojection qualified NOTwholecurrentapproval. Only_finish methodchanged; modulehelpers/endcommand/wait/nativehash-writer/AuxPopen-factories-sharedstep-frozenpredicates exact. Allpriorepochshistorical/notcurrent20canonical/admission. UnknownPopenCtorpermanentrefusal/no field-derivedownerclose API; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; finished-status-closed-helperfields DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_early_finish_scoped24PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
