import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-early-finish-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts-v1.json').read_text())
 assert source==(P/'candidate-v1.py').read_text() and source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'early_finish_regressions-v1.py').read_bytes();ast.parse(source);ast.parse(tests)
 assert json.loads((P/'candidate-ROOT-projection.json').read_text())['result_literal_AST_equivalent']
 assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(6,4,2,0);assert(a['tests'],a['failures'],a['errors'])==(24,0,0)
 assert len(b['leases'])==12 and len(a['leases'])==48 and all(r['raw_None'] for r in b['leases']+a['leases'])
 def views(path,key):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if key in v}
 old=views(P/'before-units/fixtures','record_original_outputs');new=views(P/'after-selected/fixtures','record_original_outputs');affected=views(P/'after-selected/fixtures','record_original_result');assert len(old)==len(new)==6 and len(affected)==8
 for mode in ('hash_False','hash_upper'):
  v=old[mode][0];assert v['wait_returned'] and v['Source_evidence_complete'] and v['result_status']=='success'
 assert old['hash_False'][0]['output_sha'] is False and old['hash_upper'][0]['output_sha'].upper()==old['hash_upper'][0]['output_sha']
 for mode in ('str_unknown','hash_unknown'):
  assert old[mode][0]['received_first'] and any(x['kind']=='forbidden_preserver' for x in old[mode][0]['calls'])
 waits={};cleanup={}
 for phase,data in [('before',old),('after-new',new),('after-affected-finish',affected)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())];known=[r for r in rows if r.get('kind')=='ROOT_same_original_bound_wait'];expected=8 if phase=='after-affected-finish' else 6
  assert len(known)==expected and sum(r['status']==0 for r in known)==expected-1 and sum(r['status']==3 for r in known)==1
  waits[phase]=known;cleanup[phase]=rows
  for r in rows:
   if r.get('kind') in ('ROOT_known_log','ROOT_known_journal'):assert r['raw_closed_after']
 for mode,(v,d) in new.items():
  assert v['public_producer_returned'] and v['record_present'] and v['record_original_journal'] and v['record_original_outputs'] and v['Source_outputs_original']
  assert not v['Source_pending'] and v['Source_finished'] and all(x['raw_None'] for x in v['leases'])
  assert not any(c['kind'] in ('forbidden_preserver','repr_first','note_first') for c in v['calls'])
  rows=v['Source_steps'];prefix=['output_pattern','output_path','output_hash'];suffix=['result_write','result_hash','finished_event','journal_close','journal_hash']
  if mode in ('normal','normal_failed'):
   assert v['wait_returned'] and v['record_completed'] and v['Source_evidence_complete'] and v['original_journal_closed']
   assert v['result_status']==('failed' if mode=='normal_failed' else 'success') and v['Source_returncode']==(3 if mode=='normal_failed' else 0)
   assert [r['stage'] for r in rows]==(suffix if mode=='normal_failed' else prefix+suffix)
   if mode=='normal':assert sum(x['kind']=='output_path_str_attempt' for x in v['calls'])==2 and v['output_artifact_exists']
   else:assert not any(x['kind'].startswith('output_') for x in v['calls']) and not v['output_artifact_exists']
  else:
   assert not v['wait_returned'] and not v['record_completed'] and not v['Source_evidence_complete'] and not v['failure_exists'] and not v['result_exists']
   assert v['Source_returncode']==0 and v['pure_guard_same_received'] and v['record_primary_received'] and v['Source_result_None']
   assert not v['original_journal_closed'] and v['Source_events_original']
   assert [r['stage'] for r in rows]==(prefix[:1] if mode=='str_unknown' else prefix)
   assert not any(x['kind'] in ('result_write_attempt','finished_event_attempt') for x in v['calls'])
   if mode in ('str_unknown','hash_unknown'):assert v['received_first'] and not rows[-1]['returned'] and rows[-1]['raw_None'] and rows[-1]['error_first']
   else:
    assert v['received_type']=='ProducerError' and not v['received_first'] and rows[-1]['returned']
    if mode=='hash_False':assert rows[-1]['raw_False']
    else:assert rows[-1]['raw_upper_digest']
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]}
 assert models['Qwen']['status']==models['GLM']['status']==0 and (P/'candidate-review/answer.txt').exists()
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'ONLY_finish selectedearly outputsetup +sharedsuffixcontext scopecomplete. Hoists existingattempt/privatefirst/context/digest beforeoutputcallbacks, retainsoriginaljournal-outputs andpercallintent/raw. ResultliteralASTequivalent; SourcewholeBYTEprojectback/allothermethods/modulehelpers/endcommand/wait/nativehash-writer/AuxPopen/constructors/factories/sharedstep/frozenpredicates exact. Context/digest/type/refs/finished/helpercompleted DATA notauth-atomicABA-originalcredentials-ownership-EXrelease/admission.',
 'NEW6 BEFOREonce4FAIL2normalPASS0ERROR:2knowninvalidFalse-uppercase outputdigests acceptedactualsuccessfulmetadata +2unknownPathstr/hash actualcallee-thenROOTfirst continuedenclosingreporting(oldfirstalreadyescapes). Invalidreturn andretention-refusalpolicies NOT4nativekernelbugs/RAMcause. AFTER24=6matchingNEW18affected(8priorfinishpublicationcontrols10actualwait-finishcallers); changed_finish/localstep/context justifiesaffectedselection, notunchangedendnegative-writer-hash suites/numerical/modelreplay oraggregate/fullcurrent20canonical/admission.',
 'SourceunknownoriginalPath.__str__/nativehash rawNone-returnedFalse neverROOTknownstr-digestadopted. KnownFalse/uppercase rawretainedbeforedigestrefusal; firstisnewSourceProducerError, ROOTFirst neverraisedinthosemodes. Refusalvisibleinrecord.primary_error/guard, validationneednotinventseparatecallee row. UnknownnegativespreserveactualRootFirst. Negativeonlypureguard/no Sourcepreserve/repr-note-laterhash-payload-writer-event-close-retry-replay-restore. Calleroutputsdict remainsoriginal/mutable, no freeze-copy-away. FinishedTrue remainsSourcefactnotEXrelease.',
 'Distinctnormalactualownartifact bytes/hash +exact2originalPathstrcalls/1artifacthash andfullEARLY-outEARLY-err output preserved. Finiteexit3 failure skipsALLoutputsetup; absentartifact/nativePathhookwouldfailifcalled, outputs{} preserved. Unitartifact/commands notbenchmarkfreshbody/SDK/nativeDartbroker/current20canonical/admission. Glob/multipleoutputs/Pathconversion-suboperations/earlierbindings-metadata-globalconcurrentABA/historical-transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission unexecuted/incomplete.',
 '12newviews=6BEFORE6AFTER plus8affectedfinishviews separately. ParentCURRENT officialDarwinEXverifyNone12BEFORE48AFTER plusSourcecallbacksNone UNITnotfullindependentactualEX-originalLinuxcredentials/allFD-interpreter-delegate-descendantclosure.6BEFORE6AFTERnew SAMEoriginalRootboundwait10 each5zero1three/cachedpossible;8affectedfinishwaits separate7zero1three. ROOTknownFD-log-journal devino cleanup AFTERviews/assertions UNITnotSourcecleanup-recovery-EXrelease; newharness closesnativeRaw once, callsBufferedclose onlyifdistinctobject, doesnotreclosealreadyclosednativeFileIO. Setup/internalFD/APIfactsnotallserialized/no globalabsence-fullreap-reconstruction.',
 'Qwen44157status0/full2876stdout487stderr/fullanswer ROOTqualified/rejectexpectedprebarrieremptyregistry/secondSourcefinish/lenientdigest acceptance advice. GLM44756status0/full3487stdout858stderr/fullanswer ROOTqualified: False-uppercase SourceProducerError priority intentional/ROOTFirstneverraised/exacttype alreadyasserted/recordprimaryvisible; synchronouscallbacksneverstored/replayed sofuturelatebinding theorynotbug; mutableoutputs/glob data notimmutableownership/currentimage proof/no freezeorrehashreplay. DarwinPOSIXunits notWindows/fullLinuxproof. Modelv1 seesfinalcandidatev1/privatev1beforefirstBEFORE/no candidate-harness-Source-modelreplay; ROOTwholefinalSource-tests-AST independentlyqualified NOTwholecurrentapproval.',
 'Strongowner/groups/primary-secondary/rows/originalrefs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. NamedcontrollersBEFOREcalls/availableactualAPIreturnsretained/omissionsnotreconstructed. No newharnessERROR. All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact; no Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse. Storagefloors/recheck DATAnotbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.'
 ]
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=6,failures=4,passes=2,errors=0,scope='2invalidoutputdigestreturns accepted+2oldfirstalreadyescapes/enclosingcontinuation policies NOT4nativebugs/RAMcause'),after=a,
 ROOT=dict(whole_final_Source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,result_literal_AST_equivalent=True,oldtests_BYTES_PREFIX_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=12,affected_finish_views=8,parent_BEFORE_EXverify_None=12,parent_AFTER_EXverify_None=48,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup,allotherSource_methods_modulehelpers_endcommand_wait_Aux_Popen_constructors_factories_sharedstep_frozenpredicates_exact=True),
 models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True,model_v1_before_final_v1_Sourceedit=True),limits=limits,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_early_finish_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Producer_early_finish_selected24PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected24PASS=True,new_views=12,affected_views=8,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
