"""NEW early finish output-setup barriers; native fixture artifact only."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class ProducerEarlyFinishTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)



    def _early_case(self,mode):
        calls=[];actors=[];seen={};leases=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT early finish first')
        native_allocate=producer.CommandProducer._allocate_command_process
        native_preserve=producer.CommandProducer._preserve_failure
        native_hash=producer._regular_hash;native_write=producer._write_json;native_event=producer.CommandProducer._event;native_str=Path.__str__
        body=b'EARLY-own-artifact-\x00\xff'
        artifact=self.base/'own-artifact.bin'
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def preserving(p,error):
            calls.append(dict(kind='forbidden_preserver',input_first=error is first));return native_preserve(p,error)
        def stringing(path):
            target=path is seen.get('output_path')
            if target:
                calls.append(dict(kind='output_path_str_attempt'))
                if mode=='normal_failed':raise first
            raw=native_str(path)
            if target:
                calls.append(dict(kind='output_path_str_actual_return',native=raw))
                if mode=='str_unknown':raise first
            return raw
        def hashing(path):
            target=path.name=='own-artifact.bin'
            if target:calls.append(dict(kind='output_hash_attempt'))
            raw=native_hash(path)
            if target:
                calls.append(dict(kind='output_hash_actual_return',native=raw))
                if mode=='hash_unknown':raise first
                if mode=='hash_False':return False
                if mode=='hash_upper':return raw.upper()
            return raw
        def writing(path,value):
            if path.name=='result.json':calls.append(dict(kind='result_write_attempt'))
            return native_write(path,value)
        def event(p,name,**fields):
            if name=='finished':calls.append(dict(kind='finished_event_attempt'))
            return native_event(p,name,**fields)
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer.CommandProducer,'_preserve_failure',preserving),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer.CommandProducer,'_event',event):
                code="import os;"
                if mode!='normal_failed':code+="fd=os.open("+repr(str(artifact))+",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.write(fd,"+repr(body)+");os.close(fd);"
                code+="os.write(1,b'EARLY-out');os.write(2,b'EARLY-err')"
                if mode=='normal_failed':code+=";os._exit(3)"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],outputs={'own_artifact':artifact},lease_check=verifying)
                seen['output_path']=p.outputs['own_artifact'];seen['outputs']=p.outputs
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(Path,'__str__',stringing):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                guard=getattr(producer,'_finish_publication_guard',None)
                if mode not in ('normal','normal_failed') and guard is not None:
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in getattr(producer,'_FINISH_PUBLICATION_RECORDS',[]) if r.get('owner') is p]
            record=records[-1] if records else None;rows=[] if record is None else record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,result_status=None if result is None else result['status'],
                received_type=None if received is None else type(received).__name__,received_first=received is first,
                Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],
                Source_evidence_complete=p.evidence_complete,Source_result_None=p.result is None,original_journal_closed=seen['journal']['obj'].closed,
                Source_events_original=p.events is seen['journal']['obj'],Source_outputs_original=p.outputs is seen['outputs'],
                failure_exists=(p.directory/'failure.json').exists(),result_exists=(p.directory/'result.json').exists(),
                guard_present=guard is not None,pure_guard_same_received=received is not None and guard_error is received,record_present=record is not None,
                record_original_journal=False if record is None else record.get('events') is seen['journal']['obj'],
                record_original_outputs=False if record is None else record.get('outputs') is seen['outputs'],
                record_primary_received=False if record is None else record.get('primary_error') is received,record_completed=None if record is None else record.get('completed'),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,raw_upper_digest=type(r['raw']) is str and len(r['raw'])==64 and r['raw'].upper()==r['raw'],error_first=r.get('error') is first) for r in rows],
                output_sha=None if result is None or not result['outputs'] else result['outputs']['own_artifact']['sha256'],
                output_artifact_exists=artifact.exists(),calls=list(calls),leases=leases,
                limits='OWNunit artifact notbenchmark/SDK. Source unknown Pathstr/hash returns notfilled ROOTknownstr/digest. Negativeonlypureguard/Rootsameboundwait+devinoFDcleanup AFTERevidence UNITnotSourcecleanup-ownership-fullEX-originalLinuxcredentials/fullclosure/admission. No callerdatarestore-copyfreeze/extra Pathcallback/replay.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases));self.assertTrue(p.outputs is seen['outputs'])
            if mode in ('normal','normal_failed'):
                self.assertTrue(returned);self.assertIsNotNone(result);self.assertIsNone(received)
                self.assertEqual('failed' if mode=='normal_failed' else 'success',result['status'])
                self.assertEqual(3 if mode=='normal_failed' else 0,result['commands'][0]['returncode'])
                self.assertEqual(b'EARLY-outEARLY-err',(p.directory/'command-000.log').read_bytes());self.assertTrue(p.evidence_complete)
                if mode=='normal':
                    self.assertEqual(body,artifact.read_bytes());self.assertEqual(hashlib.sha256(body).hexdigest(),result['outputs']['own_artifact']['sha256'])
                    self.assertEqual(str(artifact),result['outputs']['own_artifact']['path']);self.assertEqual(2,sum(x['kind']=='output_path_str_attempt' for x in calls))
                else:
                    self.assertEqual({},result['outputs']);self.assertFalse(artifact.exists());self.assertFalse(any(x['kind'].startswith('output_') for x in calls))
                if record is not None:self.assertTrue(record['completed'])
            else:
                self.assertFalse(returned)
                if mode in ('hash_False','hash_upper'):self.assertTrue(type(received) is producer.ProducerError)
                else:self.assertTrue(received is first)
                self.assertFalse(any(c['kind'] in ('forbidden_preserver','repr_first','note_first','result_write_attempt','finished_event_attempt') for c in calls))
                self.assertTrue(guard_error is received);self.assertTrue(record is not None);self.assertTrue(record['events'] is seen['journal']['obj'])
                self.assertTrue(record['outputs'] is seen['outputs']);self.assertTrue(record['primary_error'] is received);self.assertFalse(record['completed'])
                self.assertFalse(p.evidence_complete);self.assertTrue(p.finished);self.assertFalse(p.pending);self.assertIsNone(p.result)
                self.assertFalse((p.directory/'failure.json').exists());self.assertFalse((p.directory/'result.json').exists())
                self.assertFalse(seen['journal']['obj'].closed);self.assertTrue(p.events is seen['journal']['obj'])
                stages=['output_pattern','output_path','output_hash'];self.assertEqual(stages[:1] if mode=='str_unknown' else stages,[r['stage'] for r in rows])
                if mode in ('str_unknown','hash_unknown'):self.assertFalse(rows[-1]['returned']);self.assertIsNone(rows[-1]['raw'])
                elif mode=='hash_False':self.assertTrue(rows[-1]['returned']);self.assertTrue(rows[-1]['raw'] is False)
                else:self.assertTrue(rows[-1]['returned']);self.assertTrue(type(rows[-1]['raw']) is str and rows[-1]['raw'].upper()==rows[-1]['raw'])
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('earlyfinish pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==(3 if mode=='normal_failed' else 0))
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed and item['obj'] is not raw:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')


    def test_actual_output_path_string_then_error_stops_before_hash(self):self._early_case('str_unknown')
    def test_actual_output_hash_then_error_stops_before_payload(self):self._early_case('hash_unknown')
    def test_actual_output_hash_then_False_refused_before_publication(self):self._early_case('hash_False')
    def test_actual_output_hash_then_uppercase_refused_before_publication(self):self._early_case('hash_upper')
    def test_new_normal_actualoutput_bytes_digest_and_callback_count(self):self._early_case('normal')
    def test_new_normal_failed_exit3_skips_all_output_setup(self):self._early_case('normal_failed')
