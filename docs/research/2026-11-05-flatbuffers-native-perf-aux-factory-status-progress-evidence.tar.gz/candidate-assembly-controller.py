import sys,pathlib,ast,json,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-status-progress-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();s=(P/'before-producer.py').read_text();old="            status=call('result_status',lambda:result.__getitem__,('status',))\n            check_suffix()\n            if status!='success':raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+str(result['primary_error']))";new="            status=call('result_status',lambda:result.__getitem__,('status',))\n            if type(status) is not str or status not in ('success','failed'):\n                raise ProducerError('unknown auxiliary result status')\n            check_suffix()\n            if status!='success':\n                primary=call('failure_primary',lambda:result.__getitem__,('primary_error',))\n                if primary is not None and type(primary) is not str:\n                    raise ProducerError('unknown auxiliary failure detail')\n                check_suffix()\n                detail=call('failure_detail',lambda:str,(primary,))\n                if type(detail) is not str:\n                    raise ProducerError('unknown auxiliary failure text')\n                check_suffix()\n                raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+detail)"
 assert s.count(old)==1
 candidate=s.replace(old,new,1);ast.parse(candidate);assert candidate.replace(new,old,1)==s
 (P/'candidate-v1.py').open('x').write(candidate)
 (P/'projection-parts.json').open('x').write(json.dumps(dict(old=old,new=new),indent=2))
 (P/'candidate-ROOT-projection.json').open('x').write(json.dumps(dict(wholeSource_BYTE_projectsback=True,source_sha256=hashlib.sha256(candidate.encode()).hexdigest(),candidate_UNEXECUTED=True,only_status_detail_block_changed=True),indent=2))
 b=json.loads((P/'before-units/result.json').read_text());assert(b['tests'],b['failures'],b['errors'],b['passes'])==(8,5,0,3)
 views=[json.loads(f.read_text()) for f in sorted((P/'before-units/fixtures').glob('*/view-before-ROOT-cleanup.json'))]
 assert len(views)==8
 (P/'before-views-index.json').open('x').write(json.dumps(views,indent=2))
 l.verify_identity();print(json.dumps(dict(candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),before8='5FAIL3PASS0ERROR',views=8,candidate_UNEXECUTED=True)))
