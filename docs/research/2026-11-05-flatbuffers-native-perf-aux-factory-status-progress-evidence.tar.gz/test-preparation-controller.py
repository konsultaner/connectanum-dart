import sys,pathlib,ast,json
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-factory-status-progress-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity()
 old=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-suffix-progress-v1/aux_factory_suffix_regressions-v2.py').read_text()
 s=old.replace('AuxiliaryFactorySuffixTests','AuxiliaryFactoryStatusTests').replace('_suffix_case','_status_case').replace('aux-suffix-','aux-status-').replace('CONNECTANUM_AUX_SUFFIX_FIXTURES','CONNECTANUM_AUX_STATUS_FIXTURES').replace('suffix-a','status-a')
 x="        first=First('ROOT after original suffix call')"
 y="""        first=First('ROOT failed-detail conversion first')
        failed=mode in ('primary_fault','primary_drift','missing_primary','normal_failed_str','normal_failed_None')
        expected_exit=3 if failed else 0
        class UnknownStatus:
            def __ne__(self,other):
                render.append('status_ne')
                if mode=='status_drift':owner.auxiliary_operations=[]
                return False
        class UnknownDetail:
            def __str__(self):
                render.append('detail_str')
                if mode=='primary_fault':raise first
                owner.auxiliary_operations=[]
                return 'ROOT foreign rendered detail'
"""
 assert s.count(x)==1;s=s.replace(x,y)
 a=s.index('        def foreign_wait(');b=s.index('        marker=object();',a)
 s=s[:a]+"""        def starting(a):
            events.append(dict(kind='start_attempt'))
            raw=native_start(a);seen['main']=a
            events.append(dict(kind='actual_start_return',raw_None=raw is None))
            return raw
        def waiting(a,timeout):
            events.append(dict(kind='wait_attempt',timeout=timeout))
            raw=native_wait(a,timeout);seen['actual_main_result']=raw
            events.append(dict(kind='actual_wait_return',raw_None=raw is None))
            if raw is not None:
                if mode in ('status_lie','status_drift'):raw['status']=UnknownStatus()
                if mode in ('primary_fault','primary_drift'):raw['primary_error']=UnknownDetail()
                if mode=='missing_primary':del raw['primary_error']
                if mode=='normal_failed_None':raw['primary_error']=None
            return raw
"""+s[b:]
 a=s.index("                if mode=='foreign_result':");b=s.index('                except BaseException as error:received=error',a)
 s=s[:a]+"""                try:result=producer._observe_auxiliary(owner,'status-a',[sys.executable,'-c',"import os,sys;os.write(1,b'STATUS-A');os.write(2,b'STATUS-err');sys.exit("+str(expected_exit)+")"],stdout_max=1024)
"""+s[b:]
 s=s.replace("if mode!='normal_false_none':","if mode!='normal_success':")
 a=s.index('            rows=[r for r in attempt.steps');b=s.index('            (base/\'view-before-ROOT-cleanup.json\')',a)
 s=s[:a]+"""            rows=[r for r in attempt.steps if r['stage'].startswith('failure_') or r['stage']=='result_status']
            main_waits=[e for e in events if e['kind']=='wait_attempt']
            def raw_kind(v):return 'None' if v is None else type(v).__name__
            view=dict(mode=mode,expected_exit=expected_exit,events=events,leases=leases,received_type=None if received is None else type(received).__name__,
                received_original=received is first,received_text=BaseException.__str__(received) if type(received) is producer.ProducerError else None,
                factory_completed=attempt.completed,factory_first_received=received is not None and attempt.first_error is received,
                pure_guard_first_is_received=received is not None and guard_error is received,
                result_is_own_current=a is not None and result is a.result and result is not None,
                original_owner_count=len(original_list),current_owner_count=len(owner.auxiliary_operations),owner_alias_same=owner.auxiliary_operations is original_list,
                main_wait_attempts=len(main_waits),main_wait_args=[e['timeout'] for e in main_waits],Source_render_before_asserts=list(render),
                Source_operation_pending=a.pending,Source_operation_finished=a.finished,Source_returncode=a.status,
                result_status_type=type(a.result['status']).__name__,result_status_native=a.result['status'] if type(a.result['status']) is str else None,
                Source_status_rows=[dict(stage=r['stage'],returned=r['returned'],raw_kind=raw_kind(r['raw']),raw_None=r['raw'] is None,error_is_received=received is not None and r['error'] is received) for r in rows],
                limits='Actualown native result mutated in memory after real wait; controlled invalidvalues notspontaneouskernelbug/RAMcause. Callback/type/status/result facts DATA notauth-ABA-ownership-EX/admission. Known ROOTwait/resources afterevidence UNITonly.')
"""+s[b:]
 a=s.index('            try:\n                self.assertEqual([],render)');b=s.index('\n        finally:\n            cleanup=[]',a)
 s=s[:a]+"""            self.assertEqual([],render);self.assertTrue(all(x['raw_None'] for x in leases))
            self.assertTrue(a.finished);self.assertFalse(a.pending);self.assertEqual(expected_exit,a.status)
            self.assertEqual([60],view['main_wait_args'])
            self.assertEqual(b'STATUS-A',(directory/'status-a.stdout').read_bytes());self.assertEqual(b'STATUS-err',(directory/'status-a.stderr').read_bytes())
            if mode=='normal_success':
                self.assertIsNone(received);self.assertIs(result,a.result);self.assertEqual('success',result['status']);self.assertTrue(attempt.completed)
            else:
                if mode=='missing_primary':self.assertIs(type(received),KeyError)
                else:self.assertIs(type(received),producer.ProducerError)
                self.assertIs(attempt.first_error,received);self.assertIs(guard_error,received);self.assertFalse(attempt.completed)
                self.assertIs(owner.auxiliary_operations,original_list);self.assertEqual([a],original_list)
                if mode=='missing_primary':
                    row=next((r for r in rows if r['stage']=='failure_primary'),None);self.assertIsNotNone(row,'failed primary lookup intent missing')
                    self.assertFalse(row['returned']);self.assertIsNone(row['raw']);self.assertIs(row['error'],received)
                if mode in ('normal_failed_str','normal_failed_None'):
                    expected_detail='auxiliary command nonzero or signal' if mode=='normal_failed_str' else 'None'
                    self.assertEqual('auxiliary Git observation failed; owned status/raw streams retained: '+expected_detail,view['received_text'])
                    found=[r for r in rows if r['stage']=='failure_detail']
                    if found:self.assertTrue(found[0]['returned']);self.assertIs(type(found[0]['raw']),str)
                count=len(events)
                try:producer._auxiliary_factory_guard(owner)
                except BaseException as error:self.assertIs(error,received)
                else:self.fail('permanently refused factory guard returned')
                self.assertEqual(count,len(events))
"""+s[b:]
 s=s.replace("self.assertTrue(type(raw) is int and raw==0)","self.assertTrue(type(raw) is int and raw==expected_exit)")
 a=s.index('    def test_actual_wait_then_foreign_completed_operation_result_is_refused(')
 s=s[:a]+"""    def test_actual_success_then_lying_status_never_compares(self):self._status_case('status_lie')
    def test_actual_success_then_status_callback_cannot_mutate_owner(self):self._status_case('status_drift')
    def test_actual_nonzero_then_hostile_detail_never_renders(self):self._status_case('primary_fault')
    def test_actual_nonzero_then_detail_callback_cannot_mutate_owner(self):self._status_case('primary_drift')
    def test_actual_nonzero_then_missing_primary_retains_lookup_error(self):self._status_case('missing_primary')
    def test_new_actual_nonzero_normal_native_detail_and_full_bytes(self):self._status_case('normal_failed_str')
    def test_new_actual_nonzero_normal_None_detail_contract(self):self._status_case('normal_failed_None')
    def test_new_actual_success_normal_new_full_bytes(self):self._status_case('normal_success')
"""
 s=s.replace('NEW original factory suffix controls; no Source recovery after refusal.','NEW original factory status/error-detail controls; no Source recovery after refusal.')
 ast.parse(s);(P/'factory_status_regressions-v1.py').open('x').write(s)
 assert s.count('def test_')==8
 notes=dict(infrastructure='Knownfinite process/boundwait/FDrefs/evidencegatedROOTcleanup copied from consumed suffixv2 for NEW8 only; old7 notexecutedhere',
  actual_nonzero_status='5knownactors expected signed3;3expected signed0 perphase; never coerce unknown to0',
  controls='2lyingstatuscallbacks+2foreignstrcallbacks+1missingprimary witness+3newnative/None/success normals',
  source_controller='Exactstring storedBEFOREinlineEXdeclaration; controllerfile savedAFTERcall, notfile-beforecall proof')
 (P/'harness-preparation.json').open('x').write(json.dumps(notes,indent=2))
 l.verify_identity();print('NEW8 private v1 AST prepared; unexecuted')
