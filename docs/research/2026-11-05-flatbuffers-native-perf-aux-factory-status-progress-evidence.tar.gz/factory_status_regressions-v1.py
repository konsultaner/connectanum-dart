"""NEW original factory status/error-detail controls; no Source recovery after refusal."""
from pathlib import Path
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock
import native_perf_build_producer as producer


class AuxiliaryFactoryStatusTests(unittest.TestCase):
    def _status_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-status-'+mode+'-',dir=os.environ.get('CONNECTANUM_AUX_STATUS_FIXTURES',tempfile.gettempdir()))).resolve()
        directory=base/'a';directory.mkdir()
        owner=types.SimpleNamespace(directory=directory,repo=base,environment=dict(os.environ),lease_check=None,auxiliary_operations=[])
        original_list=owner.auxiliary_operations;events=[];actors=[];resources=[];render=[];leases=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT failed-detail conversion first')
        failed=mode in ('primary_fault','primary_drift','missing_primary','normal_failed_str','normal_failed_None')
        expected_exit=3 if failed else 0
        class UnknownStatus:
            def __ne__(self,other):
                render.append('status_ne')
                if mode=='status_drift':owner.auxiliary_operations=[]
                return False
        class UnknownDetail:
            def __str__(self):
                render.append('detail_str')
                if mode=='primary_fault':raise first
                owner.auxiliary_operations=[]
                return 'ROOT foreign rendered detail'

        cls=producer.AuxiliaryCommand;native_start=cls.start;native_wait=cls.wait;native_allocate=cls._allocate_process
        foreign_marker={'status':'success','primary_error':None,'ROOT_foreign':True}
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        owner.lease_check=verifying
        def allocating(a,record):
            # Actual own resource references BEFORE further setup/native spawn.
            for role,stream in a.streams.items():
                item=dict(operation=a,role=role,fd=stream.get('fd'),log=stream.get('log'),path=stream['path'],fd_identity=None,log_identity=None,log_close=None)
                resources.append(item)
                if type(item['fd']) is int:
                    info=os.fstat(item['fd']);item['fd_identity']=(info.st_dev,info.st_ino)
                if item['log'] is not None:
                    item['log_close']=item['log'].close
                    info=os.fstat(item['log'].fileno());item['log_identity']=(info.st_dev,info.st_ino)
            raw=native_allocate(a,record)
            actors.append(dict(process=raw,bound_wait=raw.wait,operation=a))
            events.append(dict(kind='actual_process_return',is_main=a.name=='status-a',pid=raw.pid))
            return raw
        def starting(a):
            events.append(dict(kind='start_attempt'))
            raw=native_start(a);seen['main']=a
            events.append(dict(kind='actual_start_return',raw_None=raw is None))
            return raw
        def waiting(a,timeout):
            events.append(dict(kind='wait_attempt',timeout=timeout))
            raw=native_wait(a,timeout);seen['actual_main_result']=raw
            events.append(dict(kind='actual_wait_return',raw_None=raw is None))
            if raw is not None:
                if mode in ('status_lie','status_drift'):raw['status']=UnknownStatus()
                if mode in ('primary_fault','primary_drift'):raw['primary_error']=UnknownDetail()
                if mode=='missing_primary':del raw['primary_error']
                if mode=='normal_failed_None':raw['primary_error']=None
            return raw
        marker=object();result=marker;received=None;guard_error=None
        try:
            with mock.patch.object(cls,'_allocate_process',allocating),mock.patch.object(cls,'start',starting),mock.patch.object(cls,'wait',waiting):
                try:result=producer._observe_auxiliary(owner,'status-a',[sys.executable,'-c',"import os,sys;os.write(1,b'STATUS-A');os.write(2,b'STATUS-err');sys.exit("+str(expected_exit)+")"],stdout_max=1024)
                except BaseException as error:received=error
                if mode!='normal_success':
                    try:producer._auxiliary_factory_guard(owner)
                    except BaseException as error:guard_error=error
            found=[r for r in producer._AUXILIARY_FACTORY_ATTEMPTS if r.owner is owner];attempt=found[-1]
            a=attempt.operation
            rows=[r for r in attempt.steps if r['stage'].startswith('failure_') or r['stage']=='result_status']
            main_waits=[e for e in events if e['kind']=='wait_attempt']
            def raw_kind(v):return 'None' if v is None else type(v).__name__
            view=dict(mode=mode,expected_exit=expected_exit,events=events,leases=leases,received_type=None if received is None else type(received).__name__,
                received_original=received is first,received_text=BaseException.__str__(received) if type(received) is producer.ProducerError else None,
                factory_completed=attempt.completed,factory_first_received=received is not None and attempt.first_error is received,
                pure_guard_first_is_received=received is not None and guard_error is received,
                result_is_own_current=a is not None and result is a.result and result is not None,
                original_owner_count=len(original_list),current_owner_count=len(owner.auxiliary_operations),owner_alias_same=owner.auxiliary_operations is original_list,
                main_wait_attempts=len(main_waits),main_wait_args=[e['timeout'] for e in main_waits],Source_render_before_asserts=list(render),
                Source_operation_pending=a.pending,Source_operation_finished=a.finished,Source_returncode=a.status,
                result_status_type=type(a.result['status']).__name__,result_status_native=a.result['status'] if type(a.result['status']) is str else None,
                Source_status_rows=[dict(stage=r['stage'],returned=r['returned'],raw_kind=raw_kind(r['raw']),raw_None=r['raw'] is None,error_is_received=received is not None and r['error'] is received) for r in rows],
                limits='Actualown native result mutated in memory after real wait; controlled invalidvalues notspontaneouskernelbug/RAMcause. Callback/type/status/result facts DATA notauth-ABA-ownership-EX/admission. Known ROOTwait/resources afterevidence UNITonly.')
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual([],render);self.assertTrue(all(x['raw_None'] for x in leases))
            self.assertTrue(a.finished);self.assertFalse(a.pending);self.assertEqual(expected_exit,a.status)
            self.assertEqual([60],view['main_wait_args'])
            self.assertEqual(b'STATUS-A',(directory/'status-a.stdout').read_bytes());self.assertEqual(b'STATUS-err',(directory/'status-a.stderr').read_bytes())
            if mode=='normal_success':
                self.assertIsNone(received);self.assertIs(result,a.result);self.assertEqual('success',result['status']);self.assertTrue(attempt.completed)
            else:
                if mode=='missing_primary':self.assertIs(type(received),KeyError)
                else:self.assertIs(type(received),producer.ProducerError)
                self.assertIs(attempt.first_error,received);self.assertIs(guard_error,received);self.assertFalse(attempt.completed)
                self.assertIs(owner.auxiliary_operations,original_list);self.assertEqual([a],original_list)
                if mode=='missing_primary':
                    row=next((r for r in rows if r['stage']=='failure_primary'),None);self.assertIsNotNone(row,'failed primary lookup intent missing')
                    self.assertFalse(row['returned']);self.assertIsNone(row['raw']);self.assertIs(row['error'],received)
                if mode in ('normal_failed_str','normal_failed_None'):
                    expected_detail='auxiliary command nonzero or signal' if mode=='normal_failed_str' else 'None'
                    self.assertEqual('auxiliary Git observation failed; owned status/raw streams retained: '+expected_detail,view['received_text'])
                    found=[r for r in rows if r['stage']=='failure_detail']
                    if found:self.assertTrue(found[0]['returned']);self.assertIs(type(found[0]['raw']),str)
                count=len(events)
                try:producer._auxiliary_factory_guard(owner)
                except BaseException as error:self.assertIs(error,received)
                else:self.fail('permanently refused factory guard returned')
                self.assertEqual(count,len(events))

        finally:
            cleanup=[]
            for actor in actors:
                raw=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_bounded_wait',pid=actor['process'].pid,status=raw,cached_possible=True));self.assertTrue(type(raw) is int and raw==expected_exit)
            for index,item in enumerate(resources):
                if not evidence_ready:
                    cleanup.append(dict(kind='ROOT_resource_NOread_NOclose_before_evidence',role=item['role']));continue
                row=dict(kind='ROOT_known_unit_resource',role=item['role'],fd_close=False,log_close=False,fd_identity_match=None,log_identity_match=None)
                fd=item['fd']
                if type(fd) is int:
                    try:
                        info=os.fstat(fd);same=(info.st_dev,info.st_ino)==item['fd_identity'];row['fd_identity_match']=same
                        if same:
                            captured=b'';reads=[]
                            for _ in range(4):
                                try:part=os.read(fd,65536)
                                except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                                reads.append(dict(returned=True,size=len(part)));captured+=part
                                if not part:break
                            (base/('ROOT-pipe-'+str(index)+'.bin')).write_bytes(captured);row['ROOT_reads_after_evidence']=reads
                            os.close(fd);row['fd_close']=True
                    except OSError as error:row['fd_error_errno']=error.errno
                f=item['log']
                if f is not None and not f.closed:
                    try:
                        ainfo=os.fstat(f.fileno());binfo=item['path'].stat();same=(ainfo.st_dev,ainfo.st_ino)==item['log_identity']==(binfo.st_dev,binfo.st_ino);row['log_identity_match']=same
                        if same:item['log_close']();row['log_close']=True
                    except (OSError,ValueError) as error:row['log_error_type']=type(error).__name__
                cleanup.append(row)
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_success_then_lying_status_never_compares(self):self._status_case('status_lie')
    def test_actual_success_then_status_callback_cannot_mutate_owner(self):self._status_case('status_drift')
    def test_actual_nonzero_then_hostile_detail_never_renders(self):self._status_case('primary_fault')
    def test_actual_nonzero_then_detail_callback_cannot_mutate_owner(self):self._status_case('primary_drift')
    def test_actual_nonzero_then_missing_primary_retains_lookup_error(self):self._status_case('missing_primary')
    def test_new_actual_nonzero_normal_native_detail_and_full_bytes(self):self._status_case('normal_failed_str')
    def test_new_actual_nonzero_normal_None_detail_contract(self):self._status_case('normal_failed_None')
    def test_new_actual_success_normal_new_full_bytes(self):self._status_case('normal_success')
