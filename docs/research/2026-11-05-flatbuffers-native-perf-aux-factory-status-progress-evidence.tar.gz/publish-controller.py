import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-status-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-aux-factory-status-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='b4655cbe4a998f8e9bfefe43cf98aac90a185abf'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Validate Auxiliary result values before callbacks\n\nA controlled status value in an actual completed operation's mutable result can make the old factory accept invalid status and mutate its owner ledger through comparison. The factory now requires native success/failed strings before comparing and native string/None failure detail before rendering. Detail lookup/render intent and actual returns retain first without invoking unknown callbacks. Normal nonzero/native-string and None messages, success bytes and missing-key KeyError remain intact. Result values and completion facts remain DATA, not credentials, ownership, EX or admission.\n\nNEW8 at710fcb/3dd46b yields5FAIL/3normalPASS/0ERROR:2invalid-status comparison cases,2unsupported detail-render callbacks and1stronger missing-key witness policy, not five native defects or a RAM cause. Final337ef3/0e0013 passes30selected=8matchingNEW+22affected(7suffix/7factory/8CommandProducer Git-receipt callers), not aggregate/current20canonical/admission. ROOT qualifies whole source/tests/AST/byte projection,23hashes/other18helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty. Qwen23084/GLM23497 complete0/fullanswers are ROOTqualified; incorrect review claims and withdrawals are retained. Sixteen new views/16BEFORE60AFTER currentDarwinEX observations and8BEFORE8AFTER SAMEactor ROOTwait10 (3status0/5status3 each phase, cached possible) remain UNIT facts, not full independent EX/original Linux credentials. Controller/API ordering qualifications retained. Other API/backingFD/enclosing/historical/transitive/fullindependentEX/runtime immutableCOMPLETE admission remain incomplete. No SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-aux-factory-status-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: validate Auxiliary status and failure detail'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_factory_status_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Remainingstatus-detail/earlierwriter-hash-init APInegative seams/actualFileIO backingwriters-internalFD errors; enclosingproducer cleanup/reporting; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedjournalwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Current337ef3/0e0013 ONLYfactory status/detail nativevalue guards + lookup/render intent-raw-first scopedcomplete30selectedPASS=8matchingNEW+22affected(7suffix7factory8CommandProducer). Before710fcb/3dd46bNEW8=5FAIL3normalPASS0ERROR/2invalidstatuscomparison cases+2unsupporteddetailcallbacks+1missinglookupwitnesspolicy NOT5nativekernelbugs/RAMcause. Validnonzero/native-string-None messages/missingkeyKeyError/successfullbytes preserved; no mutable-resultfreeze-copy-restore. Allpriorepochs historical/notcurrent20canonical/admission. Callerpostreturn cannotstopalreadyexecutedcalleeops; type/refs/status/finished/completed/sourcefacts DATAneverEXrelease/admission. UnknownPopenCtorpermanentrefusal/no field-derivedownerclose API; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; owner_emit_attempted/oldfreezeauxpredicates unchanged."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Auxiliary_status_scoped30PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
