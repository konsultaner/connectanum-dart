import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-factory-status-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());beforeh=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 parts=json.loads((P/'projection-parts.json').read_text());assert source==(P/'candidate-v1.py').read_text()
 assert source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'factory_status_regressions-v1.py').read_bytes()
 ast.parse(source);ast.parse(tests)
 assert sorted(k for k in h if h[k]!=beforeh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text())
 assert (b['tests'],b['failures'],b['passes'],b['errors'])==(8,5,3,0)
 assert (a['tests'],a['failures'],a['errors'])==(30,0,0)
 assert len(b['leases'])==16 and len(a['leases'])==60 and all(row['raw_None'] for row in b['leases']+a['leases'])
 def views(path):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if 'Source_status_rows' in v}
 old=views(P/'before-units/fixtures');new=views(P/'after-selected/fixtures');assert len(old)==len(new)==8
 for mode in ('status_lie','status_drift'):
  v=old[mode][0];assert v['factory_completed'] and v['received_type'] is None and v['result_is_own_current'] and v['Source_render_before_asserts']==['status_ne']
 assert not old['status_drift'][0]['owner_alias_same']
 assert old['primary_fault'][0]['received_original'] and old['primary_fault'][0]['Source_render_before_asserts']==['detail_str']
 assert old['primary_drift'][0]['Source_render_before_asserts']==['detail_str'] and not old['primary_drift'][0]['owner_alias_same']
 assert old['missing_primary'][0]['received_type']=='KeyError' and not any(r['stage']=='failure_primary' for r in old['missing_primary'][0]['Source_status_rows'])
 waits={};cleanup={}
 for phase,data in [('before',old),('after',new)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())]
  known=[r for r in rows if r['kind']=='ROOT_same_bounded_wait']
  assert len(known)==8 and all(type(r['status']) is int for r in known) and sorted(r['status'] for r in known)==[0,0,0,3,3,3,3,3]
  waits[phase]=known;cleanup[phase]=rows
 for mode,(v,d) in new.items():
  assert v['Source_render_before_asserts']==[] and all(row['raw_None'] for row in v['leases'])
  assert v['Source_operation_finished'] and not v['Source_operation_pending'] and v['Source_returncode']==v['expected_exit']
  assert v['main_wait_args']==[60] and v['owner_alias_same'] and v['original_owner_count']==v['current_owner_count']==1
  rows=v['Source_status_rows'];assert rows and rows[0]['stage']=='result_status' and rows[0]['returned']
  if mode=='normal_success':
   assert v['received_type'] is None and v['factory_completed'] and v['result_is_own_current'] and v['result_status_native']=='success'
   assert len(rows)==1
  else:
   assert v['factory_first_received'] and v['pure_guard_first_is_received'] and not v['factory_completed'] and not v['received_original']
   if mode=='missing_primary':
    assert v['received_type']=='KeyError';row=next(r for r in rows if r['stage']=='failure_primary')
    assert not row['returned'] and row['raw_None'] and row['error_is_received'] and not any(r['stage']=='failure_detail' for r in rows)
   else:assert v['received_type']=='ProducerError'
   if mode in ('status_lie','status_drift'):assert len(rows)==1 and rows[0]['raw_kind']=='UnknownStatus'
   if mode in ('primary_fault','primary_drift'):assert rows[-1]['stage']=='failure_primary' and rows[-1]['returned'] and rows[-1]['raw_kind']=='UnknownDetail'
   if mode in ('normal_failed_str','normal_failed_None'):
    assert [r['stage'] for r in rows]==['result_status','failure_primary','failure_detail']
    assert rows[-1]['returned'] and rows[-1]['raw_kind']=='str'
    suffix='auxiliary command nonzero or signal' if mode=='normal_failed_str' else 'None'
    assert v['received_text']=='auxiliary Git observation failed; owned status/raw streams retained: '+suffix
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 before=dict(tests=8,failures=5,passes=3,errors=0,scope='2invalidstatus accepted viaforeigncomparison inclownerdrift;2unsupportedprimarystrinvocations;1missinglookupintentpolicy. NOT5nativekernelbugs/RAMcause.'),after=a,
 ROOT=dict(whole_final_source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=16,parent_BEFORE_EXverify_None=16,parent_AFTER_EXverify_None=60,known_same_bounded_waits=waits,known_unit_cleanup=cleanup,original_Aux_Popen_sharedstep_earlyinit_allocation_publicconstructor_otherfactories_methodbindings_frozenpredicates_resultliteral_exact=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM=json.loads((P/'candidate-review/result.json').read_text()),advisory_ROOTqualified_NOTwholecurrentapproval=True),
 limits=['ONLYselectedfactory status/detail caller scope. Actualownresult mutated in memory AFTERrealwait; no foreigndictsubstitution or artifactrewrite; controlledinvalidvalue integrity/policy notspontaneouskernelbug/RAMcause.',
 'Exactnative str status success/failed BEFOREforeigncomparison;primary None/exactnative str BEFOREstr. Unknown/error raw preserved; missingkey oldfirstalreadyescapes/newexplicitrowpolicy notnewnativeerror. Validnormalfailurestring/None messages/fullbytes/success retained.',
 'Callerpost-return cannotstopalreadyperformed nativecallee operations. Currentmutable dict notfrozen/copied/restored; field/type/refs/status/completion/hash facts DATA notsemanticimageauth-ABA-credentials-ownership-physicalEX/admission.',
 '16newviews only(8BEFORE8AFTER),16BEFORE60AFTER parentCURRENT officialDarwinEXverifyNone;8BEFORE8AFTER knownSAMEboundRootwait10 statuses3zero5three eachphase/cachedpossible UNITnotindependentphysicalEX-originalLinuxcredentials-fullFD-interpreter-delegate-descendantclosure. Signed3 are expectedfiniteunitexit, notunknown0 or benchmark/setupretry.',
 'KnownoriginalFDrefs ROOTidentitycheck/cleanupAFTERevidence only UNITnotlivecleanup-EXrelease. ActualSourcewait completed selectednativeprocess/logfinalization beforevalueinjection; no allbackingFD/API/descendant census/fullreap or reconstruction.',
 'Sourcecontroller exactstring stored BEFOREinlineEXdeclaration/file saved AFTERcall; privateharnesspreparation stringstored BEFOREartifactcall/file AFTER. Later namedcontrollers BEFOREcalls. AvailableactualAPIreturns only; some initial toolAPIreturns notseparatelysaved/notreconstructed; originalmodel/test/source/artifact raws retained.',
 'Sharedstep/earlyinit/Popen/sourcefactories/frozenpredicates unchanged; oldprefix/sourcebyteprojectback. No oldbeforecontrol/numerical/model replay;30selected=8matchingNEW+22affected(7suffix7factory8CommandProducer), notaggregate/fullcurrent20canonical/admission.',
 'All20helpers uncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no actualSDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-adoption-RAMrepair-strictacceptance.',
 'Registry-env-journal-ref-closure-traceback/raw growthUNMEASURED/notexactheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority.',
 'Metadata/otherunsupportedreturnshapes/globalbuiltinsbinding/concurrentABA/earlierwriter-hash-init APIs/backingFileIO-internalFD/enclosingproducer/historical-transitiveunknownactors/fullindependentEX-originalruntimeimmutableCOMPLETEadmission remainINCOMPLETE.'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['auxiliary_factory_status_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Auxiliary_factory_status_selected30PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected30PASS=True,new_views=16,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
