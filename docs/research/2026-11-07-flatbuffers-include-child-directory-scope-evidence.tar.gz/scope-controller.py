import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-child-directory-scope-v1';O=B/'2026-11-07-actions-include-child-operand-source-alias-intake-v1/ROOT-FIRST-ALL2651-child-operand-source-alias-intake-PRIVATE.json';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST NEW expresslydeclared ALL63originalmode-directory child INPUT-scope preparation afterCONSUMED2651operandintake. Read ONLYexactoriginalsavedmetadata; declare EACHliteralparent+SINGLEliteralchildbasename as NEWlexicalTEXT BEFOREany SDKINPUTIO. Original1280separateparent-child flags/49queryepochs/1199latelexicalepoch/63DEFERREDflags/18rawlinksUNEXPANDED-UNFOLLOWED/oldtopncurses.h-curses.h rawhexNOTsavedNULL/ALLpriorledgers unchanged. NEWliteralreference-vs-priorCP scalar-consumption relationships are metadata only, NOTabsence/newness/alias/bodycoverage/access/ownership/effectivecompiler-sysroot-ABI/permission; nonmatches neverqueryauthority. No autojoin/resolve/follow/recursion/favorablelanguage-version-ABI/defaultcompiler filter/aliasdedup. No SDKquery/directoryquery/bodyread-hash/nativequery/Actions/import-headercompile-execute/bootstrap-build/numerical/Source20-runtime adoption. Pointmetadata sameFD/countSHA/stat/close notatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission.',
 'exact_original_saved_input':{'path':str(O),'range':[0,14348828],'bytes':14348828,'sha256':'24711b37181a40777e5f41872c6ab0af0167412795af6dd1f682e975a5882294'},
 'CP_saved_metadata_scope':{'path':str(CP),'range':'pointFDsize declared BEFOREcontentIO','purpose':'NEW ALL63literal candidate reference-consumption matching ONLY/notSDK-body-query-audit replay'},
 'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def metadata_read(path,size=None,expected=None,role=''):
  binding={'role':role,'path':str(path),'open_return_fd':None,'close_return_fd':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd
  try:
   s=os.fstat(fd);before={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']};assert stat.S_ISREG(s.st_mode);binding['before']=before
   if size is None:
    size=s.st_size;save('prior-CP-exact-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2))
   assert s.st_size==size;binding['declared_range']=[0,size];parts=[];sha=hashlib.sha256();count=0
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyEOF permanentquarantine';parts.append(chunk);sha.update(chunk);count+=len(chunk)
   assert os.read(fd,1)==b'';z=os.fstat(fd);after={k:getattr(z,k) for k in before};binding.update(after=after,bytes=count,sha256=sha.hexdigest(),EOF=True);assert before==after and count==size
   if expected is not None:assert sha.hexdigest()==expected
   return b''.join(parts)
  finally:
   os.close(fd);binding['close_return_fd']=fd
 originalraw=metadata_read(O,14348828,declaration['exact_original_saved_input']['sha256'],'ALL63_scope_original_savedmetadata_ONLY');original=json.loads(originalraw);entries=original['ALL1280_original_child_relationships_with_NEW_counts'];safe=[r['original_separate_parent_child_metadata'] for r in entries];dirs=[r for r in safe if r['saved_type_derived_from_original_mode']=='directory'];links=[r for r in safe if r['saved_type_derived_from_original_mode']=='symlink'];assert len(safe)==1280 and len(dirs)==63 and len(links)==18
 relations=[]
 for row in dirs:
  parent=row['literal_parent_reference_SEPARATE'];name=row['literal_child_name_SEPARATE'];assert name not in ['','.','..'] and '/' not in name and '\0' not in name and os.fsdecode(bytes.fromhex(row['original_name_bytes_hex']))==name and row['parent_child_NOT_joined_resolved_followed_or_executed'] is True
  ref=parent+'/'+name
  relations.append({'original_separate_parent_child_metadata':row,'NEW_explicit_lexical_candidate_reference':ref,'NEW_declaration_epoch':'ALL63_directory_INPUT_SCOPE_AFTER_complete2651operand_intake','new_literal_parent_plus_SINGLEliteralbasename_TEXT_ONLY':True,'filesystem_resolution_or_alias_identity':None,'original_separate_parent_child_DEFERRED_epochs_unchanged':True})
 refs=[r['NEW_explicit_lexical_candidate_reference'] for r in relations];assert len(refs)==63 and len(set(refs))==63
 scope={'phase':'ALL63_NEW_child_directory_INPUT_SCOPE_DECLARED_NOT_queried','ALL63_new_explicit_lexical_relations':relations,'ALL63_new_literal_directory_references':refs,'ALL1280_original_separate_child_metadata':safe,'ALL18_original_symlink_metadata_UNEXPANDED_UNFOLLOWED':original['ALL18_original_NEW_symlink_metadata_UNEXPANDED_UNFOLLOWED'],'ALL_original_child_scope_metadata_epochs_preserved':original['ALL_original_child_scope_metadata_epochs_preserved'],'ALL_original_prior_declared_metadata_preserved_NOT_revalidated':original['ALL_original_prior_declared_metadata_preserved_NOT_revalidated'],'ALL_original_NEW49_input_scope_preserved':original['ALL_original_NEW49_input_scope_preserved'],'source_original2651_summary_preserved_NOT_revalidated':original['summary'],'full_original_stat_times_CPmatches_PRIVATE_preserved':{'source':str(O),'bytes':14348828,'sha256':declaration['exact_original_saved_input']['sha256']},'new_directory_INPUT_queries':0,'recursive_queries':0,'new_headerbody_reads':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 scoped=(json.dumps(scope,ensure_ascii=True,indent=2)+'\n').encode();save('ALL63-exact-new-lexical-scope-BEFORE-INPUT-IO.json',scoped);save('original-full2651-metadata-bound-PRIVATE.json',originalraw)
 cpraw=metadata_read(CP,role='NEW63literalreference_prior_checkpoint_metadata_ONLY');prior=json.loads(cpraw);save('original-prior-CP-bound-PRIVATE.json',cpraw)
 scalars=[]
 def walk(x,path):
  if isinstance(x,str):scalars.append({'location':path,'value':x})
  elif isinstance(x,dict):
   for key,value in x.items():walk(value,path+[key])
  elif isinstance(x,list):
   for index,value in enumerate(x):walk(value,path+[index])
 walk(prior,[])
 matched=[];exacttotal=0;substringtotal=0
 for ordinal,relation in enumerate(relations,1):
  ref=relation['NEW_explicit_lexical_candidate_reference'];exact=[];mentions=[]
  for scalar in scalars:
   value=scalar['value']
   if value==ref:exact.append({'location':scalar['location'],'original_scalar':value})
   positions=[];start=0
   while True:
    found=value.find(ref,start)
    if found<0:break
    positions.append(found);start=found+1
   if positions:mentions.append({'location':scalar['location'],'original_scalar':value,'literal_substring_offsets':positions})
  exacttotal+=len(exact);substringtotal+=len(mentions)
  matched.append({'NEW_scope_position_ONE_based':ordinal,'original_and_NEW_separate_epoch_relation':relation,'ALL_prior_CP_exact_scalar_matches_PRIVATE':exact,'ALL_prior_CP_substring_matches_PRIVATE':mentions,'prior_CP_exact_scalar_match_count':len(exact),'prior_CP_substring_scalar_match_count':len(mentions),'candidate_requires_saved_scope_classification_before_query':bool(exact or mentions),'query_permission_from_matches_or_nonmatches':None,'alias_identity':None})
 with_exact=sum(x['prior_CP_exact_scalar_match_count']>0 for x in matched);with_substring=sum(x['prior_CP_substring_scalar_match_count']>0 for x in matched)
 summary={'ALL63_original_directory_record_count':63,'ALL63_express_new_literal_reference_count':63,'ALL1280_original_child_records_preserved':1280,'ALL18_symlink_records_unexpanded':18,'original63_DEFERRED_flags_unchanged':True,'prior_CP_string_scalar_count':len(scalars),'candidate_records_with_prior_CP_exact_scalar_matches':with_exact,'candidate_records_without_prior_CP_exact_scalar_matches':63-with_exact,'ALL_prior_CP_exact_scalar_match_relations':exacttotal,'candidate_records_with_prior_CP_substring_scalar_mentions':with_substring,'candidate_records_without_prior_CP_substring_scalar_mentions':63-with_substring,'ALL_prior_CP_substring_scalar_relations':substringtotal,'saved_metadata_read_binding_count':len(bindings),'new_exact_scope_bytes':len(scoped),'new_exact_scope_sha256':hashlib.sha256(scoped).hexdigest(),'new_directory_INPUT_queries':0,'new_headerbody_reads':0,'new_SDK_or_Actions_queries':0,'query_permission_from_matches_or_nonmatches':None,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'ALL63_NEW_literal_scope_metadata':scope,'ALL63_NEW_reference_consumption_relationships_PRIVATE':matched,'ALL_two_savedmetadata_read_bindings_PRIVATE_fullstat-times':bindings,'ALL1280_original_complete_relationship_records_PRIVATE_preserved':original['ALL1280_original_complete_relationship_records_PRIVATE'],'ALL49_original_parent_relationship_records_PRIVATE_preserved':original['ALL49_original_parent_relationship_records_PRIVATE'],'original2651_metadata_source_NOT_revalidated':declaration['exact_original_saved_input'],'original_CP_metadata_binding':bindings[1]}
 full=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL63-directory-scope-consumption-intake-PRIVATE.json',full);descriptor={'result_saved':'ROOT-FIRST-ALL63-directory-scope-consumption-intake-PRIVATE.json','result_bytes':len(full),'result_sha256':hashlib.sha256(full).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-scope-result.json',before);d=json.loads(before);d['actions_include_child_directory_scope_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL63_literal_directory_INPUT_scope_and_prior_CP_relationships_NOT_queried_or_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(full),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_child_directory_scope='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL63literalchild-directory INPUT scope declaredBEFOREtargetIO/newpriorCPexact-and-substring relationships preserved; no SDKINPUTquery. Summary thenFIRSTpublication/newcollector-scope qualification only, oldDEFERREDflags unchanged/newscope0queries. No oldsource-body-parser-model-SDKquery-Actions-acquisition replay/Source20-runtime adoption/build/numerical.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
