# ROOT logical decision protocol, not a binary layout or implementation

This refinement follows Qwen's case advice. It is a new abstract contract only; Qwen did not review this later refinement. No C source, generated instruction, native helper, compile recipe or runtime is produced.

Logical regions (byte offsets/endian/word ABI remain UNBOUND):
- Parent-only creator operation journal and original reference slots, reserved before creation IO. A slot label is not actor authentication.
- Parent-only single-assignment decision word: WAIT, RUN_FINITE, REFUSE_FINITE. There is no original SDK/exec/driver GO value. Actual lock-free atomic width/alignment/lowering/shared-mapping lifetime remain unproved.
- Child-only per-owned-copy operation journals, not writable by the parent to settle Source state. Parent and child FD-table copies are separate; original references and actual observed operations, not a numeric label, supply ownership.
- Separate ROOT raw collectors and original official context handle. A success-shaped result is never an accepted receipt.

Decision table:
1. Before creation attempt: WAIT. Known pre-creation refusal can end only with independently observed absence of a launch attempt, not merely pidfd=None.
2. Creation attempted but return/reference outcome unknown: remain WAIT, permanent quarantine, no retry/scan/kill/partial methods/Source-field settlement. This is not a finite runnable fault case.
3. Original native return confirmed AND all original creator handles actually retained and registered before publication: WAIT is retained until the qualified finite decision. Record completeness is not inferred from a field assignment or hash.
4. After full native registration with no errors and all finite-only obligations independently met: a single RUN_FINITE decision could release the qualified private branch. This is a future prerequisite, not current authority.
5. Controlled publication First after full native registration, with an independently qualified finite refusal branch and SAME-known-child collection mechanism: a single REFUSE_FINITE could choose that private refusal branch while preserving First/raw diagnostics. If either mechanism is absent, no launch/fault injection is allowed. This branch cannot repair unknown registration or send original SDK GO.
6. Unknown atomic/store/native-close/context-exit outcome: no repeat, reset, alternative decision or release based on final fields/EOF. Quarantine and preserve original buffers/handles.
7. Actual known finite child collection plus independently complete writer/FD/actor evidence: only then can one original context-exit attempt be considered. The collection alone is not the ownership proof; native context-exit uncertainty remains unresolved and never retried.

The qualified child would use only the already-bound atomic prefix while WAIT. RUN_FINITE and REFUSE_FINITE each lead only to selected non-SDK native instructions, with separate pre-operation journals and natural terminal outcomes. Native exit status values, exact writes/closes and error classification remain UNBOUND until an actual helper contract is selected. No guessed status or invented known exit is recorded as evidence.

No early child pipe ACK or parent sleep/stop is proposed as a scheduling proof. A future observational witness must first show it preserves the exact instruction prefix and does not create unregistered IO; if that cannot be shown, retain conditional paper ordering only, without claiming that child-first execution was exercised.

The next static artifact is a byte-layout/initialization/ownership and signal/implicit-call specification plus a separately qualified finite refusal/collection protocol. That may select a candidate helper/toolchain recipe, but compiler execution/disassembly is actual native work and needs its own complete explicit preflight, official EX, new declared actors and fresh12GiB build floor. A manual, schema, model example or this prose authorizes no compiler/native/SDK call. Do not fabricate an atomic_binding_proof or a signal-free prefix assertion.

The direct-child mechanism still cannot bind all internal unmodified SDK actors. Independent original cohort policy and output validator remain absent. Current provider/gate/controller/ownership/admission stay unchanged.
