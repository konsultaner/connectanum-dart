import pathlib,hashlib,importlib.util,json,subprocess,sys
P=pathlib.Path('/tmp/connectanum-native-perf-native-bootstrap-spec-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q=P/'case-planning';Q.mkdir()
 def save(name,obj):
  with (Q/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 context=(P/'finite-bootstrap-specification.md').read_bytes();assert len(context)<20000
 with (Q/'context.txt').open('xb') as f:f.write(context)
 prompt='Review ONLY this NEW finite non-SDK specification and proposed cases. In at most 900 words: classify C0-C3 and X1-X2 for whether any is actually runnable now (all are currently unimplemented), identify up to three concrete missing mechanisms, and suggest the smallest next static specification step. Do not propose executing unknown constructor/close/signal paths, timeout kill/release, Source-field restoration, PID scan, or new SDK/argv/env/credential/host changes. No fixture-to-live or authority-from-schema. Names/outcomes/floors do not authorize launches. Native registration and physical lease continuity before/through child IO need actual proof; manual lock-free facts are not cross-process or compiler evidence. Never call the proposed cases passed tests or a production repair.'
 argv=[sys.executable,str(h),'tests','--provider','ollama','--model','qwen3.8:27b','--stdin','--prompt',prompt,'--num-predict','2048','--timeout','180','--max-input-chars','20000','--save-output',str(Q/'answer.txt')]
 save('command-before.json',dict(argv=argv,context_size=len(context),context_sha256=sha(context),Popen_attempted=True,pid=None))
 p=subprocess.Popen(argv,cwd='/tmp',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
 save('native-handles-before-IO.json',dict(pid=pid,original_bound_wait_streams_retained=True))
 out,err=p.communicate(input=context);status=wait(10)
 for role,b in [('stdout',out),('stderr',err)]:
  with (Q/(role+'.bin')).open('xb') as f:f.write(b)
 result=dict(pid=pid,status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err),complete_answer_exists=(Q/'answer.txt').is_file(),no_native_test_or_SDK=True)
 save('result.json',result);lease.verify_identity();print(json.dumps(result))
