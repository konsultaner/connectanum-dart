import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import re,os,stat
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');Q=B/'2026-11-07-actions-include-child-directory-scope-v1/new63-control-region-intake-v1';S=B/'2026-11-07-actions-include-directory-inputs-v1/source-preserving-fix-v1/unchanged-collector.py'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':'FIRST NEW63source-extension control-region intake from exactOWNsaved49directory prepcollector. Wholeoriginal642688B usedasopaque bytepreserving carrier; select UNIQUEliteral root anchor toEOF and prefix assignment names ONLY. Notold49syntax/review/model/SDKquery replay, no oldmetadata payload resubmission or execution. Exactsource/range declaredBEFOREIO; oldSource20/runtime/SDK untouched. New63sourcegeneration stillpending/ALLsetupUNADMITTED.','exact_source':str(S),'range':[0,642688],'sha256':'383bd1c6c286645bd3dcaca429a193f889cab658621d028baa532db0621df90f','control_selector':'UNIQUE root = pathlib.Path(os.environ["RUNNER_TEMP"]) throughEOF','all_admission_flags':False},indent=2));save('controller.py',sys.argv[1])
 fd=os.open(S,os.O_RDONLY|os.O_NOFOLLOW);binding={'open_return_fd':fd,'close_return_fd':None}
 try:
  s=os.fstat(fd);before={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']};assert stat.S_ISREG(s.st_mode) and s.st_size==642688;parts=[];count=0;sha=hashlib.sha256()
  while count<642688:
   block=os.read(fd,min(65536,642688-count));assert block;parts.append(block);sha.update(block);count+=len(block)
  assert os.read(fd,1)==b'';z=os.fstat(fd);after={k:getattr(z,k) for k in before};assert before==after and sha.hexdigest()=='383bd1c6c286645bd3dcaca429a193f889cab658621d028baa532db0621df90f';raw=b''.join(parts);binding.update(before=before,after=after,bytes=count,sha256=sha.hexdigest(),EOF=True)
 finally:os.close(fd);binding['close_return_fd']=fd
 text=raw.decode();anchor='root = pathlib.Path(os.environ["RUNNER_TEMP"])';assert text.count(anchor)==1;at=text.index(anchor);prefix=text[:at];body=text[at:];names=[]
 for line in prefix.splitlines():
  found=re.match(r'^([A-Za-z_][A-Za-z_0-9]*)\s*=',line)
  if found:names.append(found.group(1))
 save('original-prepcollector-opaque-bound.py',raw);save('FIRST-control-region-selection.py',body);save('source-read-binding-PRIVATE.json',json.dumps(binding,indent=2));save('FIRST-prefix-assignment-names.json',json.dumps(names,indent=2))
 print(json.dumps({'source_bytes':len(raw),'prefix_characters':len(prefix),'prefix_assignment_names':names,'selected_control_characters':len(body),'selected_control_body':body,'no_original_code_executed':True,'no_SDK_or_Source20_runtime_query':True,'all_admission_flags':False}),flush=True);lease.verify_identity()
