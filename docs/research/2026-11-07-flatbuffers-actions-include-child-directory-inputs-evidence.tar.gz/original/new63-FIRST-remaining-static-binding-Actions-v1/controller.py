import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import subprocess,base64,ast,time,datetime,zipfile,io,os,shutil,stat
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-child-directory-scope-v1';N=P/'new63-source-generation-v1';A=P/'new63-FIRST-remaining-static-binding-Actions-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();A.mkdir()
 def save(n,b):
  with (A/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('execution-declaration.json',json.dumps({'scope':'FIRST remaining NEW ALL63 Actions source writer after actuallocalSTATICbinder DictComp failure beforeANYremote. Originalfailed namespace foreverterminal. Minimal symbolicDictComp plusfollowingliteral-subscript binding correction ONLY, originalcollector875694B/workflow479966B unchanged andallgates retained. FIRSToriginal31conditionevaluations consumed/saved; copy exactsavedPASSgates, no reevaluation/replay. NEWmatchingbinder ASTfield extraction nottargetexecution/globals-eval orsourceedit. OriginalActions firstremote/query still unperformed. FIRST NEW ALL63 explicitlydeclared child-directory one-level metadata INPUT originalActions workflow265291183. Atomic2file source andBOTHbyteexactreadbacks before single dispatch; ALL31oldjob sourceconditions false thenactualSKIPPED required32total. Exactscope5531267B/SHA42116723f7fcf899e46be761a74a45aa2e0b19ef07e5e4ae22683840383fde99 declaredBEFOREIO/sourcecontrols beforeSDKquery. Prior1280separateparent-child/fullstat-times/49queryepochs/1199latelexicalepoch/63DEFERREDflags/18rawlinksUNEXPANDED-UNFOLLOWED/oldtopncursesrawhexNULL/priorledgers unchanged vsNEWqueryepoch. CP11359scalars/63zeroexact-substring matches NOTabsence-newness-querypermission-globalnoreplay. Preserve originalworkflow/Ubuntu24-Dart3.13.5-Rust1.99/PATH-env-argv-credentials-recipes. No automaticjoin-normalize-resolve-follow-recursion/childbodyopen-hash/favorablelanguage-version-ABI-defaultcompiler filter/aliasdedup/candidateexecution/import-headercompile/bootstrap/dependency/build/driver/perf/numerical/Source20-runtime adoption/oldquery-parser-model-acquisition-archive replay. FirstnewSTATICreport-fieldbinding extraction notoldASTcheck. Unknownpartial-crash permanentlyquarantined/pointFDfacts notglobalactorFD orcontinuousphysicalEX admission.','exact_saved_sources':[str(N/'FIRST-source-validation.json'),str(N/'candidate-wamp-profile-benchmarks.yml'),str(N/'collector.py'),str(P/'ALL63-exact-new-lexical-scope-BEFORE-INPUT-IO.json'),str(B/'2026-11-07-actions-include-child-regular-inputs-v1/Actions-v1/FIRST-new-child-regular-commit.stdout')],'parent_source':'405a896d8610307ca07b065bbcc6eac261974bf2','all_admission_flags':False,'ownership':None},indent=2));save('controller.py',sys.argv[2]);save('actual-source-review-context.json',json.dumps(v,ensure_ascii=True,indent=2));save('ROOT-review-qualification.md',v['ROOT_review_qualification'])
 free=shutil.disk_usage(A).free;save('fresh-preflight-check-floor.json',json.dumps({'free_bytes':free,'required_bytes':1073741824,'not_build_authority':True}));assert free>=1073741824
 children=[]
 def native(label,args):
  save(label+'-request.json',json.dumps({'argv':args,'cwd':str(A)},indent=2));p=subprocess.Popen(args,cwd=A,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(p);save(label+'-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_IO':True},indent=2));o,e=p.communicate();status=p.wait();save(label+'.stdout',o);save(label+'.stderr',e);r={'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(o),'stderr_bytes':len(e),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_sha256':hashlib.sha256(e).hexdigest()};save(label+'-completion.json',json.dumps(r,indent=2));print(json.dumps({'label':label,**r}),flush=True);assert status==0;return o
 def api(label,method,endpoint,body=None):
  args=['gh','api','--hostname','github.com','--method',method,endpoint]
  if body is not None:save(label+'-body.json',json.dumps(body,ensure_ascii=True,indent=2));args+=['--input',str(A/(label+'-body.json'))]
  return native(label,args)

 scoped=(P/'ALL63-exact-new-lexical-scope-BEFORE-INPUT-IO.json').read_bytes();assert len(scoped)==5531267 and hashlib.sha256(scoped).hexdigest()=='42116723f7fcf899e46be761a74a45aa2e0b19ef07e5e4ae22683840383fde99';scope=json.loads(scoped);validation=json.loads((N/'FIRST-source-validation.json').read_bytes());source=(N/'candidate-wamp-profile-benchmarks.yml').read_bytes();collector=(N/'collector.py').read_bytes()
 assert len(source)==validation['workflow_bytes']==479966 and hashlib.sha256(source).hexdigest()==validation['workflow_sha256']=='e3f1cbaae9b927788142af457738a523134d0357522575b50ed13cdcbf432988'
 assert len(collector)==validation['collector_bytes']==875694 and hashlib.sha256(collector).hexdigest()==validation['collector_sha256']=='0af55b3c077386bb7d3fce9bd11c244df9644e62d62235acca27c023eb7e0038'
 assert validation['ALL31_old_jobs_unchanged'] and validation['whole_original_workflow_reverse_projection_BYTEEXACT'] and validation['whole_original_collector_reverse_projection_BYTEEXACT'] and validation['whole_scope_BYTEEXACT_JSONSTRING_PythonALLfield_equality'] and validation['ALL_original_functions_fields_guards_and_opaque_prefix_preserved']
 campaign='flatbuffers_include_child_directory_inputs'

 prior_conditions_path=P/'new63-FIRST-Actions-v1/ALL31-original-condition-source-preflight-BEFOREdispatch.json';priorconditions=prior_conditions_path.read_bytes();conditions=json.loads(priorconditions);assert len(conditions)==31 and all(row['declared_dispatch_SOURCE_false_NOT_actual_skip_yet'] is True for row in conditions)
 assert [{k:r[k] for k in ['job','if']} for r in conditions]==validation['ALL31_original_job_conditions'];save('original-ALL31-source-preflight-PASS-byteexact-NOT-reevaluated.json',priorconditions)
 # FIRST NEW63 program STATIC report-field bindings; only literal/JSON/name/subscript declarations, no target code execution.
 text=collector.decode();tree=ast.parse(text);prefix=text.split('\nimport base64, gzip\n',1)[0];constants={};imports=[]
 def literal(node):
  if isinstance(node,ast.Name):return constants[node.id]
  if isinstance(node,ast.Subscript):return literal(node.value)[literal(node.slice)]
  if isinstance(node,ast.Call):
   assert isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='json' and node.func.attr=='loads' and len(node.args)==1 and not node.keywords
   return json.loads(literal(node.args[0]))
  return ast.literal_eval(node)
 symbolic_dictcomp_count=0;symbolic_subscript_count=0
 for node in ast.parse(prefix).body:
  if isinstance(node,ast.Import):imports.extend(a.asname or a.name.split('.')[0] for a in node.names)
  if isinstance(node,ast.Assign):
   assert len(node.targets)==1;target=node.targets[0]
   if isinstance(node.value,ast.DictComp):
    assert isinstance(target,ast.Name) and target.id=='PRIOR_DECLARED_METADATA'
    assert ast.dump(node.value)==ast.dump(ast.parse('{key: value for key, value in list(globals().items()) if key.startswith("ALL")}',mode='eval').body)
    constants[target.id]={key:value for key,value in constants.items() if key.startswith('ALL')};symbolic_dictcomp_count+=1
   elif isinstance(target,ast.Subscript):
    assert isinstance(target.value,ast.Name) and target.value.id=='PRIOR_DECLARED_METADATA' and literal(target.slice)=='original_regular_references_metadata_NOT_queried' and isinstance(node.value,ast.Name) and node.value.id=='references'
    constants[target.value.id][literal(target.slice)]=literal(node.value);symbolic_subscript_count+=1
   else:
    assert isinstance(target,ast.Name);constants[target.id]=literal(node.value)
 assert symbolic_dictcomp_count==1 and symbolic_subscript_count==1
 assert 'json' in imports and 'hashlib' in imports
 constants['PRIOR_ALL49_SCOPE']=constants['NEW_SCOPE'];constants['PRIOR_DIRECTORY_REFERENCES']=constants['DIRECTORY_REFERENCES'];constants['NEW_SCOPE']=scope;constants['DIRECTORY_REFERENCES']=scope['ALL63_new_literal_directory_references']
 reports=[x for x in ast.walk(tree) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='report' for t in x.targets)];assert len(reports)==1 and isinstance(reports[0].value,ast.Dict);expected={}
 for key,value in zip(reports[0].value.keys,reports[0].value.values):
  assert isinstance(key,ast.Constant) and isinstance(key.value,str)
  if isinstance(value,ast.Name) and value.id in constants:expected[key.value]=constants[value.id]
  elif isinstance(value,ast.Constant):expected[key.value]=value.value
 expected['NEW_scope_exact_JSON_bytes']=len(scoped);expected['NEW_scope_exact_JSON_sha256']=hashlib.sha256(scoped).hexdigest()
 assert len(expected['source_directory_references'])==63 and len(expected['prior_ALL49_directory_references_NOT_requeried'])==49 and expected['NEW_ALL63_explicit_input_scope']==scope and expected['NEW_ALL49_explicit_input_scope']==constants['PRIOR_ALL49_SCOPE']
 save('FIRST-static-report-field-bindings-BEFOREremote-IO.json',json.dumps({'source_import_bindings':imports,'expected_static_report_fields':expected,'no_targetcode_executed':True,'no_old_AST_validation_repeated':True},ensure_ascii=True,indent=2));save('ALL63-exact-execution-scope-before-remote-IO.json',scoped)
 parent='405a896d8610307ca07b065bbcc6eac261974bf2';parentrecord=json.loads((B/'2026-11-07-actions-include-child-regular-inputs-v1/Actions-v1/FIRST-new-child-regular-commit.stdout').read_bytes());assert parentrecord['sha']==parent;repo='repos/konsultaner/connectanum-dart';branch='codex/pr132-actions-include-child-directory-inputs-20261107';path='.github/workflows/wamp-profile-benchmarks.yml';cpth='.github/collectors/pr132_include_child_directory_inputs.py'
 t=json.loads(api('FIRST-new63-two-file-tree','POST',repo+'/git/trees',{'base_tree':parentrecord['tree']['sha'],'tree':[{'path':path,'mode':'100644','type':'blob','content':source.decode()},{'path':cpth,'mode':'100644','type':'blob','content':collector.decode()}]}))
 committed=json.loads(api('FIRST-new63-commit','POST',repo+'/git/commits',{'message':'Declare all63 include child directory metadata inputs [skip ci]','tree':t['sha'],'parents':[parent]}));sha=committed['sha'];assert [x['sha'] for x in committed['parents']]==[parent]
 made=json.loads(api('FIRST-new63-branch','POST',repo+'/git/refs',{'ref':'refs/heads/'+branch,'sha':sha}));assert made['object']['sha']==sha
 back=json.loads(api('FIRST-new63-workflow-readback','GET',repo+'/contents/'+path+'?ref='+sha));assert base64.b64decode(back['content'])==source
 backc=json.loads(api('FIRST-new63-collector-readback','GET',repo+'/contents/'+cpth+'?ref='+sha));assert base64.b64decode(backc['content'])==collector
 save('source-publication-receipt.json',json.dumps({'source_commit':sha,'branch':branch,'parent':parent,'workflow_bytes':len(source),'workflow_sha256':hashlib.sha256(source).hexdigest(),'collector_path':cpth,'collector_bytes':len(collector),'collector_sha256':hashlib.sha256(collector).hexdigest(),'BOTH_independent_readbacks_byteexact_BEFOREdispatch':True,'ALL31oldjobs_preserved':True,'ALL31oldconditions_SOURCE_false_BEFOREdispatch':True,'scope_lossless_BYTEEXACT_JSONSTRING_PythonALLfield_equality':True,'all_original_fields_functions_and_gates_preserved':True,'all_admission_flags':False},indent=2))
 api('FIRST-dispatch-only-NEW63-child-directory-inputs','POST',repo+'/actions/workflows/265291183/dispatches',{'ref':branch,'inputs':{'campaign':campaign}})
 run=None
 for i in range(8):
  rows=json.loads(api('FIRST-discover-NEW63-run-'+str(i),'GET',repo+'/actions/workflows/265291183/runs?branch='+branch+'&event=workflow_dispatch&per_page=5'))['workflow_runs'];found=[x for x in rows if x['head_sha']==sha];assert len(found)<=1
  if found:run=found[0];break
  time.sleep(5)
 assert run is not None,'Unknown dispatch outcome; terminal/no redispatch'
 rid=run['id'];save('actual-new-run-identity.json',json.dumps(run,indent=2));print(json.dumps({'new_run':rid,'source_commit':sha}),flush=True)
 cp=B/'current-task-checkpoint.json';raw=cp.read_bytes();save('checkpoint-before-watch.json',raw);d=json.loads(raw);d['actions_include_child_directory_inputs_v1'].update(phase='NEW_ALL63_source_run_dispatched_ONCE_originalwatch_pending',source_commit=sha,branch=branch,run_id=rid,raw_directory=str(A),all_admission_flags=False);d['active_turn_status'].update(new_include_child_directory_inputs='NEW_originalwatch_pending',run_id=rid,source_commit=sha,all_admission_flags=False,RAM_repair_FINAL_strict48_50_cleanCI='INCOMPLETE');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 native('FIRST-watch-only-NEW63-run',['gh','run','watch',str(rid),'--repo','konsultaner/connectanum-dart','--exit-status','--interval','10'])
 final=json.loads(api('FIRST-new63-final','GET',repo+'/actions/runs/'+str(rid)));assert final['status']=='completed' and final['conclusion']=='success'
 jobs=json.loads(api('FIRST-new63-jobs','GET',repo+'/actions/runs/'+str(rid)+'/jobs?per_page=100'))['jobs'];target=[x for x in jobs if x['name']=='FlatBuffers include child directory inputs (no execution)'];assert len(target)==1 and target[0]['conclusion']=='success';jid=target[0]['id'];assert len(jobs)==32 and all(x['conclusion']=='skipped' for x in jobs if x['id']!=jid)
 log=api('FIRST-new63-job-log','GET',repo+'/actions/jobs/'+str(jid)+'/logs');arts=json.loads(api('FIRST-new63-artifact-list','GET',repo+'/actions/runs/'+str(rid)+'/artifacts?per_page=100'))['artifacts'];assert len(arts)==1;art=arts[0];rawzip=api('FIRST-new63-artifact-zip','GET',repo+'/actions/artifacts/'+str(art['id'])+'/zip');zsha=hashlib.sha256(rawzip).hexdigest();assert len(rawzip)==art['size_in_bytes']
 if art.get('digest'):assert art['digest']=='sha256:'+zsha
 Z=zipfile.ZipFile(io.BytesIO(rawzip));infos=Z.infolist();assert len(infos)==len(set(x.filename for x in infos));destroot=A/'artifact-members';destroot.mkdir();index=[]
 for info in infos:
  name=pathlib.PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts
  if info.is_dir():continue
  data=Z.read(info);dest=destroot/info.filename;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
  index.append({'name':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 save('actual-new-artifact-member-index.json',json.dumps(index,indent=2))
 def member(basename):
  found=[x for x in index if pathlib.PurePosixPath(x['name']).name==basename];assert len(found)==1
  return found[0],(destroot/found[0]['name']).read_bytes()
 rm,reportraw=member('include-child-directory-inputs.json');report=json.loads(reportraw);assert report['workflow_revision']==sha and str(report['run_id'])==str(rid)
 for key,value in expected.items():assert report[key]==value,key
 refs=scope['ALL63_new_literal_directory_references'];observations=report['observations'];assert [r['source_directory_reference'] for r in observations]==refs and len(refs)==63 and report['all_admission_flags'] is False and report['ownership'] is None
 sm,sraw=member('scope-before-INPUT-IO.json');assert sraw==scoped and sraw.decode()==scoped.decode() and json.loads(sraw)==scope
 jm,jraw=member('operations.jsonl');events=[json.loads(line) for line in jraw.splitlines() if line];writes=[x for x in events if x.get('event')=='output_saved' and x.get('name')=='include-child-directory-inputs.json'];assert len(writes)==1 and writes[0]['bytes']==len(reportraw) and writes[0]['sha256']==hashlib.sha256(reportraw).hexdigest() and writes[0]['same_saved_output_FD_stream_match'] is True
 scopewrites=[x for x in events if x.get('event')=='output_saved' and x.get('name')=='scope-before-INPUT-IO.json'];assert len(scopewrites)==1 and scopewrites[0]['bytes']==len(scoped) and scopewrites[0]['sha256']==hashlib.sha256(scoped).hexdigest() and events.index(scopewrites[0])<min(i for i,x in enumerate(events) if x.get('event')=='directory_INPUT_open_intent')
 assert len(report['remaining_known_FDs_before_report'])==1 and list(report['remaining_known_FDs_before_report'].values())==[{'role':'original_operations_journal'}]
 points=[x for x in events if x.get('event')=='collector_completed_point_only_NOT_crash_global_closure'];assert len(points)==1 and points[0]['remaining_known_FDs']==report['remaining_known_FDs_before_report']
 assert not any(x.get('event','').endswith('_unknown') or x.get('event') in ['collector_primary_error','directory_primary_error','output_primary_error'] for x in events)
 present=[];absent=[];totalentries=0;newlinks=[];typecounts={'regular':0,'directory':0,'symlink':0,'other':0,'unknown_lstat_absence':0}
 for ordinal,row in enumerate(observations):
  assert row['ordinal']==ordinal and row['new_query_epoch_NOT_original_DEFERRED_epoch'] is True
  if 'absent_at_open_only' in row:assert row['entries']==[];absent.append(row['source_directory_reference']);continue
  assert row['source_fd_before']==row['source_fd_after'] and row['source_FD_metadata_equal'] is True and stat.S_ISDIR(row['source_fd_before']['st_mode'])
  assert [e['name'] for e in row['entries']]==row['original_native_listdir_order_names'] and [e['name_bytes_hex'] for e in row['entries']]==row['original_native_listdir_order_namehex']
  closeevents=[x for x in events if x.get('event')=='directory_close_return' and x.get('ordinal')==ordinal];assert len(closeevents)==1 and closeevents[0]['fd']==row['close_return_fd']
  present.append(row['source_directory_reference']);totalentries+=len(row['entries'])
  for j,entry in enumerate(row['entries']):
   assert entry['ordinal']==j and entry['parent_reference_separate_NOT_joined']==row['source_directory_reference'] and entry['target_UNEXPANDED_UNFOLLOWED'] is True and bytes.fromhex(entry['name_bytes_hex'])==os.fsencode(entry['name'])
   if 'absent_at_separate_lstat_only' in entry:typecounts['unknown_lstat_absence']+=1;continue
   mode=entry['separate_lstat']['st_mode'];typ='regular' if stat.S_ISREG(mode) else 'directory' if stat.S_ISDIR(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other';typecounts[typ]+=1
   if typ=='symlink':
    assert bytes.fromhex(entry['separate_readlink_bytes_hex'])==os.fsencode(entry['separate_readlink_literal']);newlinks.append({'directory_ordinal':ordinal,'entry_ordinal':j,'entry_metadata_UNEXPANDED_UNFOLLOWED':entry})
   else:assert entry['separate_readlink_literal'] is None and entry['separate_readlink_bytes_hex'] is None
 assert len(present)+len(absent)==63 and report['directory_INPUT_open_attempts']==63 and report['one_level_directory_queries']==len(present) and sum(typecounts.values())==totalentries
 for key in ['recursive_walks','child_body_INPUT_opens','child_body_INPUT_hashes','entry_symlink_target_follows','collector_child_executions','native_information_queries','candidate_executions','environment_mutations']:assert report[key]==0
 result={'source_commit':sha,'parent_source':parent,'branch':branch,'run_id':rid,'run_url':run['html_url'],'job_id':jid,'job_conclusion':'success','ALL31_previous_jobs':'skipped_not_rerun','parsed_and_actual_job_count':32,'artifact_id':art['id'],'artifact_bytes':len(rawzip),'artifact_sha256':zsha,'job_log_bytes':len(log),'job_log_sha256':hashlib.sha256(log).hexdigest(),'report_bytes':len(reportraw),'report_sha256':hashlib.sha256(reportraw).hexdigest(),'present_directory_inputs':len(present),'absent_at_open_only':absent,'total_new_one_level_entry_records':totalentries,'new_entry_type_counts_from_original_modes':typecounts,'ALL63_source_refs':refs,'ALL63_original_observations':observations,'ALL_NEW_raw_readlink_records_UNEXPANDED_UNFOLLOWED':newlinks,'NEW_ALL63_exact_input_scope':scope,'ALL_preserved_static_report_fields':expected,'new_source_validation':validation,'ROOT_review_qualification':v['ROOT_review_qualification'],'recursive_walks':0,'child_body_INPUT_opens':0,'child_body_INPUT_hashes':0,'entry_symlink_target_follows':0,'collector_child_executions':0,'native_information_queries':0,'candidate_executions':0,'environment_mutations':0,'journal_only_known_FDs_at_report_point_NOT_global_actor_closure':report['remaining_known_FDs_before_report'],'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':report['qualification']}
 rawresult=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json',rawresult);rawcp=cp.read_bytes();save('checkpoint-before-acquisition-result.json',rawcp);d=json.loads(rawcp);node=d['actions_include_child_directory_inputs_v1'];node.update(phase='COMPLETE_CONSUMED_FIRST_ORIGINAL_Actions_ALL63_directory_child_inputs_NOT_admitted',raw_directory=str(A),source_commit=sha,run_id=rid,job_id=jid,original_saved_result=str(A/'ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json'),original_saved_result_bytes=len(rawresult),original_saved_result_sha256=hashlib.sha256(rawresult).hexdigest(),present_directory_inputs=len(present),absent_at_open_only=absent,total_new_one_level_entry_records=totalentries,new_entry_type_counts_from_original_modes=typecounts,new_raw_readlinks=len(newlinks),artifact_id=art['id'],artifact_bytes=len(rawzip),artifact_sha256=zsha,report_bytes=len(reportraw),report_sha256=hashlib.sha256(reportraw).hexdigest(),public_documentation_pending=True,model_review_pending=False,all_admission_flags=False);d['active_turn_status'].update(new_include_child_directory_inputs='COMPLETE_CONSUMED_publication_pending',next='FIRST NEW63originalActions oneleveldirectory queries/report/journal/archive completeCONSUMED. Publish exactsavednewdata andsource-controls/minimalselector fault-debug-correction qualifications. NewentrybodyinteriorsUNINSPECTED/no childbody-hash-recursion-follow/oldquery-model-parser-Action-acquisition-archive-numerical replay/Source20-runtime adoption. Prior1280/49/1199/63DEFERRED/18unexpanded/oldncursesNULL epochsprotected; allsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-FINALstrict48/50-cleanCI incomplete.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');descriptor={key:result[key] for key in ['source_commit','parent_source','branch','run_id','run_url','job_id','ALL31_previous_jobs','parsed_and_actual_job_count','artifact_id','artifact_bytes','artifact_sha256','job_log_bytes','job_log_sha256','report_bytes','report_sha256','present_directory_inputs','absent_at_open_only','total_new_one_level_entry_records','new_entry_type_counts_from_original_modes','all_admission_flags','ownership']};descriptor.update(original_saved_result_name='ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json',original_saved_result_bytes=len(rawresult),original_saved_result_sha256=hashlib.sha256(rawresult).hexdigest(),new_raw_readlinks=len(newlinks));save('original-saved-result-descriptor.json',json.dumps(descriptor,indent=2));print(json.dumps(descriptor),flush=True);lease.verify_identity()
