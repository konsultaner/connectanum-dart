from __future__ import annotations

import dataclasses
import errno
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import socket
import stat
import tempfile
import time
import types
import unittest
from unittest.mock import patch

import native_perf_session as session
from native_perf_session import PrivateDirectory, PrivateListener, PinnedElf, SessionSpec, SessionError
from native_perf_guard import FrozenLaunch, ProcessStat, ProcessInstance, PipeIdentity
from native_perf_blocked_exec import BlockedSpec, start_blocked, _open_fds
from native_perf_handoff import Peer, _channel
from native_perf_proc_witness import ProcessWitness, FdWitness


class FixtureHandle:
    def __init__(self, pid):
        self.pid, self.alive, self.closed = pid, True, False
    def require_alive(self):
        if not self.alive or self.closed:
            raise SessionError('synthetic owned helper is not alive')
    def close(self):
        self.closed = True


class FixtureBackend:
    fixture_only = True
    def __init__(self, spec, log_fd, *, corrupt=None, bad_ack=False):
        self.spec, self.log_fd, self.corrupt, self.bad_ack = spec, log_fd, corrupt, bad_ack
        self.children, self.boot = [], None
        self.records = Path(spec.directory) / 'exec-fixture.json'
    def _identity(self):
        return {'pid': os.getpid(), 'start_ticks': os.getpid() + 100,
                'image_sha256': self.spec.bootstrap_image, 'fixture_only': True}
    def launch(self, mode, phase=None):
        pid = os.fork()
        if pid == 0:
            os.dup2(self.log_fd, 2)
            peer = Peer(self.spec.controller_pid, self.spec.controller_uid, self.spec.controller_gid)
            try:
                if mode == 'helper':
                    def callback(fd, argv, env):
                        inventory = _open_fds()
                        self.records.write_text(json.dumps({'fixture_only': True, 'pid': os.getpid(),
                            'uid': os.geteuid(), 'argv': list(argv), 'open_fds': inventory,
                            'image_fd': fd, 'image_cloexec': not os.get_inheritable(fd),
                            'stdin': dataclasses.asdict(PipeIdentity.from_fd(0)),
                            'stdout': dataclasses.asdict(PipeIdentity.from_fd(1))}))
                        deadline = time.monotonic() + 5
                        while select.select([0], [], [], max(0, deadline - time.monotonic()))[0]:
                            data = os.read(0, 128)
                            if not data:
                                return
                            if data != b'enable\n':
                                raise SessionError('unexpected fixture sampler control')
                            os.write(1, b'wrong\n' if self.bad_ack else b'ack\n')
                            if time.monotonic() >= deadline:
                                return
                    session.run_helper(self.spec, fixture_peer=peer, identity=self._identity, exec_callback=callback)
                else:
                    directory = PrivateDirectory(self.spec.directory, self.spec.controller_uid)
                    sock, wire = session.connect_wire(self.spec, 'audit-' + phase + '.sock', fixture_peer=peer)
                    session.helper_preface(wire, self.spec, 'audit-' + phase, self._identity())
                    followup = session.new_round(sock, wire, spec=self.spec, as_controller=False)
                    with followup.once():
                        request = followup.read_frame()
                        target = request['target']
                        control, ack = _channel(target['control']), _channel(target['ack'])
                        pid, start = target['sampler_pid'], target['sampler_start']
                        def fd(number, identity, flags):
                            return FdWitness(number, 'pipe', identity.device, identity.inode, flags, 'fixture-pipe')
                        sampler = ProcessWitness(ProcessStat(pid, self.spec.controller_pid, start),
                            ProcessInstance(pid, start, self.spec.perf_sha, self.spec.controller_uid, self.spec.controller_gid),
                            (self.spec.controller_uid,) * 4, (self.spec.controller_gid,) * 4, self.spec.perf_argv(),
                            (0, 1, 64, 0, 0, stat.S_IFREG | 0o700), self.spec.perf_path,
                            (fd(0, control.read_end, os.O_RDONLY), fd(1, ack.write_end, os.O_WRONLY),
                             FdWitness(2, 'regular', self.spec.log_device, self.spec.log_inode, os.O_WRONLY, 'fixture-log')), True)
                        wrapper = ProcessWitness(ProcessStat(self.spec.wrapper_pid, self.spec.controller_pid, self.spec.wrapper_start),
                            ProcessInstance(self.spec.wrapper_pid, self.spec.wrapper_start, self.spec.wrapper_image,
                                            self.spec.controller_uid, self.spec.controller_gid),
                            (self.spec.controller_uid,) * 4, (self.spec.controller_gid,) * 4, self.spec.wrapper_argv,
                            (0, 2, 64, 0, 0, stat.S_IFREG | 0o700), self.spec.driver_path, (), True)
                        report = {'context': self.spec.context('audit-' + phase), 'fixture_only': True,
                                  'sampler': dataclasses.asdict(sampler), 'wrapper': dataclasses.asdict(wrapper),
                                  'actual_driver_fd_sha256': self.spec.driver_sha,
                                  'raw_evidence': [{'fixture_only': True, 'phase': phase}]}
                        if self.corrupt:
                            report = self.corrupt(phase, report)
                        receipt = session.write_report(directory, 'audit-' + phase + '.json', report)
                        followup.send_frame({'event': 'audit_report', **self.spec.context('audit-' + phase), 'receipt': receipt})
                    sock.close()
                    directory.close()
                os._exit(0)
            except BaseException as error:
                # OWN callback fixture only; preserve its error, no root/perf execution.
                Path(self.spec.directory, 'fixture-error-' + str(os.getpid()) + '.json').write_text(json.dumps(
                    {'fixture_only': True, 'error': type(error).__name__, 'reason': str(error)}))
                os._exit(78)
        child = types.SimpleNamespace(pid=pid)
        self.children.append(child)
        return child
    def accept(self, listener, child):
        return listener.accept(fixture_peer=Peer(child.pid, self.spec.controller_uid, self.spec.controller_gid))
    def handle(self, peer):
        return FixtureHandle(peer.pid)
    def wait_auditor(self, child):
        pid, status = os.waitpid(child.pid, 0)
        if os.waitstatus_to_exitcode(status) != 0:
            raise SessionError('fixture auditor failed')
    def reap(self):
        for child in self.children:
            deadline = time.monotonic() + 1
            while True:
                try:
                    found, status = os.waitpid(child.pid, os.WNOHANG)
                except ChildProcessError:
                    break
                if found:
                    break
                if time.monotonic() >= deadline:
                    os.kill(child.pid, signal.SIGKILL)  # OWN nonbenchmark callback only.
                    os.waitpid(child.pid, 0)
                    break
                time.sleep(.005)


@unittest.skipUnless(os.name == 'posix' and hasattr(os, 'fork'), 'OWN POSIX fixtures')
class SessionTests(unittest.TestCase):
    """No real Linux/root/pidfd/perf/ELF exec/native library/benchmark evidence."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ct-session-', dir='/tmp')
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name).resolve()
        self.directory.chmod(0o700)
        self.private = PrivateDirectory(self.directory, os.geteuid())
        self.addCleanup(self.private.close)
        self.log = (self.directory / 'sampler-log.json').open('wb')
        self.addCleanup(self.log.close)
        self.perf = self.directory / 'perf-fixture'
        self.perf.write_bytes(b'\x7fELFowned non-executed perf fixture')
        self.perf.chmod(0o700)
        self.driver = self.directory / 'driver-fixture'
        self.driver.write_bytes(b'owned driver exec CALLBACK fixture')
        self.driver.chmod(0o700)
        self.marker = self.directory / 'marker'
        self.marker.mkdir(mode=0o700)
        self.executed = self.directory / 'driver-executed.json'
        policy = FrozenLaunch.freeze((str(self.driver), 'fixture-argument'), os.environ.copy(), os.geteuid(), os.getegid())
        self.policy = policy
        self.child = None
        self.controllers, self.backends = [], []
        self.addCleanup(self.cleanup)
    def cleanup(self):
        for controller in self.controllers:
            try:
                if getattr(controller, 'release_attempted', False) and controller.state != 'driver_finished':
                    controller.wait_driver(self.child, 1)
                controller.close_metadata()
            except (OSError, SessionError):
                pass
        if self.child:
            self.child.close_go()
            try:
                self.child.wait(1)
            except ChildProcessError:
                pass
            except Exception:
                os.kill(self.child.pid, signal.SIGKILL)  # OWN callback only, not a campaign.
                os.waitpid(self.child.pid, 0)
            os.close(self.child.ready_fd)
        for backend in self.backends:
            backend.reap()
        evidence = os.environ.get('CONNECTANUM_PERF_SESSION_FIXTURE_EVIDENCE')
        if evidence:
            # Preserve all OWN fixture files/logs/transcripts before temp cleanup.
            target = Path(evidence) / self._testMethodName
            inventory = {str(p.relative_to(self.directory)): {'mode': p.lstat().st_mode,
                         'device': p.lstat().st_dev, 'inode': p.lstat().st_ino}
                         for p in self.directory.rglob('*')}
            def skip_sockets(directory, names):
                return [name for name in names if stat.S_ISSOCK(Path(directory, name).lstat().st_mode)]
            shutil.copytree(self.directory, target, symlinks=True, ignore=skip_sockets)
            (target / 'fixture-node-inventory.json').write_text(json.dumps(inventory))

    def spec(self, wrapper_pid=99999):
        info = os.fstat(self.log.fileno())
        return SessionSpec('a' * 64, 'b' * 32, os.getpid(), os.geteuid(), os.getegid(), str(self.directory),
            wrapper_pid, 123, 'e' * 64, ('owned-python-fixture',), str(self.driver),
            hashlib.sha256(self.driver.read_bytes()).hexdigest(), str(self.perf),
            hashlib.sha256(self.perf.read_bytes()).hexdigest(), 'e' * 64, 'c' * 64, info.st_dev, info.st_ino)
    def setup_controller(self, *, driver_wait=0, **options):
        def driver_callback(fd, argv, env):
            self.executed.write_text(json.dumps({'fixture_only': True, 'argv': list(argv)}))
            if driver_wait:
                time.sleep(driver_wait)
        blocked = BlockedSpec(self.policy, hashlib.sha256(self.driver.read_bytes()).hexdigest(),
                              'a' * 64, 'b' * 32, self.marker, Path.cwd(), 3)
        self.child = start_blocked(blocked, self.log.fileno(), test_exec=driver_callback)
        self.child.read_ready(1)
        spec = self.spec(self.child.pid)
        backend = FixtureBackend(spec, self.log.fileno(), **options)
        self.backends.append(backend)
        controller = session.SessionController(spec, backend)
        self.controllers.append(controller)
        controller.start_helper()
        return controller

    def test_private_node_and_directory_identity_and_retention(self):
        listener = PrivateListener(self.private, 'owned.sock')
        listener.verify()
        listener.close()
        self.assertTrue((self.directory / 'owned.sock').is_socket())
        with self.assertRaisesRegex(SessionError, 'exists'):
            PrivateListener(self.private, 'owned.sock')

    def test_existing_node_or_insecure_directory_refuses(self):
        (self.directory / 'existing.sock').write_text('protected fixture')
        with self.assertRaisesRegex(SessionError, 'exists'):
            PrivateListener(self.private, 'existing.sock')
        self.assertEqual((self.directory / 'existing.sock').read_text(), 'protected fixture')
        self.directory.chmod(0o755)
        with self.assertRaisesRegex(SessionError, 'permissions'):
            self.private.verify()
        self.directory.chmod(0o700)

    def test_socket_node_replacement_is_not_deleted(self):
        listener = PrivateListener(self.private, 'replaced.sock')
        (self.directory / 'replaced.sock').rename(self.directory / 'old.sock')
        (self.directory / 'replaced.sock').write_text('retain replacement')
        with self.assertRaisesRegex(SessionError, 'node changed'):
            listener.accept(fixture_peer=Peer(os.getpid(), os.geteuid(), os.getegid()))
        listener.close()
        self.assertEqual((self.directory / 'replaced.sock').read_text(), 'retain replacement')

    def test_pinned_image_bytes_and_named_path_drift_refuse(self):
        image = PinnedElf(self.perf, hashlib.sha256(self.perf.read_bytes()).hexdigest())
        self.addCleanup(image.close)
        self.perf.rename(self.directory / 'old-perf')
        self.perf.write_bytes(b'\x7fELFnew unexpected fixture image')
        self.perf.chmod(0o700)
        with self.assertRaisesRegex(SessionError, 'changed'):
            image.verify()

    def test_exclusive_report_authentication_and_terminal_partial(self):
        report = {'fixture_only': True, 'data': 'synthetic'}
        receipt = session.write_report(self.private, 'audit.json', report)
        self.assertEqual(session.read_report(self.private, receipt), report)
        with self.assertRaises(FileExistsError):
            session.write_report(self.private, 'audit.json', report)
        (self.directory / 'audit.json').write_text('mutated')
        with self.assertRaisesRegex(SessionError, 'identity|digest'):
            session.read_report(self.private, receipt)

    def test_report_boolean_receipt_and_schema_are_refused(self):
        receipt = session.write_report(self.private, 'schema.json', {'fixture_only': True})
        bad = dict(receipt, inode=False)
        with self.assertRaisesRegex(SessionError, 'receipt'):
            session.read_report(self.private, bad)

    def test_full_two_audits_ack_marker_go_and_same_pid_callback(self):
        controller = self.setup_controller()
        helper_pid = controller.boot['pid']
        gate = controller.arm(self.child, self.policy, self.marker)
        self.assertEqual(gate.state, 'released')
        self.assertEqual(controller.audited_phases, ['before-enable', 'before-go'])
        self.assertEqual(controller.wait_driver(self.child, 1), 0)
        self.assertTrue(self.executed.exists())
        record = json.loads((self.directory / 'exec-fixture.json').read_text())
        self.assertEqual(record['pid'], helper_pid)
        self.assertEqual(record['uid'], os.geteuid())
        self.assertEqual(record['argv'], list(controller.spec.perf_argv()))
        self.assertTrue(record['image_cloexec'])
        self.assertEqual(set(record['open_fds']), {0, 1, 2, record['image_fd']})
        self.assertTrue((self.marker / 'capture-consumed.json').exists())
        self.assertTrue((self.directory / 'controller-before-go.json').exists())

    def test_bad_second_audit_never_writes_marker_or_go(self):
        def corrupt(phase, report):
            if phase == 'before-go':
                report['sampler']['argv'] = (*report['sampler']['argv'], '--unexpected-flag')
            return report
        controller = self.setup_controller(corrupt=corrupt)
        with self.assertRaisesRegex(SessionError, 'sampler audit'):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse(self.executed.exists())
        self.assertFalse((self.marker / 'capture-consumed.json').exists())
        self.assertTrue((self.directory / 'audit-before-go.json').exists())
        self.assertEqual(controller.state, 'failed')

    def test_fixture_report_cannot_be_admitted_as_live(self):
        controller = self.setup_controller()
        controller.audit('before-enable')
        raw = json.loads((self.directory / 'audit-before-enable.json').read_text())
        with self.assertRaisesRegex(SessionError, 'provenance'):
            session.admit_audit(controller.spec, raw, 'before-enable', controller.boot,
                                controller.ends.control, controller.ends.ack, fixture_only=False)
        with self.assertRaisesRegex(SessionError, 'out of order'):
            controller.audit('before-enable')

    def test_spoofed_ack_never_writes_marker_or_go(self):
        controller = self.setup_controller(bad_ack=True)
        with self.assertRaises(Exception):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse((self.marker / 'capture-consumed.json').exists())
        self.assertFalse(self.executed.exists())
        self.assertEqual(controller.audited_phases, ['before-enable'])

    def test_existing_consumed_marker_never_releases_or_retries(self):
        controller = self.setup_controller()
        marker = self.marker / 'capture-consumed.json'
        marker.write_bytes(b'partial retained fixture marker')
        with self.assertRaises(FileExistsError):
            controller.arm(self.child, self.policy, self.marker)
        self.assertEqual(marker.read_bytes(), b'partial retained fixture marker')
        self.assertFalse(self.executed.exists())
        with self.assertRaisesRegex(SessionError, 'rearm'):
            controller.arm(self.child, self.policy, self.marker)

    def test_fixed_perf_argv_is_attach_only_flat_unfiltered_clock(self):
        spec = self.spec()
        argv = spec.perf_argv()
        self.assertIn('--pid', argv)
        self.assertIn('--inherit', argv)
        self.assertIn('--delay=-1', argv)
        self.assertIn('cpu-clock', argv)
        self.assertNotIn('cpu-clock:u', argv)
        self.assertNotIn('--', argv)
        self.assertNotIn('-g', argv)
        self.assertEqual(argv[0], str(self.perf))

    def test_live_cli_never_chooses_darwin_or_fixture_fallback(self):
        with patch('native_perf_session.sys.platform', 'darwin'):
            with self.assertRaisesRegex(SessionError, 'Linux'):
                session._check_root_linux()
        payload = dataclasses.asdict(self.spec())
        payload['fixture_only'] = True
        with self.assertRaisesRegex(SessionError, 'schema'):
            SessionSpec.from_json(payload)

    def test_spec_scalar_types_and_unknown_report_fields_refuse(self):
        original = self.spec()
        for field, value in [('controller_uid', False), ('wrapper_start', 0), ('declaration', 'bad')]:
            with self.subTest(field=field), self.assertRaises(SessionError):
                dataclasses.replace(original, **{field: value})
        with self.assertRaisesRegex(SessionError, 'provenance'):
            session.admit_audit(original, {'fixture_only': False}, 'before-enable', {}, None, None)

    def test_bundle_hash_drift_is_refused_before_own_module_import(self):
        root = self.directory / 'bundle'
        (root / 'tool').mkdir(parents=True)
        files = {}
        for relative in session.BUNDLE_FILES:
            path = root / relative
            path.write_bytes(b'owned synthetic source fixture\n')
            path.chmod(0o600)
            files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest = self.directory / 'manifest.json'
        manifest.write_bytes(session._bytes({'files': files}))
        digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
        verified = session.verified_bundle(root, manifest, digest, os.geteuid())
        self.assertEqual(set(verified), set(session.BUNDLE_FILES))
        (root / 'tool/native_perf_guard.py').write_bytes(b'changed source')
        with self.assertRaisesRegex(SessionError, 'digest'):
            session.verified_bundle(root, manifest, digest, os.geteuid())

    def test_verified_byte_loader_ignores_preexisting_module_cache(self):
        # Isolate module cache mutation in an OWN child. No image exec/root/native.
        result = self.directory / 'loader.json'
        pid = os.fork()
        if pid == 0:
            sources = {f'tool/{name}.py': f'VERIFIED_MARKER = {index}\n'.encode()
                       for index, name in enumerate(session.MODULE_ORDER)}
            for name in session.MODULE_ORDER:
                __import__('sys').modules[name] = types.SimpleNamespace(VERIFIED_MARKER='poisoned-cache')
            session.load_verified_modules(sources, self.directory)
            result.write_text(json.dumps([__import__('sys').modules[name].VERIFIED_MARKER for name in session.MODULE_ORDER]))
            os._exit(0)
        os.waitpid(pid, 0)
        self.assertEqual(json.loads(result.read_text()), list(range(len(session.MODULE_ORDER))))

    def test_go_eof_failure_preserves_sampler_until_driver_natural_exit(self):
        controller = self.setup_controller(driver_wait=.5)
        original = self.child.close_go
        def close_then_fail():
            original()
            raise OSError(errno.EIO, 'injected post-close GO error')
        with patch.object(self.child, 'close_go', side_effect=close_then_fail):
            with self.assertRaisesRegex(OSError, 'post-close GO'):
                controller.arm(self.child, self.policy, self.marker)
        deadline = time.monotonic() + 1
        while not self.executed.exists() and time.monotonic() < deadline:
            time.sleep(.005)
        self.assertTrue(self.executed.exists(), 'full token+EOF actually reached OWN callback')
        self.assertTrue((self.marker / 'capture-consumed.json').exists())
        with self.assertRaisesRegex(SessionError, 'natural exit'):
            controller.close_metadata()
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        self.assertEqual(controller.wait_driver(self.child, 1), 0)
        controller.close_metadata()

    def test_actual_sampler_wrong_log_fd_refuses_before_marker(self):
        def corrupt(phase, report):
            for fd in report['sampler']['fds']:
                if fd['number'] == 2:
                    fd['inode'] += 1
            return report
        controller = self.setup_controller(corrupt=corrupt)
        with self.assertRaisesRegex(SessionError, 'log'):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse(self.executed.exists())
        self.assertFalse((self.marker / 'capture-consumed.json').exists())

    def test_protocol_save_error_preserves_primary_refusal(self):
        backend = FixtureBackend(self.spec(), self.log.fileno())
        self.backends.append(backend)
        controller = session.SessionController(backend.spec, backend)
        self.controllers.append(controller)
        with patch.object(backend, 'launch', side_effect=SessionError('primary launch refusal')):
            with patch.object(controller, '_save', side_effect=OSError(errno.ENOSPC, 'injected log refusal')):
                with self.assertRaisesRegex(SessionError, 'primary launch refusal') as caught:
                    controller.start_helper()
        self.assertTrue(any('log refusal' in note for note in getattr(caught.exception, '__notes__', [])))
