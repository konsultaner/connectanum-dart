import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-end-command-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts-v2.json').read_text())
 assert source==(P/'candidate-v2.py').read_text()
 assert source.replace(parts['helper'],'',1).replace(parts['newwait'],parts['oldwait'],1).replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'end_regressions-v2.py').read_bytes();ast.parse(source);ast.parse(tests)
 assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units-v2/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(8,6,2,0);assert(a['tests'],a['failures'],a['errors'])==(26,0,0)
 assert len(b['leases'])==16 and len(a['leases'])==52 and all(r['raw_None'] for r in b['leases']+a['leases'])
 def views(path,key):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if key in v}
 old=views(P/'before-units-v2/fixtures','record_original_command');new=views(P/'after-selected/fixtures','record_original_command');affected=views(P/'after-selected/fixtures','record_original_result');assert len(old)==len(new)==len(affected)==8
 assert any(x['kind']=='ROOT_protected_False_fsync_before_native' for x in old['fileno_False'][0]['calls'])
 for mode in ('flush_unknown','fsync_unknown','close_unknown','snapshot_unknown','event_unknown'):
  assert old[mode][0]['received_first'] and any(x['kind']=='forbidden_preserver' for x in old[mode][0]['calls'])
 waits={};cleanup={}
 for phase,data in [('before-v2',old),('after-new',new),('after-affected-finish',affected)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())];known=[r for r in rows if r.get('kind')=='ROOT_same_original_bound_wait']
  assert len(known)==8 and sum(r['status']==0 for r in known)==7 and sum(r['status']==3 for r in known)==1
  waits[phase]=known;cleanup[phase]=rows
  for r in rows:
   if r.get('kind') in ('ROOT_known_log','ROOT_known_journal'):assert r['raw_closed_after']
 for mode,(v,d) in new.items():
  assert v['public_producer_returned'] and v['record_present'] and v['record_original_journal'] and v['record_original_log'] and v['record_original_command']
  assert v['Source_log_None'] and v['Source_output_log_None'] and not v['Source_pending']
  assert all(row['raw_None'] for row in v['leases']) and not any(c['kind'] in ('forbidden_preserver','repr_first','note_first','ROOT_protected_False_fsync_before_native') for c in v['calls'])
  rows=v['Source_steps'];stages=['log_flush','log_fileno','log_fsync','log_close','log_snapshot','command_end_event']
  if mode in ('normal','normal_failed'):
   assert v['wait_returned'] and v['record_completed'] and v['Source_evidence_complete'] and v['original_journal_closed']
   assert v['result_status']==('failed' if mode=='normal_failed' else 'success') and v['Source_returncode']==(3 if mode=='normal_failed' else 0)
   assert [r['stage'] for r in rows]==stages and all(r['returned'] for r in rows)
   if mode=='normal_failed':assert rows[3]['raw_False']
  else:
   assert not v['wait_returned'] and not v['record_completed'] and not v['Source_evidence_complete'] and not v['failure_exists']
   assert v['Source_finished'] and v['Source_returncode']==0 and v['pure_guard_same_received'] and v['record_primary_received']
   assert not v['original_journal_closed'] and v['Source_events_original']
   stop={'flush_unknown':0,'fileno_False':1,'fsync_unknown':2,'close_unknown':3,'snapshot_unknown':4,'event_unknown':5}[mode]
   assert [r['stage'] for r in rows]==stages[:stop+1]
   if mode=='fileno_False':assert v['received_type']=='ProducerError' and rows[-1]['raw_False'] and rows[-1]['returned']
   else:assert v['received_first'] and not rows[-1]['returned'] and rows[-1]['raw_None'] and rows[-1]['error_first']
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]}
 assert models['Qwen']['status']==models['GLM']['status']==0 and (P/'candidate-review/answer.txt').exists()
 assert json.loads((P/'before-units/result.json').read_text())['errors']==8
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'ONLY_end_command body pluswaitcatchguard scopecomplete. Existingnativewait/history/statusvalidation andallotherSource_finish-privatehelpers/preservation-defer/AuxPopen/constructors/factories/sharedstep/frozenpredicates exact. Context/ref/binding/status/closed/finished/helpercompleted DATA notsemanticimageauth-atomicABA-originalcredentials-ownership-EXrelease/admission.',
 'FirstcompletedNEW8v2 BEFORE6FAIL2normalPASS0ERROR:5oldfirstalreadyescapes butunknownnativecall continuesenclosingfailurepreserver/repr-close; knownFalsefileno oldpassesFalse towardROOTprotectedfsync whichdoesNOTnativeFD0. EarlyFalseclassification +retention/refusalpolicies NOT6spontaneousnativekernelbugs/RAMcause. AFTER26=8matchingNEW+18affected(8previousfinishpublicationcontrols+10actualwait/finishcallers). Changed_endbody/catchguard justifyaffectedselection, notunchangedcontrol/numerical/modelreplay oraggregate/fullcurrent20canonical/admission.',
 'NativeoriginalFileIO log/journal/commandrecord/context retainedbeforeIO. ActualflushNone/nativeFD/fsyncNone/closeNone/snapshotdict/eventNone ROOTknown neverfillsSourceunknownrawNone-returnedFalse. KnownFalseFD refusedbeforefsync, neverFD0. Privatefirst latches beforeterminalfinishedTrue/secondarymetadata; waitguard preventsSourcepreserver/repr-note/finish/laterIO/retry-replay-restore. SourcefinishedTrue preserveslegacypublicwait0 ProducerError terminalcontract, neverownershiporEXrelease. Source_oldreturncode-ended-logdetach order andnormalignoredcloseNone-False-object contract preserved; None-False executed only.',
 'Normalactualsuccess+declaredfiniteexit3/full14B END-outEND-err bytes/loghash/logcomplete/originalfailedresult preserved. Existinglog-versus-output consistencycheck remains. Earlierstatusmetadata/clock/binding/otherreturnshapes/invalidsnapshotkeys-values/globalbindings/concurrentABA/emptyrecords/calleeinteriorintent/historicalcontinuation/transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission incomplete.',
 '16newviews=8BEFOREv2+8AFTERnew, plus8affectedfinishviews separately. ParentCURRENT officialDarwinEXverifyNone16BEFORE52AFTER plusSourcecallbacksNone UNITnotfullindependentactualEX-originalLinuxcredentials/allFD-interpreter-delegate-descendantclosure.8BEFORE8AFTERnew SAMEoriginalRootboundwait10 each7zero1three/cachedpossible;8affectedfinish waits separate7zero1three. ROOTknownFD-log-journal devino cleanup AFTERviews/assertions UNITnotSourcecleanup-recovery-EXrelease. Setup/internalFD/API factsnotallserialized/no globalabsence-fullreap/reconstruction.',
 'Privatev1 8harnessERROR0FAIL: ROOT snapshotwrapper lacked maximum/secondargument usedduringactualAuxsetup BEFOREtarget_endcommandcontrols/CommandProducerprocesscaptures0. Partiallyenteredpublicconstructor/Auxsetup API-actor facts notallserialized/no omittedstatus-reaping reconstruction/adoption/recovery/globalabsence. Oldnamespacesterminal. Privatev2 identical *args/**kwargs delegate BEFOREfirstcompleted8targetcontrols; no completedcontrol replay/sourcefixuntil6genuineBEFOREfailures.',
 'Qwen40836status0/full3810stdout572stderr/fullanswer ROOTqualified/rejectexpectedenclosingpreserver andFDleak inference. GLM41846status0/full2309stdout769stderr/fullanswer ROOTqualified/rejectpreservegroupclosure=>reportingIO, secondrefuse despiteouterguard, finallyunreachable, prefersecondarye overprivatefirst, finished=>ownership, GCidreuse withstrongowner, leak/retry-cleanup authority. Modelv2 seesfinalcandidatev2; v1-v2UNEXECUTEDbeforeedit/v2ROOTstatus-beforefalliblemethodlookuporder strengthenedBEFOREreview/no modelrepeat.',
 'Stronggroups/owner/primary-secondary/rows/originalrefs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. NamedcontrollersBEFOREcalls/availableactualAPIreturns retained/initialAPIreturnsnotallseparatelysaved/no reconstruction. Afterresultprinted26PASS controllerstillpending infirstwait; SAMEcontroller laternatural0 retained, no guessed0/restart.',
 'All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact; no Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse. Storagefloors/recheck DATAnotbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.'
 ]
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=8,failures=6,passes=2,errors=0,scope='5unknowncallcontinuation/retentionpolicies+knownFalseFDearlyclassification NOT6nativebugs/RAMcause'),after=a,
 ROOT=dict(whole_final_Source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=16,affected_finish_views=8,parent_BEFORE_EXverify_None=16,parent_AFTER_EXverify_None=52,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup,allotherSource_finish_helpers_Aux_Popen_constructors_factories_sharedstep_frozenpredicates_exact=True),
 models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True,model_v2_before_final_v2_Sourceedit=True),limits=limits,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_end_command_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Producer_end_command_selected26PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected26PASS=True,new_views=16,affected_views=8,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
