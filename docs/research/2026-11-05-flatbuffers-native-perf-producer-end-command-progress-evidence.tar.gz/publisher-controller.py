import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-end-command-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-end-command-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='35dacb56a3c2e01cb36d4f5989b8ee7b384799fc'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Stop enclosing reports after uncertain log sealing\n\nEnd-command log sealing entered another failure report after unknown log/snapshot/event completion and passed a known False descriptor toward fsync. The selected body now retains original FileIO/journal/command/context and each call intent/raw return. A private first latch precedes terminal-field and secondary metadata updates; a pure guard stops the enclosing wait handler before later reporting I/O. Exact native integer FD validation refuses False before fsync. Normal bytes/hash/status/consistency checks, multi-command flow and ignored close returns stay intact. Finished/closed/status/handle facts remain DATA, not ownership, EX release or admission.\n\nNEW8 first-completed v2 at77dc14/72ba37 yields6FAIL/2normalPASS/0ERROR: five old-first-already-escaping continuation/retention policies plus earlier False-FD classification, not six spontaneous native kernel bugs or a RAM cause. ROOT intercepts the old False fsync before any native FD0 call. Finalc20652/fa3a11 passes26selected=8matchingNEW+18affected (8prior finish-publication controls and10wait/finish callers), not aggregate/current20canonical/admission. Initial privatev1 reaches8harnessERROR because its snapshot wrapper omits the maximum argument during Aux setup, before end-command targets; privatev2 delegates identical arguments before first completed eight. Sixteen new views plus8affected views/16BEFORE52AFTER currentDarwinEX observations and same bound ROOT waits remain UNIT facts, not independent full EX/originalLinuxcredentials. Qwen40836/GLM41846 complete0/fullanswers are ROOTqualified; group metadata is not reporting I/O, outer guard prevents second refusal, first priority is retained, and strong owners reject GC-ID-reuse claims. Both candidates are unexecuted before edit; ROOT restores status-before-method-lookup order in v2 before review. ROOT qualifies final source/tests/AST/byte projection,23hashes/other18helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty. Other APIs/earlier finish setup/historical/transitive/fullEX/immutableCOMPLETE runtime admission remain incomplete. No SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-end-command-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: guard end-command log sealing before further reports'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_end_command_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Remaining_endcommand earliermetadata-clock-methodbindings/otherreturnshapes-invalidsnapshots-calleeinteriorintent; earlier_finish_setup/enclosingreporting/publicunknownCtorretention; writer-hash-init/nativeFD seams; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Currentc20652/fa3a11 ONLY_end_command body+waitcatchguard originalFileIO-journal-commandrecord-context/percallintent-raw/privatefirst-beforeterminal-secondary/unknown-invalidstop scopedcomplete26selectedPASS=8matchingNEW+18affected(8previousfinishcontrols+10actualwait-finishcallers). FirstcompletedNEW8v2 at77dc14/72ba37=6FAIL2normalPASS0ERROR/5oldfirstalreadyescapes/enclosingcontinuation-policies+FalseFDclassification NOT6nativekernelbugs/RAMcause; ROOTFalsefsyncguard NEVERnativeFD0. Privatev1 8harnessERROR optionalmaximumarg BEFOREtargetcontrols/processcaptures0/partialconstructor-Auxsetup factsnotallserialized/no reconstruction-adoption-recovery; v2identicalargsdelegatebeforefirstcompleted8/no completedcontrolreplay. Normalactualsuccess-finiteexit3/full14B-END-outEND-err/hash-order-logcomplete/ignoredcloseFalse/publicterminalwait0 ProducerError preserved.16newviews+8affected/EX16before52after/8+8newRootboundwait7zero1three perphase/8affectedseparate UNITnotfullEX. Qwen40836-GLM41846=0/fullanswers/ROOTqualified/rejectmetadataIO-secondrefuse-finally-unreachable-secondarypriority-GCidreuse-leakcause claims. Modelv2seesfinalcandidatev2/bothunexecutedbeforeedit/ROOTwholefinalASTqualified NOTwholecurrentapproval. Othermethods_finish_helpers_AuxPopen-factories-sharedstep-frozenpredicates exact; allpriorepochshistorical/notcurrent20canonical/admission. UnknownPopenCtorpermanentrefusal/no field-derivedownerclose API; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; finished-status-closed-helperfields DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_end_command_scoped26PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
