"""Own source-frozen command evidence, not capture or canonical admission.

Caller holds the official exclusive lease. Only fixed live factories may select
canonical/production recipes; fixture commands are labelled in every receipt.
A direct child status plus output-pipe EOF does not prove all descendants exited, SDK identity,
complete canonical validation, loader validity, or loaded role/native-image bytes.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import select
import stat
import subprocess
import sys
import tarfile
import time
import threading
from types import MappingProxyType, MethodType


class ProducerError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise ProducerError('Python 3.11 or newer required before producer IO')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _regular_hash(path, maximum=1024**3, *, owners=None):
    attempt=_RegularHashAttempt(path,maximum,owners)
    _REGULAR_HASH_ATTEMPTS.append(attempt) # Retain BEFORE path/FD operations.
    return attempt.run()


def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))


# Retained IO observations only. These records grant no ownership or admission.
_JSON_WRITE_ATTEMPTS = []


class _JSONWriteAttempt:
    def __init__(self,path,value):
        self.original_path=path
        self.value=value
        self.path=None
        self.manager=None
        self.writer=None
        self.payload=None
        self.steps=[]
        self.completed=False
        self.first_error=None
        self.secondary_errors=[]
        first=[None]
        secondary=self.secondary_errors

        def guard():
            if first[0] is not None:raise first[0]

        def fail(error,row=None):
            if first[0] is None:first[0]=error # Bind BEFORE any error metadata.
            primary=first[0]
            try:
                self.first_error=primary
                if row is not None:row['error']=primary
            except BaseException as metadata_error:
                secondary.append(metadata_error)
            finally:
                raise primary

        self.guard=guard
        self._fail=fail

    def _step(self,stage,lookup,args=(),kwargs=None):
        self.guard()
        fail=self._fail # Retain original failure binding BEFORE lookup/callee.
        row=dict(stage=stage,attempted=True,lookup=lookup,args=args,kwargs=kwargs,
            method=None,returned=False,raw=None,error=None)
        self.steps.append(row) # Intent precedes lookup, not just the call.
        try:
            method=lookup()
            row['method']=method
            returned=method(*args,**({} if kwargs is None else kwargs))
            row['raw']=returned # Raw return precedes checks and the next operation.
            row['returned']=True
            return returned
        except BaseException as error:
            fail(error,row)

    def run(self):
        call=self._step
        fail=self._fail
        original_path=self.original_path
        original_value=self.value
        try:
            path=call('path',lambda:Path,(original_path,))
            self.path=path
            # Literal native Path namespace, process lifetime only; no alias,
            # cross-process, kernel identity or persistent admission inference.
            for previous in _JSON_WRITE_ATTEMPTS:
                if previous is self:break
                if previous.path is None or previous.path==path:
                    previous.guard()
                    raise FileExistsError('JSON output namespace was already attempted')
            manager=call('open',lambda:path.open,('xb',))
            self.manager=manager
            # Match normal with special-method lookup before entering. Do not
            # call exit on an unknown/invalid body or enter result.
            enter=call('enter_lookup',lambda:lambda:type(manager).__enter__)
            exit_method=call('exit_lookup',lambda:lambda:type(manager).__exit__)
            writer=call('enter',lambda:enter,(manager,))
            self.writer=writer
            rendered=call('json',lambda:json.dumps,(original_value,),
                dict(sort_keys=True,ensure_ascii=True))
            if type(rendered) is not str:raise ProducerError('unknown JSON text return')
            payload=call('encode',lambda:lambda:(rendered+'\n').encode())
            self.payload=payload
            count=call('write',lambda:writer.write,(payload,))
            if type(count) is not int or count!=len(payload):
                raise ProducerError('incomplete JSON write return')
            flushed=call('flush',lambda:writer.flush)
            if flushed is not None:raise ProducerError('unknown JSON flush return')
            fd=call('fileno',lambda:writer.fileno)
            if type(fd) is not int or fd<0:raise ProducerError('unknown JSON fileno return')
            synced=call('fsync',lambda:os.fsync,(fd,))
            if synced is not None:raise ProducerError('unknown JSON fsync return')
            call('exit',lambda:exit_method,(manager,None,None,None))
            # Normal exit return was always ignored, including False/objects.
            self.completed=True
        except BaseException as error:
            fail(error,self.steps[-1] if self.steps else None)


def _write_json(path,value):
    attempt=_JSONWriteAttempt(path,value)
    _JSON_WRITE_ATTEMPTS.append(attempt) # Retain BEFORE path conversion/open.
    attempt.run()


# Read-attempt records are observations, never credentials or ownership.
_REGULAR_HASH_ATTEMPTS = []


class _RegularHashAttempt(_JSONWriteAttempt):
    def __init__(self,path,maximum,owners):
        # Reuse only unchanged pure step/first-error machinery. No writer runs.
        super().__init__(path,None)
        self.maximum=maximum
        self.owners=owners
        self.fd=None
        self.digest=None

    def run(self):
        call=self._step
        fail=self._fail
        original_path=self.original_path
        maximum=self.maximum
        owners=self.owners
        try:
            if owners is None:owners={call('getuid',lambda:os.getuid)}
            path=call('path',lambda:Path,(original_path,))
            self.path=path
            absolute=call('is_absolute',lambda:path.is_absolute)
            if absolute is not True:raise ProducerError('input path must be canonical without symlinks')
            resolved=call('resolve',lambda:path.resolve,(),dict(strict=True))
            if type(resolved) is not type(path) or resolved!=path:
                raise ProducerError('input path must be canonical without symlinks')
            before=call('stat_before',lambda:path.stat,(),dict(follow_symlinks=False))
            if type(before) is not os.stat_result:raise ProducerError('unknown input stat return')
            fd=call('open',lambda:os.open,(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC))
            if type(fd) is not int or fd<0:raise ProducerError('unknown input open return')
            self.fd=fd
            info=call('fstat',lambda:os.fstat,(fd,))
            if type(info) is not os.stat_result:raise ProducerError('unknown input fstat return')
            identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
            if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
                raise ProducerError('input type/owner/mode/size differs')
            if identity(before)!=identity(info):raise ProducerError('input changed before read')
            h=call('hash_ctor',lambda:hashlib.sha256)
            count=0
            while True:
                requested=min(1024**2,maximum+1-count)
                part=call('read',lambda:os.read,(fd,requested))
                if type(part) is not bytes or len(part)>requested:
                    raise ProducerError('unknown input read return')
                if not part:break
                updated=call('hash_update',lambda:h.update,(part,))
                if updated is not None:raise ProducerError('unknown input hash update return')
                count+=len(part)
                if count>maximum:raise ProducerError('input grew beyond bound')
            if count!=info.st_size:raise ProducerError('input changed during read')
            final_info=call('fstat_after',lambda:os.fstat,(fd,))
            if type(final_info) is not os.stat_result or identity(final_info)!=identity(info):
                raise ProducerError('input changed during read')
            final_path=call('stat_after',lambda:path.stat,(),dict(follow_symlinks=False))
            if type(final_path) is not os.stat_result or identity(final_path)!=identity(info):
                raise ProducerError('input changed during read')
            digest=call('hexdigest',lambda:h.hexdigest)
            if type(digest) is not str or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
                raise ProducerError('unknown input digest return')
            closed=call('close',lambda:os.close,(fd,))
            if closed is not None:raise ProducerError('unknown input close return')
            self.digest=digest
            self.completed=True
            return digest
        except BaseException as error:
            fail(error,self.steps[-1] if self.steps else None)


VERSION_ARGS={'git':('--version',),'python3':('--version',),'bash':('--version',),
              'dart':('--version',),'cargo':('--version',),'rustc':('--version','--verbose')}
TOOL_FIELDS={'entry','target','sha256','version_prefix','entry_device','entry_inode','entry_mode',
             'entry_uid','entry_link','target_device','target_inode','target_mode','target_uid'}


def describe_tool(name,version_prefix,*,lookup_path=None):
    """Read-only intent preparation; executes no program and authenticates no image."""
    if name not in VERSION_ARGS or type(version_prefix) is not str or not 0<len(version_prefix)<=256 or '\0' in version_prefix or '\n' in version_prefix:
        raise ProducerError('invalid fixed tool/version declaration')
    entry=shutil.which(name,path=lookup_path)
    if entry is None or not Path(entry).is_absolute():raise ProducerError('tool PATH resolution missing or nonabsolute: '+name)
    entry=Path(entry);before=entry.lstat();target=entry.resolve(strict=True)
    if not (stat.S_ISREG(before.st_mode) or stat.S_ISLNK(before.st_mode)) or before.st_uid not in (0,os.getuid()):
        raise ProducerError('tool entry type/owner differs: '+name)
    info=target.stat()
    if not info.st_mode&0o111:raise ProducerError('tool target is not executable: '+name)
    digest=_regular_hash(target,maximum=512*1024**2,owners={0,os.getuid()})
    fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
    link=os.readlink(entry) if stat.S_ISLNK(before.st_mode) else None
    if fields(before)!=fields(entry.lstat()) or target!=entry.resolve(strict=True) or fields(info)!=fields(target.stat()):
        raise ProducerError('tool entry/target changed during observation: '+name)
    return {'entry':str(entry),'target':str(target),'sha256':digest,'version_prefix':version_prefix,
            'entry_device':before.st_dev,'entry_inode':before.st_ino,'entry_mode':before.st_mode,'entry_uid':before.st_uid,'entry_link':link,
            'target_device':info.st_dev,'target_inode':info.st_ino,'target_mode':info.st_mode,'target_uid':info.st_uid}


def _tool_table(value):
    if value is None:return MappingProxyType({})
    if type(value) is not dict or not 0<len(value)<=len(VERSION_ARGS):raise ProducerError('invalid tool table')
    result={}
    integers={'entry_device','entry_inode','entry_mode','entry_uid','target_device','target_inode','target_mode','target_uid'}
    for name,spec in value.items():
        if type(name) is not str or name not in VERSION_ARGS or type(spec) is not dict or set(spec)!=TOOL_FIELDS:
            raise ProducerError('invalid fixed tool snapshot schema')
        if any(type(spec[k]) is not int or spec[k]<0 for k in integers) or any(type(spec[k]) is not str or not spec[k] for k in ('entry','target','sha256','version_prefix')) or (spec['entry_link'] is not None and type(spec['entry_link']) is not str):
            raise ProducerError('invalid typed tool snapshot')
        if (not re.fullmatch('[0-9a-f]{64}',spec['sha256']) or not Path(spec['entry']).is_absolute() or not Path(spec['target']).is_absolute()
            or not 0<len(spec['version_prefix'])<=256 or '\0' in spec['version_prefix'] or '\n' in spec['version_prefix']):raise ProducerError('invalid tool digest/path/version declaration')
        result[name]=MappingProxyType(dict(spec))
    return MappingProxyType(result)


def _required_tools(value):
    if type(value) is not dict or set(value)!=set(VERSION_ARGS):
        raise ProducerError('live recipe requires all six declared tool snapshots')


LOCK_PATHS={'pub':'pubspec.lock','transport':'native/transport/Cargo.lock','bench':'native/bench/Cargo.lock'}
CANONICAL_RECIPES=[['bin/verify']]
PRODUCTION_RECIPES=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                    ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']]


def _required_context(kwargs):
    if (type(kwargs.get('census_id')) is not str or not re.fullmatch('[0-9a-f]{32}',kwargs['census_id'])
        or type(kwargs.get('expected_sdk')) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',kwargs['expected_sdk'])
        or type(kwargs.get('config_bindings')) is not dict or not {'server','client'}<=set(kwargs['config_bindings'])):
        raise ProducerError('live recipe needs pre-child census/SDK/config context')


def _read_json(path,expected):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NONBLOCK|os.O_NOFOLLOW)
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(2*1024**2+1)
        if len(data)>2*1024**2 or _sha(data)!=expected:raise ProducerError('sealed JSON size/digest differs')
        def pairs(values):
            out={}
            for key,value in values:
                if key in out:raise ProducerError('duplicate JSON key')
                out[key]=value
            return out
        def constant(value):raise ProducerError('nonfinite JSON constant')
        try:result=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('malformed sealed JSON') from e
        if type(result) is not dict:raise ProducerError('sealed JSON must be an object')
        return result
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('sealed JSON close failed: '+repr(e))


def _dart_sdk(line):
    match=re.match(r'^Dart SDK version: ([0-9]+\.[0-9]+\.[0-9]+) \(stable\)(?: |$)',line)
    if match is None:raise ProducerError('stable Dart SDK line required')
    return match[1]


def _read_bound_metadata(path,expected,maximum=32*1024**2):
    """Return only the bytes bound to this completed observation's snapshot."""
    if (type(expected) is not dict or set(expected)!={'size','sha256'}
        or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid auxiliary metadata bound before IO')
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_uid,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022
            or before.st_size!=expected['size']):raise ProducerError('auxiliary metadata file differs')
        chunks=[];h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(65536,maximum+1-count))
            if not part:break
            chunks.append(part);count+=len(part);h.update(part)
            if count>expected['size']:raise ProducerError('auxiliary metadata grew beyond observed bytes')
        if (count!=expected['size'] or h.hexdigest()!=expected['sha256']
            or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False))):
            raise ProducerError('auxiliary metadata consumed bytes differ from observation')
        return b''.join(chunks)
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as error:
            if primary is None:raise
            primary.add_note('auxiliary metadata close failed: '+repr(error))


# Allocation/initializer observations only; never public-constructor authority.
_AUXILIARY_INITIALIZATIONS = []


class _AuxiliaryInitializationAttempt(_JSONWriteAttempt):
    def __init__(self,origin,requested_class):
        super().__init__(None,None)
        self.origin=origin
        self.requested_class=requested_class
        self.constructor_arguments=None
        self.object=None
        self.allocation_attempted=False
        self.allocation_returned=None
        self.initializer_attempted=False
        self.initializer_returned=None
        self.initializer_result=None
        self.initializer_completed=False
        self.public_constructor_returned=None


def _bind_auxiliary_initialization(instance,record):
    record.object=instance
    def first_guard():
        record.guard() # Exact private first, before probing half-built fields.
        if record.initializer_attempted is not True:
            record._fail(ProducerError('auxiliary initializer entry is unconfirmed'))
    object.__setattr__(instance,'_initialization_progress',record)
    object.__setattr__(instance,'_initialization_first_guard',first_guard)


def _auxiliary_initial_paths(owner,directory,cwd,argv,environment):
    record=owner._initialization_progress
    call=record._step;guard=record.guard;fail=record._fail
    constructor=Path
    context=dict(object=owner,record=record,directory_input=directory,cwd_input=cwd,
        argv=argv,environment=environment,constructor=constructor,guard=guard,fail=fail,
        input_values=None,directory=None,cwd=None,directory_received=False,cwd_received=False,
        directory_resolved=None,cwd_resolved=None,completed=False)
    record.initial_path_context=context # Original refs BEFORE either Path call.

    def values():
        if (type(argv) is not list or not argv
            or any(type(x) is not str or not x or '\0' in x for x in argv)
            or type(environment) is not dict
            or any(type(k) is not str or type(v) is not str or '\0' in k+v for k,v in environment.items())):
            raise ProducerError('auxiliary early path input shape changed')
        return (tuple(argv),tuple(environment.items()))

    def check():
        guard() # Bound private first BEFORE current metadata checks.
        if (owner._initialization_progress is not record or record.object is not owner
            or record.guard is not guard or record._fail is not fail or Path is not constructor
            or record.initial_path_context is not context):
            raise ProducerError('auxiliary early path binding changed')
        if values()!=context['input_values']:
            raise ProducerError('auxiliary early path inputs changed')
        if context['directory_received'] and owner.directory is not context['directory']:
            raise ProducerError('auxiliary early directory reference changed')
        if context['cwd_received'] and owner.cwd is not context['cwd']:
            raise ProducerError('auxiliary early cwd reference changed')

    try:
        context['input_values']=values()
        value=call('initial_directory_path',lambda:constructor,(directory,))
        context['directory']=value;context['directory_received']=True
        owner.directory=value
        check()
        value=call('initial_cwd_path',lambda:constructor,(cwd,))
        context['cwd']=value;context['cwd_received']=True
        owner.cwd=value
        check()
        value=call('initial_directory_resolve',lambda:context['directory'].resolve,(),dict(strict=True))
        context['directory_resolved']=value
        check()
        if value!=context['directory']:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        value=call('initial_cwd_resolve',lambda:context['cwd'].resolve,(),dict(strict=True))
        context['cwd_resolved']=value
        check()
        if value!=context['cwd']:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        context['completed']=True # Paths only, never initializer/public constructor/EX.
    except BaseException as error:
        # Native call errors already own their step row. Post-check errors have
        # no invented native-call attribution; bind first before metadata.
        fail(error)


class AuxiliaryCommand:
    """Waitable direct child + two output pipes; never live admission.

    The owner registers this prepared object BEFORE start(). All actor handles
    stay here while pending. EOF proves no writer identity or descendant exit.
    """
    def __new__(cls,*args,**kwargs):
        record=_AuxiliaryInitializationAttempt('public_new',cls)
        record.constructor_arguments=(args,kwargs)
        _AUXILIARY_INITIALIZATIONS.append(record) # Before allocation and init IO.
        try:
            record.allocation_attempted=True
            instance=record._step('allocation',lambda:object.__new__,(cls,))
            record.object=instance # Raw reference before metadata or initialization.
            record.allocation_returned=True
            _bind_auxiliary_initialization(instance,record)
            return instance
        except BaseException as error:
            record._fail(error,record.steps[-1] if record.steps else None)

    def __init__(self,*,directory,name,argv,cwd,environment,lease_check,stdout_max=1024**3,stderr_max=32*1024**2):
        record=getattr(self,'_initialization_progress',None)
        if record is None:
            # Explicit old direct-initializer seams retain received self as DATA;
            # allocation/public class-call result remain UNKNOWN.
            record=_AuxiliaryInitializationAttempt('direct_initializer_data_only',type(self))
            _AUXILIARY_INITIALIZATIONS.append(record)
            _bind_auxiliary_initialization(self,record)
        elif type(record) is not _AuxiliaryInitializationAttempt or record.object is not self:
            previous=getattr(self,'_initialization_first_guard',None)
            if previous is not None:previous()
            raise ProducerError('auxiliary initialization binding changed')
        record.guard()
        fail=record._fail # Bound before initializer callbacks can change its alias.
        try:
            if record.initializer_attempted is not False:
                raise ProducerError('auxiliary initializer attempt is permanently terminal')
            record.initializer_attempted=True
            arguments=dict(directory=directory,name=name,argv=argv,cwd=cwd,environment=environment,
                lease_check=lease_check,stdout_max=stdout_max,stderr_max=stderr_max)
            raw=record._step('initializer',lambda:AuxiliaryCommand._initialize_auxiliary,(self,),arguments)
            record.initializer_result=raw # Before any contract check or marker.
            record.initializer_returned=True
            if raw is not None:raise TypeError('auxiliary initializer must return None')
            record.initializer_completed=True
            record.completed=True # Initializer only, NOT public class-call completion.
        except BaseException as error:
            fail(error) # Preserve private first and outer attribution despite nested rows.

    def _initialize_auxiliary(self,*,directory,name,argv,cwd,environment,lease_check,stdout_max=1024**3,stderr_max=32*1024**2):
        if (type(name) is not str or not re.fullmatch('[a-z][a-z0-9-]{0,48}',name)
            or type(argv) is not list or not argv or any(type(x) is not str or not x or '\0' in x for x in argv)
            or type(environment) is not dict or any(type(k) is not str or type(v) is not str or '\0' in k+v for k,v in environment.items())
            or any(type(x) is not int or not 0<x<=16*1024**3 for x in (stdout_max,stderr_max))):
            raise ProducerError('invalid auxiliary command declaration')
        _auxiliary_initial_paths(self,directory,cwd,argv,environment)
        self.name=name;self.argv=tuple(argv);self.environment=MappingProxyType(dict(environment));self.lease_check=lease_check
        self.started=False;self.pending=False;self.finished=False;self.process=None;self.result=None
        self.error=None;self.secondary_errors=[];self.failure_attempted=False;self.publication_attempted=False
        self.status=None;self.spawn_error=None;self.streams={}
        self._natural_wait_observed=False;self._natural_wait_status=None;self._natural_wait_process=None
        for role,maximum in [('stdout',stdout_max),('stderr',stderr_max)]:
            self.streams[role]={'path':self.directory/(name+'.'+role),'maximum':maximum,'log':None,'fd':None,'writer':None,
                'buffer':b'','hash':hashlib.sha256(),'bytes':0,'eof':False,'quarantined':False,'write_close_confirmed':False}
        allocation=dict(reserved=False,stage='unattempted',original_class=None,original_new=None,original_init=None,
            arguments=None,constructor_attempted=False,constructor_returned=None,allocation_attempted=False,allocation_returned=None,
            allocated_process=None,initializer_attempted=False,initializer_returned=None,initializer_result=None,initializer_result_valid=None,
            first_error=None,error_stage=None)
        self._process_allocation=allocation;self._allocated_process=None;self._process_allocation_arguments=None
        self._allocation_primary_error=None;self._allocation_secondary_errors=[]
        self._process_allocation_binding=(allocation,self._allocation_secondary_errors)
        self._constructor_primary_error=None;self._constructor_secondary_errors=[];self._constructor_quarantined=False
        quarantine=dict(attempted=False,returned=None,quarantined=False,first_error=None,
            secondary_errors=self._constructor_secondary_errors,streams=(),allocated_process=None,
            allocation_binding=self._process_allocation_binding)
        self._constructor_quarantine=quarantine
        self._constructor_quarantine_binding=(quarantine,self._process_allocation_binding,self.streams,
            self.streams['stdout'],self.streams['stderr'],self.lease_check,self._constructor_secondary_errors)
        self._startup_primary_error=None;self._startup_secondary_errors=[];self._startup_quarantined=False
        self._startup_state=dict(first_error=None,quarantined=False,current=None);self._startup_journal=[]
        self._startup_journal_binding=(self._startup_state,self._startup_journal,self._constructor_quarantine_binding,self._startup_secondary_errors)
        self._creator_close_primary_error=None;self._creator_close_secondary_errors=[];self._creator_close_quarantined=False
        self._creator_close_state=dict(first_error=None,quarantined=False,current=None);self._creator_close_journal=[]
        self._creator_close_binding=(self._creator_close_state,self._creator_close_journal,self._constructor_quarantine_binding,self._creator_close_secondary_errors)
        self._finalization_primary_error=None;self._finalization_secondary_errors=[];self._finalization_quarantined=False
        self._finalization_state=dict(attempted=False,completed=False,first_error=None,quarantined=False,current=None,candidate_result=None)
        self._finalization_journal=[]
        self._finalization_binding=(self._finalization_state,self._finalization_journal,self._constructor_quarantine_binding,self._creator_close_binding,self._finalization_secondary_errors)
        self._deferred_primary_error=None;self._deferred_secondary_errors=[];self._deferred_quarantined=False
        self._deferred_state=dict(received=False,first_error=None,quarantined=False)
        self._deferred_binding=(self._deferred_state,self._constructor_quarantine_binding,self._deferred_secondary_errors)
        self._buffer_write_state=dict(current=None);self._buffer_write_journal=[]
        self._buffer_write_binding=(self._buffer_write_state,self._buffer_write_journal,self._constructor_quarantine_binding)
        self._status_poll_state=dict(current=None);self._status_poll_journal=[]
        self._status_poll_binding=(self._status_poll_state,self._status_poll_journal,self._constructor_quarantine_binding,self._process_allocation_binding)
        self._direct_wait_state=dict(current=None);self._direct_wait_journal=[]
        self._direct_wait_binding=(self._direct_wait_state,self._direct_wait_journal,self._constructor_quarantine_binding,self._process_allocation_binding)
        self._stream_read_state=dict(current=None);self._stream_read_journal=[]
        self._stream_read_binding=(self._stream_read_state,self._stream_read_journal,self._constructor_quarantine_binding)
        self._select_state=dict(current=None);self._select_journal=[]
        self._select_binding=(self._select_state,self._select_journal,self._constructor_quarantine_binding)
        self._wait_lease_state=dict(current=None);self._wait_lease_journal=[]
        self._wait_lease_binding=(self._wait_lease_state,self._wait_lease_journal,self._constructor_quarantine_binding)
        self._start_lease_state=dict(current=None);self._start_lease_journal=[]
        self._start_lease_binding=(self._start_lease_state,self._start_lease_journal,self._constructor_quarantine_binding,self._startup_journal_binding)
        self._init_lease_primary_error=None;self._init_lease_quarantined=False;self._init_lease_secondary_errors=[]
        self._init_lease_state=dict(current=None,first_error=None,quarantined=False);self._init_lease_journal=[]
        self._init_lease_binding=(self._init_lease_state,self._init_lease_journal,self._constructor_quarantine_binding,self._init_lease_secondary_errors)
        self._intent_call_primary_error=None;self._intent_call_quarantined=False;self._intent_call_secondary_errors=[]
        self._intent_call_state=dict(current=None,first_error=None,quarantined=False,calls_completed=False);self._intent_call_journal=[]
        self._intent_call_binding=(self._intent_call_state,self._intent_call_journal,self._constructor_quarantine_binding,self._init_lease_binding,(_write_json,_regular_hash),self._intent_call_secondary_errors)
        self.intent={'scope':'auxiliary_command_intent_only','capture_ready':False,'argv':list(self.argv),'cwd':str(self.cwd),
            'environment_sha256':_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode()),
            'output_bounds':{'stdout':stdout_max,'stderr':stderr_max},'producer_sha256':_regular_hash(Path(__file__).resolve())}
        self._check_init_lease()
        self.intent_sha256=self._publish_intent(self.directory/(name+'-intent.json'))

    def _buffer_write_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary buffer-write guard scope')
        binding=self._buffer_write_binding
        if type(binding) is not tuple or len(binding)!=3:
            raise ProducerError('auxiliary buffer-write binding changed')
        state,journal,constructor=binding
        if (type(state) is not dict or any(type(key) is not str for key in state)
            or set(state)!={'current'} or state is not self._buffer_write_state
            or type(journal) is not list or journal is not self._buffer_write_journal
            or constructor is not self._constructor_quarantine_binding):
            raise ProducerError('auxiliary buffer-write state changed')
        required={'stream','role','log','hasher','buffer','input_len','before_bytes','maximum','read_fd','process','write_method','write_lookup_attempted','write_lookup_returned','write_attempted','write_returned','raw_count','count_valid','hash_method','hash_lookup_attempted','hash_lookup_returned','hash_attempted','hash_returned','hash_raw_return','hash_result_valid','hash_input','committed','completed','error','secondary_error'}
        for row in (journal if whole else journal[-1:]):
            if (type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required
                or type(row['role']) is not str or row['role'] not in ('stdout','stderr')
                or row['stream'] is not constructor[3 if row['role']=='stdout' else 4]
                or row['process'] is not constructor[0].get('allocated_process')
                or type(row['input_len']) is not int or row['input_len']<=0
                or type(row['before_bytes']) is not int or row['before_bytes']<0
                or type(row['maximum']) is not int or row['before_bytes']+row['input_len']>row['maximum']
                or type(row['read_fd']) is not int or row['read_fd']<0
                or row['write_method'] is None or row['hash_method'] is None
                or type(row['raw_count']) is not int or not 0<row['raw_count']<=row['input_len']
                or row['write_lookup_attempted'] is not True or row['write_lookup_returned'] is not True
                or row['write_attempted'] is not True or row['write_returned'] is not True or row['count_valid'] is not True
                or row['hash_lookup_attempted'] is not True or row['hash_lookup_returned'] is not True
                or row['hash_attempted'] is not True or row['hash_returned'] is not True
                or row['hash_raw_return'] is not None or row['hash_result_valid'] is not True
                or row['committed'] is not True or row['completed'] is not True
                or row['buffer'] is not None or row['hash_input'] is not None
                or row['error'] is not None or row['secondary_error'] is not None):
                raise ProducerError('auxiliary buffer-write operation unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current buffer-write changed')

    def _write_buffer(self,stream):
        self._constructor_guard()
        binding=self._buffer_write_binding;state,journal,constructor=binding
        row=dict(stream=stream,role=None,log=None,hasher=None,buffer=None,input_len=None,before_bytes=None,
            maximum=None,read_fd=None,process=None,write_method=None,write_lookup_attempted=False,
            write_lookup_returned=None,write_attempted=False,write_returned=None,raw_count=None,count_valid=None,
            hash_method=None,hash_lookup_attempted=False,hash_lookup_returned=None,hash_attempted=False,
            hash_returned=None,hash_raw_return=None,hash_result_valid=None,hash_input=None,
            committed=False,completed=False,error=None,secondary_error=None)
        journal.append(row);state['current']=row
        buffer=None;prefix=None
        try:
            if type(stream) is not dict or any(type(key) is not str for key in stream):
                raise ProducerError('unknown auxiliary buffered stream')
            role='stdout' if stream is constructor[3] else 'stderr' if stream is constructor[4] else None
            row['role']=role;row['log']=log=stream['log'];row['hasher']=hasher=stream['hash']
            row['buffer']=buffer=stream['buffer'];row['before_bytes']=before=stream['bytes']
            row['maximum']=maximum=stream['maximum'];row['read_fd']=read_fd=stream['fd']
            row['process']=process=constructor[0].get('allocated_process')
            if (role is None or type(buffer) is not bytes or not buffer
                or type(before) is not int or before<0 or type(maximum) is not int
                or type(read_fd) is not int or read_fd<0
                or before+len(buffer)>maximum):
                raise ProducerError('auxiliary stream exceeds declared output bound')
            row['input_len']=len(buffer)
            def check():
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or type(stream) is not dict or any(type(key) is not str for key in stream)
                    or type(self.streams) is not dict or any(type(key) is not str for key in self.streams)):
                    raise ProducerError('auxiliary buffered write metadata changed')
                if (self._buffer_write_binding is not binding or self._buffer_write_state is not state
                    or self._buffer_write_journal is not journal or state['current'] is not row
                    or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or self.streams is not constructor[2]
                    or self.streams.get(role) is not stream or self.process is not process
                    or stream.get('log') is not log or stream.get('hash') is not hasher
                    or stream.get('buffer') is not buffer or type(stream.get('bytes')) is not int
                    or stream['bytes']!=before or type(stream.get('maximum')) is not int or stream['maximum']!=maximum
                    or type(stream.get('fd')) is not type(read_fd) or stream.get('fd')!=read_fd):
                    raise ProducerError('auxiliary buffered write binding changed')
            row['write_lookup_attempted']=True;writer=log.write
            row['write_method']=writer;row['write_lookup_returned']=True;check()
            row['write_attempted']=True;count=writer(buffer)
            row['raw_count']=count;row['write_returned']=True
            if type(count) is not int or not 0<count<=len(buffer):
                raise ProducerError('auxiliary write count uncertain')
            row['count_valid']=True;check()
            row['hash_lookup_attempted']=True;updater=hasher.update
            row['hash_method']=updater;row['hash_lookup_returned']=True
            prefix=buffer[:count];row['hash_input']=prefix;check()
            row['hash_attempted']=True;value=updater(prefix)
            row['hash_raw_return']=value;row['hash_returned']=True
            if value is not None:raise ProducerError('auxiliary hash update return uncertain')
            row['hash_result_valid']=True;check()
            stream['bytes']=before+count;stream['buffer']=buffer[count:];row['committed']=True
            # Completed bytes are already in the original log, as in the old path.
            # Keep raw buffers forever only for an uncertain operation.
            row['buffer']=None;row['hash_input']=None;row['completed']=True
            return count
        except BaseException as error:
            row['error']=error;row['buffer']=buffer;row['hash_input']=prefix
            try:
                if type(stream) is dict and all(type(key) is str for key in stream):stream['quarantined']=True
            except BaseException as secondary:row['secondary_error']=secondary
            self._defer(error)

    def _deferred_error(self):
        def native(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return value if any(kind is BaseException for kind in chain) else None
        binding=getattr(self,'_deferred_binding',None)
        if type(binding) is tuple and len(binding)==3:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=native(state.get('first_error'))
                if first is not None:return first
        return native(getattr(self,'_deferred_primary_error',None))

    def _deferred_guard(self):
        first=self._deferred_error()
        if first is not None:raise first
        binding=self._deferred_binding
        if type(binding) is not tuple or len(binding)!=3:
            raise ProducerError('auxiliary deferred-error binding changed')
        state,constructor,secondary=binding
        if (type(state) is not dict or any(type(key) is not str for key in state)
            or set(state)!={'received','first_error','quarantined'}
            or state is not self._deferred_state or state['received'] is not False
            or state['first_error'] is not None or state['quarantined'] is not False
            or self._deferred_primary_error is not None or self._deferred_quarantined is not False
            or constructor is not self._constructor_quarantine_binding
            or type(secondary) is not list or secondary is not self._deferred_secondary_errors or len(secondary)!=0):
            raise ProducerError('auxiliary deferred-error state changed')

    def _defer(self,error):
        # Retain the received object before any binding check or reporting hook.
        self._deferred_primary_error=error;self._deferred_quarantined=True
        binding=getattr(self,'_deferred_binding',None)
        if type(binding) is tuple and len(binding)==3:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=state.get('first_error')
                chain=type.__dict__['__mro__'].__get__(type(first),type)
                if any(kind is BaseException for kind in chain):
                    self._deferred_primary_error=first
                    if error is not first and type(binding[2]) is list:list.append(binding[2],error)
                else:state['first_error']=error;state['received']=True;state['quarantined']=True
        # Earlier bound constructor/creator/finalization errors keep precedence.
        self._constructor_guard()
        raise ProducerError('auxiliary deferred error is not an exception instance')


    def _close_slot(self,stream,slot):
        self._constructor_guard()
        binding=self._creator_close_binding
        row=dict(role=None,slot=slot,fd=None,stream=stream,log=None,process=self.process,
            attempted=False,returned=None,raw_return=None,result_valid=None,completed=False,error=None)
        binding[0]['current']=row;list.append(binding[1],row)
        try:
            constructor=binding[2]
            if type(slot) is not str or slot not in ('fd','writer'):
                raise ProducerError('original auxiliary creator slot required')
            if stream is constructor[3]:role='stdout';index=0
            elif stream is constructor[4]:role='stderr';index=1
            else:raise ProducerError('original auxiliary creator stream required')
            if type(stream) is not dict or any(type(key) is not str for key in stream):
                raise ProducerError('native auxiliary creator stream required')
            row['role']=role;fd=stream[slot];row['fd']=fd
            if fd is None:
                row['completed']=True;return False
            quarantine=constructor[0];resources=quarantine.get('streams')
            if (type(resources) is not tuple or len(resources)!=2 or type(resources[index]) is not tuple
                or len(resources[index])!=5 or quarantine.get('returned') is not True):
                raise ProducerError('original returned auxiliary creator resources required')
            original=resources[index];row['log']=original[2]
            expected=original[3 if slot=='fd' else 4]
            if (type(fd) is not int or type(expected) is not int or fd!=expected or fd<0
                or original[1] is not stream or stream.get('log') is not original[2]
                or self.process is not quarantine.get('allocated_process')):
                raise ProducerError('auxiliary creator target changed')
            row['attempted']=True
            raw=os.close(fd)
            row['raw_return']=raw;row['returned']=True;row['result_valid']=raw is None
            if raw is not None:raise TypeError('native creator close must return None')
            # Return facts precede metadata checks; never clear a replaced slot.
            self._startup_guard()
            if (self._creator_close_binding is not binding or binding[0] is not self._creator_close_state
                or binding[1] is not self._creator_close_journal
                or binding[3] is not self._creator_close_secondary_errors
                or stream.get(slot) is not fd or stream.get('log') is not original[2]
                or self.process is not row['process']):
                raise ProducerError('auxiliary creator binding changed after close')
            stream[slot]=None;row['completed']=True
            return True
        except BaseException as error:
            self._retain_creator_close_error(binding,row,error)
            raise self._creator_close_primary_error

    def start(self):
        self._constructor_guard()
        if self.started or self.finished:raise ProducerError('auxiliary start attempt is permanently terminal')
        self.started=True;allocation=None;constructor_binding=None;startup_binding=self._startup_journal_binding
        try:
            allocation=self._allocation_record();allocation['reserved']=True
            self._startup_step(startup_binding,'lease_check',lambda:self._check_start_lease());self._allocation_record()
            sealed=self._startup_step(startup_binding,'read_intent',lambda:_read_json(self.directory/(self.name+'-intent.json'),self.intent_sha256))
            if (sealed['argv']!=list(self.argv) or sealed['cwd']!=str(self.cwd)
                or sealed['environment_sha256']!=_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode())
                or sealed['output_bounds']!={k:v['maximum'] for k,v in self.streams.items()}
                or sealed['producer_sha256']!=self._startup_step(startup_binding,'producer_hash',lambda:_regular_hash(Path(__file__).resolve()))):
                raise ProducerError('auxiliary declared plan changed')
            self._startup_step(startup_binding,'write_started',lambda:_write_json(self.directory/(self.name+'-started.json'),{'intent_sha256':self.intent_sha256,'terminal':True}))
            for role,stream in self.streams.items():
                stream['log']=self._startup_step(startup_binding,role+':log_open',lambda:stream['path'].open('xb',buffering=0))
                stream['fd'],stream['writer']=self._startup_step(startup_binding,role+':pipe',lambda:os.pipe())
                self._startup_step(startup_binding,role+':reader_inherit',lambda:os.set_inheritable(stream['fd'],False));self._startup_step(startup_binding,role+':writer_inherit',lambda:os.set_inheritable(stream['writer'],False))
                self._startup_step(startup_binding,role+':reader_nonblocking',lambda:os.set_blocking(stream['fd'],False))
            constructor_binding=self._arm_constructor()
            self.process=self._allocate_process(allocation)
            constructor_binding[0]['returned']=True
            # Retain the actual owned process BEFORE fallible closure/publication.
            self.pending=True
        except BaseException as error:
            self._retain_allocation_error(allocation,'start',error)
            if constructor_binding is not None:
                self._quarantine_constructor(constructor_binding,error)
                raise self._constructor_primary_error
            self._quarantine_startup(startup_binding,error)
            raise self._startup_primary_error
        for stream in self.streams.values():stream['write_close_confirmed']=self._close_slot(stream,'writer')
        try:_write_json(self.directory/(self.name+'-spawned.json'),{'pid':self.process.pid,'intent_sha256':self.intent_sha256})
        except BaseException as error:self._defer(error)
        return self

    def _allocation_record(self):
        binding=self._process_allocation_binding
        required={'reserved','stage','original_class','original_new','original_init','arguments',
            'constructor_attempted','constructor_returned','allocation_attempted','allocation_returned',
            'allocated_process','initializer_attempted','initializer_returned','initializer_result',
            'initializer_result_valid','first_error','error_stage'}
        if type(binding) is not tuple or len(binding)!=2:
            raise ProducerError('auxiliary allocation binding changed')
        record,history=binding
        if (type(record) is not dict or any(type(key) is not str for key in record)
            or set(record)!=required or record is not self._process_allocation
            or type(history) is not list or history is not self._allocation_secondary_errors
            or record['allocated_process'] is not self._allocated_process
            or record['arguments'] is not self._process_allocation_arguments):
            raise ProducerError('auxiliary allocation record changed')
        return record

    def _retain_allocation_error(self,record,stage,error):
        # Exact first object precedes dictionary/public reporting operations.
        if self._allocation_primary_error is None:self._allocation_primary_error=error
        else:
            binding=self._process_allocation_binding
            if type(binding) is tuple and len(binding)==2 and type(binding[1]) is list:
                list.append(binding[1],(stage,error))
        if (type(record) is dict and all(type(key) is str for key in record)
            and 'first_error' in record and 'error_stage' in record and record['first_error'] is None):
            record['first_error']=error;record['error_stage']=stage

    def _initialize_process(self,initializer,process,arguments):
        argv,cwd,environment,stdin,stdout,stderr,close_fds=arguments
        return initializer(process,argv,cwd=cwd,env=environment,stdin=stdin,
            stdout=stdout,stderr=stderr,close_fds=close_fds)

    def _allocate_process(self,record):
        constructor=self._constructor_record()
        cls=_COMMAND_POPEN_TYPE;allocator=_COMMAND_POPEN_NEW;initializer=_COMMAND_POPEN_INIT
        # Preserve the original start call's copies and evaluation BEFORE allocation.
        arguments=(list(self.argv),self.cwd,dict(self.environment),subprocess.DEVNULL,
            self.streams['stdout']['writer'],self.streams['stderr']['writer'],True)
        self._process_allocation_arguments=arguments;record['arguments']=arguments
        record['original_class']=cls;record['original_new']=allocator;record['original_init']=initializer
        record['constructor_attempted']=True;record['stage']='Popen_check'
        def check():
            if (self._allocation_record() is not record or subprocess.Popen is not cls
                or _COMMAND_POPEN_TYPE is not cls or _COMMAND_POPEN_NEW is not allocator
                or _COMMAND_POPEN_INIT is not initializer or type(cls) is not type
                or allocator is not object.__new__ or type.__getattribute__(cls,'__new__') is not allocator
                or type.__getattribute__(cls,'__init__') is not initializer):
                raise ProducerError('original auxiliary constructor binding changed')
            if self._constructor_record() is not constructor:
                raise ProducerError('original auxiliary quarantine binding changed')
        check()
        record['stage']='Popen_allocate';record['allocation_attempted']=True
        try:process=allocator(cls)
        except BaseException as error:
            self._retain_allocation_error(record,'Popen_allocate',error)
            record['allocation_returned']=False
            raise
        self._allocated_process=process;record['allocated_process']=process;record['allocation_returned']=True
        constructor['allocated_process']=process
        if type(process) is not cls:raise ProducerError('exact allocated auxiliary object required')
        check()
        record['stage']='Popen_initialize';record['initializer_attempted']=True
        try:returned=self._initialize_process(initializer,process,arguments)
        except BaseException as error:
            self._retain_allocation_error(record,'Popen_initialize',error)
            record['initializer_returned']=False
            raise
        record['initializer_result']=returned;record['initializer_returned']=True
        record['initializer_result_valid']=returned is None
        if returned is not None:
            label=type.__dict__['__name__'].__get__(type(returned),type)
            error=TypeError("__init__() should return None, not '"+label+"'")
            self._retain_allocation_error(record,'Popen_result',error)
            raise error
        check()
        record['stage']='Popen_return';record['constructor_returned']=True
        return process

    def _status_poll_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary poll guard scope')
        binding=self._status_poll_binding
        if type(binding) is not tuple or len(binding)!=4:
            raise ProducerError('auxiliary poll binding changed')
        state,journal,constructor,allocation=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._status_poll_state or type(journal) is not list or journal is not self._status_poll_journal
            or constructor is not self._constructor_quarantine_binding or allocation is not self._process_allocation_binding
            or constructor[1] is not allocation):
            raise ProducerError('auxiliary poll state changed')
        required={'process','constructor_record','constructor_returned','public_process_before','status_before','method','lookup_attempted','lookup_returned','poll_attempted','returned','raw_return','value_valid','status_committed','completed','error'}
        for row in (journal if whole else journal[-1:]):
            if (type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required
                or row['constructor_record'] is not constructor[0] or row['constructor_returned'] is not True
                or row['process'] is not constructor[0].get('allocated_process') or row['process'] is None
                or row['public_process_before'] is not row['process']
                or row['status_before'] is not None and type(row['status_before']) is not int
                or row['method'] is None or row['lookup_attempted'] is not True or row['lookup_returned'] is not True
                or row['poll_attempted'] is not True or row['returned'] is not True
                or row['raw_return'] is not None and type(row['raw_return']) is not int
                or row['value_valid'] is not True or type(row['status_committed']) is not bool
                or row['status_committed'] is not (row['raw_return'] is not None)
                or row['completed'] is not True or row['error'] is not None):
                raise ProducerError('auxiliary poll operation unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current poll changed')

    def _observe_status(self):
        self._constructor_guard()
        binding=self._status_poll_binding;state,journal,constructor,allocation=binding
        row=dict(process=None,constructor_record=None,constructor_returned=None,public_process_before=None,
            status_before=None,method=None,lookup_attempted=False,lookup_returned=None,poll_attempted=False,
            returned=None,raw_return=None,value_valid=None,status_committed=False,completed=False,error=None)
        journal.append(row);state['current']=row
        try:
            record=constructor[0];row['constructor_record']=record
            row['process']=process=record.get('allocated_process');row['public_process_before']=self.process
            row['status_before']=previous=self.status
            if (record.get('attempted') is not True or record.get('returned') is not True or process is None
                or type(allocation) is not tuple or len(allocation)!=2
                or type(allocation[0]) is not dict or any(type(key) is not str for key in allocation[0])
                or allocation[0].get('allocated_process') is not process
                or allocation[0].get('initializer_returned') is not True
                or allocation[0].get('initializer_result_valid') is not True
                or allocation[0].get('initializer_result') is not None):
                raise ProducerError('original normal auxiliary constructor required before poll')
            row['constructor_returned']=True
            def check():
                if (type(record) is not dict or any(type(key) is not str for key in record)
                    or type(allocation[0]) is not dict or any(type(key) is not str for key in allocation[0])):
                    raise ProducerError('auxiliary poll constructor metadata changed')
                if (record.get('attempted') is not True or record.get('returned') is not True
                    or record.get('allocated_process') is not process
                    or allocation[0].get('allocated_process') is not process
                    or allocation[0].get('initializer_returned') is not True
                    or allocation[0].get('initializer_result_valid') is not True
                    or allocation[0].get('initializer_result') is not None):
                    raise ProducerError('auxiliary poll constructor facts changed')
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or self._status_poll_binding is not binding or self._status_poll_state is not state
                    or self._status_poll_journal is not journal or state['current'] is not row
                    or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor
                    or self._process_allocation_binding is not allocation
                    or self.process is not process or self.status is not previous):
                    raise ProducerError('original auxiliary poll binding changed')
            if previous is not None and type(previous) is not int:
                raise ProducerError('unknown previous auxiliary status')
            check();row['lookup_attempted']=True;method=process.poll
            row['method']=method;row['lookup_returned']=True;check()
            row['poll_attempted']=True;value=method()
            row['raw_return']=value;row['returned']=True
            if value is not None and type(value) is not int:
                raise ProducerError('unknown auxiliary poll return')
            row['value_valid']=True;check()
            if value is not None:self.status=value;row['status_committed']=True
            row['completed']=True
        except BaseException as error:
            row['error']=error
            self._defer(error)


    def _complete(self):
        self._constructor_guard()
        try:self._intent_call_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._init_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._start_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._wait_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._select_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._stream_read_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._direct_wait_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._status_poll_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._buffer_write_guard(whole=True)
        except BaseException as error:self._defer(error)
        binding=self._finalization_binding;state=binding[0]
        if state['attempted']:raise ProducerError('auxiliary finalization attempt is permanently terminal')
        state['attempted']=True
        try:
            if (self._natural_wait_observed is not True or type(self._natural_wait_status) is not int
                or self._natural_wait_process is not self.process or type(self.status) is not int
                or self.status!=self._natural_wait_status):
                raise ProducerError('actual same auxiliary method wait required before finalization')
            constructor=binding[2];resources=constructor[0].get('streams')
            if type(resources) is not tuple or len(resources)!=2:
                raise ProducerError('original auxiliary finalization writers required')
            output={}
            for index,role in enumerate(('stdout','stderr')):
                stream=constructor[3+index];original=resources[index]
                if (type(original) is not tuple or len(original)!=5 or original[1] is not stream
                    or type(stream) is not dict or any(type(key) is not str for key in stream)
                    or self.streams.get(role) is not stream or stream.get('eof') is not True
                    or type(stream.get('buffer')) is not bytes or stream['buffer']
                    or stream.get('fd') is not None or stream.get('writer') is not None
                    or stream.get('write_close_confirmed') is not True or stream.get('quarantined') is not False
                    or stream.get('log') is not original[2]):
                    raise ProducerError('known auxiliary EOF/empty buffers/original writer required')
                for slot in ('fd','writer'):
                    if not any(row.get('stream') is stream and row.get('slot')==slot
                        and row.get('attempted') is True and row.get('returned') is True
                        and row.get('raw_return') is None and row.get('result_valid') is True
                        and row.get('completed') is True for row in binding[3][1]):
                        raise ProducerError('known creator close return required before writer finalization')
                log=original[2]
                self._finalization_step(binding,'flush',role,log,None,lambda:log.flush())
                fd=self._finalization_step(binding,'fileno',role,log,None,lambda:log.fileno())
                self._finalization_step(binding,'fsync',role,log,fd,lambda:os.fsync(fd))
                self._finalization_step(binding,'close',role,log,fd,lambda:log.close())
                stream['log']=None
                item={'eof':stream['eof'],'stream_bytes':stream['bytes'],'stream_sha256':stream['hash'].hexdigest(),
                    'parent_write_close_confirmed':stream['write_close_confirmed'],'quarantined':stream['quarantined']}
                item['snapshot']=self._finalization_step(binding,'snapshot',role,log,None,
                    lambda:_file_snapshot(stream['path'],stream['maximum']))
                item['snapshot_matches_stream']=item['snapshot']=={'size':stream['bytes'],'sha256':stream['hash'].hexdigest()}
                if not item['snapshot_matches_stream']:raise ProducerError('auxiliary log bytes changed: '+role)
                output[role]=item
            okay=(self.error is None and self.spawn_error is None and self.status==0
                and all(s['eof'] and s['write_close_confirmed'] for s in self.streams.values()))
            result={'kind':'auxiliary-command-observation-v1','scope':'owned_direct_child_and_two_output_streams_only',
                'capture_ready':False,'whole_descendant_exit_proven':False,'intent_sha256':self.intent_sha256,
                'argv':list(self.argv),'cwd':str(self.cwd),'pid':None if self.process is None else self.process.pid,
                'returncode':self.status,'spawn_error':self.spawn_error,'status':'success' if okay else 'failed',
                'primary_error':self.error,'secondary_errors':self.secondary_errors,'outputs':output}
            if self.status is not None and self.status!=0 and result['primary_error'] is None:result['primary_error']='auxiliary command nonzero or signal'
            state['candidate_result']=result;self.publication_attempted=True
            self._finalization_step(binding,'result',None,None,None,
                lambda:_write_json(self.directory/(self.name+'-result.json'),result))
            self.result=result;self.pending=False;self.finished=True;state['completed']=True
            return result
        except BaseException as error:
            self._retain_finalization_error(binding,None,error)
            raise self._finalization_primary_error


    def _direct_wait_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary direct wait guard scope')
        binding=self._direct_wait_binding
        if type(binding) is not tuple or len(binding)!=4:raise ProducerError('auxiliary direct wait binding changed')
        state,journal,constructor,allocation=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._direct_wait_state or type(journal) is not list or journal is not self._direct_wait_journal
            or constructor is not self._constructor_quarantine_binding or allocation is not self._process_allocation_binding
            or constructor[1] is not allocation):
            raise ProducerError('auxiliary direct wait state changed')
        required={'process','constructor_record','constructor_returned','public_process_before','timeout','witness_process_before','witness_observed_before','witness_status_before','process_bound','method','lookup_attempted','lookup_returned','wait_attempted','returned','raw_return','value_valid','timeout_received','timeout_error','witness_committed','completed','error','secondary_error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary direct wait record changed')
            normal=(row['returned'] is True and type(row['raw_return']) is int
                and row['value_valid'] is True and row['timeout_received'] is False
                and row['timeout_error'] is None and row['witness_committed'] is True)
            timed=(row['returned'] is None and row['raw_return'] is None and row['value_valid'] is None
                and row['timeout_received'] is True and row['timeout_error'] is not None
                and any(base is subprocess.TimeoutExpired for base in type.__getattribute__(type(row['timeout_error']),'__mro__'))
                and row['witness_committed'] is False)
            if (row['constructor_record'] is not constructor[0] or row['constructor_returned'] is not True
                or row['process'] is not constructor[0].get('allocated_process') or row['process'] is None
                or row['public_process_before'] is not row['process']
                or not (type(row['timeout']) is int or type(row['timeout']) is float) or not 0<=row['timeout']<=60
                or (row['witness_process_before'] is not None and row['witness_process_before'] is not row['process'])
                or type(row['witness_observed_before']) is not bool
                or (row['witness_observed_before'] and (row['witness_process_before'] is not row['process'] or type(row['witness_status_before']) is not int))
                or (not row['witness_observed_before'] and row['witness_status_before'] is not None)
                or row['process_bound'] is not True or row['method'] is None
                or row['lookup_attempted'] is not True or row['lookup_returned'] is not True or row['wait_attempted'] is not True
                or not (normal or timed) or row['completed'] is not True
                or row['error'] is not None or row['secondary_error'] is not None):
                raise ProducerError('auxiliary direct wait operation unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current direct wait changed')

    def _stream_read_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary read guard scope')
        binding=self._stream_read_binding
        if type(binding) is not tuple or len(binding)!=3:raise ProducerError('auxiliary read binding changed')
        state,journal,constructor=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._stream_read_state or type(journal) is not list or journal is not self._stream_read_journal
            or constructor is not self._constructor_quarantine_binding):
            raise ProducerError('auxiliary read state changed')
        required={'stream','constructor_record','resources','original','read_fd','log','process','buffer_before','eof_before','reader','lookup_attempted','lookup_returned','read_attempted','returned','raw_return','raw_size','value_valid','buffer_committed','raw_consumed','expected_received','expected_error','completed','error','secondary_error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary read record changed')
            original=row['original'];resources=row['resources']
            normal=(row['returned'] is True and type(row['raw_size']) is int and 0<=row['raw_size']<=65536
                and row['value_valid'] is True and row['expected_received'] is False and row['expected_error'] is None
                and type(row['buffer_committed']) is bool and row['buffer_committed'] is (row['raw_size']>0)
                and row['raw_consumed'] is (row['raw_size']>0)
                and ((row['raw_size']>0 and row['raw_return'] is None) or (row['raw_size']==0 and type(row['raw_return']) is bytes and len(row['raw_return'])==0)))
            expected=(row['returned'] is None and row['raw_return'] is None and row['raw_size'] is None
                and row['value_valid'] is None and row['buffer_committed'] is False and row['raw_consumed'] is False
                and row['expected_received'] is True and row['expected_error'] is not None
                and any(base is BlockingIOError or base is InterruptedError for base in type.__getattribute__(type(row['expected_error']),'__mro__')))
            if (row['constructor_record'] is not constructor[0] or resources is not constructor[0].get('streams')
                or type(resources) is not tuple or len(resources)!=2 or type(original) is not tuple or len(original)!=5
                or not any(item is original for item in resources) or row['stream'] is not original[1]
                or type(row['read_fd']) is not int or type(original[3]) is not int or row['read_fd']!=original[3]
                or row['log'] is not original[2] or row['log'] is None
                or row['process'] is not constructor[0].get('allocated_process') or row['process'] is None
                or type(row['buffer_before']) is not bytes or row['buffer_before'] or row['eof_before'] is not False
                or row['reader'] is None or row['lookup_attempted'] is not True or row['lookup_returned'] is not True
                or row['read_attempted'] is not True or not (normal or expected)
                or row['completed'] is not True or row['error'] is not None or row['secondary_error'] is not None):
                raise ProducerError('auxiliary read operation unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current read changed')

    def _read_stream(self,stream):
        self._constructor_guard()
        binding=self._stream_read_binding;state,journal,constructor=binding
        row=dict(stream=stream,constructor_record=None,resources=None,original=None,read_fd=None,log=None,process=None,
            buffer_before=None,eof_before=None,reader=None,lookup_attempted=False,lookup_returned=None,read_attempted=False,
            returned=None,raw_return=None,raw_size=None,value_valid=None,buffer_committed=False,raw_consumed=False,
            expected_received=False,expected_error=None,completed=False,error=None,secondary_error=None)
        journal.append(row);state['current']=row;expected_error=None
        try:
            record=constructor[0];row['constructor_record']=record;row['resources']=resources=record.get('streams')
            if record.get('attempted') is not True or record.get('returned') is not True or type(resources) is not tuple or len(resources)!=2:
                raise ProducerError('original normal auxiliary resources required before read')
            index=0 if stream is constructor[3] else 1 if stream is constructor[4] else None
            if index is None:raise ProducerError('original auxiliary stream required before read')
            original=resources[index];row['original']=original
            if type(original) is not tuple or len(original)!=5 or original[1] is not stream:
                raise ProducerError('original auxiliary read tuple required')
            row['read_fd']=fd=original[3];row['log']=log=original[2];row['process']=process=record.get('allocated_process')
            if type(stream) is not dict or any(type(key) is not str for key in stream):
                raise ProducerError('native auxiliary read stream required')
            row['buffer_before']=previous_buffer=stream.get('buffer');row['eof_before']=previous_eof=stream.get('eof')
            if (type(fd) is not int or fd<0 or log is None or process is None
                or type(previous_buffer) is not bytes or previous_buffer or previous_eof is not False):
                raise ProducerError('known empty original auxiliary read state required')
            def check():
                if (type(record) is not dict or any(type(key) is not str for key in record)
                    or type(stream) is not dict or any(type(key) is not str for key in stream)
                    or type(state) is not dict or any(type(key) is not str for key in state)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])):
                    raise ProducerError('auxiliary read metadata changed')
                if (self._stream_read_binding is not binding or self._stream_read_state is not state
                    or self._stream_read_journal is not journal or state['current'] is not row or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or record.get('streams') is not resources
                    or record.get('attempted') is not True or record.get('returned') is not True
                    or resources[index] is not original or original[1] is not stream
                    or self.streams is not constructor[2] or constructor[2].get('stdout' if index==0 else 'stderr') is not stream
                    or constructor[3+index] is not stream or record.get('allocated_process') is not process or self.process is not process
                    or type(stream.get('fd')) is not int or stream.get('fd')!=fd or stream.get('log') is not log
                    or stream.get('buffer') is not previous_buffer or stream.get('eof') is not previous_eof):
                    raise ProducerError('original auxiliary read binding changed')
            check();row['lookup_attempted']=True;reader=os.read;row['reader']=reader;row['lookup_returned']=True;check()
            row['read_attempted']=True
            try:part=reader(fd,65536)
            except (BlockingIOError,InterruptedError) as received:
                expected_error=received;row['expected_error']=received;row['expected_received']=True
                check();row['completed']=True
            else:
                row['raw_return']=part;row['returned']=True
                if type(part) is not bytes:raise ProducerError('unknown auxiliary read return')
                row['raw_size']=size=len(part)
                if size>65536:raise ProducerError('auxiliary read exceeds original request')
                row['value_valid']=True;check()
                if part:
                    stream['buffer']=part;row['buffer_committed']=True
                    # Known transfer into the original buffer; unknown outcomes retain raw.
                    row['raw_return']=None;row['raw_consumed']=True
                row['completed']=True
        except BaseException as error:
            first=expected_error if expected_error is not None else error
            row['error']=first
            if first is not error:row['secondary_error']=error
            self._defer(first)
        if expected_error is not None:raise expected_error
        return part

    def _select_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary select guard scope')
        binding=self._select_binding
        if type(binding) is not tuple or len(binding)!=3:raise ProducerError('auxiliary select binding changed')
        state,journal,constructor=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._select_state or type(journal) is not list or journal is not self._select_journal
            or constructor is not self._constructor_quarantine_binding):
            raise ProducerError('auxiliary select state changed')
        required={'constructor_record','resources','process','streams_before','readers_arg','readers_before','expected_readers','writers_arg','exceptions_arg','timeout','selector','lookup_attempted','lookup_returned','select_attempted','returned','raw_return','value_valid','completed','error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary select record changed')
            resources=row['resources'];context=row['streams_before'];expected=row['expected_readers'];raw=row['raw_return']
            if (row['constructor_record'] is not constructor[0] or resources is not constructor[0].get('streams')
                or type(resources) is not tuple or len(resources)!=2 or type(context) is not tuple or len(context)!=2
                or row['process'] is not constructor[0].get('allocated_process') or row['process'] is None):
                raise ProducerError('auxiliary select resources unknown')
            derived=[]
            for index,snapshot in enumerate(context):
                original=resources[index]
                if (type(snapshot) is not tuple or len(snapshot)!=7 or type(original) is not tuple or len(original)!=5
                    or type(snapshot[0]) is not str or snapshot[0]!=('stdout' if index==0 else 'stderr')
                    or type(original[0]) is not str or original[0]!=snapshot[0]
                    or snapshot[1] is not constructor[3+index] or snapshot[1] is not original[1]
                    or snapshot[2] is not original or snapshot[4] is not original[2] or snapshot[4] is None
                    or type(original[3]) is not int or original[3]<0
                    or type(snapshot[5]) is not bytes or snapshot[5] or type(snapshot[6]) is not bool):
                    raise ProducerError('auxiliary select stream snapshot unknown')
                if snapshot[6] is False:
                    if type(snapshot[3]) is not int or snapshot[3]!=original[3]:raise ProducerError('auxiliary select reader changed')
                    derived.append(original[3])
                elif snapshot[3] is not None:raise ProducerError('auxiliary EOF reader changed')
            if (type(expected) is not tuple or not expected or any(type(fd) is not int for fd in expected)
                or len(set(expected))!=len(expected) or tuple(derived)!=expected
                or type(row['readers_before']) is not tuple or any(type(fd) is not int for fd in row['readers_before'])
                or row['readers_before']!=expected or type(row['readers_arg']) is not list
                or any(type(fd) is not int for fd in row['readers_arg']) or tuple(row['readers_arg'])!=expected
                or type(row['writers_arg']) is not list or row['writers_arg']
                or type(row['exceptions_arg']) is not list or row['exceptions_arg']
                or not (type(row['timeout']) is int or type(row['timeout']) is float) or not 0<=row['timeout']<=.05
                or row['selector'] is None or row['lookup_attempted'] is not True or row['lookup_returned'] is not True
                or row['select_attempted'] is not True or row['returned'] is not True
                or type(raw) is not tuple or len(raw)!=3 or any(type(part) is not list for part in raw)
                or any(type(fd) is not int for part in raw for fd in part)
                or raw[1] or raw[2] or len(raw[0])>len(expected) or not set(raw[0])<=set(expected)
                or row['value_valid'] is not True or row['completed'] is not True or row['error'] is not None):
                raise ProducerError('auxiliary select operation unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current select changed')

    def _select_readers(self,readers,timeout):
        self._constructor_guard()
        binding=self._select_binding;state,journal,constructor=binding
        row=dict(constructor_record=None,resources=None,process=None,streams_before=None,readers_arg=readers,
            readers_before=None,expected_readers=None,writers_arg=[],exceptions_arg=[],timeout=timeout,selector=None,
            lookup_attempted=False,lookup_returned=None,select_attempted=False,returned=None,raw_return=None,
            value_valid=None,completed=False,error=None)
        journal.append(row);state['current']=row
        try:
            record=constructor[0];row['constructor_record']=record;row['resources']=resources=record.get('streams')
            row['process']=process=record.get('allocated_process')
            if record.get('attempted') is not True or record.get('returned') is not True or process is None or type(resources) is not tuple or len(resources)!=2:
                raise ProducerError('original normal auxiliary select resources required')
            snapshots=[];expected=[]
            for index,role in enumerate(('stdout','stderr')):
                original=resources[index];stream=constructor[3+index]
                if (type(original) is not tuple or len(original)!=5 or original[1] is not stream
                    or type(original[0]) is not str or original[0]!=role or type(original[3]) is not int or original[3]<0
                    or type(stream) is not dict or any(type(key) is not str for key in stream)):
                    raise ProducerError('original auxiliary select stream required')
                snapshot=(role,stream,original,stream.get('fd'),stream.get('log'),stream.get('buffer'),stream.get('eof'))
                snapshots.append(snapshot)
                if snapshot[6] is False:expected.append(original[3])
                elif snapshot[6] is not True:raise ProducerError('unknown auxiliary EOF before select')
            row['streams_before']=context=tuple(snapshots);row['expected_readers']=expected=tuple(expected)
            if type(readers) is not list or any(type(fd) is not int for fd in readers):
                raise ProducerError('native auxiliary reader list required')
            row['readers_before']=before=tuple(readers)
            if not expected or len(set(expected))!=len(expected) or not (type(timeout) is int or type(timeout) is float) or not 0<=timeout<=.05:
                raise ProducerError('original bounded auxiliary select required')
            writers=row['writers_arg'];exceptions=row['exceptions_arg']
            def check():
                if (type(record) is not dict or any(type(key) is not str for key in record)
                    or type(state) is not dict or any(type(key) is not str for key in state)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])):
                    raise ProducerError('auxiliary select metadata changed')
                if (self._select_binding is not binding or self._select_state is not state or self._select_journal is not journal
                    or state['current'] is not row or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or record.get('streams') is not resources
                    or record.get('attempted') is not True or record.get('returned') is not True
                    or record.get('allocated_process') is not process or self.process is not process or self.streams is not constructor[2]
                    or type(readers) is not list or any(type(fd) is not int for fd in readers) or tuple(readers)!=before or before!=expected
                    or row['readers_arg'] is not readers or row['writers_arg'] is not writers or row['exceptions_arg'] is not exceptions
                    or type(writers) is not list or writers or type(exceptions) is not list or exceptions):
                    raise ProducerError('original auxiliary select binding changed')
                for index,snapshot in enumerate(context):
                    role,stream,original,fd,log,buffer,eof=snapshot
                    if (type(stream) is not dict or any(type(key) is not str for key in stream)
                        or resources[index] is not original or constructor[3+index] is not stream
                        or constructor[2].get(role) is not stream or original[1] is not stream
                        or log is not original[2] or log is None or type(buffer) is not bytes or buffer
                        or stream.get('fd') is not fd or stream.get('log') is not log
                        or stream.get('buffer') is not buffer or stream.get('eof') is not eof
                        or eof is False and (type(fd) is not int or fd!=original[3])
                        or eof is True and fd is not None):
                        raise ProducerError('original auxiliary select stream changed')
            check();row['lookup_attempted']=True;selector=select.select;row['selector']=selector;row['lookup_returned']=True;check()
            row['select_attempted']=True;value=selector(readers,writers,exceptions,timeout)
            row['raw_return']=value;row['returned']=True
            if (type(value) is not tuple or len(value)!=3 or any(type(part) is not list for part in value)
                or any(type(fd) is not int for part in value for fd in part)
                or value[1] or value[2] or len(value[0])>len(expected) or not set(value[0])<=set(expected)):
                raise ProducerError('unknown auxiliary select return')
            row['value_valid']=True;check();row['completed']=True
        except BaseException as error:
            row['error']=error
            self._defer(error)

    def _wait_lease_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary wait lease guard scope')
        binding=self._wait_lease_binding
        if type(binding) is not tuple or len(binding)!=3:raise ProducerError('auxiliary wait lease binding changed')
        state,journal,constructor=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._wait_lease_state or type(journal) is not list or journal is not self._wait_lease_journal
            or constructor is not self._constructor_quarantine_binding):
            raise ProducerError('auxiliary wait lease state changed')
        required={'constructor_record','resources','callback','public_callback_before','process','streams_before','callback_attempted','returned','raw_return','context_checked','context_released','completed','error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary wait lease record changed')
            resources=row['resources'];context=row['streams_before']
            if (row['constructor_record'] is not constructor[0] or resources is not constructor[0].get('streams')
                or type(resources) is not tuple or len(resources)!=2 or type(context) is not tuple or len(context)!=2
                or row['callback'] is not constructor[5] or row['public_callback_before'] is not row['callback']
                or row['process'] is not constructor[0].get('allocated_process') or row['process'] is None
                or row['callback_attempted'] is not True or row['returned'] is not True
                or row['context_checked'] is not True or row['context_released'] is not True
                or row['completed'] is not True or row['error'] is not None):
                raise ProducerError('auxiliary wait lease outcome unknown')
            for index,snapshot in enumerate(context):
                original=resources[index]
                if (type(snapshot) is not tuple or len(snapshot)!=9 or type(original) is not tuple or len(original)!=5
                    or type(snapshot[0]) is not str or snapshot[0]!=('stdout' if index==0 else 'stderr')
                    or type(original[0]) is not str or original[0]!=snapshot[0]
                    or snapshot[1] is not constructor[3+index] or snapshot[1] is not original[1]
                    or snapshot[2] is not original or snapshot[5] is not original[2] or snapshot[5] is None
                    or type(original[3]) is not int or type(original[4]) is not int
                    or snapshot[3] is not None and (type(snapshot[3]) is not int or snapshot[3]!=original[3])
                    or snapshot[4] is not None and (type(snapshot[4]) is not int or snapshot[4]!=original[4])
                    or snapshot[6] is not None or type(snapshot[7]) is not bool
                    or type(snapshot[8]) is not int or snapshot[8]<0):
                    raise ProducerError('auxiliary wait lease context unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current wait lease changed')

    def _check_wait_lease(self):
        self._constructor_guard()
        binding=self._wait_lease_binding;state,journal,constructor=binding
        row=dict(constructor_record=None,resources=None,callback=None,public_callback_before=None,process=None,
            streams_before=None,callback_attempted=False,returned=None,raw_return=None,context_checked=False,
            context_released=False,completed=False,error=None)
        journal.append(row);state['current']=row
        try:
            record=constructor[0];row['constructor_record']=record;row['resources']=resources=record.get('streams')
            row['callback']=callback=constructor[5];row['public_callback_before']=self.lease_check
            row['process']=process=record.get('allocated_process')
            if record.get('attempted') is not True or record.get('returned') is not True or process is None or type(resources) is not tuple or len(resources)!=2:
                raise ProducerError('original normal auxiliary wait lease context required')
            snapshots=[]
            for index,role in enumerate(('stdout','stderr')):
                original=resources[index];stream=constructor[3+index]
                if (type(original) is not tuple or len(original)!=5 or original[1] is not stream
                    or type(original[0]) is not str or original[0]!=role
                    or type(original[3]) is not int or type(original[4]) is not int
                    or type(stream) is not dict or any(type(key) is not str for key in stream)):
                    raise ProducerError('original auxiliary wait lease stream required')
                snapshots.append((role,stream,original,stream.get('fd'),stream.get('writer'),stream.get('log'),stream.get('buffer'),stream.get('eof')))
            row['streams_before']=context=tuple(snapshots)
            def check():
                if (type(record) is not dict or any(type(key) is not str for key in record)
                    or type(state) is not dict or any(type(key) is not str for key in state)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])):
                    raise ProducerError('auxiliary wait lease metadata changed')
                if (self._wait_lease_binding is not binding or self._wait_lease_state is not state
                    or self._wait_lease_journal is not journal or state['current'] is not row or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or record.get('streams') is not resources
                    or record.get('attempted') is not True or record.get('returned') is not True
                    or record.get('allocated_process') is not process or self.process is not process
                    or self.streams is not constructor[2] or self.lease_check is not callback):
                    raise ProducerError('original auxiliary wait lease binding changed')
                for index,snapshot in enumerate(context):
                    role,stream,original,fd,writer,log,buffer,eof=snapshot
                    if (type(stream) is not dict or any(type(key) is not str for key in stream)
                        or resources[index] is not original or constructor[3+index] is not stream or constructor[2].get(role) is not stream
                        or original[1] is not stream or log is not original[2] or log is None
                        or fd is not None and (type(fd) is not int or fd!=original[3])
                        or writer is not None and (type(writer) is not int or writer!=original[4])
                        or type(buffer) is not bytes or type(eof) is not bool
                        or stream.get('fd') is not fd or stream.get('writer') is not writer or stream.get('log') is not log
                        or stream.get('buffer') is not buffer or stream.get('eof') is not eof):
                        raise ProducerError('original auxiliary wait lease stream changed')
            check();row['callback_attempted']=True;value=callback()
            # The original contract ignored this return; retain DATA without truth/type gating.
            row['raw_return']=value;row['returned']=True
            check();row['context_checked']=True
            # A known unchanged callback does not need duplicate live buffer references.
            row['streams_before']=tuple((role,stream,original,fd,writer,log,None,eof,len(buffer))
                for role,stream,original,fd,writer,log,buffer,eof in context)
            row['context_released']=True;row['completed']=True
        except BaseException as error:
            row['error']=error
            self._defer(error)

    def _start_lease_guard(self,*,whole=False):
        if type(whole) is not bool:raise ProducerError('unknown auxiliary start lease guard scope')
        binding=self._start_lease_binding
        if type(binding) is not tuple or len(binding)!=4:raise ProducerError('auxiliary start lease binding changed')
        state,journal,constructor,startup=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current'}
            or state is not self._start_lease_state or type(journal) is not list or journal is not self._start_lease_journal
            or constructor is not self._constructor_quarantine_binding or startup is not self._startup_journal_binding):
            raise ProducerError('auxiliary start lease state changed')
        required={'callback','public_callback_before','startup_operation','process_before','streams_before','object_context',
            'stream_items_before','allocation_context','callback_attempted','returned','raw_return','context_checked','completed','error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary start lease record changed')
            operation=row['startup_operation'];context=row['streams_before']
            if (row['callback'] is not constructor[5] or row['public_callback_before'] is not row['callback']
                or row['process_before'] is not None or type(context) is not tuple or len(context)!=2
                or type(operation) is not dict or any(type(key) is not str for key in operation)
                or type(operation.get('stage')) is not str or operation.get('stage')!='lease_check' or operation.get('attempted') is not True
                or operation.get('returned') is not True or operation.get('value') is not row['raw_return'] or operation.get('error') is not None
                or row['callback_attempted'] is not True or row['returned'] is not True
                or row['context_checked'] is not True or row['completed'] is not True or row['error'] is not None):
                raise ProducerError('auxiliary start lease outcome unknown')
            for index,snapshot in enumerate(context):
                if (type(snapshot) is not tuple or len(snapshot)!=8
                    or type(snapshot[0]) is not str or snapshot[0]!=('stdout' if index==0 else 'stderr')
                    or snapshot[1] is not constructor[3+index] or snapshot[2] is not snapshot[1]
                    or type(snapshot[6]) is not bytes or type(snapshot[7]) is not bool):
                    raise ProducerError('auxiliary start lease context unknown')
            for name in ('object_context','allocation_context'):
                pairs=row[name]
                if type(pairs) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in pairs):
                    raise ProducerError('auxiliary start lease saved context changed')
            saved=row['stream_items_before']
            if (type(saved) is not tuple or len(saved)!=2
                or any(type(pairs) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in pairs) for pairs in saved)):
                raise ProducerError('auxiliary start lease saved stream changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current start lease changed')

    def _check_start_lease(self):
        # The enclosing startup operation is already pending; do not enter its completed-history guard here.
        binding=self._start_lease_binding;state,journal,constructor,startup=binding
        row=dict(callback=None,public_callback_before=None,startup_operation=None,process_before=None,
            streams_before=None,object_context=None,stream_items_before=None,allocation_context=None,
            callback_attempted=False,returned=None,raw_return=None,context_checked=False,completed=False,error=None)
        journal.append(row);state['current']=row
        try:
            row['callback']=callback=constructor[5];row['public_callback_before']=self.lease_check
            row['startup_operation']=operation=startup[0]['current'];row['process_before']=self.process
            attributes=('directory','cwd','name','argv','environment','intent','intent_sha256','process','started','pending',
                'finished','result','status','spawn_error','_allocated_process','_process_allocation_arguments')
            row['object_context']=objects=tuple((name,getattr(self,name)) for name in attributes)
            allocation=self._process_allocation_binding;record=allocation[0]
            if type(record) is not dict or any(type(key) is not str for key in record):
                raise ProducerError('original auxiliary start allocation required')
            row['allocation_context']=allocation_context=tuple(record.items())
            snapshots=[];items=[]
            for index,role in enumerate(('stdout','stderr')):
                stream=constructor[3+index]
                if type(stream) is not dict or any(type(key) is not str for key in stream):
                    raise ProducerError('original auxiliary start stream required')
                snapshots.append((role,stream,stream,stream.get('fd'),stream.get('writer'),stream.get('log'),stream.get('buffer'),stream.get('eof')))
                items.append(tuple(stream.items()))
            row['streams_before']=context=tuple(snapshots);row['stream_items_before']=stream_items=tuple(items)
            def same_items(current,pairs):
                return (type(current) is dict and all(type(key) is str for key in current)
                    and len(current)==len(pairs) and all(key in current and current[key] is value for key,value in pairs))
            def check():
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or type(startup[0]) is not dict or any(type(key) is not str for key in startup[0])
                    or type(operation) is not dict or any(type(key) is not str for key in operation)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])):
                    raise ProducerError('auxiliary start lease metadata changed')
                if (self._start_lease_binding is not binding or self._start_lease_state is not state
                    or self._start_lease_journal is not journal or state['current'] is not row or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or self._startup_journal_binding is not startup
                    or startup[0]['current'] is not operation or type(startup[1]) is not list or not startup[1] or startup[1][-1] is not operation
                    or type(operation.get('stage')) is not str or operation.get('stage')!='lease_check' or operation.get('attempted') is not True or operation.get('returned') is not None
                    or self._process_allocation_binding is not allocation or not same_items(record,allocation_context)
                    or self.streams is not constructor[2] or set(constructor[2])!={'stdout','stderr'}
                    or self.lease_check is not callback or self.process is not None
                    or any(getattr(self,name) is not value for name,value in objects)):
                    raise ProducerError('original auxiliary start lease binding changed')
                for index,snapshot in enumerate(context):
                    role,stream,original,fd,writer,log,buffer,eof=snapshot
                    if (constructor[3+index] is not stream or constructor[2].get(role) is not stream
                        or type(buffer) is not bytes or type(eof) is not bool
                        or not same_items(stream,stream_items[index])):
                        raise ProducerError('original auxiliary start lease stream changed')
            check();row['callback_attempted']=True;value=callback()
            # The original startup callback return was ignored by start; retain it unchanged as DATA.
            row['raw_return']=value;row['returned']=True
            check();row['context_checked']=True;row['completed']=True
            return value
        except BaseException as error:
            row['error']=error
            # The enclosing original startup step retains/quarantines this exact first before further I/O.
            raise

    def _init_lease_error(self):
        def actual(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return any(kind is BaseException for kind in chain)
        primary=getattr(self,'_init_lease_primary_error',None)
        if primary is not None and actual(primary):return primary
        binding=getattr(self,'_init_lease_binding',None)
        if type(binding) is tuple and len(binding)==4:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=state.get('first_error')
                if first is not None and actual(first):return first
        return None

    def _init_lease_guard(self,*,whole=False):
        first=self._init_lease_error()
        if first is not None:raise first
        if type(whole) is not bool:raise ProducerError('unknown auxiliary init lease guard scope')
        binding=self._init_lease_binding
        if type(binding) is not tuple or len(binding)!=4:raise ProducerError('auxiliary init lease binding changed')
        state,journal,constructor,secondary=binding
        if (type(state) is not dict or any(type(key) is not str for key in state) or set(state)!={'current','first_error','quarantined'}
            or state is not self._init_lease_state or type(journal) is not list or journal is not self._init_lease_journal
            or constructor is not self._constructor_quarantine_binding or secondary is not self._init_lease_secondary_errors or type(secondary) is not list
            or state['first_error'] is not None or state['quarantined'] is not False
            or self._init_lease_primary_error is not None or self._init_lease_quarantined is not False):
            raise ProducerError('auxiliary init lease state changed or quarantined')
        required={'object','constructor','callback','public_callback_before','intent_before','intent_bytes_before','intent_native_before','object_context',
            'streams_before','stream_items_before','callback_attempted','returned','raw_return','context_checked','completed','error'}
        for row in (journal if whole else journal[-1:]):
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary init lease record changed')
            context=row['streams_before'];saved=row['stream_items_before'];objects=row['object_context']
            if (row['object'] is not self or row['constructor'] is not constructor
                or row['callback'] is not constructor[5] or row['public_callback_before'] is not row['callback']
                or type(row['intent_before']) is not dict or type(row['intent_bytes_before']) is not bytes
                or type(row['intent_native_before']) is not tuple or len(row['intent_native_before'])!=2
                or type(context) is not tuple or len(context)!=2 or type(saved) is not tuple or len(saved)!=2
                or type(objects) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in objects)
                or row['callback_attempted'] is not True or row['returned'] is not True
                or row['context_checked'] is not True or row['completed'] is not True or row['error'] is not None):
                raise ProducerError('auxiliary init lease outcome unknown')
            for index,snapshot in enumerate(context):
                pairs=saved[index]
                if (type(snapshot) is not tuple or len(snapshot)!=8 or type(snapshot[0]) is not str
                    or snapshot[0]!=('stdout' if index==0 else 'stderr') or snapshot[1] is not constructor[3+index]
                    or snapshot[2] is not snapshot[1] or type(snapshot[6]) is not bytes or type(snapshot[7]) is not bool
                    or type(pairs) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in pairs)):
                    raise ProducerError('auxiliary init lease saved context changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current init lease changed')

    def _check_init_lease(self):
        self._constructor_guard()
        binding=self._init_lease_binding;state,journal,constructor,secondary=binding
        row=dict(object=self,constructor=constructor,callback=None,public_callback_before=None,intent_before=None,intent_bytes_before=None,intent_native_before=None,
            object_context=None,streams_before=None,stream_items_before=None,callback_attempted=False,returned=None,
            raw_return=None,context_checked=False,completed=False,error=None)
        journal.append(row);state['current']=row
        try:
            row['callback']=callback=constructor[5];row['public_callback_before']=self.lease_check
            row['intent_before']=intent=self.intent
            def native_image(value):
                kind=type(value)
                if kind is dict:
                    if any(type(key) is not str for key in value):raise ProducerError('non-native auxiliary init intent key')
                    return ('dict',tuple((key,native_image(item)) for key,item in value.items()))
                if kind is list:return ('list',tuple(native_image(item) for item in value))
                if kind is str:return ('str',value)
                if kind is int:return ('int',value)
                if kind is bool:return ('bool',value)
                if value is None:return ('none',None)
                raise ProducerError('non-native auxiliary init intent value')
            row['intent_native_before']=native=native_image(intent)
            row['intent_bytes_before']=image=(json.dumps(intent,sort_keys=True,ensure_ascii=True)+'\n').encode()
            attributes=('directory','cwd','name','argv','environment','intent','process','started','pending','finished','result','status',
                'spawn_error','_process_allocation_binding','_allocated_process','_startup_journal_binding')
            row['object_context']=objects=tuple((name,getattr(self,name)) for name in attributes)
            snapshots=[];items=[]
            for index,role in enumerate(('stdout','stderr')):
                stream=constructor[3+index]
                if type(stream) is not dict or any(type(key) is not str for key in stream):
                    raise ProducerError('original auxiliary init stream required')
                snapshots.append((role,stream,stream,stream.get('fd'),stream.get('writer'),stream.get('log'),stream.get('buffer'),stream.get('eof')))
                items.append(tuple(stream.items()))
            row['streams_before']=context=tuple(snapshots);row['stream_items_before']=stream_items=tuple(items)
            def same_items(current,pairs):
                return (type(current) is dict and all(type(key) is str for key in current)
                    and len(current)==len(pairs) and all(key in current and current[key] is value for key,value in pairs))
            def same_native(value,snapshot):
                tag,saved=snapshot
                if tag=='dict':
                    return (type(value) is dict and all(type(key) is str for key in value) and len(value)==len(saved)
                        and all(key in value and same_native(value[key],child) for key,child in saved))
                if tag=='list':
                    return type(value) is list and len(value)==len(saved) and all(same_native(item,child) for item,child in zip(value,saved))
                if tag=='str':return type(value) is str and value==saved
                if tag=='int':return type(value) is int and value==saved
                if tag=='bool':return type(value) is bool and value is saved
                return tag=='none' and value is None
            def check():
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])
                    or type(intent) is not dict or any(type(key) is not str for key in intent)):
                    raise ProducerError('auxiliary init lease metadata changed')
                if (self._init_lease_binding is not binding or self._init_lease_state is not state or self._init_lease_journal is not journal
                    or state['current'] is not row or not journal or journal[-1] is not row
                    or state['first_error'] is not None or state['quarantined'] is not False
                    or self._init_lease_primary_error is not None or self._init_lease_quarantined is not False
                    or self._init_lease_secondary_errors is not secondary or self._constructor_quarantine_binding is not constructor
                    or self.streams is not constructor[2] or set(constructor[2])!={'stdout','stderr'}
                    or self.lease_check is not callback or any(getattr(self,name) is not value for name,value in objects)
                    or not same_native(intent,native)):
                    raise ProducerError('original auxiliary init lease binding or intent changed')
                for index,snapshot in enumerate(context):
                    role,stream,original,fd,writer,log,buffer,eof=snapshot
                    if (constructor[3+index] is not stream or constructor[2].get(role) is not stream
                        or type(buffer) is not bytes or type(eof) is not bool or not same_items(stream,stream_items[index])):
                        raise ProducerError('original auxiliary init lease stream changed')
            check();row['callback_attempted']=True;value=callback()
            # Preserve the original ignored return; None and False are both DATA.
            row['raw_return']=value;row['returned']=True
            check();row['context_checked']=True;row['completed']=True
            return value
        except BaseException as error:
            # Retain the received first BEFORE metadata updates; later faults cannot mask it.
            self._init_lease_primary_error=error;self._init_lease_quarantined=True
            try:
                row['error']=error
                if type(state) is dict and all(type(key) is str for key in state):
                    state['first_error']=error;state['quarantined']=True
            except BaseException as later:list.append(secondary,later)
            raise error

    def _intent_call_error(self):
        def actual(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return any(kind is BaseException for kind in chain)
        primary=getattr(self,'_intent_call_primary_error',None)
        if primary is not None and actual(primary):return primary
        binding=getattr(self,'_intent_call_binding',None)
        if type(binding) is tuple and len(binding)==6:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=state.get('first_error')
                if first is not None and actual(first):return first
        return None

    def _intent_call_guard(self,*,whole=False):
        first=self._intent_call_error()
        if first is not None:raise first
        if type(whole) is not bool:raise ProducerError('unknown auxiliary intent guard scope')
        binding=self._intent_call_binding
        if type(binding) is not tuple or len(binding)!=6:raise ProducerError('auxiliary intent call binding changed')
        state,journal,constructor,initial,functions,secondary=binding
        if (type(state) is not dict or any(type(key) is not str for key in state)
            or set(state)!={'current','first_error','quarantined','calls_completed'}
            or state is not self._intent_call_state or type(journal) is not list or journal is not self._intent_call_journal
            or constructor is not self._constructor_quarantine_binding or initial is not self._init_lease_binding
            or type(functions) is not tuple or len(functions)!=2
            or secondary is not self._intent_call_secondary_errors or type(secondary) is not list
            or state['first_error'] is not None or state['quarantined'] is not False
            or self._intent_call_primary_error is not None or self._intent_call_quarantined is not False
            or state['calls_completed'] is not bool(journal) or len(journal) not in (0,2)):
            raise ProducerError('auxiliary intent calls unknown or quarantined')
        required={'object','stage','function','arguments','path','intent','image','expected_digest','context',
            'attempted','returned','raw_return','value_valid','context_checked','completed','error'}
        indexed=enumerate(journal) if whole else ([(len(journal)-1,journal[-1])] if journal else [])
        for index,row in indexed:
            if type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required:
                raise ProducerError('auxiliary intent call record changed')
            stage='write' if index==0 else 'hash';arguments=row['arguments']
            if (row['object'] is not self or type(row['stage']) is not str or row['stage']!=stage
                or row['function'] is not functions[index] or type(arguments) is not tuple
                or len(arguments)!=(2 if index==0 else 1) or arguments[0] is not row['path']
                or index==0 and arguments[1] is not row['intent']
                or type(row['image']) is not bytes or type(row['expected_digest']) is not str
                or type(row['context']) is not tuple or len(row['context'])!=2
                or row['attempted'] is not True or row['returned'] is not True or row['value_valid'] is not True
                or row['context_checked'] is not True or row['completed'] is not True or row['error'] is not None
                or index==0 and row['raw_return'] is not None
                or index==1 and (type(row['raw_return']) is not str or row['raw_return']!=row['expected_digest'])):
                raise ProducerError('auxiliary intent call outcome unknown')
            objects,streams=row['context']
            if (type(objects) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in objects)
                or type(streams) is not tuple or len(streams)!=2):
                raise ProducerError('auxiliary saved intent context changed')
            for streamindex,snapshot in enumerate(streams):
                if (type(snapshot) is not tuple or len(snapshot)!=3 or type(snapshot[0]) is not str
                    or snapshot[0]!=('stdout' if streamindex==0 else 'stderr') or snapshot[1] is not constructor[3+streamindex]
                    or type(snapshot[2]) is not tuple or any(type(pair) is not tuple or len(pair)!=2 or type(pair[0]) is not str for pair in snapshot[2])):
                    raise ProducerError('auxiliary saved intent stream changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary current intent call changed')

    def _publish_intent(self,path):
        self._constructor_guard()
        binding=self._intent_call_binding;state,journal,constructor,initial,functions,secondary=binding
        if journal or state['calls_completed'] is not False:raise ProducerError('auxiliary intent attempt is permanently terminal')
        row=None
        try:
            intent=self.intent;initial_row=initial[1][-1]
            image=initial_row['intent_bytes_before'];native=initial_row['intent_native_before']
            if type(image) is not bytes or type(native) is not tuple:raise ProducerError('original auxiliary intent snapshot required')
            expected=hashlib.sha256(image).hexdigest()
            attributes=('directory','cwd','name','argv','environment','intent','streams','process','started','pending','finished','result','status',
                'spawn_error','_process_allocation_binding','_allocated_process')
            objects=tuple((name,getattr(self,name)) for name in attributes);streams=[]
            for index,role in enumerate(('stdout','stderr')):
                stream=constructor[3+index]
                if type(stream) is not dict or any(type(key) is not str for key in stream):
                    raise ProducerError('original auxiliary intent stream required')
                streams.append((role,stream,tuple(stream.items())))
            context=(objects,tuple(streams))
            def same_native(value,snapshot):
                tag,saved=snapshot
                if tag=='dict':
                    return (type(value) is dict and all(type(key) is str for key in value) and len(value)==len(saved)
                        and all(key in value and same_native(value[key],child) for key,child in saved))
                if tag=='list':
                    return type(value) is list and len(value)==len(saved) and all(same_native(item,child) for item,child in zip(value,saved))
                if tag=='str':return type(value) is str and value==saved
                if tag=='int':return type(value) is int and value==saved
                if tag=='bool':return type(value) is bool and value is saved
                return tag=='none' and value is None
            def check():
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or type(constructor[2]) is not dict or any(type(key) is not str for key in constructor[2])):
                    raise ProducerError('auxiliary intent call metadata changed')
                if (self._intent_call_binding is not binding or self._intent_call_state is not state
                    or self._intent_call_journal is not journal or state['current'] is not row or not journal or journal[-1] is not row
                    or state['first_error'] is not None or state['quarantined'] is not False or state['calls_completed'] is not False
                    or self._intent_call_primary_error is not None or self._intent_call_quarantined is not False
                    or self._intent_call_secondary_errors is not secondary
                    or self._constructor_quarantine_binding is not constructor or self._init_lease_binding is not initial
                    or self.streams is not constructor[2] or set(constructor[2])!={'stdout','stderr'}
                    or any(getattr(self,name) is not value for name,value in objects)
                    or 'intent_sha256' in self.__dict__ or not same_native(intent,native)):
                    raise ProducerError('original auxiliary intent call binding changed')
                for index,(role,stream,pairs) in enumerate(streams):
                    if (constructor[3+index] is not stream or constructor[2].get(role) is not stream
                        or type(stream) is not dict or any(type(key) is not str for key in stream) or len(stream)!=len(pairs)
                        or any(key not in stream or stream[key] is not value for key,value in pairs)):
                        raise ProducerError('original auxiliary intent call stream changed')
            value=None
            for index,stage in enumerate(('write','hash')):
                arguments=(path,intent) if index==0 else (path,)
                row=dict(object=self,stage=stage,function=functions[index],arguments=arguments,path=path,intent=intent,
                    image=image,expected_digest=expected,context=context,attempted=False,returned=None,raw_return=None,
                    value_valid=False,context_checked=False,completed=False,error=None)
                journal.append(row);state['current']=row;check()
                row['attempted']=True;value=functions[index](*arguments)
                row['raw_return']=value;row['returned']=True
                valid=value is None if index==0 else type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None and value==expected
                row['value_valid']=valid
                if valid is not True:raise ProducerError('original auxiliary intent call result differs')
                check();row['context_checked']=True;row['completed']=True
            # This records two known calls, not public digest publication or admission.
            state['calls_completed']=True
            return value
        except BaseException as error:
            self._intent_call_primary_error=error;self._intent_call_quarantined=True
            try:
                if type(row) is dict and all(type(key) is str for key in row):row['error']=error
                if type(state) is dict and all(type(key) is str for key in state):
                    state['first_error']=error;state['quarantined']=True
            except BaseException as later:list.append(secondary,later)
            raise error

    def _wait_natural_status(self,timeout):
        self._constructor_guard()
        binding=self._direct_wait_binding;state,journal,constructor,allocation=binding
        row=dict(process=None,constructor_record=None,constructor_returned=None,public_process_before=None,timeout=timeout,
            witness_process_before=None,witness_observed_before=None,witness_status_before=None,process_bound=False,
            method=None,lookup_attempted=False,lookup_returned=None,wait_attempted=False,returned=None,raw_return=None,
            value_valid=None,timeout_received=False,timeout_error=None,witness_committed=False,completed=False,error=None,secondary_error=None)
        journal.append(row);state['current']=row;timeout_error=None
        try:
            record=constructor[0];row['constructor_record']=record
            row['process']=process=record.get('allocated_process');row['public_process_before']=self.process
            row['witness_process_before']=previous_process=self._natural_wait_process
            row['witness_observed_before']=previous_observed=self._natural_wait_observed
            row['witness_status_before']=previous_status=self._natural_wait_status
            if (record.get('attempted') is not True or record.get('returned') is not True or process is None
                or type(allocation) is not tuple or len(allocation)!=2
                or type(allocation[0]) is not dict or any(type(key) is not str for key in allocation[0])
                or allocation[0].get('allocated_process') is not process
                or allocation[0].get('initializer_returned') is not True
                or allocation[0].get('initializer_result_valid') is not True
                or allocation[0].get('initializer_result') is not None):
                raise ProducerError('original normal auxiliary constructor required before direct wait')
            row['constructor_returned']=True
            def check():
                if (type(record) is not dict or any(type(key) is not str for key in record)
                    or type(allocation[0]) is not dict or any(type(key) is not str for key in allocation[0])):
                    raise ProducerError('auxiliary direct wait constructor metadata changed')
                if (record.get('attempted') is not True or record.get('returned') is not True
                    or record.get('allocated_process') is not process
                    or allocation[0].get('allocated_process') is not process
                    or allocation[0].get('initializer_returned') is not True
                    or allocation[0].get('initializer_result_valid') is not True
                    or allocation[0].get('initializer_result') is not None):
                    raise ProducerError('auxiliary direct wait constructor facts changed')
                if (type(state) is not dict or any(type(key) is not str for key in state)
                    or self._direct_wait_binding is not binding or self._direct_wait_state is not state
                    or self._direct_wait_journal is not journal or state['current'] is not row
                    or not journal or journal[-1] is not row
                    or self._constructor_quarantine_binding is not constructor or self._process_allocation_binding is not allocation
                    or self.process is not process
                    or self._natural_wait_process is not (process if row['process_bound'] else previous_process)
                    or self._natural_wait_observed is not previous_observed or self._natural_wait_status is not previous_status):
                    raise ProducerError('original auxiliary direct wait binding changed')
            if not (type(timeout) is int or type(timeout) is float) or not 0<=timeout<=60:
                raise ProducerError('bounded direct auxiliary wait required')
            if type(previous_observed) is not bool:raise ProducerError('unknown auxiliary wait witness')
            if previous_process is None:
                if previous_observed:raise ProducerError('unbound auxiliary wait witness')
            elif previous_process is not process:raise ProducerError('auxiliary wait process changed; exact handle retained')
            if previous_observed:
                if type(previous_status) is not int:raise ProducerError('unknown retained auxiliary wait status')
            elif previous_status is not None:raise ProducerError('unobserved auxiliary wait status changed')
            check();self._natural_wait_process=process;row['process_bound']=True
            row['lookup_attempted']=True;method=process.wait;row['method']=method;row['lookup_returned']=True;check()
            row['wait_attempted']=True
            try:status=method(timeout=timeout)
            except subprocess.TimeoutExpired as received:
                timeout_error=received;row['timeout_error']=received;row['timeout_received']=True
                check();row['completed']=True
            else:
                row['raw_return']=status;row['returned']=True
                if type(status) is not int:raise ProducerError('unknown direct auxiliary wait status')
                if previous_observed and status!=previous_status:raise ProducerError('direct auxiliary wait status changed')
                row['value_valid']=True;check()
                self._natural_wait_status=status;self._natural_wait_observed=True;row['witness_committed']=True
                row['completed']=True
        except BaseException as error:
            first=timeout_error if timeout_error is not None else error
            row['error']=first
            if first is not error:row['secondary_error']=error
            self._defer(first)
        if timeout_error is not None:raise timeout_error
        return status



    def wait(self,timeout):
        self._constructor_guard()
        if self.finished:raise ProducerError('auxiliary completion is permanently terminal')
        if not self.started:raise ProducerError('auxiliary command has not started')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded auxiliary wait required')
        try:self._check_wait_lease()
        except BaseException as error:self._defer(error)
        deadline=time.monotonic()+timeout
        while True:
            try:self._observe_status()
            except BaseException as error:self._defer(error);return None
            if any(s['quarantined'] for s in self.streams.values()):return None
            for stream in self.streams.values():
                if stream['eof']:continue
                if stream['buffer']:
                    self._write_buffer(stream)
                    continue
                try:part=self._read_stream(stream)
                except (BlockingIOError,InterruptedError):self._constructor_guard();continue
                except BaseException as error:self._defer(error);return None
                if not part:
                    stream['eof']=True;self._close_slot(stream,'fd')
            if all(s['eof'] for s in self.streams.values()) and self.status is not None:
                self.status=self._wait_natural_status(timeout=0)
                return self._complete()
            remaining=deadline-time.monotonic()
            if remaining<=0:return None
            # Buffered bytes must be written before waiting for further readability.
            if any(s['buffer'] for s in self.streams.values()):continue
            readers=[s['fd'] for s in self.streams.values() if s['fd'] is not None]
            try:
                if readers:self._select_readers(readers,min(remaining,.05))
                else:
                    try:self.status=self._wait_natural_status(timeout=remaining)
                    except subprocess.TimeoutExpired:return None
            except BaseException as error:self._defer(error);return None

    def _startup_guard(self):
        # Original raised instances precede all metadata validation or I/O.
        def actual_error(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return any(kind is BaseException for kind in chain)
        primary=self._startup_primary_error
        if primary is not None and actual_error(primary):raise primary
        binding=self._startup_journal_binding
        if type(binding) is not tuple or len(binding)!=4:
            raise ProducerError('auxiliary startup journal binding changed')
        state,journal,constructor,secondary=binding
        if type(state) is not dict or any(type(key) is not str for key in state):
            raise ProducerError('auxiliary startup state changed')
        first=state.get('first_error')
        if first is not None:
            if actual_error(first):raise first
            raise ProducerError('auxiliary startup first error changed')
        if (primary is not None or state is not self._startup_state or journal is not self._startup_journal
            or type(journal) is not list or constructor is not self._constructor_quarantine_binding
            or secondary is not self._startup_secondary_errors or type(secondary) is not list
            or set(state)!={'first_error','quarantined','current'}
            or self._startup_quarantined is not False or state['quarantined'] is not False):
            raise ProducerError('auxiliary startup outcome quarantined or binding changed')
        if (type(constructor) is not tuple or len(constructor)!=7
            or constructor[0] is not self._constructor_quarantine
            or constructor[1] is not self._process_allocation_binding
            or constructor[2] is not self.streams or type(self.streams) is not dict
            or any(type(key) is not str for key in self.streams)
            or self.streams.get('stdout') is not constructor[3] or self.streams.get('stderr') is not constructor[4]
            or constructor[5] is not self.lease_check or constructor[6] is not self._constructor_secondary_errors
            or type(constructor[6]) is not list):
            raise ProducerError('auxiliary startup original resources changed')
        for row in journal:
            if (type(row) is not dict or any(type(key) is not str for key in row)
                or set(row)!={'stage','attempted','returned','value','error'}
                or type(row.get('stage')) is not str or row.get('attempted') is not True):
                raise ProducerError('auxiliary startup operation record changed')
            error=row['error']
            if error is not None:
                if actual_error(error):raise error
                raise ProducerError('auxiliary startup operation error changed')
            if row['returned'] is not True:
                raise ProducerError('auxiliary startup operation return unknown')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary startup current operation changed')
        return binding

    def _quarantine_startup(self,binding,error,operation=None):
        if self._startup_primary_error is None:
            first=self._allocation_primary_error
            self._startup_primary_error=error if first is None else first
        else:list.append(binding[3],('startup',error))
        self._startup_quarantined=True
        state=binding[0]
        if type(state) is dict and all(type(key) is str for key in state):
            state['first_error']=self._startup_primary_error;state['quarantined']=True
            if type(operation) is dict and all(type(key) is str for key in operation):
                if operation.get('error') is None:operation['error']=self._startup_primary_error
        self._quarantine_constructor(binding[2],self._startup_primary_error)

    def _startup_step(self,binding,stage,action):
        current=self._startup_guard()
        if current is not binding:raise ProducerError('auxiliary startup original binding changed')
        row=dict(stage=stage,attempted=True,returned=None,value=None,error=None)
        binding[0]['current']=row;list.append(binding[1],row)
        try:
            value=action()
            # Retain the actual return BEFORE later binding checks or native I/O.
            row['value']=value;row['returned']=True
            self._startup_guard()
            return value
        except BaseException as error:
            self._quarantine_startup(binding,error,row)
            raise self._startup_primary_error

    def _creator_close_error(self):
        def native_error(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return value if any(kind is BaseException for kind in chain) else None
        first=native_error(self._creator_close_primary_error)
        if first is not None:return first
        binding=self._creator_close_binding
        if type(binding) is tuple and len(binding)==4:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=native_error(state.get('first_error'))
                if first is not None:return first
            if type(binding[1]) is list:
                for row in binding[1]:
                    if type(row) is dict and all(type(key) is str for key in row):
                        first=native_error(row.get('error'))
                        if first is not None:return first
        return None

    def _creator_close_guard(self):
        first=self._creator_close_error()
        if first is not None:raise first
        binding=self._creator_close_binding
        if type(binding) is not tuple or len(binding)!=4:
            raise ProducerError('auxiliary creator-close binding changed')
        state,journal,constructor,secondary=binding
        if (self._creator_close_primary_error is not None
            or type(state) is not dict or any(type(key) is not str for key in state)
            or set(state)!={'first_error','quarantined','current'}
            or state is not self._creator_close_state or state['first_error'] is not None
            or state['quarantined'] is not False or self._creator_close_quarantined is not False
            or type(journal) is not list or journal is not self._creator_close_journal
            or type(secondary) is not list or secondary is not self._creator_close_secondary_errors
            or constructor is not self._constructor_quarantine_binding
            or type(constructor) is not tuple or len(constructor)!=7):
            raise ProducerError('auxiliary creator-close state changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary creator-close current attempt changed')
        required={'role','slot','fd','stream','log','process','attempted','returned','raw_return','result_valid','completed','error'}
        for row in journal:
            if (type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required
                or type(row['role']) is not str or row['role'] not in ('stdout','stderr')
                or type(row['slot']) is not str or row['slot'] not in ('fd','writer')
                or row['stream'] is not constructor[3 if row['role']=='stdout' else 4]
                or row['error'] is not None or row['completed'] is not True):
                raise ProducerError('auxiliary creator-close attempt changed or incomplete')
            if row['fd'] is None:
                okay=(row['attempted'] is False and row['returned'] is None
                    and row['raw_return'] is None and row['result_valid'] is None)
            else:
                okay=(type(row['fd']) is int and row['fd']>=0 and row['attempted'] is True
                    and row['returned'] is True and row['raw_return'] is None and row['result_valid'] is True)
            if not okay:raise ProducerError('auxiliary creator-close return unknown')
            if row['fd'] is not None:
                resources=constructor[0].get('streams')
                index=0 if row['role']=='stdout' else 1
                if (type(resources) is not tuple or len(resources)!=2 or type(resources[index]) is not tuple
                    or len(resources[index])!=5 or row['log'] is not resources[index][2]
                    or type(resources[index][3 if row['slot']=='fd' else 4]) is not int
                    or row['fd']!=resources[index][3 if row['slot']=='fd' else 4]
                    or row['process'] is not constructor[0].get('allocated_process')):
                    raise ProducerError('auxiliary creator-close original context changed')

    def _retain_creator_close_error(self,binding,row,error):
        # Exact first object before any later record/binding metadata.
        if self._creator_close_primary_error is None:self._creator_close_primary_error=error
        else:list.append(binding[3],error)
        self._creator_close_quarantined=True
        state=binding[0]
        if type(state) is dict and all(type(key) is str for key in state):
            state['first_error']=self._creator_close_primary_error;state['quarantined']=True
        if type(row) is dict and all(type(key) is str for key in row):
            if row.get('error') is None:row['error']=self._creator_close_primary_error

    def _finalization_error(self):
        def native(value):
            chain=type.__dict__['__mro__'].__get__(type(value),type)
            return value if any(kind is BaseException for kind in chain) else None
        first=native(self._finalization_primary_error)
        if first is not None:return first
        binding=self._finalization_binding
        if type(binding) is tuple and len(binding)==5:
            state=binding[0]
            if type(state) is dict and all(type(key) is str for key in state):
                first=native(state.get('first_error'))
                if first is not None:return first
            if type(binding[1]) is list:
                for row in binding[1]:
                    if type(row) is dict and all(type(key) is str for key in row):
                        first=native(row.get('error'))
                        if first is not None:return first
        return None

    def _finalization_guard(self):
        first=self._finalization_error()
        if first is not None:raise first
        binding=self._finalization_binding
        if type(binding) is not tuple or len(binding)!=5:
            raise ProducerError('auxiliary finalization binding changed')
        state,journal,constructor,creator,secondary=binding
        if (self._finalization_primary_error is not None or type(state) is not dict
            or any(type(key) is not str for key in state)
            or set(state)!={'attempted','completed','first_error','quarantined','current','candidate_result'}
            or state is not self._finalization_state or type(state['attempted']) is not bool
            or type(state['completed']) is not bool or state['first_error'] is not None
            or state['quarantined'] is not False or self._finalization_quarantined is not False
            or type(journal) is not list or journal is not self._finalization_journal
            or constructor is not self._constructor_quarantine_binding or creator is not self._creator_close_binding
            or type(secondary) is not list or secondary is not self._finalization_secondary_errors):
            raise ProducerError('auxiliary finalization state changed')
        required={'stage','role','log','fd','process','candidate_result','attempted','returned','raw_return','result_valid','completed','error'}
        for row in journal:
            if (type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required
                or type(row['stage']) is not str or row['stage'] not in ('flush','fileno','fsync','close','snapshot','result')
                or row['attempted'] is not True or row['returned'] is not True
                or row['result_valid'] is not True or row['completed'] is not True or row['error'] is not None
                or row['process'] is not constructor[0].get('allocated_process')):
                raise ProducerError('auxiliary finalization operation unknown')
            if row['stage']=='result':
                if row['role'] is not None or row['candidate_result'] is not state['candidate_result']:
                    raise ProducerError('auxiliary finalization result binding changed')
            elif type(row['role']) is not str or row['role'] not in ('stdout','stderr'):
                raise ProducerError('auxiliary finalization role changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary finalization current operation changed')

    def _retain_finalization_error(self,binding,row,error):
        # Exact first object before validation/reporting; never close or replay.
        if self._finalization_primary_error is None:self._finalization_primary_error=error
        else:list.append(binding[4],error)
        self._finalization_quarantined=True
        state=binding[0]
        if type(state) is dict and all(type(key) is str for key in state):
            state['first_error']=self._finalization_primary_error;state['quarantined']=True
        if type(row) is dict and all(type(key) is str for key in row):
            if row.get('error') is None:row['error']=self._finalization_primary_error

    def _finalization_step(self,binding,stage,role,log,fd,action):
        self._constructor_guard()
        if self._finalization_binding is not binding:raise ProducerError('original auxiliary finalization required')
        row=dict(stage=stage,role=role,log=log,fd=fd,process=self.process,candidate_result=binding[0]['candidate_result'],
            attempted=True,returned=None,raw_return=None,result_valid=None,completed=False,error=None)
        binding[0]['current']=row;list.append(binding[1],row)
        try:
            value=action();row['raw_return']=value;row['returned']=True
            if stage=='fileno':valid=type(value) is int and value>=0
            elif stage=='snapshot':
                valid=(type(value) is dict and all(type(key) is str for key in value)
                    and set(value)=={'size','sha256'} and type(value['size']) is int and value['size']>=0
                    and type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None)
            else:valid=value is None
            row['result_valid']=valid
            if not valid:raise TypeError('auxiliary finalization native return invalid')
            # Preserve actual returns before all post-call binding metadata.
            self._startup_guard();self._creator_close_guard()
            if (self._finalization_binding is not binding or binding[0] is not self._finalization_state
                or binding[1] is not self._finalization_journal or binding[4] is not self._finalization_secondary_errors
                or self.process is not row['process']):
                raise ProducerError('auxiliary finalization binding changed after operation')
            if role is not None:
                stream=binding[2][3 if role=='stdout' else 4]
                expected=None if stage=='snapshot' else log
                if self.streams.get(role) is not stream or stream.get('log') is not expected:
                    raise ProducerError('auxiliary finalization writer binding changed')
            row['completed']=True
            return value
        except BaseException as error:
            self._retain_finalization_error(binding,row,error)
            raise self._finalization_primary_error

    def _constructor_guard(self):
        initialization_guard=getattr(self,'_initialization_first_guard',None)
        if initialization_guard is not None:initialization_guard()
        init_error=self._init_lease_error()
        if init_error is not None:raise init_error
        intent_error=self._intent_call_error()
        if intent_error is not None:raise intent_error
        # Raise an actual retained exception instance, never instantiate field data.
        primary=self._constructor_primary_error
        if primary is not None:
            chain=type.__dict__['__mro__'].__get__(type(primary),type)
            if any(kind is BaseException for kind in chain):raise primary
        close_error=self._creator_close_error()
        if close_error is not None:raise close_error
        final_error=self._finalization_error()
        if final_error is not None:raise final_error
        deferred_error=self._deferred_error()
        if deferred_error is not None:
            # Recover any earlier constructor/startup first from the original binding.
            previous_binding=getattr(self,'_constructor_quarantine_binding',None)
            if type(previous_binding) is tuple and len(previous_binding)==7:
                previous=previous_binding[0]
                if type(previous) is dict and all(type(key) is str for key in previous):
                    previous_error=previous.get('first_error')
                    chain=type.__dict__['__mro__'].__get__(type(previous_error),type)
                    if any(kind is BaseException for kind in chain):raise previous_error
            raise deferred_error
        binding=self._constructor_quarantine_binding
        if type(binding) is not tuple or len(binding)!=7:
            raise ProducerError('auxiliary constructor quarantine binding changed')
        record=binding[0]
        if (type(record) is not dict or any(type(key) is not str for key in record)
            or record is not self._constructor_quarantine):
            raise ProducerError('auxiliary constructor quarantine record changed')
        first=record.get('first_error')
        if first is not None:
            chain=type.__dict__['__mro__'].__get__(type(first),type)
            if any(kind is BaseException for kind in chain):raise first
            raise ProducerError('auxiliary constructor first error changed')
        if (primary is not None or self._constructor_quarantined is not False
            or record.get('quarantined') is not False):
            raise ProducerError('auxiliary constructor outcome quarantined')
        self._startup_guard()
        self._creator_close_guard()
        self._finalization_guard()
        self._deferred_guard()
        self._buffer_write_guard()
        self._status_poll_guard()
        self._direct_wait_guard()
        self._stream_read_guard()
        self._select_guard()
        self._wait_lease_guard()
        self._start_lease_guard()
        self._init_lease_guard()
        self._intent_call_guard()

    def _constructor_record(self):
        self._constructor_guard()
        binding=self._constructor_quarantine_binding;record=binding[0]
        required={'attempted','returned','quarantined','first_error','secondary_errors',
            'streams','allocated_process','allocation_binding'}
        if (set(record)!=required or type(record['attempted']) is not bool
            or record['returned'] is not None and type(record['returned']) is not bool
            or record['first_error'] is not None
            or record['secondary_errors'] is not binding[6] or type(binding[6]) is not list
            or binding[6] is not self._constructor_secondary_errors
            or record['allocation_binding'] is not binding[1]
            or binding[1] is not self._process_allocation_binding
            or binding[2] is not self.streams or type(binding[2]) is not dict
            or any(type(key) is not str for key in binding[2])
            or binding[2].get('stdout') is not binding[3] or binding[2].get('stderr') is not binding[4]
            or binding[5] is not self.lease_check or type(record['streams']) is not tuple):
            raise ProducerError('auxiliary constructor quarantine record changed')
        return record

    def _arm_constructor(self):
        record=self._constructor_record();binding=self._constructor_quarantine_binding
        if record['attempted']:raise ProducerError('auxiliary constructor attempt is permanently terminal')
        rows=[]
        for role,stream in [('stdout',binding[3]),('stderr',binding[4])]:
            if (type(stream) is not dict or any(type(key) is not str for key in stream)
                or type(stream.get('fd')) is not int or type(stream.get('writer')) is not int
                or stream.get('log') is None):
                raise ProducerError('original auxiliary constructor resources required')
            rows.append((role,stream,stream['log'],stream['fd'],stream['writer']))
        # Original known handles are retained before constructor/initializer I/O.
        record['streams']=tuple(rows);record['attempted']=True
        return binding

    def _quarantine_constructor(self,binding,error):
        # No repr/str/note/equality, callback, partial-object method or I/O here.
        if self._constructor_primary_error is None:
            first=self._allocation_primary_error
            self._constructor_primary_error=error if first is None else first
        else:list.append(binding[6],('constructor',error))
        self._constructor_quarantined=True
        record=binding[0]
        if type(record) is dict and all(type(key) is str for key in record):
            record['first_error']=self._constructor_primary_error;record['quarantined']=True
        # Preserve later binding damage as a secondary occurrence, never mask first.
        current=self._constructor_quarantine_binding
        if (current is not binding or record is not self._constructor_quarantine
            or self._process_allocation_binding is not binding[1] or self.streams is not binding[2]
            or self.lease_check is not binding[5] or self._constructor_secondary_errors is not binding[6]):
            list.append(binding[6],('constructor_binding',ProducerError('auxiliary quarantine bindings changed')))


# Factory-call progress is DATA, not constructor-origin/owner/EX authority.
_AUXILIARY_FACTORY_ATTEMPTS = []
_AUXILIARY_FACTORY_LAST = {}


def _auxiliary_factory_guard(owner):
    last=_AUXILIARY_FACTORY_LAST.get(id(owner))
    if last is None:return
    if type(last) is not tuple or len(last)!=2 or last[0] is not owner:
        raise ProducerError('auxiliary factory owner binding changed')
    record=last[1]
    record.guard() # Exact received first precedes pending/metadata checks.
    if record.completed is not True:
        raise ProducerError('auxiliary factory observation is pending or unknown')


class _AuxiliaryFactoryAttempt(_JSONWriteAttempt):
    def __init__(self,owner,name,argv,stdout_max):
        super().__init__(None,None)
        self.owner=owner
        self.name=name
        self.argv=argv
        self.stdout_max=stdout_max
        self.constructor=None
        self.constructor_attempted=False
        self.constructor_returned=None
        self.constructor_raw_return=None
        self.context_refs=None
        self.input_values=None
        self.original_members=None
        self.operation=None
        self.append_returned=None
        self.append_raw_return=None
        self.stage='before_constructor'

    def _context(self,owner):
        values=[]
        for name in ('directory','repo','environment','lease_check','auxiliary_operations'):
            values.append(self._step('owner_'+name,lambda:getattr,(owner,name)))
        return tuple(values)

    def _values(self,argv,environment):
        # Exact native shape/value comparisons; never call foreign equality.
        if type(argv) is not list or any(type(value) is not str for value in argv):
            raise ProducerError('unknown auxiliary factory argv shape')
        if type(environment) is not dict or any(type(k) is not str or type(v) is not str for k,v in environment.items()):
            raise ProducerError('unknown auxiliary factory environment shape')
        return (tuple(argv),tuple(environment.items()))

    def _check_context(self,owner,context,values,argv,expected_members,constructor):
        actual=self._context(owner)
        if any(a is not b for a,b in zip(actual,context)):
            raise ProducerError('auxiliary factory owner context changed')
        if AuxiliaryCommand is not constructor:
            raise ProducerError('auxiliary factory constructor binding changed')
        if self._values(argv,context[2])!=values:
            raise ProducerError('auxiliary factory input values changed')
        operations=context[4]
        if type(operations) is not list or len(operations)!=len(expected_members):
            raise ProducerError('auxiliary factory owner ledger changed')
        if any(actual is not expected for actual,expected in zip(operations,expected_members)):
            raise ProducerError('auxiliary factory owner members changed')

    def run(self):
        call=self._step
        fail=self._fail
        owner=self.owner
        name=self.name
        argv=self.argv
        stdout_max=self.stdout_max
        try:
            constructor=call('constructor_lookup',lambda:lambda:AuxiliaryCommand)
            self.constructor=constructor
            context=self._context(owner)
            self.context_refs=context
            if type(context[4]) is not list:
                raise ProducerError('unknown auxiliary factory owner ledger')
            members=tuple(context[4]);self.original_members=members
            values=self._values(argv,context[2]);self.input_values=values
            arguments=dict(directory=context[0],name=name,argv=argv,cwd=context[1],
                environment=context[2],lease_check=context[3],stdout_max=stdout_max)
            self.constructor_attempted=True
            raw=call('constructor',lambda:constructor,(),arguments)
            self.constructor_raw_return=raw # Before type/context checks or append.
            self.constructor_returned=True
            if type(raw) is not constructor:
                raise ProducerError('unknown auxiliary factory constructor return')
            operation=raw
            self.operation=operation # Known actual return, never a hidden init object.
            self._check_context(owner,context,values,argv,members,constructor)
            appended=call('owner_append',lambda:context[4].append,(operation,))
            self.append_raw_return=appended
            self.append_returned=True
            if appended is not None:raise ProducerError('unknown auxiliary owner append return')
            self._check_context(owner,context,values,argv,members+(operation,),constructor)
            self.stage='suffix'
            binding=dict(operation=operation,start=None,wait=None,completed=False)
            self.suffix_context=binding # Before public method lookup/start.
            start=call('operation_start_lookup',lambda:lambda:operation.start)
            wait=call('operation_wait_lookup',lambda:lambda:operation.wait)
            binding['start']=start;binding['wait']=wait

            def method_same(actual,expected):
                return (type(actual) is MethodType and type(expected) is MethodType
                    and actual.__self__ is operation and expected.__self__ is operation
                    and actual.__func__ is expected.__func__)

            def check_suffix():
                self.guard()
                if self.suffix_context is not binding or binding['operation'] is not operation:
                    raise ProducerError('auxiliary factory suffix binding changed')
                self._check_context(owner,context,values,argv,members+(operation,),constructor)
                actual_start=call('suffix_start_binding',lambda:lambda:operation.start)
                actual_wait=call('suffix_wait_binding',lambda:lambda:operation.wait)
                if not method_same(actual_start,start) or not method_same(actual_wait,wait):
                    raise ProducerError('auxiliary factory public method binding changed')

            check_suffix()
            call('operation_start',lambda:start) # Original ignored return, including False.
            check_suffix()
            result=call('operation_result',lambda:getattr,(operation,'result'))
            if result is not None and type(result) is not dict:
                raise ProducerError('unknown auxiliary operation result')
            check_suffix()
            while result is None:
                raw=call('operation_wait',lambda:wait,(60,))
                # Reject known invalid returns BEFORE another public lookup.
                if raw is not None and type(raw) is not dict:
                    raise ProducerError('unknown auxiliary wait return')
                check_suffix()
                current=call('operation_result',lambda:getattr,(operation,'result'))
                if raw is not current:
                    raise ProducerError('auxiliary wait returned a different result')
                check_suffix()
                result=raw
            status=call('result_status',lambda:result.__getitem__,('status',))
            if type(status) is not str or status not in ('success','failed'):
                raise ProducerError('unknown auxiliary result status')
            check_suffix()
            if status!='success':
                primary=call('failure_primary',lambda:result.__getitem__,('primary_error',))
                if primary is not None and type(primary) is not str:
                    raise ProducerError('unknown auxiliary failure detail')
                check_suffix()
                detail=call('failure_detail',lambda:str,(primary,))
                if type(detail) is not str:
                    raise ProducerError('unknown auxiliary failure text')
                check_suffix()
                raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+detail)
            binding['completed']=True # Caller result only, never ownership/physical EX.
            self.completed=True # Helper return only, never EX/ownership completion.
            return result
        except BaseException as error:
            fail(error) # Call errors own their rows; post-checks have no invented native attribution.


def _observe_auxiliary(owner,name,argv,stdout_max=1024**3):
    _auxiliary_factory_guard(owner)
    record=_AuxiliaryFactoryAttempt(owner,name,argv,stdout_max)
    _AUXILIARY_FACTORY_ATTEMPTS.append(record) # Before owner field lookup/class call.
    _AUXILIARY_FACTORY_LAST[id(owner)]=(owner,record) # Strong owner ref; grouping DATA only.
    return record.run()


_COMMAND_POPEN_TYPE=subprocess.Popen
_COMMAND_POPEN_NEW=_COMMAND_POPEN_TYPE.__new__
_COMMAND_POPEN_INIT=_COMMAND_POPEN_TYPE.__init__

_FAILURE_PRESERVATION_GROUPS={}
_FAILURE_PRESERVATION_RECORDS=[]


def _failure_preservation_group(owner,error):
    key=id(owner)
    previous=_FAILURE_PRESERVATION_GROUPS.get(key)
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        previous[1]()
        return previous
    primary=error
    quarantined=[False]
    secondary=[]

    def guard():
        if quarantined[0]:raise primary

    def refuse(received,row=None):
        quarantined[0]=True # Private terminal first BEFORE secondary metadata.
        try:
            if received is not primary:secondary.append(received)
            if row is not None:row['error']=received
        finally:
            raise primary

    group=(owner,guard,refuse,primary,secondary)
    _FAILURE_PRESERVATION_GROUPS[key]=group # Strong owner/first, process lifetime.
    return group


def _failure_preservation_guard(owner):
    group=_FAILURE_PRESERVATION_GROUPS.get(id(owner))
    if group is not None:
        if group[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        group[1]()


_DEFERRED_FAILURE_RECORDS=[]


def _deferred_failure_guard(owner):
    _failure_preservation_guard(owner)


_FINISH_PUBLICATIONS={}
_FINISH_PUBLICATION_RECORDS=[]


def _finish_publication_guard(owner):
    previous=_FINISH_PUBLICATIONS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('finish publication owner mismatch')
        previous[1]()


_END_COMMAND_GROUPS={}
_END_COMMAND_RECORDS=[]


def _end_command_group(owner):
    previous=_END_COMMAND_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('end-command owner mismatch')
        previous[1]()
        return previous
    primary=[None]
    def guard():
        if primary[0] is not None:raise primary[0]
    def refuse(error,record,row=None):
        if primary[0] is None:primary[0]=error
        try:
            owner.finished=True
            group=_failure_preservation_group(owner,primary[0])
            primary[0]=group[3]
            record['primary_error']=primary[0]
            group[2](error,row)
        finally:raise primary[0]
    group=(owner,guard,refuse)
    _END_COMMAND_GROUPS[id(owner)]=group
    return group


def _end_command_guard(owner):
    previous=_END_COMMAND_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('end-command owner mismatch')
        previous[1]()


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None,tools=None,census_id=None,expected_sdk=None,config_bindings=None,_preflight_owner=None):
        if _preflight_owner is not None:
            if type(_preflight_owner) is not _RetainedPreflightOwner:raise ProducerError('foreign preflight entry hook')
            _preflight_owner._register_producer(self)
        self._receipt_primary_error_object=None;self._receipt_primary_error_stage=None
        self._receipt_secondary_error_objects=[]
        self._receipt_resources=[];self._receipt_resources_quarantined=False
        self._receipt_resource_directory=None;self._receipt_resource_lease=lease_check
        self._receipt_readers=[];self._receipt_reader_ledger=self._receipt_readers
        self._command_attempts=[];self._command_attempt=None
        self._command_history_primary_error=None;self._command_history_primary_stage=None
        self._command_history_secondary_errors=[]
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        if ((census_id is None)!=(expected_sdk is None) or (census_id is not None and
            (type(census_id) is not str or not re.fullmatch('[0-9a-f]{32}',census_id) or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)))):
            raise ProducerError('invalid pre-child census/SDK context')
        config_bindings={} if config_bindings is None else config_bindings
        if (type(config_bindings) is not dict or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}',k) or type(v) is not str or v not in inputs for k,v in config_bindings.items())
            or (config_bindings and (expected_sdk is None or not {'server','client'}<=set(config_bindings)))):
            raise ProducerError('unbound pre-child config context')
        self.census_id=census_id;self.expected_sdk=expected_sdk;self.config_bindings=MappingProxyType(dict(config_bindings))
        self.evidence_complete=False;self.receipt_attempted=False;self.intent_sha256=None;self.result_sha256=None;self.journal_sha256=None
        self.repo=Path(repo);self.directory=Path(run_dir)
        self._receipt_resource_directory=self.directory
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.tools=_tool_table(tools)
        self.task_kinds=tuple(('tool_version',name) for name in sorted(self.tools))+tuple(('recipe',None) for _ in commands)
        self.commands=tuple((self.tools[name]['entry'],*VERSION_ARGS[name]) for name in sorted(self.tools))+tuple(tuple(a) for a in commands)
        self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.environment={**os.environ,**self.env_delta};self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False;self.output_log=None;self.failure_attempted=False;self.auxiliary_operations=[]
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            _write_json(self.directory/'intent.json',{'kind':'build-preparation-intent-v1','source_commit':source_commit,'runtime_commit':runtime_commit,
                        'census_id':self.census_id,'expected_sdk':self.expected_sdk,'config_bindings':dict(self.config_bindings),
                        'expected_archive_sha256':expected_archive_sha256,'inputs':dict(self.inputs),'tools':{k:dict(v) for k,v in self.tools.items()},
                        'commands':[list(a) for a in self.commands],'task_kinds':self.task_kinds,'provenance':provenance,
                        'producer_file_sha256':_regular_hash(Path(__file__).resolve()),'environment_delta':self.env_delta})
            self.intent_sha256=_regular_hash(self.directory/'intent.json')
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self._defer_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        name=f'git-{index:03}';out=self.directory/(name+'.stdout')
        cmd=[self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv]
        result=_observe_auxiliary(self,name,cmd)
        stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
        if argv[0]=='archive':
            if _file_snapshot(out,1024**3)!=stdout:raise ProducerError('auxiliary archive output differs')
            data=None
        else:data=_read_bound_metadata(out,stdout)
        self._event('git_observation',argv=list(argv),returncode=result['returncode'],stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'],
            auxiliary_result_sha256=_regular_hash(self.directory/(name+'-result.json')))
        if argv[0]=='archive':return out
        return data

    def _source_guard(self,observe=None):
        observe=self._git if observe is None else observe
        self.lease_check()
        self._tool_guard()
        if observe('rev-parse','HEAD').decode().strip()!=self.source_commit:raise ProducerError('source HEAD differs')
        if observe('status','--porcelain','--untracked-files=normal'):raise ProducerError('source worktree is not clean')
        if observe('diff','--no-ext-diff','--no-textconv',self.runtime_commit,self.source_commit,'--','packages','native'):raise ProducerError('runtime source differs')

    def _make_archive(self):
        # git archive bytes are kept without extraction. Validate every blob and mode.
        raw_path=self._git('archive','--format=tar',self.source_commit)
        archive=self.directory/'source.tar'
        # Exclusive hard-link publication keeps original command bytes, no copy/overwrite.
        os.link(raw_path,archive,follow_symlinks=False)
        archive_hash=_regular_hash(archive)
        if archive_hash!=self.expected_archive_sha256:raise ProducerError('source archive differs from immutable expected digest')
        tree={}
        for entry in self._git('ls-tree','-rz',self.source_commit).split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,kind,object_id=meta.split(b' ')
            if kind!=b'blob':raise ProducerError('unsupported source tree entry')
            tree[os.fsdecode(name)]=(mode.decode(),object_id.decode())
        found=set()
        with tarfile.open(archive,'r:') as tar:
            for member in tar:
                if member.isdir():continue
                if member.name not in tree or member.name in found:raise ProducerError('archive has unknown or duplicate source entry')
                mode,object_id=tree[member.name]
                if member.issym() and mode=='120000':data=os.fsencode(member.linkname)
                elif member.isfile() and mode in ('100644','100755'):
                    if member.size>128*1024**2:raise ProducerError('source entry exceeds declared bound')
                    if bool(member.mode&0o111)!=(mode=='100755'):raise ProducerError('source archive executable mode differs')
                    data=tar.extractfile(member).read()
                else:raise ProducerError('source archive type differs')
                if hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=object_id:raise ProducerError('source archive blob differs')
                found.add(member.name)
        if found!=set(tree):raise ProducerError('source archive omits committed files')
        self.source_entries=len(found);self.source_archive_sha256=_regular_hash(archive)
        if self.source_archive_sha256!=archive_hash:raise ProducerError('archive changed during membership check')
        self._event('source_archive',sha256=self.source_archive_sha256,entries=self.source_entries)


    def _tool_guard(self):
        for name,expected in self.tools.items():
            observed=describe_tool(name,expected['version_prefix'],lookup_path=self.environment.get('PATH'))
            if observed!=dict(expected):raise ProducerError('tool entry/target identity differs: '+name)

    def _version_guard(self):
        record=self.records[-1]
        if record['kind']!='tool_version':return
        if record['log_bytes']>65536:raise ProducerError('tool version output exceeds declared bound')
        path=self.directory/f'command-{len(self.records)-1:03}.log'
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            with os.fdopen(fd,'rb',closefd=False) as reader:data=reader.read(65537)
            if len(data)!=record['log_bytes'] or _sha(data)!=record['log_sha256']:raise ProducerError('tool version bytes changed')
            text=data.decode('utf-8')
            prefix=self.tools[record['tool']]['version_prefix']
            line=text.splitlines()[0] if text else ''
            match=line.startswith(prefix)
            suffix=line[len(prefix):] if match else ''
            if not text or '\0' in text or not text.endswith('\n') or not match or (not prefix[-1].isspace() and suffix and not suffix[0].isspace()):
                raise ProducerError('tool version differs: '+record['tool'])
            record['version_line']=text.splitlines()[0]
            if record['tool']=='dart' and self.expected_sdk is not None and _dart_sdk(record['version_line'])!=self.expected_sdk:
                raise ProducerError('reported Dart SDK differs from pre-child context')
        finally:
            primary=sys.exception()
            try:os.close(fd)
            except OSError as error:
                if primary is None:raise
                primary.add_note('version descriptor close failed: '+repr(error))


    def _config_guard(self):
        for relative in set(self.config_bindings.values()):
            value=_read_json(self.repo/relative,self.inputs[relative])
            packages=value.get('packages')
            if (type(value.get('configVersion')) is not int or value['configVersion']!=2
                or value.get('generator')!='pub' or value.get('generatorVersion')!=self.expected_sdk
                or type(packages) is not list or not packages):raise ProducerError('config generator/SDK differs')
            names=set()
            for entry in packages:
                if (type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names
                    or type(entry.get('rootUri')) is not str or not entry['rootUri']
                    or type(entry.get('packageUri')) is not str):raise ProducerError('invalid generated package config entry')
                names.add(entry['name'])

    def _input_guard(self):
        self.lease_check()
        for relative,expected in self.inputs.items():
            if _regular_hash(self.repo/relative)!=expected:raise ProducerError('input identity/digest differs: '+relative)
        if self.config_bindings:self._config_guard()

    def _command_history_error(self,attempt,stage,error,secondary=False):
        if self._command_history_primary_error is None:
            self._command_history_primary_error=error;self._command_history_primary_stage=stage
        elif secondary or error is not self._command_history_primary_error:
            self._command_history_secondary_errors.append((stage,error))
        if type(attempt) is dict and all(type(key) is str for key in attempt):
            if attempt.get('first_error') is None:attempt['first_error']=error
            attempt['error_stage']=stage

    def _wait_command_natural(self,timeout):
        if type(timeout) not in (int,float) or not 0<=timeout<=60:
            raise ProducerError('bounded command wait required')
        attempt=self._command_attempt
        if (type(attempt) is not dict or any(type(key) is not str for key in attempt)
            or type(self._command_attempts) is not list
            or not any(item is attempt for item in self._command_attempts)):
            raise ProducerError('exact retained command attempt required')
        process=self.process
        try:
            if (type(process) is not _COMMAND_POPEN_TYPE or attempt['process'] is not process
                or attempt['wait_uncertain'] is not False
                or (attempt['wait_process'] is not None and attempt['wait_process'] is not process)
                or type(self.records) is not list or not self.records
                or type(attempt['index']) is not int or attempt['index']!=len(self.records)-1
                or attempt['record'] is not self.records[-1]):
                raise ProducerError('command wait identity or progress changed')
            if type(attempt['wait_observed']) is not bool:
                raise ProducerError('unknown command wait witness')
            previous=attempt['wait_status']
            if attempt['wait_observed'] and type(previous) is not int:
                raise ProducerError('unknown previous command wait status')
            if type(attempt['record']) is not dict or any(type(key) is not str for key in attempt['record']):
                raise ProducerError('unknown current command record')
            if not attempt['wait_observed'] and previous is not None:
                raise ProducerError('unobserved command status is not empty')
            cached=self.records[-1]['returncode']
            if cached is not None and type(cached) is not int:
                raise ProducerError('unknown cached command status')
            attempt['wait_process']=process
            try:status=process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                attempt['wait_timeouts']+=1
                raise
            attempt['raw_wait_return']=status
            if (type(status) is not int or (attempt['wait_observed'] and previous!=status)
                or (cached is not None and cached!=status)):
                raise ProducerError('command wait returned malformed or changed status')
            # This exact METHOD return precedes _end_command and all its metadata IO.
            attempt['wait_status']=status;attempt['wait_observed']=True
            return status
        except subprocess.TimeoutExpired:raise
        except BaseException as error:
            attempt['wait_uncertain']=True
            self._command_history_error(attempt,'command_wait',error)
            raise

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index]);kind,tool=self.task_kinds[index]
        attempt=dict(index=index,argv=tuple(argv),kind=kind,tool=tool,record=None,log=None,
            reader_fd=None,writer_fd=None,pipe_attempted=False,pipe_returned=None,
            popen_attempted=False,popen_returned=None,process=None,
            parent_writer_close_attempted=False,parent_writer_close_returned=None,
            cleanup_close_attempts=[],stage='reserved',first_error=None,error_stage=None,
            wait_process=None,wait_status=None,wait_observed=False,raw_wait_return=None,
            wait_uncertain=False,wait_timeouts=0,allocation_class=None,allocation_new=None,allocation_init=None,
            allocated_process=None,allocation_attempted=False,allocation_returned=None,
            initializer_attempted=False,initializer_returned=None,initializer_result=None,initializer_result_valid=None,allocation_arguments=None)
        self._command_attempt=attempt
        self._command_attempts.append(attempt)
        try:
            attempt['stage']='command_start_event'
            self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
            attempt['stage']='log_open'
            self.log=(self.directory/f'command-{index:03}.log').open('xb',buffering=0)
            attempt['log']=self.log
            self.output_log=self.log;self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False
            self.output_hash=hashlib.sha256();self.output_bytes=0
            record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),
                    'returncode':None,'spawn_error':None,'output_eof':False,'log_complete':False,
                    'whole_descendant_exit_proven':False,'parent_output_write_close_confirmed':False}
            attempt['record']=record
            self.records.append(record)
            writer=None
            try:
                attempt['stage']='pipe';attempt['pipe_attempted']=True
                self.output_fd,writer=os.pipe()
                attempt['reader_fd']=self.output_fd;attempt['writer_fd']=writer;attempt['pipe_returned']=True
                attempt['stage']='pipe_flags'
                os.set_inheritable(self.output_fd,False);os.set_inheritable(writer,False)
                os.set_blocking(self.output_fd,False)
                attempt['stage']='Popen';attempt['popen_attempted']=True
                self.process=self._allocate_command_process(attempt,argv,writer)
                attempt['process']=self.process;attempt['popen_returned']=True
            except OSError as error:
                self._command_history_error(attempt,attempt['stage'],error)
                if attempt['popen_attempted'] and attempt['popen_returned'] is None:attempt['popen_returned']=False
                record['spawn_error']=repr(error)
                for fd in (writer,self.output_fd):
                    if fd is not None:
                        close=dict(fd=fd,attempted=True,returned=None)
                        attempt['cleanup_close_attempts'].append(close)
                        try:os.close(fd)
                        except OSError as secondary:
                            close['returned']=False
                            self._command_history_error(attempt,'unspawned_close',secondary,secondary=True)
                            error.add_note('unspawned output close failed: '+repr(secondary))
                        else:close['returned']=True
                self.output_fd=None;record['output_eof']=None
                self._end_command(None)
                self._finish('failed','command spawn failed: '+repr(error))
            else:
                # Exact returned Popen is retained above, before pid/close/journal IO.
                record['pid']=self.process.pid;self.pending=True
                try:
                    fd=writer;writer=None
                    attempt['stage']='parent_writer_close';attempt['parent_writer_close_attempted']=True
                    os.close(fd)
                except OSError as error:
                    attempt['parent_writer_close_returned']=False
                    self._command_history_error(attempt,'parent_writer_close',error)
                    record['parent_output_write_close_error']=repr(error)
                    self._defer_failure(error)
                else:
                    attempt['parent_writer_close_returned']=True
                    record['parent_output_write_close_confirmed']=True
                attempt['stage']='command_spawned_event'
                self._event('command_spawned',index=index,pid=self.process.pid)
                attempt['stage']='spawned'
        except BaseException as error:
            self._command_history_error(attempt,attempt['stage'],error)
            raise

    def _observe_direct_status(self):
        status=self.process.poll()
        if status is not None and self.records[-1]['returncode'] is None:
            self.records[-1]['returncode']=status
            self.records[-1]['direct_exit_observed_ns']=time.time_ns()
        return status

    def _drain_output(self,deadline):
        """Continue one pipe, bounded by the caller's remaining wait budget.

        EOF authenticates no writer or descendant identity. A read error fails the
        run even if later continuation reaches EOF. An ambiguous file-write error
        quarantines the original read FD and bounded unwritten bytes, without
        replaying bytes, closing a live writer channel, or launching another child.
        """
        record=self.records[-1]
        while True:
            self._observe_direct_status()
            if self.output_write_uncertain:return False
            if self.output_buffer:
                try:count=self.output_log.write(self.output_buffer)
                except BaseException:
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise
                if type(count) is not int or not 0<count<=len(self.output_buffer):
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise ProducerError('output log write count is uncertain')
                self.output_hash.update(self.output_buffer[:count]);self.output_bytes+=count
                self.output_buffer=self.output_buffer[count:]
                if time.monotonic()>=deadline:return False
                continue
            if record['output_eof'] is True:return True
            try:part=os.read(self.output_fd,65536)
            except InterruptedError:
                if time.monotonic()>=deadline:return False
                continue
            except BlockingIOError:
                remaining=deadline-time.monotonic()
                if remaining<=0:return False
                select.select([self.output_fd],[],[],min(remaining,.05))
                continue
            except BaseException as error:
                record.setdefault('output_read_errors',[]).append(repr(error))
                raise
            if part:
                self.output_buffer=part
                continue
            record['output_eof']=True;record['output_eof_observed_ns']=time.time_ns()
            fd=self.output_fd;self.output_fd=None
            try:os.close(fd)
            except OSError as error:
                record['output_read_close_error']=repr(error)
                raise
            return True

    def _end_command(self,status):
        group=_end_command_group(self);guard=group[1];refuse=group[2]
        attempt={'owner':self,'log':None,'events':None,'command_record':None,
                 'primary_error':None,'steps':[],'completed':False}
        _END_COMMAND_RECORDS.append(attempt)
        def step(stage,callback):
            guard();_failure_preservation_guard(self)
            row={'stage':stage,'returned':False,'raw':None,'error':None}
            attempt['steps'].append(row)
            try:
                raw=callback();row['raw']=raw;row['returned']=True
                return raw
            except BaseException as error:refuse(error,attempt,row)
        try:
            log=self.log;events=self.events;directory=self.directory;records=self.records
            record=records[-1];index=len(records)-1
            attempt.update(log=log,events=events,command_record=record,directory=directory,records=records,index=index)
            flush=log.flush;fileno=log.fileno;close=log.close
            fsync=os.fsync;snapshot=_file_snapshot;event=self._event
            self.pending=False
            record['returncode']=status;record['ended_ns']=time.time_ns()
            self.log=None;self.output_log=None
            def context():
                guard()
                if (self.directory is not directory or self.events is not events or self.records is not records
                    or len(records)!=index+1 or records[-1] is not record or self.pending is not False
                    or self.log is not None or self.output_log is not None):
                    raise ProducerError('end-command context changed')
            context()
            raw=step('log_flush',flush)
            if raw is not None:raise ProducerError('log flush returned an invalid result')
            context()
            fd=step('log_fileno',fileno)
            if type(fd) is not int or fd<0:raise ProducerError('log fileno returned an invalid descriptor')
            context()
            raw=step('log_fsync',lambda:fsync(fd))
            if raw is not None:raise ProducerError('log fsync returned an invalid result')
            context()
            step('log_close',close)
            context()
            data=step('log_snapshot',lambda:snapshot(directory/f'command-{index:03}.log'))
            if (type(data) is not dict or set(data)!= {'size','sha256'}
                or type(data['size']) is not int or data['size']<0
                or type(data['sha256']) is not str or re.fullmatch('[0-9a-f]{64}',data['sha256']) is None):
                raise ProducerError('log snapshot returned an invalid result')
            context()
            record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
            if record['spawn_error'] is None:
                if (record['output_eof'] is not True or self.output_fd is not None or self.output_buffer
                    or data!={'size':self.output_bytes,'sha256':self.output_hash.hexdigest()}):
                    raise ProducerError('output pipe bytes and final log snapshot differ')
                record['log_complete']=not self.output_write_uncertain and 'output_read_errors' not in record
            raw=step('command_end_event',lambda:event('command_end',index=index,**record))
            if raw is not None:raise ProducerError('command-end event returned an invalid result')
            context();attempt['completed']=True
        except BaseException as error:
            guard()
            refuse(error,attempt)

    def _finish(self,status,error=None):
        self.finished=True
        output_hashes={}
        if status=='success':
            for role,path in self.outputs.items():
                if '*' in str(path):
                    matches=sorted(Path(path).parent.glob(Path(path).name))
                    if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                    path=matches[0]
                output_hashes[role]={'path':str(path),'sha256':_regular_hash(Path(path))}
        self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                     'scope':'owned_direct_child_wait_output_pipe_eof_and_file_snapshots_only','capture_ready':False,
                     'status':status,'error':error,'census_id':self.census_id,'expected_sdk':self.expected_sdk,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                     'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                     'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance,'tools':{k:dict(v) for k,v in self.tools.items()}}
        _finish_publication_guard(self)
        _failure_preservation_guard(self)
        if id(self) in _FINISH_PUBLICATIONS:raise ProducerError('finish publication is permanently terminal')
        original_events=self.events;directory=self.directory;result=self.result
        private_first=[None]
        def guard():
            if private_first[0] is not None:raise private_first[0]
        record={'owner':self,'events':original_events,'directory':directory,'result':result,
                'primary_error':None,'steps':[],'completed':False}
        _FINISH_PUBLICATIONS[id(self)]=(self,guard)
        _FINISH_PUBLICATION_RECORDS.append(record)
        def refuse(error,row=None):
            private_first[0]=error
            try:
                group=_failure_preservation_group(self,error)
                private_first[0]=group[3]
                record['primary_error']=private_first[0]
                group[2](error,row)
            finally:raise private_first[0]
        def step(stage,callback):
            guard();_failure_preservation_guard(self)
            row={'stage':stage,'returned':False,'raw':None,'error':None}
            record['steps'].append(row)
            try:
                raw=callback();row['raw']=raw;row['returned']=True
                return raw
            except BaseException as error:refuse(error,row)
        def context(expected_events):
            guard()
            if self.directory is not directory or self.events is not expected_events or self.result is not result:
                raise ProducerError('finish publication context changed')
        def digest(raw):
            if type(raw) is not str or re.fullmatch('[0-9a-f]{64}',raw) is None:
                raise ProducerError('finish publication digest is invalid')
            return raw
        try:
            writer=_write_json;hasher=_regular_hash;event=self._event;close=original_events.close
            result_path=directory/'result.json';journal_path=directory/'journal.jsonl'
            context(original_events)
            raw=step('result_write',lambda:writer(result_path,result))
            if raw is not None:raise ProducerError('finish result writer returned an invalid result')
            context(original_events)
            raw=step('result_hash',lambda:hasher(result_path))
            self.result_sha256=digest(raw)
            context(original_events)
            raw=step('finished_event',lambda:event('finished',status=status,error=error))
            if raw is not None:raise ProducerError('finish event returned an invalid result')
            context(original_events)
            self.events=None
            step('journal_close',close)
            context(None)
            raw=step('journal_hash',lambda:hasher(journal_path))
            self.journal_sha256=digest(raw)
            context(None)
            self.evidence_complete=True;record['completed']=True
            return self.result
        except BaseException as error:
            guard()
            refuse(error)

    def _defer_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,
            process=None,events=None,log=None,completed=False,steps=[])
        _DEFERRED_FAILURE_RECORDS.append(record) # Before formatting/callee I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            process=call('process',lambda:getattr,(self,'process'));record['process']=process
            events=call('events',lambda:getattr,(self,'events'));record['events']=events
            log=call('log',lambda:getattr,(self,'log'));record['log']=log
            pending=call('pending',lambda:getattr,(self,'pending'))
            records=call('records',lambda:getattr,(self,'records'))
            deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
            if (type(pending) is not bool or type(records) is not list or not records
                or type(records[-1]) is not dict or any(type(k) is not str for k in records[-1])
                or (deferred is not None and type(deferred) is not str)):
                raise ProducerError('unknown deferred failure context')
            command_record=records[-1];record['command_record']=command_record
            preserver=call('preserver_lookup',lambda:lambda:self._preserve_failure)
            renderer=call('repr_lookup',lambda:lambda:repr)

            def check_context(expected,expected_events=events):
                guard()
                if (self.directory is not directory or self.process is not process
                    or self.events is not expected_events or self.log is not log or self.pending is not pending
                    or self.records is not records or not records or records[-1] is not command_record
                    or self.deferred_error is not expected):
                    raise ProducerError('deferred failure context changed')
                actual=call('preserver_binding',lambda:lambda:self._preserve_failure)
                if (type(actual) is not MethodType or type(preserver) is not MethodType
                    or actual.__self__ is not self or preserver.__self__ is not self
                    or actual.__func__ is not preserver.__func__):
                    raise ProducerError('deferred failure preserver binding changed')

            check_context(deferred)
            text=call('error_repr',lambda:renderer,(error,))
            if type(text) is not str:raise ProducerError('unknown deferred failure representation')
            check_context(deferred)
            if deferred is None:
                self.deferred_error=text;expected=text
            else:
                secondary=call('secondary_list',lambda:command_record.setdefault,('secondary_errors',[]))
                if type(secondary) is not list:raise ProducerError('unknown secondary failure ledger')
                appended=call('secondary_append',lambda:secondary.append,(text,))
                if appended is not None:raise ProducerError('unknown secondary append return')
                expected=deferred
            check_context(expected)
            raw=call('failure_preserve',lambda:preserver,(error,))
            if raw is not None:raise ProducerError('unknown failure preserver return')
            check_context(expected,None if not pending and events is not None else events)
            record['completed']=True # Deferral body only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)

    def _preserve_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,events=None,
            completed=False,steps=[])
        _FAILURE_PRESERVATION_RECORDS.append(record) # Before context lookup/I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            events=call('events',lambda:getattr,(self,'events'))
            record['events']=events # Original handle BEFORE representation/publication.
            pending=call('pending',lambda:getattr,(self,'pending'))
            attempted=call('failure_attempted',lambda:getattr,(self,'failure_attempted'))
            if type(pending) is not bool or type(attempted) is not bool:
                raise ProducerError('unknown failure preservation flags')
            if not attempted:
                self.failure_attempted=True # Original one terminal publication attempt.
                writer=call('failure_writer_lookup',lambda:lambda:_write_json)
                renderer=call('repr_lookup',lambda:lambda:repr)
                deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
                if deferred is not None and type(deferred) is not str:
                    raise ProducerError('unknown deferred failure text')
                text=deferred or call('error_repr',lambda:renderer,(error,))
                if type(text) is not str:raise ProducerError('unknown failure representation')
                uncertain=self.output_write_uncertain
                if type(uncertain) is not bool:raise ProducerError('unknown output write uncertainty')
                payload={'error':text,'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
                    'output_write_uncertain':uncertain,
                    'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if uncertain else None}
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation context changed')
                raw=call('failure_write',lambda:writer,(directory/'failure.json',payload))
                if raw is not None:raise ProducerError('unknown failure publication return')
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation publication context changed')
            if not pending and events is not None:
                if self.directory is not directory or self.events is not events or self.pending is not pending:
                    raise ProducerError('failure journal context changed')
                closer=call('journal_close_lookup',lambda:lambda:events.close)
                self.events=None # Preserve original clearing-before-close; handle retained.
                call('journal_close',lambda:closer) # Original ignored return, including False.
            record['completed']=True # Helper only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)

    def wait(self,timeout):
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        self.lease_check()
        deadline=time.monotonic()+timeout
        try:
            while True:
                if not self._drain_output(deadline):return None
                try:status=self._wait_command_natural(max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._version_guard();self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:
                    self._command_history_error(self._command_attempt,'postcommand_guards',e)
                    return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            _end_command_guard(self)
            _finish_publication_guard(self)
            self._command_history_error(self._command_attempt,'command_wait_body',e)
            if self.pending:
                self._defer_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise

    def _initialize_command_process(self,initializer,process,arguments):
        argv,cwd,stdin,writer,stderr,close_fds,environment=arguments
        return initializer(process,argv,cwd=cwd,stdin=stdin,stdout=writer,
            stderr=stderr,close_fds=close_fds,env=environment)

    def _allocate_command_process(self,attempt,argv,writer):
        cls=_COMMAND_POPEN_TYPE;allocator=_COMMAND_POPEN_NEW;initializer=_COMMAND_POPEN_INIT
        arguments=(argv,self.repo,subprocess.DEVNULL,writer,subprocess.STDOUT,True,self.environment)
        attempt['allocation_arguments']=arguments
        attempt['allocation_class']=cls;attempt['allocation_new']=allocator;attempt['allocation_init']=initializer
        def check():
            if (subprocess.Popen is not cls or _COMMAND_POPEN_TYPE is not cls
                or _COMMAND_POPEN_NEW is not allocator or _COMMAND_POPEN_INIT is not initializer
                or type(cls) is not type or allocator is not object.__new__
                or type.__getattribute__(cls,'__new__') is not allocator
                or type.__getattribute__(cls,'__init__') is not initializer):
                raise ProducerError('original command constructor binding changed')
        check()
        attempt['stage']='Popen_allocate';attempt['allocation_attempted']=True
        try:process=allocator(cls)
        except BaseException as error:
            self._command_history_error(attempt,'Popen_allocate',error)
            attempt['allocation_returned']=False
            raise
        # This exact object precedes initializer I/O, including constructor failure.
        attempt['allocated_process']=process;attempt['allocation_returned']=True
        if type(process) is not cls:raise ProducerError('exact allocated command object required')
        check()
        attempt['stage']='Popen_initialize';attempt['initializer_attempted']=True
        try:returned=self._initialize_command_process(initializer,process,arguments)
        except BaseException as error:
            self._command_history_error(attempt,'Popen_initialize',error)
            attempt['initializer_returned']=False
            raise
        attempt['initializer_result']=returned;attempt['initializer_returned']=True
        attempt['initializer_result_valid']=returned is None
        if returned is not None:
            label=type.__dict__['__name__'].__get__(type(returned),type)
            raise TypeError("__init__() should return None, not '"+label+"'")
        return process



def start_fixture(**kwargs):
    return CommandProducer(**kwargs,provenance='fixture')


def _live_inputs(inputs):
    required={'pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'}
    if type(inputs) is not dict or not required<set(inputs) or any(k not in required and not k.endswith('/.dart_tool/package_config.json') and k!='.dart_tool/package_config.json' for k in inputs):
        raise ProducerError('actual three locks and generated package configs required')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR'):
        if os.environ.get(key):raise ProducerError('undeclared build environment: '+key)


def _canonical_native_path(repo):
    return Path(repo)/'native/transport/target/ffi-test/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')


def _validate_owned_output_path(run,phase,role,path):
    """Location predicate only; this does not validate bytes or admit a capture."""
    if phase=='canonical' and role=='canonical_native':
        if path!=_canonical_native_path(run.repo):raise ProducerError('canonical native outside own ffi-test output')
    elif phase=='execution' and role=='static_rlib':
        if path.parent!=run.directory/'target/release/deps' or not re.fullmatch('libct_core-[A-Za-z0-9_]+\\.rlib',path.name):raise ProducerError('RLIB outside own production target')
    elif phase=='execution' and role in ('native_elf','driver_elf'):
        if path!=run.directory/'target/release'/('libct_ffi.so' if role=='native_elf' else 'http_stream'):
            raise ProducerError('production artifact outside own target')
    else:raise ProducerError('own output phase/role differs')


def start_canonical(**kwargs):
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    if os.environ.get('CONNECTANUM_CI_NATIVE_DIR'):raise ProducerError('undeclared canonical CI artifact reuse')
    native=_canonical_native_path(kwargs['repo'])
    configured=os.environ.get('CONNECTANUM_NATIVE_LIB')
    if configured and Path(configured).resolve()!=native:raise ProducerError('canonical native path is outside own declared ffi-test output')
    return CommandProducer(**kwargs,commands=[['bin/verify']],provenance='canonical_recipe',outputs={'canonical_native':native})


def start_production(**kwargs):
    if sys.platform!='linux':raise ProducerError('production ELF recipe requires actual Linux')
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    target=Path(kwargs['run_dir'])/'target'
    return CommandProducer(**kwargs,provenance='production_recipe',env_delta={'CARGO_TARGET_DIR':str(target)},
        commands=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                  ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],
        outputs={'native_elf':target/'release/libct_ffi.so','driver_elf':target/'release/http_stream',
                 'static_rlib':target/'release/deps/libct_core-*.rlib'})




def _retain_receipt_error(run,stage,error,secondary=False):
    # Process-life private objects; public receipt failure metadata is TYPEONLY.
    primary=run._receipt_primary_error_object
    if primary is None:
        run._receipt_primary_error_object=error
        run._receipt_primary_error_stage=stage
    elif secondary or error is not primary:
        # Separate occurrences retain their stage, even for the same error object.
        run._receipt_secondary_error_objects.append((stage,error))
    return run._receipt_primary_error_object


def _receipt_resource_error(run,resource,stage,error,uncertain=False,secondary=False):
    if resource['first_error'] is None:resource['first_error']=error
    resource['error_stage']=stage
    if uncertain:
        resource['quarantined']=True
        run._receipt_resources_quarantined=True
    _retain_receipt_error(run,stage,error,secondary=secondary)

def _receipt_resource_context(run,closing=False):
    if run._receipt_resources_quarantined and not closing:
        raise ProducerError('receipt resources are quarantined')
    ledger=run._receipt_resources
    if type(ledger) is not list:
        raise ProducerError('unknown receipt resource ledger')
    callback=run._receipt_resource_lease
    directory=run._receipt_resource_directory
    if run.lease_check is not callback:
        raise ProducerError('receipt lease callback changed')
    retained=[]
    for resource in ledger:
        if type(resource) is not dict or any(type(key) is not str for key in resource):
            raise ProducerError('unknown receipt resource fields before callback')
        retained.append((resource,tuple(resource.items())))
    callback()
    if run._receipt_resources_quarantined and not closing:
        raise ProducerError('receipt resources quarantined during callback')
    if (run.lease_check is not callback or run._receipt_resource_lease is not callback
        or run.directory is not directory or run._receipt_resource_directory is not directory
        or type(directory) is not type(Path())):
        raise ProducerError('receipt directory or callback changed')
    if run._receipt_resources is not ledger or len(ledger)!=len(retained):
        raise ProducerError('receipt resource ledger changed during callback')
    for actual,(resource,fields) in zip(ledger,retained):
        if (actual is not resource or type(resource) is not dict or len(resource)!=len(fields)
            or any(type(key) is not str for key in resource)):
            raise ProducerError('receipt resource records changed during callback')
        if any(key not in resource or resource[key] is not value for key,value in fields):
            raise ProducerError('receipt resource field changed during callback')

def _receipt_resource_guard(run,resource,closing=False):
    if (type(resource) is not dict or any(type(k) is not str for k in resource)
        or not any(item is resource for item in run._receipt_resources)):
        raise ProducerError('unknown exact receipt resource')
    if resource['quarantined'] or resource['close_attempted']:
        raise ProducerError('receipt resource is quarantined or retired')
    if run._receipt_resources_quarantined and not closing:
        raise ProducerError('receipt resource ledger is quarantined')
    try:
        _receipt_resource_context(run,closing=closing)
        if resource['quarantined'] or resource['close_attempted']:
            raise ProducerError('receipt resource retired or quarantined during callback')
        if type(resource['binding']) is not tuple or len(resource['binding'])!=3:
            raise ProducerError('unknown receipt resource binding')
        role,path,direction=resource['binding']
        if (resource['role'] is not role or resource['path'] is not path
            or resource['direction'] is not direction or type(path) is not type(Path())
            or path.parent!=run._receipt_resource_directory):
            raise ProducerError('receipt resource binding changed')
        fd=resource['fd']
        if type(fd) is not int or fd<0:raise ProducerError('unknown receipt resource FD')
        import fcntl
        info=os.fstat(fd);current_path=path.lstat()
        identity=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink)
        current=identity(info)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or current!=identity(current_path)
            or os.get_inheritable(fd) is not False
            or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=(os.O_WRONLY if direction=='write' else os.O_RDONLY)):
            raise ProducerError('receipt FD/path/direction changed')
        if resource['identity'] is None:
            resource['identity']=current
            resource['initial_size']=info.st_size
        if current!=resource['identity']:raise ProducerError('receipt FD identity drift')
        expected_size=resource['offset'] if direction=='write' else resource['initial_size']
        if info.st_size!=expected_size:raise ProducerError('receipt file size changed')
        if not (closing and resource['read_uncertain']):
            position=os.lseek(fd,0,os.SEEK_CUR)
            if type(position) is not int or position!=resource['offset']:
                raise ProducerError('receipt FD position changed')
        for other in run._receipt_resources:
            if other is resource or other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:
                raise ProducerError('active receipt FDs alias')
    except BaseException:
        resource['quarantined']=True;run._receipt_resources_quarantined=True
        raise

def _receipt_resource_open(run,role,path,direction):
    if (type(role) is not str or type(path) is not type(Path()) or type(direction) is not str or direction not in ('read','write')
        or type(run._receipt_resources) is not list or run._receipt_resources_quarantined):
        raise ProducerError('receipt resource opening refused')
    if any(type(item) is not dict or type(item.get('path')) is not type(Path()) for item in run._receipt_resources):
        raise ProducerError('unknown earlier receipt resource fields')
    if any(item['path']==path for item in run._receipt_resources):
        raise ProducerError('receipt resource path attempt is permanently terminal')
    resource=dict(role=role,path=path,direction=direction,binding=(role,path,direction),
        fd=None,raw_open_return=None,identity=None,initial_size=None,offset=0,
        open_attempted=False,open_returned=None,close_attempted=False,close_returned=None,
        write_attempted=False,last_write_count=None,write_uncertain=False,read_uncertain=False,
        pending_payload=None,pending_offset=0,last_read=None,fsync_attempted=False,fsync_returned=None,
        quarantined=False,first_error=None,error_stage=None)
    run._receipt_resources.append(resource) # Reserve and retain BEFORE any fallible open/metadata IO.
    try:
        _receipt_resource_context(run)
        if path.parent!=run._receipt_resource_directory:
            raise ProducerError('receipt resource path outside original directory')
        resource['open_attempted']=True
        flags=os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK
        flags|=(os.O_WRONLY|os.O_CREAT|os.O_EXCL) if direction=='write' else os.O_RDONLY
        returned=_receipt_resource_io(resource,'open',flags)
        resource['raw_open_return']=returned
        if type(returned) is not int or returned<0:raise ProducerError('unknown receipt open return')
        resource['fd']=returned # Exact raw FD retained BEFORE callback/fstat or other IO.
        resource['open_returned']=True
        _receipt_resource_guard(run,resource)
        if direction=='write' and resource['initial_size']!=0:
            raise ProducerError('new receipt output is not empty')
        return resource
    except BaseException as error:
        if resource['open_returned'] is None:resource['open_returned']=False
        _receipt_resource_error(run,resource,'resource_open',error,True)
        raise

def _receipt_resource_io(resource,step,value=None):
    if step=='open':return os.open(resource['path'],value,0o666)
    if step=='write':return os.write(resource['fd'],value)
    if step=='read':return os.read(resource['fd'],value)
    if step=='fsync':return os.fsync(resource['fd'])
    if step=='close':return os.close(resource['fd'])
    raise ProducerError('unknown receipt resource IO step')

def _receipt_resource_write(run,resource,payload):
    if type(payload) is not bytes:raise ProducerError('receipt payload must be exact bytes')
    if run._receipt_resources_quarantined or resource['direction']!='write' or resource['pending_payload'] is not None:
        raise ProducerError('receipt write state unavailable')
    resource['pending_payload']=payload;resource['pending_offset']=0
    try:
        while resource['pending_offset']<len(payload):
            _receipt_resource_guard(run,resource)
            resource['write_attempted']=True
            remaining=payload[resource['pending_offset']:]
            count=_receipt_resource_io(resource,'write',remaining)
            resource['last_write_count']=count
            if type(count) is not int or count<=0 or count>len(remaining):
                raise ProducerError('unknown receipt write count')
            resource['pending_offset']+=count;resource['offset']+=count
        resource['pending_payload']=None
    except BaseException as error:
        resource['write_uncertain']=True
        _receipt_resource_error(run,resource,'resource_write',error,True)
        raise

def _receipt_resource_read(run,resource,maximum):
    if resource['direction']!='read' or type(maximum) is not int or maximum<=0:
        raise ProducerError('invalid receipt read')
    try:
        _receipt_resource_guard(run,resource)
        value=_receipt_resource_io(resource,'read',maximum);resource['last_read']=value
        if type(value) is not bytes or len(value)>maximum:raise ProducerError('unknown receipt read return')
        resource['offset']+=len(value)
        return value
    except BaseException as error:
        resource['read_uncertain']=True
        _receipt_resource_error(run,resource,'resource_read',error)
        raise

def _receipt_resource_sync(run,resource):
    try:
        _receipt_resource_guard(run,resource)
        resource['fsync_attempted']=True
        _receipt_resource_io(resource,'fsync')
    except BaseException as error:
        if resource['fsync_attempted']:resource['fsync_returned']=False
        _receipt_resource_error(run,resource,'resource_fsync',error)
        raise
    else:resource['fsync_returned']=True

def _receipt_resource_close(run,resource,primary=None):
    # Unknown write/identity/close MUST NOT be followed by close/reclose or replay.
    if resource['quarantined'] or resource['write_uncertain'] or resource['close_attempted']:return
    try:
        _receipt_resource_guard(run,resource,closing=True)
        resource['close_attempted']=True
        try:_receipt_resource_io(resource,'close')
        except BaseException:
            resource['close_returned']=False
            raise
        else:resource['close_returned']=True
    except BaseException as error:
        _receipt_resource_error(run,resource,'resource_close',error,True,secondary=primary is not None)
        if primary is None:raise


def _receipt_reader_io(reader,step,value=None):
    # Separate native seam: output-ledger resources never adopt reader records.
    if step=='open':return os.open(reader['path'],value,0o666)
    if step=='read':return os.read(reader['fd'],value)
    if step=='close':return os.close(reader['fd'])
    raise ProducerError('unknown receipt reader IO step')

def _receipt_reader_error(run,reader,stage,error,uncertain=False,secondary=False,read_uncertain=False):
    # Owner history precedes updates to possibly damaged per-reader dictionaries.
    first=_retain_receipt_error(run,stage,error,secondary=secondary)
    if uncertain:run._receipt_resources_quarantined=True
    if type(reader) is dict and all(type(key) is str for key in reader):
        if reader.get('first_error') is None:reader['first_error']=error
        reader['error_stage']=stage
        if uncertain:reader['quarantined']=True
        if read_uncertain:reader['read_uncertain']=True
    return first

def _receipt_reader_context(run,closing=False):
    ledger=run._receipt_readers
    if type(ledger) is not list or ledger is not run._receipt_reader_ledger:
        raise ProducerError('receipt reader ledger changed')
    retained=[]
    for reader in ledger:
        if type(reader) is not dict or any(type(key) is not str for key in reader):
            raise ProducerError('unknown receipt reader fields')
        retained.append((reader,tuple(reader.items())))
    _receipt_resource_context(run,closing=closing)
    if run._receipt_readers is not ledger or run._receipt_reader_ledger is not ledger or len(ledger)!=len(retained):
        raise ProducerError('receipt reader ledger changed during callback')
    for current,(reader,fields) in zip(ledger,retained):
        if (current is not reader or type(reader) is not dict or len(reader)!=len(fields)
            or any(type(key) is not str for key in reader)
            or any(key not in reader or reader[key] is not value for key,value in fields)):
            raise ProducerError('receipt reader fields changed during callback')

def _receipt_reader_guard(run,reader,closing=False):
    try:
        if (type(reader) is not dict or any(type(key) is not str for key in reader)
            or type(run._receipt_readers) is not list or not any(item is reader for item in run._receipt_readers)):
            raise ProducerError('receipt reader unavailable')
        if (any(type(reader.get(key)) is not bool for key in ('quarantined','close_attempted','read_uncertain','eof','open_attempted'))
            or reader['quarantined'] is True or reader['close_attempted'] is True or reader.get('open_returned') is not True
            or (reader['read_uncertain'] is True and not closing)
            or type(reader.get('offset')) is not int or reader['offset']<0):
            raise ProducerError('unknown receipt reader progress fields')
        _receipt_reader_context(run,closing=closing)
        binding=reader['binding']
        if type(binding) is not tuple or len(binding)!=5:
            raise ProducerError('unknown receipt reader binding')
        purpose,path,kind,maximum,owners=binding
        if (type(purpose) is not str or type(kind) is not str or kind not in ('hash','snapshot','json','metadata')
            or type(maximum) is not int or maximum<0 or type(owners) is not frozenset
            or any(type(owner) is not int for owner in owners)
            or type(reader.get('role')) is not str or reader['role']!='reader:'+purpose):
            raise ProducerError('unknown receipt reader binding scalars')
        if (type(reader.get('path_before')) is not tuple or len(reader['path_before'])!=9
            or any(type(item) is not int for item in reader['path_before'])
            or (reader.get('identity') is not None and (type(reader['identity']) is not tuple
                or len(reader['identity'])!=9 or any(type(item) is not int for item in reader['identity'])))):
            raise ProducerError('unknown receipt reader identity fields')
        if (reader['purpose'] is not purpose or reader['path'] is not path or reader['kind'] is not kind
            or reader['maximum'] is not maximum or reader['owners'] is not owners
            or type(path) is not type(Path()) or type(reader['fd']) is not int or reader['fd']<0):
            raise ProducerError('receipt reader binding changed')
        fd=reader['fd']
        info=os.fstat(fd);current_path=path.lstat()
        identity=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,
            value.st_nlink,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
        current=identity(info)
        import fcntl
        if (not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022
            or info.st_nlink<1 or not 0<=info.st_size<=maximum
            or current!=identity(current_path) or current!=reader['path_before']
            or os.get_inheritable(fd) is not False or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_RDONLY):
            raise ProducerError('receipt reader FD/path/owner/mode/size differs')
        if kind=='hash' and info.st_size==0:raise ProducerError('receipt hash input empty')
        if reader['identity'] is None:
            reader['identity']=current;reader['initial_size']=info.st_size
        if current!=reader['identity']:raise ProducerError('receipt reader metadata drift')
        if not (closing and reader['read_uncertain']):
            position=os.lseek(fd,0,os.SEEK_CUR)
            if type(position) is not int or position!=reader['offset']:
                raise ProducerError('receipt reader position changed')
        for other in run._receipt_readers:
            if other is reader or other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:raise ProducerError('active receipt readers alias')
        for other in run._receipt_resources:
            if other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:raise ProducerError('receipt reader aliases output')
    except BaseException:
        run._receipt_resources_quarantined=True
        if type(reader) is dict and all(type(key) is str for key in reader):reader['quarantined']=True
        raise

def _receipt_reader_open(run,purpose,path,kind,maximum,owners):
    if (type(purpose) is not str or not purpose or type(path) is not type(Path())
        or type(kind) is not str or kind not in ('hash','snapshot','json','metadata')
        or type(maximum) is not int or maximum<0 or type(owners) is not frozenset
        or not owners or any(type(owner) is not int or owner<0 for owner in owners)
        or run._receipt_resources_quarantined or type(run._receipt_readers) is not list
        or run._receipt_readers is not run._receipt_reader_ledger):
        raise ProducerError('receipt reader opening refused')
    for prior in run._receipt_readers:
        if type(prior) is not dict or any(type(key) is not str for key in prior) or type(prior.get('purpose')) is not str:
            raise ProducerError('unknown prior receipt reader')
        if prior['purpose']==purpose:raise ProducerError('receipt reader purpose permanently terminal')
    reader=dict(role='reader:'+purpose,purpose=purpose,path=path,kind=kind,maximum=maximum,owners=owners,
        binding=(purpose,path,kind,maximum,owners),path_before=None,fd=None,raw_open_return=None,
        open_attempted=False,open_returned=None,identity=None,initial_size=None,offset=0,
        read_uncertain=False,last_read=None,eof=False,collected=None,
        close_attempted=False,close_returned=None,quarantined=False,first_error=None,error_stage=None)
    run._receipt_readers.append(reader)
    try:
        _receipt_reader_context(run)
        if not path.is_absolute() or (kind in ('hash','json') and path.resolve(strict=True)!=path):
            raise ProducerError('receipt reader path is not canonical')
        info=path.lstat()
        reader['path_before']=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,
            info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
        _receipt_reader_context(run)
        reader['open_attempted']=True
        returned=_receipt_reader_io(reader,'open',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        reader['raw_open_return']=returned
        if type(returned) is not int or returned<0:raise ProducerError('unknown receipt reader open return')
        reader['fd']=returned;reader['open_returned']=True
        _receipt_reader_guard(run,reader)
        return reader
    except BaseException as error:
        _receipt_reader_error(run,reader,'reader_open:'+purpose,error,True)
        if type(reader) is dict and all(type(key) is str for key in reader) and reader.get('open_returned') is None:
            reader['open_returned']=False
        raise

def _receipt_reader_read(run,reader,maximum):
    try:
        _receipt_reader_guard(run,reader)
        value=_receipt_reader_io(reader,'read',maximum);reader['last_read']=value
        if type(value) is not bytes or len(value)>maximum:raise ProducerError('unknown receipt reader read return')
        reader['offset']+=len(value)
        if not value:reader['eof']=True
        return value
    except BaseException as error:
        _receipt_reader_error(run,reader,'reader_read',error,read_uncertain=True)
        raise

def _receipt_reader_close(run,reader,primary):
    if (type(reader) is dict and all(type(key) is str for key in reader)
        and (reader.get('quarantined') is True or reader.get('close_attempted') is True)):return
    try:
        _receipt_reader_guard(run,reader,closing=True)
        reader['close_attempted']=True
        try:
            returned=_receipt_reader_io(reader,'close')
            if returned is not None:raise ProducerError('unknown receipt reader close return')
        except BaseException:
            reader['close_returned']=False
            raise
        else:reader['close_returned']=True
    except BaseException as error:
        _receipt_reader_error(run,reader,'reader_close',error,True,secondary=primary is not None)
        if primary is None:raise

def _receipt_reader_scan(run,purpose,path,kind,maximum,*,owners=None,expected_sha=None,expected_size=None):
    owners=frozenset({os.getuid()}) if owners is None else frozenset(owners)
    reader=_receipt_reader_open(run,purpose,Path(path),kind,maximum,owners);primary=None
    try:
        parts=[];digest=hashlib.sha256()
        if expected_size is not None and reader['initial_size']!=expected_size:
            raise ProducerError('receipt metadata size differs')
        while True:
            part=_receipt_reader_read(run,reader,min(65536 if kind=='metadata' else 1024**2,maximum+1-reader['offset']))
            if not part:break
            digest.update(part)
            if kind in ('json','metadata'):parts.append(part)
            if reader['offset']>maximum:raise ProducerError('receipt reader grew beyond bound')
        _receipt_reader_guard(run,reader)
        if reader['offset']!=reader['initial_size']:raise ProducerError('receipt reader byte count differs')
        if kind in ('json','metadata'):reader['collected']=b''.join(parts)
        actual_sha=_sha(reader['collected']) if kind=='json' else digest.hexdigest()
        if expected_sha is not None and actual_sha!=expected_sha:raise ProducerError('receipt consumed digest differs')
        return dict(size=reader['offset'],sha256=actual_sha,data=reader['collected'])
    except BaseException as error:
        primary=error;_receipt_reader_error(run,reader,'reader_body:'+purpose,error)
        raise
    finally:_receipt_reader_close(run,reader,primary)

def _receipt_regular_hash(run,purpose,path,maximum=1024**3,*,owners=None):
    return _receipt_reader_scan(run,purpose,path,'hash',maximum,owners=owners)['sha256']

def _receipt_file_snapshot(run,purpose,path,maximum=16*1024**3):
    result=_receipt_reader_scan(run,purpose,path,'snapshot',maximum)
    return dict(size=result['size'],sha256=result['sha256'])

def _receipt_read_bound_metadata(run,purpose,path,expected,maximum=32*1024**2):
    if (type(expected) is not dict or any(type(key) is not str for key in expected)
        or set(expected)!={'size','sha256'} or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid receipt metadata bound before IO')
    return _receipt_reader_scan(run,purpose,path,'metadata',maximum,
        expected_sha=expected['sha256'],expected_size=expected['size'])['data']

def _receipt_read_json(run,purpose,path,expected):
    data=_receipt_reader_scan(run,purpose,path,'json',2*1024**2,expected_sha=expected)['data']
    def pairs(values):
        out={}
        for key,value in values:
            if key in out:raise ProducerError('duplicate JSON key')
            out[key]=value
        return out
    def constant(value):raise ProducerError('nonfinite JSON constant')
    try:result=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
    except (ValueError,UnicodeError) as error:raise ProducerError('malformed sealed JSON') from error
    if type(result) is not dict:raise ProducerError('sealed JSON must be an object')
    return result

def _receipt_json(run,role,path,value):
    resource=_receipt_resource_open(run,role,path,'write');primary=None
    try:
        payload=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
        _receipt_resource_write(run,resource,payload)
        _receipt_resource_sync(run,resource)
    except BaseException as error:
        primary=error;_retain_receipt_error(run,role,error)
        raise
    finally:_receipt_resource_close(run,resource,primary)

def _receipt_source_audit(run):
    path=run.directory/'receipt-source-audit.jsonl'
    audit=_receipt_resource_open(run,'source_audit',path,'write');index=0;primary=None
    try:
        def observe(*argv):
            nonlocal index
            number=index;index+=1
            out=run.directory/f'receipt-git-{number:03}.stdout';err=run.directory/f'receipt-git-{number:03}.stderr'
            cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
            result=_observe_auxiliary(run,f'receipt-git-{number:03}',cmd,32*1024**2)
            stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
            data=_receipt_read_bound_metadata(run,'audit_stdout-'+format(number,'03'),out,stdout)
            record={'argv':cmd,'returncode':result['returncode'],'stdout':stdout,'stderr':stderr,
                'auxiliary_result_sha256':_receipt_regular_hash(run,'audit_result-'+format(number,'03'),run.directory/f'receipt-git-{number:03}-result.json')}
            _receipt_resource_write(run,audit,(json.dumps(record,sort_keys=True)+'\n').encode())
            _receipt_resource_sync(run,audit)
            return data
        run._source_guard(observe)
    except BaseException as error:
        primary=error
        _retain_receipt_error(run,'source_audit',error)
        raise
    finally:_receipt_resource_close(run,audit,primary)
    return _receipt_regular_hash(run,'audit_hash',path)


def _emit(run,phase,fixture):
    if type(run) is not CommandProducer or phase not in ('canonical','execution'):
        raise ProducerError('owned producer and valid phase required')
    if run.pending or not run.finished or not run.evidence_complete or run.result['status']!='success':
        raise ProducerError('successful complete owned producer required')
    if fixture:
        if run.provenance!='fixture':raise ProducerError('fixture emitter only accepts fixture provenance')
    elif run.provenance!=('canonical_recipe' if phase=='canonical' else 'production_recipe'):
        raise ProducerError('live receipt cannot adopt fixture or foreign producer provenance')
    if run.receipt_attempted or run._receipt_primary_error_object is not None:
        raise ProducerError('receipt attempt or retained failure is permanently terminal')
    run.receipt_attempted=True
    try:
        _receipt_json(run,'attempt',run.directory/'receipt-attempt.json',{'census_id':run.census_id,'phase':phase,'fixture':fixture,'terminal':True})
        if run.census_id is None or run.expected_sdk is None or not {'server','client'}<=set(run.config_bindings):
            raise ProducerError('receipt context was not declared before child')
        intent=_receipt_read_json(run,'intent',run.directory/'intent.json',run.intent_sha256)
        sealed=_receipt_read_json(run,'result',run.directory/'result.json',run.result_sha256)
        if (intent['census_id']!=run.census_id or intent['expected_sdk']!=run.expected_sdk
            or intent['config_bindings']!=dict(run.config_bindings) or intent['inputs']!=dict(run.inputs)
            or intent['source_commit']!=run.source_commit or intent['runtime_commit']!=run.runtime_commit
            or intent['expected_archive_sha256']!=run.source_archive_sha256 or sealed!=run.result
            or intent['provenance']!=run.provenance or sealed['provenance']!=run.provenance
            or sealed['kind']!=('fixture-command-evidence-v1' if fixture else 'own-command-evidence-v1')):
            raise ProducerError('pre-child receipt context changed')
        if _receipt_regular_hash(run,'journal_hash',run.directory/'journal.jsonl')!=run.journal_sha256:raise ProducerError('sealed journal changed')
        source_audit_sha256=_receipt_source_audit(run);run._input_guard()
        if _receipt_regular_hash(run,'archive_hash',run.directory/'source.tar')!=run.source_archive_sha256:raise ProducerError('sealed archive changed')
        if set(run.tools)!=set(VERSION_ARGS) or len(sealed['commands'])!=len(run.commands):raise ProducerError('six probes and all recipes required')
        recipes=[];dart=None
        for index,record in enumerate(sealed['commands']):
            if (record['argv']!=list(run.commands[index]) or (record['kind'],record['tool'])!=run.task_kinds[index]
                or record['returncode']!=0 or record['spawn_error'] is not None
                or record.get('output_eof') is not True or record.get('log_complete') is not True
                or record.get('parent_output_write_close_confirmed') is not True):raise ProducerError('command phase/argv/status/output completion differs')
            log=_receipt_file_snapshot(run,'command_snapshot-'+format(index,'03'),run.directory/f'command-{index:03}.log')
            if log!={'size':record['log_bytes'],'sha256':record['log_sha256']}:raise ProducerError('command log changed')
            if record['kind']=='recipe':recipes.append({'argv':record['argv'],'exit':record['returncode']})
            elif record['tool']=='dart':dart=_dart_sdk(record['version_line'])
        if dart!=run.expected_sdk:raise ProducerError('actual reported SDK differs')
        if not fixture and [r['argv'] for r in recipes]!=(CANONICAL_RECIPES if phase=='canonical' else PRODUCTION_RECIPES):
            raise ProducerError('live phase recipe differs')
        expected_roles={'canonical_native'} if phase=='canonical' else {'native_elf','driver_elf','static_rlib'}
        if set(sealed['outputs'])!=expected_roles:raise ProducerError('own output roles differ')
        for role,entry in sealed['outputs'].items():
            path=Path(entry['path'])
            if not fixture:_validate_owned_output_path(run,phase,role,path)
            if _receipt_regular_hash(run,'output_hash-'+role,path)!=entry['sha256']:raise ProducerError('own output bytes changed')
        complete=run.directory/'complete-command.log'
        out=_receipt_resource_open(run,'complete_log',complete,'write');output_error=None
        try:
            for index,record in enumerate(sealed['commands']):
                incoming=_receipt_resource_open(run,'copy_input-'+format(index,'03'),run.directory/f'command-{index:03}.log','read')
                primary=None
                try:
                    h=hashlib.sha256();count=0
                    while True:
                        part=_receipt_resource_read(run,incoming,1024**2)
                        if not part:break
                        count+=len(part)
                        if count>record['log_bytes']:raise ProducerError('command log grew during copy')
                        h.update(part);_receipt_resource_write(run,out,part)
                    if count!=record['log_bytes'] or h.hexdigest()!=record['log_sha256']:
                        raise ProducerError('command bytes changed during copy')
                except BaseException as error:
                    primary=error;_retain_receipt_error(run,'command_log_copy',error)
                    raise
                finally:_receipt_resource_close(run,incoming,primary)
            _receipt_resource_sync(run,out)
        except BaseException as error:
            output_error=error;_retain_receipt_error(run,'complete_log',error)
            raise
        finally:_receipt_resource_close(run,out,output_error)
        common={'census_id':run.census_id,'source_commit':run.source_commit,'runtime_commit':run.runtime_commit,
                'source_archive_sha256':run.source_archive_sha256,'sdk':dart,'log_sha256':_receipt_regular_hash(run,'complete_hash',complete,maximum=16*1024**3),
                'lock_hashes':{k:run.inputs[p] for k,p in LOCK_PATHS.items()},
                'package_configs':{k:run.inputs[p] for k,p in run.config_bindings.items()},'commands':recipes}
        receipt={'kind':('fixture-' if fixture else 'own-')+('canonical-v1' if phase=='canonical' else 'production-v1'),**common}
        if phase=='canonical':receipt['native_sha256']=sealed['outputs']['canonical_native']['sha256']
        else:receipt.update(outputs={k:v['sha256'] for k,v in sealed['outputs'].items()},features=[])
        _receipt_json(run,'input_receipt',run.directory/'input-receipt.json',receipt)
        binding={'scope':'command-produced links only; independent canonical breadth/descendant/SDK-image/root admission still required',
                 'capture_ready':False,'fixture':fixture,'census_id':run.census_id,'intent_sha256':run.intent_sha256,
                 'result_sha256':run.result_sha256,'journal_sha256':run.journal_sha256,'source_audit_sha256':source_audit_sha256,'receipt_sha256':_receipt_regular_hash(run,'input_receipt_hash',run.directory/'input-receipt.json'),
                 'log_sha256':receipt['log_sha256']}
        _receipt_json(run,'binding',run.directory/'receipt-binding.json',binding)
        return receipt
    except BaseException as error:
        first=_retain_receipt_error(run,'emit',error)
        name=type.__dict__['__name__'].__get__(type(first),type)
        if not run._receipt_resources_quarantined:
            try:_receipt_json(run,'failure',run.directory/'receipt-failure.json',{'primary_error':name,'terminal':True})
            except BaseException as secondary:_retain_receipt_error(run,'failure_publication',secondary,secondary=True)
        if first is error:raise
        # A context-manager close may have replaced the earlier retained primary.
        raise first


def emit_receipt(run):
    if (type(run) is not CommandProducer or run.provenance not in ('canonical_recipe','production_recipe')
        or type(run.result) is not dict or run.result.get('kind')!='own-command-evidence-v1' or run.result.get('provenance')!=run.provenance):
        raise ProducerError('live receipt requires actual live-factory provenance')
    return _emit(run,'canonical' if run.provenance=='canonical_recipe' else 'execution',False)


def emit_fixture_receipt(run,phase):
    return _emit(run,phase,True)


# Separate SDK-method observer only. Never injected into WAMP/benchmark workers.
DART_PACKAGE_PROBE_SOURCE = r"""import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

Future<void> main(List<String> args) async {
  if (args.length != 1 || !RegExp(r'^[0-9a-f]{32}$').hasMatch(args.single)) {
    stderr.writeln('one declared nonce required');
    exitCode = 64;
    return;
  }
  final missingName = '__native_perf_absent_${args.single}';
  final active = await Isolate.packageConfig;
  String? bytesBase64;
  final mappings = <Map<String, Object?>>[];
  if (active != null) {
    if (active.scheme != 'file') throw StateError('non-file active config unsupported');
    final file = File.fromUri(active);
    if (file.lengthSync() > 2 * 1024 * 1024) throw StateError('active config too large');
    final bytes = file.readAsBytesSync();
    if (bytes.length > 2 * 1024 * 1024) throw StateError('active config grew');
    bytesBase64 = base64Encode(bytes);
    final config = jsonDecode(utf8.decode(bytes));
    if (config is! Map || config['packages'] is! List) throw StateError('config shape');
    final packages = config['packages'] as List;
    if (packages.length > 1024) throw StateError('too many packages');
    for (final entry in packages) {
      if (entry is! Map || entry['name'] is! String) throw StateError('package name');
      final name = entry['name'] as String;
      final resolved = await Isolate.resolvePackageUri(Uri.parse('package:$name/'));
      mappings.add({'name': name, 'uri': resolved?.toString()});
    }
  }
  final missing = await Isolate.resolvePackageUri(Uri.parse('package:$missingName/'));
  stdout.writeln(jsonEncode({
    'kind': 'dart-package-config-observation-v1',
    'script': Platform.script.toString(),
    'sdk': Platform.version,
    'config_uri': active?.toString(),
    'config_b64': bytesBase64,
    'mappings': mappings,
    'missing_name': missingName,
    'missing_uri': missing?.toString(),
  }));
}
"""


def validate_package_observation(value,*,expected_sdk,expected_script_uri,expected_config_uri,expected_config_bytes,nonce):
    """Validate helper-only observations, not compiled/loaded-role provenance."""
    import base64
    from urllib.parse import urlsplit
    keys={'kind','script','sdk','config_uri','config_b64','mappings','missing_name','missing_uri'}
    if (type(value) is not dict or set(value)!=keys or value['kind']!='dart-package-config-observation-v1'
        or type(nonce) is not str or not re.fullmatch('[0-9a-f]{32}',nonce)
        or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)
        or type(expected_script_uri) is not str or not expected_script_uri.startswith('file:')
        or type(value['sdk']) is not str or len(value['sdk'])>4096 or value['script']!=expected_script_uri
        or value['missing_name']!='__native_perf_absent_'+nonce or value['missing_uri'] is not None
        or type(value['mappings']) is not list or len(value['mappings'])>1024):
        raise ProducerError('invalid package observation schema/context')
    if _dart_sdk('Dart SDK version: '+value['sdk'])!=expected_sdk:raise ProducerError('package observer SDK differs')
    if expected_config_bytes is None:
        if expected_config_uri is not None or value['config_uri'] is not None or value['config_b64'] is not None or value['mappings']:
            raise ProducerError('null-config negative differs')
        raw=None;names=[]
    else:
        if (type(expected_config_bytes) is not bytes or not 0<len(expected_config_bytes)<=2*1024**2
            or type(expected_config_uri) is not str or not expected_config_uri.startswith('file:')
            or value['config_uri']!=expected_config_uri or type(value['config_b64']) is not str):raise ProducerError('package config context differs')
        if len(value['config_b64'])!=4*((len(expected_config_bytes)+2)//3):raise ProducerError('package encoding length differs before decoder')
        try:raw=base64.b64decode(value['config_b64'],validate=True)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config encoding') from e
        if raw!=expected_config_bytes:raise ProducerError('exact package config bytes differ')
        def pairs(values):
            out={}
            for key,entry in values:
                if key in out:raise ProducerError('duplicate package config JSON key')
                out[key]=entry
            return out
        def constant(entry):raise ProducerError('nonfinite package config JSON')
        try:config=json.loads(raw,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config JSON') from e
        if (type(config) is not dict or type(config.get('configVersion')) is not int or config['configVersion']!=2
            or config.get('generatorVersion')!=expected_sdk or type(config.get('packages')) is not list
            or not 0<len(config['packages'])<=1024):raise ProducerError('package config schema/SDK differs')
        names=[]
        for entry in config['packages']:
            if type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names:
                raise ProducerError('package config has duplicate/invalid names')
            names.append(entry['name'])
        if value['missing_name'] in names:raise ProducerError('absent query name is in declared config')
    if len(names)!=len(value['mappings']):raise ProducerError('package mapping inventory differs')
    mappings=[];other=0
    for name,entry in zip(names,value['mappings']):
        if type(entry) is not dict or set(entry)!= {'name','uri'} or entry['name']!=name:
            raise ProducerError('package mapping order/entry differs')
        uri=entry['uri']
        if uri is not None:
            if type(uri) is not str or not 0<len(uri)<=16384 or any(c in uri for c in '\0\r\n') or re.search(r'%(?![0-9a-fA-F]{2})',uri):
                raise ProducerError('invalid resolved package URI')
            try:scheme=urlsplit(uri).scheme
            except ValueError as e:raise ProducerError('malformed resolved URI') from e
            if not scheme or scheme=='package':raise ProducerError('package URI was not resolved')
        else:scheme=None
        if scheme!='file':other+=1
        mappings.append((name,uri))
    return {'scope':'helper_package_config_observation_only','capture_ready':False,'config_sha256':None if raw is None else _sha(raw),
            'package_count':len(names),'mappings':tuple(mappings),'other_or_null':other,'sdk':value['sdk'],'config_uri':value['config_uri']}


# These objects retain only this process's OWN preparation calls. They are not
# admission capabilities, descendant census, or physical lease retention.
_PREFLIGHT_OWNERS={}
_PREFLIGHT_OWNER_LIMIT=64
_PREFLIGHT_OWNERS_LOCK=threading.Lock()


def _preflight_timeout(value):
    if type(value) not in (int,float) or not 0<=value<=60:
        raise ProducerError('bounded preflight observation/wait required')
    return value


def _copy_preflight_kwargs(kwargs):
    if '_preflight_owner' in kwargs or not callable(kwargs.get('lease_check')):
        raise ProducerError('private owner hook or missing lease callback')
    budget=[4096]
    def copy(value,depth=0):
        budget[0]-=1
        if budget[0]<0 or depth>24:raise ProducerError('preflight declaration exceeds copy bound')
        if value is None or type(value) in (bool,int,float):return value
        if type(value) is str:
            if len(value)>1024**2:raise ProducerError('preflight string exceeds bound')
            return value
        if type(value) is type(Path()):return value
        if type(value) is dict:
            if any(type(k) is not str for k in value):raise ProducerError('preflight declaration keys must be strings')
            return {k:copy(v,depth+1) for k,v in value.items()}
        if type(value) in (list,tuple):
            items=[copy(v,depth+1) for v in value]
            return items if type(value) is list else tuple(items)
        raise ProducerError('unsupported preflight declaration value')
    return {k:(v if k=='lease_check' else copy(v)) for k,v in kwargs.items()}


class _RetainedPreflightOwner:
    """Serialized phase calls; caller keeps the official EX lease throughout."""

    def __init__(self,kind,owner_id,kwargs):
        self.kind=kind;self.owner_id=owner_id;self._kwargs=kwargs
        self._operation=None;self._initialized=False;self._pending=None;self._finished=None
        self._lock=threading.Lock();self._event=threading.Event();self._thread=None
        self._busy=False;self._call_done=False;self._action=None;self._index=0
        self._state='reserved';self._failed=False;self._first_error=None;self._first_error_object=None
        self._owner_emit_attempted=False;self._last_result=None
        self._workers=[];self._joined_workers=0
        self._partial_auxiliaries=None;self._auxiliary_views={};self._auxiliary_index=None
        self._auxiliary_quarantined=False;self._auxiliary_ledger_check_matched=None
        self._partial_command=None;self._command_quarantined=False;self._command_wait_status=None
        self._command_view=MappingProxyType(dict(scope='retained_command_observation_only',observed=False,
            quarantined=False,terminal_observed=False,direct_status=None,natural_wait_observed=False,pid=None))
        self._writer_seal_attempted=False;self._writer_namespace_reserved=False
        self._parent_writers=();self._parent_writer_rows=();self._parent_writer_errors=[]
        self._parent_writer_quarantined=False
        self._known_actor_attempted=False;self._known_actor_rows=()
        self._known_actor_producer=None;self._known_actor_auxiliaries=();self._known_actor_processes=()
        self._known_actor_binding=None;self._known_actor_origin=None;self._known_actor_lease_callback=None
        self._known_wait_bindings={};self._known_wait_rows={};self._known_wait_quarantined=False
        self._known_log_attempted=False;self._known_log_namespace_reserved=False
        self._known_log_writers=();self._known_log_lookup={};self._known_log_actor_records=()
        self._known_log_stream_groups=()
        self._known_log_rows=();self._known_log_errors=[];self._known_log_quarantined=False
        self._history_attempted=False;self._history_rows=()
        self._history_producer=None;self._history_binding=None;self._history_check_binding=None
        self._history_callback=None;self._history_capture_current=None
        self._history_attempt_refs=();self._history_current_attempt=None;self._history_auxiliary_refs=()
        self._history_primary_error=None;self._history_secondary_errors=[];self._history_quarantined=False
        self._snapshot=self._snapshot_locked()

    def _snapshot_locked(self):
        return MappingProxyType(dict(scope='retained_preflight_call_only',
            owner_id=self.owner_id,call_index=self._index,action=self._action,
            call_state=self._state,call_done=self._call_done,failed=self._failed,
            first_error=self._first_error,retained_operation=self._operation is not None,
            initialized=self._initialized,producer_pending=self._pending,
            producer_finished=self._finished,owner_emit_attempted=self._owner_emit_attempted,
            worker_joined=None if not self._workers else self._workers[-1]['worker_joined'],
            worker_start_settled=None if not self._workers else self._workers[-1]['start_settled'],
            all_workers_joined=bool(self._workers) and self._joined_workers==len(self._workers),
            auxiliary_index=self._auxiliary_index,
            auxiliary_ledger_check_matched=self._auxiliary_ledger_check_matched,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))

    def _register_producer(self,operation):
        with self._lock:
            with _PREFLIGHT_OWNERS_LOCK:registered=_PREFLIGHT_OWNERS.get(self.owner_id) is self
            if (threading.current_thread() is not self._thread or self._action!='construct'
                or self._operation is not None or type(operation) is not CommandProducer or not registered):
                raise ProducerError('foreign or repeated preflight constructor registration')
            self._operation=operation
            self._snapshot=self._snapshot_locked()

    def _error_locked(self,error):
        self._failed=True
        if self._first_error_object is None:
            self._first_error_object=error
            self._first_error=type.__dict__['__name__'].__get__(type(error),type)

    def _schedule(self,action,value=None):
        with self._lock:
            if self._busy:raise ProducerError('preflight phase already running or quarantined')
            if self._workers and (not self._workers[-1]['worker_joined'] or not self._workers[-1]['start_settled']):
                raise ProducerError('previous exact preflight worker has not joined with settled start')
            if self._history_attempted:
                raise ProducerError('command history attempt is permanently terminal')
            if self._known_log_attempted:
                raise ProducerError('frozen log seal attempt is permanently terminal')
            if self._known_actor_attempted and action not in ('known_stream_wait','known_log_seal'):
                raise ProducerError('known actor snapshot attempt is permanently terminal')
            if action=='command_history_inventory':
                if self._failed is not True or self._operation is None or self._owner_emit_attempted:
                    raise ProducerError('command history snapshot not eligible')
                self._history_attempted=True
            elif action=='known_log_seal':
                if (not self._known_actor_attempted or not self._known_actor_rows
                    or self._known_actor_rows[0]['snapshot_checked'] is not True
                    or self._known_actor_rows[0]['quarantined'] is not False or self._known_wait_quarantined):
                    raise ProducerError('frozen log seal is not eligible')
                self._known_log_attempted=True
            elif action=='known_stream_wait':
                if (not self._known_actor_attempted or not self._known_actor_rows
                    or self._known_actor_rows[0]['snapshot_checked'] is not True
                    or self._known_actor_rows[0]['quarantined'] is not False or self._known_wait_quarantined):
                    raise ProducerError('selected known wait is not eligible')
                private=self._known_wait_bindings.get((value[0],value[1]))
                if private is not None and (private['quarantined'] or private['primary_error'] is not None):
                    raise ProducerError('selected known actor privately quarantined')
                cached=self._known_wait_rows.get((value[0],value[1]))
                if cached is not None and (cached['terminal_observed'] or cached['quarantined']):
                    raise ProducerError('selected known wait is permanently terminal')
            elif action=='actor_inventory':
                if self._failed is not True or self._operation is None or self._owner_emit_attempted:
                    raise ProducerError('known actor snapshot not eligible')
                self._known_actor_attempted=True
                self._known_actor_origin=(self._initialized,self._workers[-1] if self._workers else None)
            elif action=='construct':
                if self._index:raise ProducerError('constructor attempt is permanently terminal')
            elif action=='parent_writer_seal':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._command_quarantined
                    or not self._command_view['terminal_observed'] or self._writer_seal_attempted):
                    raise ProducerError('parent writer sealing not eligible')
                self._writer_seal_attempted=True
            elif action=='command_wait':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._command_quarantined
                    or self._command_view['terminal_observed']):
                    raise ProducerError('partial command continuation not eligible')
            elif action=='auxiliary_wait':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._auxiliary_quarantined):
                    raise ProducerError('partial auxiliary continuation not eligible')
                cached=self._auxiliary_views.get(value[0])
                if cached is not None and cached['terminal_result_observed']:
                    raise ProducerError('auxiliary wait is permanently terminal')
            elif (not self._initialized or self._owner_emit_attempted
                  or (action=='wait' and (self._finished or (self._failed and self._pending is not True)))
                  or (action=='emit' and self._failed)):
                raise ProducerError('preflight continuation not eligible; exact owner retained')
            if action=='emit':self._owner_emit_attempted=True
            self._index+=1;self._action=action;self._busy=True;self._call_done=False;self._state='running'
            self._event=threading.Event()
            record=dict(call_index=self._index,action=action,thread_created=False,
                start_attempted=False,start_returned=False,start_settled=False,
                worker_entered=False,call_done=False,worker_joined=False,join_error=None,call_error=None,
                auxiliary_observation_error=None,_thread=None,_join_error_object=None,_call_error_object=None,
                _auxiliary_observation_error_object=None)
            self._workers.append(record)
            try:thread=threading.Thread(target=self._work,args=(action,value,self._event,record),daemon=False)
            except BaseException as error:
                self._thread=None;self._state='start_uncertain';self._error_locked(error)
                record['start_settled']=True
                self._snapshot=self._snapshot_locked();return self
            self._thread=thread;record['_thread']=thread;record['thread_created']=True
            record['start_attempted']=True;self._snapshot=self._snapshot_locked()
        try:thread.start()
        except BaseException as error:
            with self._lock:
                record['start_settled']=True;self._error_locked(error)
                if not self._call_done:self._state='start_uncertain'
                self._snapshot=self._snapshot_locked()
                # Do not set completion or start again: the actual worker may exist.
        else:
            with self._lock:
                record['start_returned']=True;record['start_settled']=True
                self._snapshot=self._snapshot_locked()
        return self

    def _work(self,action,value,event,record):
        with self._lock:
            record['worker_entered']=True
            self._snapshot=self._snapshot_locked()
        error=None;result=None
        try:
            if action=='construct':
                factory={'fixture':start_fixture,'canonical':start_canonical,'production':start_production}[self.kind]
                result=factory(**self._kwargs,_preflight_owner=self)
                if result is not self._operation:raise ProducerError('factory did not return registered exact producer')
            elif action=='wait':result=self._operation.wait(value)
            elif action=='auxiliary_wait':result=self._wait_partial_auxiliary(*value)
            elif action=='command_wait':result=self._wait_partial_command(value)
            elif action=='parent_writer_seal':result=self._seal_parent_writers()
            elif action=='actor_inventory':result=self._freeze_known_actors()
            elif action=='command_history_inventory':result=self._freeze_command_history()
            elif action=='known_stream_wait':result=self._wait_known_streams(*value)
            elif action=='known_log_seal':result=self._seal_known_logs()
            elif self.kind=='fixture':result=emit_fixture_receipt(self._operation,value)
            else:
                # The own emitter derives its phase from producer provenance.
                result=emit_receipt(self._operation)
        except BaseException as caught:error=caught
        with self._lock:
            if action=='construct' and error is None:self._initialized=True
            if self._initialized and action not in ('actor_inventory','known_stream_wait','known_log_seal','command_history_inventory'):
                # Inventory leaves earlier owner scalar observations historical.
                # Only the serialized worker reads producer state after the call.
                self._pending=self._operation.pending;self._finished=self._operation.finished
            if error is not None:
                record['_call_error_object']=error;self._error_locked(error)
                record['call_error']=type.__dict__['__name__'].__get__(type(error),type)
            self._last_result=result;self._call_done=True;self._busy=False;record['call_done']=True
            self._state='raised' if error is not None else 'returned'
            self._snapshot=self._snapshot_locked()
        event.set()

    def observe(self,timeout=0):
        timeout=_preflight_timeout(timeout);deadline=time.monotonic()+timeout
        with self._lock:
            event=self._event;record=self._workers[-1] if self._workers else None
            thread=None if record is None else record['_thread']
        event.wait(timeout)
        # Keep the exact handle until a real join succeeds. Call/event completion
        # alone cannot release a worker or authorize another producer phase.
        if thread is not None and thread is not threading.current_thread() and thread.ident is not None:
            try:
                thread.join(max(0,deadline-time.monotonic()))
                joined=not thread.is_alive()
            except BaseException as error:
                with self._lock:
                    if record['join_error'] is None:
                        record['_join_error_object']=error
                        record['join_error']=type.__dict__['__name__'].__get__(type(error),type)
                    self._snapshot=self._snapshot_locked()
            else:
                with self._lock:
                    if joined and not record['worker_joined']:
                        record['worker_joined']=True;self._joined_workers+=1
                        record['_thread']=None
                    self._snapshot=self._snapshot_locked()
        with self._lock:return self._snapshot

    def worker_lifecycle(self):
        """Frozen call records, with no producer, Thread, FD or exception objects."""
        with self._lock:
            return tuple(MappingProxyType({key:value for key,value in record.items() if not key.startswith('_')})
                for record in self._workers)


    def _partial_auxiliary_ledger(self):
        if threading.current_thread() is not self._thread or type(self._operation) is not CommandProducer:
            raise ProducerError('partial auxiliary inspection requires the retained worker')
        data=self._operation.__dict__
        if (not {'pending','process','finished','auxiliary_operations'}<=data.keys()
            or data['pending'] is not False or data['process'] is not None or data['finished'] is not True):
            raise ProducerError('recipe actor or unknown partial producer remains unresolved')
        ledger=data['auxiliary_operations']
        if type(ledger) is not list or any(type(item) is not AuxiliaryCommand for item in ledger):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger is unknown')
        current=tuple(ledger)
        if len({id(item) for item in current})!=len(current):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger aliases an actor')
        with self._lock:
            if self._partial_auxiliaries is None:self._partial_auxiliaries=current
            frozen=self._partial_auxiliaries
        if len(current)!=len(frozen) or any(a is not b for a,b in zip(current,frozen)):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger changed; exact handles retained')
        with self._lock:
            if self._auxiliary_quarantined:raise ProducerError('partial auxiliary ledger is quarantined')
            self._auxiliary_ledger_check_matched=True
            self._snapshot=self._snapshot_locked()
        return frozen

    def _quarantine_auxiliary_ledger(self):
        with self._lock:
            self._auxiliary_quarantined=True;self._auxiliary_ledger_check_matched=False
            self._auxiliary_views={index:MappingProxyType({**dict(row),'ledger_check_matched':False})
                for index,row in self._auxiliary_views.items()}
            self._snapshot=self._snapshot_locked()

    def _cache_auxiliary_observation(self,index,auxiliary,stage):
        # Only the serialized worker reads raw actor state. Cached rows are data,
        # never actor closure, authentication or physical lease-release authority.
        if threading.current_thread() is not self._thread:
            raise ProducerError('auxiliary observation requires the retained worker')
        data=auxiliary.__dict__
        required={'started','pending','finished','process','result','status','streams'}
        if not required<=data.keys() or data['started'] is not True:
            raise ProducerError('unknown auxiliary lifecycle')
        if type(data['pending']) is not bool or type(data['finished']) is not bool:
            raise ProducerError('invalid auxiliary state')
        process=data['process'];status=data['status'];result=data['result'];streams=data['streams']
        if (type(process) is not subprocess.Popen or type(process.pid) is not int or process.pid<=0
            or (status is not None and type(status) is not int)
            or (result is not None and type(result) is not dict)
            or type(streams) is not dict or set(streams)!= {'stdout','stderr'}
            or any(type(streams[key]) is not dict or type(streams[key].get('eof')) is not bool for key in streams)):
            raise ProducerError('unknown auxiliary handle or stream state')
        terminal=data['finished'] is True and data['pending'] is False and type(result) is dict
        if terminal:
            if result.get('returncode')!=status or type(result.get('returncode')) is not type(status):
                raise ProducerError('auxiliary terminal status differs')
        elif not (data['pending'] is True and data['finished'] is False and result is None):
            raise ProducerError('incomplete auxiliary terminal state')
        row=dict(index=index,pid=process.pid,direct_status=status,pending=data['pending'],
            finished=data['finished'],stdout_eof=streams['stdout']['eof'],stderr_eof=streams['stderr']['eof'],
            terminal_result_observed=terminal,stage=stage)
        with self._lock:
            row['ledger_check_matched']=self._auxiliary_ledger_check_matched
            value=MappingProxyType(row);self._auxiliary_views[index]=value;self._auxiliary_index=index
            self._snapshot=self._snapshot_locked()
        return value

    def _wait_partial_auxiliary(self,index,timeout):
        frozen=self._partial_auxiliary_ledger()
        # Freeze and retain before selecting; never reselect a different actor.
        if index>=len(frozen):raise ProducerError('partial auxiliary index is not retained')
        auxiliary=frozen[index]
        before=self._cache_auxiliary_observation(index,auxiliary,'before_wait')
        if before['terminal_result_observed']:raise ProducerError('auxiliary wait is permanently terminal')
        try:result=auxiliary.wait(timeout)
        except BaseException as error:
            try:
                self._cache_auxiliary_observation(index,auxiliary,'after_wait_error')
                self._partial_auxiliary_ledger()
            except BaseException as secondary:
                with self._lock:
                    record=self._workers[-1]
                    record['auxiliary_observation_error']=type(secondary).__name__
                    record['_auxiliary_observation_error_object']=secondary
            raise
        after=self._cache_auxiliary_observation(index,auxiliary,'after_wait')
        self._partial_auxiliary_ledger()
        if (result is None and after['terminal_result_observed']) or (result is not None and result is not auxiliary.result):
            raise ProducerError('auxiliary wait result differs from retained state')
        return after

    def auxiliary_observations(self):
        """Immutable selected-actor data; never a complete actor inventory."""
        with self._lock:return tuple(self._auxiliary_views[index] for index in sorted(self._auxiliary_views))


    def _quarantine_command(self):
        with self._lock:
            self._command_quarantined=True
            self._command_view=MappingProxyType(dict(self._command_view,quarantined=True))

    def _checked_partial_command(self):
        # Worker-only bounded identity observations, not atomic FD/writer authority.
        if threading.current_thread() is not self._thread or type(self._operation) is not CommandProducer:
            raise ProducerError('partial command inspection requires the retained worker')
        try:
            data=self._operation.__dict__
            required={'pending','finished','process','result','records','commands','log','output_log',
                      'output_fd','output_buffer','output_hash','output_bytes','output_write_uncertain',
                      'auxiliary_operations','lease_check'}
            if (not required<=data.keys() or data['pending'] is not True or data['finished'] is not False
                or data['result'] is not None):
                raise ProducerError('unknown or nonpending partial command')
            process=data['process'];records=data['records'];commands=data['commands'];log=data['output_log']
            pid=process.pid if type(process) is subprocess.Popen else None
            auxiliary=data['auxiliary_operations']
            if (type(process) is not subprocess.Popen or type(pid) is not int or pid<=0
                or type(records) is not list or not records or any(type(x) is not dict for x in records)
                or type(commands) is not tuple or not len(records)<=len(commands)
                or any(type(x) is not tuple or not x or any(type(a) is not str for a in x) for x in commands)
                or type(log) is not io.FileIO or data['log'] is not log or log.closed
                or type(data['output_buffer']) is not bytes or type(data['output_bytes']) is not int or data['output_bytes']<0
                or type(data['output_write_uncertain']) is not bool
                or type(data['output_hash']) is not type(hashlib.sha256()) or data['output_hash'].name!='sha256'
                or type(auxiliary) is not list or any(type(x) is not AuxiliaryCommand for x in auxiliary)
                or len({id(x) for x in auxiliary})!=len(auxiliary) or not callable(data['lease_check'])):
                raise ProducerError('unknown retained command handles or state')
            record=records[-1];index=len(records)-1;argv=record.get('argv');fd=data['output_fd']
            argv_values=tuple(argv) if type(argv) is list else None;kind=record.get('kind')
            if (type(argv) is not list or any(type(x) is not str for x in argv_values) or argv_values!=commands[index]
                or type(record.get('pid')) is not int or record['pid']!=pid
                or type(kind) is not str
                or kind not in ('recipe','tool_version')
                or type(record.get('output_eof')) is not bool
                or type(record.get('parent_output_write_close_confirmed')) is not bool
                or (record.get('returncode') is not None and type(record['returncode']) is not int)
                or (fd is None and record['output_eof'] is not True)
                or (fd is not None and (type(fd) is not int or fd<0 or record['output_eof'] is True))):
                raise ProducerError('unknown command record or output pipe')
            candidate=dict(process=process,records=records,record=record,argv=argv,commands=commands,log=log,
                output_hash=data['output_hash'],auxiliary=auxiliary,lease_check=data['lease_check'],
                record_ids=tuple(id(x) for x in records),auxiliary_ids=tuple(id(x) for x in auxiliary),
                argv_values=argv_values,index=index,pid=pid,kind=kind,output_fd=fd,
                log_fd=None,log_identity=None,pipe_identity=None)
            # Retain exact actor/log/ledger handles BEFORE fstat or callback I/O.
            with self._lock:
                if self._partial_command is None:self._partial_command=candidate
                frozen=self._partial_command
                if self._command_quarantined:raise ProducerError('partial command is quarantined')
            pointers=('process','records','record','argv','commands','log','output_hash','auxiliary','lease_check')
            values=('record_ids','auxiliary_ids','argv_values','index','pid','kind')
            if (any(candidate[x] is not frozen[x] for x in pointers)
                or any(candidate[x]!=frozen[x] for x in values)
                or (fd is not None and fd!=frozen['output_fd'])):
                raise ProducerError('partial command identity changed; exact handles retained')
            log_fd=log.fileno();info=os.fstat(log_fd)
            file_identity=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink)
            if not stat.S_ISREG(info.st_mode):raise ProducerError('command log is not regular')
            if frozen['log_fd'] is None:frozen['log_fd']=log_fd;frozen['log_identity']=file_identity
            if log_fd!=frozen['log_fd'] or file_identity!=frozen['log_identity']:
                raise ProducerError('command log identity changed')
            if fd is not None:
                info=os.fstat(fd)
                pipe_identity=(info.st_dev,info.st_ino,info.st_mode)
                if not stat.S_ISFIFO(info.st_mode):raise ProducerError('command output is not a pipe')
                if frozen['pipe_identity'] is None:frozen['pipe_identity']=pipe_identity
                if pipe_identity!=frozen['pipe_identity']:raise ProducerError('command output identity changed')
            return frozen
        except BaseException:
            self._quarantine_command()
            raise

    def _cache_command_observation(self,stage):
        frozen=self._checked_partial_command()
        data=self._operation.__dict__;record=frozen['record']
        # Copy primitive values before validation; never publish fresh raw reads
        # after checking mutable producer fields. This does not make a global snapshot atomic.
        eof=record.get('output_eof');buffered=data.get('output_buffer');size=data.get('output_bytes')
        uncertain=data.get('output_write_uncertain');writer_closed=record.get('parent_output_write_close_confirmed')
        pending=data.get('pending');log_open=not frozen['log'].closed
        if (type(eof) is not bool or type(buffered) is not bytes or type(size) is not int or size<0
            or type(uncertain) is not bool or type(writer_closed) is not bool or pending is not True
            or type(stage) is not str):
            self._quarantine_command()
            raise ProducerError('unknown command observation scalar')
        with self._lock:
            status=self._command_wait_status;waited=status is not None
            terminal=waited and eof and not buffered
            row=dict(scope='retained_command_observation_only',observed=True,index=frozen['index'],
                pid=frozen['pid'],kind=frozen['kind'],direct_status=status,
                natural_wait_observed=waited,output_eof=eof,
                output_buffer_bytes=len(buffered),output_bytes=size,
                output_write_uncertain=uncertain,parent_output_write_close_confirmed=writer_closed,
                log_open=log_open,producer_pending=pending,
                terminal_observed=terminal,quarantined=self._command_quarantined,stage=stage,
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False)
            self._command_view=MappingProxyType(row)
            return self._command_view

    def _wait_partial_command(self,timeout):
        frozen=self._checked_partial_command()
        before=self._cache_command_observation('before_wait')
        if before['terminal_observed']:raise ProducerError('partial command wait is permanently terminal')
        try:
            frozen['lease_check']()
            self._checked_partial_command() # Callback drift refuses before pipe I/O.
            deadline=time.monotonic()+timeout
            # No end_command/finish, audits, next spawn, log close or publication.
            self._operation._drain_output(deadline)
            if self._command_wait_status is None:
                try:status=frozen['process'].wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:pass
                else:
                    if type(status) is not int:raise ProducerError('unknown direct command status')
                    with self._lock:self._command_wait_status=status
        except BaseException:
            try:self._cache_command_observation('after_wait_error')
            except BaseException as secondary:
                with self._lock:
                    record=self._workers[-1]
                    record['command_observation_error']=type(secondary).__name__
                    record['_command_observation_error_object']=secondary
            raise
        return self._cache_command_observation('after_wait')

    def command_observation(self):
        """Immutable selected-command data, never actor/lease closure authority."""
        with self._lock:return self._command_view

    def continue_command_wait(self,timeout):
        return self._schedule('command_wait',_preflight_timeout(timeout))


    def _cache_parent_writer(self,index,**updates):
        if any(type(key) is not str or not (value is None or type(value) is str or type(value) is bool or type(value) is int)
               for key,value in updates.items()):
            raise ProducerError('invalid parent writer scalar')
        with self._lock:
            rows=list(self._parent_writer_rows)
            rows[index]=MappingProxyType(dict(rows[index],**updates))
            self._parent_writer_rows=tuple(rows)

    def _parent_writer_error(self,index,step,error):
        self._parent_writer_errors.append((index,step,error))
        if index is not None:
            try:
                row=self._parent_writer_rows[index]
                self._cache_parent_writer(index,first_error=row['first_error'] or type(error).__name__)
            except BaseException as secondary:
                self._parent_writer_errors.append((index,'error_observation',secondary))
                self._parent_writer_quarantined=True

    def _parent_writer_raw(self,writer):
        if type(writer) is io.FileIO:raw=writer
        elif type(writer) is io.BufferedWriter:raw=writer.raw
        else:raise ProducerError('unknown parent writer object')
        if type(raw) is not io.FileIO or raw.closefd is not True:
            raise ProducerError('borrowed or unknown parent writer raw FD')
        forbidden={'flush','close','fileno','write','read','readinto','seek','tell',
                   'writable','readable','seekable','raw','closed','closefd','detach'}
        for item in ((writer,) if raw is writer else (writer,raw)):
            keys=tuple(item.__dict__)
            if any(type(key) is not str for key in keys) or any(key in forbidden for key in keys):
                raise ProducerError('parent writer has shadowed IO methods')
        if raw.closed or not io.FileIO.writable(raw):
            raise ProducerError('parent writer is not an open owned writer')
        return raw

    def _verify_parent_writer(self,index):
        if threading.current_thread() is not self._thread or self._parent_writer_quarantined:
            raise ProducerError('parent writer worker is unavailable or quarantined')
        frozen=self._partial_command
        try:
            frozen['lease_check']()
            data=self._operation.__dict__;records=data.get('records');buffered=data.get('output_buffer')
            if (data.get('process') is not frozen['process'] or records is not frozen['records']
                or tuple(id(x) for x in records)!=frozen['record_ids']
                or data.get('log') is not self._parent_writers[0]['writer']
                or data.get('output_log') is not self._parent_writers[0]['writer']
                or data.get('events') is not self._parent_writers[1]['writer']
                or data.get('pending') is not True or data.get('finished') is not False or data.get('result') is not None
                or type(buffered) is not bytes or buffered or data.get('output_fd') is not None
                or data.get('output_write_uncertain') is not False or frozen['record'].get('output_eof') is not True
                or data.get('lease_check') is not frozen['lease_check']
                or type(self._command_wait_status) is not int
                or type(frozen['process'].returncode) is not int
                or frozen['process'].returncode!=self._command_wait_status):
                raise ProducerError('parent writer command state changed')
            for position,resource in enumerate(self._parent_writers):
                row=self._parent_writer_rows[position]
                if row['close_returned'] is True and row['closed_observed'] is True and resource['writer'].closed is not True:
                    raise ProducerError('previously closed writer state changed')
            resource=self._parent_writers[index];writer=resource['writer'];raw=self._parent_writer_raw(writer)
            if raw is not resource['raw']:raise ProducerError('parent writer raw object changed')
            fd=io.FileIO.fileno(raw)
            info=os.fstat(fd);path_info=resource['path'].lstat()
            identity=lambda item:(item.st_dev,item.st_ino,item.st_mode,item.st_uid,item.st_gid,item.st_nlink)
            current=identity(info)
            if (type(fd) is not int or fd<0 or not stat.S_ISREG(info.st_mode)
                or info.st_nlink!=1 or current!=identity(path_info)):
                raise ProducerError('parent writer FD/path identity differs')
            if resource['fd'] is None:resource['fd']=fd;resource['identity']=current
            if fd!=resource['fd'] or current!=resource['identity']:
                raise ProducerError('parent writer identity changed')
            self._cache_parent_writer(index,identity_checked=True)
            return resource
        except BaseException:
            self._parent_writer_quarantined=True
            raise

    def _parent_writer_io(self,index,step):
        resource=self._parent_writers[index];writer=resource['writer']
        # Native classes are exact; instance IO method shadows were refused.
        if step=='flush':
            if type(writer) is io.FileIO:return io.FileIO.flush(writer)
            return io.BufferedWriter.flush(writer)
        if step=='fsync':return os.fsync(resource['fd'])
        if step=='close':
            if type(writer) is io.FileIO:return io.FileIO.close(writer)
            return io.BufferedWriter.close(writer)
        raise ProducerError('unknown parent writer step')

    def _seal_parent_writers(self):
        if threading.current_thread() is not self._thread or self._partial_command is None:
            raise ProducerError('parent writer sealing requires retained worker handles')
        try:
            self._partial_command['lease_check']()
            declared=self._kwargs.get('run_dir')
            if type(declared) not in (str,type(Path())):raise ProducerError('unknown declared run directory')
            directory=Path(declared)
            if directory.resolve(strict=True)!=directory:raise ProducerError('run directory is not canonical')
            # Fixed namespace, one attempt, before original writer artifact metadata.
            (directory/'owned-parent-writers').mkdir(mode=0o700)
            self._writer_namespace_reserved=True
            data=self._operation.__dict__;log=data.get('output_log');journal=data.get('events')
            self._parent_writers=(
                dict(role='command_log',writer=log,raw=None,fd=None,identity=None,
                     path=directory/('command-'+str(self._partial_command['index']).zfill(3)+'.log')),
                dict(role='journal',writer=journal,raw=None,fd=None,identity=None,path=directory/'journal.jsonl'))
            rows=tuple(MappingProxyType(dict(
                scope='owned_parent_writer_object_observations_only',role=resource['role'],
                namespace_reserved=True,identity_checked=False,flush_attempted=False,flush_returned=None,
                fsync_attempted=False,fsync_returned=None,close_attempted=False,close_returned=None,
                closed_observed=None,quarantined=False,first_error=None,
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
                for resource in self._parent_writers)
            with self._lock:self._parent_writer_rows=rows
            # Retain BOTH candidate objects before fstat; refuse unknown/shadowed/borrowed types before any close.
            for resource in self._parent_writers:resource['raw']=self._parent_writer_raw(resource['writer'])
            if self._parent_writers[0]['raw'] is self._parent_writers[1]['raw']:
                raise ProducerError('parent writers alias the same raw object')
            frozen=self._checked_partial_command()
            if (frozen is not self._partial_command or data.get('directory')!=directory
                or not self._command_view['terminal_observed']):
                raise ProducerError('parent writer declaration changed')
            for index in range(2):self._verify_parent_writer(index)
            if (self._parent_writers[0]['fd']==self._parent_writers[1]['fd']
                or self._parent_writers[0]['identity'][:2]==self._parent_writers[1]['identity'][:2]):
                raise ProducerError('parent writer FDs or files alias')
        except BaseException as error:
            self._parent_writer_quarantined=True
            self._parent_writer_error(None,'prepare',error)
            for index in range(len(self._parent_writer_rows)):
                self._cache_parent_writer(index,quarantined=True)
            raise
        for index,resource in enumerate(self._parent_writers):
            for step in ('flush','fsync','close'):
                try:self._verify_parent_writer(index)
                except BaseException as error:
                    self._parent_writer_error(index,'identity',error)
                    break
                self._cache_parent_writer(index,**{step+'_attempted':True})
                try:self._parent_writer_io(index,step)
                except BaseException as error:
                    self._cache_parent_writer(index,**{step+'_returned':False})
                    self._parent_writer_error(index,step,error)
                    if step=='flush':
                        # close() may flush again: NEVER replay after a failed flush.
                        self._cache_parent_writer(index,quarantined=True)
                        break
                    if step=='close':self._cache_parent_writer(index,quarantined=True)
                else:self._cache_parent_writer(index,**{step+'_returned':True})
                if step=='close':
                    closed=resource['writer'].closed
                    if type(closed) is not bool:
                        self._parent_writer_error(index,'closed_observation',ProducerError('unknown writer closed state'))
                    else:
                        self._cache_parent_writer(index,closed_observed=closed)
                        if not closed:
                            self._cache_parent_writer(index,quarantined=True)
                            self._parent_writer_error(index,'closed_observation',ProducerError('parent writer close was not observed'))
            if self._parent_writer_quarantined:
                for position in range(len(self._parent_writer_rows)):
                    self._cache_parent_writer(position,quarantined=True)
                break
        if self._parent_writer_errors:raise self._parent_writer_errors[0][2]
        return self.parent_writer_observations()

    def seal_parent_writers(self):
        """One failed-pipeline parent writer attempt; never closure/admission."""
        return self._schedule('parent_writer_seal')

    def parent_writer_observations(self):
        with self._lock:return self._parent_writer_rows


    def _capture_known_actors(self,retain):
        # Object/collection observations only; no poll/wait, FD IO or closure authority.
        if threading.current_thread() is not self._thread:
            raise ProducerError('known actor snapshot requires retained worker')
        op=self._operation;owner_callback=self._kwargs.get('lease_check')
        if retain:
            self._known_actor_producer=op;self._known_actor_lease_callback=owner_callback
        def dictionary(obj,kind):
            if type(obj) is not kind:return None
            data=obj.__dict__
            return data if type(data) is dict and all(type(k) is str for k in data) else None
        data=dictionary(op,CommandProducer)
        data={} if data is None else data
        process=data.get('process');records=data.get('records');ledger=data.get('auxiliary_operations')
        current=records[-1] if type(records) is list and records else None
        auxiliaries=tuple(ledger) if type(ledger) is list else ()
        auxiliary_data=tuple(dictionary(a,AuxiliaryCommand) for a in auxiliaries)
        processes=(process,)+tuple(None if d is None else d.get('process') for d in auxiliary_data)
        auxiliary_callbacks=tuple(None if d is None else d.get('lease_check') for d in auxiliary_data)
        binding=(op,data,process,records,current,ledger,owner_callback,data.get('lease_check'))+auxiliaries+auxiliary_data+processes+auxiliary_callbacks
        if retain:
            # Keep the original containers and all available direct handles BEFORE callback IO.
            self._known_actor_auxiliaries=auxiliaries
            self._known_actor_processes=processes
            self._known_actor_binding=binding
        def boolean(d,key):
            value=d.get(key)
            return value if type(value) is bool else None
        def text(d,key):
            value=d.get(key)
            return value if type(value) is str else None
        def direct(proc):
            fields=dictionary(proc,subprocess.Popen)
            if proc is None:return False,None,None,True
            if fields is None:return False,None,None,False
            pid=fields.get('pid');status=fields.get('returncode')
            pid_ok=type(pid) is int and pid>0
            status_ok=status is None or type(status) is int
            return True,pid if pid_ok else None,status if status_ok else None,pid_ok and status_ok and {'pid','returncode'}<=fields.keys()
        origin_initialized,origin=self._known_actor_origin
        origin=origin if type(origin) is dict and all(type(k) is str for k in origin) else {}
        origin_index=origin.get('call_index')
        origin_index=origin_index if type(origin_index) is int and origin_index>0 else None
        owner_initialized=origin_initialized if type(origin_initialized) is bool else None
        ledger_known=type(ledger) is list
        records_known=type(records) is list and all(type(r) is dict for r in records)
        pending=boolean(data,'pending');finished=boolean(data,'finished')
        producer_valid=(type(op) is CommandProducer and {'process','records','auxiliary_operations','lease_check'}<=data.keys()
            and ledger_known and records_known and pending is not None and finished is not None
            and owner_initialized is not None and origin_index is not None
            and callable(owner_callback) and data.get('lease_check') is owner_callback)
        rows=[dict(role='producer',index=-1,owner_initialized=owner_initialized,origin_action=text(origin,'action'),
            origin_call_index=origin_index,origin_call_error=text(origin,'call_error'),
            origin_start_attempted=boolean(origin,'start_attempted'),origin_start_returned=boolean(origin,'start_returned'),
            pending=pending,finished=finished,ledger_known=ledger_known,
            ledger_entries=len(ledger) if ledger_known else None,fields_valid=producer_valid)]
        held,pid,status,process_valid=direct(process)
        recipe_valid=producer_valid and process_valid
        rows.append(dict(role='recipe',index=0,retained_process=held,pid=pid,cached_returncode=status,
            pending=pending,finished=finished,records_known=records_known,
            record_count=len(records) if type(records) is list else None,fields_valid=recipe_valid))
        duplicate=len({id(a) for a in auxiliaries})!=len(auxiliaries)
        valid=producer_valid and recipe_valid and not duplicate
        for index,(aux,d,proc) in enumerate(zip(auxiliaries,auxiliary_data,processes[1:])):
            fields={} if d is None else d
            apending=boolean(fields,'pending');afinished=boolean(fields,'finished');started=boolean(fields,'started')
            held,pid,status,process_valid=direct(proc)
            okay=(d is not None and 'process' in fields and apending is not None
                and afinished is not None and started is not None and process_valid and not duplicate
                and fields.get('lease_check') is owner_callback)
            rows.append(dict(role='auxiliary',index=index,retained_auxiliary=type(aux) is AuxiliaryCommand,
                retained_process=held,pid=pid,cached_returncode=status,started=started,
                pending=apending,finished=afinished,fields_valid=okay))
            valid=valid and okay
        return binding,rows,valid

    def _cache_known_actor_rows(self,rows,stage,checked,quarantined):
        values=[]
        for original in rows:
            row=dict(original,scope='current_recipe_and_retained_auxiliary_object_snapshot_only',
                stage=stage,snapshot_checked=checked,quarantined=quarantined,
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False)
            if any(not any(type(v) is kind for kind in (str,int,bool,type(None))) for v in row.values()):
                raise ProducerError('nonprimitive known actor observation')
            values.append(MappingProxyType(row))
        with self._lock:self._known_actor_rows=tuple(values)

    def _freeze_known_actors(self):
        binding,rows,valid=self._capture_known_actors(True)
        self._cache_known_actor_rows(rows,'retained_before_lease',False,False)
        try:
            callback=self._known_actor_lease_callback
            if not callable(callback):raise ProducerError('unknown retained owner lease callback')
            callback()
            after,after_rows,after_valid=self._capture_known_actors(False)
            if (not valid or not after_valid or len(binding)!=len(after)
                or any(a is not b for a,b in zip(binding,after)) or rows!=after_rows):
                raise ProducerError('known actor fields or identities are unresolved')
        except BaseException:
            self._cache_known_actor_rows(rows,'quarantined',False,True)
            raise
        self._cache_known_actor_rows(rows,'checked',True,False)
        return self._known_actor_rows

    def freeze_known_actors(self):
        """One terminal known-object snapshot; caller retains physical official EX."""
        return self._schedule('actor_inventory')

    def known_actor_observations(self):
        """Historical immutable object facts, never live actor/lease authority."""
        with self._lock:return self._known_actor_rows



    def _check_known_wait_inventory(self):
        if self._known_wait_quarantined:raise ProducerError('known wait inventory is quarantined')
        current,rows,valid=self._capture_known_actors(False)
        original=self._known_actor_binding
        frozen=self._known_actor_rows
        if (not valid or original is None or len(current)!=len(original)
            or any(a is not b for a,b in zip(current,original))
            or len(rows)!=len(frozen)
            or any(a.get('pid')!=b.get('pid') for a,b in zip(rows,frozen))
            or rows[0]['ledger_entries']!=frozen[0]['ledger_entries']
            or rows[1]['record_count']!=frozen[1]['record_count']):
            self._known_wait_quarantined=True
            raise ProducerError('frozen known actor identity or layout changed')

    def _known_stream_initial(self,record,role,state,keys,eof_state,eof_key,path,maximum):
        stream=dict(role=role,state=state,keys=keys,eof_state=eof_state,eof_key=eof_key,path=path,
            log=state.get(keys['log']),hash=state.get(keys['hash']),original_fd=state.get(keys['fd']),
            expected_fd=state.get(keys['fd']),buffer=state.get(keys['buffer']),bytes=state.get(keys['bytes']),
            eof=eof_state.get(eof_key),maximum=maximum,log_fd=None,log_identity=None,read_identity=None,
            write_pending=False,last_return=None,close_attempted=False,close_confirmed=None,last_observed=None)
        record['streams'].append(stream) # Retain available raw handles BEFORE metadata/callback IO.
        if (type(state) is not dict or type(eof_state) is not dict
            or type(stream['log']) is not io.FileIO or type(stream['hash']) is not type(hashlib.sha256())
            or stream['hash'].name!='sha256' or type(stream['buffer']) is not bytes
            or type(stream['bytes']) is not int or stream['bytes']<0 or type(stream['eof']) is not bool
            or type(path) is not type(Path()) or (maximum is not None and (type(maximum) is not int or maximum<=0))
            or (stream['expected_fd'] is None and stream['eof'] is not True)
            or (stream['expected_fd'] is not None and (type(stream['expected_fd']) is not int or stream['expected_fd']<0 or stream['eof']))):
            raise ProducerError('unknown selected stream fields')
        self._parent_writer_raw(stream['log'])
        stream['digest']=stream['hash'].hexdigest()
        return stream

    def _bind_known_wait(self,role,index):
        key=(role,index)
        if key in self._known_wait_bindings:
            record=self._known_wait_bindings[key]
            if record['quarantined'] or record['primary_error'] is not None:
                raise ProducerError('selected known actor privately quarantined')
            return record
        actor=self._known_actor_producer if role=='recipe' else self._known_actor_auxiliaries[index]
        process=self._known_actor_processes[0 if role=='recipe' else index+1]
        frozen=self._known_actor_rows[1 if role=='recipe' else index+2]
        record=dict(role=role,index=index,actor=actor,process=process,pid=frozen['pid'],data=None,
            streams=[],stream_table=None,wait_observed=False,wait_status=None,wait_origin='not_observed',
            primary_error=None,secondary_errors=[],quarantined=False)
        self._known_wait_bindings[key]=record
        self._check_known_wait_inventory()
        if type(process) is not subprocess.Popen or type(record['pid']) is not int:
            raise ProducerError('selected actor has no exact retained process')
        data=actor.__dict__;record['data']=data
        if type(data) is not dict or any(type(k) is not str for k in data):
            raise ProducerError('unknown selected actor fields')
        record['directory']=data.get('directory')
        if type(record['directory']) is not type(Path()):raise ProducerError('unknown selected actor directory')
        if role=='recipe':
            required={'pending','finished','result','records','directory','output_log','log','output_fd','output_hash','output_buffer','output_bytes','output_write_uncertain'}
            if (not required<=data.keys() or data['pending'] is not True or data['finished'] is not False or data['result'] is not None
                or type(data['records']) is not list or not data['records'] or type(data['records'][-1]) is not dict
                or type(data['directory']) is not type(Path()) or data['log'] is not data['output_log']):
                raise ProducerError('unknown nonpending selected recipe')
            source=data['records'][-1];record['source_record']=source
            record['source_record_keys']=tuple(source)
            if any(type(k) is not str for k in source):raise ProducerError('unknown selected recipe record keys')
            read_errors=source.get('output_read_errors')
            if (source.get('parent_output_write_close_confirmed') is not True
                or source.get('output_read_close_error') is not None
                or (read_errors is not None and (type(read_errors) is not list or len(read_errors)!=0))):
                raise ProducerError('selected recipe output ownership/error unresolved')
            keys=dict(log='output_log',hash='output_hash',fd='output_fd',buffer='output_buffer',bytes='output_bytes',uncertain='output_write_uncertain')
            self._known_stream_initial(record,'merged',data,keys,source,'output_eof',
                data['directory']/('command-'+format(len(data['records'])-1,'03')+'.log'),None)
            if (self._partial_command is not None and self._partial_command['process'] is process
                and type(self._command_wait_status) is int):
                record.update(wait_observed=True,wait_status=self._command_wait_status,wait_origin='retained_partial_command_method_witness')
        else:
            if (type(actor) is not AuxiliaryCommand or data.get('started') is not True or data.get('pending') is not True
                or data.get('finished') is not False or data.get('result') is not None):
                raise ProducerError('selected auxiliary is not pending')
            table=data.get('streams');record['stream_table']=table
            if type(table) is not dict or any(type(k) is not str for k in table) or set(table)!=set(('stdout','stderr')):
                raise ProducerError('unknown selected auxiliary streams')
            for name in ('stdout','stderr'):
                state=table[name]
                if (type(state) is not dict or any(type(k) is not str for k in state)
                    or not {'log','hash','fd','buffer','bytes','eof','maximum','path','quarantined','writer','write_close_confirmed'}<=state.keys()
                    or state['writer'] is not None or state['write_close_confirmed'] is not True):
                    raise ProducerError('auxiliary stream writer ownership unresolved')
                keys=dict(log='log',hash='hash',fd='fd',buffer='buffer',bytes='bytes',uncertain='quarantined')
                self._known_stream_initial(record,name,state,keys,state,'eof',state['path'],state['maximum'])
            self._known_aux_wait_witness(record)
        return record

    def _known_aux_wait_witness(self,record):
        data=record['data'];observed=data.get('_natural_wait_observed');status=data.get('_natural_wait_status')
        process=data.get('_natural_wait_process')
        if (type(observed) is not bool or (observed and (type(status) is not int or process is not record['process']))
            or (not observed and (status is not None or (process is not None and process is not record['process'])))):
            raise ProducerError('unknown selected auxiliary direct-wait witness')
        if observed:
            if record['wait_observed'] and record['wait_status']!=status:raise ProducerError('selected auxiliary wait fact changed')
            if not record['wait_observed']:
                record.update(wait_observed=True,wait_status=status,wait_origin='retained_auxiliary_method_witness')

    def _known_wait_guard(self,record,sealed_writers=None):
        if record['quarantined'] or record['primary_error'] is not None:
            raise ProducerError('selected known actor privately quarantined')
        if sealed_writers is not None:
            if (sealed_writers is not self._known_log_lookup or not self._known_log_attempted
                or threading.current_thread() is not self._thread):
                raise ProducerError('unknown frozen log guard context')
        else:
            try:self._known_actor_lease_callback()
            except BaseException:
                self._known_wait_quarantined=True
                raise
        self._check_known_wait_inventory()
        data=record['data']
        if (record['actor'].__dict__ is not data or data.get('process') is not record['process']
            or data.get('directory') is not record['directory']):
            raise ProducerError('selected actor binding changed')
        if record['role']=='auxiliary':
            table=data.get('streams')
            if (table is not record['stream_table'] or type(table) is not dict
                or any(type(k) is not str for k in table) or set(table)!=set(('stdout','stderr'))):
                raise ProducerError('selected auxiliary stream table changed')
            self._known_aux_wait_witness(record)
        import fcntl
        active=[]
        for stream in record['streams']:
            state=stream['state'];keys=stream['keys'];eof_state=stream['eof_state']
            if (type(state) is not dict or type(eof_state) is not dict
                or any(type(k) is not str for k in state) or any(type(k) is not str for k in eof_state)
                or (record['role']=='auxiliary' and record['stream_table'].get(stream['role']) is not state)):
                raise ProducerError('selected stream dictionary changed')
            if record['role']=='auxiliary':
                maximum=state.get('maximum')
                if (state.get('path') is not stream['path'] or type(maximum) is not int or maximum!=stream['maximum']
                    or state.get('writer') is not None or state.get('write_close_confirmed') is not True):
                    raise ProducerError('selected auxiliary path/bound/writer metadata changed')
            observed=(state.get(keys['log']),state.get(keys['hash']),state.get(keys['fd']),
                state.get(keys['buffer']),state.get(keys['bytes']),eof_state.get(stream['eof_key']),state.get(keys['uncertain']))
            stream['last_observed']=observed
            if (observed[0] is not stream['log'] or observed[1] is not stream['hash']
                or type(observed[2]) is not type(stream['expected_fd']) or observed[2]!=stream['expected_fd']
                or observed[3] is not stream['buffer'] or type(observed[4]) is not int or observed[4]!=stream['bytes']
                or type(observed[5]) is not bool or observed[5] is not stream['eof'] or observed[6] is not False
                or stream['hash'].hexdigest()!=stream['digest']):
                raise ProducerError('selected stream progress changed or uncertain')
            closed_log=False
            if sealed_writers is not None:
                resource=sealed_writers.get(id(stream['log']))
                if (resource is None or resource['writer'] is not stream['log']
                    or resource['path'] is not stream['path']):
                    raise ProducerError('unknown frozen stream log binding')
                if resource['closed_expected'] is True:
                    self._known_log_raw(resource)
                    if resource['fd']!=stream['log_fd'] or resource['identity']!=stream['log_identity']:
                        raise ProducerError('closed stream log identity changed')
                    closed_log=True
            if not closed_log:
                self._parent_writer_raw(stream['log'])
                fd=stream['log'].fileno();info=os.fstat(fd);path_info=os.stat(stream['path'],follow_symlinks=False)
                identity=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink)
                if not stat.S_ISREG(info.st_mode) or identity!=(path_info.st_dev,path_info.st_ino,path_info.st_mode,path_info.st_uid,path_info.st_gid,path_info.st_nlink):
                    raise ProducerError('selected log FD/path identity mismatch')
                if stream['log_fd'] is None:stream['log_fd']=fd;stream['log_identity']=identity
                if (fd!=stream['log_fd'] or identity!=stream['log_identity'] or os.get_inheritable(fd) is not False
                    or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_WRONLY):
                    raise ProducerError('selected log identity/direction changed')
            reader=stream['expected_fd']
            if reader is not None:
                info=os.fstat(reader);identity=(info.st_dev,info.st_ino,info.st_mode)
                if (not stat.S_ISFIFO(info.st_mode) or os.get_inheritable(reader) is not False
                    or os.get_blocking(reader) is not False or fcntl.fcntl(reader,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_RDONLY):
                    raise ProducerError('selected read FD kind/direction changed')
                if stream['read_identity'] is None:stream['read_identity']=identity
                if identity!=stream['read_identity']:raise ProducerError('selected read FD identity changed')
                active.append(reader)
        if len(set(active))!=len(active):raise ProducerError('selected read FDs alias')

    def _known_stream_read(self,stream):
        return os.read(stream['expected_fd'],65536)

    def _known_stream_write(self,stream,data):
        return io.FileIO.write(stream['log'],data)

    def _known_stream_close(self,stream):
        os.close(stream['original_fd'])

    def _known_stream_progress(self,stream,**updates):
        stream.update(updates)
        state=stream['state'];keys=stream['keys']
        if 'buffer' in updates:state[keys['buffer']]=stream['buffer']
        if 'bytes' in updates:state[keys['bytes']]=stream['bytes']
        if 'expected_fd' in updates:state[keys['fd']]=stream['expected_fd']
        if 'eof' in updates:stream['eof_state'][stream['eof_key']]=stream['eof']

    def _cache_known_wait(self,record,stage):
        streams=record['streams'];byrole={s['role']:s for s in streams}
        error=record['primary_error'];error_type=None if error is None else type.__getattribute__(type(error),'__name__')
        buffers=sum(len(s['buffer']) for s in streams) if streams and all(type(s['buffer']) is bytes for s in streams) else None
        eof=bool(streams) and all(s['eof'] is True for s in streams)
        quarantined=record['quarantined'] or self._known_wait_quarantined
        row=dict(scope='selected_known_actor_wait_only',role=record['role'],index=record['index'],pid=record['pid'],
            stage=stage,wait_method_observed=record['wait_observed'],direct_status=record['wait_status'],
            wait_origin=record['wait_origin'],output_eof=byrole['merged']['eof'] if 'merged' in byrole else None,
            stdout_eof=byrole['stdout']['eof'] if 'stdout' in byrole else None,stderr_eof=byrole['stderr']['eof'] if 'stderr' in byrole else None,
            buffered_bytes=buffers,stream_bytes=sum(s['bytes'] for s in streams) if streams and all(type(s['bytes']) is int for s in streams) else None,
            terminal_observed=record['wait_observed'] and eof and buffers==0 and not quarantined,
            quarantined=quarantined,error_type=error_type,
            read_close_confirmed=byrole['merged']['close_confirmed'] if 'merged' in byrole else None,
            stdout_read_close_confirmed=byrole['stdout']['close_confirmed'] if 'stdout' in byrole else None,
            stderr_read_close_confirmed=byrole['stderr']['close_confirmed'] if 'stderr' in byrole else None,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False)
        if any(not any(type(v) is kind for kind in (str,int,bool,type(None))) for v in row.values()):
            raise ProducerError('nonprimitive selected wait observation')
        with self._lock:self._known_wait_rows[(record['role'],record['index'])]=MappingProxyType(row)
        return self._known_wait_rows[(record['role'],record['index'])]

    def _wait_known_streams(self,role,index,timeout):
        record=None
        try:
            record=self._bind_known_wait(role,index)
            self._cache_known_wait(record,'before_wait')
            deadline=time.monotonic()+timeout
            while True:
                progressed=False
                for stream in record['streams']:
                    if stream['buffer']:
                        self._known_wait_guard(record)
                        if stream['maximum'] is not None and stream['bytes']+len(stream['buffer'])>stream['maximum']:
                            raise ProducerError('selected stream exceeds declared bound')
                        stream['write_pending']=True
                        try:
                            count=self._known_stream_write(stream,stream['buffer']);stream['last_return']=count
                            if type(count) is not int or not 0<count<=len(stream['buffer']):
                                raise ProducerError('selected output write count uncertain')
                            stream['hash'].update(stream['buffer'][:count])
                            self._known_stream_progress(stream,bytes=stream['bytes']+count,buffer=stream['buffer'][count:])
                            stream['digest']=stream['hash'].hexdigest();stream['write_pending']=False
                        except BaseException:
                            stream['state'][stream['keys']['uncertain']]=True
                            raise
                        progressed=True
                    elif not stream['eof']:
                        self._known_wait_guard(record)
                        try:part=self._known_stream_read(stream);stream['last_return']=part
                        except (BlockingIOError,InterruptedError):continue
                        if type(part) is not bytes or len(part)>65536:raise ProducerError('unknown selected read return')
                        if part:self._known_stream_progress(stream,buffer=part)
                        else:
                            self._known_wait_guard(record)
                            stream['close_attempted']=True;stream['close_confirmed']=False
                            self._known_stream_progress(stream,eof=True,expected_fd=None)
                            self._known_stream_close(stream);stream['close_confirmed']=True
                        progressed=True
                if all(s['eof'] and not s['buffer'] for s in record['streams']):break
                remaining=deadline-time.monotonic()
                if remaining<=0:break
                if not progressed:
                    self._known_wait_guard(record)
                    readers=[s['expected_fd'] for s in record['streams'] if s['expected_fd'] is not None]
                    if readers:select.select(readers,[],[],min(remaining,.05))
            self._known_wait_guard(record)
            if not record['wait_observed']:
                try:
                    if role=='recipe':status=record['process'].wait(timeout=max(0,deadline-time.monotonic()))
                    else:status=record['actor']._wait_natural_status(max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:pass
                else:
                    if type(status) is not int:raise ProducerError('unknown selected direct wait status')
                    record.update(wait_observed=True,wait_status=status,wait_origin='new_direct_method_return')
            return self._cache_known_wait(record,'after_wait')
        except BaseException as error:
            if record is None:record=self._known_wait_bindings.get((role,index))
            if record is not None:
                if record['primary_error'] is None:record['primary_error']=error
                else:record['secondary_errors'].append(error)
                record['quarantined']=True
                try:self._cache_known_wait(record,'after_wait_error')
                except BaseException as secondary:
                    record['secondary_errors'].append(secondary)
                    with self._lock:
                        current=self._workers[-1]
                        current['known_wait_observation_error']=type.__getattribute__(type(secondary),'__name__')
                        current['_known_wait_observation_error_object']=secondary
            raise

    def continue_known_actor_wait(self,role,index,timeout):
        if type(role) is not str or role not in ('recipe','auxiliary') or type(index) is not int or index<0 or (role=='recipe' and index!=0):
            raise ProducerError('invalid selected actor role/index')
        timeout=_preflight_timeout(timeout)
        with self._lock:
            if role=='auxiliary' and index>=len(self._known_actor_auxiliaries):raise ProducerError('unknown auxiliary index')
        return self._schedule('known_stream_wait',(role,index,timeout))

    def known_actor_wait_observations(self):
        with self._lock:return tuple(self._known_wait_rows[key] for key in sorted(self._known_wait_rows))



    def _known_log_raw(self,resource):
        writer=resource['writer']
        if type(writer) is io.FileIO:raw=writer
        elif type(writer) is io.BufferedWriter:raw=writer.raw
        else:raise ProducerError('unknown frozen log writer')
        if type(raw) is not io.FileIO or raw.closefd is not True:
            raise ProducerError('borrowed or unknown frozen log FD')
        forbidden={'flush','close','fileno','write','read','readinto','seek','tell',
            'writable','readable','seekable','raw','closed','closefd','detach'}
        for item in ((writer,) if raw is writer else (writer,raw)):
            keys=tuple(item.__dict__)
            if any(type(k) is not str for k in keys) or any(k in forbidden for k in keys):
                raise ProducerError('frozen log has shadowed IO methods')
        if resource['raw'] is None:resource['raw']=raw
        if raw is not resource['raw']:raise ProducerError('frozen log raw object changed')
        expected=resource['closed_expected']
        if type(expected) is not bool or writer.closed is not expected or raw.closed is not expected:
            raise ProducerError('frozen log closed state changed')
        return raw

    def _known_log_validate(self,resource):
        raw=self._known_log_raw(resource)
        path_info=resource['path'].lstat()
        identity=lambda item:(item.st_dev,item.st_ino,item.st_mode,item.st_uid,item.st_gid,item.st_nlink)
        if resource['closed_expected']:
            if identity(path_info)!=resource['identity']:
                raise ProducerError('closed frozen log path changed')
            return
        import fcntl
        fd=io.FileIO.fileno(raw);info=os.fstat(fd);current=identity(info)
        if (type(fd) is not int or fd<0 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1
            or current!=identity(path_info) or os.get_inheritable(fd) is not False
            or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_WRONLY):
            raise ProducerError('frozen log FD/path/direction changed')
        if resource['fd'] is None:resource['fd']=fd;resource['identity']=current
        if fd!=resource['fd'] or current!=resource['identity']:
            raise ProducerError('frozen log identity changed')

    def _known_log_guard(self):
        if threading.current_thread() is not self._thread or self._known_log_quarantined:
            raise ProducerError('frozen log worker unavailable or quarantined')
        self._known_actor_lease_callback()
        self._check_known_wait_inventory()
        keys=(('recipe',0),)+tuple(('auxiliary',i) for i in range(len(self._known_actor_auxiliaries)))
        bindings=self._known_wait_bindings
        if (type(bindings) is not dict or any(type(k) is not tuple or len(k)!=2
            or type(k[0]) is not str or type(k[1]) is not int for k in bindings)
            or set(bindings)!=set(keys) or len(self._known_log_actor_records)!=len(keys)
            or any(bindings[k] is not row for k,row in zip(keys,self._known_log_actor_records))):
            raise ProducerError('frozen waited actor layout changed')
        if len(self._known_log_stream_groups)!=len(keys):
            raise ProducerError('frozen private stream groups changed')
        for key,record,group in zip(keys,self._known_log_actor_records,self._known_log_stream_groups):
            container,streams=group
            roles=('merged',) if key[0]=='recipe' else ('stdout','stderr')
            if (type(record.get('role')) is not str or record['role']!=key[0]
                or type(record.get('index')) is not int or record['index']!=key[1]
                or type(record.get('streams')) is not list or record['streams'] is not container
                or len(container)!=len(streams) or len(streams)!=len(roles)
                or any(a is not b for a,b in zip(container,streams))
                or any(type(stream.get('role')) is not str for stream in streams)
                or tuple(stream['role'] for stream in streams)!=roles):
                raise ProducerError('frozen private stream layout changed')
            data=record['data'];process=record['process']
            if (record['quarantined'] or record['primary_error'] is not None or record['wait_observed'] is not True
                or type(record['wait_status']) is not int or type(process) is not subprocess.Popen
                or type(process.__dict__.get('returncode')) is not int
                or process.__dict__['returncode']!=record['wait_status']
                or type(data) is not dict or any(type(k) is not str for k in data)
                or data.get('pending') is not True or data.get('finished') is not False or data.get('result') is not None):
                raise ProducerError('frozen actor lacks a checked terminal wait')
            if record['role']=='recipe':
                source=record['source_record']
                if type(source) is not dict or any(type(k) is not str for k in source):
                    raise ProducerError('unknown frozen recipe record keys')
                errors=source.get('output_read_errors')
                if (tuple(source)!=record['source_record_keys']
                    or data.get('log') is not data.get('output_log')
                    or source.get('parent_output_write_close_confirmed') is not True
                    or source.get('output_read_close_error') is not None
                    or (errors is not None and (type(errors) is not list or errors))):
                    raise ProducerError('frozen recipe stream metadata changed')
            for stream in record['streams']:
                if (stream['eof'] is not True or stream['expected_fd'] is not None
                    or type(stream['buffer']) is not bytes or stream['buffer']
                    or stream['close_confirmed'] is not True or stream['write_pending'] is not False):
                    raise ProducerError('frozen read stream closure unresolved')
            self._known_wait_guard(record,self._known_log_lookup)
        data=self._known_actor_producer.__dict__
        if data.get('events') is not self._known_log_writers[-1]['writer']:
            raise ProducerError('frozen journal object changed')
        for resource in self._known_log_writers:self._known_log_validate(resource)
        raws=[id(r['raw']) for r in self._known_log_writers]
        fds=[r['fd'] for r in self._known_log_writers]
        files=[r['identity'][:2] for r in self._known_log_writers]
        if len(set(raws))!=len(raws) or len(set(fds))!=len(fds) or len(set(files))!=len(files):
            raise ProducerError('frozen log writers alias')

    def _cache_known_logs(self,stage):
        rows=[]
        for resource in self._known_log_writers:
            error=resource['first_error']
            error_type=None if error is None else type.__getattribute__(type(error),'__name__')
            row=dict(scope='frozen_known_log_object_facts_only',role=resource['role'],
                index=resource['index'],stream=resource['stream'],stage=stage,
                namespace_reserved=self._known_log_namespace_reserved,
                flush_attempted=resource['flush_attempted'],flush_returned=resource['flush_returned'],
                fsync_attempted=resource['fsync_attempted'],fsync_returned=resource['fsync_returned'],
                close_attempted=resource['close_attempted'],close_returned=resource['close_returned'],
                closed_observed=resource['closed_observed'],quarantined=self._known_log_quarantined,
                error_type=error_type,actor_ownership_complete=None,
                capture_ready=False,source_admitted=False,live_admission=False)
            if any(not any(type(v) is kind for kind in (str,int,bool,type(None))) for v in row.values()):
                raise ProducerError('nonprimitive frozen log observation')
            rows.append(MappingProxyType(row))
        with self._lock:self._known_log_rows=tuple(rows)

    def _known_log_error(self,index,stage,error):
        self._known_log_errors.append((index,stage,error))
        if index is not None:
            resource=self._known_log_writers[index]
            if resource['first_error'] is None:resource['first_error']=error

    def _known_log_io(self,index,step):
        resource=self._known_log_writers[index];writer=resource['writer']
        if step=='flush':
            return io.FileIO.flush(writer) if type(writer) is io.FileIO else io.BufferedWriter.flush(writer)
        if step=='fsync':return os.fsync(resource['fd'])
        if step=='close':
            return io.FileIO.close(writer) if type(writer) is io.FileIO else io.BufferedWriter.close(writer)
        raise ProducerError('unknown frozen log step')

    def _seal_known_logs(self):
        index=None;stage='prepare'
        try:
            if threading.current_thread() is not self._thread:
                raise ProducerError('frozen log sealing requires retained worker')
            keys=(('recipe',0),)+tuple(('auxiliary',i) for i in range(len(self._known_actor_auxiliaries)))
            bindings=self._known_wait_bindings
            if (type(bindings) is not dict or any(type(k) is not tuple or len(k)!=2
                or type(k[0]) is not str or type(k[1]) is not int for k in bindings) or set(bindings)!=set(keys)):
                raise ProducerError('every frozen actor needs a retained selected wait')
            self._known_log_actor_records=tuple(bindings[k] for k in keys)
            if any(type(row) is not dict or type(row.get('streams')) is not list
                or any(type(stream) is not dict for stream in row['streams']) for row in self._known_log_actor_records):
                raise ProducerError('unknown frozen private stream records')
            self._known_log_stream_groups=tuple((row['streams'],tuple(row['streams']))
                for row in self._known_log_actor_records)
            resources=[]
            def retain(role,number,name,writer,path):
                resources.append(dict(role=role,index=number,stream=name,writer=writer,path=path,
                    raw=None,fd=None,identity=None,closed_expected=False,first_error=None,
                    flush_attempted=False,flush_returned=None,fsync_attempted=False,fsync_returned=None,
                    close_attempted=False,close_returned=None,closed_observed=None))
            for record in self._known_log_actor_records:
                for stream in record['streams']:
                    retain(record['role'],record['index'],stream['role'],stream['log'],stream['path'])
            op=self._known_actor_producer;data=op.__dict__;directory=data.get('directory')
            retain('producer',-1,'journal',data.get('events'),
                directory/'journal.jsonl' if type(directory) is type(Path()) else None)
            self._known_log_writers=tuple(resources) # ALL available writer handles BEFORE callback/fstat.
            self._known_log_lookup={id(r['writer']):r for r in resources}
            if len(self._known_log_lookup)!=len(resources):raise ProducerError('frozen writer objects alias')
            self._known_actor_lease_callback()
            declared=self._kwargs.get('run_dir')
            if type(declared) not in (str,type(Path())):raise ProducerError('unknown frozen log run directory')
            declared=Path(declared)
            if (type(directory) is not type(Path()) or declared!=directory
                or declared.resolve(strict=True)!=declared):
                raise ProducerError('frozen log run directory changed')
            (declared/'owned-known-logs').mkdir(mode=0o700)
            self._known_log_namespace_reserved=True
            self._cache_known_logs('reserved')
            self._known_log_guard() # Validate ALL writers before first explicit flush.
            self._cache_known_logs('validated')
            for index,resource in enumerate(self._known_log_writers):
                for step in ('flush','fsync','close'):
                    stage=step
                    self._known_log_guard()
                    resource[step+'_attempted']=True
                    self._cache_known_logs(step+'_before')
                    # Cache publication is fallible too; revalidate after it and before native IO.
                    self._known_log_guard()
                    failure=None
                    try:self._known_log_io(index,step)
                    except BaseException as error:
                        resource[step+'_returned']=False;failure=error
                        self._known_log_error(index,step,error)
                    else:resource[step+'_returned']=True
                    if step=='close':
                        closed=resource['writer'].closed;raw_closed=resource['raw'].closed
                        resource['closed_observed']=closed if type(closed) is bool else None
                        if failure is None:
                            if closed is not True or raw_closed is not True:
                                raise ProducerError('frozen log close did not close both exact objects')
                            resource['closed_expected']=True
                    if failure is not None and step!='fsync':raise failure
                    self._cache_known_logs(step+'_after')
                if self._known_log_errors:raise self._known_log_errors[0][2]
            self._known_log_guard()
            self._cache_known_logs('sealed')
            return self.known_log_observations()
        except BaseException as error:
            if not self._known_log_errors or self._known_log_errors[-1][2] is not error:
                self._known_log_error(index,stage,error)
            self._known_log_quarantined=True
            try:self._cache_known_logs('failed')
            except BaseException as secondary:self._known_log_error(None,'observation',secondary)
            raise self._known_log_errors[0][2]

    def seal_known_actor_logs(self):
        return self._schedule('known_log_seal')

    def known_log_observations(self):
        with self._lock:return self._known_log_rows

    def continue_auxiliary_wait(self,index,timeout):
        if type(index) is not int or index<0:raise ProducerError('nonnegative auxiliary index required')
        return self._schedule('auxiliary_wait',(index,_preflight_timeout(timeout)))

    def continue_wait(self,timeout):
        return self._schedule('wait',_preflight_timeout(timeout))

    def emit(self,phase):
        if phase not in ('canonical','execution'):raise ProducerError('valid receipt phase required')
        if (self.kind=='canonical' and phase!='canonical') or (self.kind=='production' and phase!='execution'):
            raise ProducerError('receipt phase differs from fixed preflight factory')
        return self._schedule('emit',phase)

    def _history_failure(self,error):
        self._history_quarantined=True
        if self._history_primary_error is None:self._history_primary_error=error
        else:self._history_secondary_errors.append(error)

    def _capture_command_history(self,retain):
        # References/scalars only: never inspect retired FD numbers or poll/wait.
        op=self._operation
        if retain:self._history_producer=op
        binding=[]
        if retain:self._history_binding=binding
        else:self._history_check_binding=binding
        seen=set();bad=False
        def hold(value,deep=False):
            nonlocal bad
            if retain:self._history_capture_current=value
            binding.append(value)
            kind=type(value)
            if not deep or (kind is not dict and kind is not list and kind is not tuple):return
            ident=id(value)
            if ident in seen:return
            seen.add(ident)
            if kind is dict:
                pairs=tuple(dict.items(value))
                for key,item in pairs:
                    hold(key)
                    if type(key) is not str:bad=True
                    hold(item,True)
            else:
                for item in value:hold(item,True)
        def dictionary(obj,kind,deep=False):
            nonlocal bad
            hold(obj)
            if type(obj) is not kind:bad=True;return None
            data=object.__getattribute__(obj,'__dict__')
            hold(data,deep)
            if type(data) is not dict:bad=True;return None
            pairs=tuple(dict.items(data))
            for key,value in pairs:
                if not deep:hold(key);hold(value)
                if type(key) is not str:bad=True
            if any(type(key) is not str for key,value in pairs):return None
            return data
        def primitive(value,kind,nullable=False):
            return (nullable and value is None) or type(value) is kind
        def process(proc):
            if proc is None:return False,None,None,True
            data=dictionary(proc,_COMMAND_POPEN_TYPE)
            if data is None:return False,None,None,False
            pid=data.get('pid');status=data.get('returncode')
            okay=type(pid) is int and pid>0 and 'returncode' in data and primitive(status,int,True)
            return True,pid if type(pid) is int else None,status if primitive(status,int,True) else None,okay
        hold(op)
        if threading.current_thread() is not self._thread:
            raise ProducerError('command history capture requires retained worker')
        owner_callback=self._kwargs.get('lease_check');hold(owner_callback)
        if retain:self._history_callback=owner_callback
        fields=dictionary(op,CommandProducer)
        data={} if fields is None else fields
        history=data.get('_command_attempts');current=data.get('_command_attempt')
        records=data.get('records');ledger=data.get('auxiliary_operations')
        hold(history,True);hold(current,True);hold(records,True);hold(ledger)
        attempts=tuple(history) if type(history) is list else ()
        auxiliaries=tuple(ledger) if type(ledger) is list else ()
        if retain:
            self._history_attempt_refs=attempts;self._history_current_attempt=current
            self._history_auxiliary_refs=auxiliaries
        # Each attempt/current/auxiliary root is retained before any callback.
        extra=() if current is None or any(item is current for item in attempts) else (current,)
        all_attempts=attempts+extra
        for item in all_attempts:hold(item,True)
        auxiliary_fields=tuple(dictionary(aux,AuxiliaryCommand,True) for aux in auxiliaries)
        current_process=data.get('process');hold(current_process)
        current_direct=process(current_process)
        callback_ok=callable(owner_callback) and data.get('lease_check') is owner_callback
        valid=(fields is not None and type(history) is list and '_command_attempt' in data
            and type(records) is list and type(ledger) is list
            and type(data.get('pending')) is bool and type(data.get('finished')) is bool
            and callback_ok and current_direct[3] and not extra
            and len({id(item) for item in attempts})==len(attempts)
            and len({id(aux) for aux in auxiliaries})==len(auxiliaries))
        current_native=type(current) is dict and all(type(key) is str for key in current)
        layout_ok=(not attempts and current is None and type(records) is list and not records)
        if current_native and type(records) is list and records and attempts:
            layout_ok=(current is attempts[-1] and current.get('process') is current_process
                and current.get('record') is records[-1] and len(records)==len(attempts))
        valid=valid and layout_ok
        rows=[dict(role='producer',index=-1,history_known=type(history) is list,
            history_entries=len(attempts) if type(history) is list else None,
            current_outside_history=bool(extra),auxiliary_known=type(ledger) is list,
            auxiliary_entries=len(auxiliaries) if type(ledger) is list else None,
            pending=data.get('pending') if type(data.get('pending')) is bool else None,
            finished=data.get('finished') if type(data.get('finished')) is bool else None,
            retained_current_process=current_direct[0],current_pid=current_direct[1],
            current_cached_returncode=current_direct[2],fields_valid=valid)]
        required={'index','argv','kind','tool','record','log','reader_fd','writer_fd',
            'pipe_attempted','pipe_returned','popen_attempted','popen_returned','process',
            'parent_writer_close_attempted','parent_writer_close_returned','cleanup_close_attempts',
            'stage','first_error','error_stage','wait_process','wait_status','wait_observed',
            'raw_wait_return','wait_uncertain','wait_timeouts','allocation_class','allocation_new','allocation_init',
            'allocated_process','allocation_attempted','allocation_returned','initializer_attempted',
            'initializer_returned','initializer_result','initializer_result_valid','allocation_arguments'}
        for ordinal,attempt in enumerate(all_attempts):
            native=(type(attempt) is dict and all(type(key) is str for key in attempt))
            record={} if not native else attempt
            keys=set(record) if native else set()
            child=record.get('process');held,pid,cached,child_ok=process(child)
            allocated=record.get('allocated_process');allocated_held,allocated_pid,allocated_cached,allocated_ok=process(allocated)
            public=record.get('record')
            public_native=type(public) is dict and all(type(key) is str for key in public)
            cached_record=None if not public_native else public.get('returncode')
            observed=record.get('wait_observed');status=record.get('wait_status')
            raw=record.get('raw_wait_return');wait_process=record.get('wait_process')
            scalars=(primitive(record.get('index'),int) and record.get('index')==ordinal
                and type(record.get('argv')) is tuple and all(type(arg) is str for arg in record['argv'])
                and type(record.get('kind')) is str and primitive(record.get('tool'),str,True)
                and type(record.get('stage')) is str and primitive(record.get('error_stage'),str,True)
                and type(record.get('wait_timeouts')) is int and record['wait_timeouts']>=0
                and type(observed) is bool and primitive(status,int,True)
                and type(record.get('wait_uncertain')) is bool
                and type(record.get('cleanup_close_attempts')) is list
                and all(type(record.get(key)) is bool for key in
                    ('pipe_attempted','popen_attempted','parent_writer_close_attempted'))
                and all(primitive(record.get(key),bool,True) for key in
                    ('pipe_returned','popen_returned','parent_writer_close_returned'))
                and all(primitive(record.get(key),int,True) for key in ('reader_fd','writer_fd')))
            wait_ok=((observed is False and status is None)
                or (observed is True and type(status) is int and type(raw) is int and status==raw
                    and wait_process is child and type(cached) is int and cached==status))
            public_ok=(public is None or (public_native and 'returncode' in public
                and primitive(cached_record,int,True)))
            if public is not None:
                public_ok=public_ok and type(records) is list and ordinal<len(records) and public is records[ordinal]
            if observed is True and cached_record is not None:
                wait_ok=wait_ok and type(cached_record) is int and type(status) is int and cached_record==status
            start_unknown=record.get('popen_attempted') is True and record.get('popen_returned') is not True
            returned_ok=(record.get('popen_returned') is not True or held)
            refs=(record.get('allocation_class'),record.get('allocation_new'),record.get('allocation_init'))
            refs_ok=(all(value is None for value in refs) or
                (refs[0] is _COMMAND_POPEN_TYPE and refs[1] is _COMMAND_POPEN_NEW and refs[2] is _COMMAND_POPEN_INIT))
            arguments=record.get('allocation_arguments')
            arguments_known=(type(arguments) is tuple and len(arguments)==7
                and type(arguments[0]) is list and all(type(arg) is str for arg in arguments[0])
                and type(record.get('argv')) is tuple and all(type(arg) is str for arg in record['argv'])
                and tuple(arguments[0])==record['argv'] and arguments[1] is data.get('repo')
                and type(arguments[2]) is int and arguments[2]==subprocess.DEVNULL
                and type(arguments[3]) is int and type(record.get('writer_fd')) is int and arguments[3]==record['writer_fd']
                and type(arguments[4]) is int and arguments[4]==subprocess.STDOUT
                and arguments[5] is True and arguments[6] is data.get('environment'))
            allocation_ok=(refs_ok and type(record.get('allocation_attempted')) is bool
                and primitive(record.get('allocation_returned'),bool,True)
                and type(record.get('initializer_attempted')) is bool
                and primitive(record.get('initializer_returned'),bool,True)
                and primitive(record.get('initializer_result_valid'),bool,True)
                and (arguments is None or arguments_known))
            if record.get('allocation_returned') is True:
                allocation_ok=allocation_ok and record.get('allocation_attempted') is True and allocated_held and allocated_ok and arguments_known
            else:allocation_ok=allocation_ok and allocated is None
            if record.get('initializer_attempted') is True:
                allocation_ok=allocation_ok and record.get('allocation_returned') is True
            if record.get('initializer_returned') is True:
                allocation_ok=allocation_ok and record.get('initializer_attempted') is True and (record.get('initializer_result_valid') is (record.get('initializer_result') is None))
            if record.get('popen_returned') is True:
                allocation_ok=allocation_ok and record.get('initializer_returned') is True and record.get('initializer_result_valid') is True and child is allocated
            okay=(native and keys==required and scalars and wait_ok and public_ok
                and child_ok and allocated_ok and allocation_ok and returned_ok and not start_unknown and ordinal<len(attempts))
            valid=valid and okay
            rows.append(dict(role='command',index=ordinal,current=attempt is current,
                outside_history=ordinal>=len(attempts),retained_process=held,pid=pid,
                retained_allocated_process=allocated_held,allocated_pid=allocated_pid,allocated_cached_returncode=allocated_cached,
                allocation_attempted=record.get('allocation_attempted') if type(record.get('allocation_attempted')) is bool else None,
                allocation_returned=record.get('allocation_returned') if primitive(record.get('allocation_returned'),bool,True) else None,
                initializer_attempted=record.get('initializer_attempted') if type(record.get('initializer_attempted')) is bool else None,
                initializer_returned=record.get('initializer_returned') if primitive(record.get('initializer_returned'),bool,True) else None,
                initializer_result_valid=record.get('initializer_result_valid') if primitive(record.get('initializer_result_valid'),bool,True) else None,
                cached_returncode=cached,record_cached_returncode=cached_record if primitive(cached_record,int,True) else None,
                method_wait_observed=observed if type(observed) is bool else None,
                method_wait_status=status if primitive(status,int,True) else None,
                wait_uncertain=record.get('wait_uncertain') if type(record.get('wait_uncertain')) is bool else None,
                popen_attempted=record.get('popen_attempted') if type(record.get('popen_attempted')) is bool else None,
                popen_returned=record.get('popen_returned') if primitive(record.get('popen_returned'),bool,True) else None,
                start_outcome_unknown=start_unknown,retained_log=record.get('log') is not None,
                stage=record.get('stage') if type(record.get('stage')) is str else None,fields_valid=okay))
        for index,(aux,aux_data) in enumerate(zip(auxiliaries,auxiliary_fields)):
            values={} if aux_data is None else aux_data
            held,pid,cached,child_ok=process(values.get('process'))
            allocation=values.get('_process_allocation');allocation_binding=values.get('_process_allocation_binding')
            native=(type(allocation) is dict and all(type(key) is str for key in allocation))
            record=allocation if native else {}
            allocated=values.get('_allocated_process');allocated_held,allocated_pid,allocated_cached,allocated_ok=process(allocated)
            original=(type(allocation_binding) is tuple and len(allocation_binding)==2 and allocation_binding[0] is allocation
                and type(allocation_binding[1]) is list and allocation_binding[1] is values.get('_allocation_secondary_errors'))
            arguments=record.get('arguments')
            arguments_ok=(arguments is None or (type(arguments) is tuple and len(arguments)==7
                and type(arguments[0]) is list and all(type(arg) is str for arg in arguments[0])
                and type(values.get('argv')) is tuple and all(type(arg) is str for arg in values['argv'])
                and tuple(arguments[0])==values['argv'] and arguments[1] is values.get('cwd')
                and type(arguments[2]) is dict and all(type(key) is str and type(value) is str for key,value in dict.items(arguments[2]))
                and type(arguments[3]) is int and arguments[3]==subprocess.DEVNULL
                and type(arguments[4]) is int and type(arguments[5]) is int and arguments[4]!=arguments[5]
                and arguments[6] is True))
            required={'reserved','stage','original_class','original_new','original_init','arguments',
                'constructor_attempted','constructor_returned','allocation_attempted','allocation_returned',
                'allocated_process','initializer_attempted','initializer_returned','initializer_result',
                'initializer_result_valid','first_error','error_stage'}
            allocation_ok=(native and set(record)==required and original and type(record.get('reserved')) is bool
                and type(record.get('stage')) is str and primitive(record.get('error_stage'),str,True)
                and all(type(record.get(key)) is bool for key in ('constructor_attempted','allocation_attempted','initializer_attempted'))
                and all(primitive(record.get(key),bool,True) for key in ('constructor_returned','allocation_returned','initializer_returned','initializer_result_valid'))
                and arguments is values.get('_process_allocation_arguments') and arguments_ok
                and record.get('allocated_process') is allocated and allocated_ok)
            refs=(record.get('original_class'),record.get('original_new'),record.get('original_init'))
            allocation_ok=allocation_ok and (all(value is None for value in refs) or
                (refs[0] is _COMMAND_POPEN_TYPE and refs[1] is _COMMAND_POPEN_NEW and refs[2] is _COMMAND_POPEN_INIT))
            if record.get('constructor_attempted') is True:
                allocation_ok=allocation_ok and record.get('reserved') is True and arguments is not None and all(value is not None for value in refs)
            if record.get('allocation_returned') is True:
                allocation_ok=allocation_ok and record.get('allocation_attempted') is True and record.get('constructor_attempted') is True and allocated_held and arguments is not None
            else:allocation_ok=allocation_ok and allocated is None
            if record.get('initializer_attempted') is True:
                allocation_ok=allocation_ok and record.get('allocation_returned') is True
            if record.get('initializer_returned') is True:
                allocation_ok=allocation_ok and record.get('initializer_attempted') is True and (record.get('initializer_result_valid') is (record.get('initializer_result') is None))
            if record.get('constructor_returned') is True:
                allocation_ok=allocation_ok and record.get('reserved') is True and record.get('constructor_attempted') is True and record.get('initializer_returned') is True and record.get('initializer_result_valid') is True and allocated is values.get('process')
            quarantine=values.get('_constructor_quarantine');quarantine_binding=values.get('_constructor_quarantine_binding')
            hold(quarantine,True);hold(quarantine_binding)
            qnative=(type(quarantine) is dict and all(type(key) is str for key in quarantine))
            q=quarantine if qnative else {}
            qkeys={'attempted','returned','quarantined','first_error','secondary_errors','streams','allocated_process','allocation_binding'}
            qoriginal=(type(quarantine_binding) is tuple and len(quarantine_binding)==7
                and quarantine_binding[0] is quarantine and quarantine_binding[1] is allocation_binding
                and quarantine_binding[2] is values.get('streams')
                and quarantine_binding[5] is owner_callback
                and type(quarantine_binding[6]) is list and quarantine_binding[6] is values.get('_constructor_secondary_errors'))
            qokay=(qnative and set(q)==qkeys and qoriginal and type(q.get('attempted')) is bool
                and primitive(q.get('returned'),bool,True) and type(q.get('quarantined')) is bool
                and q.get('quarantined') is values.get('_constructor_quarantined')
                and q.get('first_error') is values.get('_constructor_primary_error')
                and q.get('secondary_errors') is values.get('_constructor_secondary_errors')
                and q.get('allocation_binding') is allocation_binding
                and q.get('allocated_process') is allocated and type(q.get('streams')) is tuple)
            constructor_quarantined=q.get('quarantined') is True or values.get('_constructor_primary_error') is not None
            start_unknown=(record.get('constructor_attempted') is True and record.get('constructor_returned') is not True
                or q.get('attempted') is True and q.get('returned') is not True or constructor_quarantined)
            close_state=values.get('_creator_close_state');close_journal=values.get('_creator_close_journal')
            close_binding=values.get('_creator_close_binding')
            close_native=type(close_state) is dict and all(type(key) is str for key in close_state)
            cs=close_state if close_native else {}
            close_original=(type(close_binding) is tuple and len(close_binding)==4
                and close_binding[0] is close_state and close_binding[1] is close_journal
                and close_binding[2] is quarantine_binding
                and type(close_binding[3]) is list and close_binding[3] is values.get('_creator_close_secondary_errors'))
            close_ok=(close_native and set(cs)=={'first_error','quarantined','current'} and close_original
                and type(close_journal) is list and type(cs.get('quarantined')) is bool
                and cs.get('quarantined') is values.get('_creator_close_quarantined')
                and cs.get('first_error') is values.get('_creator_close_primary_error') and cs.get('first_error') is None)
            close_quarantined=(values.get('_creator_close_primary_error') is not None
                or cs.get('first_error') is not None
                or values.get('_creator_close_quarantined') is not False or cs.get('quarantined') is not False)
            close_required={'role','slot','fd','stream','log','process','attempted','returned','raw_return','result_valid','completed','error'}
            if type(close_journal) is list:
                for item in close_journal:
                    native=type(item) is dict and all(type(key) is str for key in item)
                    cr=item if native else {}
                    scalar=(native and set(cr)==close_required and type(cr.get('role')) is str
                        and cr['role'] in ('stdout','stderr') and type(cr.get('slot')) is str
                        and cr['slot'] in ('fd','writer') and cr.get('completed') is True
                        and cr.get('error') is None and cr.get('process') is allocated)
                    if scalar and type(quarantine_binding) is tuple and len(quarantine_binding)==7:
                        scalar=cr['stream'] is quarantine_binding[3 if cr['role']=='stdout' else 4]
                    else:scalar=False
                    if cr.get('fd') is None:
                        scalar=scalar and cr.get('attempted') is False and cr.get('returned') is None and cr.get('raw_return') is None and cr.get('result_valid') is None
                    else:
                        scalar=scalar and type(cr.get('fd')) is int and cr['fd']>=0 and cr.get('attempted') is True and cr.get('returned') is True and cr.get('raw_return') is None and cr.get('result_valid') is True
                    close_ok=close_ok and scalar
                    if cr.get('error') is not None or cr.get('completed') is not True:close_quarantined=True
                close_ok=close_ok and ((not close_journal and cs.get('current') is None)
                    or (bool(close_journal) and cs.get('current') is close_journal[-1]))
            poll_state=values.get('_status_poll_state');poll_journal=values.get('_status_poll_journal');poll_binding=values.get('_status_poll_binding')
            poll_native=type(poll_state) is dict and all(type(key) is str for key in poll_state)
            ps=poll_state if poll_native else {}
            poll_context=type(quarantine_binding) is tuple and len(quarantine_binding)==7
            poll_original=(type(poll_binding) is tuple and len(poll_binding)==4 and poll_binding[0] is poll_state
                and poll_binding[1] is poll_journal and poll_binding[2] is quarantine_binding
                and poll_binding[3] is values.get('_process_allocation_binding'))
            poll_ok=(poll_native and set(ps)=={'current'} and poll_original and type(poll_journal) is list)
            poll_quarantined=not poll_ok;poll_last={}
            poll_required={'process','constructor_record','constructor_returned','public_process_before','status_before','method','lookup_attempted','lookup_returned','poll_attempted','returned','raw_return','value_valid','status_committed','completed','error'}
            if type(poll_journal) is list:
                for item in poll_journal:
                    native=type(item) is dict and all(type(key) is str for key in item)
                    pr=item if native else {};poll_last=pr
                    scalar=(native and poll_context and set(pr)==poll_required
                        and pr.get('constructor_record') is quarantine_binding[0] and pr.get('constructor_returned') is True
                        and pr.get('process') is allocated and pr.get('process') is not None
                        and pr.get('public_process_before') is pr.get('process')
                        and (pr.get('status_before') is None or type(pr.get('status_before')) is int)
                        and pr.get('method') is not None and pr.get('lookup_attempted') is True and pr.get('lookup_returned') is True
                        and pr.get('poll_attempted') is True and pr.get('returned') is True
                        and (pr.get('raw_return') is None or type(pr.get('raw_return')) is int)
                        and pr.get('value_valid') is True and type(pr.get('status_committed')) is bool
                        and pr.get('status_committed') is (pr.get('raw_return') is not None)
                        and pr.get('completed') is True and pr.get('error') is None)
                    poll_ok=poll_ok and scalar
                    if not scalar:poll_quarantined=True
                poll_ok=poll_ok and ((not poll_journal and ps.get('current') is None)
                    or (bool(poll_journal) and ps.get('current') is poll_journal[-1]))
            if not poll_ok:poll_quarantined=True
            intentcall_state=values.get('_intent_call_state');intentcall_journal=values.get('_intent_call_journal');intentcall_binding=values.get('_intent_call_binding')
            intentcall_native=type(intentcall_state) is dict and all(type(key) is str for key in intentcall_state);ics=intentcall_state if intentcall_native else {}
            intentcall_original=(type(intentcall_binding) is tuple and len(intentcall_binding)==6 and intentcall_binding[0] is intentcall_state
                and intentcall_binding[1] is intentcall_journal and intentcall_binding[2] is quarantine_binding
                and intentcall_binding[3] is values.get('_init_lease_binding') and type(intentcall_binding[4]) is tuple and len(intentcall_binding[4])==2
                and intentcall_binding[5] is values.get('_intent_call_secondary_errors') and type(intentcall_binding[5]) is list)
            intentcall_ok=(intentcall_native and set(ics)=={'current','first_error','quarantined','calls_completed'} and intentcall_original
                and type(intentcall_journal) is list and len(intentcall_journal) in (0,2) and ics.get('calls_completed') is bool(intentcall_journal)
                and ics.get('first_error') is None and ics.get('quarantined') is False
                and values.get('_intent_call_primary_error') is None and values.get('_intent_call_quarantined') is False)
            intentcall_quarantined=not intentcall_ok;intentcall_last={}
            intentcall_required={'object','stage','function','arguments','path','intent','image','expected_digest','context',
                'attempted','returned','raw_return','value_valid','context_checked','completed','error'}
            if type(intentcall_journal) is list:
                for icindex,item in enumerate(intentcall_journal):
                    native=type(item) is dict and all(type(key) is str for key in item);icr=item if native else {};intentcall_last=icr
                    arguments=icr.get('arguments');icstage='write' if icindex==0 else 'hash'
                    scalar=(native and set(icr)==intentcall_required and intentcall_original and icindex<2
                        and icr.get('object') is aux and type(icr.get('stage')) is str and icr.get('stage')==icstage
                        and icr.get('function') is intentcall_binding[4][icindex] and type(arguments) is tuple
                        and len(arguments)==(2 if icindex==0 else 1) and arguments[0] is icr.get('path')
                        and (icindex!=0 or arguments[1] is icr.get('intent')) and type(icr.get('image')) is bytes
                        and type(icr.get('expected_digest')) is str and type(icr.get('context')) is tuple and len(icr.get('context'))==2
                        and icr.get('attempted') is True and icr.get('returned') is True and icr.get('value_valid') is True
                        and icr.get('context_checked') is True and icr.get('completed') is True and icr.get('error') is None
                        and (icindex!=0 or icr.get('raw_return') is None)
                        and (icindex!=1 or type(icr.get('raw_return')) is str and icr.get('raw_return')==icr.get('expected_digest')))
                    if scalar:
                        icobjects,icstreams=icr['context']
                        scalar=(type(icobjects) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in icobjects)
                            and type(icstreams) is tuple and len(icstreams)==2 and type(quarantine_binding) is tuple and len(quarantine_binding)==7)
                        if scalar:
                            for icstreamindex,snapshot in enumerate(icstreams):
                                scalar=scalar and (type(snapshot) is tuple and len(snapshot)==3 and type(snapshot[0]) is str
                                    and snapshot[0]==('stdout' if icstreamindex==0 else 'stderr') and snapshot[1] is quarantine_binding[3+icstreamindex]
                                    and type(snapshot[2]) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in snapshot[2]))
                    intentcall_ok=intentcall_ok and scalar
                    if not scalar:intentcall_quarantined=True
                intentcall_ok=intentcall_ok and ((not intentcall_journal and ics.get('current') is None)
                    or (bool(intentcall_journal) and ics.get('current') is intentcall_journal[-1]))
            if not intentcall_ok:intentcall_quarantined=True
            initlease_state=values.get('_init_lease_state');initlease_journal=values.get('_init_lease_journal');initlease_binding=values.get('_init_lease_binding')
            initlease_native=type(initlease_state) is dict and all(type(key) is str for key in initlease_state);ils=initlease_state if initlease_native else {}
            initlease_original=(type(initlease_binding) is tuple and len(initlease_binding)==4 and initlease_binding[0] is initlease_state
                and initlease_binding[1] is initlease_journal and initlease_binding[2] is quarantine_binding
                and initlease_binding[3] is values.get('_init_lease_secondary_errors') and type(initlease_binding[3]) is list)
            initlease_ok=(initlease_native and set(ils)=={'current','first_error','quarantined'} and initlease_original and type(initlease_journal) is list
                and ils.get('first_error') is None and ils.get('quarantined') is False
                and values.get('_init_lease_primary_error') is None and values.get('_init_lease_quarantined') is False)
            initlease_quarantined=not initlease_ok;initlease_last={}
            initlease_required={'object','constructor','callback','public_callback_before','intent_before','intent_bytes_before','intent_native_before','object_context',
                'streams_before','stream_items_before','callback_attempted','returned','raw_return','context_checked','completed','error'}
            if type(initlease_journal) is list:
                for item in initlease_journal:
                    native=type(item) is dict and all(type(key) is str for key in item);ilr=item if native else {};initlease_last=ilr
                    ilcontext=ilr.get('streams_before');ilsaved=ilr.get('stream_items_before');ilobjects=ilr.get('object_context')
                    scalar=(native and set(ilr)==initlease_required and type(quarantine_binding) is tuple and len(quarantine_binding)==7
                        and ilr.get('object') is aux and ilr.get('constructor') is quarantine_binding
                        and ilr.get('callback') is quarantine_binding[5] and ilr.get('public_callback_before') is ilr.get('callback')
                        and type(ilr.get('intent_before')) is dict and type(ilr.get('intent_bytes_before')) is bytes
                        and type(ilr.get('intent_native_before')) is tuple and len(ilr.get('intent_native_before'))==2
                        and type(ilcontext) is tuple and len(ilcontext)==2 and type(ilsaved) is tuple and len(ilsaved)==2
                        and type(ilobjects) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in ilobjects)
                        and ilr.get('callback_attempted') is True and ilr.get('returned') is True
                        and ilr.get('context_checked') is True and ilr.get('completed') is True and ilr.get('error') is None)
                    if scalar:
                        for ilindex,snapshot in enumerate(ilcontext):
                            pairs=ilsaved[ilindex]
                            scalar=scalar and (type(snapshot) is tuple and len(snapshot)==8 and type(snapshot[0]) is str
                                and snapshot[0]==('stdout' if ilindex==0 else 'stderr') and snapshot[1] is quarantine_binding[3+ilindex]
                                and snapshot[2] is snapshot[1] and type(snapshot[6]) is bytes and type(snapshot[7]) is bool
                                and type(pairs) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in pairs))
                    initlease_ok=initlease_ok and scalar
                    if not scalar:initlease_quarantined=True
                initlease_ok=initlease_ok and ((not initlease_journal and ils.get('current') is None)
                    or (bool(initlease_journal) and ils.get('current') is initlease_journal[-1]))
            if not initlease_ok:initlease_quarantined=True
            startlease_state=values.get('_start_lease_state');startlease_journal=values.get('_start_lease_journal');startlease_binding=values.get('_start_lease_binding')
            startlease_native=type(startlease_state) is dict and all(type(key) is str for key in startlease_state);sls=startlease_state if startlease_native else {}
            startlease_original=(type(startlease_binding) is tuple and len(startlease_binding)==4 and startlease_binding[0] is startlease_state
                and startlease_binding[1] is startlease_journal and startlease_binding[2] is quarantine_binding
                and startlease_binding[3] is values.get('_startup_journal_binding'))
            startlease_ok=(startlease_native and set(sls)=={'current'} and startlease_original and type(startlease_journal) is list)
            startlease_quarantined=not startlease_ok;startlease_last={}
            startlease_required={'callback','public_callback_before','startup_operation','process_before','streams_before','object_context',
                'stream_items_before','allocation_context','callback_attempted','returned','raw_return','context_checked','completed','error'}
            if type(startlease_journal) is list:
                for item in startlease_journal:
                    native=type(item) is dict and all(type(key) is str for key in item);slr=item if native else {};startlease_last=slr
                    sloperation=slr.get('startup_operation');slcontext=slr.get('streams_before')
                    scalar=(native and set(slr)==startlease_required and type(quarantine_binding) is tuple and len(quarantine_binding)==7
                        and slr.get('callback') is quarantine_binding[5] and slr.get('public_callback_before') is slr.get('callback')
                        and slr.get('process_before') is None and type(slcontext) is tuple and len(slcontext)==2
                        and type(sloperation) is dict and all(type(key) is str for key in sloperation)
                        and type(sloperation.get('stage')) is str and sloperation.get('stage')=='lease_check'
                        and sloperation.get('attempted') is True and sloperation.get('returned') is True
                        and sloperation.get('value') is slr.get('raw_return') and sloperation.get('error') is None
                        and slr.get('callback_attempted') is True and slr.get('returned') is True
                        and slr.get('context_checked') is True and slr.get('completed') is True and slr.get('error') is None)
                    if scalar:
                        for slindex,snapshot in enumerate(slcontext):
                            scalar=scalar and (type(snapshot) is tuple and len(snapshot)==8 and type(snapshot[0]) is str
                                and snapshot[0]==('stdout' if slindex==0 else 'stderr') and snapshot[1] is quarantine_binding[3+slindex]
                                and snapshot[2] is snapshot[1] and type(snapshot[6]) is bytes and type(snapshot[7]) is bool)
                        for slname in ('object_context','allocation_context'):
                            pairs=slr[slname]
                            scalar=scalar and (type(pairs) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in pairs))
                        saved=slr['stream_items_before']
                        scalar=scalar and (type(saved) is tuple and len(saved)==2
                            and all(type(pairs) is tuple and all(type(pair) is tuple and len(pair)==2 and type(pair[0]) is str for pair in pairs) for pairs in saved))
                    startlease_ok=startlease_ok and scalar
                    if not scalar:startlease_quarantined=True
                startlease_ok=startlease_ok and ((not startlease_journal and sls.get('current') is None)
                    or (bool(startlease_journal) and sls.get('current') is startlease_journal[-1]))
            if not startlease_ok:startlease_quarantined=True
            waitlease_state=values.get('_wait_lease_state');waitlease_journal=values.get('_wait_lease_journal');waitlease_binding=values.get('_wait_lease_binding')
            waitlease_native=type(waitlease_state) is dict and all(type(key) is str for key in waitlease_state);wls=waitlease_state if waitlease_native else {}
            waitlease_original=(type(waitlease_binding) is tuple and len(waitlease_binding)==3 and waitlease_binding[0] is waitlease_state
                and waitlease_binding[1] is waitlease_journal and waitlease_binding[2] is quarantine_binding)
            waitlease_ok=(waitlease_native and set(wls)=={'current'} and waitlease_original and type(waitlease_journal) is list)
            waitlease_quarantined=not waitlease_ok;waitlease_last={};waitlease_required={'constructor_record','resources','callback','public_callback_before','process','streams_before','callback_attempted','returned','raw_return','context_checked','context_released','completed','error'}
            if type(waitlease_journal) is list:
                for item in waitlease_journal:
                    native=type(item) is dict and all(type(key) is str for key in item);wlr=item if native else {};waitlease_last=wlr
                    wlresources=wlr.get('resources');wlcontext=wlr.get('streams_before')
                    scalar=(native and set(wlr)==waitlease_required and type(quarantine_binding) is tuple and len(quarantine_binding)==7
                        and wlr.get('constructor_record') is quarantine_binding[0] and wlresources is q.get('streams')
                        and type(wlresources) is tuple and len(wlresources)==2 and type(wlcontext) is tuple and len(wlcontext)==2
                        and wlr.get('callback') is quarantine_binding[5] and wlr.get('public_callback_before') is wlr.get('callback')
                        and wlr.get('process') is allocated and allocated is not None
                        and wlr.get('callback_attempted') is True and wlr.get('returned') is True
                        and wlr.get('context_checked') is True and wlr.get('context_released') is True
                        and wlr.get('completed') is True and wlr.get('error') is None)
                    if scalar:
                        for wlindex,wlsnapshot in enumerate(wlcontext):
                            wloriginal=wlresources[wlindex]
                            context_ok=(type(wlsnapshot) is tuple and len(wlsnapshot)==9 and type(wloriginal) is tuple and len(wloriginal)==5
                                and type(wlsnapshot[0]) is str and wlsnapshot[0]==('stdout' if wlindex==0 else 'stderr')
                                and type(wloriginal[0]) is str and wloriginal[0]==wlsnapshot[0]
                                and wlsnapshot[1] is quarantine_binding[3+wlindex] and wlsnapshot[1] is wloriginal[1]
                                and wlsnapshot[2] is wloriginal and wlsnapshot[5] is wloriginal[2] and wlsnapshot[5] is not None
                                and type(wloriginal[3]) is int and type(wloriginal[4]) is int
                                and (wlsnapshot[3] is None or type(wlsnapshot[3]) is int and wlsnapshot[3]==wloriginal[3])
                                and (wlsnapshot[4] is None or type(wlsnapshot[4]) is int and wlsnapshot[4]==wloriginal[4])
                                and wlsnapshot[6] is None and type(wlsnapshot[7]) is bool
                                and type(wlsnapshot[8]) is int and wlsnapshot[8]>=0)
                            scalar=scalar and context_ok
                    waitlease_ok=waitlease_ok and scalar
                    if not scalar:waitlease_quarantined=True
                waitlease_ok=waitlease_ok and ((not waitlease_journal and wls.get('current') is None)
                    or (bool(waitlease_journal) and wls.get('current') is waitlease_journal[-1]))
            if not waitlease_ok:waitlease_quarantined=True
            select_state=values.get('_select_state');select_journal=values.get('_select_journal');select_binding=values.get('_select_binding')
            select_native=type(select_state) is dict and all(type(key) is str for key in select_state);ss=select_state if select_native else {}
            select_original=(type(select_binding) is tuple and len(select_binding)==3 and select_binding[0] is select_state
                and select_binding[1] is select_journal and select_binding[2] is quarantine_binding)
            select_ok=(select_native and set(ss)=={'current'} and select_original and type(select_journal) is list)
            select_quarantined=not select_ok;select_last={};select_required={'constructor_record','resources','process','streams_before','readers_arg','readers_before','expected_readers','writers_arg','exceptions_arg','timeout','selector','lookup_attempted','lookup_returned','select_attempted','returned','raw_return','value_valid','completed','error'}
            if type(select_journal) is list:
                for item in select_journal:
                    native=type(item) is dict and all(type(key) is str for key in item);sr=item if native else {};select_last=sr
                    sresources=sr.get('resources');scontext=sr.get('streams_before');sexpected=sr.get('expected_readers');sraw=sr.get('raw_return')
                    scalar=(native and set(sr)==select_required and type(quarantine_binding) is tuple and len(quarantine_binding)==7
                        and sr.get('constructor_record') is quarantine_binding[0] and sresources is q.get('streams')
                        and type(sresources) is tuple and len(sresources)==2 and type(scontext) is tuple and len(scontext)==2
                        and sr.get('process') is allocated and allocated is not None)
                    select_derived=[]
                    if scalar:
                        for sindex,ssnapshot in enumerate(scontext):
                            soriginal=sresources[sindex]
                            select_context_ok=(type(ssnapshot) is tuple and len(ssnapshot)==7 and type(soriginal) is tuple and len(soriginal)==5
                                and type(ssnapshot[0]) is str and ssnapshot[0]==('stdout' if sindex==0 else 'stderr')
                                and type(soriginal[0]) is str and soriginal[0]==ssnapshot[0]
                                and ssnapshot[1] is quarantine_binding[3+sindex] and ssnapshot[1] is soriginal[1]
                                and ssnapshot[2] is soriginal and ssnapshot[4] is soriginal[2] and ssnapshot[4] is not None
                                and type(soriginal[3]) is int and soriginal[3]>=0
                                and type(ssnapshot[5]) is bytes and not ssnapshot[5] and type(ssnapshot[6]) is bool)
                            if select_context_ok:
                                if ssnapshot[6] is False:
                                    select_context_ok=type(ssnapshot[3]) is int and ssnapshot[3]==soriginal[3];select_derived.append(soriginal[3])
                                else:select_context_ok=ssnapshot[3] is None
                            scalar=scalar and select_context_ok
                    scalar=(scalar and type(sexpected) is tuple and bool(sexpected) and all(type(fd) is int for fd in sexpected)
                        and len(set(sexpected))==len(sexpected) and tuple(select_derived)==sexpected
                        and type(sr.get('readers_before')) is tuple and all(type(fd) is int for fd in sr.get('readers_before'))
                        and sr.get('readers_before')==sexpected and type(sr.get('readers_arg')) is list
                        and all(type(fd) is int for fd in sr.get('readers_arg')) and tuple(sr.get('readers_arg'))==sexpected
                        and type(sr.get('writers_arg')) is list and not sr.get('writers_arg')
                        and type(sr.get('exceptions_arg')) is list and not sr.get('exceptions_arg')
                        and (type(sr.get('timeout')) is int or type(sr.get('timeout')) is float) and 0<=sr.get('timeout')<=.05
                        and sr.get('selector') is not None and sr.get('lookup_attempted') is True and sr.get('lookup_returned') is True
                        and sr.get('select_attempted') is True and sr.get('returned') is True
                        and type(sraw) is tuple and len(sraw)==3 and all(type(part) is list for part in sraw)
                        and all(type(fd) is int for part in sraw for fd in part)
                        and not sraw[1] and not sraw[2] and len(sraw[0])<=len(sexpected) and set(sraw[0])<=set(sexpected)
                        and sr.get('value_valid') is True and sr.get('completed') is True and sr.get('error') is None)
                    select_ok=select_ok and scalar
                    if not scalar:select_quarantined=True
                select_ok=select_ok and ((not select_journal and ss.get('current') is None)
                    or (bool(select_journal) and ss.get('current') is select_journal[-1]))
            if not select_ok:select_quarantined=True
            read_state=values.get('_stream_read_state');read_journal=values.get('_stream_read_journal');read_binding=values.get('_stream_read_binding')
            read_native=type(read_state) is dict and all(type(key) is str for key in read_state);rs=read_state if read_native else {}
            read_original=(type(read_binding) is tuple and len(read_binding)==3 and read_binding[0] is read_state
                and read_binding[1] is read_journal and read_binding[2] is quarantine_binding)
            read_ok=(read_native and set(rs)=={'current'} and read_original and type(read_journal) is list)
            read_quarantined=not read_ok;read_last={}
            read_required={'stream','constructor_record','resources','original','read_fd','log','process','buffer_before','eof_before','reader','lookup_attempted','lookup_returned','read_attempted','returned','raw_return','raw_size','value_valid','buffer_committed','raw_consumed','expected_received','expected_error','completed','error','secondary_error'}
            if type(read_journal) is list:
                for item in read_journal:
                    native=type(item) is dict and all(type(key) is str for key in item);rr=item if native else {};read_last=rr
                    rr_original=rr.get('original');rr_resources=rr.get('resources')
                    normal=(rr.get('returned') is True and type(rr.get('raw_size')) is int and 0<=rr.get('raw_size')<=65536
                        and rr.get('value_valid') is True and rr.get('expected_received') is False and rr.get('expected_error') is None
                        and type(rr.get('buffer_committed')) is bool and rr.get('buffer_committed') is (rr.get('raw_size')>0)
                        and rr.get('raw_consumed') is (rr.get('raw_size')>0)
                        and ((rr.get('raw_size')>0 and rr.get('raw_return') is None)
                            or (rr.get('raw_size')==0 and type(rr.get('raw_return')) is bytes and len(rr.get('raw_return'))==0)))
                    expected=(rr.get('returned') is None and rr.get('raw_return') is None and rr.get('raw_size') is None
                        and rr.get('value_valid') is None and rr.get('buffer_committed') is False and rr.get('raw_consumed') is False
                        and rr.get('expected_received') is True and rr.get('expected_error') is not None
                        and any(base is BlockingIOError or base is InterruptedError for base in type.__getattribute__(type(rr.get('expected_error')),'__mro__')))
                    scalar=(native and set(rr)==read_required and type(quarantine_binding) is tuple and len(quarantine_binding)==7
                        and rr.get('constructor_record') is quarantine_binding[0]
                        and rr_resources is q.get('streams') and type(rr_resources) is tuple and len(rr_resources)==2
                        and type(rr_original) is tuple and len(rr_original)==5 and any(item is rr_original for item in rr_resources)
                        and rr.get('stream') is rr_original[1] and type(rr.get('read_fd')) is int and type(rr_original[3]) is int and rr.get('read_fd')==rr_original[3]
                        and rr.get('log') is rr_original[2] and rr.get('log') is not None
                        and rr.get('process') is allocated and allocated is not None
                        and type(rr.get('buffer_before')) is bytes and not rr.get('buffer_before') and rr.get('eof_before') is False
                        and rr.get('reader') is not None and rr.get('lookup_attempted') is True and rr.get('lookup_returned') is True
                        and rr.get('read_attempted') is True and (normal or expected) and rr.get('completed') is True
                        and rr.get('error') is None and rr.get('secondary_error') is None)
                    read_ok=read_ok and scalar
                    if not scalar:read_quarantined=True
                read_ok=read_ok and ((not read_journal and rs.get('current') is None)
                    or (bool(read_journal) and rs.get('current') is read_journal[-1]))
            if not read_ok:read_quarantined=True
            wait_state=values.get('_direct_wait_state');wait_journal=values.get('_direct_wait_journal');wait_binding=values.get('_direct_wait_binding')
            wait_native=type(wait_state) is dict and all(type(key) is str for key in wait_state)
            ws=wait_state if wait_native else {}
            wait_original=(type(wait_binding) is tuple and len(wait_binding)==4 and wait_binding[0] is wait_state
                and wait_binding[1] is wait_journal and wait_binding[2] is quarantine_binding
                and wait_binding[3] is values.get('_process_allocation_binding'))
            wait_ok=(wait_native and set(ws)=={'current'} and wait_original and type(wait_journal) is list)
            wait_quarantined=not wait_ok;wait_last={}
            if type(wait_journal) is list:
                for item in wait_journal:
                    native=type(item) is dict and all(type(key) is str for key in item)
                    wr=item if native else {};wait_last=wr
                    normal=(wr.get('returned') is True and type(wr.get('raw_return')) is int
                        and wr.get('value_valid') is True and wr.get('timeout_received') is False
                        and wr.get('timeout_error') is None and wr.get('witness_committed') is True)
                    timed=(wr.get('returned') is None and wr.get('raw_return') is None and wr.get('value_valid') is None
                        and wr.get('timeout_received') is True and wr.get('timeout_error') is not None
                        and any(base is subprocess.TimeoutExpired for base in type.__getattribute__(type(wr.get('timeout_error')),'__mro__'))
                        and wr.get('witness_committed') is False)
                    scalar=(native and wr.get('process') is allocated and allocated is not None
                        and wr.get('constructor_record') is (quarantine_binding[0] if type(quarantine_binding) is tuple and len(quarantine_binding)==7 else None)
                        and wr.get('constructor_returned') is True and wr.get('public_process_before') is allocated
                        and (type(wr.get('timeout')) is int or type(wr.get('timeout')) is float) and 0<=wr.get('timeout')<=60
                        and (wr.get('witness_process_before') is None or wr.get('witness_process_before') is allocated)
                        and type(wr.get('witness_observed_before')) is bool
                        and ((wr.get('witness_observed_before') and wr.get('witness_process_before') is allocated and type(wr.get('witness_status_before')) is int)
                            or (wr.get('witness_observed_before') is False and wr.get('witness_status_before') is None))
                        and wr.get('process_bound') is True and wr.get('method') is not None
                        and wr.get('lookup_attempted') is True and wr.get('lookup_returned') is True and wr.get('wait_attempted') is True
                        and (normal or timed) and wr.get('completed') is True and wr.get('error') is None and wr.get('secondary_error') is None)
                    wait_ok=wait_ok and scalar
                    if not scalar:wait_quarantined=True
                wait_ok=wait_ok and ((not wait_journal and ws.get('current') is None)
                    or (bool(wait_journal) and ws.get('current') is wait_journal[-1]))
            if not wait_ok:wait_quarantined=True
            buffer_state=values.get('_buffer_write_state');buffer_journal=values.get('_buffer_write_journal')
            buffer_binding=values.get('_buffer_write_binding')
            buffer_native=type(buffer_state) is dict and all(type(key) is str for key in buffer_state)
            bs=buffer_state if buffer_native else {}
            buffer_context_native=type(quarantine_binding) is tuple and len(quarantine_binding)==7
            buffer_original=(type(buffer_binding) is tuple and len(buffer_binding)==3
                and buffer_binding[0] is buffer_state and buffer_binding[1] is buffer_journal
                and buffer_binding[2] is quarantine_binding)
            buffer_ok=(buffer_native and set(bs)=={'current'} and buffer_original and type(buffer_journal) is list)
            buffer_quarantined=not buffer_ok
            buffer_last={}
            buffer_required={'stream','role','log','hasher','buffer','input_len','before_bytes','maximum','read_fd','process','write_method','write_lookup_attempted','write_lookup_returned','write_attempted','write_returned','raw_count','count_valid','hash_method','hash_lookup_attempted','hash_lookup_returned','hash_attempted','hash_returned','hash_raw_return','hash_result_valid','hash_input','committed','completed','error','secondary_error'}
            if type(buffer_journal) is list:
                for item in buffer_journal:
                    native=type(item) is dict and all(type(key) is str for key in item)
                    br=item if native else {};buffer_last=br
                    scalar=(native and buffer_context_native and set(br)==buffer_required and type(br.get('role')) is str
                        and br['role'] in ('stdout','stderr')
                        and br.get('stream') is quarantine_binding[3 if br['role']=='stdout' else 4]
                        and br.get('process') is allocated
                        and type(br.get('input_len')) is int and br['input_len']>0
                        and type(br.get('before_bytes')) is int and br['before_bytes']>=0
                        and type(br.get('maximum')) is int and br['before_bytes']+br['input_len']<=br['maximum']
                        and type(br.get('read_fd')) is int and br['read_fd']>=0
                        and br.get('write_method') is not None and br.get('hash_method') is not None
                        and type(br.get('raw_count')) is int and 0<br['raw_count']<=br['input_len']
                        and br.get('write_lookup_attempted') is True and br.get('write_lookup_returned') is True
                        and br.get('write_attempted') is True and br.get('write_returned') is True
                        and br.get('count_valid') is True and br.get('hash_lookup_attempted') is True
                        and br.get('hash_lookup_returned') is True and br.get('hash_attempted') is True
                        and br.get('hash_returned') is True and br.get('hash_raw_return') is None
                        and br.get('hash_result_valid') is True and br.get('committed') is True
                        and br.get('completed') is True and br.get('buffer') is None and br.get('hash_input') is None
                        and br.get('error') is None and br.get('secondary_error') is None)
                    buffer_ok=buffer_ok and scalar
                    if not scalar:buffer_quarantined=True
                buffer_ok=buffer_ok and ((not buffer_journal and bs.get('current') is None)
                    or (bool(buffer_journal) and bs.get('current') is buffer_journal[-1]))
            if not buffer_ok:buffer_quarantined=True
            deferred_state=values.get('_deferred_state');deferred_binding=values.get('_deferred_binding')
            deferred_native=type(deferred_state) is dict and all(type(key) is str for key in deferred_state)
            ds=deferred_state if deferred_native else {}
            deferred_original=(type(deferred_binding) is tuple and len(deferred_binding)==3
                and deferred_binding[0] is deferred_state and deferred_binding[1] is quarantine_binding
                and type(deferred_binding[2]) is list and deferred_binding[2] is values.get('_deferred_secondary_errors'))
            deferred_ok=(deferred_native and set(ds)=={'received','first_error','quarantined'} and deferred_original
                and ds.get('received') is False and ds.get('first_error') is None
                and ds.get('quarantined') is False and values.get('_deferred_quarantined') is False
                and values.get('_deferred_primary_error') is None and len(deferred_binding[2])==0)
            deferred_quarantined=(values.get('_deferred_primary_error') is not None or ds.get('first_error') is not None
                or values.get('_deferred_quarantined') is not False or ds.get('quarantined') is not False)
            final_state=values.get('_finalization_state');final_journal=values.get('_finalization_journal')
            final_binding=values.get('_finalization_binding')
            final_native=type(final_state) is dict and all(type(key) is str for key in final_state)
            fs=final_state if final_native else {}
            final_original=(type(final_binding) is tuple and len(final_binding)==5
                and final_binding[0] is final_state and final_binding[1] is final_journal
                and final_binding[2] is quarantine_binding and final_binding[3] is close_binding
                and type(final_binding[4]) is list and final_binding[4] is values.get('_finalization_secondary_errors'))
            final_ok=(final_native and set(fs)=={'attempted','completed','first_error','quarantined','current','candidate_result'}
                and final_original and type(final_journal) is list
                and type(fs.get('attempted')) is bool and type(fs.get('completed')) is bool
                and fs.get('first_error') is values.get('_finalization_primary_error') and fs.get('first_error') is None
                and type(fs.get('quarantined')) is bool and fs.get('quarantined') is values.get('_finalization_quarantined'))
            final_quarantined=(values.get('_finalization_primary_error') is not None or fs.get('first_error') is not None
                or values.get('_finalization_quarantined') is not False or fs.get('quarantined') is not False)
            final_required={'stage','role','log','fd','process','candidate_result','attempted','returned','raw_return','result_valid','completed','error'}
            if type(final_journal) is list:
                for item in final_journal:
                    native=type(item) is dict and all(type(key) is str for key in item)
                    fr=item if native else {}
                    scalar=(native and set(fr)==final_required and type(fr.get('stage')) is str
                        and fr['stage'] in ('flush','fileno','fsync','close','snapshot','result')
                        and fr.get('process') is allocated and fr.get('attempted') is True
                        and fr.get('returned') is True and fr.get('result_valid') is True
                        and fr.get('completed') is True and fr.get('error') is None)
                    if fr.get('stage')=='result':
                        scalar=scalar and fr.get('role') is None and fr.get('candidate_result') is fs.get('candidate_result')
                    else:scalar=scalar and type(fr.get('role')) is str and fr['role'] in ('stdout','stderr')
                    final_ok=final_ok and scalar
                    if fr.get('error') is not None or fr.get('completed') is not True:final_quarantined=True
                final_ok=final_ok and ((not final_journal and fs.get('current') is None)
                    or (bool(final_journal) and fs.get('current') is final_journal[-1]))
                if final_journal:final_ok=final_ok and fs.get('attempted') is True
            if fs.get('completed') is True:
                final_ok=final_ok and fs.get('attempted') is True and values.get('result') is fs.get('candidate_result') and values.get('finished') is True and values.get('pending') is False
            okay=(aux_data is not None and 'process' in values and child_ok and allocation_ok and qokay and not start_unknown
                and close_ok and not close_quarantined
                and final_ok and not final_quarantined
                and values.get('lease_check') is owner_callback
                and all(type(values.get(key)) is bool for key in ('started','pending','finished')))
            valid=valid and okay
            rows.append(dict(role='auxiliary',index=index,retained_process=held,pid=pid,cached_returncode=cached,
                retained_allocated_process=allocated_held,allocated_pid=allocated_pid,allocated_cached_returncode=allocated_cached,
                allocation_attempted=record.get('allocation_attempted') if type(record.get('allocation_attempted')) is bool else None,
                allocation_returned=record.get('allocation_returned') if primitive(record.get('allocation_returned'),bool,True) else None,
                initializer_attempted=record.get('initializer_attempted') if type(record.get('initializer_attempted')) is bool else None,
                initializer_returned=record.get('initializer_returned') if primitive(record.get('initializer_returned'),bool,True) else None,
                constructor_returned=record.get('constructor_returned') if primitive(record.get('constructor_returned'),bool,True) else None,
                start_outcome_unknown=start_unknown,allocation_fields_valid=allocation_ok,
                constructor_quarantined=constructor_quarantined,constructor_quarantine_fields_valid=qokay,
                creator_close_quarantined=close_quarantined,creator_close_fields_valid=close_ok,
                creator_close_entries=len(close_journal) if type(close_journal) is list else None,
                status_poll_fields_valid=poll_ok,status_poll_quarantined=poll_quarantined,
                status_poll_entries=len(poll_journal) if type(poll_journal) is list else None,
                status_poll_returned=poll_last.get('returned') if type(poll_last.get('returned')) is bool else None,
                status_poll_raw_status=poll_last.get('raw_return') if type(poll_last.get('raw_return')) is int else None,
                status_poll_value_valid=poll_last.get('value_valid') if type(poll_last.get('value_valid')) is bool else None,
                status_poll_completed=poll_last.get('completed') if type(poll_last.get('completed')) is bool else None,
                intent_call_fields_valid=intentcall_ok,intent_call_quarantined=intentcall_quarantined,
                intent_call_entries=len(intentcall_journal) if type(intentcall_journal) is list else None,
                intent_call_returned=intentcall_last.get('returned') if type(intentcall_last.get('returned')) is bool else None,
                intent_call_completed=intentcall_last.get('completed') if type(intentcall_last.get('completed')) is bool else None,
                intent_call_pair_completed=ics.get('calls_completed') if type(ics.get('calls_completed')) is bool else None,
                init_lease_fields_valid=initlease_ok,init_lease_quarantined=initlease_quarantined,
                init_lease_entries=len(initlease_journal) if type(initlease_journal) is list else None,
                init_lease_returned=initlease_last.get('returned') if type(initlease_last.get('returned')) is bool else None,
                init_lease_completed=initlease_last.get('completed') if type(initlease_last.get('completed')) is bool else None,
                start_lease_fields_valid=startlease_ok,start_lease_quarantined=startlease_quarantined,
                start_lease_entries=len(startlease_journal) if type(startlease_journal) is list else None,
                start_lease_returned=startlease_last.get('returned') if type(startlease_last.get('returned')) is bool else None,
                start_lease_completed=startlease_last.get('completed') if type(startlease_last.get('completed')) is bool else None,
                wait_lease_fields_valid=waitlease_ok,wait_lease_quarantined=waitlease_quarantined,
                wait_lease_entries=len(waitlease_journal) if type(waitlease_journal) is list else None,
                wait_lease_returned=waitlease_last.get('returned') if type(waitlease_last.get('returned')) is bool else None,
                wait_lease_context_released=waitlease_last.get('context_released') if type(waitlease_last.get('context_released')) is bool else None,
                wait_lease_completed=waitlease_last.get('completed') if type(waitlease_last.get('completed')) is bool else None,
                select_fields_valid=select_ok,select_quarantined=select_quarantined,
                select_entries=len(select_journal) if type(select_journal) is list else None,
                select_returned=select_last.get('returned') if type(select_last.get('returned')) is bool else None,
                select_value_valid=select_last.get('value_valid') if type(select_last.get('value_valid')) is bool else None,
                select_completed=select_last.get('completed') if type(select_last.get('completed')) is bool else None,
                stream_read_fields_valid=read_ok,stream_read_quarantined=read_quarantined,
                stream_read_entries=len(read_journal) if type(read_journal) is list else None,
                stream_read_returned=read_last.get('returned') if type(read_last.get('returned')) is bool else None,
                stream_read_raw_size=read_last.get('raw_size') if type(read_last.get('raw_size')) is int else None,
                stream_read_expected_received=read_last.get('expected_received') if type(read_last.get('expected_received')) is bool else None,
                stream_read_completed=read_last.get('completed') if type(read_last.get('completed')) is bool else None,
                direct_wait_fields_valid=wait_ok,direct_wait_quarantined=wait_quarantined,
                direct_wait_entries=len(wait_journal) if type(wait_journal) is list else None,
                direct_wait_returned=wait_last.get('returned') if type(wait_last.get('returned')) is bool else None,
                direct_wait_raw_status=wait_last.get('raw_return') if type(wait_last.get('raw_return')) is int else None,
                direct_wait_timeout_received=wait_last.get('timeout_received') if type(wait_last.get('timeout_received')) is bool else None,
                direct_wait_completed=wait_last.get('completed') if type(wait_last.get('completed')) is bool else None,
                buffer_write_fields_valid=buffer_ok,buffer_write_quarantined=buffer_quarantined,
                buffer_write_entries=len(buffer_journal) if type(buffer_journal) is list else None,
                buffer_write_known_count=buffer_last.get('raw_count') if type(buffer_last.get('raw_count')) is int else None,
                buffer_write_hash_returned=buffer_last.get('hash_returned') if type(buffer_last.get('hash_returned')) is bool else None,
                buffer_write_completed=buffer_last.get('completed') if type(buffer_last.get('completed')) is bool else None,
                deferred_fields_valid=deferred_ok,deferred_quarantined=deferred_quarantined,
                deferred_received=ds.get('received') if type(ds.get('received')) is bool else None,
                finalization_fields_valid=final_ok,finalization_quarantined=final_quarantined,
                finalization_entries=len(final_journal) if type(final_journal) is list else None,
                finalization_attempted=fs.get('attempted') if type(fs.get('attempted')) is bool else None,
                finalization_completed=fs.get('completed') if type(fs.get('completed')) is bool else None,
                started=values.get('started') if type(values.get('started')) is bool else None,
                pending=values.get('pending') if type(values.get('pending')) is bool else None,
                finished=values.get('finished') if type(values.get('finished')) is bool else None,fields_valid=okay))
        valid=valid and not bad
        rows[0]['fields_valid']=valid
        return binding,rows,valid

    def _cache_command_history(self,rows,checked,quarantined):
        error=self._history_primary_error
        label=None if error is None else type.__dict__['__name__'].__get__(type(error),type)
        self._history_rows=tuple(MappingProxyType(dict(row,scope='command_history_data_only',
            snapshot_checked=checked,quarantined=quarantined,first_error=label,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
            for row in rows)

    def _freeze_command_history(self):
        rows=[]
        try:
            original,rows,valid=self._capture_command_history(True)
            original=tuple(original);self._history_binding=original
            callback=self._history_callback
            self._cache_command_history(rows,False,not valid)
            if not valid:raise ProducerError('command history fields or start outcome unknown')
            if self._history_callback is not callback:
                raise ProducerError('retained command history callback changed')
            callback()
            current,after,valid=self._capture_command_history(False)
            current=tuple(current);self._history_check_binding=current
            if not valid or len(original)!=len(current) or any(a is not b for a,b in zip(original,current)):
                raise ProducerError('command history binding changed across lease callback')
            self._cache_command_history(rows,True,False)
        except BaseException as error:
            self._history_failure(error)
            try:self._cache_command_history(rows,False,True)
            except BaseException as secondary:self._history_failure(secondary)
            raise self._history_primary_error
        return self._history_rows

    def freeze_command_history(self):
        """One terminal DATA snapshot; no actor I/O, closure or admission."""
        return self._schedule('command_history_inventory')

    def command_history_observations(self):
        with self._lock:return self._history_rows



def start_owned_preflight(kind,*,owner_id,**kwargs):
    """Retain before launch; call completion never grants capture admission."""
    if type(kind) is not str or kind not in ('fixture','canonical','production'):
        raise ProducerError('fixed preflight factory required')
    if type(owner_id) is not str or not re.fullmatch('[0-9a-f]{32}',owner_id):
        raise ProducerError('preflight owner id required')
    with _PREFLIGHT_OWNERS_LOCK:
        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')
        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')
    frozen=_copy_preflight_kwargs(kwargs)
    owner=_RetainedPreflightOwner(kind,owner_id,frozen)
    with _PREFLIGHT_OWNERS_LOCK:
        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')
        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')
        _PREFLIGHT_OWNERS[owner_id]=owner
    return owner._schedule('construct')
