import sys,pathlib,json,ast,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path("/tmp/connectanum-native-perf-producer-end-command-progress-v1");parts=json.loads((p/'projection-parts-v1.json').read_text());c=(p/'candidate-v1.py').read_text()
 old="""            flush=log.flush;fileno=log.fileno;close=log.close
            fsync=os.fsync;snapshot=_file_snapshot;event=self._event
            self.pending=False
            record['returncode']=status;record['ended_ns']=time.time_ns()
            self.log=None;self.output_log=None
"""
 new="""            self.pending=False
            record['returncode']=status;record['ended_ns']=time.time_ns()
            self.log=None;self.output_log=None
            flush=log.flush;fileno=log.fileno;close=log.close
            fsync=os.fsync;snapshot=_file_snapshot;event=self._event
"""
 assert c.count(old)==1;c=c.replace(old,new,1);parts['method']=parts['method'].replace(old,new,1);parts['new']=parts['method'].rstrip('\n');ast.parse(c)
 assert c.replace(parts['helper'],'',1).replace(parts['newwait'],parts['oldwait'],1).replace(parts['new'],parts['old'],1)==(p/'before-producer.py').read_text()
 (p/'candidate-v2.py').open('x').write(c);(p/'projection-parts-v2.json').open('x').write(json.dumps(parts,indent=2));(p/'candidate-ROOT-projection-v2.json').open('x').write(json.dumps(dict(wholeSource_BYTE_projectsback=True,candidate_UNEXECUTED=True,source_sha256=hashlib.sha256(c.encode()).hexdigest(),reason='ROOT retains originalpending-status-ended-logdetach order beforefallibleboundmethod lookups; strongoriginalrefs alreadyrecorded. v1-v2UNEXECUTED beforeedit/modelreviewv2.'),indent=2))
 l.verify_identity();print(hashlib.sha256(c.encode()).hexdigest())
