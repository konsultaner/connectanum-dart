import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_NEW29_directory_lexical_scope_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)







import os,stat,collections,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-directory-scope-v1';O=B/'2026-11-07-actions-include-great-great-grandchild-entry-source-alias-intake-v1/ROOT-FIRST-ALL2308-great-great-grandchild-entry-source-alias-intake-PRIVATE.json';R=B/'2026-11-07-actions-include-great-great-grandchild-operand-source-alias-intake-v1/FIRST-original-result-descriptor.json';CP=B/'current-task-checkpoint.json';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration=v['declaration']
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw



 raws={}
 for source in declaration['exact_saved_inputs']:
  raw=read_bounded(pathlib.Path(source['path']),source['range'][1],source['sha256'],source['role']);raws[source['role']]=raw;save(source['role']+'-bound-PRIVATE.json',raw)
 original=json.loads(raws['original_ALL2308_metadata']);currentdescriptor=json.loads(raws['current9026_original_descriptor_ONLYphaseidentity_locator']);assert currentdescriptor==v['current9026_original_descriptor'] and currentdescriptor['result_bytes']==826745446 and currentdescriptor['result_sha256']=='e115ebe01c9e4d98f318b5394bb2e8b253045566a12948ddc909843984d7a7a6'
 allmetadata=[r['original_separate_parent_child_metadata'] for r in original['ALL2308_original_child_relationships_with_NEW_counts']];dirs=[r for r in allmetadata if r['saved_type_derived_from_original_mode']=='directory'];regular=[r for r in allmetadata if r['saved_type_derived_from_original_mode']=='regular'];links=[r for r in allmetadata if r['saved_type_derived_from_original_mode']=='symlink'];assert len(allmetadata)==2308 and len(dirs)==29 and len(regular)==2279 and len(links)==0
 dir_positions=[i for i,r in enumerate(allmetadata) if r['saved_type_derived_from_original_mode']=='directory'];assert len(dir_positions)==29
 relations=[]
 for ordinal,row in enumerate(dirs,1):
  parent=row['literal_parent_reference_SEPARATE'];name=row['literal_child_name_SEPARATE'];assert row['parent_child_NOT_joined_resolved_followed_or_executed'] is True and name not in ['','.','..'] and '/' not in name and '\0' not in name and os.fsdecode(bytes.fromhex(row['original_name_bytes_hex']))==name
  relations.append({'NEW_directory_scope_position_ONE_based':ordinal,'original_ALL2308_record_position_ZERO_based':dir_positions[ordinal-1],'original_separate_parent_child_metadata_PRIVATE':row,'NEW_express_lexical_candidate_TEXT':parent+'/'+name,'NEW_declaration_epoch':'ALL29_directory_INPUT_scope_AFTER9026operand_relationship_intake_BEFORE_ANY_SDK_INPUT_IO','literal_text_only_NOTfilesystemjoin_resolution_or_alias':True,'original_parent_child_and_prior_query_epochs_unchanged':True,'DEFERRED_UNQUERIED_in_THIS_new_scope':True,'alias_identity':None,'query_permission':None,'unperformed_readlink_comparison_count':None,'unperformed_readlink_matches':None,'unperformed_readlink_nonmatches':None})
 refs=[r['NEW_express_lexical_candidate_TEXT'] for r in relations]
 private_scope={'phase':'NEW_ALL29_directory_INPUT_lexicalscope_DECLARED_NOT_queried','ALL29_new_explicit_lexical_relations_PRIVATE':relations,'ALL29_new_literal_directory_references':refs,'ALL2308_original_separate_child_metadata_PRIVATE':allmetadata,'ALL29_original_directory_metadata_DEFERRED_PRIVATE':dirs,'NEW0_original_symlink_metadata_UNEXPANDED_UNFOLLOWED_PRIVATE':links,'ALL199_original_parent_query_records_PRIVATE_preserved':original['ALL199_original_parent_query_records_PRIVATE_preserved'],'original_ALL2308_name_namehex_link_summary_NOT_revalidated':original['summary'],'current_ALL9026_relationship_descriptor_ONLYphaseidentity_NOT_revalidated':currentdescriptor,'all_prior_metadata_epoch_field_sources_unchanged':declaration['exact_saved_inputs'],'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'new_regular_BODY_reads':0,'recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 privateraw=(json.dumps(private_scope,ensure_ascii=True,indent=2)+'\n').encode();save('ALL29-private-exact-new-directory-lexical-scope-BEFORE-INPUT-IO.json',privateraw)
 def public_metadata(row):
  out={k:value for k,value in row.items() if k not in ['original_separate_lstat_full_stat_times_PRIVATE','original_full_child_record_PRIVATE','original_parent_query_record_except_children_PRIVATE']};s=row['original_separate_lstat_full_stat_times_PRIVATE'];out['EXPLICITLY_DERIVED_original_mode_UIDGID_nlink_size_only']=None if s is None else {k:s[k] for k in ['st_mode','st_uid','st_gid','st_nlink','st_size']};return out
 public_scope={'interpretation':'EXPLICITLY_DERIVED_PUBLIC_SAFE_directory_metadata_scope_ONLY/fulloriginalstat-times-FD-privatecontexts PRIVATEretained/alloriginalfields-gates unchanged; expresslyNEWlexicalTEXT beforeSDKINPUT andbeforeCPcomparison/no automaticjoin-resolve-follow-recursion/permissionfrommetadata','phase':private_scope['phase'],'ALL29_new_explicit_lexical_relations':[{**{k:value for k,value in r.items() if k!='original_separate_parent_child_metadata_PRIVATE'},'original_separate_parent_child_metadata_EXPLICITLY_DERIVED_PUBLIC':public_metadata(r['original_separate_parent_child_metadata_PRIVATE'])} for r in relations],'ALL29_new_literal_directory_references':refs,'ALL2308_original_safe_separate_entry_metadata':[public_metadata(r) for r in allmetadata],'ALL29_original_directory_metadata_DEFERRED':[public_metadata(r) for r in dirs],'NEW0_original_symlink_metadata_UNEXPANDED_UNFOLLOWED':[],'original_private_scope_bytes':len(privateraw),'original_private_scope_sha256':hashlib.sha256(privateraw).hexdigest(),'original2308_savedmetadata_bytes':167300212,'original2308_savedmetadata_sha256':'44ee6b3e598b022d483561e0e288b4fa1028bf6f325ace47fe0eb3848f998192','current9026_descriptor_ONLYphaseidentity':currentdescriptor,'all_prior_query_epochs_DEFERRED_flags_6and18links_oldncursesrawhexNULL_unchanged':True,'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'new_regular_BODY_reads':0,'recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 publicraw=(json.dumps(public_scope,ensure_ascii=True,indent=2)+'\n').encode();save('ALL29-new-exact-public-safe-directory-scope-BEFORE-INPUT-IO.json',publicraw)
 cpraw=read_bounded(CP,None,None,'prior_checkpoint_ALL_string_scalar_VALUES');save('prior-checkpoint-bound-PRIVATE.json',cpraw);priorcp=json.loads(cpraw);assert 'actions_include_great_great_grandchild_directory_scope_v1' not in priorcp
 scalars=[]
 def collect(value,path):
  if isinstance(value,str):scalars.append({'ordinal_ZERO_based':len(scalars),'location':path,'original_scalar_PRIVATE':value})
  elif isinstance(value,dict):
   for key,child in value.items():collect(child,path+[key])
  elif isinstance(value,list):
   for i,child in enumerate(value):collect(child,path+[i])
 collect(priorcp,[])
 def nonmatching_runs(matched):
  out=[];start=None
  for ordinal in range(len(scalars)):
   if ordinal not in matched:
    if start is None:start=ordinal
   elif start is not None:out.append([start,ordinal]);start=None
  if start is not None:out.append([start,len(scalars)])
  return out
 consumed=[];exactrefs=0;substringrefs=0;allscalarmatches=0;alloccurrences=0
 for ordinal,reference in enumerate(refs):
  matches=[];exact=[];hitpositions=set()
  for scalar in scalars:
   text=scalar['original_scalar_PRIVATE'];positions=[];start=0
   while True:
    pos=text.find(reference,start)
    if pos<0:break
    positions.append(pos);start=pos+1
   if positions:
    try:bytepositions=[len(text[:pos].encode('utf-8','surrogatepass')) for pos in positions];bytelength=len(reference.encode('utf-8','surrogatepass'));error=None
    except UnicodeEncodeError as e:bytepositions=None;bytelength=None;error={'kind':type(e).__name__,'start':e.start,'end':e.end,'reason':e.reason}
    row={'prior_CP_scalar_ordinal_ZERO_based':scalar['ordinal_ZERO_based'],'original_scalar_location':scalar['location'],'original_scalar_PRIVATE':text,'candidate_exact_scalar_equality':text==reference,'ALL_overlapping_character_offsets_ZERO_based':positions,'ALL_overlapping_UTF8surrogatepass_SCALAR_byte_offsets_ZERO_based':bytepositions,'candidate_character_length':len(reference),'candidate_UTF8surrogatepass_SCALAR_byte_length_UNMEASURED_if_unencodable':bytelength,'UTF8_offset_encoding_error_UNMEASURED_if_valid':error};matches.append(row);hitpositions.add(scalar['ordinal_ZERO_based']);alloccurrences+=len(positions)
    if text==reference:exact.append(scalar['ordinal_ZERO_based'])
  exactrefs+=bool(exact);substringrefs+=bool(matches);allscalarmatches+=len(matches)
  consumed.append({'NEW_directory_scope_position_ONE_based':ordinal+1,'NEW_express_lexical_candidate_TEXT':reference,'original_directory_relation_position_ONE_based':ordinal+1,'new_full_reference_CP_comparison_performed':True,'exact_scalar_match_count':len(exact),'exact_scalar_match_original_ordinals_ZERO_based':exact,'substring_scalar_match_count':len(matches),'ALL_matching_prior_CP_scalars_PRIVATE':matches,'ALL_nonmatching_prior_CP_scalar_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':nonmatching_runs(hitpositions),'unperformed_readlink_comparison_count':None,'unperformed_readlink_matches':None,'unperformed_readlink_nonmatches':None,'alias_identity':None,'query_permission_from_matches_or_nonmatches':None})
 assert len(consumed)==len(refs)==29 and len(bindings)==3
 summary={'source_metadata_run_id':42403777505,'source_metadata_revision':'c4b4e6b2d7bce853d008b9c91cccb811088ad6ed','ALL2308_original_entries_preserved':2308,'original_mode_regular':2279,'ALL29_original_mode_directory_scope_candidates':29,'NEW0_symlink_rawlink_records_THISdataset':0,'ALL29_unperformed_readlink_counts_lists_NULL':True,'ALL199_original_parent_query_epochs_preserved':199,'private_scope_bytes':len(privateraw),'private_scope_sha256':hashlib.sha256(privateraw).hexdigest(),'explicitly_derived_public_safe_source_bytes':len(publicraw),'explicitly_derived_public_safe_source_sha256':hashlib.sha256(publicraw).hexdigest(),'prior_checkpoint_ALL_string_scalar_VALUES':len(scalars),'new_directory_refs_with_exact_scalar_matches':exactrefs,'new_directory_refs_without_exact_scalar_matches':29-exactrefs,'new_directory_refs_with_substring_scalar_matches':substringrefs,'new_directory_refs_without_substring_scalar_matches':29-substringrefs,'all_matching_scalar_relations':allscalarmatches,'all_overlapping_matching_occurrences':alloccurrences,'saved_metadata_read_bindings':len(bindings),'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'new_regular_BODY_reads':0,'new_directory_queries':0,'recursive_queries':0,'candidate_executions':0,'query_permission_from_matches_or_nonmatches':None,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'NEW_ALL29_private_exact_directory_scope_PRIVATE':private_scope,'NEW_ALL29_explicitly_derived_public_safe_scope':public_scope,'ALL29_NEW_fullreference_prior_CP_relationships_PRIVATE':consumed,'original2308_ALL_fields_PRIVATE_preserved':original,'current9026_descriptor_ALLfields_UNCHANGED':currentdescriptor,'ALL_prior_CP_scalars_PRIVATE':scalars,'ALL_three_savedmetadata_read_bindings_PRIVATE_fullstat_times':bindings}
 raw=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL29-directory-scope-consumption-intake-PRIVATE.json',raw);descriptor={'result_saved':'ROOT-FIRST-ALL29-directory-scope-consumption-intake-PRIVATE.json','result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-scope-result.json',before);d=json.loads(before);d['actions_include_great_great_grandchild_directory_scope_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL29_directory_lexicalscope_and_priorCP_fullreference_relationships_NOT_queried_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(raw),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_grandchild_directory_scope='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST boundedsummary-publication fromoriginalnewALL29directoryscope/fullreferenceCPresult ONLY; no SDKquery-bodyreads-parser/oldsource-model-Actionsacquisition-archive-numerical replay/Source20-runtime adoption-build-cleanup. All29dirsDEFERRED/alloriginal2308fields-stat-times-199epochs-prior6and18links-oldncursesrawhexNULL unchanged/noquerypermission fromCPcounts/allsetupUNADMITTED/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
