import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-runtime-epoch-package-v1");D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-original-path-bootstrap-gaps'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').open('x').write(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').open('x').write(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait()
  for name,raw in [('stdout',out),('stderr',err)]:(q/f'{i}-{name}.bin').open('xb').write(raw)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/f'{i}-result.json').open('x').write(json.dumps(commands[-1]))
  assert status==0,(argv,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='ed93433d5f3861657a3ffc07c1e0f1e965d980f9'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 ass=json.loads((P/'ROOT-assessment.json').read_text())
 files=[f for f in sorted(P.rglob('*')) if stat.S_ISREG(f.lstat().st_mode) and not f.relative_to(P).as_posix().startswith(('docs-publication/','LOCAL-ONLY/'))]
 excluded=[dict(path=x['body_retained_LOCAL_ONLY'],size=x['size'],sha256=x['sha256'],reason='external SDK input body retained LOCAL ONLY') for x in ass['input_observations']['rows'] if x['present']]
 model_before=json.loads((P/'model-summary/command-before.json').read_text());excluded.append(dict(path='LOCAL-ONLY/model-context.txt',size=model_before['input_chars'],sha256=model_before['input_sha256'],reason='source-bearing model input LOCAL ONLY'))
 assert {x['path'] for x in excluded}=={f.relative_to(P).as_posix() for f in (P/'LOCAL-ONLY').iterdir() if f.is_file()}
 selected=dict(excluded_LOCALONLY=excluded,selected=[dict(path=f.relative_to(P).as_posix(),size=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in files],scope='NEW selected SDK bootstrap gaps metadata only; external bodies LOCALONLY; no prior source package/archive opened; later bookkeeping excluded')
 mp=P/'selected-member-manifest.json';mp.open('x').write(json.dumps(selected,indent=2)+'\n');files.append(mp)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
  for f in files:tar.add(f,arcname=f.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  ms=tar.getmembers();assert len(ms)==len(files) and len({x.name for x in ms})==len(ms) and all(x.isfile() for x in ms)
  for member in ms:assert tar.extractfile(member).read()==(P/member.name).read_bytes()
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 ass['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(files),all_selected_BYTEEXACT=True)
 (D/(prefix+'-assessment.json')).write_text(json.dumps(ass,indent=2)+'\n')
 (D/(prefix+'-preparation.md')).write_text((P/'public-preparation.md').read_text()+'\nThe evidence archive contains '+str(len(files))+' selected regular members, all verified byte-exact. Evidence archive SHA256: '+digest+'. Later publication/readback bookkeeping is outside this snapshot.\n')
 common="## 2026-11-05 — Record selected bootstrap gaps without invoking the SDK\n\nSeven previously unbound SDK input files are present and retained in full locally; the selected optional bootstrap script is absent. The observations include the tool snapshot, pubspec/lock, content-aware-hash script, realm and a symbolic Git HEAD with its single loose ref. Copied SHA/size readback matches. No SDK or Git CLI was invoked, and external SDK bodies remain outside the public archive.\n\nThe new hash-script inspection identifies conditional Git branch/remote/merge-base, shallow/CI, Git-version and tree/object obligations. The HEAD token and six absent administrative environment names establish file data only. They do not describe original benchmark workers, prove no updater writes or join the local SDK to the original Linux cohort. Gemma's bounded summary is complete and ROOT-qualified.\n\nThere were no Source/test edits, current helper/HEAD refresh, tests, bootstrap, build, native workload or capture. Original first lock/configuration generation and complete actor/FD ownership remain pending before any SDK invocation. Admission, RAM repair, final strict 48/50 and clean final CI remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text();(q/(path.name+'-before.txt')).open('x').write(old);assert common.splitlines()[0] not in old
  name='2026-11-05-flatbuffers-native-perf-original-path-bootstrap-gaps'
  block=common+'[Declaration and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05');new=old[:pos]+block+old[pos:];path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 assert {x[3:] for x in git(['status','--porcelain','--untracked-files=all']).decode().splitlines()}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: retain selected bootstrap input gaps without SDK launch'])
 head=git(['rev-parse','HEAD']).decode().strip();git(['push','origin','codex/flatbuffers-acceptance-status']);assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(files),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 (P/'publication-readback.json').open('x').write(json.dumps(receipt,indent=2)+'\n')
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']
 n['original_path_bootstrap_gaps']=dict(directory=str(P),declaration=str(P/'declaration.json'),input_result=str(P/'input-gap-result.json'),ROOT_assessment=str(P/'ROOT-assessment.json'),publication=receipt,present=7,selected_absent=1,retained_LOCALONLY_bytes=48517062,Source_test_edits=False,SourceHEAD_current20_not_refreshed=True,SDK_Git_CLI_bootstrap_test_build_native_capture_adoption=False,model=ass['model'],docs_pending=False,descriptions_pending=True,automation_pending=True,full_admission=False)
 constraints=n['next'][n['next'].index('\nNeed '):];n['next']='Next NEW combined first-lock/configuration-generation and transitive-actor declaration for original bin/bootstrap and canonical recipes, tied to current20 candidate717a1c and tracked601 opaque reference. Identify pub get/transport metadata/bench lock generation and complete command-interpreter-delegate-descendant/FD ownership before ANY SDK/bootstrap/build call. New selectedSDKgaps are FILEDATA ONLY:7present1selected-absent bootstrap.sh,48517062B local retained, snapshot48487312B SHA6ef8e2cd2477544e26c192623cc7710a88e5d0169d362511687a4bf0d78340be; SDK.gitHEAD loose stable token6655482ec06e547f90abf8ae7590466f4415978d NOTGitobject-cleanliness/loadedimage proof. Currentadministrative6envnamesabsent NOToriginaldriver/effectivemode. Newlyretained content-aware script uses Git branch/upstream-or-origin/conditionalmergebase/shallow-LUCI/Gitversion/ls-tree selectedDEPS-engine-release-marker/hash-object: commandsUNEXECUTED/no completeinputclosure. Historical laterupdaterwrite obligations remain; optionalbootstrapabsence NOTnoupdate. Gemma53493=0/1478out321err/fullanswer-BOTH EOF-reaped/ROOTqualified, toolrebuildpurpose qualified/originfallback+CIinputs retained. SevenfullSDKbodies+modelinputLOCALONLY excludedpublic. No currentSourceHEAD20refresh, Source/test edits, SDK/GitCLI/bootstrap/pub/cargo/rustup/tests/build/nativeworkload/kernel/broker/benchmarkcapture/adoption-Sourcecommitpush-strictdispatch, oldSDKwrapper-stamp-model-sourcepackage-archive-suite-campaign/cleanup replay, environment/SDK/host/credentials/flags changes or transplant. Current20remain2b7454/6594f3 previouspackagedDATA/uncommitteduncanonicalunadmitted; providerABSENT/controllerCLOSED/ownershipNone/flagsFalse/RAMrepair-finalstrict48/50-cleanCI incomplete. All pointstats-bytehashes notatomicABA/origin-auth/physicalEX-originalLinux/fullFD-interpreter-delegate-descendantclosure/immutableCOMPLETEadmission. No SourceeditwithoutmeaningfulactualBEFOREfail/no startup-build-captureapproval fromfiledata.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Original_PATH_bootstrap_gaps_7present1selectedAbsent_FILEDATA_docs_pushed_admin_pending');cp.write_text(json.dumps(c,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(docs_commit=head,evidence_archive_sha256=digest,evidence_members=len(files),selected_present=7,selected_absent=1,admission=False)))
