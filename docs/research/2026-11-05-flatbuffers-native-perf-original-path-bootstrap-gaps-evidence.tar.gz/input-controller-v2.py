import sys,pathlib,json,hashlib,os,stat,datetime,re
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-original-path-bootstrap-gaps-v1");SDK=pathlib.Path('/Users/konsultaner/flutter/flutter')
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def ident(s):return dict(dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,flags=getattr(s,'st_flags',None))
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();q=P/'acquisition';q.mkdir();local=P/'LOCAL-ONLY';local.mkdir();declaration=json.loads((P/'declaration.json').read_text());rows=[];total=0
 def acquire(relative):
  global total
  i=len(rows);path=SDK/relative;write(q/f'{i}-attempt-before.json',dict(relative=relative,operation='lstat then regular nofollow streaming read',sdk_process_started=False))
  try:a=path.lstat()
  except FileNotFoundError as exc:
   row=dict(relative=relative,present=False,error=dict(type=type(exc).__name__,errno=exc.errno,text=str(exc)),selected_absence_only=True);rows.append(row);write(q/f'{i}-result.json',row);return row,None
  assert stat.S_ISREG(a.st_mode),str(path);assert a.st_size<=declaration['per_file_cap'] and total+a.st_size<=declaration['total_retained_cap']
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
  h=hashlib.sha256();count=0;retained=local/f'{i:02d}-{path.name}'
  try:
   write(q/f'{i}-opened-before-read.json',dict(relative=relative,fd=fd,operation_registered=True))
   opened=os.fstat(fd);assert ident(opened)==ident(a)
   with retained.open('xb') as dest:
    while True:
     raw=os.read(fd,1024**2)
     if not raw:break
     count+=len(raw);assert count<=declaration['per_file_cap'] and total+count<=declaration['total_retained_cap']
     h.update(raw);dest.write(raw)
   after=os.fstat(fd);end=path.lstat();assert ident(a)==ident(after)==ident(end) and count==a.st_size
  finally:os.close(fd)
  check=hashlib.sha256();size=0
  with retained.open('rb') as f:
   while True:
    raw=f.read(1024**2)
    if not raw:break
    check.update(raw);size+=len(raw)
  assert size==count and check.hexdigest()==h.hexdigest();total+=count
  row=dict(relative=relative,present=True,kind='regular',size=count,sha256=h.hexdigest(),before=ident(a),opened=ident(opened),after=ident(after),path_after=ident(end),body_retained_LOCAL_ONLY=retained.relative_to(P).as_posix(),retained_readback_SHA_size_exact=True,descriptor_closed_by_own_reader=True,point_data_NOT_atomic_or_runtime_immutable=True)
  rows.append(row);write(q/f'{i}-result.json',row);return row,retained
 retained={}
 for relative in declaration['fixed_relative_inputs']:
  row,copy=acquire(relative)
  if copy is not None:retained[relative]=copy
 head=dict(status='UNRESOLVED',actual_git_CLI=False,object_database_read=False,commit_content_or_cleanliness_proved=False)
 if '.git/HEAD' in retained:
  raw=retained['.git/HEAD'].read_bytes();assert len(raw)<=4096
  value=raw.decode('ascii').strip()
  if re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}',value):head.update(status='detached_commit_token_FILEDATA',commit_token=value)
  elif value.startswith('ref: '):
   ref=value[5:];assert re.fullmatch(r'refs/(heads|tags)/[A-Za-z0-9_./-]+',ref) and '..' not in ref and not ref.endswith('/')
   row,copy=acquire('.git/'+ref)
   head['symbolic_ref']=ref
   if copy is not None:
    token=copy.read_text().strip();assert re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}',token);head.update(status='loose_ref_commit_token_FILEDATA',commit_token=token)
   else:
    row,copy=acquire('.git/packed-refs')
    if copy is not None:
     matches=[]
     for line in copy.read_text().splitlines():
      if not line or line[0] in '#^':continue
      fields=line.split(' ')
      if len(fields)==2 and fields[1]==ref:matches.append(fields[0])
     assert len(matches)<=1
     if matches:
      assert re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}',matches[0]);head.update(status='packed_ref_commit_token_FILEDATA',commit_token=matches[0])
  else:head['status']='unknown_HEAD_format_FILEDATA'
 env={key:dict(present=key in os.environ,size=len(os.environ[key].encode()) if key in os.environ else None,sha256=hashlib.sha256(os.environ[key].encode()).hexdigest() if key in os.environ else None) for key in declaration['environment_filedata_only']}
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='SELECTED_BOOTSTRAP_GAPS_FILEDATA_NOT_EXECUTION_ADMISSION',sdk_root_preselected=str(SDK),candidate_reference=declaration['candidate_reference'],rows=rows,present=sum(x['present'] for x in rows),selected_absent=sum(not x['present'] for x in rows),total_retained_bytes=total,Git_HEAD=head,current_administrative_environment_presence_hashes_NOT_original_driver=env,SourceR_HEAD_current20_refreshed=False,SDK_CLI_GitCLI_bootstrap_test_build_native_capture_adoption=False,external_source_bodies_LOCALONLY=True,old_SDK_stamp_wrapper_archive_model_replay=False,SDK_mutation_requested=False,full_input_closure=False,immutable_runtime=False,physical_EX_originalLinux_actorFD_closure=False,admission=False)
 write(P/'input-gap-result.json',result);lease.verify_identity();print(json.dumps(dict(present=result['present'],selected_absent=result['selected_absent'],total_retained_bytes=total,Git_HEAD_status=head['status'],admission=False)))
