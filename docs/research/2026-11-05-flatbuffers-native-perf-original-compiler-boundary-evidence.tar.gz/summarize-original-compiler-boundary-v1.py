import os,json,hashlib,importlib.util,subprocess,time
from pathlib import Path
P=Path('/tmp/connectanum-native-perf-original-compiler-boundary-v1')
H=Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
hb=H.read_bytes();st=H.stat()
assert (st.st_uid,st.st_gid,len(hb),hashlib.sha256(hb).hexdigest())==(501,20,35983,'d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8')
s=importlib.util.spec_from_file_location('boundary_model_companion',H);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def put(n,o):
 with (P/n).open('x') as f:json.dump(o,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 inp=(P/'selected-build-context-model-input.LOCAL-ONLY.txt').read_bytes()
 cmd=['python3',str(H),'summarize','--stdin','--provider','ollama','--num-predict','1536','--timeout','180','--max-input-chars','40000','--save-output',str(P/'gemma-original-compiler-boundary-answer.txt')]
 put('model-command-before.json',{'argv':cmd,'input_sha256':hashlib.sha256(inp).hexdigest(),'input_bytes':len(inp),'role':'NEW historical compiler-boundary summary only, advisory','launch_attempt_pending':True})
 child=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd='/tmp')
 put('model-original-handle-before-IO.json',{'pid':child.pid,'stdin_fd':child.stdin.fileno(),'stdout_fd':child.stdout.fileno(),'stderr_fd':child.stderr.fileno()})
 out,err=child.communicate(inp)
 rc=child.wait(timeout=10)
 for n,b in [('gemma-stdout.raw',out),('gemma-stderr.raw',err)]:
  with (P/n).open('xb') as f:f.write(b)
 put('model-native-completion.json',{'pid':child.pid,'signed_status':rc,'wait_same_original':True,'wait_may_be_cached':True,'communicate_once':True,'both_eof':True,'stdout_size':len(out),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_size':len(err),'stderr_sha256':hashlib.sha256(err).hexdigest(),'approval':False})
 lease.verify_identity()
 print(json.dumps({'pid':child.pid,'status':rc,'stdout_bytes':len(out),'stderr_bytes':len(err)}))
 print(out.decode('utf-8',errors='replace'))
 print(err.decode('utf-8',errors='replace'))
