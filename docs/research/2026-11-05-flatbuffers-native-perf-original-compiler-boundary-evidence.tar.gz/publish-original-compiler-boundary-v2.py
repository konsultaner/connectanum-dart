import os,json,hashlib,importlib.util,subprocess,tarfile,io,datetime
from pathlib import Path
P=Path('/tmp/connectanum-native-perf-original-compiler-boundary-v1')
A=P/'publication-v2'
A.mkdir()
def put(p,o):
 with p.open('x') as f:json.dump(o,f,indent=2);f.write('\n')
put(A/'declaration.json',{'scope':'DOCS ONLY NEW original compiler-boundary FILEDATA','expected_docs_HEAD':'4b47c4f5f7c3b3f4c1fec6ac89d05d849b8a79e8','branch':'codex/flatbuffers-acceptance-status','production_changes':False,'prior_controller':'JS parser SyntaxError Unexpected identifier ubuntu24 before any nested tool call, controller save, namespace, Git or archive; no omitted unsaved draft reconstructed.'})
H=Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
hb=H.read_bytes();hs=H.stat()
assert(hs.st_uid,hs.st_gid,len(hb),hashlib.sha256(hb).hexdigest())==(501,20,35983,'d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8')
sp=importlib.util.spec_from_file_location('boundary_publish_companion',H);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
D=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
rows=[]
def git(args):
 i=len(rows);argv=['git']+args
 put(A/('git-%02d-before.json'%i),{'argv':argv,'cwd':str(D),'launch_attempt_pending':True})
 c=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 put(A/('git-%02d-original-handle-before-IO.json'%i),{'pid':c.pid,'stdout_fd':c.stdout.fileno(),'stderr_fd':c.stderr.fileno()})
 out,err=c.communicate();rc=c.wait(timeout=10)
 for n,b in [('stdout',out),('stderr',err)]:
  with(A/('git-%02d-%s.raw'%(i,n))).open('xb') as f:f.write(b)
 row={'argv':argv,'pid':c.pid,'signed_status':rc,'wait_same_original':True,'wait_may_be_cached':True,'both_EOF':True,'stdout_size':len(out),'stderr_size':len(err),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()}
 rows.append(row);put(A/('git-%02d-completion.json'%i),row)
 if rc!=0:raise RuntimeError('Git refused; namespace terminal')
 return out
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 if git(['rev-parse','HEAD']).decode().strip()!='4b47c4f5f7c3b3f4c1fec6ac89d05d849b8a79e8':raise RuntimeError('docs HEAD changed')
 if git(['branch','--show-current']).decode().strip()!='codex/flatbuffers-acceptance-status':raise RuntimeError('wrong docs branch')
 if git(['status','--porcelain','--untracked-files=all']):raise RuntimeError('docs WT dirty')
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 prep=(P/'preparation-draft.md').read_bytes()
 local=[];selected=[]
 for p in sorted(P.iterdir()):
  if not p.is_file():continue
  b=p.read_bytes();row={'name':p.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  if 'LOCAL-ONLY' in p.name:local.append(row)
  else:selected.append((p.name,b,row))
 localindex=(json.dumps({'scope':'Hashes of NEW saved LOCAL ONLY observations/copies/model input/tool objects; not original runtime binding','files':local},indent=2)+'\n').encode()
 with(P/'local-only-evidence-index.json').open('xb') as f:f.write(localindex)
 selected.append(('local-only-evidence-index.json',localindex,{'name':'local-only-evidence-index.json','size':len(localindex),'sha256':hashlib.sha256(localindex).hexdigest()}))
 manifest=(json.dumps({'scope':'NEW original601 compiler-boundary retained FILEDATA/model/ROOT qualification; zero SDK or native execution','selected':[r for n,b,r in selected],'excluded_local_only':local,'publisher_parser_failure':'v1 JavaScript parse before nested tools; v2 first publication'},indent=2)+'\n').encode()
 with(P/'selected-members-manifest.json').open('xb') as f:f.write(manifest)
 selected.append(('selected-members-manifest.json',manifest,{'name':'selected-members-manifest.json','size':len(manifest),'sha256':hashlib.sha256(manifest).hexdigest()}))
 tarpath=A/'evidence.tar.gz'
 with tarfile.open(tarpath,'x:gz') as tf:
  for n,b,r in selected:
   ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o644;ti.mtime=0
   tf.addfile(ti,io.BytesIO(b))
 with tarfile.open(tarpath,'r:gz') as tf:
  members=tf.getmembers()
  if len(members)!=len(selected) or any(not x.isfile() for x in members):raise RuntimeError('archive shape')
  for member,(n,b,r) in zip(members,selected):
   if member.name!=n or tf.extractfile(member).read()!=b:raise RuntimeError('archive BYTEEXACT readback')
 archive=tarpath.read_bytes();archive_sha=hashlib.sha256(archive).hexdigest()
 prefix='docs/research/2026-11-05-flatbuffers-native-perf-original-compiler-boundary'
 files=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 for rel,b in [(files[2],prep),(files[3],(P/'ROOT-assessment.json').read_bytes()),(files[4],archive)]:
  with(D/rel).open('xb') as f:f.write(b)
  if(D/rel).read_bytes()!=b:raise RuntimeError('new docs readback')
 common="""## 2026-11-05 — Locate original compiler context in retained setup text

A new acquisition reads only three retained original601 setup texts, totaling 30,956 bytes. The host text reports runner image ubuntu24/20261026.354.1, Linux 7.0.0-1017-azure, Dart 3.13.5 and rustc 1.99.0 (b940084d7 2026-09-28). Native and driver logs record their release compilations. Full text copies and model input remain local; sizes, hashes and qualifications are published.

These historical labels do not bind actual compiler/linker images, target ABI, headers/sysroots, runtime/loader, full argv/env/credentials, current access or transitive actor/FD ownership. Apple LLVM 21 in earlier symbol metadata was an administrative inspector; the older D9CB frozen-runtime pointer and predecessor ffi-test notes cannot replace the production601 cohort.

Gemma's full natural-zero summary is ROOT-qualified against exact host/build lines. Its deprecation suggestions supply no Source fix authority. A narrow checkpoint digest search and an ANSI-sensitive line selector establish no global absence or complete compiler census.

No current20/runtime source, SDK census, compiler, disassembler, SDK/bootstrap recipe, build, native helper, test or numerical campaign ran. All admission flags stay false. Exact original-cohort input provenance/access, native actor/collector/writer mechanisms, continuous physical EX and independent generated-output authority remain unresolved. RAM repair, own final strict48/50 and clean final CI are incomplete.

See the [preparation](research/2026-11-05-flatbuffers-native-perf-original-compiler-boundary-preparation.md), [assessment](research/2026-11-05-flatbuffers-native-perf-original-compiler-boundary-assessment.json) and [evidence](research/2026-11-05-flatbuffers-native-perf-original-compiler-boundary-evidence.tar.gz). The next step must bind a permitted original-cohort input source before any compiler/disassembly/run; it must not select a replacement host or treat historical text as execution authority. Publisher v1 failed JavaScript parsing before any nested tool call; v2 is the first actual publication.

"""
 for rel in files[:2]:
  p=D/rel;old=p.read_bytes();at=old.index(b'## ')
  c=common if rel==files[0] else common.replace('(research/','(../research/')
  new=old[:at]+c.encode()+old[at:]
  with(A/(p.name+'.before')).open('xb') as f:f.write(old)
  p.write_bytes(new)
  if p.read_bytes()!=new or new[:at]+new[at+len(c.encode()):]!=old:raise RuntimeError('old docs bytes changed')
 status=git(['status','--porcelain','--untracked-files=all']).decode()
 if sorted(x[3:] for x in status.splitlines())!=sorted(files):raise RuntimeError('unexpected docs paths')
 git(['add','--']+files);git(['diff','--cached','--check'])
 if sorted(git(['diff','--cached','--name-only']).decode().splitlines())!=sorted(files):raise RuntimeError('unexpected staged paths')
 git(['commit','-m','docs: locate original compiler context in retained setup'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 if git(['status','--porcelain','--untracked-files=all']):raise RuntimeError('docs dirty after push')
 receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'docs_commit':head,'archive_sha256':archive_sha,'archive_size':len(archive),'selected_regular_members':len(selected),'all_selected_BYTEEXACT':True,'docs_only_files':files,'git_commands':rows,'source20_runtime_changes':False,'actual_compiler_execution':False,'admission':False,'publisher_v1':'JS parse failure before tools; no old namespace/artifact/Git writes','publisher_v2':'first actual publication'}
 put(P/'publication-readback.json',receipt)
 cp_path=Path('/tmp/connectanum-current-task-checkpoint.json');cpb=cp_path.read_bytes()
 with(A/'checkpoint-before.json').open('xb') as f:f.write(cpb)
 cp=json.loads(cpb);n=cp['native_perf_only_diagnostic_design']
 n['original_compiler_boundary']={'directory':str(P),'ROOT_assessment':str(P/'ROOT-assessment.json'),'publication':receipt,'reported_rustc':'1.99.0 (b940084d7 2026-09-28)','reported_Dart':'3.13.5','retained_text_files':3,'retained_bytes':30956,'model_pid':75809,'model_status':0,'model_full_BOTH_EOF_ROOT_qualified':True,'new_tests':0,'actual_current_compiler_binding':False,'Source20_runtime_edits_imports':False,'HEAD_20_SDK_census_refresh':False,'capture_ready':False,'evidence_complete':False,'admission':False,'automation_pending':True,'descriptions_pending':False,'GitHub_description_update_not_needed':'Historical compiler-reference acquisition changes no production runtime/admission claim; saved description remains accurate.'}
 n['phase']='Original_compiler_boundary_FILEDATA_docs_complete_admin_pending_original_admission_incomplete'
 n['next']=assessment['next']
 cp['status_docs_commit']=head;cp['updated_utc']=receipt['utc']
 cp['active_turn_status']='Original_compiler_boundary_FILEDATA_docs_complete_automation_pending'
 cp['last_heartbeat_summary']='Three retained original601 setup texts report rustc1.99.0/Dart3.13.5 and release builds; actual original compiler/input custody remains unbound. No SDK/native/tests/campaign execution.'
 cp_path.write_text(json.dumps(cp,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps({k:receipt[k] for k in ('docs_commit','archive_sha256','selected_regular_members','all_selected_BYTEEXACT','admission')}))
