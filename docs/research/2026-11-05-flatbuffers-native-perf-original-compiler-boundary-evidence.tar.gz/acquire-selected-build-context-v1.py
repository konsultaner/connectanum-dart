import os,stat,json,hashlib,importlib.util
from pathlib import Path
P=Path('/tmp/connectanum-native-perf-original-compiler-boundary-v1')
H=Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
hb=H.read_bytes();hs=H.stat()
assert (hs.st_uid,hs.st_gid,len(hb),hashlib.sha256(hb).hexdigest())==(501,20,35983,'d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8')
sp=importlib.util.spec_from_file_location('boundary_context_companion',H);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def put(n,o):
 with (P/n).open('x') as f: json.dump(o,f,indent=2);f.write('\n')
def ident(s):
 return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 paths=[Path('/tmp/connectanum-601-primary/extracted/setup')/x for x in ('host-info.txt','native-build.log','driver-build.log')]
 put('selected-build-context-acquisition-before.json',{'question':'NEW original production compiler/input boundary, not old numerical audit','paths':[str(x) for x in paths],'max_total_bytes':40000,'scope':'Retained setup text only. No binaries, digests, locks, bootstrap, campaign, run polling, or tool execution. Historical logs do not bind actual current compiler FD, original cohort authority, immutable runtime or admission.'})
 held=[];raw=[]
 try:
  for i,p in enumerate(paths):
   fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);held.append(fd)
   before=os.fstat(fd)
   put('selected-build-context-FD-before-read-%d.json'%i,{'path':str(p),'fd':fd,'identity':ident(before)})
   if not stat.S_ISREG(before.st_mode) or before.st_size>40000:raise RuntimeError('refused selected input')
   chunks=[]
   while True:
    c=os.read(fd,65536)
    if not c:break
    chunks.append(c)
   b=b''.join(chunks);after=os.fstat(fd);path_after=os.stat(p,follow_symlinks=False)
   if len(b)!=before.st_size or ident(before)!=ident(after) or ident(after)!=ident(path_after):raise RuntimeError('point identity changed')
   raw.append((p,b,before,after,path_after))
  if sum(len(b) for p,b,*_ in raw)>40000:raise RuntimeError('total input cap')
  rows=[]
  for i,(p,b,before,after,pa) in enumerate(raw):
   dest=P/(p.name+'.LOCAL-ONLY')
   with dest.open('xb') as f:f.write(b)
   with dest.open('rb') as f:copy=f.read()
   if copy!=b:raise RuntimeError('copy readback')
   rows.append({'path':str(p),'copy':str(dest),'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'before':ident(before),'after':ident(after),'path_after':ident(pa),'copy_byte_exact':True,'eof_observed':True})
  context='NEW QUESTION: Identify only original compiler/build input boundary clues in these retained original601 setup texts. Separate reported tool versions, actual build command/output, target/host facts, input generation and missing identity/ABI/runtime/credentials/access/cohort/actor-FD bindings. Historical text labels are not compiler image hashes, current original-runtime access, ownership, immutable admission or permission to compile/run. Apple LLVM from a previous static-symbol metadata file was an ADMINISTRATIVE inspection tool, not the original Linux compiler. Do not infer compiler from it. Do not analyze numerical benchmark results, suggest reruns, borrow local host/toolchain, change SDK/flags/cohort, or claim absence beyond these three texts. Give concise exact line-numbered clues and limits, then a next read-only acquisition boundary if supported. No command execution is authorized.\n'
  for p,b,*_ in raw:
   context+='\n=== '+p.name+' ===\n'+''.join(str(j+1)+': '+line+'\n' for j,line in enumerate(b.decode('utf-8').splitlines()))
  with (P/'selected-build-context-model-input.LOCAL-ONLY.txt').open('x') as f:f.write(context)
  put('selected-build-context-acquisition-actual-LOCAL-ONLY.json',{'rows':rows,'total_bytes':sum(len(b) for p,b,*_ in raw),'model_input_chars':len(context),'scope':'Historical retained text, no compiler invocation or current input closure.'})
  print(json.dumps({'files':[{'name':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b,*_ in raw],'model_input_chars':len(context)}))
 finally:
  for i,fd in enumerate(held):
   os.close(fd)
   put('selected-build-context-close-%d.json'%i,{'fd':fd,'actual_close_returned':True})
 lease.verify_identity()
