"""OWN non-benchmark producer fixtures; never real canonical/build admission."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import native_perf_build_producer as producer


def digest(data):
    return hashlib.sha256(data).hexdigest()


class ProducerTests(unittest.TestCase):
    def setUp(self):
        evidence = os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:
            Path(evidence).mkdir(exist_ok=True)
        self.base = Path(tempfile.mkdtemp(prefix='producer-', dir=evidence)).resolve()
        self.repo = self.base / 'repo'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.email', 'fixture@example.invalid')
        self.git('config', 'user.name', 'Owned Fixture')
        (self.repo / '.gitignore').write_text('inputs/\n')
        (self.repo / 'worker.py').write_text("""import os,sys,time,signal
from pathlib import Path
mode=sys.argv[1]
if mode=='sleep':
    Path(sys.argv[2]).write_text('running')
    time.sleep(0.12)
elif mode=='drift':
    Path(sys.argv[2]).write_text('changed')
    time.sleep(0.08)
    Path(sys.argv[3]).write_text('natural-exit')
elif mode=='large':
    os.write(1,b'A'*9000);os.write(2,b'B'*7000)
elif mode=='nonzero':
    print('failed-with-bytes',flush=True);sys.exit(7)
elif mode=='signal':
    print('before-signal',flush=True);os.kill(os.getpid(),signal.SIGTERM)
elif mode=='environment':
    assert os.environ['PERF_FIXTURE_SECRET']=='preserved-value'
    print('environment-preserved')
else:
    print('fixture-ok')
""")
        self.git('add', '.')
        self.git('commit', '-qm', 'tiny owned fixture')
        self.head = self.git('rev-parse', 'HEAD').decode().strip()
        self.archive_sha = digest(self.git('archive', '--format=tar', self.head))
        self.inputs = {}
        for name in ('pub', 'transport', 'bench', 'package_config'):
            path = self.repo / 'inputs' / name
            path.parent.mkdir(exist_ok=True)
            path.write_text('fixture-' + name)
            self.inputs['inputs/' + name] = digest(path.read_bytes())
        self.runs = []

    def tearDown(self):
        for run in self.runs:
            if run.pending:
                if run.finished:
                    status=run.process.wait(2)
                    run._end_command(status)
                    if run.events is not None:run.events.close();run.events=None
                    (self.base/'fixture-fallback-reaped.json').write_text(json.dumps({'pid':run.child_pid,'status':status,'scope':'OWN finite fixture teardown only; no live controller workaround'}))
                else:
                    run.wait(2)
        # Evidence deliberately remains, including failed/partial source archives.

    def git(self, *args):
        return subprocess.check_output(['git', '-C', str(self.repo), *args], stderr=subprocess.PIPE)

    def start(self, *modes, **overrides):
        kwargs = dict(repo=self.repo, source_commit=self.head, runtime_commit=self.head,
                      run_dir=self.base / 'run', expected_archive_sha256=self.archive_sha,
                      inputs=self.inputs, commands=[[sys.executable, 'worker.py', *mode] for mode in modes],
                      lease_check=lambda: None)
        kwargs.update(overrides)
        run = producer.start_fixture(**kwargs)
        self.runs.append(run)
        return run

    def finish(self, run):
        result = run.wait(2)
        self.assertIsNotNone(result)
        return result

    def test_positive_exact_source_commands_and_output_bytes(self):
        run = self.start(('large',), ('ok',))
        result = self.finish(run)
        self.assertEqual('fixture-command-evidence-v1', result['kind'])
        self.assertEqual('success', result['status'])
        self.assertEqual(2, len(result['commands']))
        raw = (self.base / 'run' / 'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000, raw)
        self.assertEqual(digest(raw), result['commands'][0]['log_sha256'])
        self.assertEqual(self.archive_sha, result['source_archive_sha256'])
        self.assertFalse(result['capture_ready'])

    def test_existing_run_directory_is_terminal_before_any_command(self):
        directory=self.base/'run';directory.mkdir();(directory/'partial').write_bytes(b'keep')
        with self.assertRaises(FileExistsError): self.start(('ok',))
        self.assertEqual(['partial'], [p.name for p in directory.iterdir()])

    def test_completed_run_cannot_run_again(self):
        run=self.start(('ok',));self.finish(run)
        before={p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()}
        with self.assertRaises(producer.ProducerError):run.wait(0)
        with self.assertRaises(FileExistsError):self.start(('ok',))
        self.assertEqual(before,{p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()})

    def test_nonzero_exit_preserves_log_and_prevents_next_command(self):
        result=self.finish(self.start(('nonzero',),('ok',)))
        self.assertEqual('failed',result['status']);self.assertEqual(7,result['commands'][0]['returncode'])
        self.assertEqual(1,len(result['commands']));self.assertIn(b'failed-with-bytes',(self.base/'run'/'command-000.log').read_bytes())

    def test_negative_signal_status_is_not_success(self):
        result=self.finish(self.start(('signal',)))
        self.assertEqual(-signal.SIGTERM,result['commands'][0]['returncode']);self.assertEqual('failed',result['status'])
        self.assertIn(b'before-signal',(self.base/'run'/'command-000.log').read_bytes())

    def test_spawn_failure_retains_null_status_no_retry(self):
        run=self.start(('ok',),commands=[['/nonexistent/owned-fixture-command']])
        result=run.result
        self.assertEqual('failed',result['status']);self.assertIsNone(result['commands'][0]['returncode'])
        self.assertIn('FileNotFoundError',result['commands'][0]['spawn_error'])

    def test_timeout_only_waits_same_owned_process(self):
        run=self.start(('sleep',str(self.base/'started')))
        pid=run.child_pid;self.assertIsNone(run.wait(0));self.assertEqual(pid,run.child_pid)
        result=self.finish(run);self.assertEqual('success',result['status']);self.assertEqual(1,len(result['commands']))

    def test_input_drift_waits_for_natural_child_exit(self):
        done=self.base/'done'
        result=self.finish(self.start(('drift',str(self.repo/'inputs/pub'),str(done))))
        self.assertEqual('natural-exit',done.read_text());self.assertEqual('failed',result['status'])
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertIn('input',result['error'])

    def test_dirty_source_refused_before_command(self):
        (self.repo/'worker.py').write_text('raise SystemExit(99)')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'failure.json').is_file())

    def test_wrong_archive_refused_before_command(self):
        with self.assertRaises(producer.ProducerError):self.start(('ok',),expected_archive_sha256='0'*64)
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'source.tar').is_file())

    def test_head_drift_refused_before_command(self):
        (self.repo/'extra').write_text('new');self.git('add','.');self.git('commit','-qm','new')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_input_symlink_refused(self):
        p=self.repo/'inputs/pub';p.rename(self.repo/'inputs/old');p.symlink_to('old')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_lease_refusal_before_reservation(self):
        def refuse():raise RuntimeError('lease unavailable')
        with self.assertRaisesRegex(RuntimeError,'lease unavailable'):self.start(('ok',),lease_check=refuse)
        self.assertFalse((self.base/'run').exists())

    def test_environment_inherited_without_values_in_metadata(self):
        old=os.environ.get('PERF_FIXTURE_SECRET');os.environ['PERF_FIXTURE_SECRET']='preserved-value'
        try: result=self.finish(self.start(('environment',)))
        finally:
            if old is None:os.environ.pop('PERF_FIXTURE_SECRET')
            else:os.environ['PERF_FIXTURE_SECRET']=old
        self.assertEqual('success',result['status'])
        for p in (self.base/'run').glob('*.json*'):self.assertNotIn('preserved-value',p.read_text())

    def test_source_archive_members_match_committed_bytes(self):
        result=self.finish(self.start(('ok',)))
        self.assertEqual(self.head,result['source_commit'])
        self.assertEqual(2,result['source_entries'])
        self.assertEqual(self.git('archive','--format=tar',self.head),(self.base/'run'/'source.tar').read_bytes())

    def test_mutating_caller_input_dictionary_does_not_change_snapshot(self):
        run=self.start(('sleep',str(self.base/'started')))
        self.inputs.clear()
        self.assertEqual('success',self.finish(run)['status'])

    def test_production_factory_refuses_nonlinux_before_reservation(self):
        if sys.platform=='linux':self.skipTest('Darwin negative only')
        with self.assertRaises(producer.ProducerError):
            producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=self.inputs,lease_check=lambda:None)
        self.assertFalse((self.base/'run').exists())

    def test_postspawn_journal_error_keeps_owned_child_waitable(self):
        original_event=producer.CommandProducer._event
        original_spawn=producer.CommandProducer._spawn
        observed=[]
        def spawn(run):
            observed.append(run)
            return original_spawn(run)
        def event(run,kind,**kwargs):
            if kind=='command_spawned':raise OSError('injected post-spawn journal fault')
            return original_event(run,kind,**kwargs)
        try:
            with mock.patch.object(producer.CommandProducer,'_spawn',spawn),mock.patch.object(producer.CommandProducer,'_event',event):
                run=self.start(('sleep',str(self.base/'started')))
            self.assertTrue(run.pending)
            result=self.finish(run)
            self.assertEqual('failed',result['status'])
            self.assertIn('injected post-spawn',result['error'])
            self.assertEqual(0,result['commands'][0]['returncode'])
        finally:
            # Actual first counterexample must retain/reap its OWN finite child.
            for run in observed:
                if run not in self.runs:self.runs.append(run)

    def test_single_wait_budget_decreases_across_commands(self):
        run=self.start(('sleep',str(self.base/'one')),('sleep',str(self.base/'two')))
        original=producer.subprocess.Popen.wait;timeouts=[]
        def waiting(child,timeout=None):
            if child.args and child.args[0]==sys.executable:timeouts.append(timeout)
            return original(child,timeout=timeout)
        with mock.patch.object(producer.subprocess.Popen,'wait',waiting):self.finish(run)
        self.assertEqual(2,len(timeouts))
        self.assertLess(timeouts[1],timeouts[0])

    def test_log_hashing_does_not_load_whole_output_into_memory(self):
        run=self.start(('large',));original=Path.read_bytes
        def read(path):
            if path.name.startswith('command-') and path.suffix=='.log':raise AssertionError('whole log read forbidden')
            return original(path)
        with mock.patch.object(Path,'read_bytes',read):result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(16000,result['commands'][0]['log_bytes'])

    def test_wait_status_retained_before_uncertain_log_close(self):
        run=self.start(('ok',));original=run.log;calls=[]
        class Fault:
            def flush(self):return original.flush()
            def fileno(self):return original.fileno()
            def close(self):
                calls.append('close');original.close();raise OSError('injected ambiguous log close')
        run.log=Fault()
        with self.assertRaisesRegex(OSError,'ambiguous log close'):run.wait(2)
        self.assertEqual(0,run.records[0]['returncode'])
        self.assertEqual(['close'],calls);self.assertIsNone(run.log)
        with self.assertRaises(producer.ProducerError):run.wait(0)
        self.assertEqual(['close'],calls)

    def test_production_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer.sys,'platform','linux'),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            result=producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,lease_check=lambda:None)
        self.assertEqual('fixture-placeholder',result)
        kwargs=cls.call_args.kwargs
        self.assertEqual([['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],kwargs['commands'])
        self.assertEqual({'CARGO_TARGET_DIR':str(self.base/'run/target')},kwargs['env_delta'])
        self.assertFalse((self.base/'run').exists())

    def test_canonical_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            producer.start_canonical(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,lease_check=lambda:None)
        self.assertEqual([['bin/verify']],cls.call_args.kwargs['commands'])
        self.assertFalse((self.base/'run').exists())

    def make_tool(self,version='1.0',mutate=False):
        directory=self.base/'tools';directory.mkdir(exist_ok=True)
        target=self.base/'real-python3'
        body="#!/bin/sh\nprintf 'Fixture %s "+version+"\\n' \"${0##*/}\"\n"
        if mutate:body+="printf '#changed\\n' >> \"$0\"\n"
        target.write_text(body);target.chmod(0o755)
        entry=directory/'python3';entry.symlink_to(target)
        return directory,entry,target

    def test_tool_entry_basename_and_fixed_version_argv_preserved(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('success',result['status'])
        self.assertEqual([str(entry),'--version'],result['commands'][0]['argv'])
        self.assertEqual('tool_version',result['commands'][0]['kind'])
        self.assertEqual('recipe',result['commands'][1]['kind'])
        self.assertEqual(str(target),result['tools']['python3']['target'])
        self.assertEqual(b'Fixture python3 1.0\n',(self.base/'run/command-000.log').read_bytes())

    def test_tool_wrong_version_preserves_raw_and_blocks_recipe(self):
        directory,entry,target=self.make_tool(version='9.0')
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('version',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])
        self.assertIn(b'9.0',(self.base/'run/command-000.log').read_bytes())

    def test_tool_path_lookup_drift_refuses_before_any_probe(self):
        directory,entry,target=self.make_tool()
        alternative=self.base/'different';alternative.mkdir();(alternative/'python3').symlink_to(target)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            with mock.patch.dict(os.environ,{'PATH':str(alternative)+os.pathsep+os.environ['PATH']}):
                with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_symlink_retarget_even_equal_bytes_refuses(self):
        directory,entry,target=self.make_tool();other=self.base/'equal-bytes';other.write_bytes(target.read_bytes());other.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            entry.unlink();entry.symlink_to(other)
            with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_mutation_during_probe_blocks_following_recipe(self):
        directory,entry,target=self.make_tool(mutate=True)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('tool',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])

    def test_tool_caller_spec_mutation_does_not_change_pinned_snapshot(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0');tools={'python3':spec}
            run=self.start(('ok',),tools=tools);spec['sha256']='0'*64;tools.clear()
            result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(hashlib.sha256(target.read_bytes()).hexdigest(),result['tools']['python3']['sha256'])

    def test_tool_unknown_name_and_empty_version_rejected(self):
        with self.assertRaises(producer.ProducerError):producer.describe_tool('untrusted-build-command','anything')
        with self.assertRaises(producer.ProducerError):producer.describe_tool('python3','')


if __name__=='__main__':unittest.main()
