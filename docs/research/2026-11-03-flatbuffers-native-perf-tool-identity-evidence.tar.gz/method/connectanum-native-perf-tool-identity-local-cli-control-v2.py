from pathlib import Path
import sys,json,hashlib,subprocess,types,shutil,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
wt=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');base=Path('/tmp/connectanum-native-perf-tool-identity-local-cli-control-v2').resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
try:
 with local_resource_lease(exclusive=True) as lease:
  lease.verify_identity();assert shutil.disk_usage(wt).free>=1024**3
  frozen=json.loads(Path('/tmp/connectanum-native-perf-build-producer-tool-fixed-tests.json').read_bytes());assert frozen['exit']==0
  assert all(sha((wt/p).read_bytes())==h for p,h in frozen['source_sha256'].items())
  source=wt/'tool/native_perf_build_producer.py';data=source.read_bytes();module=types.ModuleType('own_producer_control');module.__file__=str(source);exec(compile(data,str(source),'exec'),module.__dict__)
  prefixes={'git':'git version ','bash':'GNU bash, version ','python3':'Python '+'.'.join(map(str,sys.version_info[:3])),'dart':'Dart SDK version: 3.13.1','cargo':'cargo 1.95.0','rustc':'rustc '}
  tools={name:module.describe_tool(name,prefix) for name,prefix in prefixes.items()}
  base.mkdir(mode=0o700)
  declaration={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'ACTUAL local installed-tool --version observations plus OWN tiny Git/finite Python control ONLY; no canonical/native build/Linux/perf/VMAPI/benchmark/diagnostic capture','producer_sha256':sha(data),'controller_sha256':sha(Path(__file__).read_bytes()),'tools':tools,'source_sha256':frozen['source_sha256'],'expected_local_Dart':'3.13.1','expected_cargo':'1.95.0','no_SDK_or_runtime_policy_change':True,'free_bytes':shutil.disk_usage(wt).free}
  with (base/'declaration.json').open('x') as f:json.dump(declaration,f,indent=2);f.write('\n')
  repo=base/'fixture-source';repo.mkdir();setup=[]
  with (base/'setup.log').open('xb') as log:
   def git(*args):
    argv=[tools['git']['entry'],'-C',str(repo),*args];r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,close_fds=True);setup.append({'argv':argv,'exit':r.returncode});assert r.returncode==0
   git('init','-q');git('config','user.email','fixture@example.invalid');git('config','user.name','Owned Tool Control')
   (repo/'.gitignore').write_text('inputs/\n');(repo/'control.txt').write_text('No benchmark/native workload or real runtime source archive.\n')
   git('add','.');git('commit','-qm','owned nonbenchmark tool control')
  (base/'setup.json').write_text(json.dumps(setup,indent=2)+'\n')
  def read_git(*args):return subprocess.check_output([tools['git']['entry'],'-C',str(repo),*args],stderr=subprocess.STDOUT)
  head=read_git('rev-parse','HEAD').decode().strip();archive_sha=sha(read_git('archive','--format=tar',head))
  inputs={}
  for name in ['pub','transport','bench','package_config']:
   p=repo/'inputs'/name;p.parent.mkdir(exist_ok=True);p.write_text('OWN synthetic '+name);inputs[str(p.relative_to(repo))]=sha(p.read_bytes())
  command=[sys.executable,'-c','print("owned nonbenchmark tool control complete")']
  with (base/'intent.json').open('x') as f:json.dump({'source_commit':head,'source_archive_sha256':archive_sha,'inputs':inputs,'tools':tools,'command':command,'scope':'fixture source/input roles; actual installed CLI probes ONLY'},f,indent=2);f.write('\n')
  run=module.start_fixture(repo=repo,source_commit=head,runtime_commit=head,run_dir=base/'run',expected_archive_sha256=archive_sha,inputs=inputs,commands=[command],tools=tools,lease_check=lease.verify_identity)
  result=run.result if run.finished else None
  while result is None:result=run.wait(1)
  lease.verify_identity();assert all(sha((wt/p).read_bytes())==h for p,h in frozen['source_sha256'].items())
  observation={'result':result,'version_lines':{r['tool']:r.get('version_line') for r in result['commands'] if r['kind']=='tool_version'},'source_and_tools_unchanged_after':True,'scope':declaration['scope']}
  with (base/'observation.json').open('x') as f:json.dump(observation,f,indent=2);f.write('\n')
  print(json.dumps({'status':result['status'],'error':result['error'],'version_lines':observation['version_lines'],'recipes_executed':sum(r['kind']=='recipe' for r in result['commands'])}));sys.exit(0 if result['status']=='success' else 1)
except LocalResourceLeaseError as e:
 with Path(str(base)+'-lease-refusal.json').open('x') as f:json.dump({'error':str(e),'before_control_or_workload':True},f)
 print(str(e));sys.exit(75)
