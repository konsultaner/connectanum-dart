
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as companion
import os,json,pathlib,hashlib,stat,time,types
from unittest import mock
PLAN=pathlib.Path('/tmp/connectanum-native-perf-partial-actor-control-plan')
ROOT=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
ATTEMPT=pathlib.Path('/private/tmp/connectanum-native-perf-partial-actor-control-v1')
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def identity(info):
 return dict(dev=info.st_dev,ino=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid,
  nlink=info.st_nlink,size=info.st_size,mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns)
def views(owner):
 return dict(view=dict(owner.observe(0)),workers=[dict(row) for row in owner.worker_lifecycle()])
def join_call(owner):
 while True:
  view=owner.observe(1)
  if view['call_done'] and view['worker_joined'] and view['worker_start_settled']:return
def wait_auxiliary(operation,real_wait):
 result=operation.result
 while result is None:result=real_wait(operation,1)
 return result
with companion.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 declaration=json.loads((PLAN/'declaration.json').read_text())
 assert declaration['attempt']==str(ATTEMPT)
 free=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
 assert free>=1024**3
 ATTEMPT.mkdir(mode=0o700)
 put(ATTEMPT/'declaration.json',declaration)
 held={};sources={};observations=[];primary=None;producer=None;owner=None;cleanup_errors=[];fallback=[]
 known_auxiliary=None;real_wait=None;patches=[];injections=[];checks=[]
 nonce='b73e50a47d294f389a1b65e4c72809da'
 try:
  for rel,expected in declaration['source_sha256'].items():
   path=ROOT/rel
   assert path.resolve(strict=True)==path
   fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK);held[rel]=fd
   before=os.fstat(fd)
   put(ATTEMPT/('input-'+str(len(held)).zfill(2)+'-before.json'),dict(path=rel,stat=identity(before)))
   assert stat.S_ISREG(before.st_mode)
   assert before.st_uid==501 and before.st_gid==20
   assert stat.S_IMODE(before.st_mode)==0o644 and before.st_size<=2*1024**2
   data=b''
   while len(data)<=before.st_size:
    part=os.read(fd,min(65536,before.st_size+1-len(data)))
    if not part:break
    data+=part
   after=os.fstat(fd);assert len(data)==before.st_size
   assert identity(before)==identity(after)==identity(path.stat())
   assert sha(data)==expected
   sources[rel]=data;observations.append(dict(path=rel,before=identity(before),after=identity(after),sha256=sha(data)))
   target=ATTEMPT/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as f:f.write(data)
  put(ATTEMPT/'source-before.json',observations)
  name='native_perf_build_producer'
  assert name not in sys.modules
  producer=types.ModuleType(name);producer.__file__=str(ROOT/'tool/native_perf_build_producer.py')
  sys.modules[name]=producer
  exec(compile(sources['tool/native_perf_build_producer.py'],producer.__file__,'exec'),producer.__dict__)
  repo=ATTEMPT/'fixture-repo';repo.mkdir()
  ready=ATTEMPT/'child-ready';release=ATTEMPT/'child-release'
  code=declaration['auxiliary_code']
  argv=[sys.executable,'-c',code,str(ready),str(release)]
  put(ATTEMPT/'actual-command-intent.json',dict(argv=argv,scope='OWN finite fixture auxiliary, not Git/canonical/production/benchmark'))
  real_wait=producer.AuxiliaryCommand.wait
  fault=OSError(5,'OWN one-shot auxiliary wait escape fixture')
  def lease_check():
   lease.verify_identity();checks.append(dict(pid=os.getpid(),check_index=len(checks)))
  def source_guard(operation,observe=None):
   assert observe is None
   return producer._observe_auxiliary(operation,'own-probe',argv,stdout_max=65536)
  def injected_wait(operation,timeout):
   if operation.name=='own-probe' and not injections:
    assert operation.pending and operation.process is not None and operation.result is None
    injections.append(dict(pid=operation.process.pid,scope='one-shot raised fault before actual auxiliary wait'))
    raise fault
   return real_wait(operation,timeout)
  patches=[mock.patch.object(producer.CommandProducer,'_source_guard',source_guard),
   mock.patch.object(producer.AuxiliaryCommand,'wait',injected_wait)]
  for patch in patches:patch.start()
  try:
   owner=producer.start_owned_preflight('fixture',owner_id=nonce,repo=repo,
    source_commit='a'*40,runtime_commit='a'*40,run_dir=ATTEMPT/'fixture-run',
    expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
    commands=[[sys.executable,'-c',"raise SystemExit(99)"]],lease_check=lease_check)
   join_call(owner)
  finally:
   if owner is None:owner=producer.__dict__.get('_PREFLIGHT_OWNERS',{}).get(nonce)
   if owner is not None:join_call(owner)
   for patch in reversed(patches):patch.stop()
   patches=[]
  operation=owner._operation
  assert type(operation) is producer.CommandProducer and operation.provenance=='fixture'
  assert len(operation.auxiliary_operations)==1
  known_auxiliary=operation.auxiliary_operations[0]
  before=views(owner)
  end=time.monotonic()+3
  while not ready.exists() and time.monotonic()<end:time.sleep(.005)
  child_status=known_auxiliary.process.poll()
  refusal=None
  try:owner.continue_wait(0)
  except producer.ProducerError as error:refusal=type(error).__name__
  before.update(recipe_pending=operation.pending,recipe_finished=operation.finished,
   auxiliary_pending=known_auxiliary.pending,auxiliary_result=known_auxiliary.result,
   child_pid=known_auxiliary.process.pid,child_status=child_status,child_ready=ready.exists(),
   public_continuation_refused=refusal,first_error_is_injected_fault=owner._first_error_object is fault,
   after_refusal=views(owner))
  put(ATTEMPT/'case-before.json',before)
  assert before['child_ready'] and child_status is None
  assert before['view']['failed'] and not before['view']['initialized']
  assert before['view']['producer_pending'] is None
  assert before['view']['worker_joined'] and before['view']['call_done']
  assert operation.pending is False and operation.finished is True
  assert known_auxiliary.pending and known_auxiliary.result is None
  assert refusal=='ProducerError' and before['view']['call_index']==before['after_refusal']['view']['call_index']
  assert before['first_error_is_injected_fault']
  with release.open('x') as f:f.write('OWN fixture release; not GO\n')
  result=wait_auxiliary(known_auxiliary,real_wait)
  after=views(owner)
  put(ATTEMPT/'case-after.json',dict(owner=after,auxiliary_result=result,
   child_returncode=known_auxiliary.process.returncode,
   scope='fixture-only direct known AuxiliaryCommand wait; not a live partial-constructor drain API'))
  assert result['returncode']==0 and known_auxiliary.process.returncode==0
  for role,expected in declaration['expected_raw'].items():
   output=result['outputs'][role]
   assert output['eof'] and output['snapshot_matches_stream']
   assert (ATTEMPT/'fixture-run'/('own-probe.'+role)).read_bytes()==expected.encode()
  assert not after['view']['initialized'] and after['view']['first_error']=='OSError'
  assert after['view']['actor_ownership_complete'] is None
  assert all(after['view'][k] is False for k in ('capture_ready','source_admitted','live_admission'))
  put(ATTEMPT/'case-summary.json',dict(scope='ONE current-Darwin OWN finite partial-constructor fault fixture ONLY',
   one_injected_error=injections,constructor_raised=True,worker_join_confirmed=True,
   public_partial_actor_continuation_absent=True,child_natural_status=result['returncode'],
   both_separate_output_EOF=all(v['eof'] for v in result['outputs'].values()),
   private_fixture_direct_wait_only=True,producer_stays_failed_uninitialized=True,
   not_original_host_or_kernel_control=True,no_canonical_build_or_benchmark=True,
   no_production_defect_cause_or_acceptance=True,all_admission_flags=False))

 except BaseException as error:
  primary=error
  try:put(ATTEMPT/'failure.json',dict(type=type(error).__name__,scope='terminal OWN control attempt; no reset/retry'))
  except BaseException as secondary:
   cleanup_errors.append(dict(stage='failure publication',type=type(secondary).__name__))
  raise
 finally:
  def remember(error,stage):
   global primary
   cleanup_errors.append(dict(stage=stage,type=type(error).__name__))
   if primary is None:primary=error
  # Same known worker/child waits continue under actual EX; no total-deadline release.
  if owner is None and producer is not None:
   owner=producer.__dict__.get('_PREFLIGHT_OWNERS',{}).get(nonce)
  if owner is not None:
   join_call(owner)
   operation=owner._operation
   if operation is not None:
    for auxiliary in operation.__dict__.get('auxiliary_operations',[]):
     if auxiliary.process is not None and auxiliary.result is None:
      release=ATTEMPT/'child-release'
      try:
       if not release.exists():
        with release.open('x') as f:f.write('OWN finite fixture failure release; not GO\n')
      except BaseException as error:remember(error,'OWN fixture release')
      try:wait_auxiliary(auxiliary,real_wait)
      except BaseException as error:
       remember(error,'OWN direct auxiliary cleanup wait')
       # Fixture-only natural wait for this already-retained finite Popen;
       # never a producer recovery or live admission workaround.
       while True:
        try:
         status=auxiliary.process.wait(timeout=1)
         fallback.append(dict(pid=auxiliary.process.pid,status=status,scope='fixture-only same known finite child natural wait; no output-completion claim'))
         break
        except producer.subprocess.TimeoutExpired:continue
  for patch in reversed(patches):
   try:patch.stop()
   except BaseException as error:remember(error,'restore OWN fixture patch')
  post=[]
  while held:
   rel,fd=held.popitem()
   try:
    current=os.fstat(fd);record=next((x for x in observations if x['path']==rel),None)
    post.append(dict(path=rel,held_fd_identity=identity(current),original_full_read_record_present=record is not None))
    if record is not None:assert identity(current)==record['after']
    assert identity((ROOT/rel).stat())==identity(current)
   except BaseException as error:remember(error,'held source postcheck '+rel)
   finally:
    try:os.close(fd)
    except BaseException as error:remember(error,'ONE source FD close '+rel)
  for path,value in ((ATTEMPT/'source-after.json',post),(ATTEMPT/'lease-checks.json',checks)):
   try:put(path,value)
   except BaseException as error:remember(error,'terminal observation publication '+path.name)
  if producer is not None and sys.modules.get('native_perf_build_producer') is producer:
   sys.modules.pop('native_perf_build_producer')
  try:lease.verify_identity()
  except BaseException as error:remember(error,'final official EX identity')
  try:put(ATTEMPT/'finalization.json',dict(primary=None if primary is None else type(primary).__name__,cleanup_errors=cleanup_errors,fixture_fallback=fallback,known_actor_scope_only=True,all_admission_flags=False))
  except BaseException as error:remember(error,'terminal finalization publication')
  if primary is not None:raise primary
print(json.dumps(dict(terminal=True,attempt=str(ATTEMPT),scope='OWN finite fault fixture only')))
