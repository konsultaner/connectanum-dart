import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat
P=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-07-actions-include-great-grandchild-regular-inputs-v1');N=P/'source-control-interpretation-v1';T=P/'source-preparation-inputs-v1/FIRST-new-selected-source-control-tail.py'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();N.mkdir()
 def save(n,b):
  with (N/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':'FIRST bounded static interpretation ofNEWselectedsaved12274B sourcecontroltail ONLY, neededforFIRST4868extension. Original854571Bprefix/oldloaders remainopaque/oldAST-syntax/model/SDK/parser notrerun. ExactOWNsavedtail/range-SHA declaredBEFOREIO; no sourceimport-exec/test/nativeSDK-Actionsquery/Source20-runtimeadoption.','path':str(T),'range':[0,12274],'sha256':'590bd6186c4ccb46f13e0961b2204a527941f5266430a868e91de3e63f95207a','all_admission_flags':False},indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save('prior-CP-exact-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw

 raw=read_bounded(T,12274,'590bd6186c4ccb46f13e0961b2204a527941f5266430a868e91de3e63f95207a','NEWselectedcontroltail');save('FIRST-control-tail-binding.json',json.dumps(bindings[0],indent=2));save('FIRST-control-tail-byteexact.py',raw);print(raw.decode(),flush=True);lease.verify_identity()
