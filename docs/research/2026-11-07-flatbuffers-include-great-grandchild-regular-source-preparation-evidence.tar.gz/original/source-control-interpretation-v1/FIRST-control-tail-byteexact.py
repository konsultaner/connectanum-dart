    scope_path = root / "NEW-grandchild-scope-BEFORE-INPUT-IO.json"
    scope_fd = os.open(scope_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    owned.append(scope_fd)
    try:
        event("NEW_scope_output_open_return_BEFORE_INPUT", fd=scope_fd, bytes=len(NEW_GRANDCHILD_SCOPE_RAW), sha256=hashlib.sha256(NEW_GRANDCHILD_SCOPE_RAW).hexdigest())
        write_all(scope_fd, NEW_GRANDCHILD_SCOPE_RAW, "NEW_scope")
    finally:
        close_known(scope_fd, "NEW_scope_output")
    observations = []
    for ordinal, reference in enumerate(references):
        row = {"source_reference": reference, "ordinal": ordinal}
        observations.append(row)
        try:
            src = os.open(reference, os.O_RDONLY | os.O_NOFOLLOW)
        except FileNotFoundError as error:
            row["absent_at_open_only"] = {"type": type(error).__name__, "text": str(error)}
            event("input_absent_at_open", source=reference)
            continue
        owned.append(src)
        try:
            event("input_open_return_before_read", fd=src, source=reference)
            before = state(src)
            row["source_fd_before"] = before
            if not stat.S_ISREG(before["mode"]):
                raise RuntimeError("new input FD is not regular; no fallback/retry")
            destination = root / ("input-" + str(ordinal).zfill(2) + ".bin")
            dst = os.open(destination, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
            owned.append(dst)
            try:
                event("saved_output_open_return_before_IO", fd=dst, path=str(destination), source=reference)
                digest = hashlib.sha256()
                count = 0
                while True:
                    chunk = os.read(src, 65536)
                    if not chunk:
                        break
                    digest.update(chunk)
                    count += len(chunk)
                    write_all(dst, chunk, "saved_input_output")
                after = state(src)
                row["source_fd_after"] = after
                if before != after or count != before["size"]:
                    raise RuntimeError("input FD metadata or stream size changed; partial raw quarantined")
                os.lseek(dst, 0, os.SEEK_SET)
                saved_digest = hashlib.sha256()
                saved_count = 0
                while True:
                    chunk = os.read(dst, 65536)
                    if not chunk:
                        break
                    saved_digest.update(chunk)
                    saved_count += len(chunk)
                if saved_count != count or saved_digest.digest() != digest.digest():
                    raise RuntimeError("same saved output FD stream differs; partial raw quarantined")
                row.update(saved_member=destination.name, bytes=count, sha256=digest.hexdigest(),
                           same_saved_output_FD_stream_matches=True, saved_output_fd_state=state(dst))
                event("input_stream_saved", source=reference, saved_member=destination.name,
                      bytes=count, sha256=digest.hexdigest(), same_saved_output_FD_matches=True)
            finally:
                close_known(dst, "saved_input_output")
        finally:
            close_known(src, "regular_source_input")
    if owned:
        raise RuntimeError("known source/output FD closure incomplete")
    report = {
        "workflow_revision": os.environ["GITHUB_SHA"], "run_id": os.environ["GITHUB_RUN_ID"],
        "source_regular_references": references,
        "NEW_ALL1199_child_regular_input_scope": NEW_CHILD_SCOPE,
        "NEW_ALL1229_grandchild_regular_input_scope": NEW_GRANDCHILD_SCOPE,
        "original_ALL1199_regular_reference_metadata_NOT_requeried": prior_child_regular_references,
        "NEW_grandchild_scope_exact_JSON_bytes": len(NEW_GRANDCHILD_SCOPE_RAW),
        "NEW_grandchild_scope_exact_JSON_sha256": hashlib.sha256(NEW_GRANDCHILD_SCOPE_RAW).hexdigest(),
        "NEW1229_prior_actual_reference_ledger_metadata": NEW_PRIOR_REFERENCE_LEDGERS,
        "original_ALL160_regular_reference_metadata_NOT_requeried": prior_regular_references,
        "NEW_scope_exact_JSON_bytes": len(NEW_CHILD_SCOPE_RAW),
        "NEW_scope_exact_JSON_sha256": hashlib.sha256(NEW_CHILD_SCOPE_RAW).hexdigest(),
        "ALL210_include_original_safe_entry_metadata": ALL210_include_original_safe_entry_metadata,
        "ALL160_include_explicit_lexical_relations": ALL160_include_explicit_lexical_relations,
        "ALL49_include_deferred_directories_NO_query_recursion": ALL49_include_deferred_directories_NO_query_recursion,
        "ALL1_include_original_symlink_UNEXPANDED_UNFOLLOWED": ALL1_include_original_symlink_UNEXPANDED_UNFOLLOWED,
        "ALL4_positive_regular_point_metadata": ALL4_positive_regular_point_metadata,
        "ALL4_positive_math_catalogue_metadata": ALL4_positive_math_catalogue_metadata,
        "ALL4_explicit_lexical_reference_relations": ALL4_explicit_lexical_reference_relations,
        "ALL5_prior_reference_reacquisition_exclusions": ALL5_prior_reference_reacquisition_exclusions,
        "dynamic_source_record_declaration": dynamic_source_record_declaration,
        "ALL76_source_NEEDED_bindings": ALL76_source_NEEDED_bindings,
        "ALL14_source_INTERP_records_NUL_preserved": ALL14_source_INTERP_records_NUL_preserved,
        "ALL19_positive_entry_metadata": ALL19_positive_entry_metadata,
        "ALL3_conservative_pre_IO_plugin_exclusions": ALL3_plugin_exclusions,
        "deferred_directory_metadata_NO_query": deferred_directory_metadata,
        "ALL9_historical_candidate_metadata": source_candidate_metadata,
        "ALL20_reference_relations": source_directory_reference_origins,
        "ALL11_positive_usr_entries": source_usr_entry_metadata,
        "ALL4_explicit_pre_IO_exclusions": explicit_source_exclusions,
        "ALL2_positive_gcc_entry_metadata": source_gcc_entry_metadata,
        "ALL2_positive_gcc_child_metadata": source_gcc_child_entry_metadata,
        "ALL4_positive_gcc_component_metadata": source_gcc_component_entry_metadata,
        "observations": observations,
        "collector_credentials": {"uid": os.getuid(), "gid": os.getgid(), "groups": os.getgroups()},
        "collector_cwd": os.getcwd(), "collector_argv": list(sys.argv),
        "collector_interpreter_reference": sys.executable,
        "regular_source_INPUT_body_opens": sum("source_fd_before" in x for x in observations),
        "regular_source_INPUT_hashes": sum("sha256" in x for x in observations),
        "entry_symlink_target_follows": 0, "recursive_walks": 0, "directory_queries": 0,
        "collector_child_executions": 0, "native_information_queries": 0,
        "candidate_executions": 0, "environment_mutations": 0,
        "remaining_known_input_output_FDs": list(owned), "all_admission_flags": False,
        "qualification": 'NEWexpresslydeclared ALL1229originalmode-regular grandchild BODYinputs afterALL1425sourcealias intake/exactlexicalscope. Original1425fullmetadata-stat-times/63queryepochs/190DEFERRED/6rawlinksUNEXPANDED-UNFOLLOWED/prior1280-49query-1199latelexical-old63DEFERRED-18olderlinks-oldtopncurses.h-curses.h rawhexNOTsavedNULL/ledgers unchanged. Old1199scope/160refs andALLoriginalmetadata/functions/guards-fields retained NOTrequeried. New1229refs checkedexactly againstboundedprior1199actualBODY/160immutableBODY/63actualdirectory/49immutable-directory ledgers+allcapturedpriorstaticmetadata literalstrings; allmatches-nonmatches kept/nonmatchesNOTglobalabsence-newness-alias-permission. Metadata-onlygzip-base64 transport preserveswholedecodedbytes/JSONSTRING/PythonALLfields/no schema-rounding-normalization-gatewaiver/SDKbodycompression/ownershipshortcut; fullprivateoriginalfields separatelyunchanged. Original65536Bregularcopy/FD-beforeafter/countSHA/SAMEsavedOUTPUTFD/close-error functions unchanged. FinalO_NOFOLLOW/pointchecks NOTatomicABA-origin/pathchain/defaultcompiler-sysroot-CargoCFG-flavor-ABIloadedcohort/originaldriveraccess-credentials/globalactorFD/continuousphysicalEX-crash admission. No aliasdedup/favorablefilter/linkfollow-recursion-directoryquery/candidateexecution/import-headercompile/envmutation/bootstrap-dependency-build-driver-perf-numerical/Source20-runtime adoption. BodyinteriorsUNINSPECTED/unknownpartial-crash permanentlyquarantined/no cleanup-retry-ownerdiscard. Regularfile stdinpython3dash NOTidenticalFDtopology; setupUNADMITTED/allflagsFALSE/ownershipNone.',
        "prior_ALL1199_collector_qualification_metadata_only": 'NEW expresslydeclared originalActions ALL1199originalmode-regular child BODYinputs afterALL1280sourcealias intake; EACHliteralparent+SINGLEchildbasename NEWtext declaration BEFOREINPUT, oldseparate-parent-child/49query/210-160-original49DEFERRED epochs unchanged. ALL1280metadata/63newchilddirsDEFERRED/18NEWsymlinksrawbytesUNEXPANDED-UNFOLLOWED/allpriorledgers kept; oldtopncurses.h-curses.h missingrawhexNULL neverretrofilled. Lossless gzip-base64 packaging of exact public-safe scope3463612B/SHA2fa42e2c02962f9d4a323072786842f61af96eefe7874994295bbdaa204aedea preservesALLbytes/JSONSTRING/PythonALLfields, NOTSDKbodycompression/fielddrop/schema-gatewaiver/metadata-mutability-ownership shortcut. Originalfullstat-times/privateCPmatches retained unchanged separately. Sameoriginalregularcopyfunctions/fullstream65536Bchunks/regularFD/finalO_NOFOLLOW/beforeaftermetadata/countSHA/SAMEsavedOUTPUTFD validation kept. Pointchecks NOTfullpathchain/atomicABA-origin-auth/effectivecompiler-sysroot/ABI-loadedcohort/originaldriveraccess-credentials/globalactorFD/continuousofficialphysicalEX-crash admission. No aliasdedup/favorablelanguage-version-ABI-defaultcompiler filter/sourceENTRYlinkfollow/recursion/directoryquery/import/headercompile/nativequery/candidateexec/envmutation/bootstrap/dependency/build/driver/perf/benchmark/numerical/Source20-runtime adoption. BodyinteriorsUNINSPECTED/allunknownpartial/crashoutcomespermanentquarantine/no cleanup-retry-ownerdiscard. AllsetupUNADMITTED/flagsFALSE/ownershipNone.',
        "prior_ALL160_collector_qualification_metadata_only": 'NEW expresslydeclared ORIGINALActions static full regular-input acquisition ALL160 original include regular records after ALL210 source-alias intake; literalparent+EACH singlebasename NEWtextcandidate declaration beforeIO, original separate-parent-name epochs unchanged. ALL210 names/namehex/modes/types/UIDGID/readlinkstrings kept; ALL49directories DEFERRED/noquery-recursion; ncurses.h literal curses.h UNEXPANDED/UNFOLLOWED/originalrawreadlinkbytehexNULL. No aliasdedup/favorablelanguage-version-ABI-defaultcompiler filter. Old math/catalogue/libm/libc/loader/plugin/v6/76NEEDED14INTERP/19records/7sets1124rows/11source4exclusions9historical20relations/4flavorsBOTHcfg/11installerBOTHLLVM/974rows ledgers preserved historical NOTnewread-revalidated. FinalO_NOFOLLOW/regularFD/fullcountSHA/before-aftermetadata/same savedOUTPUTFD stream comparison are pointdata NOTfullpathchain/atomicABA-origin-auth/originaldriveraccess-credentials/loadedmap/runtimecohort/globalactorFD/continuousofficialphysicalEX-crash admission. No sourceENTRYsymlinkfollow/recursion/directoryquery/nativequery/import/candidateexec/envmutation/SDKbootstrap/dependency/build/driver/perf/benchmark/numerical/Source20-runtime adoption. BodyinteriorsUNINSPECTED. Unknownacquire-allocation-write-close-journal-crash/partialraw permanentquarantine/no cleanup-retry-ownerdiscard-fakesettlement. SetupUNADMITTED/allflagsFALSE/ownershipNone.'
    }
    raw = (json.dumps(report, sort_keys=True, indent=2) + "\n").encode()
    path = root / "include-grandchild-regular-inputs.json"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    owned.append(fd)
    try:
        event("report_open_return_before_write", fd=fd, path=str(path))
        write_all(fd, raw, "report")
        event("report_bytes_written", fd=fd, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    finally:
        close_known(fd, "report")
    event("report_saved", declared_regular_refs=len(references), present_streams=sum("saved_member" in x for x in observations),
          remaining_known_input_output_FDs=list(owned), native_information_queries=0, candidate_executions=0)
finally:
    journal.close()
