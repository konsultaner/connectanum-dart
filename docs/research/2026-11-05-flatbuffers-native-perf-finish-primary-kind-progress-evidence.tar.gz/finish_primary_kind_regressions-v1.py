import unittest,pathlib,tempfile,sys,os,hashlib,json,subprocess
import native_perf_build_producer as b
Path=pathlib.Path
def finish_primary_sha(raw):return hashlib.sha256(raw).hexdigest()
class FinishPrimaryFirst(RuntimeError):pass
class FinishPrimarySecond(RuntimeError):pass
class FinishPrimaryThird(RuntimeError):pass
_ROOT_FINISH_PRIMARY_ATTEMPTS=[]
class FinishPrimaryKindTests(unittest.TestCase):
 def _case(self,mode):
  root=Path(os.environ['CONNECTANUM_FINISH_PRIMARY_FIXTURES']);root.mkdir(exist_ok=True)
  base=Path(tempfile.mkdtemp(prefix=mode+'-',dir=root)).resolve();repo=base/'repo';repo.mkdir();run=base/'run'
  setup=[];actors=[];pipes=[];files=[];groups=[];seen={'snapshot_returned':False,'group_attempts':0}
  first=FinishPrimaryFirst('finish-primary-original-First');second=FinishPrimarySecond('finish-primary-pending-Second');third=FinishPrimaryThird('finish-primary-callback-Third')
  attempt=dict(base=base,actors=actors,pipes=pipes,files=files);_ROOT_FINISH_PRIMARY_ATTEMPTS.append(attempt)
  def git(*args):
   i=len(setup);argv=['git','-C',str(repo),*args];row={'argv':argv,'Popen_attempted':True,'pid':None};setup.append(row)
   (base/f'setup-{i}-before.json').write_text(json.dumps(row))
   process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=process.wait
   (base/f'setup-{i}-start.json').write_text(json.dumps({'pid':process.pid}))
   out,err=process.communicate();status=wait(10)
   (base/f'setup-{i}-stdout.bin').write_bytes(out);(base/f'setup-{i}-stderr.bin').write_bytes(err)
   row.update(pid=process.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=finish_primary_sha(out),stderr_sha256=finish_primary_sha(err))
   (base/'setup-commands.json').write_text(json.dumps(setup,indent=2))
   if status!=0:raise RuntimeError('new fixture setup refused')
   return out
  git('init','-q');git('config','user.email','finish-primary@example.invalid');git('config','user.name','Finish Primary Fixture')
  (repo/'.gitignore').write_text('inputs/\n')
  (repo/'worker.py').write_text("import os,time\ntime.sleep(0.08)\nos.write(1,b'FP-v1-out')\nos.write(2,b'FP-v1-err')\n")
  git('add','.');git('commit','-qm','new finish primary contract fixture');head=git('rev-parse','HEAD').decode().strip()
  expected=finish_primary_sha(git('archive','--format=tar',head));(repo/'inputs').mkdir();(repo/'inputs'/'context').write_bytes(b'group-acquisition-input-v1')
  inputs={'inputs/context':finish_primary_sha((repo/'inputs'/'context').read_bytes())}
  native_os=b.os;native_open=Path.open;native_aux=b.AuxiliaryCommand._allocate_process;native_recipe=b.CommandProducer._allocate_command_process;native_writer=b._write_json;native_group=b._failure_preservation_group
  root_readers=[]
  def remember(process,kind):actors.append({'process':process,'wait':process.wait,'pid':process.pid,'kind':kind})
  class OSFacade:
   def __getattr__(self,name):return getattr(native_os,name)
   def pipe(self):
    pair=native_os.pipe();info=[]
    for fd in pair:
     st=native_os.fstat(fd);info.append({'fd':fd,'dev':st.st_dev,'ino':st.st_ino,'inheritable':native_os.get_inheritable(fd)})
    pipes.append({'pair':pair,'info':info});return pair
  def opened(path,*args,**kwargs):
   value=native_open(path,*args,**kwargs)
   if path.parent==run:
    raw=getattr(value,'raw',None)
    for stream in ([raw,value] if raw is not None and raw is not value else [value]):
     st=native_os.fstat(stream.fileno());files.append({'path':str(path),'stream':stream,'close':stream.close,'fd':stream.fileno(),'dev':st.st_dev,'ino':st.st_ino})
   return value
  def auxiliary(owner,record):
   process=native_aux(owner,record);remember(process,'Auxiliary');return process
  def recipe(owner,attempt,argv,writer):
   process=native_recipe(owner,attempt,argv,writer);remember(process,'recipe');return process
  def written(path,payload):
   raw=native_writer(path,payload)
   if Path(path)==run/'result.json':
    seen.update(writer_returned_ROOT=True,writer_raw_None=raw is None,result_payload=payload);raise first
   return raw
  def grouped(owner,error):
   seen['group_attempts']+=1;value=native_group(owner,error);groups.append(value)
   if mode=='unknown':seen['unknown_group_Second_attempted']=True;raise second
   if mode in ('none','false'):
    raw=None if mode=='none' else False;seen.update(invalid_primary_selected=True,raw_primary=raw);return value[:3]+(raw,)+value[4:]
   return value
  owner=None;result=None;received=None;guard_error=None;evidence_ready=False
  try:
   b.os=OSFacade();Path.open=opened;b.AuxiliaryCommand._allocate_process=auxiliary;b.CommandProducer._allocate_command_process=recipe
   owner=b.CommandProducer(repo=repo,source_commit=head,runtime_commit=head,run_dir=run,expected_archive_sha256=expected,inputs=inputs,commands=[[sys.executable,str(repo/'worker.py')]],lease_check=lambda:None,provenance='fixture')
   attempt['owner']=owner;seen['healthy_constructor_returned']=True
   b._write_json=written;b._failure_preservation_group=grouped
   try:result=owner.wait(10)
   except BaseException as error:received=error
   finally:
    b._write_json=native_writer;b._failure_preservation_group=native_group;b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   try:b._finish_publication_guard(owner)
   except BaseException as error:guard_error=error
   records=[r for r in b._FINISH_PUBLICATION_RECORDS if r['owner'] is owner];target=records[-1] if records else None
   steps=[] if target is None else [{'stage':r['stage'],'returned':r['returned'],'raw_None':r['raw'] is None,'error_First':r['error'] is first,'error_type':None if r['error'] is None else type(r['error']).__name__} for r in target['steps']]
   command=owner.records[-1];source_result=owner.result
   view={'finish_primary_kind':mode,'healthy_constructor_returned':seen.get('healthy_constructor_returned',False),'native_result_writer_completed_ROOT':seen.get('writer_returned_ROOT',False),'writer_raw_None':seen.get('writer_raw_None',False),'Source_result_is_native_writer_payload':source_result is seen.get('result_payload'),'Source_result_status_DATA':None if type(source_result) is not dict else source_result.get('status'),'Source_result_capture_ready_DATA':None if type(source_result) is not dict else source_result.get('capture_ready'),'Source_evidence_complete_DATA':owner.evidence_complete,'Source_group_attempts':seen['group_attempts'],'native_group_returns_ROOT':len(groups),'invalid_primary_selected':seen.get('invalid_primary_selected',False),'raw_primary_None':mode=='none' and seen.get('raw_primary') is None,'raw_primary_False':mode=='false' and seen.get('raw_primary') is False,'unknown_group_Second_attempted':seen.get('unknown_group_Second_attempted',False),'received_First':received is first,'received_type':None if received is None else type(received).__name__,'pure_guard_First':guard_error is first,'pure_guard_type':None if guard_error is None else type(guard_error).__name__,'result_returned':result is not None,'Source_pending_DATA':owner.pending,'Source_finished_DATA':owner.finished,'Source_log_None_DATA':owner.log is None,'Source_output_fd_None_DATA':owner.output_fd is None,'Source_command_status_DATA':command.get('returncode'),'Source_output_eof_DATA':command.get('output_eof'),'Source_attempt_primary_First':target is not None and target['primary_error'] is first,'Source_attempt_primary_None':target is not None and target['primary_error'] is None,'Source_attempt_primary_False':target is not None and target['primary_error'] is False,'Source_attempt_completed':False if target is None else target['completed'],'Source_steps':steps,'First_context_type':None if first.__context__ is None else type(first.__context__).__name__,'actor_rows':[{'pid':r['pid'],'kind':r['kind']} for r in actors],'ROOT_native_tuple_NOT_filled_called_adopted':True,'one_Source_wait_only_pure_guard_no_IO':True,'result_file_DATA_NOTreceipt_admission':True,'unit_not_liveness_ownership_EXrelease_admission':True}
   (base/'view-before-ROOT-wait.json').write_text(json.dumps(view,indent=2));evidence_ready=True
   self.assertTrue(received is first);self.assertTrue(guard_error is first);self.assertIsNone(result)
   self.assertTrue(view['healthy_constructor_returned']);self.assertTrue(view['native_result_writer_completed_ROOT']);self.assertTrue(view['writer_raw_None']);self.assertTrue(view['Source_result_is_native_writer_payload']);self.assertEqual('success',view['Source_result_status_DATA']);self.assertFalse(view['Source_result_capture_ready_DATA']);self.assertFalse(view['Source_evidence_complete_DATA'])
   self.assertFalse(view['Source_pending_DATA']);self.assertTrue(view['Source_finished_DATA']);self.assertTrue(view['Source_log_None_DATA']);self.assertTrue(view['Source_output_fd_None_DATA']);self.assertEqual(0,view['Source_command_status_DATA']);self.assertTrue(view['Source_output_eof_DATA']);self.assertFalse(view['Source_attempt_completed'])
   if mode=='native':self.assertTrue(view['Source_attempt_primary_First'])
   else:self.assertTrue(view['Source_attempt_primary_None'])
   self.assertEqual(1,view['Source_group_attempts']);self.assertEqual(1,view['native_group_returns_ROOT'])
  finally:
   b._write_json=native_writer;b._failure_preservation_group=native_group;b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   if not evidence_ready:raise RuntimeError('ROOT evidence absent; known handles retained, no cleanup claim')
   rows=[]
   for item in actors:
    try:
     raw=item['wait'](10);rows.append({'kind':'same_original_bound_wait','actor_kind':item['kind'],'pid':item['pid'],'status':raw,'signed_native_int':type(raw) is int})
    except BaseException as error:rows.append({'kind':'same_original_bound_wait','actor_kind':item['kind'],'pid':item['pid'],'status':None,'signed_native_int':False,'error_type':type(error).__name__,'no_retry':True})
   all_known=all(r['signed_native_int'] for r in rows);(base/'ROOT-all-known-waits-before-assert.json').write_text(json.dumps({'rows':rows,'all_statuses_known':all_known},indent=2))
   if not all_known:attempt['unknown_wait_statuses_retained']=True;raise RuntimeError('ROOT unknown wait; no cleanup settlement')
   for label,path,limit in [('log',run/'command-000.log',65536),('result',run/'result.json',16*1024**2)]:
    (base/f'ROOT-{label}-reader-before-open.json').write_text(json.dumps({'path':str(path),'attempted':True,'actual_source_file_not_reconstruction':True}))
    reader=native_open(path,'rb',buffering=0);readrow={'stream':reader,'close':reader.close,'fd':reader.fileno(),'label':label};root_readers.append(readrow);attempt['root_readers']=root_readers
    st=native_os.fstat(readrow['fd']);readrow.update(dev=st.st_dev,ino=st.st_ino)
    (base/f'ROOT-{label}-reader-before-read.json').write_text(json.dumps({k:v for k,v in readrow.items() if k not in ('stream','close')},indent=2))
    data=native_os.read(readrow['fd'],limit);end=native_os.read(readrow['fd'],1);(base/f'ROOT-actual-{label}.bin').write_bytes(data);(base/f'ROOT-{label}-tail.bin').write_bytes(end)
    (base/f'ROOT-{label}-read-result.json').write_text(json.dumps({'size':len(data),'sha256':finish_primary_sha(data),'EOF':end==b'','tail_size':len(end),'actual_source_file_NOT_constructed_or_adopted_receipt':True},indent=2))
    self.assertEqual(b'',end)
    if label=='log':self.assertEqual(b'FP-v1-outFP-v1-err',data)
    else:
     parsed=json.loads(data);self.assertEqual('success',parsed['status']);self.assertFalse(parsed['capture_ready'])
   (base/'ROOT-before-FDclose.json').write_text(json.dumps({'evidence_ready':True,'rows':rows},indent=2))
   for item in root_readers:
    st=native_os.fstat(item['fd']);same=(st.st_dev,st.st_ino)==(item['dev'],item['ino']);record={'kind':'ROOT_file_reader','label':item['label'],'fd':item['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(record)
    if same:item['close']();record['closed_by_ROOT']=True
   for pipe in pipes:
    for info in pipe['info']:
     try:st=native_os.fstat(info['fd'])
     except OSError as error:rows.append({'kind':'creatorFD','fd':info['fd'],'already_closed_errno':error.errno});continue
     same=(st.st_dev,st.st_ino)==(info['dev'],info['ino']);rows.append({'kind':'creatorFD','fd':info['fd'],'same_devino':same,'closed_by_ROOT':same})
     if same:native_os.close(info['fd'])
   for item in files:
    if item['stream'].closed:continue
    try:st=native_os.fstat(item['fd'])
    except OSError as error:rows.append({'kind':'file','path':item['path'],'fd':item['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(item['dev'],item['ino']);record={'kind':'file','path':item['path'],'fd':item['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(record)
    if same:
     try:item['close']();record['closed_by_ROOT']=True
     except BaseException as error:record['close_error_type']=type(error).__name__
   (base/'ROOT-unit-cleanup.json').write_text(json.dumps({'evidence_ready':True,'rows':rows,'unit_not_live_ownership_fullFD_descendant_closure':True},indent=2))
   self.assertTrue(all(r['status']==0 for r in rows if r['kind']=='same_original_bound_wait'))
 def test_new_finish_primary_None_does_not_replace_First(self):self._case('none')
 def test_new_finish_primary_False_does_not_replace_First(self):self._case('false')
 def test_new_native_finish_primary_caller_control(self):self._case('native')
 def test_new_unknown_group_completion_keeps_finish_First(self):self._case('unknown')
