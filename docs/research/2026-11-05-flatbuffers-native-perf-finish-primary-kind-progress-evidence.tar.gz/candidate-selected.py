def _finish(self,status,error=None):
        _finish_publication_guard(self)
        _failure_preservation_guard(self)
        if id(self) in _FINISH_PUBLICATIONS:raise ProducerError('finish publication is permanently terminal')
        original_events=self.events;directory=self.directory;result=self.result;outputs=self.outputs
        private_first=[None]
        def guard():
            if private_first[0] is not None:raise private_first[0]
        record={'owner':self,'events':original_events,'directory':directory,'result':result,'outputs':outputs,
                'primary_error':None,'steps':[],'completed':False}
        _FINISH_PUBLICATIONS[id(self)]=(self,guard)
        _FINISH_PUBLICATION_RECORDS.append(record)
        def refuse(error,row=None):
            private_first[0]=error
            try:
                group=_failure_preservation_group(self,error)
                returned_primary=group[3]
                if not isinstance(returned_primary,BaseException):raise ProducerError('unknown finish failure primary')
                private_first[0]=returned_primary
                record['primary_error']=private_first[0]
                group[2](error,row)
            finally:raise private_first[0]
        def step(stage,callback,role=None):
            guard();_failure_preservation_guard(self)
            row={'stage':stage,'role':role,'returned':False,'raw':None,'error':None}
            record['steps'].append(row)
            try:
                raw=callback();row['raw']=raw;row['returned']=True
                return raw
            except BaseException as error:refuse(error,row)
        def context(expected_events):
            guard()
            if (self.directory is not directory or self.events is not expected_events
                or self.result is not result or self.outputs is not outputs):
                raise ProducerError('finish publication context changed')
        def digest(raw):
            if type(raw) is not str or re.fullmatch('[0-9a-f]{64}',raw) is None:
                raise ProducerError('finish publication digest is invalid')
            return raw
        try:
            self.finished=True
            writer=_write_json;hasher=_regular_hash;event=self._event;close=original_events.close
            output_hashes={}
            if status=='success':
                for role,path in outputs.items():
                    context(original_events)
                    pattern=step('output_pattern',lambda:str(path),role)
                    if type(pattern) is not str:raise ProducerError('output pattern is invalid')
                    context(original_events)
                    if '*' in pattern:
                        parent_path=step('output_glob_parent_path',lambda:Path(path),role)
                        context(original_events)
                        parent=step('output_glob_parent',lambda:parent_path.parent,role)
                        context(original_events)
                        glob=step('output_glob_method',lambda:parent.glob,role)
                        context(original_events)
                        name_path=step('output_glob_name_path',lambda:Path(path),role)
                        context(original_events)
                        name=step('output_glob_name',lambda:name_path.name,role)
                        context(original_events)
                        iterator=step('output_glob_call',lambda:glob(name),role)
                        context(original_events)
                        matches=step('output_glob_sorted',lambda:sorted(iterator),role)
                        context(original_events)
                        if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                        path=matches[0]
                    label=step('output_path',lambda:str(path),role)
                    if type(label) is not str:raise ProducerError('output path is invalid')
                    context(original_events)
                    raw=step('output_hash',lambda:hasher(Path(path)),role)
                    value=digest(raw)
                    context(original_events)
                    output_hashes[role]={'path':label,'sha256':value}
            self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                         'scope':'owned_direct_child_wait_output_pipe_eof_and_file_snapshots_only','capture_ready':False,
                         'status':status,'error':error,'census_id':self.census_id,'expected_sdk':self.expected_sdk,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                         'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                         'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance,'tools':{k:dict(v) for k,v in self.tools.items()}}
            result=self.result;record['result']=result
            result_path=directory/'result.json';journal_path=directory/'journal.jsonl'
            context(original_events)
            raw=step('result_write',lambda:writer(result_path,result))
            if raw is not None:raise ProducerError('finish result writer returned an invalid result')
            context(original_events)
            raw=step('result_hash',lambda:hasher(result_path))
            self.result_sha256=digest(raw)
            context(original_events)
            raw=step('finished_event',lambda:event('finished',status=status,error=error))
            if raw is not None:raise ProducerError('finish event returned an invalid result')
            context(original_events)
            self.events=None
            step('journal_close',close)
            context(None)
            raw=step('journal_hash',lambda:hasher(journal_path))
            self.journal_sha256=digest(raw)
            context(None)
            self.evidence_complete=True;record['completed']=True
            return self.result
        except BaseException as error:
            guard()
            refuse(error)