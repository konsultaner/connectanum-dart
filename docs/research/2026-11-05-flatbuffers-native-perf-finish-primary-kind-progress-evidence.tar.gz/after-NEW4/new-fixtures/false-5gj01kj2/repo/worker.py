import os,time
time.sleep(0.08)
os.write(1,b'FP-v1-out')
os.write(2,b'FP-v1-err')
