import sys,pathlib,json,hashlib,shutil,unittest,importlib.util,io,datetime,os
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-finish-primary-kind-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'before-NEW4';q.mkdir();free=shutil.disk_usage(R).free;assert free>=1024**3
 expected={'tool/native_perf_build_producer.py':'f96d3e417c5de241b22fad5af5733c4756a0a3561016efc50c30b283e0728cef','tool/test_native_perf_build_producer.py':'c5506859ce40a221cb67b310fd458ed1b9e449b3aebcf35320292777ca067590'}
 before={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert before==expected
 (q/'fresh2-source-test.json').write_text(json.dumps(before,indent=2));(q/'floor.json').write_text(json.dumps(dict(free_bytes=free,fresh_1GiB_floor=True,no_build_capture_deletion_authority=True)))
 os.environ['CONNECTANUM_FINISH_PRIMARY_FIXTURES']=str(q/'fixtures');sys.path.insert(0,str(R/'tool'))
 spec=importlib.util.spec_from_file_location('finish_primary_scope',P/'finish_primary_kind_regressions-v1.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   leases.append(dict(test=str(test),position='before',raw_None=l.verify_identity() is None));super().startTest(test)
  def stopTest(self,test):
   leases.append(dict(test=str(test),position='after',raw_None=l.verify_identity() is None));super().stopTest(test)
 names=unittest.defaultTestLoader.getTestCaseNames(module.FinishPrimaryKindTests);assert names==['test_new_finish_primary_False_does_not_replace_First', 'test_new_finish_primary_None_does_not_replace_First', 'test_new_native_finish_primary_caller_control', 'test_new_unknown_group_completion_keeps_finish_First'];suite=unittest.TestSuite(module.FinishPrimaryKindTests(name) for name in names);stream=io.StringIO()
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(suite)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert after==before
 (q/'stdout.txt').write_text(stream.getvalue());out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),leases=leases,Source_test_fresh2_unchanged=after,Source_test_edits=False,new_BEFORE4_only=True,prior6_old27_completed25_old2bodies_old7suite_private2_replayed=False,SourceHEAD_current20recensus_or_compiledcanonical_admission=False,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(out,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['finish_primary_kind_progress']={'directory':str(P),'declaration':str(P/'declaration.json'),'before_result':out,'Source_test_edits':False,'ROOT_pending':True,'SourceHEAD_current20_not_refreshed':True};c.update(updated_utc=out['utc'],active_turn_status='Finish_primary_kind_NEW4_BEFORE_recorded_ROOTpending');cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps({k:v for k,v in out.items() if k not in ('leases','details')}));print(stream.getvalue()[-7000:])
