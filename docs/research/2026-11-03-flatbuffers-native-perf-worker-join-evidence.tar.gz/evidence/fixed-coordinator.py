import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-worker-join')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'before-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3

path=R/'tool/native_perf_build_producer.py';source=path.read_text()
def replace(old,new):
 global source
 assert source.count(old)==1,old
 source=source.replace(old,new,1)
replace("        self._owner_emit_attempted=False;self._last_result=None\n",
"        self._owner_emit_attempted=False;self._last_result=None\n        self._workers=[];self._joined_workers=0\n")
replace("            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))",
"""            worker_joined=None if not self._workers else self._workers[-1]['worker_joined'],
            worker_start_settled=None if not self._workers else self._workers[-1]['start_settled'],
            all_workers_joined=bool(self._workers) and self._joined_workers==len(self._workers),
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))""")
replace("            if self._busy:raise ProducerError('preflight phase already running or quarantined')",
"""            if self._busy:raise ProducerError('preflight phase already running or quarantined')
            if self._workers and (not self._workers[-1]['worker_joined'] or not self._workers[-1]['start_settled']):
                raise ProducerError('previous exact preflight worker has not joined with settled start')""")
replace("""            self._event=threading.Event()
            try:thread=threading.Thread(target=self._work,args=(action,value,self._event),daemon=False)""",
"""            self._event=threading.Event()
            record=dict(call_index=self._index,action=action,thread_created=False,
                start_attempted=False,start_returned=False,start_settled=False,
                worker_entered=False,call_done=False,worker_joined=False,join_error=None,
                _thread=None,_join_error_object=None)
            self._workers.append(record)
            try:thread=threading.Thread(target=self._work,args=(action,value,self._event,record),daemon=False)""")
replace("""                self._thread=None;self._state='start_uncertain';self._error_locked(error)
                self._snapshot=self._snapshot_locked();return self
            self._thread=thread;self._snapshot=self._snapshot_locked()
        try:thread.start()
        except BaseException as error:
            with self._lock:
                self._error_locked(error)
                if not self._call_done:self._state='start_uncertain'
                self._snapshot=self._snapshot_locked()
                # Do not set completion or start again: the actual worker may exist.
        return self

    def _work(self,action,value,event):
        error=None;result=None""",
"""                self._thread=None;self._state='start_uncertain';self._error_locked(error)
                record['start_settled']=True
                self._snapshot=self._snapshot_locked();return self
            self._thread=thread;record['_thread']=thread;record['thread_created']=True
            record['start_attempted']=True;self._snapshot=self._snapshot_locked()
        try:thread.start()
        except BaseException as error:
            with self._lock:
                record['start_settled']=True;self._error_locked(error)
                if not self._call_done:self._state='start_uncertain'
                self._snapshot=self._snapshot_locked()
                # Do not set completion or start again: the actual worker may exist.
        else:
            with self._lock:
                record['start_returned']=True;record['start_settled']=True
                self._snapshot=self._snapshot_locked()
        return self

    def _work(self,action,value,event,record):
        with self._lock:
            record['worker_entered']=True
            self._snapshot=self._snapshot_locked()
        error=None;result=None""")
replace("            self._last_result=result;self._call_done=True;self._busy=False",
"            self._last_result=result;self._call_done=True;self._busy=False;record['call_done']=True")
replace("""        with self._lock:event=self._event;thread=self._thread
        event.wait(timeout)
        if event.is_set() and thread is not None and thread is not threading.current_thread():
            thread.join(max(0,deadline-time.monotonic()))
        with self._lock:return self._snapshot

    def continue_wait(self,timeout):""",
"""        with self._lock:
            event=self._event;record=self._workers[-1] if self._workers else None
            thread=None if record is None else record['_thread']
        event.wait(timeout)
        # Keep the exact handle until a real join succeeds. Call/event completion
        # alone cannot release a worker or authorize another producer phase.
        if thread is not None and thread is not threading.current_thread() and thread.ident is not None:
            try:
                thread.join(max(0,deadline-time.monotonic()))
                joined=not thread.is_alive()
            except BaseException as error:
                with self._lock:
                    if record['join_error'] is None:
                        record['join_error']=type(error).__name__;record['_join_error_object']=error
                    self._snapshot=self._snapshot_locked()
            else:
                with self._lock:
                    if joined and not record['worker_joined']:
                        record['worker_joined']=True;self._joined_workers+=1
                        record['_thread']=None
                    self._snapshot=self._snapshot_locked()
        with self._lock:return self._snapshot

    def worker_lifecycle(self):
        \"\"\"Frozen call records, with no producer, Thread, FD or exception objects.\"\"\"
        with self._lock:
            return tuple(MappingProxyType({key:value for key,value in record.items() if not key.startswith('_')})
                for record in self._workers)

    def continue_wait(self,timeout):""")
ast.parse(source);path.write_text(source)
summary=runtests('fixed',['PreflightWorkerJoinTests',
 'PreflightEmissionDispatchTests',
 'OwnedPreflightTests.test_postspawn_primary_failure_keeps_same_known_child_until_natural_exit',
 'OwnedPreflightTests.test_blocked_constructor_observation_and_overlap_refusal',
 'OwnedPreflightTests.test_emit_attempt_is_terminal_and_keeps_first_error',
 'OwnedPreflightTests.test_thread_object_setup_failure_retains_returned_quarantine'])
lease.verify_identity()
print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
