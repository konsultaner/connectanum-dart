import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-worker-join')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'fixed-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
path=R/'tool/test_native_perf_build_producer.py';source=path.read_text()
marker="if __name__=='__main__':unittest.main()";assert source.count(marker)==1
source=source.replace(marker,"\n    def test_joined_worker_does_not_settle_parent_start_outcome(self):\n        start_return=self.threading.Event();release=self.threading.Event()\n        self.releases.append(release);self.held_threads=[]\n        real_start=self.threading.Thread.start;results=[];errors=[]\n        nonce=digest((str(self.base)+'start-outcome').encode())[:32]\n        self.sequence+=1\n        def start(thread):\n            real_start(thread)\n            start_return.set();release.wait(5)\n        def call():\n            try:\n                with mock.patch.object(self.threading.Thread,'start',start):\n                    results.append(producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments()))\n            except BaseException as error:errors.append(error)\n        caller=self.threading.Thread(target=call,daemon=False)\n        self.held_threads.append(caller);caller.start()\n        try:\n            self.assertTrue(start_return.wait(3))\n            owner=producer._PREFLIGHT_OWNERS[nonce];self.owners.append(owner)\n            self.held_threads.append(owner._thread)\n            view=owner.observe(2)\n            self.assertTrue(view['call_done']);self.assertTrue(view['worker_joined'])\n            self.assertFalse(view['worker_start_settled'])\n            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)\n        finally:\n            release.set();caller.join(5);self.assertFalse(caller.is_alive())\n        self.assertEqual([],errors);self.assertEqual([owner],results)\n        self.assertTrue(owner.observe(0)['worker_start_settled'])\n\n"+marker,1)
old="        def join(timeout=None):\n            calls.append(timeout)"
new="        def join(timeout=None):\n            unlocked=owner._lock.acquire(blocking=False)\n            self.assertTrue(unlocked,'join must run outside observer lock')\n            if unlocked:owner._lock.release()\n            calls.append(timeout)"
assert source.count(old)==1;source=source.replace(old,new,1)
ast.parse(source);path.write_text(source)
summary=runtests('final',['PreflightWorkerJoinTests.test_joined_worker_does_not_settle_parent_start_outcome',
'PreflightWorkerJoinTests.test_join_error_keeps_same_handle_and_first_producer_error'])
lease.verify_identity()
print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
