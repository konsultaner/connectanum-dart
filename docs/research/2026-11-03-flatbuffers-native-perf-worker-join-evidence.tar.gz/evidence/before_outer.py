import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-worker-join')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 
 P.mkdir()
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-owned-emission-dispatch/final-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assert free>=1024**3
 writej(P/'declaration.json',dict(scope='OWN finite thread join guards only; no canonical/build/kernel/benchmark/admission',free_bytes=free,scoped_floor=1024**3,build_floor=12*1024**3,source_before=expected,model_tests_direct_exit0=True,judge_final_assessment_absent=True))
 snapshot('original')
 writej(P/'model-root-qualification.json',dict(tests_session99227_direct_exit0=True,
  accepted=['Event-held actual target tail after call return; same known Thread joins outside lock; immutable lifecycle and separate join confirmation; preserve errors'],
  rejected=['continue_wait schedules producer waits; it is not a join API and does not raise timeout or producer exceptions','Producer errors remain privately retained and type-only snapshots; no CustomError propagation/operation.status invention','Repeated observe joins exact held thread; never restart, explicit termination, generic resource cleanup or pytest command','No indefinitely blocked fixture; bounded finite OWN target with retained release/join cleanup'],
  judge_session32660_outer_status='unavailable after context; not invented',judge_helper_terminal='response exceeded max-response-chars; no saved advice/final assessment',reachable_not_unavailable=True,no_unchanged_repeat=True))
 path=R/'tool/test_native_perf_build_producer.py';source=path.read_text()
 marker="if __name__=='__main__':unittest.main()"
 assert source.count(marker)==1
 source=source.replace(marker,"\nclass PreflightWorkerJoinTests(unittest.TestCase):\n    \"\"\"Exact OWN finite Thread joins; call completion is not actor admission.\"\"\"\n    git=ProducerTests.git\n    setUp=OwnedPreflightTests.setUp\n    arguments=OwnedPreflightTests.arguments\n    start_owned=OwnedPreflightTests.start_owned\n    blocked_lease=OwnedPreflightTests.blocked_lease\n\n    def drive(self,owner):\n        for _ in range(100):\n            view=owner.observe(1)\n            if not view['call_done'] or not view.get('worker_joined',True):continue\n            self.assertFalse(view['failed'],view)\n            if view['producer_finished'] and not view['producer_pending']:return view\n            owner.continue_wait(.2)\n        self.fail('OWN finite phase did not complete within fixture observations')\n\n    def tearDown(self):\n        for event in self.releases:event.set()\n        cleanup=[]\n        for thread in getattr(self,'held_threads',[]):\n            if thread.ident is not None:\n                thread.join(5);self.assertFalse(thread.is_alive())\n                cleanup.append({'ident':thread.ident,'joined':True,'scope':'known OWN fixture Thread only'})\n        for owner in self.owners:\n            view=owner.observe(2)\n            if view['initialized'] and not view['failed'] and not view['producer_finished']:\n                self.drive(owner)\n            owner.observe(2)\n        (self.base/'worker-cleanup.json').write_text(json.dumps(cleanup))\n        ProducerTests.tearDown(self)\n\n    def tail_owner(self):\n        entered=self.threading.Event();release=self.threading.Event()\n        self.releases.append(release);self.held_threads=[]\n        original=producer._RetainedPreflightOwner._work\n        def work(owner,*args):\n            original(owner,*args)\n            if args[0]=='construct':\n                entered.set();release.wait(5)\n        patcher=mock.patch.object(producer._RetainedPreflightOwner,'_work',work)\n        patcher.start();self.addCleanup(patcher.stop)\n        owner=self.start_owned();thread=owner._thread;self.held_threads.append(thread)\n        self.assertTrue(entered.wait(3))\n        return owner,thread,release\n\n    def test_call_return_cannot_replace_unjoined_actual_thread(self):\n        owner,thread,release=self.tail_owner()\n        view=owner.observe(0)\n        self.assertTrue(view['call_done']);self.assertTrue(thread.is_alive())\n        try:\n            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)\n        finally:\n            if owner._thread is not thread:self.held_threads.append(owner._thread)\n            release.set()\n        self.assertIs(thread,owner._thread)\n\n    def test_lifecycle_is_immutable_and_join_confirmation_is_separate(self):\n        owner,thread,release=self.tail_owner()\n        partial=owner.observe(0);history=owner.worker_lifecycle()\n        self.assertTrue(partial['call_done']);self.assertFalse(partial['worker_joined'])\n        self.assertFalse(partial['all_workers_joined'])\n        self.assertEqual(1,len(history));self.assertTrue(history[0]['worker_entered'])\n        self.assertTrue(history[0]['call_done']);self.assertFalse(history[0]['worker_joined'])\n        with self.assertRaises(TypeError):history[0]['worker_joined']=True\n        release.set();done=owner.observe(2)\n        self.assertTrue(done['worker_joined']);self.assertTrue(done['all_workers_joined'])\n        self.assertFalse(history[0]['worker_joined'])\n        self.assertIsNone(done['actor_ownership_complete'])\n        self.assertFalse(done['capture_ready']);self.assertFalse(done['source_admitted']);self.assertFalse(done['live_admission'])\n\n    def test_join_error_keeps_same_handle_and_first_producer_error(self):\n        check,entered,release=self.blocked_lease(raise_after=True)\n        owner=self.start_owned(check);self.assertTrue(entered.wait(3))\n        thread=owner._thread;self.held_threads=[thread]\n        real_join=thread.join;fault=OSError(5,'OWN synthetic join observation error');calls=[]\n        def join(timeout=None):\n            calls.append(timeout)\n            if len(calls)==1:raise fault\n            return real_join(timeout)\n        release.set()\n        with mock.patch.object(thread,'join',side_effect=join):\n            partial=owner.observe(2)\n            self.assertTrue(partial['failed']);self.assertTrue(partial['call_done'])\n            self.assertFalse(partial['worker_joined'])\n            self.assertEqual('RuntimeError',partial['first_error'])\n            self.assertEqual('OSError',owner.worker_lifecycle()[0]['join_error'])\n            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)\n            done=owner.observe(2)\n        self.assertGreaterEqual(len(calls),2);self.assertTrue(done['worker_joined'])\n        self.assertEqual('RuntimeError',done['first_error'])\n        self.assertEqual('OSError',owner.worker_lifecycle()[0]['join_error'])\n        self.assertIs(thread,owner._thread)\n\n    def test_uncertain_start_keeps_unjoined_actual_handle(self):\n        with mock.patch.object(self.threading.Thread,'start',side_effect=OSError(5,'OWN start uncertainty')):\n            owner=self.start_owned()\n        thread=owner._thread;self.assertIsNotNone(thread);self.assertIsNone(thread.ident)\n        view=owner.observe(0);history=owner.worker_lifecycle()\n        self.assertFalse(view['call_done']);self.assertFalse(view['worker_joined'])\n        self.assertTrue(history[0]['thread_created']);self.assertTrue(history[0]['start_attempted'])\n        self.assertFalse(history[0]['start_returned']);self.assertFalse(history[0]['worker_joined'])\n        with self.assertRaises(producer.ProducerError):owner.continue_wait(0)\n        self.assertIs(thread,owner._thread)\n\n    def test_all_phase_records_require_join_and_keep_order(self):\n        owner=self.start_owned();view=self.drive(owner)\n        before=owner.worker_lifecycle()\n        def emit(run,phase):return {'kind':'fixture-interface-only','capture_ready':False}\n        with mock.patch.object(producer,'emit_fixture_receipt',autospec=True,side_effect=emit):\n            owner.emit('canonical');view=owner.observe(2)\n        history=owner.worker_lifecycle()\n        self.assertEqual(list(range(1,len(history)+1)),[v['call_index'] for v in history])\n        self.assertEqual('construct',history[0]['action']);self.assertEqual('emit',history[-1]['action'])\n        self.assertTrue(all(v['call_done'] and v['worker_joined'] for v in history))\n        self.assertEqual(len(before)+1,len(history));self.assertTrue(view['all_workers_joined'])\n        self.assertIsNone(view['actor_ownership_complete']);self.assertFalse(view['live_admission'])\n\n"+marker,1)
 ast.parse(source);path.write_text(source)
 summary=runtests('before',['PreflightWorkerJoinTests'])
 lease.verify_identity()
 print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
 