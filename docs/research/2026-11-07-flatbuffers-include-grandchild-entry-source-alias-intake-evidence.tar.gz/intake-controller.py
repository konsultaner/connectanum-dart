import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-include-child-directory-scope-v1/new63-FIRST-remaining-static-binding-Actions-v1';P=B/'2026-11-07-actions-include-grandchild-entry-source-alias-intake-v1';O=A/'ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json';I=A/'actual-new-artifact-member-index.json';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST saved-data source/alias intake ALL1425NEWoneleveldirectory-entry records fromoriginalActions42365704161/sourceed183100f5dff2c40a1a748b630960979114094f. Exactoriginalsavedresult/index/report/CP sources andboundedranges declaredBEFOREcontentIO; pointFDsize ranges forindex/CP declaredonopenedFD BEFOREcontentIO. Report/index ONLYlocate originalrecords, no oldacquisition-journal/body-reader-parser/model/API/Actions/archive revalidation/replay. ALL63literalparents+EACHchildbasename remainSEPARATE; originalnativeorder/duplicates/names-namehex-modes-UIDGID/fulloriginalstat-times/ALL6NEWrawlinkbytes-literals UNEXPANDED-UNFOLLOWED retained. No join/pathsplit/normalize/resolve/follow/recursion/SDKquery/childbodyopen-hash/candidateexecution/import-headercompile/bootstrap/dependency/build/driver/perf/numerical/Source20-runtime adoption. ALLprior1280/49queryepochs/1199latelexical/63originalDEFERRED/18earlierlinks/oldtopncurses.h-curses.h originalrawhexNOTsavedNULL/priorledgers unchanged vsNEW63queryepoch. Compare ONLYsaved literalnames/namehex/readlinkliteral/rawhex vsALLstrings underEVERYprior CP actions_ node except current63acquisition node andNEWintake node, preserving everymatch/nonmatch/location/offset; fixedscope notfavorablelanguage-version-ABI/type filter. Matches/nonmatchesNOTabsence/newness/alias/bodycoverage/effectivecompiler-sysroot-ABI/access/credentials/ownership/permission/queryauthority. None linkfield meansUNPERFORMEDNULL notzero. PointFDcountSHA/stat/close notatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission; missingouterPID-EOFNULL.',
 'exact_sources':[{'role':'original_saved_result','path':str(O),'range':[0,13814766],'sha256':'85e36d181b234b30d651ff094f1b979d578dea0e564755c4392aac077fc44b3e'},{'role':'original_index_ONLYlocate_report','path':str(I),'range':'pointFDsize declaredBEFOREcontentIO'},{'role':'located_report_ONLYoriginal_records','original_basename':'include-child-directory-inputs.json','range':[0,7723348],'sha256':'2b0f809eee9eeefa9d9aed20060a96c69a834eb5059497174eebc47f97a19907'},{'role':'prior_CP_metadata','path':str(CP),'range':'pointFDsize declaredBEFOREcontentIO','ALL_prior_actions_nodes_excluding_exact_names':['actions_include_child_directory_inputs_v1','actions_include_grandchild_entry_source_alias_intake_v1']}],'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def metadata_read(path,size=None,expected=None,role=''):
  binding={'role':role,'path':str(path),'open_return_fd':None,'close_return_fd':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd
  try:
   s=os.fstat(fd);before={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']};assert stat.S_ISREG(s.st_mode);binding['before']=before
   if size is None:
    size=s.st_size;save(role+'-exact-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2))
   assert s.st_size==size;binding['declared_range']=[0,size];parts=[];sha=hashlib.sha256();count=0
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyEOF permanentquarantine';parts.append(chunk);sha.update(chunk);count+=len(chunk)
   assert os.read(fd,1)==b'';z=os.fstat(fd);after={k:getattr(z,k) for k in before};binding.update(after=after,bytes=count,sha256=sha.hexdigest(),EOF=True);assert before==after and count==size
   if expected is not None:assert sha.hexdigest()==expected
   return b''.join(parts)
  finally:
   os.close(fd);binding['close_return_fd']=fd

 originalraw=metadata_read(O,13814766,'85e36d181b234b30d651ff094f1b979d578dea0e564755c4392aac077fc44b3e','original_saved_result');original=json.loads(originalraw);save('original-full-saved-result-bound-PRIVATE.json',originalraw)
 indexraw=metadata_read(I,role='original_index');index=json.loads(indexraw);found=[r for r in index if pathlib.PurePosixPath(r['name']).name=='include-child-directory-inputs.json'];assert len(found)==1;ir=found[0];name=pathlib.PurePosixPath(ir['name']);assert not name.is_absolute() and '..' not in name.parts and ir['bytes']==7723348 and ir['sha256']=='2b0f809eee9eeefa9d9aed20060a96c69a834eb5059497174eebc47f97a19907';RP=A/'artifact-members'/ir['name']
 save('located-report-exact-source-range-BEFORE-content-IO.json',json.dumps({'path':str(RP),'range':[0,7723348],'sha256':ir['sha256'],'index_ONLYlocates_original_records_notprior_journal_comparison':True},indent=2));reportraw=metadata_read(RP,7723348,ir['sha256'],'original_report');report=json.loads(reportraw)
 assert original['ALL63_original_observations']==report['observations'] and len(report['observations'])==63 and report['workflow_revision']==original['source_commit']=='ed183100f5dff2c40a1a748b630960979114094f' and str(report['run_id'])==str(original['run_id'])=='42365704161'
 save('original-index-bound-PRIVATE.json',indexraw);save('original-report-bound-PRIVATE.json',reportraw)
 cpraw=metadata_read(CP,role='prior_CP_metadata');prior=json.loads(cpraw);save('original-prior-CP-bound-PRIVATE.json',cpraw)
 excluded=declaration['exact_sources'][3]['ALL_prior_actions_nodes_excluding_exact_names'];nodes=[key for key in prior if key.startswith('actions_') and key not in excluded];scalars=[]
 def walk(x,path):
  if isinstance(x,str):scalars.append({'location':path,'value':x})
  elif isinstance(x,dict):
   for key,value in x.items():walk(value,path+[key])
  elif isinstance(x,list):
   for ordinal,value in enumerate(x):walk(value,path+[ordinal])
 for key in nodes:walk(prior[key],[key])
 def matches(candidate):
  if candidate is None:return None
  assert isinstance(candidate,str) and candidate!='';out=[]
  for scalar in scalars:
   value=scalar['value'];positions=[];start=0
   while True:
    at=value.find(candidate,start)
    if at<0:break
    positions.append(at);start=at+1
   if positions:out.append({'location':scalar['location'],'original_scalar':value,'literal_character_offsets':positions,'UTF8_byte_offsets':[len(value[:at].encode('utf-8',errors='surrogatepass')) for at in positions],'exact_scalar_equal':value==candidate})
  return out
 relationships=[];typecounts=collections.Counter();linkrecords=[];namematched=0;hexmatched=0;linkmatched=0;linkhexmatched=0
 for parentordinal,parent in enumerate(report['observations']):
  assert parent['ordinal']==parentordinal and 'absent_at_open_only' not in parent
  for entryordinal,entry in enumerate(parent['entries']):
   assert entry['ordinal']==entryordinal and entry['parent_reference_separate_NOT_joined']==parent['source_directory_reference']
   name=entry['name'];namehex=entry['name_bytes_hex'];assert os.fsdecode(bytes.fromhex(namehex))==name and name not in ['','.','..'] and '/' not in name and '\0' not in name
   s=entry.get('separate_lstat');mode=None if s is None else s['st_mode'];typ='unknown' if mode is None else 'regular' if stat.S_ISREG(mode) else 'directory' if stat.S_ISDIR(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other';typecounts[typ]+=1
   link=entry['separate_readlink_literal'];linkhex=entry['separate_readlink_bytes_hex']
   if typ=='symlink':assert link is not None and linkhex is not None and os.fsdecode(bytes.fromhex(linkhex))==link
   else:assert link is None and linkhex is None
   safe={'source_originalActions_run_id':original['run_id'],'source_originalActions_revision':original['source_commit'],'parent_query_ordinal_ZERO_based':parentordinal,'child_entry_ordinal_ZERO_based':entryordinal,'literal_parent_reference_SEPARATE':parent['source_directory_reference'],'literal_child_name_SEPARATE':name,'original_name_bytes_hex':namehex,'saved_type_derived_from_original_mode':typ,'original_separate_lstat_full_stat_times_PRIVATE':s,'original_separate_readlink_literal_UNEXPANDED_UNFOLLOWED':link,'original_separate_readlink_rawhex_UNEXPANDED_UNFOLLOWED':linkhex,'original_full_child_record_PRIVATE':entry,'original_parent_query_record_except_children_PRIVATE':{k:value for k,value in parent.items() if k!='entries'},'parent_child_NOT_joined_resolved_followed_or_executed':True,'alias_identity':None}
   nm=matches(name);hm=matches(namehex);lm=matches(link);lhm=matches(linkhex);namematched+=bool(nm);hexmatched+=bool(hm);linkmatched+=bool(lm);linkhexmatched+=bool(lhm)
   relation={'new_saved_record_position_ONE_based':len(relationships)+1,'original_separate_parent_child_metadata':safe,'ALL_prior_CP_name_matches_PRIVATE':nm,'ALL_prior_CP_namehex_matches_PRIVATE':hm,'ALL_prior_CP_link_literal_matches_PRIVATE':lm,'ALL_prior_CP_link_rawhex_matches_PRIVATE':lhm,'prior_CP_name_scalar_match_count':len(nm),'prior_CP_namehex_scalar_match_count':len(hm),'prior_CP_link_literal_scalar_match_count':None if lm is None else len(lm),'prior_CP_link_rawhex_scalar_match_count':None if lhm is None else len(lhm),'link_comparison_performed':link is not None,'alias_identity':None,'query_permission_from_matches_or_nonmatches':None};relationships.append(relation)
   if typ=='symlink':linkrecords.append(safe)
 assert len(relationships)==1425 and dict(typecounts)=={'regular':1229,'directory':190,'symlink':6} and len(linkrecords)==6
 summary={'source_run_id':original['run_id'],'source_revision':original['source_commit'],'ALL63_original_parent_queries_preserved':63,'ALL1425_original_new_child_records':1425,'type_counts_from_original_modes':dict(typecounts),'ALL6_NEW_readlink_records_UNEXPANDED_UNFOLLOWED':6,'prior_CP_actions_node_count':len(nodes),'prior_CP_string_scalar_count':len(scalars),'record_name_candidates_with_prior_CP_scalar_matches':namematched,'record_name_candidates_without_prior_CP_scalar_matches':1425-namematched,'record_namehex_candidates_with_prior_CP_scalar_matches':hexmatched,'record_namehex_candidates_without_prior_CP_scalar_matches':1425-hexmatched,'symlink_literal_candidates_with_prior_CP_matches':linkmatched,'symlink_literal_candidates_without_prior_CP_matches':6-linkmatched,'symlink_rawhex_candidates_with_prior_CP_matches':linkhexmatched,'symlink_rawhex_candidates_without_prior_CP_matches':6-linkhexmatched,'link_comparisons_performed':6,'link_comparisons_UNPERFORMED_NULL':1419,'saved_metadata_read_binding_count':len(bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_headerbody_reads':0,'new_recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'ALL1425_original_child_relationships_with_NEW_counts':relationships,'ALL6_original_NEW_symlink_metadata_UNEXPANDED_UNFOLLOWED':linkrecords,'ALL63_original_parent_query_records_PRIVATE_preserved':report['observations'],'original_saved_result_ALL_fields_PRIVATE_preserved':original,'original_report_ALL_fields_PRIVATE_preserved':report,'original_index_ALL_fields_PRIVATE_preserved':index,'ALL_prior_CP_nodes_selected':nodes,'ALL_prior_CP_scalars_PRIVATE':scalars,'ALL_four_savedmetadata_read_bindings_PRIVATE_fullstat-times':bindings,'original_metadata_sources':declaration['exact_sources']}
 raw=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL1425-grandchild-entry-source-alias-intake-PRIVATE.json',raw);descriptor={'result_saved':'ROOT-FIRST-ALL1425-grandchild-entry-source-alias-intake-PRIVATE.json','result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-intake-result.json',before);d=json.loads(before);d['actions_include_grandchild_entry_source_alias_intake_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL1425_saved_entry_source_alias_relationships_NOT_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(raw),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_grandchild_entry_source_alias_intake='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL1425savedentry metadata/priorCPname-namehex-link relationships COMPLETE_CONSUMED; fourdeclaredsavedmetadata bindings/no SDKquery orbodyread. Summary thenFIRSTpublication fromoriginalsavedresult only. Priorrecords/stat-times/epochs/6NEWlinks-18earlierlinksUNEXPANDED/oldncursesrawhexNULL protected. No oldquery-reader-parser-model-Actions-acquisition-archive-numerical replay/Source20-runtime adoption/build.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
