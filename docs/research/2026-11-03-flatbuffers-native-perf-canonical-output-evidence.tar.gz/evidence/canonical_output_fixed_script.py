import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-canonical-output')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads((P/'implemented-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 original=(P/'original-source/tool/native_perf_build_producer.py').read_text()
 target=R/'tool/native_perf_build_producer.py';source=target.read_text()
 patterns=lambda text:[n.args[0].value for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='fullmatch' and n.args and isinstance(n.args[0],ast.Constant) and 'libct_core' in str(n.args[0].value)]
 old=patterns(original);new=patterns(source);assert len(old)==len(new)==1
 assert old[0]!=new[0]
 wrong=repr(new[0]);right=repr(old[0])
 # Match the raw source literal selected by its AST value, retaining the original regex.
 regexnode=next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='fullmatch' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value==new[0])
 literal=ast.get_source_segment(source,regexnode.args[0]);assert source.count(literal)==1
 source=source.replace(literal,right,1);assert patterns(source)==old;ast.parse(source);target.write_text(source)
 names=['CanonicalOutputPathTests','OwnedOutputLocationTests',
  'ProducerTests.test_production_factory_refuses_nonlinux_before_reservation',
  'ProducerTests.test_production_recipe_factory_only_synthetic_argv_observation',
  'ProducerTests.test_canonical_recipe_factory_only_synthetic_argv_observation']
 summary=runtests('fixed',names)
 writej(P/'intermediate-error-qualification.json',dict(scope='Introduced helper extraction escaping error, not a production performance defect',
  actual_first_implemented_tests=14,actual_errors=1,actual_passes=13,
  error='Transferred RLIB pattern was double-escaped and rejected an OWN data-only valid RLIB path',
  correction='Restore exact original regex AST value; no production target or recipe change',
  all_first_failure_evidence_retained=True))
 lease.verify_identity()
 print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
