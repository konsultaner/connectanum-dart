"""Synthetic census/ELF/log fixtures only; no live provider or runtime capture."""
import hashlib
import json
import os
from pathlib import Path
import unittest
import tempfile
from unittest.mock import patch

import native_perf_admission as admission
from native_perf_guard import FrozenLaunch
import test_native_perf_input_census as census_fixtures

BASE=Path(os.environ['CONNECTANUM_PERF_ADMISSION_FIXTURES']).resolve()
REPO=Path(__file__).resolve().parent.parent
POLICY=Path('/tmp/connectanum-601-native-perf-source-policy-binding.json')
SCENARIOS=Path('/tmp/connectanum-601-native-perf-source-policy-binding/selected-generator/scenarios')


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.root=BASE/self._testMethodName;self.root.mkdir(parents=True)
        self.output_parent=Path(tempfile.mkdtemp(prefix='ct-cap-',dir='/tmp')).resolve()
        self.output=self.output_parent/'r'
        (self.root/'fixture-owned-capture-parent.json').write_text(json.dumps({'fixture_only':True,'path':str(self.output_parent)}))
        self.fixture=census_fixtures.InputCensusTests('runTest');self.fixture.setUp();self.fixture._testMethodName=self._testMethodName
        self.addCleanup(self.fixture.doCleanups)
        self.checked=self.fixture.verify();self.context=self.fixture.context
        self.env={'CONNECTANUM_SKIP_NATIVE_BUILD':'1','CONNECTANUM_BENCH_WAMP_REUSE_WORKER':'1','OWN_SECRET':'do-not-publish-this-value'}
        self.extra={}
        for name in ['perf_elf','python_elf','router_config']:
            p=self.root/name;p.write_bytes(b'OWN synthetic '+name.encode());p.chmod(0o600)
            self.extra[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        self.scenarios={}
        for p in sorted(SCENARIOS.glob('*.toml')):
            target=self.root/p.name;target.write_bytes(p.read_bytes());target.chmod(0o600)
            self.scenarios[p.name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
        self.tools={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in REPO.glob('tool/*native_perf*.py')}
        self.kwargs=dict(context=self.context,checked=self.checked,policy_bytes=POLICY.read_bytes(),scenarios=self.scenarios,
            source_root=REPO,tool_hashes=self.tools,extra_files=self.extra,output_dir=self.output,
            environment=self.env,gid=os.getegid(),nonce='c'*32)
        self.reservations=[];self.addCleanup(self.close_all)

    def close_all(self):
        for reservation in self.reservations:reservation.close()

    def declaration(self,**changes):return admission.CaptureDeclaration.prepare(**{**self.kwargs,**changes})
    def reservation(self):
        value=admission.CaptureReservation(self.declaration());self.reservations.append(value);return value

    def test_policy_all10_original_order_330_proposed_rows(self):
        decl=self.declaration();value=decl.as_dict();policy=json.loads(POLICY.read_bytes())
        self.assertEqual([x['scenario'] for x in value['runs']],[x['scenario'] for x in policy['runs']])
        self.assertEqual([x['order'] for x in value['runs']],[x['order'] for x in policy['runs']])
        self.assertEqual(sum(len(x['order']) for x in value['runs']),330)
        self.assertEqual(value['scope'],'prelaunch_manifest_binding_only');self.assertFalse(value['capture_ready'])
        self.assertEqual(len(value['tool_hashes']),20)

    def test_original_argv_and_env_values_never_published(self):
        decl=self.declaration();value=decl.as_dict();launch=decl.launch(0)
        self.assertIsInstance(launch,FrozenLaunch)
        self.assertEqual(launch.argv[1:3],('--dart','dart'));self.assertIn('--collect-wamp-vm-metrics',launch.argv)
        self.assertNotIn(self.env['OWN_SECRET'],json.dumps(value));self.assertEqual(dict(launch.environment),self.env)

    def test_declaration_deep_freeze_not_mutable_alias(self):
        decl=self.declaration();old=decl.raw
        self.env['OWN_SECRET']='changed';self.tools.clear();self.extra['perf_elf']['sha256']='f'*64
        v=decl.as_dict();v['runs'][0]['order'].reverse()
        self.assertEqual(decl.raw,old);self.assertEqual(dict(decl.launch(0).environment)['OWN_SECRET'],'do-not-publish-this-value')

    def test_wrong_policy_or_subset_refuses(self):
        with self.assertRaises(admission.AdmissionError):self.declaration(policy_bytes=b'{}')
        broken=dict(self.scenarios);broken.pop(next(iter(broken)))
        with self.assertRaises(admission.AdmissionError):self.declaration(scenarios=broken)

    def test_changed_scenario_bytes_refuses_before_fixture_start(self):
        r=self.reservation();p=Path(next(iter(self.scenarios.values()))['path']);p.write_bytes(b'changed')
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))
        self.assertTrue((self.output/'attempt.json').is_file())

    def test_changed_pinned_native_retains_terminal_reservation(self):
        r=self.reservation();Path(self.checked.files['native_elf']['path']).write_bytes(b'changed ELF')
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))
        with self.assertRaises(FileExistsError):admission.CaptureReservation(self.declaration())

    def test_existing_partial_output_directory_forever_terminal(self):
        out=self.output;out.mkdir();(out/'attempt.json').write_bytes(b'partial')
        with self.assertRaises(FileExistsError):admission.CaptureReservation(self.declaration())
        self.assertEqual((out/'attempt.json').read_bytes(),b'partial')

    def test_pinned_fd_sourcepath_replacement_refuses(self):
        r=self.reservation();p=Path(self.extra['router_config']['path']);old=p.with_suffix('.retained');p.rename(old);p.write_bytes(old.read_bytes());p.chmod(0o600)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))

    def test_fixture_stages_strict_order_and_expected_evaluation_digest(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256)
        self.assertEqual(r.authorize_fixture('START',0,p)['kind'],'fixture_only_permission')
        r.authorize_fixture('ENABLE',0,p);r.authorize_fixture('GO',0,p)
        r.finish_fixture(0,driver_exit=0,sampler_exit=0,rows=33)
        r.authorize_fixture('START',1,p)

    def test_nonzero_partial_fixture_finish_retains_status_and_stops(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256)
        for stage in ['START','ENABLE','GO']:r.authorize_fixture(stage,0,p)
        value=r.finish_fixture(0,driver_exit=-15,sampler_exit=2,rows=4)
        self.assertEqual(value['driver_exit'],-15);self.assertEqual(value['rows'],4)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',1,p)

    def test_live_authorization_cannot_be_minted_by_json_or_fixture(self):
        r=self.reservation()
        for alleged in [None,{'ready':True,'capture_ready':True},admission.FixturePreflight(r.declaration.sha256)]:
            with self.assertRaises(admission.UnresolvedLiveAdmission):admission.require_live_admission(alleged)
        self.assertFalse(r.declaration.as_dict()['capture_ready'])

    def test_twenty_tool_set_and_scalar_types_refuse(self):
        bad=dict(self.tools);bad.pop(next(iter(bad)))
        with self.assertRaises(admission.AdmissionError):self.declaration(tool_hashes=bad)
        with self.assertRaises(admission.AdmissionError):self.declaration(gid=True)
        with self.assertRaises(admission.AdmissionError):self.declaration(nonce='not-hex')

    def test_close_relinquishes_fd_ownership_once(self):
        r=self.reservation();real=os.close
        def uncertain(fd):real(fd);raise OSError(5,'synthetic close ambiguity')
        with patch('native_perf_admission.os.close',side_effect=uncertain) as close:
            with self.assertRaises(OSError):r.close()
            count=close.call_count;r.close();self.assertEqual(close.call_count,count)


    def test_refused_stage_is_terminal_without_corrected_retry(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('GO',0,p)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,p)

    def test_partial_stage_report_refuses_before_second_recheck(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256);original=r._write
        def partial(name,value):
            if name=='fixture-0-start.json':
                (r.path/name).write_bytes(b'partial')
                raise OSError(28,'synthetic output full')
            return original(name,value)
        with patch.object(r,'_write',side_effect=partial):
            with self.assertRaises(OSError):r.authorize_fixture('START',0,p)
        with patch.object(r,'recheck',side_effect=AssertionError('must refuse before second artifact sweep')):
            with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,p)
        self.assertEqual((r.path/'fixture-0-start.json').read_bytes(),b'partial')

    def test_census_file_instance_must_remain_bound_to_checked_record(self):
        decl=self.declaration();p=Path(self.checked.files['driver_elf']['path']);old=p.with_suffix('.retained')
        p.rename(old);p.write_bytes(old.read_bytes());p.chmod(0o600)
        with self.assertRaises(admission.AdmissionError):
            r=admission.CaptureReservation(decl);self.reservations.append(r)

    def test_direct_constructor_cannot_skip_prepare(self):
        with self.assertRaises(admission.AdmissionError):admission.CaptureDeclaration(b'{}',())

    def test_evaluated_digest_mismatch_is_terminal(self):
        r=self.reservation()
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight('f'*64))
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))

    def test_long_unix_listener_path_refuses_before_reservation(self):
        out=self.root/('x'*101)
        with self.assertRaises(admission.AdmissionError):self.declaration(output_dir=out)
        self.assertFalse(out.exists())

    def test_checked_census_context_cannot_be_retagged(self):
        from native_perf_input_census import CensusContext
        ctx=CensusContext(self.context.census_id,'d'*40,self.context.runtime_commit,self.context.owner_uid,self.context.elf_machine,
            {k:dict(v) for k,v in self.context.lock_hashes.items()},dict(self.context.sdks))
        with self.assertRaises(admission.AdmissionError):self.declaration(context=ctx)

    def test_closed_reservation_cannot_bind_even_matching_session(self):
        import types
        r=self.reservation();d=r.declaration.as_dict();run=d['runs'][0];files=d['files']
        spec=types.SimpleNamespace(declaration=r.declaration.sha256,nonce=run['nonce'],directory=run['directory'],
            controller_uid=d['owner_uid'],controller_gid=d['gid'],driver_path=files['census/driver_elf']['path'],
            driver_sha=files['census/driver_elf']['sha256'],perf_path=files['perf_elf']['path'],perf_sha=files['perf_elf']['sha256'],
            bootstrap_image=files['python_elf']['sha256'],bundle_sha=d['tool_bundle_sha256'])
        r.close()
        with self.assertRaises(admission.AdmissionError):r.bind_fixture_session(spec,0)



class MethodReceiptIntakeTests(unittest.TestCase):
    """OWN synthetic data only. No kernel case, subprocess or live permission."""
    def setUp(self):
        self.root=BASE/self._testMethodName;self.root.mkdir(parents=True)
        self.inputs_root=self.root/'inputs';self.inputs_root.mkdir()
        self.receiver={name:'b'*64 for name in admission.TOOL_FILES}
        self.historical={name:'a'*64 for name in admission.TOOL_FILES}
        self.d={'kind':'own-unprivileged-linux-method-context-v3-intake','source_head':admission.RUNTIME,
            'all20source_sha256':self.historical,'method_sha256':'c'*64,'orchestrator_sha256':'d'*64,
            'source_context_binding':{'guest_uid':1000,'guest_gid':1000,'host_controller_uid_data':501,
                'kind':'own-unprivileged-linux-method-v3','source_owner_namespace':'guest_controller'},
            'image_reference':'fixed-method-image','image_config_digest':'fixed-config',
            'case_nonces':{},'capture_ready':False,'live_admission':False}
        self.manifest={'kind':'own-unprivileged-linux-method-v3','all20source_sha256':dict(self.historical),
            'method_sha256':'c'*64,'method_python_elf_sha256':'e'*64,'container_id':'f'*64,
            'source_context':{'expected_guest_uid':1000,'expected_guest_gid':1000,'host_controller_uid_data':501,
                'source_owner_namespace':'guest_controller'},'image_reference':'fixed-method-image',
            'image_config_digest':'fixed-config','case_nonces':{},
            'capture_ready':False,'live_admission':False,'source_admitted':False}
        self.context={'kind':'namespaced_unprivileged_method_only','uid':1000,'gid':1000,'capture_ready':False}
        self.guest={'scope':'namespaced_unprivileged_Linux_method_only','capture_ready':False,'live_admission':False,
            'errors':[],'results':[{'case':case,'pid':pid,'status':status,'errors':[]}
                for case,pid,status in zip(('fdexec-positive','pre-go-eof-negative','handoff'),(7,8,9),(0,78,0))]}
        self.guest['known_actor_statuses']=json.loads(json.dumps(self.guest['results']))
        command={'kind':'auxiliary-command-observation-v1','capture_ready':False,'status':'success',
            'returncode':0,'primary_error':None,'spawn_error':None,'secondary_errors':[],
            'whole_descendant_exit_proven':False,'outputs':{name:{'eof':True,'quarantined':False,
                'snapshot_matches_stream':True} for name in ('stdout','stderr')}}
        self.host={'scope':'actual_namespaced_unprivileged_Linux_method_ONLY','capture_ready':False,
            'source_admitted':False,'live_admission':False,'pending_records':[],
            'container_id':'f'*64,'method_python_elf_sha256':'e'*64,
            'container_state':{'Status':'exited','ExitCode':0,'Running':False,'OOMKilled':False},
            'known_actor_statuses':[{k:r[k] for k in ('case','pid','status')} for r in self.guest['results']],
            'command_records':[json.loads(json.dumps(command)) for _ in range(8)]}
        self.output=self.root/'observation'
        self.publish_inputs()

    def publish_inputs(self):
        def raw(doc):return json.dumps(doc,sort_keys=True).encode()
        d_raw=raw(self.d);digest=hashlib.sha256(d_raw).hexdigest()
        self.manifest['declaration_sha256']=digest;self.host['declaration_sha256']=digest;self.context['declaration_sha256']=digest
        self.host['manifest_sha256']=hashlib.sha256(raw(self.manifest)).hexdigest()
        self.host['artifact_records']=[{'path':name,'sha256':hashlib.sha256(raw(doc)).hexdigest(),'size':len(raw(doc))}
            for name,doc in [('context.json',self.context),('summary.json',self.guest)]]
        docs={'declaration.json':self.d,'bundle/manifest.json':self.manifest,'summary.json':self.host,
            'guest-raw/context.json':self.context,'guest-raw/summary.json':self.guest}
        self.inputs={}
        for name,doc in docs.items():
            path=self.inputs_root/name;path.parent.mkdir(parents=True,exist_ok=True);data=raw(doc)
            if path.exists():
                retained=self.root/('retained-'+name.replace('/','-')+'-'+hashlib.sha256(path.read_bytes()).hexdigest()[:12])
                if not retained.exists():retained.write_bytes(path.read_bytes())
            path.write_bytes(data);path.chmod(0o600)
            self.inputs[name]={'path':str(path),'sha256':hashlib.sha256(data).hexdigest()}

    def intake(self,**changes):
        return admission.intake_method_receipts(**{'inputs':self.inputs,'output_dir':self.output,
            'receiver_tool_hashes':self.receiver,'owner_uid':os.geteuid(),**changes})

    def test_valid_historical_epoch_is_separate_and_never_authority(self):
        value=self.intake()
        self.assertEqual(value['kind'],'historical_method_receipt_linkage_only')
        self.assertEqual(value['historical_tool_hashes'],self.historical)
        self.assertEqual(value['receiver_tool_hashes_declared'],self.receiver)
        self.assertEqual([r['status'] for r in value['reported_cases']],[0,78,0])
        for name in ('capture_ready','source_admitted','live_admission'):self.assertIs(value[name],False)
        self.assertEqual(len(value['unresolved']),4)
        with self.assertRaises(admission.UnresolvedLiveAdmission):admission.require_live_admission(value)
        for index,name in enumerate(('declaration.json','bundle/manifest.json','summary.json','guest-raw/context.json','guest-raw/summary.json')):
            self.assertEqual((self.output/('input-'+str(index)+'.raw')).read_bytes(),Path(self.inputs[name]['path']).read_bytes())

    def test_scope_refusal_is_terminal_before_second_input_read(self):
        self.context['kind']='original_host_root';self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()
        self.assertTrue((self.output/'attempt.json').exists());self.assertTrue((self.output/'refused.json').exists())
        with patch.object(admission.os,'read',side_effect=AssertionError('second input read')):
            with self.assertRaises(FileExistsError):self.intake()

    def test_bool_status_is_refused_after_valid_hash_links(self):
        self.guest['results'][0]['status']=False;self.guest['known_actor_statuses'][0]['status']=False
        self.host['known_actor_statuses'][0]['status']=False;self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()

    def test_bool_uid_is_not_fixed_guest1000(self):
        self.context['uid']=True;self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()

    def test_incomplete_logged_stderr_is_refused(self):
        self.host['command_records'][7]['outputs']['stderr']['eof']=False;self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()

    def test_reordered_cases_refused_without_favorable_selection(self):
        self.guest['results'].reverse();self.guest['known_actor_statuses'].reverse()
        self.host['known_actor_statuses'].reverse();self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()

    def test_retagged_historical_source_epoch_refused(self):
        self.manifest['all20source_sha256']['tool/native_perf_guard.py']='0'*64;self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()

    def test_duplicate_key_refused_and_exact_consumed_raw_retained(self):
        name='declaration.json';p=Path(self.inputs[name]['path']);original=p.read_bytes()
        (self.root/'original-declaration.raw').write_bytes(original)
        p.write_bytes(original[:-1]+b', "capture_ready": false}')
        self.inputs[name]['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
        with self.assertRaises(admission.AdmissionError):self.intake()
        self.assertEqual((self.output/'input-0.raw').read_bytes(),p.read_bytes())

    def test_hash_mismatch_retains_raw_without_parser_retry(self):
        self.inputs['declaration.json']['sha256']='0'*64
        with self.assertRaises(admission.AdmissionError):self.intake()
        self.assertEqual((self.output/'input-0.raw').read_bytes(),Path(self.inputs['declaration.json']['path']).read_bytes())

    def test_oversize_refuses_before_read(self):
        p=Path(self.inputs['declaration.json']['path']);(self.root/'original-small.raw').write_bytes(p.read_bytes())
        p.write_bytes(b'x'*(1024**2+1));self.inputs['declaration.json']['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
        with patch.object(admission.os,'read',side_effect=AssertionError('oversized read')):
            with self.assertRaises(admission.AdmissionError):self.intake()

    def test_same_bytes_replacement_refused_by_instance(self):
        original=admission.os.read;replaced=False;p=Path(self.inputs['declaration.json']['path'])
        def read(fd,size):
            nonlocal replaced
            data=original(fd,size)
            if not replaced:
                replaced=True;p.rename(self.root/'retained-original-inode.raw');p.write_bytes(data);p.chmod(0o600)
            return data
        with patch.object(admission.os,'read',side_effect=read):
            with self.assertRaises(admission.AdmissionError):self.intake()

    def test_partial_read_prefix_retained_and_primary_survives_close(self):
        read=admission.os.read;close=admission.os.close;calls=0;input_fd=None;closed=[]
        def observed_read(fd,size):
            nonlocal calls,input_fd
            input_fd=fd;calls+=1
            if calls==1:return read(fd,min(size,7))
            raise OSError(13,'OWN injected read error')
        def observed_close(fd):
            close(fd)
            if fd==input_fd and not closed:
                closed.append(fd);raise OSError(5,'OWN post-real-close uncertainty')
        with patch.object(admission.os,'read',side_effect=observed_read),patch.object(admission.os,'close',side_effect=observed_close):
            with self.assertRaises(OSError) as caught:self.intake()
        self.assertEqual(caught.exception.errno,13);self.assertEqual(len(closed),1)
        self.assertEqual((self.output/'input-0.raw').read_bytes(),Path(self.inputs['declaration.json']['path']).read_bytes()[:7])
        self.assertFalse((self.output/'observation.json').exists())

    def test_data_authority_flag_integer_alias_refused(self):
        self.manifest['capture_ready']=0;self.publish_inputs()
        with self.assertRaises(admission.AdmissionError):self.intake()


    def test_partial_observation_is_terminal_without_overwrite(self):
        original=admission.os.write;injected=False
        def partial(fd,data):
            nonlocal injected
            if not injected and b'"kind":"historical_method_receipt_linkage_only"' in data:
                injected=True;original(fd,data[:17]);raise OSError(28,'OWN partial observation write')
            return original(fd,data)
        with patch.object(admission.os,'write',side_effect=partial):
            with self.assertRaises(OSError) as caught:self.intake()
        self.assertEqual(caught.exception.errno,28);self.assertTrue(injected)
        raw=(self.output/'observation.json').read_bytes();self.assertEqual(len(raw),17)
        with patch.object(admission.os,'read',side_effect=AssertionError('terminal means no second input read')):
            with self.assertRaises(FileExistsError):self.intake()
        self.assertEqual((self.output/'observation.json').read_bytes(),raw)

if __name__=='__main__':unittest.main()
