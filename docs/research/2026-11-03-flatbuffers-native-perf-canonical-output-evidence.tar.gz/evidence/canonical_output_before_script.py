import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-canonical-output')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads(C.read_text())['native_perf_only_diagnostic_design']['current_source_sha256']
 assert len(expected)==20
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert subprocess.check_output(['git','-C',str(R),'branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 assert not subprocess.check_output(['git','-C',str(R),'diff','HEAD','--','packages','native'])
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assert free>=1024**3,free
 P.mkdir()
 writej(P/'declaration.json',dict(scope='Canonical output path source integration only',free_before=free,
  build_floor=12*1024**3,scoped_floor=1024**3,no_actual_build=True,source_commit='601108ea6216464bd00ae29c16cfaf0a59c71db6',
  before_source_sha256=expected,model_request_already_completed=True))
 snapshot('original')
 addition="\n\nclass CanonicalOutputPathTests(unittest.TestCase):\n    \"\"\"Synthetic platform/path guards; never execute a build or emit a receipt.\"\"\"\n\n    def setUp(self):\n        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')\n        if evidence:Path(evidence).mkdir(exist_ok=True)\n        self.base=Path(tempfile.mkdtemp(prefix='canonical-path-',dir=evidence)).resolve()\n        self.repo=self.base/'repo';self.repo.mkdir()\n        self.kwargs=dict(repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,\n            run_dir=self.base/'run',expected_archive_sha256='b'*64,\n            inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock',\n                'native/bench/Cargo.lock','.dart_tool/package_config.json')},\n            tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,\n            expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json',\n                'client':'.dart_tool/package_config.json'},lease_check=lambda:None)\n\n    def factory(self,platform='darwin',environment=None):\n        with mock.patch.dict(os.environ,environment or {},clear=True),\\\n                mock.patch.object(producer.sys,'platform',platform),\\\n                mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:\n            result=producer.start_canonical(**self.kwargs)\n        self.assertEqual('fixture-placeholder',result)\n        self.assertFalse((self.base/'run').exists())\n        return cls.call_args.kwargs\n\n    def shell_path(self,platform):\n        import re\n        root=Path(__file__).resolve().parents[1]\n        common=(root/'bin/common.sh').read_bytes()\n        names=('native_lib_file_name','native_ffi_test_lib_path')\n        functions=[]\n        for name in names:\n            matches=re.findall(rb'(?ms)^'+name.encode()+rb'\\(\\) \\{\\n.*?^\\}',common)\n            self.assertEqual(1,len(matches));functions.append(matches[0])\n        script=(b'set -euo pipefail\\nROOT_DIR=\"$1\"\\nfixture_platform=\"$2\"\\n'\n            b'uname() { printf \"%s\\\\n\" \"$fixture_platform\"; }\\n'+b'\\n'.join(functions)+\n            b'\\nnative_ffi_test_lib_path\\n')\n        path=self.base/'selected-functions.sh';path.write_bytes(script)\n        argv=['/bin/bash',str(path),str(self.repo),platform]\n        result=subprocess.run(argv,capture_output=True,check=False)\n        (self.base/'bash.stdout').write_bytes(result.stdout)\n        (self.base/'bash.stderr').write_bytes(result.stderr)\n        (self.base/'bash-result.json').write_text(json.dumps(dict(\n            scope='OWN extracted path functions with SYNTHETIC uname; no build',\n            argv=argv,returncode=result.returncode,both_output_eof=True,\n            common_sha256=digest(common),script_sha256=digest(script))))\n        self.assertEqual(0,result.returncode);self.assertEqual(b'',result.stderr)\n        return Path(result.stdout.decode().strip())\n\n    def test_darwin_factory_matches_exact_selected_shell_functions(self):\n        self.assertEqual(self.shell_path('Darwin'),self.factory()['outputs']['canonical_native'])\n\n    def test_linux_factory_matches_exact_selected_shell_functions(self):\n        self.assertEqual(self.shell_path('Linux'),self.factory('linux')['outputs']['canonical_native'])\n\n    def test_configured_own_ffi_test_path_is_accepted(self):\n        expected=self.repo/'native/transport/target/ffi-test/release/libct_ffi.dylib'\n        actual=self.factory(environment={'CONNECTANUM_NATIVE_LIB':str(expected)})\n        self.assertEqual(expected,actual['outputs']['canonical_native'])\n\n    def test_configured_standard_release_path_refused_before_constructor(self):\n        standard=self.repo/'native/transport/target/release/libct_ffi.dylib'\n        with mock.patch.dict(os.environ,{'CONNECTANUM_NATIVE_LIB':str(standard)},clear=True),\\\n                mock.patch.object(producer.sys,'platform','darwin'),\\\n                mock.patch.object(producer,'CommandProducer') as cls:\n            with self.assertRaises(producer.ProducerError):\n                producer.start_canonical(**self.kwargs)\n        cls.assert_not_called();self.assertFalse((self.base/'run').exists())\n\n    def test_ci_artifact_override_refused_before_constructor(self):\n        with mock.patch.dict(os.environ,{'CONNECTANUM_CI_NATIVE_DIR':'retained-artifacts'},clear=True),\\\n                mock.patch.object(producer,'CommandProducer') as cls:\n            with self.assertRaises(producer.ProducerError):\n                producer.start_canonical(**self.kwargs)\n        cls.assert_not_called();self.assertFalse((self.base/'run').exists())\n\n    def test_empty_ci_override_preserves_fixed_recipe(self):\n        for environment in ({},{'CONNECTANUM_CI_NATIVE_DIR':''}):\n            with self.subTest(environment=environment):\n                actual=self.factory(environment=environment)\n                self.assertEqual([['bin/verify']],actual['commands'])\n                self.assertEqual('canonical_recipe',actual['provenance'])\n"
 testpath=R/'tool/test_native_perf_build_producer.py'
 source=testpath.read_text()
 node=[x for x in ast.parse(source).body if isinstance(x,ast.If) and "__name__" in ast.unparse(x.test)]
 assert len(node)==1
 lines=source.splitlines(keepends=True);at=sum(len(x) for x in lines[:node[0].lineno-1])
 updated=source[:at]+addition+'\n'+source[at:];ast.parse(updated)
 testpath.write_text(updated)
 summary=runtests('before',['CanonicalOutputPathTests'])
 writej(P/'tests-advice-root-assessment.json',dict(
  complete_answer_retained=True,terminal_reports_complete=True,exec_session1895_no_longer_available=True,
  status_limit='Natural terminal success supported by saved helper stdout+stderr completion; no retained outer exec signed status',
  accepted=['synthetic Darwin/Linux exact extracted functions','nonempty CI override refusal','empty CI override allowance','path factory/validator agreement'],
  rejected=['No new canonical reservation helper API is required','Mocking factory alone cannot cover _emit validation','Production recipe is Linux-only and uses run/target, not repository target or Darwin dylib','Advice verification shell test path was hypothetical, not an actual executed command'],
  no_repeat_request=True))
 lease.verify_identity()
 print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
