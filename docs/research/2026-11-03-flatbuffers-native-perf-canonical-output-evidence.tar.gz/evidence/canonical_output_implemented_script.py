import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-canonical-output')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads(P.joinpath('before-hashes.json').read_text())
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/native_perf_build_producer.py';source=path.read_text()
 source=source.replace('def start_canonical(**kwargs):',"def _canonical_native_path(repo):\n    return Path(repo)/'native/transport/target/ffi-test/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')\n\n\ndef _validate_owned_output_path(run,phase,role,path):\n    \"\"\"Location predicate only; this does not validate bytes or admit a capture.\"\"\"\n    if phase=='canonical' and role=='canonical_native':\n        if path!=_canonical_native_path(run.repo):raise ProducerError('canonical native outside own ffi-test output')\n    elif phase=='execution' and role=='static_rlib':\n        if path.parent!=run.directory/'target/release/deps' or not re.fullmatch(r'libct_core-[A-Za-z0-9_]+\\\\.rlib',path.name):raise ProducerError('RLIB outside own production target')\n    elif phase=='execution' and role in ('native_elf','driver_elf'):\n        if path!=run.directory/'target/release'/('libct_ffi.so' if role=='native_elf' else 'http_stream'):\n            raise ProducerError('production artifact outside own target')\n    else:raise ProducerError('own output phase/role differs')\n\n\n"+'def start_canonical(**kwargs):',1)
 old="    repo=Path(kwargs['repo']);native=repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')"
 assert source.count(old)==1
 source=source.replace(old,"    if os.environ.get('CONNECTANUM_CI_NATIVE_DIR'):raise ProducerError('undeclared canonical CI artifact reuse')\n    native=_canonical_native_path(kwargs['repo'])",1)
 source=source.replace("canonical native path is outside own declared release output","canonical native path is outside own declared ffi-test output",1)
 start=source.index("            if not fixture:\n                if phase=='canonical':")
 end=source.index("            if _regular_hash(path)",start)
 source=source[:start]+"            if not fixture:_validate_owned_output_path(run,phase,role,path)\n"+source[end:]
 ast.parse(source)
 # Preserve the complete production factory body byte-for-byte.
 original=(P/'original-source/tool/native_perf_build_producer.py').read_text()
 find=lambda text,name:ast.get_source_segment(text,next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name))
 assert find(source,'start_production')==find(original,'start_production')
 path.write_text(source)
 testpath=R/'tool/test_native_perf_build_producer.py';source=testpath.read_text()
 node=next(x for x in ast.parse(source).body if isinstance(x,ast.If) and "__name__" in ast.unparse(x.test))
 at=sum(len(x) for x in source.splitlines(keepends=True)[:node.lineno-1])
 source=source[:at]+"\n\nclass OwnedOutputLocationTests(unittest.TestCase):\n    \"\"\"Pure location predicates only; do not produce/adopt live evidence.\"\"\"\n\n    def setUp(self):\n        from types import SimpleNamespace\n        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')\n        if evidence:Path(evidence).mkdir(exist_ok=True)\n        self.base=Path(tempfile.mkdtemp(prefix='output-location-',dir=evidence)).resolve()\n        self.run=SimpleNamespace(repo=self.base/'repo',directory=self.base/'run')\n\n    def test_canonical_ffi_test_locations_for_two_synthetic_platforms(self):\n        for platform,filename in (('darwin','libct_ffi.dylib'),('linux','libct_ffi.so')):\n            with self.subTest(platform=platform),mock.patch.object(producer.sys,'platform',platform):\n                path=self.run.repo/'native/transport/target/ffi-test/release'/filename\n                producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)\n        self.assertFalse(self.run.directory.exists())\n\n    def test_canonical_rejects_standard_release_and_foreign_output(self):\n        with mock.patch.object(producer.sys,'platform','darwin'):\n            for path in (self.run.repo/'native/transport/target/release/libct_ffi.dylib',\n                    self.base/'foreign/native/transport/target/ffi-test/release/libct_ffi.dylib'):\n                with self.subTest(path=str(path)),self.assertRaises(producer.ProducerError):\n                    producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)\n\n    def test_three_production_locations_preserved(self):\n        for role,suffix in (('native_elf','libct_ffi.so'),('driver_elf','http_stream'),\n                ('static_rlib','deps/libct_core-Ab09_.rlib')):\n            with self.subTest(role=role):\n                producer._validate_owned_output_path(self.run,'execution',role,\n                    self.run.directory/'target/release'/suffix)\n\n    def test_production_rejects_wrong_targets_and_rlib_names(self):\n        cases=(('native_elf',self.run.repo/'native/transport/target/release/libct_ffi.so'),\n            ('driver_elf',self.base/'foreign/target/release/http_stream'),\n            ('static_rlib',self.run.directory/'target/release/deps/libct_core-.rlib'),\n            ('static_rlib',self.run.directory/'target/release/deps/libct_core-x.y.rlib'),\n            ('static_rlib',self.run.directory/'target/release/libct_core-Ab09.rlib'))\n        for role,path in cases:\n            with self.subTest(role=role,path=str(path)),self.assertRaises(producer.ProducerError):\n                producer._validate_owned_output_path(self.run,'execution',role,path)\n\n    def test_phase_and_role_mismatches_refused(self):\n        for phase,role in (('canonical','native_elf'),('execution','canonical_native'),\n                ('unknown','driver_elf'),('execution','unknown')):\n            with self.subTest(phase=phase,role=role),self.assertRaises(producer.ProducerError):\n                producer._validate_owned_output_path(self.run,phase,role,\n                    self.run.directory/'target/release/http_stream')\n"+'\n'+source[at:];ast.parse(source);testpath.write_text(source)
 names=['CanonicalOutputPathTests','OwnedOutputLocationTests',
  'ProducerTests.test_production_factory_refuses_nonlinux_before_reservation',
  'ProducerTests.test_production_recipe_factory_only_synthetic_argv_observation',
  'ProducerTests.test_canonical_recipe_factory_only_synthetic_argv_observation']
 summary=runtests('implemented',names)
 assert not subprocess.check_output(['git','-C',str(R),'diff','HEAD','--','packages','native'])
 lease.verify_identity()
 print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
