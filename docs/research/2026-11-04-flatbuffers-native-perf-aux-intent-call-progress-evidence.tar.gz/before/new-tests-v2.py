class AuxiliaryIntentCallProgressTests(unittest.TestCase):
    """NEW outer original writer/hash progress; generic internal close semantics unchanged."""
    def _intent_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-intent-call-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        a=object.__new__(producer.AuxiliaryCommand);initialize=producer.AuxiliaryCommand.__init__;verify=official_ex_verify
        path=base/'intent-source-intent.json';payload=b'OWN-intent-call-output';fault=False;raised=None;guard_error=None;returned=False;initializing=True
        api=[];verify_rows=[];actors=[];cleanup=[];file_rows=[];managers=[];repr_rows=[]
        native_write=producer._write_json;native_hash=producer._regular_hash;native_open=Path.open;real_allocate=producer.AuxiliaryCommand._allocate_process
        class Fault(OSError):
            def __repr__(self):repr_rows.append(True);raise AssertionError('first must never be rendered by source')
        first=Fault(5,'ROOT hides actual intent API return')
        def rows():
            value=getattr(a,'_intent_call_journal',None)
            return value if type(value) is list else []
        def callback():
            value=verify();verify_rows.append(dict(returned=True,raw_is_None=value is None));return value
        class Prefix:
            def __init__(self,raw):self.raw=raw
            def __enter__(self):
                value=self.raw.__enter__();file_rows.append(dict(kind='enter',returned=True,same_native=value is self.raw));return self
            def __exit__(self,*args):
                value=self.raw.__exit__(*args);file_rows.append(dict(kind='exit',returned=True,raw_None=value is None));return value
            def write(self,data):
                nonlocal fault
                value=self.raw.write(data[:3]);file_rows.append(dict(kind='prefix_write',requested=len(data),sent=3,raw_count=value));fault=True;return value
            def flush(self):
                value=self.raw.flush();file_rows.append(dict(kind='flush',returned=True,raw_None=value is None));return value
            def fileno(self):
                value=self.raw.fileno();file_rows.append(dict(kind='fileno',returned=True,fd=value));return value
        def opening(current,*args,**kwargs):
            value=native_open(current,*args,**kwargs)
            if current==path and args and args[0]=='xb':
                managers.append(value)
                if mode=='prefix':return Prefix(value)
            return value
        def writing(current,value):
            nonlocal fault
            if Path(current)!=path or not initializing:return native_write(current,value)
            row=rows()[-1] if rows() else {}
            intent=(row.get('object') is a and row.get('stage')=='write' and row.get('function') is writing and row.get('attempted') is True and row.get('returned') is None)
            entry=dict(kind='write',attempted=True,source_intent_BEFOREcall=intent,returned=None);api.append(entry)
            raw=native_write(current,value);entry.update(returned=True,raw_None=raw is None)
            if mode in ('write-drift','write-error'):
                fault=True
                if mode=='write-drift':a.streams['stdout']['buffer']=b'ROOT-after-write'
                else:raise first
            return raw
        def hashing(current,*args,**kwargs):
            nonlocal fault
            if Path(current)!=path or not initializing:return native_hash(current,*args,**kwargs)
            row=rows()[-1] if rows() else {}
            intent=(row.get('object') is a and row.get('stage')=='hash' and row.get('function') is hashing and row.get('attempted') is True and row.get('returned') is None)
            entry=dict(kind='hash',attempted=True,source_intent_BEFOREcall=intent,returned=None,after_fault=fault);api.append(entry)
            raw=native_hash(current,*args,**kwargs);entry.update(returned=True,raw_string=type(raw) is str,raw_digest=raw)
            if mode in ('hash-drift','hash-error','false'):
                fault=True
                if mode=='hash-drift':a.streams['stdout']['buffer']=b'ROOT-after-hash'
                elif mode=='hash-error':raise first
                else:entry['facade_returns_False']=True;return False
            return raw
        def allocate(current,record):
            value=real_allocate(current,record);actors.append(dict(process=value,bound_wait=value.wait));return value
        try:
            with mock.patch.object(Path,'open',opening),mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate):
                try:
                    raw_init=initialize(a,directory=base,name='intent-source',argv=[sys.executable,'-c',"import os;os.write(1,"+repr(payload)+")"],
                        cwd=base,environment=dict(os.environ),lease_check=callback);returned=True;initializing=False
                    init_api_names=[x['kind'] for x in api]
                    if mode=='normal':self.assertIsNone(raw_init);a.start();a.wait(timeout=10)
                except BaseException as error:raised=error;init_api_names=[x['kind'] for x in api]
                if mode!='normal':
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
            data=path.read_bytes() if path.exists() else None;rs=rows();row=rs[-1] if rs else {}
            report=dict(mode=mode,api=api,init_api_names=init_api_names,verifier_rows=verify_rows,original_initializer_returned=returned,
                controlled_raw_object_original_initializer_NOTenclosing_factory_retention_or_admission=True,
                error_is_original=raised is first,error_is_ProducerError=type(raised) is producer.ProducerError,
                pureguard_received_first=raised is not None and guard_error is raised,private_first_received=raised is not None and getattr(a,'_intent_call_primary_error',None) is raised,
                digest_exists='intent_sha256' in a.__dict__,digest_is_False=a.__dict__.get('intent_sha256') is False,
                digest=a.__dict__.get('intent_sha256') if type(a.__dict__.get('intent_sha256')) is str else None,
                bytes_hex=None if data is None else data.hex(),bytes_size=None if data is None else len(data),
                actual_file_sha256=None if data is None else hashlib.sha256(data).hexdigest(),
                original_expected_bytes=(json.dumps(a.intent,sort_keys=True,ensure_ascii=True)+'\n').encode().hex(),
                row_original_object=row.get('object') is a,row_stage=row.get('stage'),row_returned=row.get('returned'),
                row_raw_None=row.get('raw_return') is None,row_raw_False=row.get('raw_return') is False,
                row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                source_repr_before_unitasserts=len(repr_rows),source_process_returns=len(actors),
                started=a.started,pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                ROOT_prefix_actual_native_APIrows=file_rows,ROOT_native_manager_closed_DATAonly=[x.closed for x in managers])
            with (base/'intent-call-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(all(x['returned'] and x['raw_is_None'] for x in verify_rows));self.assertEqual(0,report['source_repr_before_unitasserts'])
            if mode=='normal':
                self.assertIsNone(raised);self.assertTrue(returned);self.assertEqual(['write','hash'],init_api_names)
                self.assertEqual(bytes.fromhex(report['original_expected_bytes']),data);self.assertEqual(hashlib.sha256(data).hexdigest(),a.intent_sha256)
                self.assertEqual(payload,(base/'intent-source.stdout').read_bytes());self.assertTrue(a.finished);self.assertFalse(a.pending)
            else:
                self.assertFalse(returned);self.assertFalse(report['digest_exists']);self.assertEqual([],actors)
                if mode in ('write-error','hash-error'):self.assertIs(first,raised)
                else:self.assertIs(type(raised),producer.ProducerError)
                self.assertIs(raised,guard_error);self.assertTrue(report['private_first_received']);self.assertTrue(report['row_error_is_received'])
                self.assertTrue(report['row_original_object']);self.assertTrue(all(x['source_intent_BEFOREcall'] for x in api))
                self.assertEqual(['write'] if mode in ('write-drift','write-error') else ['write','hash'],init_api_names)
                self.assertFalse(a.started);self.assertFalse(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
                if mode in ('write-error','hash-error'):self.assertIsNone(report['row_returned'])
                else:self.assertIs(report['row_returned'],True)
                if mode=='prefix':
                    self.assertEqual(3,len(data));self.assertEqual(3,next(x['raw_count'] for x in file_rows if x['kind']=='prefix_write'))
                if mode=='false':self.assertTrue(report['row_raw_False'])
        finally:
            for actor in actors:
                value=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_bound_same_finite_wait',pid=actor['process'].pid,status=value,expected=0,cached_possible=True))
                self.assertIs(type(value),int);self.assertEqual(0,value)
            with (base/'intent-call-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_actual_intent_writer_return_then_drift_stops_before_hash(self):self._intent_case('write-drift')
    def test_actual_intent_hash_return_then_drift_refuses_public_digest(self):self._intent_case('hash-drift')
    def test_actual_intent_writer_then_fault_retains_unknown_call_first(self):self._intent_case('write-error')
    def test_actual_intent_hash_then_fault_retains_unknown_call_first(self):self._intent_case('hash-error')
    def test_actual_prefix_write_then_hash_cannot_admit_truncated_intent(self):self._intent_case('prefix')
    def test_actual_hash_then_False_is_not_published_as_digest(self):self._intent_case('false')
    def test_normal_original_intent_pair_preserves_bytes_order_and_output(self):self._intent_case('normal')
