import sys,pathlib,json,hashlib,ast,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-intent-call-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();h=json.loads((P/'after-edit-hashes.json').read_text());actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert actual==h
 s=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();ast.parse(s);ast.parse(tests)
 assert s==(P/'candidate-producer-v4.py').read_text()
 oldtests=(P/'before-existing-tests.py').read_bytes();assert tests==oldtests+b'\n'+(P/'new-tests-v2.py').read_bytes()
 assert json.loads((P/'ROOT-candidate-invariants-v4.json').read_text())['candidate_BYTEprojectsback'] is True
 before=json.loads((P/'before/result.json').read_text());after=json.loads((P/'after-selected/result.json').read_text());assert (before['tests'],before['failures'],before['errors'])==(7,6,0);assert (after['tests'],after['failures'],after['errors'])==(28,0,0)
 commands=[['git','rev-parse','HEAD'],['git','branch','--show-current'],['git','status','--short','--untracked-files=all'],['git','diff','--name-only','HEAD','--','packages','native']]
 git=[]
 for index,argv in enumerate(commands):
  prefix=q/('git-'+str(index))
  with prefix.with_suffix('.before.json').open('x') as f:json.dump(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None),f)
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  with prefix.with_suffix('.start.json').open('x') as f:json.dump(dict(pid=child.pid),f)
  out,err=child.communicate();status=child.wait()
  for name,raw in [('stdout.bin',out),('stderr.bin',err)]:
   with pathlib.Path(str(prefix)+'.'+name).open('xb') as f:f.write(raw)
  result=dict(argv=argv,pid=child.pid,status=status,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),stdout_size=len(out),stderr_size=len(err),both_EOF=True)
  with prefix.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
  assert status==0 and err==b'';git.append((out,result))
 assert git[0][0].decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6';assert git[1][0].decode().strip()=='codex/flatbuffers-native-perf-guard'
 statuslines=git[2][0].decode().splitlines();assert len(statuslines)==20 and all(x.startswith('?? tool/') for x in statuslines);assert git[3][0]==b''
 reports=[];waitrows=[];verifyrows=[];prefix_rows=[];expected_sizes={}
 for phase in ['before','after-selected']:
  for path in sorted((P/phase/'fixtures').glob('*/intent-call-before-cleanup.json')):
   r=json.loads(path.read_text());cleanup=json.loads(path.with_name('intent-call-unit-cleanup.json').read_text());reports.append(dict(phase=phase,path=str(path),mode=r['mode']))
   expected_sizes.setdefault(phase,[]).append(len(bytes.fromhex(r['original_expected_bytes'])))
   verifyrows+=r['verifier_rows'];waitrows+=[x for x in cleanup if x['kind']=='ROOT_bound_same_finite_wait']
   if r['mode']=='prefix':
    assert r['bytes_size']==3;prefix_rows+=[x for x in r['ROOT_prefix_actual_native_APIrows'] if x['kind']=='prefix_write']
   if phase=='after-selected':
    assert r['source_repr_before_unitasserts']==0
    if r['mode']!='normal':
     assert r['digest_exists'] is False and r['original_initializer_returned'] is False and r['source_process_returns']==0
     assert r['pureguard_received_first'] and r['private_first_received'] and r['row_error_is_received'] and r['row_original_object']
     assert r['started'] is False and r['pending'] is False and r['finished'] is False and r['result_is_None'] is True
     assert all(x['source_intent_BEFOREcall'] for x in r['api'])
     assert r['init_api_names']==(['write'] if r['mode'] in ['write-drift','write-error'] else ['write','hash'])
     assert r['row_returned'] is (None if r['mode'] in ['write-error','hash-error'] else True)
     if r['mode']=='false':assert r['row_raw_False'] is True
 assert len(reports)==14 and len(waitrows)==2 and all(type(x['status']) is int and x['status']==0 for x in waitrows)
 assert len(verifyrows)==18 and all(x['returned'] and x['raw_is_None'] for x in verifyrows)
 assert len(prefix_rows)==2 and all(x['sent']==3 and x['raw_count']==3 for x in prefix_rows)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Auxiliary OUTER intent writer/hash calls only; original generic internal with/finally-close/addnote and earlier init/enclosing factory/fullphysicalEX/runtimeadmission/RAMrepair/acceptance incomplete',
 source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],NEWbefore7='6FAIL1PASS0APIerrors at1b3e08/21b6fd; controlled3B/False/context publication; twoerrorcases originalcallerfirst alreadyworks NOTsix nativebugs',
 AFTERselected28='7matchingNEW+21affected PASS/newepochONLY/notaggregate/fullcurrent20canonical/admission',
 whole_final_source_tests_AST_schema_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_unchanged=True,
 original_generic_writer_hash_including_internal_close_addnote_othermethods_factories_gates_resultliteral_Popenfacts_exact=True,
 source_git_new4_actual0_BOTHstreams=True,branch='codex/flatbuffers-native-perf-guard',HEAD='601108ea6216464bd00ae29c16cfaf0a59c71db6',exact20_untracked_uncommitted_uncanonical_unadmitted=True,tracked_packages_native_diffempty_DATA_only=True,
 new_unit_journals=14,new_ROOT_boundwait_rows=2,all_signed0_cached_possible=True,actual_A_callback_CURRENT_official_EX_verify_None_rows=18,not_all_setup_controller_FD_API_calls=True,
 two_ROOTprefix_native_writes_exact3B_NOTspontaneouskernelshortwrite=True,actual_regular_hash_stable3Bfile_digest_rejected=True,observed_expected_declaration_sizes={key:sorted(set(values)) for key,values in expected_sizes.items()},
 integrity_only_callee_contract_match_NOTindependent_byte_durability_auth_atomicABA_physicalEX_admission=True,
 paircompleted_notpublicdigestpublication=True,normal_initializer_None_distinct_writer_None_callback_None_hash_string=True,
 no_negative_SourceSTART_wait_or_repeatedINIT_no_terminalnamespace_recovery=True,
 controlled_preallocated_originalinitializer_seam_NOToriginal_enclosing_factory_retention_publicconstructor_Popen_admission=True,
 GLM84020='review0/reaped/stdout6464stderr1286/input38603/fullanswer/selectedv2notv3v4/ROOTqualified NOTwholecurrentapproval',Qwen82805='planning0/reaped/stdout1480stderr395/fullanswer/ROOTqualified',
 ROOT_v3_v4_AFTERreview='savedcontext shapes + passive icstage avoids oldstage3refs; allcandidatesUNEXECUTED beforeedit; unsupported malformed shapes SOURCEqualified notglobalruntimeclosure',
 helper_v1_UNEXECUTED='Root nonlocal/INITonly observation v2 fixes BEFOREtests/no failurecounts',
 rawlimits='Only normal finitePythonactors perphase/RootSAMEwait afterreports/cachedpossible. Root originalcallee/prefixBufferedWriter returns observed, notall generic internalFD/syscall returns/no allchildFD-interpreter-delegate-descendant instructionclosure. Legacysetup/actorFD/tool/inlineartifact API notallfiles/no reconstruction.',
 free_bytes=free,storage_floor='OPEN' if free>=12884901888 else 'CLOSED',storage_cause_outside_old_lossless_cleanup_UNMEASURED_no_deletion_authority=True,
 provider_ABSENT=True,gate_alwaysraises=True,controller_CLOSED=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_adoption_cleanup_RAMrepair_strictacceptance=True,reports=reports,git=[x[1] for x in git])
 for path in [q/'assessment.json',P/'ROOT-final-invariants.json']:
  with path.open('x') as f:json.dump(result,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_intent_call_progress'];v.update(ROOT_pending=False,ROOT_assessment=str(q/'assessment.json'),ROOT_qualified=True,source_component_only_COMPLETE=True,publication_pending=True,source_new_epoch_UNTESTED=False,never_repeat_unchanged=True)
 n['current_helper_source_epoch'].update(producer_sha256=result['source_sha256'],test_sha256=result['test_sha256'],hashes_file=str(P/'after-edit-hashes.json'),final_epoch_UNTESTED=False,verification_scope='4bac3d/4b55a5 selected28PASS=7new21affected ROOTqualified NOTmodelwholecurrentapproval/current20canonical/admission',latest_postflight=str(q/'assessment.json'))
 c['active_turn_status']='Aux_intent_calls4bac3d_4b55a5_selected28PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity()
 print(json.dumps({k:result[k] for k in ['source_sha256','test_sha256','NEWbefore7','AFTERselected28','new_unit_journals','new_ROOT_boundwait_rows','actual_A_callback_CURRENT_official_EX_verify_None_rows','free_bytes']}))
