import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-snapshot-factory-returns-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-snapshot-factory-returns-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='e2e7e641a00b2edd20528818041fabe2c91255f2'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Refuse None and bool hash factories before the first read\n\nA controlled SHA factory constructed a native hasher and then returned None, False or True. The snapshot helper read23bytes before failing an update-method lookup. It now rejects those explicit return kinds before the first read. Known invalid values stay recorded as returned; an unknown completion keeps its original error and stays unknown. A known returned proxy still delegates normal native hashing and returns the full size and SHA.\n\nFive new controls before3a007f/286a72 produced3FAIL/2PASS/0ERROR: three controlled continuation/refusal policies, not spontaneous kernel bugs or a RAM cause. The unknown-completion and distinct normal23-byte proxy controls already passed. Finalc4199a/0e4e94 passes49selected=5matchingNEW+44affected(26previoussnapshot8end10actualwaitcallers). Whole Source projection and the existing test prefix are exact. Both advisory models completed; ROOT independently qualifies their claims, the patch and the results. This guard does not validate every possible factory return or establish native identity.\n\nTen new direct views create no child actors. Current Darwin lease observations, known FD cleanup and affected finite waits remain unit evidence; full independent EX and original Linux actor closure remain unproved. Chunk-retention machinery is unchanged. Avoiding a read in these controlled refusals establishes no heap/RSS bound or RAM repair. Source remains uncommitted, uncanonical and unadmitted; runtime admission and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-snapshot-factory-returns-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: refuse invalid snapshot factory returns'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_factory_returns_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Snapshot earlierconstructor-registration/metadata-globalbindings/otherfactoryshapes-getterinternals-calleeinterior-statcontents-concurrentABA; otherAPIs/enclosing-publicunknownCtor; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Currentc4199a/0e4e94 ONLYhash_ctor hNone/exactbool refusal BEFOREcount-firstread, knownNone-False-True rowTRUE/rawinvalid retained vsunknownNoneFalse/originalFirst/pureguard; ROOTnativehasher neverSourcefilled. Otherobjects/knownROOTproxy contract preserved; SourceKNOWNproxy!=nativeunderlying notnativeidentity-auth-completefactoryshape-ownership-admission. NEW5before3a007f/286a72=3FAIL2PASS0ERROR: actualnativeSHAfactory thenNone/False/True eachallowedone23Bread beforeh.update lookupAttributeError, 3controlledcontinuation/refusalpolicies NOT3nativekernelbugs-RAMcause; unknownfactoryFirst/normal23Bproxy alreadyPASS; final49PASS=5NEW44affected(26snapshot8end10actualwaitcallers)/no old26BEFORE-model-numericalreplay-aggregate-current20canonical-admission.10newdirectviews+26prior8end/EX10before98after/ZEROnewchild/Root4before4afterFDcloses AFTERevidence/devino-only/normalSourceclosed-no borrowedreclose;26priorRootclose20separate/8endRootsameboundwait10 signed7zero1threeCached UNITnotSourcecleanup-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. Qwen82335=0/1718out404err;GLM82664=0/1660out603err/fullanswers-BOTH EOF-reaped-ROOTqualified NOTwholecurrentapproval. RejectSourcefailclose-completedcleanup/globalhashlibpatch/oldempty-maxcontrols/swallowedfactory/guardmutation/hypotheticalimportbinding-__getattr__proxytheories: actualnativefactory inside_step/unknownalreadyPASS, privatefirstpureguard, explicitfacadeconstructor-Proxydelegates. Otherfactoryshapes/metadata/calleeinterior/stdlibtransitiveactors/ABA unproved. Candidatev1firstexecutedAFTERSourceedit/privateharnessv1firstBEFORE/controllersBEFOREcalls/wholeSourceBYTEprojectback-oldtestPREFIXexact-othermethodshelpersfactoriesfrozenpredicates exact/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. RetentionmachineryUNCHANGED/processlife chunks NOTfixedmemory; beforeknowninvalid1x23Bread after0 logicalcountsNOTheapRSS-allocvolume-timing-leakcause-RAMrepairproof/default16GiBlogicalfilelimitNOTheapRSSbound/no memorybound-RAMrepair-trim-reset-evict-deleteauthority. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_snapshot_factory_selected49PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
