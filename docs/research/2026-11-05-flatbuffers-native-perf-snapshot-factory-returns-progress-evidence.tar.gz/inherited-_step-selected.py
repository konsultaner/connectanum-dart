def _step(self,stage,lookup,args=(),kwargs=None):
        self.guard()
        fail=self._fail # Retain original failure binding BEFORE lookup/callee.
        row=dict(stage=stage,attempted=True,lookup=lookup,args=args,kwargs=kwargs,
            method=None,returned=False,raw=None,error=None)
        self.steps.append(row) # Intent precedes lookup, not just the call.
        try:
            method=lookup()
            row['method']=method
            returned=method(*args,**({} if kwargs is None else kwargs))
            row['raw']=returned # Raw return precedes checks and the next operation.
            row['returned']=True
            return returned
        except BaseException as error:
            fail(error,row)
