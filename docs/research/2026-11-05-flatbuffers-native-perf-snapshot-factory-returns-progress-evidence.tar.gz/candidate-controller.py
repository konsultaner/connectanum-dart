import sys,pathlib,json,hashlib,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-factory-returns-progress-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();before=(P/'before-producer.py').read_text()
 old="            h=call('hash_ctor',lambda:hashlib.sha256);count=0\n"
 new="            h=call('hash_ctor',lambda:hashlib.sha256)\n            if h is None or type(h) is bool:\n                raise ProducerError('unknown log snapshot hash factory return')\n            count=0\n"
 assert before.count(old)==1
 after=before.replace(old,new,1);ast.parse(after);assert after.replace(new,old,1)==before
 (P/'candidate-producer-v1.py').open('x').write(after)
 node=next(x for x in ast.parse(after).body if isinstance(x,ast.ClassDef) and x.name=='_FileSnapshotAttempt')
 (P/'candidate-snapshot-v1.py').open('x').write(ast.get_source_segment(after,node)+'\n');(P/'projection-parts-v1.json').open('x').write(json.dumps(dict(old=old,new=new),indent=2))
 receipt=dict(wholeSource_BYTE_projectsback=True,all_other_existing_methods_helpers_classes_factories_frozenpredicates_exact=True,oldtests_PREFIX_exact=True,only_explicit_factory_None_bool_refusal=True,original_healthy_nativeIO_order_preserved=True,complete_factory_returnshape_admission=False,privatev1_BEFORE5_frozen=True,no_before_replay=True,Qwen_planning_ROOT_qualified='82335status0/full1718stdout404stderr. Reject globalhashlibpatch/Sourcefailclose orcompletedbasedcleanup/extraoldempty-sizecontrols; explicitmodulelocalnativeconstructor-thenNone-bool-First/proxycontract kept; actualfirstreadoccursbeforemethodlookup onknowninvalidfactory.')
 (P/'candidate-ROOT-projection.json').open('x').write(json.dumps(receipt,indent=2));(P/'candidate.diff').open('x').write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before',tofile='candidate')))
 views=[json.loads(f.read_text()) for f in (P/'before-units/fixtures').glob('*/view-before-ROOT-cleanup.json')]
 print(json.dumps([dict(mode=v['mode'],Source_returned=v['Source_returned'],received=v['received_type'],last=v['Source_steps'][-1],calls=v['calls'],nativeknown=v['ROOT_native_hasher_known'],proxyknown=v['ROOT_proxy_known']) for v in views],indent=2))
 l.verify_identity();print((P/'candidate.diff').read_text())
