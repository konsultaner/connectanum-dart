"""NEW snapshot SHA factory None/bool return controls."""
import os
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class SnapshotFactoryReturnTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_FACTORY_FIXTURES']);self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root));self.path=self.base/'factory-input.bin';self.body=b'FACTORY-control-content'
        with self.path.open('xb') as output:output.write(self.body)

    def _case(self,mode):
        native_os=producer.os;native_hashlib=producer.hashlib;calls=[];fds=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT factory first')
        class Proxy:
            def __init__(self,h):self.h=h
            def update(self,part):
                raw=self.h.update(part);calls.append(dict(kind='native_proxy_update_return',size=len(part),raw_None=raw is None));return raw
            def hexdigest(self):
                raw=self.h.hexdigest();calls.append(dict(kind='native_proxy_digest_return',raw=raw));return raw
        class HashlibFacade:
            def __getattr__(self,name):return getattr(native_hashlib,name)
            def sha256(self,*args,**kwargs):
                raw=native_hashlib.sha256(*args,**kwargs);seen['native']=raw;calls.append(dict(kind='native_factory_return',arg_count=len(args),kwargs_keys=sorted(kwargs)))
                if mode=='None':return None
                if mode=='False':return False
                if mode=='True':return True
                if mode=='unknown':raise first
                proxy=Proxy(raw);seen['proxy']=proxy;return proxy
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs);info=native_os.fstat(raw);fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)));calls.append(dict(kind='native_open_return',fd=raw,flags=flags));return raw
            def read(self,fd,size):
                raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw)));return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt'));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None));return raw
        returned=False;result=None;received=None;guard_error=None;attempt=None
        try:
            before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(producer,'hashlib',HashlibFacade()):
                try:result=producer._file_snapshot(self.path);returned=True
                except BaseException as error:received=error
            attempt=producer._FILE_SNAPSHOT_ATTEMPTS[before:][-1]
            if mode!='normal':
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=attempt.steps
            view=dict(mode=mode,snapshot_factory_control=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,pure_guard_same_received=received is not None and guard_error is received,Source_first_received=attempt.first_error is received,
                Source_completed=attempt.completed,Source_close_returned=attempt.close_returned,ROOT_native_hasher_known='native' in seen,ROOT_proxy_known='proxy' in seen,ROOT_proxy_distinct_native='proxy' in seen and seen['proxy'] is not seen['native'],
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,raw_True=r['raw'] is True,raw_native='native' in seen and r['raw'] is seen['native'],raw_proxy='proxy' in seen and r['raw'] is seen['proxy'],error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='DirectOWNfile/MODULELOCALhashlib-os/nativeconstructor thenNone-bool-First-orKNOWNROOTproxy !=nativeunderlying. KnownNone/boolTRUE vsunknownNoneFalse neverROOTnativehasherfilled. ExplicitNone-boolrefusalONLY/notcompletehashfactoryshape-nativeidentity-auth-ownership-admission. ROOTactualFD/devino-beforefault/sameopenFDcleanupAFTERevidence only/no borrowedclosedreclose. ZEROchild/DarwinEXNone UNITnotSourcecleanup-fullEX-originalLinux-allFD-interpreter-descendantclosure. RawchunksUNCHANGED/NOTfixedmemory/heapRSS-timing-causeUNMEASURED.')
            (self.base/'input-retained.bin').write_bytes(self.path.read_bytes());(self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable']);self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags']);self.assertTrue('native' in seen)
            self.assertEqual(1,sum(x['kind']=='native_factory_return' for x in calls))
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned);self.assertEqual(dict(size=len(self.body),sha256=hashlib.sha256(self.body).hexdigest()),result)
                self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls));row=next(r for r in rows if r['stage']=='hash_ctor');self.assertTrue(row['raw'] is seen['proxy']);self.assertFalse(row['raw'] is seen['native']);self.assertTrue(row['returned'])
                self.assertEqual([len(self.body),0],[x['size'] for x in calls if x['kind']=='native_read_return'])
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed);self.assertFalse(attempt.close_returned)
                self.assertFalse(any(x['kind'] in ('Source_close_attempt','repr_first','note_first','native_read_return','native_proxy_update_return','native_proxy_digest_return') for x in calls));self.assertFalse(any(r['stage'] in ('hash_update','hexdigest') for r in rows))
                row=rows[-1];self.assertEqual('hash_ctor',row['stage'])
                if mode=='unknown':self.assertTrue(received is first);self.assertFalse(row['returned']);self.assertIsNone(row['raw']);self.assertTrue(row['error'] is first)
                else:
                    self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(row['returned']);self.assertIs(row['raw'],dict(NoneValue=None,FalseValue=False,TrueValue=True)[mode+'Value'])
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('factory pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);pathstat=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(pathstat.st_dev,pathstat.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_native_factory_then_None_refuses_before_firstread(self):self._case('None')
    def test_native_factory_then_False_refuses_before_firstread(self):self._case('False')
    def test_native_factory_then_True_refuses_before_firstread(self):self._case('True')
    def test_native_factory_then_first_keeps_unknown_factory(self):self._case('unknown')
    def test_new_normal_known_proxy_preserves_native_sha_order(self):self._case('normal')
