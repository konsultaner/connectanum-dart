def __init__(self,path,value):
        self.original_path=path
        self.value=value
        self.path=None
        self.manager=None
        self.writer=None
        self.payload=None
        self.steps=[]
        self.completed=False
        self.first_error=None
        self.secondary_errors=[]
        first=[None]
        secondary=self.secondary_errors

        def guard():
            if first[0] is not None:raise first[0]

        def fail(error,row=None):
            if first[0] is None:first[0]=error # Bind BEFORE any error metadata.
            primary=first[0]
            try:
                self.first_error=primary
                if row is not None:row['error']=primary
            except BaseException as metadata_error:
                secondary.append(metadata_error)
            finally:
                raise primary

        self.guard=guard
        self._fail=fail
