import pathlib,sys,json,hashlib,importlib.util,os,stat,re,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_ALL8_NEW_GCC_dependency_saved_catalogue_lookup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-gcc-entry-dynamic-reference-intake-v1';Q=P/'ALL8-saved-catalogue-lookup-v1';S=B/'2026-11-06-actions-linkage-inputs-v1/actual-new-run-evidence/queries__loader-cache-listing.stdout'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'question':'FIRST ALL8 newly observed GCC-entry NEEDED literal-name lookup in previously saved loader-cache listing ONLY, preserving ALL76ordered bindings/ALL14NUL-terminated INTERP records/ALL15sources/19priorrecords/plugins/v6/ledgers. Exact source is saved queries__loader-cache-listing.stdout located by local saved metadata listing, not native query replay. Keep EVERY matching line and occurrence/architecture/path literal with no favorable host-language-version-ABI filter. Optional complete line format capture does not resolve aliases or select active loader/runtime. No source image/body/SDK rehash, cache query, ENTRYtargetfollow, import, resolve, download, compile, execute, sourcegeneration, Actions/acquisition or numerical work. Existing catalogue coverage/newnames/matches NOTabsence/alias/newness/acquisition/execution authority.','exact_source':str(S),'all_admission_flags':False},indent=2));save('controller.py',sys.argv[1])
 d=json.loads((P/'ROOT-ALL76-ALL14-CP-source-alias-metadata-intake-PRIVATE.json').read_bytes());cp=json.loads((P/'checkpoint-before-intake.json').read_bytes());names=d['ALL8_literal_NEEDED_names'];assert len(names)==8 and len(d['ALL76_ordered_NEEDED_bindings'])==76 and len(d['ALL14_INTERP_records'])==14
 fd=os.open(S,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  st=os.fstat(fd);assert stat.S_ISREG(st.st_mode);before={'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns};parts=[]
  while True:
   raw=os.read(fd,65536)
   if not raw:break
   parts.append(raw)
  raw=b''.join(parts);st=os.fstat(fd);after={'dev':st.st_dev,'ino':st.st_ino,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns};assert before==after and len(raw)==before['size']
 finally:os.close(fd)
 matches=[];offset=0
 for ordinal,line in enumerate(raw.splitlines(keepends=True),1):
  hits=[]
  for name in names:
   needle=name.encode();positions=[];start=0
   while True:
    pos=line.find(needle,start)
    if pos<0:break
    positions.append(pos);start=pos+len(needle)
   if positions:hits.append({'literal_name':name,'line_byte_offsets':positions})
  if hits:
   parsed=re.fullmatch(rb'[ \t]*(\S+)[ \t]+\(([^)]*)\)[ \t]+=>[ \t]+(\S+)[ \t]*(?:\r?\n)?',line)
   matches.append({'line_ordinal':ordinal,'file_byte_offset':offset,'ALL_literal_substring_matches':hits,'literal_line_hex':line.hex(),'literal_line_utf8_surrogateescape':line.decode('utf-8','surrogateescape'),'unresolved_line_format':parsed is None,'captured_name_literal':parsed.group(1).decode('utf-8','surrogateescape') if parsed else None,'captured_qualifier_literal':parsed.group(2).decode('utf-8','surrogateescape') if parsed else None,'captured_path_literal':parsed.group(3).decode('utf-8','surrogateescape') if parsed else None})
  offset+=len(line)
 assert offset==len(raw)
 prior_paths=[]
 for node in ['actions_c_tool_runtime_inputs_v1','actions_c_runtime_transitive_inputs_v1']:
  for path in cp[node]['source_path_references']:prior_paths.append({'CP_node':node,'prior_literal_reference':path})
 summary=[]
 for name in names:
  rows=[x for x in matches if any(h['literal_name']==name for h in x['ALL_literal_substring_matches'])]
  summary.append({'literal_name':name,'ALL_matching_catalogue_lines':[r['line_ordinal'] for r in rows],'ALL_captured_literal_path_metadata':[{'line':r['line_ordinal'],'captured_name':r['captured_name_literal'],'qualifier':r['captured_qualifier_literal'],'path':r['captured_path_literal'],'prior_exact_reference_matches':[p for p in prior_paths if p['prior_literal_reference']==r['captured_path_literal']]} for r in rows]})
 r={'phase':'FIRST_ALL8_GCC_entry_NEEDED_saved_catalogue_metadata_lookup_COMPLETE_CONSUMED_NOT_admitted','catalogue_saved_source':str(S),'saved_metadata_bytes':len(raw),'saved_metadata_sha256':hashlib.sha256(raw).hexdigest(),'saved_metadata_before':before,'saved_metadata_after':after,'ALL76_ordered_NEEDED_bindings':d['ALL76_ordered_NEEDED_bindings'],'ALL14_INTERP_records_NUL_preserved':d['ALL14_INTERP_records'],'ALL8_name_coverage':summary,'ALL_matching_saved_catalogue_line_metadata':matches,'qualification':'NEW relationship lookup in saved catalogue metadata only, not old native query/body/hash/streamcomparison/model/Actions replay. ALL candidate lines/qualifiers/paths retained without ABI choice. Saved candidate path string/exact prior-reference match does NOTprove aliasidentity/active installedversion/default/runtime/ABI/cohort/access/ownership or acquisition/execution authority. Prior matches conservatively exclude any reacquisition; nonmatches are NOTnewness/globalabsence/permission. NULINTERPs unmodified; no path expansion/follow/resolution. PointFD/read/stat/close NOTatomicABA-origin/globalactorFD/continuousofficialphysicalEX-crash admission. AllsetupUNADMITTED/flagsFALSE/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.','separate_launcher_PID_pipe_EOF':None,'all_admission_flags':False}
 save('ROOT-ALL8-catalogue-coverage-ALL76-ALL14-PRIVATE.json',json.dumps(r,ensure_ascii=True,indent=2)+'\n')
 CP=B/'current-task-checkpoint.json';rawcp=CP.read_bytes();save('checkpoint-before-catalogue-lookup.json',rawcp);current=json.loads(rawcp);current['actions_gcc_entry_dynamic_reference_intake_v1'].update(phase=r['phase'],saved_catalogue_bytes=len(raw),saved_catalogue_sha256=r['saved_metadata_sha256'],ALL8_name_coverage=summary,catalogue_metadata_lookup_assessment=str(Q/'ROOT-ALL8-catalogue-coverage-ALL76-ALL14-PRIVATE.json'),public_documentation_pending=True,all_admission_flags=False);current['active_turn_status']['next']='ALL8savedcatalogue/76NEEDED/14INTERP sourcealiasmetadataintake COMPLETE_CONSUMED. Review every catalogue candidate/prior source-body coverage before any expresslydeclared acquisition; no favorableABI/version filter or default/runtime/alias/newness/permission inference. Preserveall15/19/plugins/v6/priorledgers. No oldnewbody/hash/parser/model/query/Actions/archive/numerical replay; allflagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';current['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();current['updated_at']=current['updated_utc'];CP.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'phase':r['phase'],'saved_catalogue_bytes':len(raw),'saved_catalogue_sha256':r['saved_metadata_sha256'],'matching_line_count':len(matches),'ALL8_name_coverage':summary,'qualification':r['qualification']}),flush=True);lease.verify_identity()
