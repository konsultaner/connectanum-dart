import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_NEW_ALL8_saved_linkage_catalogue_metadata_binding_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
P=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-07-actions-gcc-entry-dynamic-reference-intake-v1');Q=P/'catalogue-binding-metadata-v1'
S=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-06-actions-linkage-inputs-v1/actual-new-run-evidence/ROOT-first-linkage-acquisition-assessment.json')
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'question':'NEW ALL8 GCC-entry NEEDED-name coverage/reference binding against prior saved linkage acquisition assessment metadata ONLY, exact saved source named by CP locator. Preserve all76ordered bindings/all14NUL INTERPs; no saved library image/catalogue body or path resolution/query/download/execution authority. Metadata string mentions NOTprior-bodyalias/cohort/newness/permission.','exact_source':str(S),'all_admission_flags':False},indent=2));save('controller.py',sys.argv[1]);raw=S.read_bytes();d=json.loads(raw);needle=['libisl.so.23','libmpc.so.3','libmpfr.so.6','libgmp.so.10','libz.so.1','libzstd.so.1','libc.so.6','ld-linux-x86-64.so.2'];paths=[];matches=[];catalogue=[]
 def walk(x,path):
  if isinstance(x,dict):
   for k,v in x.items():
    if 'catalog' in k.lower():catalogue.append({'location':path+[k],'value':v})
    walk(v,path+[k])
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+[i])
  elif isinstance(x,str):
   if x.startswith('/') or 'catalog' in x.lower() or 'member' in '/'.join(str(p) for p in path).lower():paths.append({'location':path,'literal':x})
   hit=[n for n in needle if n in x]
   if hit:matches.append({'location':path,'literal':x,'ALL_literal_substrings':hit})
 walk(d,[]);r={'source':str(S),'metadata_bytes':len(raw),'metadata_sha256':hashlib.sha256(raw).hexdigest(),'top_keys':list(d),'ALL_catalogue_key_metadata':catalogue,'ALL_catalogue_path_member_scalar_metadata':paths,'ALL8_name_matching_metadata':matches,'qualification':'NEW bounded prior-metadata relationship lookup, not old SDK image/catalogue hash/read/parser/query/native refresh or alias/default/ABI/cohort/execution authority. AllflagsFALSE.','separate_launcher_PID_pipe_EOF':None};save('ROOT-saved-linkage-metadata-reference-binding.json',json.dumps(r,indent=2));print(json.dumps(r),flush=True);lease.verify_identity()
