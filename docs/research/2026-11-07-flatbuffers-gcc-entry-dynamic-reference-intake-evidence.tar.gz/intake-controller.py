import pathlib,sys,json,hashlib,importlib.util,os,stat,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_NEW_ALL76_GCC_dynamic_reference_CP_intake_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-gcc-entry-dynamic-reference-intake-v1';S=B/'2026-11-07-actions-gcc-entry-interiors-v1/ROOT-FIRST-ALL15-summary.json';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 decl={'question':'FIRST source/alias metadata intake for ALL76 ordered NEEDED bindings/eight literal names and ALL14 INTERP records from new saved GCC-entry interpretation. Exact declared sources are current-task-checkpoint.json and 2026-11-07-actions-gcc-entry-interiors-v1/ROOT-FIRST-ALL15-summary.json only. Inspect prior actions_* CP scalar metadata excluding own new interiors, retain every exact/substring mention with JSON location, discover existing saved catalogue metadata reference locations only. No catalogue BODY read, body/parser/SDK hash refresh, acquisition/nativequery/resolve/download/import/compile/execute/Actions/numerical work. No path/default/version/ABI/alias/newness/acquisition authority from names, matches or nonmatches. All15/19/plugins/v6/priorledgers preserved.','all_admission_flags':False}
 save('declaration.json',json.dumps(decl,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def read(path,role):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);row={'role':role,'path':str(path),'open_return_fd':fd};bindings.append(row)
  try:
   s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);before={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};parts=[]
   while True:
    chunk=os.read(fd,65536)
    if not chunk:break
    parts.append(chunk)
   raw=b''.join(parts);s=os.fstat(fd);after={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};assert before==after and len(raw)==before['size'];row.update(before=before,after=after,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),read_EOF=True);return raw
  finally:os.close(fd);row['close_return_fd']=fd
 rawcp=read(CP,'prior_CP_metadata_for_NEW_dynamic_ref_question');d=json.loads(rawcp);s=json.loads(read(S,'ALL15_new_bounded_interpretation_metadata_NOT_body_replay'));save('checkpoint-before-intake.json',rawcp)
 assert s['source_run']==42326330584 and len(s['ALL15_summaries'])==15
 edges=[];interps=[]
 for sourceordinal,r in enumerate(s['ALL15_summaries']):
  for bindingordinal,b in enumerate(r['ALL_needed_RPATH_RUNPATH_bindings']):
   edges.append({'source_ordinal':sourceordinal,'source_reference':r['source_reference'],'binding_ordinal':bindingordinal,**b})
  for x in r['INTERP']:interps.append({'source_ordinal':sourceordinal,'source_reference':r['source_reference'],**x})
 assert len(edges)==76 and all(x['tag']==1 for x in edges) and len(interps)==14
 names=list(dict.fromkeys(x['literal'] for x in edges));assert len(names)==8
 literal_interps=list(dict.fromkeys(x['literal_bytes']['utf8_surrogateescape'] for x in interps));assert literal_interps==['/lib64/ld-linux-x86-64.so.2\u0000']
 needles=names+literal_interps
 prior_keys=[k for k in d if k.startswith('actions_') and k!='actions_gcc_entry_interiors_v1']
 scalars=[]
 def walk(x,path):
  if isinstance(x,dict):
   for k,v in x.items():walk(v,path+[k])
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+[i])
  elif isinstance(x,str):scalars.append((path,x))
 for k in prior_keys:walk(d[k],[k])
 matches=[];catalogue=[]
 for path,value in scalars:
  hits=[]
  for needle in needles:
   offsets=[];start=0
   while True:
    offset=value.find(needle,start)
    if offset<0:break
    offsets.append(offset);start=offset+len(needle)
   if offsets:hits.append({'literal_needle':needle,'exact_scalar':value==needle,'literal_substring_offsets':offsets})
  if hits:matches.append({'JSON_location':path,'literal_scalar':value,'ALL_matches':hits})
  if 'catalogue' in value.lower() or 'catalogue' in '/'.join(str(p) for p in path).lower():catalogue.append({'JSON_location':path,'literal_scalar':value})
 result={'phase':'FIRST_ALL76_NEEDED_ALL14_INTERP_CP_source_alias_metadata_intake_COMPLETE_CONSUMED_NOT_admitted','source_run':42326330584,'ALL76_ordered_NEEDED_bindings':edges,'ALL14_INTERP_records':interps,'ALL8_literal_NEEDED_names':names,'ALL_literal_INTERP_values_with_NUL':literal_interps,'prior_CP_actions_nodes':prior_keys,'prior_string_scalar_count':len(scalars),'ALL_prior_CP_matching_scalar_metadata':matches,'ALL_prior_CP_catalogue_mention_metadata':catalogue,'exact_scalar_match_count':sum(h['exact_scalar'] for r in matches for h in r['ALL_matches']),'matching_scalar_count':len(matches),'catalogue_mention_scalar_count':len(catalogue),'qualification':'String matches and nonmatches only scoped prior CP metadata, NOTalias identity/globalabsence/newness/hostpathselection/actualloader/compiler/header/default/Cargo/ABI/cohort/access/ownership/acquisition or execution authority. INTERP NUL retained, no trim/normalize/resolve. Full prior metadata preserved, no catalogue body read or installed image rehash. PointFD/stat/hash/close NOTatomicABA-origin/globalnativeactorFD/continuousofficialphysicalEX-crash admission. AllflagsFALSE/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.','reader_tool_separate_launcher_PID_pipe_EOF':None,'all_admission_flags':False}
 save('metadata-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('ROOT-ALL76-ALL14-CP-source-alias-metadata-intake-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2)+'\n')
 d['actions_gcc_entry_dynamic_reference_intake_v1']={'directory':str(P),'phase':result['phase'],'source_run':42326330584,'needed_edges':76,'interp_records':14,'needed_names':names,'exact_scalar_match_count':result['exact_scalar_match_count'],'matching_scalar_count':len(matches),'catalogue_mention_scalar_count':len(catalogue),'assessment':str(P/'ROOT-ALL76-ALL14-CP-source-alias-metadata-intake-PRIVATE.json'),'all_admission_flags':False,'public_documentation_pending':True};d['active_turn_status']['next']='ALL76NEEDED/ALL14INTERP priorCPmetadataintake COMPLETE_CONSUMED; exactmatches NOTalias/absence/newness/permission. Next inspect declared saved catalogue metadata references before ANYacquisition, retain ALL8names/ALL14INTERP/ALL15sources/19priorrecords/plugins/v6/priorledgers. No body/hash/parser/model/query/Actions/archive replay. AllflagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 summary={k:v for k,v in result.items() if k not in ['ALL76_ordered_NEEDED_bindings','ALL14_INTERP_records','ALL_prior_CP_matching_scalar_metadata']};summary['matching_scalar_locations']=[{'JSON_location':x['JSON_location'],'ALL_matches':x['ALL_matches']} for x in matches];print(json.dumps(summary),flush=True);lease.verify_identity()
