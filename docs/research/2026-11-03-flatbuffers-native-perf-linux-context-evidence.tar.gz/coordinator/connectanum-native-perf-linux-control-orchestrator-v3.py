"""Single NEW OWN Linux method attempt; no product build/capture/acceptance."""
from pathlib import Path
import ast, base64, datetime, hashlib, json, os, re, shutil, stat, sys, time, types
sys.path.insert(0, "/Users/konsultaner/.codex/skills/local-model-companions/scripts")
from ollama_companion import local_resource_lease, LocalResourceLeaseError
WT = Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
OUT = Path("/private/tmp/connectanum-native-perf-linux-control-attempt-v3")
PRIMARY = Path("/private/tmp/connectanum-native-perf-linux-control-primary")
METHOD = Path("/tmp/connectanum-native-perf-linux-control-method-v3.py")
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(lease):
    lease.verify_identity()
    assert shutil.disk_usage(WT).free >= 1536 * 1024**2
    cp = json.loads(Path("/tmp/connectanum-current-task-checkpoint.json").read_bytes())
    expected = cp["native_perf_only_diagnostic_design"]["current_source_sha256"]
    assert len(expected) == 20
    sources = {name: (WT / name).read_bytes() for name in expected}
    assert {name: sha(raw) for name, raw in sources.items()} == expected
    method = METHOD.read_bytes()
    orchestrator_sha = sha(Path(__file__).read_bytes())
    ast.parse(method)
    receipt = json.loads((PRIMARY / "receipt.json").read_bytes())
    digest = receipt["selected_platform_digest"]
    assert digest == "sha256:29434a59c93070e470f84663e4289026e04644ea44b5220ef7e07d653318ca1f"
    image = "docker.io/library/python@" + digest
    config = receipt["image_config_digest"]
    assert config == "sha256:fe83005fb105be014095e304ce578212522449ec2ad47649ef4833ef9a84abda"
    assert sha((PRIMARY / "python-arm64-manifest.json").read_bytes()) == digest[7:]
    mod = types.ModuleType("linux_method_command_owner")
    mod.__file__ = str(WT / "tool/native_perf_build_producer.py")
    exec(compile(sources["tool/native_perf_build_producer.py"], mod.__file__, "exec"), mod.__dict__)
    census = json.loads(Path("/private/tmp/connectanum-native-perf-linux-control-docker-census/summary.json").read_bytes())
    assert census["status"] == "supporting_only"
    endpoint = census["endpoint"]
    assert endpoint.startswith("unix:///") and census["context"] == "desktop-linux"
    sock = Path(endpoint[7:]).resolve(strict=True)
    si = sock.stat()
    assert stat.S_ISSOCK(si.st_mode) and si.st_uid in (0, os.getuid())
    socket_stamp = (si.st_dev, si.st_ino, si.st_uid)
    entry = Path("/usr/local/bin/docker")
    target = entry.resolve(strict=True)
    docker_sha = mod._regular_hash(target, owners={0, os.getuid()})
    selected_context_raw = (Path("/private/tmp/connectanum-native-perf-linux-input-observation") / "declaration.json").read_bytes()
    selected_context = json.loads(selected_context_raw)
    selected_stamp = selected_context["socket_stamp"]
    if (type(selected_stamp) is not list or len(selected_stamp) != 3
            or any(type(value) is not str or re.fullmatch("0|[1-9][0-9]*", value) is None for value in selected_stamp)):
        raise RuntimeError("invalid selected local context socket stamp")
    continuity = {
        "docker_entry": str(entry) == selected_context["docker_entry"],
        "docker_target": str(target) == selected_context["docker_target"],
        "docker_sha256": docker_sha == selected_context["docker_sha256"],
        "local_endpoint": endpoint == selected_context["local_endpoint"],
        "socket_stamp": socket_stamp == tuple(int(value) for value in selected_stamp),
        "host_controller_uid_data": os.getuid() == selected_context["host_source_owner_uid_data_only"]}
    if not all(continuity.values()):
        with Path("/tmp/connectanum-native-perf-linux-context-continuity-refusal.json").open("x") as stream:
            json.dump({"scope": "NEW method preflight refusal only", "capture_ready": False,
                "source_admitted": False, "continuity": continuity,
                "selected_context_declaration_sha256": sha(selected_context_raw),
                "no_attempt_namespace_container_or_primitive_started": True}, stream, indent=2)
        raise RuntimeError("selected method context drifted; no alternative cohort/reprobe")
    env = dict(os.environ)
    assert not any(env.get(k) for k in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"))
    OUT.mkdir(mode=0o700)
    commands = OUT / "commands"
    commands.mkdir()
    bundle = OUT / "bundle"
    bundle.mkdir(mode=0o755)
    (bundle / "tool").mkdir(mode=0o755)
    for name, raw in sources.items():
        with (bundle / name).open("xb") as stream:
            stream.write(raw)
        (bundle / name).chmod(0o644)
    with (bundle / "method.py").open("xb") as stream:
        stream.write(method)
    (bundle / "method.py").chmod(0o644)
    nonce = os.urandom(16).hex()
    container_name = "ct132-method-" + nonce
    declared = {
        "kind": "own-unprivileged-linux-method-context-v3-intake", "declared": now(),
        "scope": "namespaced finite mechanism controls ONLY; never live capture admission",
        "completed_intake_predecessor": "connectanum-native-perf-linux-control-attempt-v1",
        "predecessor_failure_sha256": sha((Path("/private/tmp/connectanum-native-perf-linux-control-attempt-v1") / "failure.json").read_bytes()),
        "source_context_binding": {"host_controller_uid_data": os.getuid(), "guest_uid": 1000, "guest_gid": 1000,
            "source_owner_namespace": "guest_controller", "kind": "own-unprivileged-linux-method-v3"},
        "image_id_semantics": "exact29.4containerd manifest target ID; config independently bound via exact exported blob",
        "capture_ready": False, "live_admission": False,
        "source_head": "601108ea6216464bd00ae29c16cfaf0a59c71db6",
        "all20source_sha256": expected, "method_sha256": sha(method),
        "orchestrator_sha256": orchestrator_sha,
        "primary_receipt_sha256": sha((PRIMARY / "receipt.json").read_bytes()),
        "selected_method_context_declaration_sha256": sha(selected_context_raw),
        "selected_method_context_continuity": continuity,
        "platform_digest": digest, "image_config_digest": config,
        "selected_tag_metadata_only": receipt["tag_before_data"],
        "platform": "linux/arm64", "image_reference": image, "container_name": container_name,
        "docker_entry": str(entry), "docker_target": str(target), "docker_read_sha256": docker_sha,
        "local_endpoint": endpoint, "socket_stamp": [str(v) for v in socket_stamp],
        "environment_sha256": sha(json.dumps(env, sort_keys=True, ensure_ascii=True).encode()),
        "storage_admission": {"test_floor_bytes": 1024**3, "image_allowance_bytes": 512*1024**2,
                              "build_floor_bytes_UNCHANGED": 12*1024**3, "no_build_authorized": True},
        "cases": ["fdexec-positive", "pre-go-eof-negative", "handoff"],
        "case_nonces": {name: os.urandom(16).hex() for name in
                        ("fdexec-positive", "pre-go-eof-negative", "handoff")},
        "guest_policy": {"uid": 1000, "gid": 1000, "cap_drop": "ALL", "network": "none",
            "readonly_root": True, "no_new_privileges": True, "memory": 268435456,
            "pids_limit": 32, "cpus": 1, "tmpfs_bytes": 16777216,
            "only_host_mount": "exact declared OWN source bundle READONLY", "no_added_capabilities": True,
            "no_security_relaxation": True, "no_restart_kill_retry_or_cleanup": True},
        "command_order": ["reuse-completed-method-image-input-links-NO-COMMAND", "container-create",
            "container-inspect-before", "copy-python-elf", "copy-readonly-bundle-back",
            "container-inspect-staged", "attach-start-ONCE", "wait-natural", "container-inspect-after"],
        "command_template": [str(entry), "--host", endpoint, "{one-declared-operation}"],
        "guest_command": ["/usr/local/bin/python3.14", "-I", "-S", "-B",
                          "/opt/control/method.py", "coordinator"],
        "limitations": ["No original diagnostic host/kernel/credentials/perf/access/inheritance/arming proof.",
            "No actual original WAMP/SDK/compiler/native/roles/privateCOW/clock/compiledclosure/acceptance.",
            "Real os.execve(fd) API, not syscall-level tracing or proof of every delegated loaded image.",
            "EOF is not writer authenticity or whole descendant completion.",
            "Namespace user1000 credentials are actual only within this Docker control context.",
            "Live independent preflight provider absent; live SessionController CLOSED."]
    }
    mod._write_json(OUT / "declaration.json", declared)
    declaration_sha = mod._regular_hash(OUT / "declaration.json")
    operations, records = [], []
    known_container = None
    frozen_manifest_sha = None
    def recheck():
        lease.verify_identity()
        assert mod._regular_hash(OUT / "declaration.json") == declaration_sha
        assert entry.resolve(strict=True) == target and mod._regular_hash(target, owners={0, os.getuid()}) == docker_sha
        info = sock.stat()
        assert (info.st_dev, info.st_ino, info.st_uid) == socket_stamp
        assert {name: sha((WT / name).read_bytes()) for name in expected} == expected
        assert sha(METHOD.read_bytes()) == declared["method_sha256"]
        assert sha(Path(__file__).read_bytes()) == orchestrator_sha
        if frozen_manifest_sha is not None:
            assert mod._regular_hash(bundle / "manifest.json") == frozen_manifest_sha
    def observe(name, args, *, allow_failure=False):
        recheck()
        operation = mod.AuxiliaryCommand(directory=commands, name=name,
            argv=[str(entry), "--host", endpoint, *args], cwd=WT, environment=env,
            lease_check=lease.verify_identity, stdout_max=8*1024**2, stderr_max=8*1024**2)
        operations.append(operation)  # Prepared owner BEFORE spawn.
        operation.start()
        result = operation.result
        while result is None:
            result = operation.wait(5)
        records.append(result)
        mod._write_json(OUT / (name + "-record.json"), result)
        raw = mod._read_bound_metadata(commands / (name + ".stdout"),
                                       result["outputs"]["stdout"]["snapshot"], 8*1024**2)
        if result["status"] != "success" and not allow_failure:
            raise RuntimeError("declared Docker operation failed: " + name)
        return raw
    def inspect_container(name):
        raw = observe(name, ["container", "inspect", known_container])
        decoded = json.loads(raw)
        assert type(decoded) is list and len(decoded) == 1
        data = decoded[0]
        assert data["Id"] == known_container and data["Image"] == digest
        assert data["Name"] == "/" + container_name
        cfg, host = data["Config"], data["HostConfig"]
        assert cfg["User"] == "1000:1000"
        assert cfg["Entrypoint"] == ["/usr/local/bin/python3.14"]
        assert cfg["Cmd"] == ["-I", "-S", "-B", "/opt/control/method.py", "coordinator"]
        assert not cfg["OpenStdin"] and not cfg["Tty"]
        assert host["NetworkMode"] == "none" and host["ReadonlyRootfs"] is True
        assert host["CapDrop"] == ["ALL"] and not host["CapAdd"] and host["Privileged"] is False
        assert not host["Binds"]
        mounts = host["Mounts"]
        assert len(mounts) == 1
        assert mounts[0]["Type"] == "bind" and mounts[0]["Source"] == str(bundle)
        assert mounts[0]["Target"] == "/opt/control" and mounts[0]["ReadOnly"] is True
        assert mounts[0]["BindOptions"]["Propagation"] == "rprivate"
        actual_mounts = [x for x in data["Mounts"] if x["Destination"] == "/opt/control"]
        assert len(actual_mounts) == 1 and actual_mounts[0]["RW"] is False
        assert actual_mounts[0]["Source"] == str(bundle)
        assert host["PidsLimit"] == 32 and host["Memory"] == 268435456
        assert host["MemorySwap"] == 268435456 and host["NanoCpus"] == 1000000000
        assert host["RestartPolicy"]["Name"] == "no"
        assert host["SecurityOpt"] == ["no-new-privileges:true"]
        assert host["Tmpfs"] == {"/tmp": "rw,nosuid,nodev,noexec,size=16777216,mode=1777"}
        return data
    try:
        completed = Path("/private/tmp/connectanum-native-perf-linux-control-attempt-v2")
        exported_raw = (completed / "exported-identity-receipt.json").read_bytes()
        exported = json.loads(exported_raw)
        assert exported["manifest_digest"] == digest and exported["config_digest"] == config
        expected_method_elf = json.loads((completed / "bundle/manifest.json").read_bytes())["method_python_elf_sha256"]
        mod._write_json(OUT / "completed-method-input-links.json", {
            "scope": "reuse completed exact image/export/ELF INPUT receipts only, no admission",
            "exported_identity_receipt_sha256": sha(exported_raw),
            "expected_method_elf_sha256": expected_method_elf,
            "manifest_digest": digest, "config_digest": config, "capture_ready": False,
            "source_admitted": False, "live_admission": False,
            "no_image_pull_inspect_save_or_old_identity_guard_repeat": True})
        cid_raw = observe("container-create", ["container", "create", "--name", container_name,
            "--user", "1000:1000", "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
            "--network", "none", "--read-only",
            "--mount", "type=bind,source=" + str(bundle) + ",target=/opt/control,readonly,bind-propagation=rprivate",
            "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=16777216,mode=1777",
            "--memory", "268435456", "--memory-swap", "268435456", "--pids-limit", "32",
            "--cpus", "1", "--workdir", "/tmp", "--entrypoint", "/usr/local/bin/python3.14",
            image, "-I", "-S", "-B", "/opt/control/method.py", "coordinator"])
        cid = cid_raw.decode("ascii").strip()
        assert re.fullmatch("[0-9a-f]{64}", cid)
        known_container = cid
        before = inspect_container("container-inspect-before")
        assert before["State"]["Status"] == "created" and before["State"]["Running"] is False
        elf_dir = OUT / "method-image-executable"
        elf_dir.mkdir()
        observe("copy-python-elf", ["container", "cp", cid + ":/usr/local/bin/python3.14", str(elf_dir / "python3.14")])
        elf_path = elf_dir / "python3.14"
        assert elf_path.read_bytes()[:4] == b"\x7fELF" and elf_path.stat().st_size <= 32*1024**2
        elf_sha = mod._regular_hash(elf_path)
        assert elf_sha == expected_method_elf
        manifest = {"kind": "own-unprivileged-linux-method-v3", "capture_ready": False,
            "live_admission": False, "source_admitted": False, "declaration_sha256": declaration_sha,
            "container_id": cid, "image_reference": image, "image_config_digest": config,
            "all20source_sha256": expected, "method_sha256": sha(method),
            "source_context": {"host_controller_uid_data": os.getuid(),
                "source_owner_namespace": "guest_controller", "expected_guest_uid": 1000, "expected_guest_gid": 1000},
            "method_python_elf_sha256": elf_sha, "case_nonces": declared["case_nonces"],
            "manifest_written_before_ANY_guest_start": True}
        mod._write_json(bundle / "manifest.json", manifest)
        (bundle / "manifest.json").chmod(0o644)
        frozen_manifest_sha = mod._regular_hash(bundle / "manifest.json")
        back = OUT / "bundle-roundtrip"
        observe("copy-readonly-bundle-back", ["container", "cp", cid + ":/opt/control", str(back)])
        expected_bundle = {str(p.relative_to(bundle)): mod._regular_hash(p)
                           for p in bundle.rglob("*") if p.is_file()}
        actual_bundle = {str(p.relative_to(back)): mod._regular_hash(p)
                         for p in back.rglob("*") if p.is_file()}
        assert expected_bundle == actual_bundle
        staged = inspect_container("container-inspect-staged")
        assert staged["State"]["Status"] == "created" and staged["State"]["Running"] is False
        mod._write_json(OUT / "staged-before-start.json", {
            "declaration_sha256": declaration_sha, "manifest_sha256": frozen_manifest_sha,
            "actual_roundtrip_files": actual_bundle, "container_id": cid,
            "source_identity_binding": {"host_uid_data": os.getuid(), "guest_uid": 1000, "guest_gid": 1000,
                "owner_namespace": "guest_controller"},
            "readonly_OWN_bundle_mount_not_root_trusted_helper_proof": True,
            "capture_ready": False, "live_admission": False})
        raw_guest = observe("attach-start-once", ["container", "start", "--attach", cid], allow_failure=True)
        # No restart/retry/reset; raw stream is retained even if parsing fails.
        natural_wait_raw = observe("wait-natural", ["container", "wait", cid])
        after = inspect_container("container-inspect-after")
        state = after["State"]
        assert state["Status"] == "exited" and state["Running"] is False
        assert type(state["ExitCode"]) is int
        assert natural_wait_raw == (str(state["ExitCode"]) + "\n").encode("ascii")
        assert state["StartedAt"] and state["FinishedAt"]
        extracted = OUT / "guest-raw"
        extracted.mkdir(mode=0o700)
        footer, artifact_records, special, pending = None, [], [], []
        def pairs(items):
            out = {}
            for key, value in items:
                assert key not in out
                out[key] = value
            return out
        assert raw_guest.endswith(b"\n")
        for line in raw_guest.splitlines():
            value = json.loads(line, object_pairs_hook=pairs)
            event = value.get("event")
            assert footer is None
            if event == "artifact":
                name = value["path"]
                rel = Path(name)
                assert name and not rel.is_absolute() and all(x not in ("..", ".") for x in rel.parts)
                data = base64.b64decode(value["data_base64"], validate=True)
                assert type(value["size"]) is int and value["size"] == len(data) <= 2*1024**2
                assert sha(data) == value["sha256"]
                output = extracted / rel
                output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                with output.open("xb") as stream:
                    stream.write(data)
                artifact_records.append({key: value[key] for key in ("path", "size", "sha256")})
            elif event == "special_metadata":
                special.append(value)
            elif event == "owned_pending":
                pending.append(value)
            elif event == "method_footer":
                footer = value
            else:
                raise RuntimeError("unknown method output; raw retained")
        assert state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["Error"]
        assert footer is not None and footer["artifacts"] == artifact_records
        assert footer["capture_ready"] is False and footer["live_admission"] is False
        assert footer["all_declared_cases_completed"] is True and footer["case_count"] == 3 and not footer["errors"]
        assert [(x["case"], x["status"]) for x in footer["known_actor_statuses"]] == [
            ("fdexec-positive", 0), ("pre-go-eof-negative", 78), ("handoff", 0)]
        recheck()
        mod._write_json(OUT / "summary.json", {"scope": "actual_namespaced_unprivileged_Linux_method_ONLY",
            "capture_ready": False, "live_admission": False, "source_admitted": False,
            "declaration_sha256": declaration_sha, "manifest_sha256": frozen_manifest_sha,
            "container_id": cid, "container_state": state, "method_python_elf_sha256": elf_sha,
            "known_actor_statuses": footer["known_actor_statuses"], "artifact_records": artifact_records,
            "special_metadata": special, "pending_records": pending, "command_records": records,
            "source20_unchanged": True, "no_canonical_build_originalSDK_native_perf_or_benchmark": True,
            "free_bytes": shutil.disk_usage(WT).free, "finished": now()})
        print(json.dumps({"result": "three_method_cases_complete", "capture_ready": False,
                          "source_admitted": False, "directory": str(OUT)}))
    except BaseException as error:
        # Terminal attempt: retain partial command data, known CID/actors; no retries.
        mod._write_json(OUT / "failure.json", {"capture_ready": False, "live_admission": False,
            "error_type": type(error).__name__, "reason": str(error), "container_id": known_container,
            "commands": records, "finished": now(), "no_retry_cleanup_restart_or_kill": True})
        raise

deadline = time.monotonic() + 45
errors = []
while True:
    admitted = False
    try:
        with local_resource_lease(exclusive=True) as lease:
            admitted = True
            run(lease)
    except LocalResourceLeaseError as error:
        if admitted:
            raise
        errors.append(str(error))
        if time.monotonic() >= deadline:
            path = Path("/tmp/connectanum-native-perf-linux-control-method-admission-refusal.json")
            with path.open("x") as stream:
                json.dump({"errors": errors, "before_attempt_or_any_Docker_actions": True}, stream, indent=2)
            print("Unstarted method resource admission refused.")
            break
        time.sleep(.5)
    else:
        break
