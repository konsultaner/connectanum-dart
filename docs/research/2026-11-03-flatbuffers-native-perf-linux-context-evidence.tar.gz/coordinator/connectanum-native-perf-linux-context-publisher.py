import sys,os,io,stat,json,hashlib,tarfile,shutil,subprocess,datetime
from pathlib import Path
T=Path("/private/tmp")
D=Path("/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart")
W=Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
R=T/"connectanum-native-perf-linux-control-attempt-v3"
stem="2026-11-03-flatbuffers-native-perf-linux-context"
sha=lambda b:hashlib.sha256(b).hexdigest()
def call(argv,cwd=D):
    p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors="replace")[-1600:])
    return p.stdout
ACTIVE_LEASE.verify_identity()
cpfile=Path("/tmp/connectanum-current-task-checkpoint.json")
prior=cpfile.read_bytes()
cp=json.loads(prior)
n=cp["native_perf_only_diagnostic_design"]
expected=n["current_source_sha256"]
assert {k:sha((W/k).read_bytes()) for k in expected}==expected
assert call(["git","rev-parse","HEAD"],W).decode().strip()=="601108ea6216464bd00ae29c16cfaf0a59c71db6"
assert not call(["git","diff","HEAD","--","packages","native"],W)
assert not call(["git","status","--porcelain"])
assert call(["git","branch","--show-current"]).decode().strip()=="codex/flatbuffers-acceptance-status"
s=json.loads((R/"summary.json").read_bytes())
decl=json.loads((R/"declaration.json").read_bytes())
assert len(s["command_records"])==8 and all(x["returncode"]==0 and x["outputs"]["stdout"]["eof"] and x["outputs"]["stderr"]["eof"] for x in s["command_records"])
assert s["container_state"]["ExitCode"]==0 and not s["container_state"]["OOMKilled"]
assert [(x["case"],x["status"]) for x in s["known_actor_statuses"]]==[("fdexec-positive",0),("pre-go-eof-negative",78),("handoff",0)]
cases={label:json.loads((R/"guest-raw"/label/"result.json").read_bytes()) for label in ("fdexec-positive","pre-go-eof-negative","handoff")}
positive,negative,wire=(cases[k] for k in ("fdexec-positive","pre-go-eof-negative","handoff"))
assert all(not x["errors"] and x["pidfd_before"]==[] and x["pidfd_after"] for x in cases.values())
assert positive["go_attempted"] is True and negative["go_attempted"] is False
target=positive["target"]
ready=json.loads((R/"guest-raw/fdexec-positive/ready.json").read_bytes())
assert target["pid"]==positive["pid"]==ready["pid"] and str(ready["start_ticks"])==target["start_ticks"]
assert ready["test_exec_callback"] is False
assert target["executable_sha256"]==s["method_python_elf_sha256"] and {x["fd"] for x in target["open_fds"]}=={0,1,2}
assert not (R/"guest-raw/pre-go-eof-negative/target.json").exists()
assert not (R/"guest-raw/pre-go-eof-negative/capture-consumed.json").exists()
assert wire["peer"]=={"uid":1000,"gid":1000,"pid":wire["pid"]}
received=[x for x in wire["wire_evidence"] if x["operation"]=="recvmsg"]
assert received and all(x["fixture_only"] is False for x in received)
assert all(any(a["kind"]==2 for a in x["ancillary"]) for x in received)
assert any(any(a["kind"]==1 for a in x["ancillary"]) for x in received)
assert len(wire["received_fds"])==2 and all(x["noninheritable"] for x in wire["received_fds"])
assert decl["all20source_sha256"]==expected and all(decl["selected_method_context_continuity"].values())
for name,status in (("before",1),("fixed",0),("extra",0)):
    assert json.loads((T/("connectanum-native-perf-linux-context-"+name+"-tests.json")).read_bytes())["status"]==status
root_models={
"GLM_design":"Complete/reaped advisory. Requested same-FD bytes, symmetric sameUID/wrongnamespace regression, GID pin and owned module-cache rollback; implemented/tested. Namespace separation only fixed1000/hostUIDdata. Oldmode022 already blockedgroupwrite; GID pin stricter context, not proofoldgroupwritehole. Not globalatomicity/authentication.",
"Qwen_tests83472":"Complete/reaped advisory; post-read retag, partial module rollback, first read error versus close error controls implemented plus foreign-owner rejection.",
"Qwen_current_review75988":"Complete/reaped advisory; sourceguest selected1-163, root separately fullsource/callers. Reject PIDreuse allegation: self/known direct unreaped single-threaded child, SIGCHLD_DFL, no other reaper, pidfd held beforeGO/across naturalexit. Reject extraction traversal: absolute/up rejected, fresh0700 private parent, only regular xb files, no guest-created symlinks; no global sameUID malicious-host/atomicity claim. Reject unbounded cumulative2MiB artifacts: rawstdout8MiB bound caps total base64 content below that. Schema drift failsclosed, no reprobe/version selection;755bundle inside0700 parent, umask cannotaddpermissions.",
"resource_refusals":"Two current-review admissions refused BEFOREbackend; later final-current-code request admitted, complete/reaped. Other checkpoint/read/publication preparations refused BEFOREIO/source/test; no bypass, no backendunavailability/approval or executed-data retry."
}
with (T/"connectanum-native-perf-linux-context-model-root-summary.json").open("x") as f:
    json.dump({"models":root_models,"capture_ready":False,"all_own_model_command_sessions_reaped":True},f,indent=2)
files={}
special=[]
excluded=[]
roots=[*sorted(T.glob("connectanum-native-perf-linux-context-*")),R,T/"connectanum-native-perf-linux-control-method-v3.py",T/"connectanum-native-perf-linux-control-orchestrator-v3.py"]
for root in roots:
    if root.is_file():files["coordinator/"+root.name]=root
    elif root.is_dir():
        for p in sorted(root.rglob("*")):
            if p.is_dir():continue
            member=root.name+"/"+p.relative_to(root).as_posix()
            info=p.lstat()
            if "method-image-executable" in p.parts:
                excluded.append({"member":member,"bytes":info.st_size,"sha256":sha(p.read_bytes()),"third_party_LOCAL_ONLY":True})
            elif stat.S_ISREG(info.st_mode):files[member]=p
            else:special.append({"member":member,"mode":info.st_mode,"device":str(info.st_dev),"inode":str(info.st_ino),"target_sha256":sha(os.readlink(p).encode()) if p.is_symlink() else None})
public=D/"docs/research"
archive=public/(stem+"-evidence.tar.gz")
assert not archive.exists()
metadata=json.dumps({"special_nodes_metadata_only":special,"third_party_ELF_LOCAL_ONLY":excluded},indent=2,sort_keys=True).encode()+b"\n"
with tarfile.open(archive,"w:gz") as tar:
    for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
    item=tarfile.TarInfo("archive-retention-metadata.json")
    item.size=len(metadata)
    tar.addfile(item,io.BytesIO(metadata))
verified=[]
with tarfile.open(archive,"r:gz") as tar:
    for item in tar.getmembers():
        assert item.isfile()
        stream=tar.extractfile(item)
        raw=stream.read()
        stream.close()
        original=metadata if item.name=="archive-retention-metadata.json" else files[item.name].read_bytes()
        assert raw==original
        verified.append({"member":item.name,"bytes":len(raw),"sha256":sha(raw)})
free=shutil.disk_usage(W).free
a={"scope":"OWN unprivileged namespaced Linux component controls ONLY; no live capture admission",
"capture_ready":False,"live_admission":False,"source_admitted":False,
"production_packages_native_source_unchanged":True,"source20_unchanged":True,
"source_head":"601108ea6216464bd00ae29c16cfaf0a59c71db6","all20source_sha256":expected,
"private_method_source_sha256":"d5ad8f92c6b5074a429afc59229c25cf48e5d3b9dee6a1697d5005295ec5b270",
"private_host_source_sha256":"e24c2c13009c2fd8e805543fe85136bd615a9a3903235b01626aa8cac927c5fa",
"method_context":"Exact own-unprivileged-linux-method-v3/guest_controller, fixed actual UID/EUID/GID/EGID1000 beforetoolIO; hostUID501 DATAONLY. No legacy scalar/bool/tag/authority ambiguity/owner expansion. Fixed20source names/SHA and regularUID/GID1000/non-group-writable, bounded sameFD bytes+identity recheck compile/cache rollback.",
"unit_before":"TWO actual FAILs on old private v2: host-owner501/wrongnamespace and sameUID1000/wrongnamespace got through and compiled. OWN files/SYNTHETIC namespace stats/UIDs, no production defect/validforgedlive/GO.",
"unit_fixed":"SIX new private-method guardsPASS",
"unit_extra":"FOUR separately appended guardsPASS; source and six-test codeprefix unchanged. Foreign owner/postreadretag/module rollback/readerrno13 beforeONEcloseerrno5. Fixture realclosesknownOWNfd theninjects uncertainty, notlivecleanup.",
"not_combined10_or_canonical":True,
"actual_kernel_cases":[
{"case":"fdexec-positive","direct_status":0,"pid":positive["pid"],"start_ticks":target["start_ticks"],"same_pid_start_before_after_exec":True,"actual_os_execve_FD_no_callback":True,"no_path_fallback_in_our_source":True,"syscall_implementation_NOT_traced":True,"proc_self_exe_backing_SHA_matches_method_ELF":True,"postexec_open_fds":[0,1,2],"actual_pidfd_before":positive["pidfd_before"],"actual_pidfd_after":positive["pidfd_after"]},
{"case":"pre-go-eof-negative","direct_status":78,"pid":negative["pid"],"GO_attempted":False,"target_and_marker_absent":True,"natural_refusal_not_campaign_cancellation":True,"actual_pidfd_before":negative["pidfd_before"],"actual_pidfd_after":negative["pidfd_after"]},
{"case":"credential_descriptor_handoff","direct_status":0,"pid":wire["pid"],"actual_peer":wire["peer"],"named_socket_client_connects_AFTER_own_exec":True,"actual_SO_PEERCRED_and_each_SCM_CREDENTIALS":True,"MSG_CMSG_CLOEXEC_and_noninheritable_rights":True,"received_distinct_pipe_inodes":[x["inode"] for x in wire["received_fds"]],"source_transferred_copies_closed_before_completion_frame":True,"tiny_ping_ack_completed":True,"actual_pidfd_after":wire["pidfd_after"],"not_live_root_offer_endpoints_or_perf_handoff":True}],
"actual_Docker_command_statuses":[0]*8,"all_command_streams_EOF":True,"container_natural_exit":0,"OOMKilled":False,
"method_ELF_sha256":s["method_python_elf_sha256"],"same_selected_cli_path_SHA_socketstamp":decl["selected_method_context_continuity"],
"same_selected_image_manifest":"sha256:29434a59c93070e470f84663e4289026e04644ea44b5220ef7e07d653318ca1f",
"same_config_digest":"sha256:fe83005fb105be014095e304ce578212522449ec2ad47649ef4833ef9a84abda",
"same_fixed_UID1000_policy_readonly_OWN_input_no_chown":True,
"no_image_pull_inspect_save_or_old_guard_control_repeat":True,"prior_terminal_containers_not_restarted":True,
"all_own_known_actor_model_command_statuses_naturally_retained":True,"models":root_models,
"limits":[
"These are current Docker Linuxkit/arm64 unprivileged method cases, not original diagnostic host/kernel/root/perf/SDK/driver/broker controls or authentication.",
"FDexec proof is actual os.execve(fd) API and same PID/start/backing ELF hash, no callback/path fallback in our source; no syscall implementation trace, every delegated image/COW/actual instructions/compiled closure proof.",
"Actual PIDfd readiness is for known OWN finite children; not all descendant completion/global privileged ownership/ABA/atomic observations.",
"Actual wire credentials belong to this named private unprivileged context. Root-only offer_endpoints/private sampler/source bootstrap/access/inheritance/arming/coverage/loss/role/timing remain unproved.",
"Old failed source stat missing, never reconstructed or precise old predicate inferred. New explicit namespace binding never accepts arbitrary observed owner or relaxes original ownership.",
"Source20 uncommitted/uncanonical, liveprovider absent/require_live_admission ALWAYSraises/liveSessionController CLOSED. No ownfullcanonical/sourcearchive/productionrecipe/native/driver/RLIB/SDKcompiler/originalhost/WAMP/VMservice/perf/benchmark/capture/strict dispatch.",
"Original UID/GID/env/argv/--dart dart/SDK/GC/allocator/workers/controls/fullfresh bodies/windows/samples/gates unchanged. No RAM cause/repair/heap/RSS magnitude/strict acceptance."
],
"archive":{"path":"docs/research/"+archive.name,"sha256":sha(archive.read_bytes()),"members":len(verified),"all_regular_members_byte_exact":True,"special_nodes_metadata_only":True,"methodELF_and_old_image_LOCAL_ONLY":True,"prior194_and157_archives_unchanged_not_reread":True},
"free_bytes":free,"build_floor_bytes":12*1024**3,"build_admission_open":False,"cause_of_disk_change_unmeasured":True,"no_cleanup":True}
a["next"]="Integrate scoped actual OWN method receipts into independent preflight orchestration without promoting them to original-host/root/perf/live authority. Full own20tool canonical/source archive/native/driver/staticRLIB/locks/configs/SDKcompiler provenance plus actual original-host credential/access/pidfd/FDexec/inheritance/arming/metadata/role controls and immutable admission stillrequired before anydiagnosticdata. Live gate CLOSED, no unchanged numerical campaign retry."
with (public/(stem+"-assessment.json")).open("x") as f:json.dump(a,f,indent=2);f.write("\n")
with (public/(stem+"-preparation.md")).open("x") as f:f.write(PUBLIC_NOTE)
paragraph=("## Scoped Linux method controls complete; capture remains closed (2026-11-03)\n\n"
"Three fresh OWN unprivileged namespace controls complete: actual FD-based\n"
"Python ELF execution with same PID/start and backing hash, no-GO natural78,\n"
"and actual named-socket credentials/two descriptor rights. Real pidfds are\n"
"held before release and report exit readiness after natural child waits.\n"
"[Exact source, statuses, before regressions and limits](research/"+stem+"-preparation.md).\n\n"
"These are Linuxkit/arm64 method controls, not original-host/root/perf/broker\n"
"verification or admission. Two old-private-context unit failures are fixed;\n"
"six guards plus four separately added guards pass, never combined10/canonical.\n"
"All20tool sources/production601 unchanged/uncommitted/uncanonical. No actual\n"
"production build, WAMP/VMservice/perf/benchmark/capture/strict dispatch, source\n"
"adoption, ownership waiver or cleanup. Live provider/controller stay closed;\n"
"both strict campaigns still fail. Free "+f"{free/1e9:.2f}"+"GB<12GiB buildfloor, cause unmeasured.\n\n")
anchor="## Current source UID context observed"
for rel in ("docs/project_state.md","docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md"):
    p=D/rel
    text=p.read_text()
    assert anchor in text
    insert=paragraph if rel.endswith("project_state.md") else paragraph.replace("(research/","(../research/")
    p.write_text(text.replace(anchor,insert+anchor,1))
names=["docs/project_state.md","docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md","docs/research/"+stem+"-preparation.md","docs/research/"+stem+"-assessment.json","docs/research/"+archive.name]
call(["git","add","--",*names])
assert set(call(["git","diff","--cached","--name-only"]).decode().splitlines())==set(names)
call(["git","commit","-m","docs: retain scoped Linux method execution and credential controls"])
commit=call(["git","rev-parse","HEAD"]).decode().strip()
call(["git","push","github","codex/flatbuffers-acceptance-status"])
assert not call(["git","status","--porcelain"])
rb=T/"connectanum-native-perf-linux-context-root-readback.json"
with rb.open("x") as f:
    json.dump({"docs_commit":commit,"assessment":a,"archive_members_verified":verified,"local_original_files":{k:str(v) for k,v in files.items()},"protected_stopped_v3_container":s["container_id"],"known_actors":s["known_actor_statuses"],"source20_unchanged":True,"capture_ready":False,"source_admitted":False,"all_own_sessions_reaped":True},f,indent=2);f.write("\n")
with (T/"connectanum-native-perf-linux-context-checkpoint-before.json").open("xb") as f:f.write(prior)
n.update({"phase":"private_context_2beforeFAIL_6PASS_plus4separatePASS_actual3scopedLinuxControls_COMPLETE_live_gate_CLOSED",
"linux_context_root_readback":str(rb),"linux_context_phase_docs_commit":commit,
"linux_context_archive_sha256":a["archive"]["sha256"],"linux_context_archive_members":len(verified),
"linux_context_before_failures":2,"linux_context_fixed_PASS":6,"linux_context_extra_PASS_separately":4,
"linux_context_not_combined10_or_canonical":True,"linux_context_actual_kernel_cases_completed":3,
"linux_context_known_actor_statuses":s["known_actor_statuses"],"linux_context_protected_stopped_container":s["container_id"],
"linux_context_fixed_guest_sha256":a["private_method_source_sha256"],"linux_context_final_host_sha256":a["private_host_source_sha256"],
"linux_context_models":root_models,"linux_context_all_own_sessions_reaped":True,
"linux_context_scope":"OWN unprivileged namespaced method ONLY, no original-host/root/perf/admission/production acceptance",
"linux_context_unpublished_pending_admission":False,
"actual_linux_fd_exec_executed":True,"actual_linux_fd_exec_scope":"OWN Linuxkit arm64 Python method os.execve(FD), no callback/pathfallback in our source; no syscalltrace/originaldriver/privilegedhost proof",
"actual_original_driver_linux_fd_exec_verified":False,
"last_free_bytes":free,"current_free_bytes_about":free,"build_disk_admission_open":False,"next":a["next"]})
cp["status_docs_commit"]=commit
cp["updated_utc"]=cp["last_heartbeat_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
cp["last_heartbeat_summary"]="ScopedOWNLinux3 controls complete:FDexec/pidfd/noGO78/actualcredentialrights, statuses0/78/0;2beforeFAIL fixed6PASS+4separate. Source20/production601unchanged; originalhost/root/perf/fullprovenance/liveadmission/strictRAMacceptance unresolved."
cpfile.write_text(json.dumps(cp,indent=2)+"\n")
intro=("Latest2026-11-03 scoped OWN Linux method controls complete: actual Python ELF FD-exec retains PID/start/backing hash, no-GO refusal exits78, and named-socket SO_PEERCRED/each SCM_CREDENTIALS plus two descriptor rights complete. Real pidfds observe each known child exit; actor statuses0/78/0, eight command parents/container natural0. Same preselected image/UID1000/readonly policy/CLI+socket stamp, no owner expansion or old-container/image-control repeat. Two old-private context unit failures fixed; six guards plus four separate extras pass, not combined10/canonical. This is isolated Linuxkit/arm64 component evidence, not original-host/root/perf/SDK/broker/admission or RAM acceptance. Source20/production601 unchanged/uncommitted, liveprovider/controller CLOSED, no actual production build/WAMP/VMservice/perf/benchmark/capture/strict dispatch/adoption/cleanup.\n\nEvidence: docs/research/"+stem+"-preparation.md and matching assessment/archive at docs-only "+commit+".\n\n")
descriptions=[]
for kind,num,endpoint in (("pr132",132,"pulls"),("issue103",103,"issues")):
    before=json.loads(call(["gh","api","repos/konsultaner/connectanum-dart/"+endpoint+"/"+str(num)]))
    assert before["state"]=="open"
    if endpoint=="pulls":assert before["draft"] and before["head"]["sha"]=="40ddcb3ff0dbf947ef21b8e7fb9cca3465a502b5" and before["base"]["ref"]=="codex/flatbuffers-byte-vector-views"
    body=intro+before["body"]
    p=T/("connectanum-native-perf-linux-context-"+kind+"-body.md")
    with p.open("x") as f:f.write(body)
    call(["gh","pr" if endpoint=="pulls" else "issue","edit",str(num),"--repo","konsultaner/connectanum-dart","--body-file",str(p)])
    after=json.loads(call(["gh","api","repos/konsultaner/connectanum-dart/"+endpoint+"/"+str(num)]))
    assert after["body"]==body
    descriptions.append({"kind":kind,"body_sha256":sha(body.encode()),"readback_exact":True})
with (T/"connectanum-native-perf-linux-context-GitHub-description-receipt.json").open("x") as f:
    json.dump({"docs_commit":commit,"descriptions":descriptions,"descriptions_only":True,"head_base_draft_issue_open_unchanged":True,"no_GitHub_tokens_comments_messages":True},f,indent=2)
print(json.dumps({"docs_commit":commit,"archive_members":len(verified),"archive_sha256":a["archive"]["sha256"],"free_bytes":free,"root_readback":str(rb),"actual_kernel_cases":3,"container_id":s["container_id"]}))
