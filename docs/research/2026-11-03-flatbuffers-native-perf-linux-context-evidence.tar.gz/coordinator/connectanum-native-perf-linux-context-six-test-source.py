"""NEW OWN pure method-context regressions; synthetic namespace IDs, no Linux cases."""
import copy, hashlib, importlib.util, json, os, sys, types, unittest
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(os.environ["OWN_CONTEXT_METHOD_SOURCE"])
ROOT=Path(os.environ["OWN_CONTEXT_FIXTURES"])
W=Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
ELF=Path("/private/tmp/connectanum-native-perf-linux-control-attempt-v2/method-image-executable/python3.14")
sha=lambda b:hashlib.sha256(b).hexdigest()
class OwnedPath:
    calls=0
    owner=1000
    gid=1000
    def __init__(self,p):self.p=Path(p.p if isinstance(p,OwnedPath) else p)
    def __truediv__(self,x):return OwnedPath(self.p/x)
    def __str__(self):return str(self.p)
    def __fspath__(self):return str(self.p)
    def __getattr__(self,n):return getattr(self.p,n)
    def lstat(self):
        OwnedPath.calls+=1
        return virtual_stat(self.p.lstat())
def virtual_stat(info):
    values={name:getattr(info,name) for name in (
        "st_dev","st_ino","st_size","st_mode","st_mtime_ns","st_ctime_ns")}
    values.update(st_uid=OwnedPath.owner,st_gid=OwnedPath.gid)
    return types.SimpleNamespace(**values)
class GuestOS:
    uid=1000
    gid=1000
    def __getattr__(self,name):return getattr(os,name)
    def getuid(self):return self.uid
    def geteuid(self):return self.uid
    def getgid(self):return self.gid
    def getegid(self):return self.gid
    def fstat(self,fd):return virtual_stat(os.fstat(fd))
class ContextRegressions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):ROOT.mkdir(mode=0o700)
    def prepare(self,name,owner=1000,legacy=False,namespace="guest_controller"):
        directory=ROOT/name;directory.mkdir();(directory/"tool").mkdir()
        cp=json.loads(Path("/tmp/connectanum-current-task-checkpoint.json").read_bytes())
        expected=cp["native_perf_only_diagnostic_design"]["current_source_sha256"]
        for p,digest in expected.items():
            data=(W/p).read_bytes();self.assertEqual(sha(data),digest)
            (directory/p).write_bytes(data);(directory/p).chmod(0o644)
        data=SOURCE.read_bytes();(directory/"method.py").write_bytes(data)
        manifest={"kind":"own-unprivileged-linux-method-v3","capture_ready":False,
            "source_admitted":False,"live_admission":False,"all20source_sha256":expected,
            "method_sha256":sha(data),"method_python_elf_sha256":sha(ELF.read_bytes()),
            "source_context":{"host_controller_uid_data":501,"source_owner_namespace":namespace,
                "expected_guest_uid":1000,"expected_guest_gid":1000}}
        if legacy:manifest["source_file_owner_uid"]=owner
        module=types.ModuleType("owned_method_context_case")
        module.__file__=str(SOURCE)
        exec(compile(data,str(SOURCE),"exec"),module.__dict__)
        module.SOURCE=OwnedPath(directory);module.PYTHON=str(ELF);module.Path=OwnedPath;module.os=GuestOS()
        OwnedPath.owner=owner;OwnedPath.gid=1000;OwnedPath.calls=0
        return directory,manifest,module
    def invoke(self,directory,manifest,module):
        (directory/"manifest.json").write_text(json.dumps(manifest,sort_keys=True))
        saved={name:sys.modules.get(name) for name in (
            "native_perf_guard","native_perf_blocked_exec","native_perf_handoff")}
        try:return module.checked_modules()
        finally:
            for name,previous in saved.items():
                if previous is None:sys.modules.pop(name,None)
                else:sys.modules[name]=previous
    def test_host_owner_context_rejected_before_source_io(self):
        directory,manifest,module=self.prepare("host-owner-501",501,True,"host_controller")
        with self.assertRaises((ValueError,AssertionError)):
            self.invoke(directory,manifest,module)
        self.assertEqual(OwnedPath.calls,0)
    def test_same_uid_wrong_namespace_rejected_before_source_io(self):
        directory,manifest,module=self.prepare("same-uid-wrong-namespace",1000,True,"host_controller")
        with self.assertRaises((ValueError,AssertionError)):
            self.invoke(directory,manifest,module)
        self.assertEqual(OwnedPath.calls,0)
    def test_fixed_namespace_positive_not_host_uid_permission(self):
        directory,manifest,module=self.prepare("valid")
        returned,modules=self.invoke(directory,manifest,module)
        self.assertEqual(set(modules),{"native_perf_guard","native_perf_blocked_exec","native_perf_handoff"})
        self.assertEqual(returned["source_context"]["host_controller_uid_data"],501)
        self.assertIs(returned["capture_ready"],False)
    def test_context_types_and_authority_rejected_before_source_io(self):
        for name,mutation in [
            ("bool-uid",lambda m:m["source_context"].update(expected_guest_uid=True)),
            ("uid-string",lambda m:m["source_context"].update(expected_guest_uid="1000")),
            ("guest501",lambda m:m["source_context"].update(expected_guest_uid=501)),
            ("kind",lambda m:m.update(kind="own-production-v1")),
            ("authority",lambda m:m.update(capture_ready=True))]:
            directory,manifest,module=self.prepare(name);mutation(manifest)
            with self.subTest(name=name),self.assertRaises((ValueError,AssertionError)):
                self.invoke(directory,manifest,module)
            self.assertEqual(OwnedPath.calls,0)
    def test_runtime_and_file_gid_rejected(self):
        directory,manifest,module=self.prepare("runtime-gid")
        module.os.gid=1001
        with self.assertRaises((ValueError,AssertionError)):
            self.invoke(directory,manifest,module)
        self.assertEqual(OwnedPath.calls,0)
        directory,manifest,module=self.prepare("source-gid")
        OwnedPath.gid=1001
        with self.assertRaises((ValueError,AssertionError)):
            self.invoke(directory,manifest,module)
    def test_same_fd_bytes_used_no_compile_path_reread(self):
        directory,manifest,module=self.prepare("same-fd")
        original=OwnedPath.__getattr__
        def restricted(self,name):
            if name=="read_bytes" and self.p.parent.name=="tool":
                raise AssertionError("second path read of compiled source")
            return original(self,name)
        with patch.object(OwnedPath,"__getattr__",restricted):
            returned,modules=self.invoke(directory,manifest,module)
        self.assertEqual(len(modules),3)
if __name__=="__main__":
    if os.environ.get("OWN_CONTEXT_BEFORE_ONLY")=="1":
        unittest.main(argv=[sys.argv[0],
            "ContextRegressions.test_host_owner_context_rejected_before_source_io",
            "ContextRegressions.test_same_uid_wrong_namespace_rejected_before_source_io"])
    else:unittest.main()
