import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-select-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW Aux per-native select original constructor reader descriptors/streams/process/input lists/timeout/lookup/intent/raw tuple progress; original min(remaining,.05), no SDK/nativebuild/HEAD/tests/capture/cleanup',source_expected='649857ccf5379fd2a86db87376a073d8b155e28dde7a7e42191474c45971ce7f',tests_expected='574940e8d7166fe92b48c1950953970fa1efad3197913993984eb4dfd24000e5',prior_components_consumed_no_unchanged_repeat=True,all_source_test_model_admin_ops_official_leases=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='649857ccf5379fd2a86db87376a073d8b155e28dde7a7e42191474c45971ce7f' and hashlib.sha256(tests).hexdigest()=='574940e8d7166fe92b48c1950953970fa1efad3197913993984eb4dfd24000e5'
 for name,body in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(body)
 s=source.decode();cls=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 selected={x.name:ast.get_source_segment(s,x) for x in cls.body if isinstance(x,ast.FunctionDef) and x.name in ('wait','_arm_constructor','_constructor_guard','_defer')}
 with (P/'selected-source.json').open('x') as f:json.dump(selected,f,indent=2)
 l.verify_identity();print('NEW select source snapshot; source649857/tests574940 exact; no tests/HEAD/SDK/native executed')
