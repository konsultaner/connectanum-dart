import sys,pathlib,json,hashlib,subprocess,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-select-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];slot=len(calls);row=dict(argv=argv,Popen_attempted=True,pid=None,status=None,stdout_eof=None,stderr_eof=None);calls.append(row)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  row['parent_pipe_FDstats']={name:dict(fd=stream.fileno(),dev=os.fstat(stream.fileno()).st_dev,ino=os.fstat(stream.fileno()).st_ino) for name,stream in [('stdout',child.stdout),('stderr',child.stderr)]}
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  out,err=child.communicate();status=child.wait();row.update(status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   path=q/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   st=path.stat();assert st.st_size==len(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest();row[label+'_pathstat']=dict(dev=st.st_dev,ino=st.st_ino,size=st.st_size)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not production
 h=json.loads((P/'after-edit-hashes.json').read_text());prior=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-stream-read-progress-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items()) and all(h[k]==v for k,v in prior.items() if 'build_producer.py' not in k)
 before=(P/'source-before.py').read_text();current=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert current==(P/'candidate-producer-v3.py').read_text() and current==(P/'after-producer.py').read_text()
 old=ast.parse(before);new=ast.parse(current);oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_select_guard','_select_readers'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','wait','_constructor_guard','_complete'})
 methods=(P/'candidate-methods.py.txt').read_text();init=(P/'candidate-init.py.txt').read_text();schema=(P/'candidate-schema-v2.py.txt').read_text();fields=(P/'candidate-data-fields-v3.txt').read_text();full=(P/'candidate-complete-guard.txt').read_text()
 projected=current.replace(methods,'',1).replace(init,'',1).replace('        self._select_guard()\n','',1).replace(full,'',1).replace(schema,'',1).replace(fields,'',1)
 projected=projected.replace('                if readers:self._select_readers(readers,min(remaining,.05))','                if readers:select.select(readers,[],[],min(remaining,.05))',1)
 assert projected==before and tests==(P/'tests-before.py').read_text()+'\n\n'+(P/'new-tests.py').read_text()
 assert 'for index,' not in schema and 'for sindex,ssnapshot' in schema
 def output_literal(node):
  return next(x for x in ast.walk(node) if isinstance(x,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='whole_descendant_exit_proven' for k in x.keys))
 assert ast.dump(output_literal(om['_complete']))==ast.dump(output_literal(nm['_complete']))
 forbidden={'repr','str','add_note','_write_json','close','_close_slot','wait','kill','_complete','_observe_status','_read_stream'}
 calls=[x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id if isinstance(x.func,ast.Name) else '' for x in ast.walk(nm['_select_readers']) if isinstance(x,ast.Call)]
 assert not set(calls)&forbidden
 body=ast.get_source_segment(current,nm['_select_readers'])
 assert body.index("check();row['lookup_attempted']=True;selector=select.select")<body.index("row['select_attempted']=True;value=selector(readers,writers,exceptions,timeout)")
 assert body.index("row['raw_return']=value;row['returned']=True")<body.index("if (type(value) is not tuple")<body.index("row['value_valid']=True;check();row['completed']=True")
 assert not any(isinstance(x,ast.Return) for x in ast.walk(nm['_select_readers']))
 guard_calls=[]
 for name,node in nm.items():
  for call in ast.walk(node):
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='_select_guard':guard_calls.append(dict(caller=name,keywords=[ast.unparse(x) for x in call.keywords]))
 assert {x['caller'] for x in guard_calls}=={'_constructor_guard','_complete'}
 invariant=dict(ROOT_whole_final_affected_methods_new7_helper_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_BYTEexact=True,
 old_read_directwait_poll_defer_othermethods_factories_gates_emit_freeze_auxpredicates_exact=True,original_result_literal_ASTexact=True,generic_Command_select_unchanged=True,
 native_input_readers_list_object_order_empty_write_exception_args_timeout_min_remaining_dot05_preserved=True,helper_normalNone_matches_ignored_original_select_result=True,
 original_Ctor_streams_readFDs_log_process_buffers_EOF_and_args_beforelookup=True,foreignFD_refuses_beforelookup_select=True,actualrawreturn_beforeformat_and_postbinding_checks=True,
 first_error_permanent_no_report_cleanup_restore_retry_replay_pipelineadvance=True,ordinary_latestrow_full_pre_finalization_and_passive_history=True,guard_calls=guard_calls,
 passive_inner_sindex_preserves_original_outer_auxiliary_index=True,descriptor_refs_and_tuples_DATA_NOTkernelidentity_ABA_auth_arming_partialPopenauthority_EXrelease_or_admission=True,
 local_GLM_response_limit1_NOretained_final_NOTapproval_ORglobalunavailability=True,ROOT_independent_source_tests_AST_qualified_NOTmodel_fullcurrent_approval=True,
 lease_backingFD_init_generic_enclosing_historical_transitive_fullphysicalEX_originalruntimeadmission_INCOMPLETE=True)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 reports=[];journals=[]
 for stage in ('before','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('select-before-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
   assert d['original_process_retained'] is True
   if stage=='after-selected':
    assert d['row_present'] is True and d['row_original_process'] is True
    if d['mode'] in ('foreign-before','fd-drift','arg-drift','invalid-bool','unknown-return'):
     assert d['guard_raises_received_first'] is True and d['private_first_is_received'] is True and d['row_error_is_received'] is True
     assert d['pending'] is True and d['finished'] is False and d['result_is_None'] is True and d['row_completed'] is False and d['after_fault_source_attempts']==[]
     assert d['row_expected_readers']==d['original_fds']
     if d['mode']=='foreign-before':assert not d['events'] and d['row_select_attempted'] is False and d['row_lookup_attempted'] is False
     else:
      assert len(d['events'])==1 and d['events'][0]['source_intent_before_native'] is True
      if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['row_returned'] is None and d['row_raw'] is None
      elif d['mode']=='invalid-bool':assert d['row_returned'] is True and d['row_raw_is_False'] is True and d['row_value_valid'] is not True
      else:assert d['row_returned'] is True and d['row_raw']==d['events'][0]['raw']
      if d['mode']=='arg-drift':assert len(d['row_readers_arg_after'])==len(d['row_readers_before'])+1 and d['foreign_fd'] in d['row_readers_arg_after']
    else:
     assert d['row_returned'] is True and d['row_value_valid'] is True and d['row_completed'] is True
     assert d['events'] and all(x['source_intent_before_native'] is True for x in d['events'])
     if d['mode']=='empty':
      assert d['guard_absent'] is True and d['status'] is None and d['natural_wait_observed'] is False and d['pending'] is True and d['finished'] is False
      assert all(x['raw']==[[],[],[]] for x in d['events'])
     else:assert d['mode']=='ready' and d['finished'] is True and d['pending'] is False and any(x['raw'][0] for x in d['events'])
  for path in sorted((P/stage/'fixtures').rglob('select-unit-cleanup.json')):
   raw=path.read_bytes();journals.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 assert len(reports)==14 and len(journals)==14
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(waits)==28 and all(type(row['status']) is int and row['status']==0 for row in waits)
 for name,data in [('new-precleanup-reports.json',reports),('new-unit-journals.json',journals)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 b=json.loads((P/'before/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert (b['tests'],b['failures'],b['errors'])==(7,5,0) and (a['tests'],a['failures'],a['errors'])==(19,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 NEWbefore7=b,AFTERselected19=a,not_aggregated_or_current20canonical_or_originalruntimeadmission=True,
 source_Git=dict(head=head,branch=branch,untracked20_exact=True,production_packages_native_diffempty=True,four_signed0_BOTHseparateEOF=True,DATA_only=True),
 planning=json.loads((P/'test-planning/finish.json').read_text()),review=json.loads((P/'review/finish.json').read_text()),ROOT_review_qualification=json.loads((P/'ROOT-review-assessment.json').read_text()),
 ROOT_independent_wholefinal_source_tests_AST_qualified_NOTmodel_fullapproval=True,candidate_UNEXECUTED_before_edit=True,
 private_v2_assembler_uniqueness_assertion_FAIL_BEFOREoutputs_sourcewrite_model_and_v3_Aux_only_correction=True,assembler_failure_APIreturn_chat_only_NOTreconstructed=True,
 new_finite_journals=14,new_known_boundwait_rows=28,new_signed0_rows=28,cached_possible_NOTfreshsyscall=True,
 only_pureguardprobe_aftererror_NOsecond_source_wait_read_poll=True,afterfault_monitored_native_attempts_zero=True,
 two_actual_OWN_normal_SourceAux_commands_percase_not_other_task_actors=True,old_existing_readguard_later_refusal_NOTnew_foreign_readbug=True,
 old_unknownreturn_first_ALREADYretained_NEWstronger_select_intent_policy_NOTfifth_native_kernelbug=True,
 normalready_ROOTrelease_BEFOREnativecall_UNITreadinesssetup_NOTworkloadarming=True,other_ROOTrelease_AFTERevidence_finite8s_gate_bounded10sSAMEwait_UNITnotbenchmarkfreeze=True,
 readiness_tuple_completed_DATA_NOTkernel_sampler_arming_ownership_or_release=True,
 ROOT_unit_cleanup_stat_errors=sum(row['kind']=='ROOT_known_FD_stat_error_NOTclosureproof' for j in journals for row in j['data']),
 ROOT_unit_cleanup_identity_drifts=sum(row['kind']=='ROOT_known_FD_identity_changed_NOTclosed' for j in journals for row in j['data']),
 ROOTknown_parentFD_rawlog_cleanup_afterevidence_UNITonly_NOTliveEX=True,logical_history_lists_scalars_sharedrefs_NOTexactheapRSS_bound_leak_timing_or_cause=True,
 required_legacy_setup_actorFD_APIreturns_notallserialized_no_reconstruction=True,inlineartifact_APIreturns_notall_regularfiles=True,all_named_operational_controllers_BEFOREcalls=True,
 other18helpers3bins_BYTEexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,
 free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_old_cleanup_spacechange_cause_UNMEASURED=True,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,
 provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_OPEN_DRAFT_base130_issue103_milestoneOPEN=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_select_progress']
 v.update(new_epoch_UNTESTED=False,ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW select postcomponent4Git0/BOTHseparateEOF/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Finalf39da0/299139 nineteen selected PASS=7matchingNEW+12affected; ROOTqualified NOmodelanswer/current20canonical/admission')
 c['active_turn_status']='Aux_selectf39da0_299139_selected19PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],NEWbefore7='5FAIL2normalPASS0APIerrors',AFTERselected19='PASS',new_unit_journals=14,new_boundwait_rows=28,signed0=28,free_bytes=free)))
