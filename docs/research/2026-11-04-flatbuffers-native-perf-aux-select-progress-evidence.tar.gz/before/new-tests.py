class AuxiliarySelectProgressTests(unittest.TestCase):
    """NEW actual select boundaries with finite own actors; no kernel admission."""
    def _select_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-select-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        release=base/'finite-release';actors=[];logs={};pipes=[];closed=[];cleanup=[];events=[];after_ops=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_read=os.read
        native_select=producer.select.select;native_mono=producer.time.monotonic
        real_allocate=producer.AuxiliaryCommand._allocate_process
        a=None;b=None;raised=None;guard_error=None;fault=False;clock_calls=0
        first=OSError(5,'OWN native select return hidden by ROOT fault');payload=b'OWN-A-select-ready'
        def allocate(current,record):
            value=real_allocate(current,record);actors.append(dict(name=current.name,process=value,bound_wait=value.wait,bound_poll=value.poll));return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for name in ('select-source','select-foreign'):
                for role in ('stdout','stderr'):
                    if path==base/(name+'.'+role):logs[name+'.'+role]=value
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            st=os.fstat(fd);value=native_close(fd);closed.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None));return value
        def rows():
            journal=getattr(a,'_select_journal',None)
            return journal if type(journal) is list else []
        def shape(raw):
            if type(raw) is tuple and len(raw)==3 and all(type(part) is list and all(type(fd) is int for fd in part) for part in raw):
                return [list(part) for part in raw]
            return None
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                code="import pathlib,time,os;p=pathlib.Path("+repr(str(release))+");end=time.monotonic()+8\nwhile not p.exists() and time.monotonic()<end: time.sleep(.005)\n"
                if mode=='ready':code+="os.write(1,"+repr(payload)+")"
                a=producer.AuxiliaryCommand(directory=base,name='select-source',argv=[sys.executable,'-c',code],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);a.start()
                b=producer.AuxiliaryCommand(directory=base,name='select-foreign',argv=[sys.executable,'-c',"import os;os.write(1,b'OWN-B-ready')"],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);b.start()
                source=next(x for x in actors if x['name']=='select-source');foreign=next(x for x in actors if x['name']=='select-foreign')
                self.assertEqual(0,foreign['bound_wait'](10))
                original_fds=[a.streams[role]['fd'] for role in ('stdout','stderr')]
                foreign_fd=b.streams['stdout']['fd'];known={}
                for fd in original_fds+[foreign_fd]:
                    st=os.fstat(fd);known[fd]=(st.st_dev,st.st_ino)
                def clock():
                    nonlocal clock_calls,fault
                    clock_calls+=1;value=native_mono()
                    if mode=='foreign-before' and clock_calls==2:
                        a.streams['stdout']['fd']=foreign_fd;fault=True
                    return value
                def polling():
                    if fault:after_ops.append(dict(kind='source_bound_poll_attempt'))
                    return source['bound_poll']()
                def reading(fd,count):
                    if fault:
                        st=os.fstat(fd)
                        if known.get(fd)==(st.st_dev,st.st_ino):after_ops.append(dict(kind='source_native_read_attempt',fd=fd,count=count))
                    return native_read(fd,count)
                def selecting(readers,writers,exceptions,timeout):
                    nonlocal fault
                    if fault:after_ops.append(dict(kind='source_native_select_attempt'))
                    row=rows()[-1] if rows() else {}
                    intent=(row.get('readers_arg') is readers and row.get('select_attempted') is True and row.get('returned') is None)
                    before=list(readers)
                    if mode=='ready' and not release.exists():
                        # UNIT readiness setup before this native call, not a workload GO.
                        with native_open(release,'x') as f:f.write('OWN finite unit readiness release')
                    value=native_select(readers,writers,exceptions,timeout)
                    events.append(dict(stage='actual_native_select_return',readers_before=before,writers_before=list(writers),
                        exceptions_before=list(exceptions),timeout=timeout,raw=shape(value),source_intent_before_native=intent))
                    if mode in ('fd-drift','arg-drift','invalid-bool','unknown-return'):
                        fault=True
                        if mode=='fd-drift':a.streams['stdout']['fd']=foreign_fd
                        if mode=='arg-drift':readers.append(foreign_fd)
                        if mode=='invalid-bool':return False
                        if mode=='unknown-return':raise first
                    return value
                source['process'].poll=polling
                with mock.patch.object(producer.time,'monotonic',clock),mock.patch.object(os,'read',reading),mock.patch.object(producer.select,'select',selecting):
                    try:a.wait(timeout=1 if mode=='ready' else .12)
                    except BaseException as error:raised=error
                    if mode!='ready':
                        # Pure entry guard only; no second source wait/read/poll after error.
                        try:a._constructor_guard()
                        except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            row=rows()[0] if rows() else {};raw=row.get('raw_return');arg=row.get('readers_arg')
            report=dict(mode=mode,events=events,after_fault_source_attempts=after_ops,clock_calls=clock_calls,
                raised_is_injected=raised is first,raised_is_ProducerError=type(raised) is producer.ProducerError,
                guard_raises_received_first=raised is not None and guard_error is raised,guard_absent=guard_error is None,
                private_first_is_received=raised is not None and getattr(a,'_deferred_primary_error',None) is raised,
                original_process_retained=a._constructor_quarantine.get('allocated_process') is source['process'],
                original_fds=original_fds,foreign_fd=foreign_fd,pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                status=a.status,natural_wait_observed=a._natural_wait_observed,
                row_present=bool(row),row_original_process=row.get('process') is source['process'],
                row_readers_before=list(row['readers_before']) if type(row.get('readers_before')) is tuple else None,
                row_expected_readers=list(row['expected_readers']) if type(row.get('expected_readers')) is tuple else None,
                row_readers_arg_after=list(arg) if type(arg) is list and all(type(fd) is int for fd in arg) else None,
                row_lookup_attempted=row.get('lookup_attempted'),row_select_attempted=row.get('select_attempted'),
                row_returned=row.get('returned'),row_raw=shape(raw),row_raw_is_False=raw is False,
                row_value_valid=row.get('value_valid'),row_completed=row.get('completed'),
                row_error_is_received=raised is not None and row.get('error') is raised,
                known_ROOT_parent_pipes=pipes,known_ROOT_native_close_returns=closed,
                scope='TWO own finite SourceAux actors/actual select before ROOT faults; FD/tuple fields not kernel identity/ABA/auth/arming/physicalEX/SDK')
            with (base/'select-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_process_retained'])
            if mode=='ready':
                self.assertIsNone(raised);self.assertTrue(a.finished);self.assertFalse(a.pending);self.assertIsNotNone(a.result)
                self.assertEqual(payload,(base/'select-source.stdout').read_bytes())
                self.assertTrue(events);self.assertTrue(any(event['raw'] is not None and event['raw'][0] for event in events))
            elif mode=='empty':
                self.assertIsNone(raised);self.assertIsNone(guard_error);self.assertTrue(events)
                self.assertTrue(all(event['raw']==[[],[],[]] for event in events))
                self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.status);self.assertFalse(a._natural_wait_observed)
            else:
                if mode=='foreign-before':self.assertEqual([],events);self.assertIs(type(raised),producer.ProducerError)
                else:
                    self.assertEqual(1,len(events))
                    if mode=='unknown-return':self.assertIs(first,raised)
                    else:self.assertIs(type(raised),producer.ProducerError)
                self.assertEqual([],after_ops);self.assertIs(raised,guard_error);self.assertTrue(report['private_first_is_received'])
                self.assertTrue(report['row_original_process']);self.assertTrue(report['row_error_is_received'])
                self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result);self.assertFalse(report['row_completed'])
                self.assertEqual(original_fds,report['row_expected_readers'])
                if mode=='foreign-before':self.assertFalse(report['row_select_attempted'])
                else:
                    self.assertTrue(events[0]['source_intent_before_native'])
                    if mode=='unknown-return':self.assertIsNone(report['row_returned']);self.assertIsNone(report['row_raw'])
                    else:
                        self.assertIs(report['row_returned'],True)
                        if mode=='invalid-bool':self.assertTrue(report['row_raw_is_False']);self.assertIsNot(report['row_value_valid'],True)
                        else:self.assertEqual(events[0]['raw'],report['row_raw'])
        finally:
            try:
                if not release.exists():
                    with native_open(release,'x') as f:f.write('OWN finite unit cleanup release after evidence')
            finally:
                for actor in actors:
                    value=actor['bound_wait'](10);cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=0,cached_possible=True));self.assertIs(type(value),int);self.assertEqual(0,value)
                identities={(item['fd'],item['dev'],item['ino']) for item in closed};seen=set()
                for item in pipes:
                    key=(item['fd'],item['dev'],item['ino'])
                    if key in seen or key in identities:continue
                    seen.add(key);fd=item['fd']
                    try:st=os.fstat(fd)
                    except OSError as error:
                        cleanup.append(dict(kind='ROOT_known_FD_stat_error_NOTclosureproof',fd=fd,errno=error.errno));continue
                    if (st.st_dev,st.st_ino)!=(item['dev'],item['ino']):
                        cleanup.append(dict(kind='ROOT_known_FD_identity_changed_NOTclosed',fd=fd));continue
                    value=native_close(fd);cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
                for name,log in logs.items():
                    if not log.closed:
                        fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                        log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',name=name,fd=fd,returned=True))
                with (base/'select-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_foreign_readers_refuse_before_actual_select(self):self._select_case('foreign-before')
    def test_actual_select_then_FD_drift_stops_before_next_native_operation(self):self._select_case('fd-drift')
    def test_actual_select_then_input_list_drift_stops(self):self._select_case('arg-drift')
    def test_actual_select_then_False_is_not_ignored(self):self._select_case('invalid-bool')
    def test_actual_select_then_fault_retains_unknown_intent(self):self._select_case('unknown-return')
    def test_normal_actual_empty_timeout_preserves_pending(self):self._select_case('empty')
    def test_normal_actual_readiness_preserves_bytes_and_completion(self):self._select_case('ready')
