import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-select-progress-v1');before=(p/'source-before.py').read_text();s=before
 methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema.py.txt').read_text();full=(p/'candidate-complete-guard.txt').read_text()
 needle='    def _wait_natural_status(self,timeout):';assert s.count(needle)==1;s=s.replace(needle,methods+needle,1)
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='        self._stream_read_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._stream_read_guard()\n        self._select_guard()\n\n    def _constructor_record',1)
 cls=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_complete')
 body=ast.get_source_segment(s,node);needle='        self._constructor_guard()\n';assert body.count(needle)==1;s=s.replace(body,body.replace(needle,needle+full,1),1)
 needle='                if readers:select.select(readers,[],[],min(remaining,.05))';replacement='                if readers:self._select_readers(readers,min(remaining,.05))'
 assert s.count(needle)==1;s=s.replace(needle,replacement,1)
 needle="            read_state=values.get('_stream_read_state');read_journal=values.get('_stream_read_journal')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 fields="                select_fields_valid=select_ok,select_quarantined=select_quarantined,\n                select_entries=len(select_journal) if type(select_journal) is list else None,\n                select_returned=select_last.get('returned') if type(select_last.get('returned')) is bool else None,\n                select_value_valid=select_last.get('value_valid') if type(select_last.get('value_valid')) is bool else None,\n                select_completed=select_last.get('completed') if type(select_last.get('completed')) is bool else None,\n"
 needle='                stream_read_fields_valid=read_ok,stream_read_quarantined=read_quarantined,';assert s.count(needle)==1;s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer.py',s),('candidate-data-fields.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='649857-before',tofile='NEW-select-candidate')))
 l.verify_identity();print('private select candidate UNEXECUTED; source unchanged')
