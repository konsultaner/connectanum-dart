import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-select-progress-v1');result=json.loads((p/'before/result.json').read_text());assert (result['tests'],result['failures'],result['errors'])==(7,5,0)
 reports=[];journals=[]
 for path in sorted((p/'before/fixtures').rglob('select-before-cleanup.json')):
  raw=path.read_bytes();d=json.loads(raw);reports.append(dict(path=str(path.relative_to(p)),sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),data=d))
  assert d['original_process_retained'] is True
  if d['mode']=='foreign-before':assert len(d['events'])==1 and d['foreign_fd'] in d['events'][0]['readers_before'] and d['foreign_fd'] in d['events'][0]['raw'][0]
  if d['mode']=='fd-drift':assert len(d['events'])==1 and any(x['kind']=='source_bound_poll_attempt' for x in d['after_fault_source_attempts'])
  if d['mode'] in ('arg-drift','invalid-bool'):assert len(d['events'])>1 and d['after_fault_source_attempts']
  if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['guard_raises_received_first'] is True and d['private_first_is_received'] is True and d['row_present'] is False
  if d['mode']=='ready':assert d['finished'] is True and any(x['raw'][0] for x in d['events'])
 for path in sorted((p/'before/fixtures').rglob('select-unit-cleanup.json')):
  raw=path.read_bytes();journals.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(reports)==7 and len(journals)==7 and len(waits)==14 and all(type(row['status']) is int and row['status']==0 for row in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),NEWbefore7='5FAIL2normalPASS0APIerrors',source_epoch='649857/574940',
 actual_foreign_FD_select_seen_before_existing_read_guard_refusal_NOTnew_foreign_read_bug=True,
 post_select_FD_drift_advances_one_native_poll_before_existing_read_guard=True,
 input_list_drift_and_injected_False_ignored_with_more_native_loop_operations=True,
 unknown_native_return_then_ROOTfault_old_caller_ALREADYretains_first_NEWstronger_intent_policy_NOTfifth_native_kernel_bug=True,
 actual_empty_timeout_and_actual_native_readable_tuple_normal_completion_PASS=True,
 reports=reports,journals=journals,new_known_finite_SAMEboundwaits14_signed0=True,cached_possible=True,
 readiness_ROOTrelease_BEFOREnativecall_UNITsetup_NOTworkload_arming=True,
 other_modes_ROOTrelease_AFTERevidence_UNITcleanup_NOTliveEX=True,original_waitbudget_and_native_min_remaining_dot05_unchanged=True,
 prior_legacy_rawlimits_preserved_no_reconstruction=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(cp.read_text());v=d['native_perf_only_diagnostic_design']['auxiliary_select_progress'];v.update(planning_pending=False,planning_status=0,NEW_tests_UNEXECUTED=False,NEWbefore7='5FAIL2normalPASS0APIerrors',ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),candidate_UNIMPLEMENTED=True,review_pending=True);d['active_turn_status']='Aux_select_NEWbefore7_5FAIL2PASS_candidateUNIMPLEMENTED_source649857_unchanged';cp.write_text(json.dumps(d,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(NEWbefore7='5FAIL2normalPASS0APIerrors',actual_empty_and_readiness_PASS=True,new_boundwaits14_signed0=True)))
