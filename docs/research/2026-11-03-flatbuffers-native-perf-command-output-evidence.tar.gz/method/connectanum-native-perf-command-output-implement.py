from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();p=root/'tool/native_perf_build_producer.py';s=p.read_text()
 s=s.replace('import hashlib\n','import base64\nimport hashlib\n',1).replace('import shutil\n','import shutil\nimport select\n',1)
 s=s.replace('A waited child and log snapshot do not prove all descendants exited, SDK identity,','A direct child status plus output-pipe EOF does not prove all descendants exited, SDK identity,',1)
 s=s.replace('self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None','self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None\n        self.output_fd=None;self.output_buffer=b\'\';self.output_write_uncertain=False;self.output_log=None',1)
 a=s.index('    def _spawn(self):');b=s.index('    def _finish(self,',a)
 s=s[:a]+'''    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index])
        self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
        self.log=(self.directory/f'command-{index:03}.log').open('xb',buffering=0)
        self.output_log=self.log;self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False
        self.output_hash=hashlib.sha256();self.output_bytes=0
        kind,tool=self.task_kinds[index]
        record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),
                'returncode':None,'spawn_error':None,'output_eof':False,'log_complete':False,
                'whole_descendant_exit_proven':False,'parent_output_write_close_confirmed':False}
        self.records.append(record)
        writer=None
        try:
            self.output_fd,writer=os.pipe()
            os.set_inheritable(self.output_fd,False);os.set_inheritable(writer,False)
            os.set_blocking(self.output_fd,False)
            self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=writer,
                stderr=subprocess.STDOUT,close_fds=True,env=self.environment)
        except OSError as error:
            record['spawn_error']=repr(error)
            for fd in (writer,self.output_fd):
                if fd is not None:
                    try:os.close(fd)
                    except OSError as secondary:error.add_note('unspawned output close failed: '+repr(secondary))
            self.output_fd=None;record['output_eof']=None
            self._end_command(None)
            self._finish('failed','command spawn failed: '+repr(error))
        else:
            # Own the actual child before any fallible close/journal operation.
            record['pid']=self.process.pid;self.pending=True
            try:
                fd=writer;writer=None
                os.close(fd)
            except OSError as error:
                self.deferred_error=repr(error)
                record['parent_output_write_close_error']=repr(error)
                self._preserve_failure(error)
            else:record['parent_output_write_close_confirmed']=True
            self._event('command_spawned',index=index,pid=self.process.pid)

    def _observe_direct_status(self):
        status=self.process.poll()
        if status is not None and self.records[-1]['returncode'] is None:
            self.records[-1]['returncode']=status
            self.records[-1]['direct_exit_observed_ns']=time.time_ns()
        return status

    def _drain_output(self,deadline):
        """Continue one pipe, bounded by the caller's remaining wait budget.

        EOF authenticates no writer or descendant identity. A read error fails the
        run even if later continuation reaches EOF. An ambiguous file-write error
        quarantines the original read FD and bounded unwritten bytes, without
        replaying bytes, closing a live writer channel, or launching another child.
        """
        record=self.records[-1]
        while True:
            self._observe_direct_status()
            if self.output_write_uncertain:return False
            if self.output_buffer:
                try:count=self.output_log.write(self.output_buffer)
                except BaseException:
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise
                if type(count) is not int or not 0<count<=len(self.output_buffer):
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise ProducerError('output log write count is uncertain')
                self.output_hash.update(self.output_buffer[:count]);self.output_bytes+=count
                self.output_buffer=self.output_buffer[count:]
                if time.monotonic()>=deadline:return False
                continue
            if record['output_eof'] is True:return True
            try:part=os.read(self.output_fd,65536)
            except InterruptedError:
                if time.monotonic()>=deadline:return False
                continue
            except BlockingIOError:
                remaining=deadline-time.monotonic()
                if remaining<=0:return False
                select.select([self.output_fd],[],[],min(remaining,.05))
                continue
            except BaseException as error:
                record.setdefault('output_read_errors',[]).append(repr(error))
                raise
            if part:
                self.output_buffer=part
                continue
            record['output_eof']=True;record['output_eof_observed_ns']=time.time_ns()
            fd=self.output_fd;self.output_fd=None
            try:os.close(fd)
            except OSError as error:
                record['output_read_close_error']=repr(error)
                raise
            return True

    def _end_command(self,status):
        self.pending=False
        record=self.records[-1];record['returncode']=status;record['ended_ns']=time.time_ns()
        log=self.log;self.log=None;self.output_log=None
        log.flush();os.fsync(log.fileno());log.close()
        data=_file_snapshot(self.directory/f'command-{len(self.records)-1:03}.log')
        record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
        if record['spawn_error'] is None:
            if (record['output_eof'] is not True or self.output_fd is not None or self.output_buffer
                or data!={'size':self.output_bytes,'sha256':self.output_hash.hexdigest()}):
                raise ProducerError('output pipe bytes and final log snapshot differ')
            record['log_complete']=not self.output_write_uncertain and 'output_read_errors' not in record
        self._event('command_end',index=len(self.records)-1,**record)

''' +s[b:]
 s=s.replace("'scope':'owned_child_waited_and_file_snapshots_only'","'scope':'owned_direct_child_wait_output_pipe_eof_and_file_snapshots_only'",1)
 s=s.replace("'provenance':self.provenance})\n        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))", "'provenance':self.provenance,\n             'output_write_uncertain':self.output_write_uncertain,\n             'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if self.output_write_uncertain else None})\n        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))",1)
 s=s.replace('''                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)''','''                if not self._drain_output(deadline):return None
                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)''',1)
 s=s.replace("or record['returncode']!=0 or record['spawn_error'] is not None):raise ProducerError('command phase/argv/status differs')", "or record['returncode']!=0 or record['spawn_error'] is not None\n                or record.get('output_eof') is not True or record.get('log_complete') is not True\n                or record.get('parent_output_write_close_confirmed') is not True):raise ProducerError('command phase/argv/status/output completion differs')",1)
 p.write_text(s);lease.verify_identity()
