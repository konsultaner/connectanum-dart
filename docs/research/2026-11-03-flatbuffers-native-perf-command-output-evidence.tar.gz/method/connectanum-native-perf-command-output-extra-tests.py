from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
addition=r'''

    def test_command_output_later_read_error_preserves_first_journal_failure(self):
        original=producer.CommandProducer._event
        def event(run,kind,**fields):
            if kind=='command_spawned':raise OSError(13,'PRIMARY postspawn journal fault')
            return original(run,kind,**fields)
        with mock.patch.object(producer.CommandProducer,'_event',event):run=self.fixture.start(('ok',),('ok',))
        original_read=producer.os.read;fd=run.output_fd
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY pipe read fault')
            return original_read(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn('PRIMARY',result['error'])
        self.assertTrue(any('SECONDARY' in x for x in result['commands'][0]['secondary_errors']))
        self.assertFalse(result['commands'][0]['log_complete'])

    def test_command_output_short_writes_keep_bytes_and_fd_flags(self):
        run=self.fixture.start(('large',));original=run.output_log
        self.assertFalse(os.get_inheritable(run.output_fd));self.assertFalse(os.get_blocking(run.output_fd))
        class Short:
            def write(self,data):return original.write(data[:17])
        run.output_log=Short()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertIsNone(run.output_fd)
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000,raw)
        self.assertTrue(result['commands'][0]['parent_output_write_close_confirmed'])

    def test_command_output_eof_close_error_consumes_fd_once(self):
        run=self.fixture.start(('ok',));fd=run.output_fd;original_close=producer.os.close;calls=[]
        def close(target):
            if target==fd:
                calls.append(target);original_close(target);raise OSError(5,'uncertain EOF descriptor close')
            return original_close(target)
        with mock.patch.object(producer.os,'close',close):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual([fd],calls);self.assertIsNone(run.output_fd)
        self.assertEqual('failed',result['status']);self.assertEqual(0,run.records[0]['returncode'])
        self.assertIn('uncertain EOF descriptor close',result['error'])

    def test_command_output_write_failure_quarantines_without_replay(self):
        run=self.fixture.start(('large',));original=run.output_log;calls=[]
        class Fault:
            def write(self,data):calls.append(len(data));raise OSError(28,'injected log-space fault')
        run.output_log=Fault()
        try:
            self.assertIsNone(run.wait(2));fd=run.output_fd
            self.assertTrue(run.output_write_uncertain);self.assertTrue(run.output_buffer)
            self.assertIsNone(run.wait(0));self.assertEqual(1,len(calls))
            self.assertEqual(fd,run.output_fd);self.assertTrue(run.pending)
            self.assertFalse(run.evidence_complete);self.assertFalse((run.directory/'result.json').exists())
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
            raw=json.loads((run.directory/'failure.json').read_text())
            self.assertEqual(run.output_buffer,base64.b64decode(raw['unwritten_output_base64']))
        finally:
            # Tiny finite OWN child fits available pipe capacity: no kill/cancel,
            # no producer recovery, no live cleanup workaround or success receipt.
            status=run.process.wait(3)
            (self.base/'fixture-quarantined-output.json').write_text(json.dumps({
                'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit; producer stays quarantined/unadmitted',
                'pid':run.child_pid,'returncode':status,'unwritten_sha256':digest(run.output_buffer),
                'unwritten_base64':base64.b64encode(run.output_buffer).decode('ascii')}))
            self.extra.append(run.process)
            fd=run.output_fd;run.output_fd=None
            if fd is not None:os.close(fd)
            original.close();run.log=None;run.output_log=None
            if run.events is not None:run.events.close();run.events=None
            self.fixture.runs.remove(run)
'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();p=root/'tool/test_native_perf_build_producer.py'
 assert 'def test_command_output_later_read_error' not in p.read_text()
 with p.open('a') as f:f.write(addition)
 lease.verify_identity()
