from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();s=p.read_text()
 s=s.replace('self.output_fd=None;self.output_buffer=b\'\';self.output_write_uncertain=False;self.output_log=None','self.output_fd=None;self.output_buffer=b\'\';self.output_write_uncertain=False;self.output_log=None;self.failure_attempted=False',1)
 s=s.replace('self.deferred_error=repr(error)\n                self._preserve_failure(error)','self._defer_failure(error)',1)
 s=s.replace("self.deferred_error=repr(error)\n                record['parent_output_write_close_error']=repr(error)\n                self._preserve_failure(error)","record['parent_output_write_close_error']=repr(error)\n                self._defer_failure(error)",1)
 s=s.replace('''    def _preserve_failure(self,error):
        try:_write_json(self.directory/'failure.json',{'error':repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
             'output_write_uncertain':self.output_write_uncertain,
             'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if self.output_write_uncertain else None})
        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))''','''    def _defer_failure(self,error):
        if self.deferred_error is None:self.deferred_error=repr(error)
        else:self.records[-1].setdefault('secondary_errors',[]).append(repr(error))
        self._preserve_failure(error)

    def _preserve_failure(self,error):
        # One terminal publication attempt. Later errors remain in the owned
        # record/final failed result, never overwrite the first partial artifact.
        if not self.failure_attempted:
            self.failure_attempted=True
            try:_write_json(self.directory/'failure.json',{'error':self.deferred_error or repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
                 'output_write_uncertain':self.output_write_uncertain,
                 'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if self.output_write_uncertain else None})
            except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))''',1)
 s=s.replace('self.deferred_error=repr(e)\n                self._preserve_failure(e)','self._defer_failure(e)',1)
 p.write_text(s);lease.verify_identity()
