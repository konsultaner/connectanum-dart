from pathlib import Path
import json,sys,hashlib,tarfile,gzip,io,re,subprocess,os,stat,datetime,copy,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
wt=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');docs=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart');base=Path('/tmp/connectanum-native-perf-command-output');name='2026-11-03-flatbuffers-native-perf-command-output';sha=lambda b:hashlib.sha256(b).hexdigest()
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();final=json.loads(Path(str(base)+'-partial-fixed-tests.json').read_text());fixed=json.loads(Path(str(base)+'-fixed-tests.json').read_text());assert final['exit']==fixed['exit']==0
 for rel,h in final['source_sha256'].items():assert sha((wt/rel).read_bytes())==h
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert not subprocess.check_output(['git','diff','HEAD','--','packages','native'],cwd=wt)
 prior=json.loads(Path('/tmp/connectanum-native-perf-admission-final-tests.json').read_text())
 changed=[k for k,h in prior['source_sha256'].items() if h!=final['source_sha256'][k]]
 assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 assert (wt/'tool/test_native_perf_build_producer.py').read_bytes().startswith(Path(str(base)+'-fixed-source/test_native_perf_build_producer.py').read_bytes())
 assert final['source_sha256']['tool/native_perf_build_producer.py']==fixed['source_sha256']['tool/native_perf_build_producer.py']
 assert subprocess.check_output(['git','branch','--show-current'],cwd=docs,text=True).strip()=='codex/flatbuffers-acceptance-status'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=docs)
 files={};special={};phases={}
 def tree(p,label):
  for f in sorted(p.rglob('*')):
   info=f.lstat();key=label+'/'+str(f.relative_to(p))
   if stat.S_ISREG(info.st_mode):files[key]=f
   elif not stat.S_ISDIR(info.st_mode):special[key]={'mode':info.st_mode,'link_target':os.readlink(f) if stat.S_ISLNK(info.st_mode) else None}
 for phase in ['before','implemented','integrated','review-before','fixed','partial-control','partial-fixed']:
  b=Path(str(base)+'-'+phase);r=json.loads(Path(str(b)+'-tests.json').read_text());log=Path(str(b)+'-tests.log').read_bytes()
  assert sha(log)==r['log_sha256']
  phases[phase]={'tests':int(re.search(rb'Ran (\d+) tests?',log)[1]),'exit':r['exit'],'log_sha256':sha(log),'source_sha256':r['source_sha256']}
  for suffix in ['-tests.log','-tests.json']:f=Path(str(b)+suffix);files[phase+'/'+f.name]=f
  for suffix in ['-source','-fixtures']:tree(Path(str(b)+suffix),phase+suffix)
  for rel,h in r['source_sha256'].items():assert sha((Path(str(b)+'-source')/Path(rel).name).read_bytes())==h
 assert phases['fixed']['tests']==64 and phases['partial-fixed']['tests']==1
 for suffix in ['test-advice.txt','test-wrapper.log','source-review.txt','source-review-wrapper.log','write-tests.py','run.py','implement.py','extra-tests.py','fix.py','partial-test.py','publish.py']:
  p=Path(str(base)+'-'+suffix);assert p.is_file();files['method/'+p.name]=p
 archive=docs/'docs/research'/f'{name}-evidence.tar.gz';members={}
 with archive.open('xb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for member,p in sorted(files.items()):
     b=p.read_bytes();info=tarfile.TarInfo(member);info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b));members[member]={'size':len(b),'sha256':sha(b)}
    b=(json.dumps(special,indent=2)+'\n').encode();info=tarfile.TarInfo('original-special-node-metadata.json');info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b));members[info.name]={'size':len(b),'sha256':sha(b)}
 with tarfile.open(archive,'r:gz') as tar:
  assert len(tar.getmembers())==len(members)
  for m in tar:assert members[m.name]=={'size':m.size,'sha256':sha(tar.extractfile(m).read())}
 free=shutil.disk_usage(wt).free
 next_action='Complete actual independently owned preflight/command and nonbenchmark Linux-control producers. This output-pipe completion repair covers version/recipe commands only; Git auxiliary observers, descendant completion, actual SDK/compiler/source/config/native provenance and Linux controls remain unresolved. Live admission stays CLOSED. Own20tool fullcanonical/archive/native/driver/RLIB/3locks/hidden configs/tool/kernel evidence and immutable declaration precede diagnostic data; post-GO roles/timing/metadata must still validate.'
 audit={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'OWN finite Git/Python source-command output completion only; version/recipe output pipe, no real canonical/build/kernel/capture','runtime_head':'601108ea6216464bd00ae29c16cfaf0a59c71db6','production_source_unchanged':True,'uncommitted_python_tools':20,'helper_bundle_files':20,'source_sha256':final['source_sha256'],'changed_files':changed,'other18_files_byteidentical_to_admission_final':True,
 'changed_producer_integration_PASS':64,'new_focused_in_64':8,'required_changed_callers_in_64':56,'additional_partial_failure_control_PASS':1,'final_test_prefix64_byteidentical':True,'NOT_combined65_or_fullcanonical':True,'phases':phases,
 'actual_failures':['Before4=2FAIL+2ERROR. Actual next recipe launched while separately owned actual writer still held output; nonzero recipe finalized failure before writer completion. Two errors were missing output_eof record fields, not two further production defects.','Implemented4PASS and changed60PASS. Four more focused controls made8:7PASS1 actualFAIL. Secondary pipe read error replaced earlier primary postspawn journal error. Fixed first-error retention plus secondary record and one terminal failure-evidence attempt; changed64PASS.','Separate final partial-publication guard first1ERROR due fixture event parameter kind colliding with command record kind, then corrected fixture1PASS. Producer unchanged,64test prefix exact; no combined65 claim.'],
 'method':{'pipe':'Parent owns unbuffered regular log and private noninherited nonblocking read FD; commands inherit only stdout/stderr writer endpoints. Parent relinquishes writer numeric ownership before close. Incremental reads/short writes retain bounded65,536-byte pending data and exact stream digest.','completion':'Actual signed direct-child status is retained before output errors. EOF and full log-stream digest/snapshot equality required before next recipe or success receipt. Close numeric ownership consumed before syscall; ambiguous EOF close never retried. EOF does not authenticate writers or prove descendants exited.','faults':'First primary error remains primary; secondary errors retained in command record. Failed/partial failure.json publication attempted once, never overwritten/retried. Read-error continuation may finish only FAILED, not receipt-ready. Ambiguous log write quarantines original read FD and bounded unwritten bytes with base64 raw failure evidence if publication succeeds, never replays bytes/closes a live channel/launches next command. A naturally pending writer is not canceled.','fixtures':'Extra output writer is a separately main-owned finite direct Popen actor, not an orphan grandchild. All known actor handles naturally waited and statuses retained. Quarantined write test explicitly uses OWN finite-fixture cleanup after known direct natural exit; no producer recovery/success/admission. Its direct recipe child is held in extra-actor bookkeeping for teardown, not a discovered second role.','recipes':'Only finite Python fixture recipes and tiny OWN Git source observations actually executed; all emitted canonical/production receipts remain fixture-kind. Actual installed tool-version control and original workloads not repeated.'},
 'models':{'tests74170':'Qwen COMPLETE/REAPED advisory. Useful ordering/capacity/budget controls adopted. Hypothetical pytest paths/commands and suggested stdout=read-FD example were not executed and are invalid here. Root uses existing unittest and actual numeric writer endpoint.','review33867':'GLM COMPLETE/REAPED with saved assessment, not approval. P1 bounded pending until writer EOF is intentional; known direct status and output_eof already distinguish it in owned record. No global cancellation deadline added. P2 self-explained next-call quarantine is intentional and visible through deferred_error/flag/failure artifact; reject repeated raise/report retry. P3 title journal-close-loss contradicts its own source account: _preserve_failure closes journal, hashes already assigned before mismatch; raw failure retains known status/hash and no completed success artifact is fabricated. Base64 pending bytes remain in memory/failure artifact, contrary to permanent unrecoverability wording. Root independently found actual primary masking and added controls.'},
 'limits':['Actual independent live preflight provider does NOT exist; require_live_admission ALWAYS refuses and live SessionController stays closed. Output completion is not full immutable capture admission.','No actual own20tool canonical/build/archive/production/native/RLIB/compiler/loadedSDK/Linux/root/procfs/pidfd/FDexec/perf/kernel/VM/WAMP/nativebenchmark/capture/numerical result. Tiny fixture Git archives are not actual whole worktree archives.','EOF only establishes this stream has no current writers; it does not authenticate writer identity, prove all descendants exited or private/COW pages/roles/clocks/compiled closure/atomic global ABA. Git auxiliary observations retain their separate prior path and are outside the new output-pipe claim.','Uncertain log writes remain pending/quarantined; no retry/recovery/cancel route or live permission is implemented. Fixture cleanup is not a live workaround. Raw child output retained; no universal secret-free-log promise.','64 is changed producer integration plus1 separately appended control, not combined65, fullcanonical, strict48/50, RAM/RSS/cause/performance acceptance. Prior admission109 and distinct kernel/tool proofs were not rerun unchanged. Original source/workload/SDK/GC/allocator/worker/argv/control/window/sample/body policies remain unchanged.'],
 'archive':str(archive.relative_to(docs)),'archive_sha256':sha(archive.read_bytes()),'archive_members':members,'special_node_metadata':special,'free_bytes':free,'no_cleanup':True,'actual_live_preflight_provider_implemented':False,'live_SessionController_closed':True,'capture_ready':False,'next':next_action}
 Path(str(base)+'-root-readback.json').write_text(json.dumps(audit,indent=2)+'\n');public=copy.deepcopy(audit)
 for v in public['special_node_metadata'].values():
  if v['link_target'] is not None and Path(v['link_target']).is_absolute():v['link_target']={'transient_target_sha256':sha(v['link_target'].encode()),'original':'original-special-node-metadata.json in archive'}
 assert '/tmp/' not in json.dumps(public) and '/Users/' not in json.dumps(public)
 (docs/'docs/research'/f'{name}-assessment.json').write_text(json.dumps(public,indent=2)+'\n')
 note=f'''# Command output completion guards (2026-11-03)

The changed producer passes64 cases (8new output controls plus56required changed
callers), followed by1 separately appended partial-failure publication control.
The64test prefix and producer bytes are identical in that final focused control;
this is not a combined65 or fullcanonical claim. Twenty tools remain uncommitted,
helper bundle20, production packages/native exact601. Actual independent live
preflight remains unresolved; live SessionController intentionally stays closed.

Two actual before failures show the old producer advancing to another recipe or
finalizing a nonzero result while a separately main-owned finite output writer
still holds the command descriptor. Two other before errors only reflect absent
output_eof fields. New source drains a private pipe into a parent-owned regular
log, preserving both streams, incremental bytes/digest and short writes. It
requires actual signed direct-child status AND output EOF before next command or
successful receipt. EOF authenticates no writer and proves no whole-descendant
exit. Git auxiliary observers retain their separate prior path.

Four more controls expose one actual primary-error masking failure: a later
pipe read error replaced an earlier journal error. The first primary is now
retained with secondary record errors. Failure evidence is attempted once;
partial bytes never get overwritten/retried. The final separate control initially
errored because its fixture event argument collided with the command kind field;
that fixture-only correction passes. [Every phase/member hash]({name}-assessment.json),
[all executed source/log/regular fixtures and advisory outputs]({name}-evidence.tar.gz).

Ambiguous log writes quarantine the original read descriptor and bounded pending
bytes; they do not replay bytes, cancel a writer or launch another command. Raw
pending bytes are kept in memory and failure evidence when publication succeeds.
The finite fault fixture explicitly closes its own known descriptors AFTER the
known child naturally exits, preserving a labelled cleanup receipt; this is not
a live recovery or success path. All known finite Popen actors are naturally
waited, with signed statuses retained. No orphan-grandchild cleanup claim.

Qwen and GLM advice is complete/reaped and advisory. Suggested pytest paths and
read-end-as-stdout examples were not executed. Intentional indefinite ownership
pending EOF is not a cancellation deadline. The review's journal-close/hash-loss
allegation is contradicted by its own source account: failure closes the journal
and hashes are assigned before mismatch refusal. No success artifact is invented
on failure. Root independently confirms the primary-error failure above.

No actual own fullcanonical/production recipe or live receipt, native build,
Linux/root/pidfd/FDexec/perf/kernel/VM/benchmark/capture or new numerical result.
All positive canonical/production receipt callers remain fixture-kind. Previous
actual installed CLI controls, admission109 and original strict data were not
rerun unchanged. Output completion remains supporting command evidence only,
capture_ready=false. Own source/config/SDK/compiler/native provenance, descendant
completion, actual independent preflight and bounded Linux controls remain next;
post-GO role/timing/metadata outcomes still require validation. Both strict
campaigns remain failed; no production RAM cause/repair/acceptance. PR132 draft.
Last free{free/10**9:.2f}GB; no cleanup, source commit/push/adoption or strict dispatch.
'''
 (docs/'docs/research'/f'{name}-preparation.md').write_text(note)
 state=docs/'docs/project_state.md';s=state.read_text();at=s.index('## ');s=s[:at]+f'''## Command output completion verified; live preflight unresolved (2026-11-03)

Changed producer guards pass64 cases plus1 separate new partial-failure control.
Actual before failures advanced while an OWN finite output writer was still alive;
new source waits for direct status AND pipe EOF, preserves late bytes and first
errors, and keeps partial publications terminal. EOF is not whole-descendant
proof. [Exact scope, failures and evidence](research/{name}-preparation.md).

Twenty tools uncommitted, helper20, production601 unchanged. No actual canonical/
native build/Linux/perf/kernel/VM/benchmark/capture or strict dispatch. Actual
independent preflight provider remains unresolved; live SessionController stays
closed. All known OWN finite actors naturally waited; uncertain output uses only
explicit fixture cleanup, never live recovery. Last free{free/10**9:.2f}GB, no cleanup.
Original strict campaigns remain failed; no production RAM repair/acceptance.

'''+s[at:];state.write_text(s)
 plan=docs/'docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md';s=plan.read_text();at=s.index('## ');s=s[:at]+f'''Command producer output completion now passes64changed cases plus1separate new
partial-failure guard. Before-failing late-writer ordering and primary-error
masking are fixed, with every phase retained. EOF/direct status is supporting
command evidence, never whole-descendant or live preflight proof. Bundle20 and
production601 unchanged; no canonical/native/kernel/benchmark/capture or strict
dispatch. [Qualified scope](../research/{name}-preparation.md).
Actual independent preflight/command/Linux-control producers and full own source/
SDK/compiler/config/native receipts remain required; live controller stays closed.

'''+s[at:];plan.write_text(s)
 lease.verify_identity();print(json.dumps({'archive_members':len(members),'archive_sha256':audit['archive_sha256'],'free_bytes':free,'producer':final['source_sha256']['tool/native_perf_build_producer.py'],'test':final['source_sha256']['tool/test_native_perf_build_producer.py']}))
