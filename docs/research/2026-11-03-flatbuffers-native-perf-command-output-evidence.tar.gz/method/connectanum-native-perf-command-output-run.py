from pathlib import Path
import sys,subprocess,json,hashlib,shutil,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');phase=sys.argv[1];assert phase.replace('-','').isalnum();base=Path('/tmp/connectanum-native-perf-command-output-'+phase)
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();free=shutil.disk_usage(root).free;assert free>=1024**3
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert not subprocess.check_output(['git','diff','HEAD','--','packages','native'],cwd=root)
 snap=Path(str(base)+'-source');snap.mkdir();files=sorted(root.glob('tool/*native_perf*.py'));hashes={}
 for p in files:b=p.read_bytes();(snap/p.name).write_bytes(b);hashes[str(p.relative_to(root))]=sha(b)
 selected=sys.argv[2] if len(sys.argv)>2 else 'test_native_perf_build_producer.CommandOutputCompletionTests'
 command=[sys.executable,'-B','-m','unittest','-v',selected]
 receipt={'started':now(),'source_sha256':hashes,'official_exclusive_lease':True,'free_bytes':free,'scope':'finite OWN Git/Python command/output guards only; actual separate direct Popen writer, no orphan descendants or kernel/capture/benchmark','command':command}
 with Path(str(base)+'-tests.log').open('xb') as f:r=subprocess.run(command,cwd=root/'tool',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','CONNECTANUM_PERF_PRODUCER_FIXTURES':str(base)+'-fixtures'})
 lease.verify_identity();assert hashes=={str(p.relative_to(root)):sha(p.read_bytes()) for p in files}
 log=Path(str(base)+'-tests.log');receipt.update(ended=now(),exit=r.returncode,log_sha256=sha(log.read_bytes()))
 with Path(str(base)+'-tests.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({'exit':r.returncode,'log':str(log),'last':log.read_text()[-4500:]}))
