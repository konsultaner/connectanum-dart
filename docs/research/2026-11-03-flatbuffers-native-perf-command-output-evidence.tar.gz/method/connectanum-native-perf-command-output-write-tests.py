from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
addition=r'''

class CommandOutputCompletionTests(unittest.TestCase):
    """Actual finite OWN direct children; no orphan descendants or benchmark."""
    def setUp(self):
        self.fixture=ProducerTests('runTest');self.fixture.setUp()
        self.base=self.fixture.base
        self.extra=[];self.release=self.base/'release-output-writer'
        self.ready=self.base/'output-writer-ready'

    def tearDown(self):
        self.release.touch(exist_ok=True)
        statuses=[]
        for child in self.extra:
            statuses.append({'pid':child.pid,'returncode':child.wait(5),'role':'OWN separately parented command-output writer'})
        self.fixture.tearDown()
        for run in self.fixture.runs:
            statuses.append({'pid':run.child_pid,'returncode':run.process.returncode,'role':'OWN recipe direct child'})
        (self.base/'owned-output-actors.json').write_text(json.dumps({'scope':'finite OWN direct Popen actors only, not descendants/kernel/capture','actors':statuses}))

    def start_with_writer(self,mode='ok',next_command=True):
        real_popen=producer.subprocess.Popen
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:])
ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-stdout\\n');os.write(2,b'late-owned-stderr\\n')
"""
        def popen(argv,*args,**kwargs):
            if list(argv)==[sys.executable,'worker.py',mode]:
                child=real_popen([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=kwargs['stdout'],stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,close_fds=True)
                self.extra.append(child)
            return real_popen(argv,*args,**kwargs)
        with mock.patch.object(producer.subprocess,'Popen',popen):
            run=self.fixture.start((mode,),('ok',)) if next_command else self.fixture.start((mode,))
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        return run

    def test_command_output_exit_before_eof_blocks_next_and_receipt(self):
        run=self.start_with_writer()
        self.assertEqual(0,run.process.wait(2))
        self.assertIsNone(run.wait(0),'direct exit cannot finalize while an actual OWN output writer holds stdout')
        self.assertTrue(run.pending);self.assertEqual(1,len(run.records))
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'receipt-attempt.json').exists())
        self.release.touch()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertEqual(2,len(result['commands']))
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertIn(b'late-owned-stdout',raw);self.assertIn(b'late-owned-stderr',raw)
        self.assertTrue(result['commands'][0]['output_eof'])
        self.assertFalse(result['commands'][0]['whole_descendant_exit_proven'])

    def test_command_output_nonzero_waits_writer_without_next_command(self):
        run=self.start_with_writer('nonzero')
        self.assertEqual(7,run.process.wait(2))
        self.assertIsNone(run.wait(0))
        self.assertEqual(7,run.records[0]['returncode'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn(b'late-owned-stderr',(run.directory/'command-000.log').read_bytes())

    def test_command_output_large_pipe_drains_without_wait_deadlock(self):
        code="import os;data=b'A'*65536;[os.write(1,data) for _ in range(40)];os.write(2,b'END')"
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code]])
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status'])
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(40*65536+3,len(raw));self.assertEqual(digest(raw),result['commands'][0]['log_sha256'])
        self.assertTrue(result['commands'][0]['output_eof'])

    def test_command_output_eof_before_exit_keeps_child_owned(self):
        code="""import os,sys,time
from pathlib import Path
os.close(1);os.close(2)
ready,release=map(Path,sys.argv[1:]);ready.write_text('closed')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
"""
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code,str(self.ready),str(self.release)]])
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        self.assertIsNone(run.wait(.03));self.assertIsNone(run.process.returncode);self.assertTrue(run.pending)
        self.assertTrue(run.records[0]['output_eof'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertEqual('success',result['status'])
'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=root/'tool/test_native_perf_build_producer.py'
 assert 'class CommandOutputCompletionTests' not in p.read_text()
 with p.open('a') as f:f.write(addition)
 lease.verify_identity()
