from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/test_native_perf_build_producer.py')
s=r'''

    def test_command_output_partial_failure_evidence_never_retried(self):
        original_event=producer.CommandProducer._event;original_write=producer._write_json;calls=[]
        def event(run,kind,**fields):
            if kind=='command_spawned':raise OSError(13,'PRIMARY journal fault')
            return original_event(run,kind,**fields)
        def write(path,value):
            if Path(path).name=='failure.json':
                calls.append(str(path))
                if len(calls)==1:
                    with Path(path).open('xb') as f:f.write(b'PARTIAL-ORIGINAL-FAILURE')
                    raise OSError(28,'secondary failure-publication space error')
            return original_write(path,value)
        with mock.patch.object(producer.CommandProducer,'_event',event),mock.patch.object(producer,'_write_json',write):
            run=self.fixture.start(('ok',),('ok',));fd=run.output_fd;real_read=producer.os.read
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY stream fault')
                return real_read(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
            result=self.fixture.finish(run)
        self.assertEqual(1,len(calls));self.assertIn('PRIMARY',result['error'])
        self.assertEqual(b'PARTIAL-ORIGINAL-FAILURE',(run.directory/'failure.json').read_bytes())
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();assert 'def test_command_output_partial_failure_evidence' not in p.read_text()
 with p.open('a') as f:f.write(s)
 lease.verify_identity()
