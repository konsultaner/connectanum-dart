import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_new2279_saved_physical_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)





import os,stat,datetime,collections,contextlib,types,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-physical-text-v1';A=B/'2026-11-08-actions-include-great-great-great-grandchild-regular-inputs-v1/FIRST-remaining-Git-transport-and-originalActions-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration=v['execution_declaration'];save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));bindings=[];aux_bindings=[];copy_input_bindings=[];copy_output_bindings=[]
 free=shutil.disk_usage(P).free;save('fresh-artifact-storage-POINT.json',json.dumps({'free_bytes':free,'required_prospective_metadata_copy_and_newresult_floor':4*(713531338+677905776)+1073741824,'not_build_capture_or_deletion_authority':True}));assert free>=4*(713531338+677905776)+1073741824
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def snapshot(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 def readn(fd,count):
  parts=[];n=0
  while n<count:
   x=os.read(fd,count-n);assert x;parts.append(x);n+=len(x)
  return b''.join(parts)
 def read_bounded(path,size,expected,role,target=None):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};(bindings if target is None else target).append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw



 helper=declaration['auxiliary_owned_artifact_parser'];hb=read_bounded(pathlib.Path(helper['path']),7283,helper['sha256'],'auxiliary_OWNartifact_parser_ONLY',target=aux_bindings);save('auxiliary-OWNartifact-parser-binding-PRIVATE.json',json.dumps(aux_bindings,indent=2))
 bj=types.ModuleType('pr132_FIRST375_owned_metadata_json_parser');bj.__file__=helper['path'];bj.__package__='';sys.modules[bj.__name__]=bj;exec(compile(hb,helper['path'],'exec'),bj.__dict__)
 def copy_metadata(source):
  role=source['role'];path=pathlib.Path(source['path']);size=source['range'][1];expected=source['sha256'];copy=P/(role+'-bound-PRIVATE.json');b={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b)
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;outfd=None;primary=None;ob={'role':role+'_whole_PRIVATEcopy_SAMEOUTPUTFD_readback','path':str(copy),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};copy_output_bindings.append(ob);parts=[];captured=role=='original_saved_index_ONLYlocator'
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snapshot(fd)
   if size is None:
    size=b['before']['st_size'];save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'sha256_before_first_read':None},indent=2));b['declared_range']=[0,size]
   assert b['before']['st_size']==size
   outfd=os.open(copy,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);ob['open_return_fd']=outfd;ob['before'],ob['before_atime_ns_POINT_ONLY']=snapshot(outfd);count=0;h=hashlib.sha256();hc=hashlib.sha256()
   while count<size:
    block=os.read(fd,min(65536,size-count));assert block;sent=0
    while sent<len(block):
     n=os.write(outfd,block[sent:]);assert n>0;sent+=n
    os.lseek(outfd,count,os.SEEK_SET);check=readn(outfd,len(block));assert check==block;h.update(block);hc.update(check);count+=len(block)
    if captured:parts.append(block)
   b['after'],b['after_atime_ns_POINT_ONLY']=snapshot(fd);ob['after'],ob['after_atime_ns_POINT_ONLY']=snapshot(outfd);b.update(bytes=count,sha256=h.hexdigest());ob.update(bytes=count,sha256=hc.hexdigest(),ALL_bytes_BYTEWISE_equal=True);assert b['before']==b['after'] and count==size and h.hexdigest()==hc.hexdigest() and (expected is None or h.hexdigest()==expected) and ob['after']['st_size']==size
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  if outfd is not None:
   try:os.close(outfd);ob['close_return_fd']=outfd
   except BaseException as e:
    ob['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-input-binding-PRIVATE.json',json.dumps(b,indent=2));save(role+'-OUTPUT-binding-PRIVATE.json',json.dumps(ob,indent=2))
  if primary is not None:raise primary
  return {'path':str(copy),'bytes':size,'sha256':b['sha256'],'captured_small_index_raw':b''.join(parts) if captured else None}
 copies={s['role']:copy_metadata(s) for s in declaration['saved_metadata_inputs']}
 @contextlib.contextmanager
 def copyfd(row,role):
  save(role+'-exact-copy-range-BEFORE-IO.json',json.dumps({'path':row['path'],'range':[0,row['bytes']],'sha256':row['sha256'],'COPY_only_new_locator_or_raw_embedding_phase_NOTold_acquisitionproof':True},indent=2));b={'role':role,'path':row['path'],'range':[0,row['bytes']],'expected_sha256':row['sha256'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};copy_input_bindings.append(b);fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snapshot(fd);assert b['before']['st_size']==row['bytes'];yield fd,b;b['after'],b['after_atime_ns_POINT_ONLY']=snapshot(fd);assert b['before']==b['after'] and b['bytes']==row['bytes'] and b['sha256']==row['sha256']
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-input-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
 def locator(row,role,wanted):
  values={}
  with copyfd(row,role) as (fd,b):
   rr=bj.BoundedJSON(lambda n:os.read(fd,n),row['bytes'])
   for key in rr.object_keys():
    if key in wanted:values[key]=rr.value()
    else:rr.skip_value()
   rr.finish();assert rr.bytes_read==row['bytes'] and rr.digest.hexdigest()==row['sha256'];b.update(bytes=rr.bytes_read,sha256=rr.digest.hexdigest(),strict_UTF8_JSON_all_original_bytes_preserved_in_copy=True)
  return values
 original=locator(copies['original_saved_result'],'FIRST_original_result_COPY_locator',{'source_commit','run_id','job_id','ALL375_source_refs'})
 report=locator(copies['original_saved_report_ONLYlocator'],'FIRST_original_report_COPY_locator',{'observations'})
 index=json.loads(copies['original_saved_index_ONLYlocator']['captured_small_index_raw'])
 assert original['source_commit']=='5a187768a0cb8ec1caa325ecb62bba4e7996efed' and original['run_id']==42434499630 and original['job_id']==128590360371
 rows=report['observations'];manifest=[]
 for ordinal,row in enumerate(rows):
  if 'absent_at_open_only' in row:raise RuntimeError('unexpected absent saved-row vsdeclaredALL375scope/no bodyIO yet')
  matches=[entry for entry in index if entry['name']==row['saved_member'] or entry['name'].endswith('/'+row['saved_member'])];assert len(matches)==1
  entry=matches[0];assert entry['bytes']==row['bytes'] and entry['sha256']==row['sha256']
  manifest.append({'ordinal':ordinal,'original_literal_source_reference_UNALTERED':row['source_reference'],'original_saved_member_literal':row['saved_member'],'original_index_member_literal':entry['name'],'local_saved_artifact_path_ONLYlocator':str(A/'artifact-members'/entry['name']),'range':[0,row['bytes']],'sha256':row['sha256'],'all_original_report_observation_fields_PRIVATE':row})
 assert len(manifest)==375 and sum(row['range'][1] for row in manifest)==1697754 and [row['original_literal_source_reference_UNALTERED'] for row in manifest]==original['ALL375_source_refs']
 save('ALL375-local-saved-body-ranges-BEFORE-ANY-body-IO-PRIVATE.json',json.dumps(manifest,ensure_ascii=True,indent=2))
 files=[];totals=collections.Counter();words=collections.Counter();operands=collections.Counter();invalids=[];tails=[];allops=[]
 def positions(raw,needle):
  result=[];start=0
  while True:
   x=raw.find(needle,start)
   if x<0:return result
   result.append(x);start=x+1
 def alpha(c):return 65<=c<=90 or 97<=c<=122 or c==95
 def alnum(c):return alpha(c) or 48<=c<=57
 for row in manifest:
  ordinal=row['ordinal'];raw=read_bounded(pathlib.Path(row['local_saved_artifact_path_ONLYlocator']),row['range'][1],row['sha256'],'FIRST_NEW375_saved_body_physical_'+str(ordinal))
  try:
   text0=raw.decode('utf-8');utf8=True;utf8error=None
  except UnicodeDecodeError as e:
   utf8=False;text0=None;utf8error={'kind':type(e).__name__,'start':e.start,'end':e.end,'reason':e.reason};invalids.append(ordinal)
  lf=raw.count(b'\n');nul=positions(raw,b'\0');slashlf=positions(raw,b'\\\n');slashcrlf=positions(raw,b'\\\r\n');tail=bool(raw and not raw.endswith(b'\n'))
  if tail:tails.append(ordinal)
  directives=[];ops=[];segments=[];start=0;line_no=0;charbase=0
  while start<len(raw):
   at=raw.find(b'\n',start);end=len(raw) if at<0 else at+1;line=raw[start:end];content_end=len(line)-(1 if line.endswith(b'\n') else 0);decoded=line.decode('utf-8') if utf8 else None
   segments.append({'physical_segment_ordinal_zero':line_no,'file_byte_range':[start,end],'file_character_range_UTF8':[charbase,charbase+len(decoded)] if utf8 else None,'LF_terminated':line.endswith(b'\n'),'raw_physical_row_bytes_hex':line.hex(),'raw_physical_row_UTF8':decoded})
   i=0
   while i<content_end and line[i] in (32,9):i+=1
   if i<content_end and line[i]==35:
    hashpos=i;i+=1
    while i<content_end and line[i] in (32,9):i+=1
    word_start=i
    if i<content_end and alpha(line[i]):
     i+=1
     while i<content_end and alnum(line[i]):i+=1
    word_end=i;word=line[word_start:word_end].decode('ascii') if word_end>word_start else None
    def charoffset(relative):
     return charbase+len(line[:relative].decode('utf-8')) if utf8 else None
    record={'directive_row_ordinal':len(directives),'physical_segment_ordinal_zero':line_no,'file_byte_range':[start,end],'file_character_range_UTF8':[charbase,charbase+len(decoded)] if utf8 else None,'LF_terminated':line.endswith(b'\n'),'raw_line_bytes_hex':line.hex(),'raw_line_UTF8':decoded,'leading_SP_TAB_bytes_hex':line[:hashpos].hex(),'hash_file_byte_offset':start+hashpos,'hash_file_character_offset_UTF8':charoffset(hashpos),'ASCII_directive_word':word,'directive_word_bytes_hex':line[word_start:word_end].hex(),'directive_word_file_byte_range':[start+word_start,start+word_end],'directive_word_file_character_range_UTF8':[charoffset(word_start),charoffset(word_end)] if utf8 else None,'after_directive_word_physical_bytes_hex':line[word_end:content_end].hex()}
    directives.append(record);words[word if word is not None else 'NO_ASCII_WORD_UNMEASURED']+=1
    if word in ('include','include_next'):
     j=word_end
     while j<content_end and line[j] in (32,9):j+=1
     opening=line[j:j+1];closing=b'>' if opening==b'<' else b'"' if opening==b'"' else None;k=line.find(closing,j+1,content_end) if closing is not None else -1
     kind='angle_delimited_literal' if opening==b'<' and k>=0 else 'quote_delimited_literal' if opening==b'"' and k>=0 else 'unterminated_delimiter_UNPERFORMED' if closing is not None else 'macro_or_other_UNDELIMITED_UNPERFORMED'
     literal=line[j+1:k] if closing is not None and k>=0 else None
     try:literaltext=literal.decode('utf-8') if literal is not None else None
     except UnicodeDecodeError:literaltext=None
     operand={'file_ordinal':ordinal,'directive_row_ordinal':record['directive_row_ordinal'],'physical_segment_ordinal_zero':line_no,'directive_word':word,'physical_operand_kind':kind,'physical_tail_bytes_hex':line[j:content_end].hex(),'physical_tail_UTF8':line[j:content_end].decode('utf-8') if utf8 else None,'physical_tail_file_byte_range':[start+j,start+content_end],'physical_tail_file_character_range_UTF8':[charoffset(j),charoffset(content_end)] if utf8 else None,'literal_operand_bytes_hex':literal.hex() if literal is not None else None,'literal_operand_UTF8':literaltext,'literal_operand_file_byte_range':[start+j+1,start+k] if literal is not None else None,'literal_operand_file_character_range_UTF8':[charoffset(j+1),charoffset(k)] if literal is not None and utf8 else None,'opening_delimiter_byte':opening[0] if closing is not None else None,'closing_delimiter_byte':closing[0] if literal is not None else None,'comparison_performed':False,'comparison_match_count_UNPERFORMED':None,'comparison_matches_UNPERFORMED':None,'comparison_nonmatches_UNPERFORMED':None,'comparison_nonmatch_count_UNPERFORMED':None,'include_target_resolution_UNPERFORMED':None,'C_preprocessor_semantics_UNEVALUATED':None}
     ops.append(operand);allops.append(operand);operands[kind]+=1
   if utf8:charbase+=len(decoded)
   line_no+=1;start=end
  assert line_no==lf+int(tail) and (not utf8 or charbase==len(text0))
  files.append({'ordinal':ordinal,'original_literal_source_reference_UNALTERED':row['original_literal_source_reference_UNALTERED'],'original_saved_member_literal':row['original_saved_member_literal'],'original_index_member_literal':row['original_index_member_literal'],'original_source_observation_ALLfields_PRIVATE':row['all_original_report_observation_fields_PRIVATE'],'new_saved_body_binding_index':len(bindings)-1,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'LF_bytes':lf,'physical_segments':line_no,'nonempty_unterminated_tail_PRESENT':tail,'UTF8_strict':utf8,'UTF8_decode_error_UNMEASURED_if_valid':utf8error,'UTF8_character_count':len(text0) if utf8 else None,'NUL_file_byte_positions':nul,'backslash_LF_file_byte_positions':slashlf,'backslash_CRLF_file_byte_positions':slashcrlf,'ALL_original_raw_physical_segments_PRIVATE':segments,'ALL_SP_TAB_leading_hash_raw_physical_rows':directives,'ALL_include_include_next_physical_operands':ops,'C_preprocessor_semantics_UNEVALUATED':None})
  totals.update(files=1,bytes=len(raw),LF_bytes=lf,physical_segments=line_no,nonempty_unterminated_tail_files=int(tail),strict_UTF8_files=int(utf8),invalid_UTF8_files=int(not utf8),NUL_bytes=len(nul),backslash_LF=len(slashlf),backslash_CRLF=len(slashcrlf),SP_TAB_leading_hash_rows=len(directives),include_include_next_operands=len(ops))

 assert totals['files']==375 and totals['bytes']==1697754 and len(bindings)==378 and len(aux_bindings)==1 and sum(operands.values())==len(allops)==totals['include_include_next_operands']
 output=P/'ROOT-FIRST-ALL375-great-great-great-grandchild-physical-text-PRIVATE.json';outb={'role':'FIRST_whole_newresult_progressive_RAWvalueembedding_SAMEOUTPUTFD_readback','path':str(output),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outfd=os.open(output,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);outb['open_return_fd']=outfd;primary=None;outcount=0;outh=hashlib.sha256();checkh=hashlib.sha256()
 try:
  outb['before'],outb['before_atime_ns_POINT_ONLY']=snapshot(outfd)
  def emit(block):
   global outcount
   sent=0
   while sent<len(block):
    n=os.write(outfd,block[sent:]);assert n>0;sent+=n
   os.lseek(outfd,outcount,os.SEEK_SET);checked=readn(outfd,len(block));assert checked==block;outh.update(block);checkh.update(checked);outcount+=len(block)
  def jsonvalue(value):
   for part in json.JSONEncoder(ensure_ascii=True,indent=2).iterencode(value):emit(part.encode())
  emit(b'{\n')
  for key,role in [('ALL_original_report_fields_PRIVATE_UNCHANGED','original_saved_report_ONLYlocator'),('ALL_original_remaining_result_fields_PRIVATE_UNCHANGED','original_saved_result')]:
   emit(json.dumps(key).encode()+b': ')
   row=copies[role]
   with copyfd(row,'FIRST_RAWvalue_embedding_'+role) as (fd,b):
    count=0;h=hashlib.sha256()
    while count<row['bytes']:
     block=os.read(fd,min(65536,row['bytes']-count));assert block;emit(block);h.update(block);count+=len(block)
    assert count==row['bytes'] and h.hexdigest()==row['sha256'];b.update(bytes=count,sha256=h.hexdigest(),complete_original_JSON_value_BYTEEXACT_embedded=True)
   emit(b',\n')
  assert len(copy_input_bindings)==4 and len(copy_output_bindings)==3
  summary={'source_commit':'5a187768a0cb8ec1caa325ecb62bba4e7996efed','run_id':42434499630,'job_id':128590360371,'totals':dict(totals),'ALL_directive_word_counts':dict(words),'ALL_physical_operand_kind_counts':dict(operands),'invalid_UTF8_file_ordinals':invalids,'nonempty_unterminated_tail_file_ordinals':tails,'saved_metadata_bindings':3,'saved_body_bindings':375,'all_main_bindings':len(bindings),'auxiliary_OWNartifact_parser_bindings':len(aux_bindings),'metadata_copy_locator_and_RAWembedding_input_bindings':len(copy_input_bindings),'metadata_copy_SAMEOUTPUTFD_bytewise_readback_bindings':len(copy_output_bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_directory_queries':0,'candidate_executions':0,'preprocessor_compiler_include_target_resolution_UNPERFORMED':None,'all_operand_comparison_counts_lists_UNPERFORMED_NULL':True,'all_original_private_fields_stat_times_relationships_preserved':True,'whole_original_report_result_JSON_values_BYTEEXACT_embedded_PRIVATE':True,'prospective_bounded_OWNmetadata_only_NOTRAMrepair_or_schemawaiver':True,'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipe_EOF':None}
  result={'summary':summary,'execution_declaration':declaration,'ALL_saved_metadata_and_body_read_bindings_PRIVATE':bindings,'auxiliary_OWNartifact_parser_bindings_PRIVATE':aux_bindings,'ALL_metadata_copy_locator_RAWembedding_read_bindings_PRIVATE':copy_input_bindings,'ALL_metadata_copy_SAMEOUTPUTFD_readback_bindings_PRIVATE':copy_output_bindings,'ALL375_physical_file_records_PRIVATE':files,'ALL_include_operand_rows_PRIVATE':allops,'ALL_original_index_metadata_UNCHANGED':index,'qualification':'FIRSTnew375physicalrawbytes lexicalmetadata only/fullrawrows-order-duplicates-offsets retainedPRIVATE/originalFULLreport-result JSONvalues completeverbatimembedded/rawprivatecopiesunchanged/no oldparser-proof replay/no Csemantics-query-execution-admission/no fielddrop-round-normalize-schemawaiver/notRAMrepair-resourcefailure-retry-wholeprocessRAMbound/epochs-links-NULLs-ledgers unchanged/no Source20-runtimeadoption-build-cleanup.'}
  items=list(result.items())
  for i,(key,value) in enumerate(items):
   emit(json.dumps(key).encode()+b': ');jsonvalue(value);emit(b',\n' if i+1<len(items) else b'\n')
  emit(b'}\n');outb['after'],outb['after_atime_ns_POINT_ONLY']=snapshot(outfd);outb.update(bytes=outcount,sha256=outh.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback_equal=True,independent_readback_sha256=checkh.hexdigest());assert outb['after']['st_size']==outcount and outh.hexdigest()==checkh.hexdigest()
 except BaseException as e:primary=e;outb['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(outfd);outb['close_return_fd']=outfd
 except BaseException as e:
  outb['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('FIRST-newresult-output-binding-PRIVATE.json',json.dumps(outb,indent=2))
 if primary is not None:raise primary
 save('FIRST-ALL375-physical-text-summary.json',json.dumps(summary,indent=2))
 descriptor={'original_saved_result_name':output.name,'original_saved_result_bytes':outcount,'original_saved_result_sha256':outh.hexdigest(),'summary':summary}
 save('original-saved-result-descriptor.json',json.dumps(descriptor,indent=2))
 cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-physical-result.json',before);d=json.loads(before);d['actions_include_great_great_great_grandchild_physical_text_v1']={'phase':'COMPLETE_CONSUMED_FIRST_ALL375_saved_physical_text_NOT_admitted','directory':str(P),'original_saved_result':str(output),'original_saved_result_bytes':outcount,'original_saved_result_sha256':descriptor['original_saved_result_sha256'],'summary':summary,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_great_grandchild_physical_text='COMPLETE_CONSUMED_publication_pending',next='FIRSTsummary-publication NEWALL375savedphysicaltext ONLY/no oldreader-parser-model-SDKquery-Actions-acquisition-archive-numerical replay. Originalmetadata-stat-times-epochs-71dirsDEFERRED-prior6and18links unchanged/10staticNULLsimmutable/newfactsSEPARATE/allsetupUNADMITTED/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor),flush=True);lease.verify_identity()
