class AuxiliaryBufferWriteProgressTests(unittest.TestCase):
    """NEW native write/hash boundaries; finite ROOT cleanup is unit-only."""
    def _buffer_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-buffer-write-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        phase=['init'];events=[];calls={'repr':0};trigger=[None];proxies={};hashes={}
        pipes=[];closed=[];closed_numbers=set();child=[None];bound_wait=[None]
        aux=None;raised=None;result=None;guard_error=None;cleanup=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_sha=hashlib.sha256
        original_allocate=producer.AuxiliaryCommand._allocate_process
        first=OSError(5,'OWN native buffered write/hash boundary returned before fault')
        def latest():
            journal=getattr(aux,'_buffer_write_journal',None)
            return journal[-1] if type(journal) is list and journal and type(journal[-1]) is dict else {}
        class Digest:
            def __init__(self,native,role):self.native=native;self.role=role
            def hexdigest(self):return self.native.hexdigest()
            def digest(self):return self.native.digest()
            def copy(self):return self.native.copy()
            def update(self,data):
                value=self.native.update(data)
                if phase[0]=='wait':
                    row=dict(stage='hash',role=self.role,input_hex=bytes(data).hex(),native_return_is_None=value is None)
                    events.append(row)
                    if self.role=='stdout' and mode in ('hash-full','hash-partial') and trigger[0] is None:
                        trigger[0]=len(events)-1;raise first
                return value
        def hashing(*args,**kwargs):
            value=native_sha(*args,**kwargs)
            if phase[0]=='init' and not args and not kwargs and len(hashes)<2:
                role=('stdout','stderr')[len(hashes)];proxy=Digest(value,role);hashes[role]=proxy;return proxy
            return value
        class Log:
            def __init__(self,native,role):self.native=native;self.role=role
            @property
            def name(self):return self.native.name
            @property
            def closed(self):return self.native.closed
            def fileno(self):return self.native.fileno()
            def flush(self):return self.native.flush()
            def close(self):return self.native.close()
            def write(self,data):
                current=latest()
                intent=(current.get('stream') is aux.streams[self.role]
                    and current.get('log') is self and current.get('buffer') is data
                    and current.get('write_attempted') is True and current.get('write_returned') is None)
                limited=(mode in ('hash-partial','normal-partial') and self.role=='stdout')
                value=self.native.write(data[:3] if limited else data)
                if phase[0]=='wait':
                    st=os.fstat(self.native.fileno())
                    events.append(dict(stage='write',role=self.role,requested_hex=bytes(data).hex(),
                        native_prefix_limited_by_ROOT=limited,native_return=value,
                        source_intent_before_native_call=intent,ROOT_log_fd=self.native.fileno(),ROOT_log_dev=st.st_dev,ROOT_log_ino=st.st_ino))
                    if mode=='write-unknown' and self.role=='stdout' and trigger[0] is None:
                        trigger[0]=len(events)-1;raise first
                return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for role in ('stdout','stderr'):
                if path==base/('buffered.'+role):
                    proxy=Log(value,role);proxies[role]=proxy;return proxy
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            value=native_close(fd);closed_numbers.add(fd);closed.append(dict(fd=fd,raw_None=value is None));return value
        def allocate(current,record):
            value=original_allocate(current,record);child[0]=value;bound_wait[0]=value.wait;return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),
            mock.patch.object(os,'close',closing),mock.patch.object(hashlib,'sha256',hashing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                aux=producer.AuxiliaryCommand(directory=base,name='buffered',argv=[sys.executable,'-c',
                    "import os;os.write(1,b'buffer-write-out');os.write(2,b'buffer-err')"],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None)
                self.assertIs(aux,aux.start());phase[0]='wait'
                try:result=aux.wait(3)
                except BaseException as error:raised=error
                if mode in ('hash-full','hash-partial','write-unknown'):
                    # Pure DATA guard only: no second wait, native write, reset or replay.
                    try:aux._constructor_guard()
                    except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            phase[0]='report';current=latest();stream=aux.streams['stdout']
            report=dict(mode=mode,events=events,trigger_index=trigger[0],raised_is_first=raised is first,
                guard_raises_first=guard_error is first,pending=aux.pending,finished=aux.finished,
                result_is_None=result is None,source_result_is_None=aux.result is None,
                stream_quarantined=stream['quarantined'],source_bytes=stream['bytes'],source_buffer_hex=stream['buffer'].hex(),
                source_private_first=getattr(aux,'_deferred_primary_error',None) is first,
                row_present=bool(current),row_stream_is_original=current.get('stream') is stream,
                row_log_is_original=current.get('log') is proxies.get('stdout'),
                row_buffer_is_source_buffer=current.get('buffer') is stream['buffer'],
                row_buffer_hex=current['buffer'].hex() if type(current.get('buffer')) is bytes else None,
                row_write_attempted=current.get('write_attempted'),row_write_returned=current.get('write_returned'),
                row_raw_count=current.get('raw_count'),row_count_valid=current.get('count_valid'),
                row_hash_attempted=current.get('hash_attempted'),row_hash_returned=current.get('hash_returned'),
                row_hash_raw_None=current.get('hash_raw_return') is None,row_completed=current.get('completed'),
                row_error_is_first=current.get('error') is first,
                known_ROOT_created_pipe_slots=pipes,known_ROOT_native_close_returns=closed,
                scope='Real finite child/rawFileIO/nativehash; ROOT-limited prefix write simulates short count, not spontaneous kernel shortwrite; hidden ROOTreturns NOT source knowledge; no SDK/physicalEX')
            with (base/'buffer-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertEqual({'stdout','stderr'},set(hashes));self.assertEqual({'stdout','stderr'},set(proxies))
            if mode in ('normal-full','normal-partial'):
                self.assertIsNone(raised);self.assertEqual(0,result['returncode']);self.assertTrue(aux.finished)
                self.assertEqual(b'buffer-write-out',(base/'buffered.stdout').read_bytes())
                self.assertEqual(b'buffer-err',(base/'buffered.stderr').read_bytes())
                self.assertEqual(native_sha(b'buffer-write-out').hexdigest(),result['outputs']['stdout']['stream_sha256'])
                if mode=='normal-partial':
                    writes=[x for x in events if x['stage']=='write' and x['role']=='stdout']
                    self.assertGreater(len(writes),1);self.assertTrue(all(0<x['native_return']<=3 for x in writes))
            else:
                self.assertIs(first,raised)
                if mode in ('hash-full','hash-partial'):
                    # Real BEFORE defect: first hash error escaped without a permanent guard.
                    self.assertIs(first,guard_error);self.assertTrue(report['source_private_first'])
                writes=[x for x in events if x['stage']=='write' and x['role']=='stdout']
                self.assertEqual(1,len(writes));self.assertTrue(writes[0]['source_intent_before_native_call'])
                self.assertTrue(report['row_error_is_first']);self.assertTrue(aux.pending);self.assertFalse(aux.finished)
                self.assertIsNone(aux.result);self.assertEqual(0,stream['bytes'])
                self.assertEqual(b'buffer-write-out',stream['buffer']);self.assertTrue(report['row_buffer_is_source_buffer'])
                self.assertFalse(report['row_completed'])
                if mode=='write-unknown':
                    self.assertIsNone(report['row_write_returned']);self.assertIsNone(report['row_raw_count'])
                    self.assertFalse(report['row_hash_attempted'])
                else:
                    self.assertIs(report['row_write_returned'],True);self.assertIs(report['row_count_valid'],True)
                    self.assertEqual(3 if mode=='hash-partial' else len(b'buffer-write-out'),report['row_raw_count'])
                    self.assertIs(report['row_hash_attempted'],True);self.assertIsNone(report['row_hash_returned'])
                    self.assertEqual(trigger[0]+1,len(events))
        finally:
            phase[0]='unit-cleanup'
            if bound_wait[0] is not None:
                status=bound_wait[0](3);cleanup.append(dict(kind='bound_same_finite_wait',pid=child[0].pid,status=status,cached_possible=True))
                self.assertIs(type(status),int);self.assertEqual(0,status)
            for item in pipes:
                fd=item['fd']
                if fd in closed_numbers:continue
                st=os.fstat(fd);self.assertEqual((item['dev'],item['ino']),(st.st_dev,st.st_ino))
                value=native_close(fd);cleanup.append(dict(kind='known_ROOT_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
            for role,proxy in proxies.items():
                if not proxy.native.closed:
                    fd=proxy.native.fileno();a=os.fstat(fd);b=Path(proxy.name).stat()
                    self.assertEqual((a.st_dev,a.st_ino),(b.st_dev,b.st_ino));proxy.native.close()
                    cleanup.append(dict(kind='known_ROOT_rawlog_close',role=role,fd=fd,returned=True))
            with (base/'buffer-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_native_full_write_hash_return_then_fault_keeps_first_guard(self):self._buffer_case('hash-full')
    def test_native_prefix_write_hash_return_then_fault_keeps_known_count(self):self._buffer_case('hash-partial')
    def test_native_write_return_then_fault_has_original_intent(self):self._buffer_case('write-unknown')
    def test_normal_full_native_write_and_hash(self):self._buffer_case('normal-full')
    def test_normal_prefix_limited_native_writes_commit_each_count(self):self._buffer_case('normal-partial')
