import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-buffer-write-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW per-native Auxiliary buffered log write/hash progress question; source/test snapshot and narrow wait/constructor references only; no tests/model/build/SDK/native/HEAD/Git/archive/cleanup in this controller',actual_official_EX=True,producer_expected='df2588ec26064b3e9db8251740758bc28e20d3a977a318c78ec74377979e73dc',test_expected='900ff5fbb955bfd9c014afb9df532121565975ee4bef84c356ebcdab373f0dfe',prior_components_consumed_no_unchanged_replays=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='df2588ec26064b3e9db8251740758bc28e20d3a977a318c78ec74377979e73dc' and hashlib.sha256(tests).hexdigest()=='900ff5fbb955bfd9c014afb9df532121565975ee4bef84c356ebcdab373f0dfe'
 for name,data in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(data)
 source=source.decode();klass=next(x for x in ast.parse(source).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 methods={x.name:ast.get_source_segment(source,x) for x in klass.body if isinstance(x,ast.FunctionDef) and x.name in ('wait','_constructor_record','_observe_status','_wait_natural_status')}
 with (P/'selected-source.json').open('x') as f:json.dump(methods,f,indent=2)
 l.verify_identity();print(json.dumps(methods))
