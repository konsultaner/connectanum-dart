import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-buffer-write-progress-v1')
 initial=json.loads((p/'before/result.json').read_text());positive=json.loads((p/'before-positive-v2/result.json').read_text())
 assert (initial['tests'],initial['failures'],initial['errors'])==(5,3,2) and (positive['tests'],positive['failures'],positive['errors'])==(2,0,0)
 reports=[];journals=[]
 for stage in ('before','before-positive-v2'):
  for path in sorted((p/stage/'fixtures').rglob('buffer-before-cleanup.json')):
   raw=path.read_bytes();value=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=value))
  for path in sorted((p/stage/'fixtures').rglob('buffer-unit-cleanup.json')):
   raw=path.read_bytes();value=json.loads(raw);journals.append(dict(stage=stage,path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=value))
 assert len(reports)==7 and len(journals)==7
 for r in reports:
  d=r['data']
  if d['mode'] in ('hash-full','hash-partial'):
   assert d['raised_is_first'] is True and d['guard_raises_first'] is False and d['source_private_first'] is False
   assert any(x['stage']=='hash' and x['native_return_is_None'] is True for x in d['events'])
   assert d['source_bytes']==0 and d['source_buffer_hex']==b'buffer-write-out'.hex()
  elif d['mode']=='write-unknown':
   assert d['raised_is_first'] is True and d['guard_raises_first'] is True
   assert not any(x.get('source_intent_before_native_call') is True for x in d['events'])
 waits=[r for j in journals for r in j['data'] if r['kind']=='bound_same_finite_wait'];assert len(waits)==7 and all(type(x['status']) is int and x['status']==0 for x in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_epoch='df2588/900ff5',initialNEW5='3FAIL2ERROR',meaningful_hash_error_barrier_failures=2,stronger_write_intent_policy_failure=1,initial_normal2='UnitKeyError stdout.sha256 AFTERrealcommand-completion; notnormalfunctionalbreak',correctedONLYpositive2='2PASS atsame source; stdout.stream_sha256; negative3NOTreplayed',never_aggregate_as5_full_before=True,reports=reports,journals=journals,new_known_boundwait0_rows=7,cached_possible=True,no_actual_second_write_wait_retry_replay_after_hashfault=True,only_pure_guardprobe_after_error=True,root_prefix_count_notspontaneous_kernelshortwrite=True,known_parent_pipe_slots_native_close_facts_selected_NOTglobalchildFDcensus=True,all_actor_initial_FDs_delegates_instructions_NOTcomplete=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True,models_advisory_only=True,unit_notSDK_nativeworkload_physicalEX_or_RAMcause=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_buffer_write_progress']=dict(path=str(p),candidate_UNIMPLEMENTED=True,historical_before_epoch='df2588/900ff5',initialNEW5='3FAIL2ERROR',correctedONLYpositive2='2PASS',meaningful_hash_barrier_failures=2,stronger_write_intent_policy_failure=1,ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),planning_pid=47306,planning_status=0,review_pending=True,review_outer_session=74329,per_read_status_select_lease_init_generic_fullphysicalEX_runtimeadmission_INCOMPLETE=True)
 c['active_turn_status']='Aux_buffer_write_NEWbefore5_3FAIL2harnessERROR_correctedpositive2PASS_candidate_unexecuted_review_pending_source_unchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(initialNEW5='3FAIL2ERROR',correctedONLYpositive2='2PASS',hash_barrier_failures=2,intent_policy_failure=1,known_boundwait0_rows=7,not_aggregated=True,source_unchanged=True)))
