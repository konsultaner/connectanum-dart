import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-buffer-write-progress-v1');before=(p/'source-before.py').read_text();s=before;methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema.py.txt').read_text()
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='    def _deferred_error(self):';assert s.count(needle)==1;s=s.replace(needle,methods+needle,1)
 c=next(x for x in ast.parse(before).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');wait=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='wait');w=ast.get_source_segment(before,wait)
 begin=w.index("                if stream['buffer']:\n");end=w.index("                try:part=os.read",begin);old=w[begin:end]
 assert old.count("stream['log'].write")==1 and old.count("stream['hash'].update")==1
 replacement="                if stream['buffer']:\n                    self._write_buffer(stream)\n                    continue\n"
 assert s.count(old)==1;s=s.replace(old,replacement,1)
 needle='        self._deferred_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._deferred_guard()\n        self._buffer_write_guard()\n\n    def _constructor_record',1)
 needle="            deferred_state=values.get('_deferred_state');deferred_binding=values.get('_deferred_binding')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 needle='                deferred_fields_valid=deferred_ok,deferred_quarantined=deferred_quarantined,';assert s.count(needle)==1
 fields="                buffer_write_fields_valid=buffer_ok,buffer_write_quarantined=buffer_quarantined,\n                buffer_write_entries=len(buffer_journal) if type(buffer_journal) is list else None,\n                buffer_write_known_count=buffer_last.get('raw_count') if type(buffer_last.get('raw_count')) is int else None,\n                buffer_write_hash_returned=buffer_last.get('hash_returned') if type(buffer_last.get('hash_returned')) is bool else None,\n                buffer_write_completed=buffer_last.get('completed') if type(buffer_last.get('completed')) is bool else None,\n"
 s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer.py',s),('old-wait-buffer-block.txt',old),('new-wait-buffer-block.txt',replacement),('candidate-data-fields.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='df2588-before',tofile='NEW-buffer-write-progress-candidate')))
 l.verify_identity();print('private candidate UNEXECUTED; no source edit')
