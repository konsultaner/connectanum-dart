import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 D=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-late-binding-review');D.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation')
 h=json.loads((P/'late-binding-fixed-hashes.json').read_text())
 def put(name,value):
  with (D/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 s=(R/'tool/native_perf_build_producer.py').read_text();assert hashlib.sha256(s.encode()).hexdigest()==h['tool/native_perf_build_producer.py']
 c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='CommandProducer')
 selected='\n\n'.join(ast.get_source_segment(s,n) for n in c.body if isinstance(n,ast.FunctionDef) and n.name in ('_allocate_command_process','_initialize_command_process'))
 owner=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='_RetainedPreflightOwner')
 capture=ast.get_source_segment(s,next(n for n in owner.body if isinstance(n,ast.FunctionDef) and n.name=='_capture_command_history'))
 selected+='\n\n'+capture[capture.index("            refs=("):capture.index("            okay=(native")]
 context='NEW changed binding fixes only. Previous review38454 at sourcea252 is consumed, never repeat. ROOT found initializer reread global after check and cwd/env kwargs evaluated after allocator rather than before, unlike original typecall. New controls2FAIL; changed selected6PASS including actual constructor/history/output/error callers. New code captures exact initializer and tuple of ORIGINAL argv/cwd/DEVNULL/writer/STDOUT/True/environment references BEFORE allocator and passes locals through private initializer seam. Tuple does not freeze/copy mutable argv/env bodies. Original attempt.process/self.process only normalreturn; allocated ref before initIO. None-only init semantics. Module captured Popen/new/init standardbindings checked beforeallocator and beforeinitializer; no subclass/foreignfactory fallback. Bounded localchecks NOTatomic/auth/globalABA/physicalEX closure. Existing publicspawn repr/add_note/pipe/error/end/finish cleanup deliberately UNCHANGED/incomplete, maymask errors/closecopies; do not claim newly fixed. Frozen DATA requires arguments typed before equality and exact capturedreferences/normal allocatedPopen facts. primitive(value,bool,True) explicitly permits None for unknown start. No unknownFDclose/retry/cancel/GCdiscard/SDK or benchmark. Review only new concrete binding/schema defects, max1/max160words; no fullsource/liveclosure approval. ROOT verifies.\n\n'+selected
 assert len(context)<9500
 put('declaration.json',dict(source_hashes=h,scope='NEW changed argument/initializer binding, not repeated full old review',no_runtime_canonical_admission=True))
 (D/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','1300','--max-input-chars','9500','--max-response-chars','6500','--timeout','180','--save-output',str(D/'review.txt'),'--prompt','Only NEW concrete binding/schema defects in these changed hunks. Max1/max160words, no broad cleanup or physicalrelease approval.']
 put('command-before.json',dict(argv=argv,chars=len(context),sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 put('started.json',dict(pid=child.pid))
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (D/(label+'.bin')).open('xb') as out:out.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-6500:])
