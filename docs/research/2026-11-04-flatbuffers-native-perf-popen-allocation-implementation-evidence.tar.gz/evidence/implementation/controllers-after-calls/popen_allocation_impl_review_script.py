import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();D=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-design');D.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation')
 h=json.loads((P/'affected-callers-hashes.json').read_text());raw=(R/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==h['tool/native_perf_build_producer.py']
 s=raw.decode();tree=ast.parse(s);classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
 selected='\n\n'.join(ast.get_source_segment(s,n) for n in classes['CommandProducer'].body if isinstance(n,ast.FunctionDef) and n.name in ('_allocate_command_process','_initialize_command_process','_spawn'))
 capture=ast.get_source_segment(s,next(n for n in classes['_RetainedPreflightOwner'].body if isinstance(n,ast.FunctionDef) and n.name=='_capture_command_history'))
 start=capture.index("        required=")
 selected+='\n\n'+capture[start:]
 context='NEW actual retained-Popen implementation. Exact original class/resolved object.__new__/initializer captured at moduleimport, current bindings checked before allocation and before init. Distinct allocated_process strongref before initializer; old process/current assignment only normalreturn. Private earliest error before allocation/init metadata updates. Explicit None-only init result. Original public spawn repr/add_note/pipe/end/finish cleanup deliberately UNCHANGED and can mask/close; not repaired or proof of closure. No fallback/subclass/changedargv-env-stdio/SDKflags. Frozen DATA schema gains allocated actor (may be incomplete), allflagsFalse. Private _initialize_command_process seam enables actual-writer/negative-before-native old unit tests without rebinding global factory. Wholeloadedimage/originalhost/physicalcontroller/admission remainincomplete; class/type/binding not auth. Before consumed5=4FAIL1PASS actual4Python wait0; changedsource AFTER private5PASS, matching selected source tests9PASS after parse and R-path harness fixes (9previousNameError beforecapsule/actors), affected8PASS separately; not combined/canonical. Matching units real finite Python/capsule import AFTER declared init wrapper so module binding matches; class/new/factory drift negatives refuse native hook; normal and partial allocated DATA validated. Review max2 NEW concrete source-supported bugs/max220words. No uncertainFDclose/retry/kill/GCdiscard/globalauth/heapRSScause suggestions; do not call original publiccleanup a newly fixed guarantee. ROOTverifies.\n\n'+selected
 assert len(context)<17000
 def put(name,value):
  with (D/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 put('declaration.json',dict(scope='NEW current implementation selected allocator/spawn/DATA schema review only',source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],no_SDK_canonical_capture=True))
 with (D/'review-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','1700','--max-input-chars','17000','--max-response-chars','8500','--timeout','180','--save-output',str(D/'review.txt'),'--prompt','Selected NEW allocation/spawn/DATA schema review, max2 concrete bugs/max220words. Preserve original publiccleanup scope limitation; no canonical/live/physicalrelease approval.']
 put('review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (D/('review-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-8500:])
