import ast,sys,pathlib,json,hashlib,os,io,types,unittest,datetime
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation')
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def snapshot(stage):
 target=P/(stage+'-source');target.mkdir();h={}
 for rel in expected:
  b=(R/rel).read_bytes();path=target/rel;path.parent.mkdir(exist_ok=True);path.write_bytes(b);h[rel]=sha(b)
 put(P/(stage+'-hashes.json'),h);return h
def run_tests(stage,names):
 h=snapshot(stage);fixtures=P/(stage+'-fixtures');fixtures.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('receipt_resources_selected_tests','tool/test_native_perf_build_producer.py')]:
  mod=types.ModuleType(name);mod.__file__=str(R/rel);assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  raw=(P/(stage+'-source')/rel).read_bytes();assert sha(raw)==h[rel];exec(compile(raw,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
 with (P/(stage+'-tests.log')).open('x') as f:f.write(output.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
  successful=result.wasSuccessful(),scope='NEW finite OWN unit fixtures only, not canonical/admission/runtime',source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 put(P/(stage+'-tests.json'),value)
 for name in reversed(modules):sys.modules.pop(name)
 return value
