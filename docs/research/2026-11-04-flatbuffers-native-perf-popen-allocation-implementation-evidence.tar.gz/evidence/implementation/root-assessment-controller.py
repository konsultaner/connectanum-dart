import sys,pathlib,json,hashlib,ast,copy,subprocess,datetime,os,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation')
 Q=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-root-assessment');Q.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 def put(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 old=json.loads((P/'original-hashes.json').read_text());new=json.loads((P/'late-binding-fixed-hashes.json').read_text())
 assert len(new)==23 and set(new)==set(old)
 for rel,digest in new.items():assert sha((R/rel).read_bytes())==digest
 changed=[rel for rel in old if old[rel]!=new[rel]]
 assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 before=(P/'original-source/tool/native_perf_build_producer.py').read_text();after=(R/'tool/native_perf_build_producer.py').read_text()
 bt=ast.parse(before);at=ast.parse(after)
 def classes(tree):return {n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
 def methods(c):return {n.name:n for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 bc,ac=classes(bt),classes(at);assert set(bc)==set(ac)
 allowed={'CommandProducer':{'_spawn','_allocate_command_process','_initialize_command_process'},'_RetainedPreflightOwner':{'_capture_command_history'}}
 unchanged=[]
 for name in bc:
  b,a=methods(bc[name]),methods(ac[name])
  assert set(a)-set(b)==({'_allocate_command_process','_initialize_command_process'} if name=='CommandProducer' else set())
  for method in b:
   if method not in allowed.get(name,set()):
    assert ast.get_source_segment(before,b[method])==ast.get_source_segment(after,a[method]),(name,method)
    unchanged.append(name+'.'+method)
 def top(tree,text):
  return [ast.get_source_segment(text,n) for n in tree.body if not isinstance(n,ast.ClassDef)]
 oldtop=top(bt,before);newtop=top(at,after)
 newtop=[s for s in newtop if not s.startswith(('_COMMAND_POPEN_NEW=','_COMMAND_POPEN_INIT='))]
 assert oldtop==newtop
 bspawn=methods(bc['CommandProducer'])['_spawn'];aspawn=copy.deepcopy(methods(ac['CommandProducer'])['_spawn'])
 original_call=next(n for n in ast.walk(bspawn) if isinstance(n,ast.Call) and ast.unparse(n.func)=='subprocess.Popen')
 extra={'allocation_class','allocation_new','allocation_init','allocated_process','allocation_attempted','allocation_returned','initializer_attempted','initializer_returned','initializer_result','initializer_result_valid','allocation_arguments'}
 class Normalize(ast.NodeTransformer):
  def visit_Call(self,node):
   if ast.unparse(node.func)=='self._allocate_command_process':
    assert [ast.unparse(arg) for arg in node.args]==['attempt','argv','writer'] and not node.keywords
    return copy.deepcopy(original_call)
   if ast.unparse(node.func)=='dict' and any(k.arg=='cleanup_close_attempts' for k in node.keywords):
    assert extra.issubset({k.arg for k in node.keywords})
    node.keywords=[k for k in node.keywords if k.arg not in extra]
   return self.generic_visit(node)
 assert ast.dump(Normalize().visit(aspawn),include_attributes=False)==ast.dump(bspawn,include_attributes=False)
 allocation=ast.get_source_segment(after,methods(ac['CommandProducer'])['_allocate_command_process'])
 assert allocation.index("arguments=(argv,self.repo")<allocation.index('process=allocator(cls)')
 assert allocation.index("attempt['allocated_process']=process")<allocation.index('returned=self._initialize_command_process(initializer,process,arguments)')
 initializer=ast.get_source_segment(after,methods(ac['CommandProducer'])['_initialize_command_process'])
 assert '_COMMAND_POPEN_INIT' not in initializer and 'self.repo' not in initializer and 'self.environment' not in initializer
 testbefore=(P/'original-source/tool/test_native_perf_build_producer.py').read_text();testafter=(R/'tool/test_native_perf_build_producer.py').read_text()
 tb,ta=ast.parse(testbefore),ast.parse(testafter);tbc,tac=classes(tb),classes(ta)
 assert set(tac)-set(tbc)=={'AllocatedCommandProcessTests'}
 testallow={('CommandOutputCompletionTests','start_with_writer'),('CommandHistoryReviewTests','test_declared_Popen_OSError_finishes_failed_without_success_else')}
 for name in tbc:
  b,a=methods(tbc[name]),methods(tac[name]);assert set(b)==set(a)
  for method in b:
   if (name,method) not in testallow:
    assert ast.get_source_segment(testbefore,b[method])==ast.get_source_segment(testafter,a[method]),(name,method)
 assert top(tb,testbefore)==top(ta,testafter)
 names=[n for n in methods(tac['AllocatedCommandProcessTests']) if n.startswith('test_')];assert len(names)==11
 for rel in changed:
  original=(P/'original-source'/rel).read_text();current=(R/rel).read_text()
  with (Q/(pathlib.Path(rel).name+'.diff')).open('x') as f:f.write(''.join(difflib.unified_diff(original.splitlines(True),current.splitlines(True))))
 with (Q/'whole-affected-methods.txt').open('x') as f:
  for name,methodnames in allowed.items():
   for method in sorted(methodnames):f.write(name+'.'+method+'\n'+ast.get_source_segment(after,methods(ac[name])[method])+'\n\n')
  f.write(ast.get_source_segment(testafter,tac['AllocatedCommandProcessTests']))
 put(Q/'invariants.json',dict(changed_pair_only=changed,other21selected_files_byteexact=True,other_original_methods_module_nodes_byteexact=True,original_spawn_projects_back_AST_exact=True,original_public_cleanup_AST_exact=True,original_argv_env_stdio_call_AST_retained=True,argument_refs_bound_before_allocator=True,captured_initializer_passed_as_local=True,tests_original_nodes_unchanged_except_two_seams=True,new_test_methods=names,unchanged_source_methods=unchanged,root_qualification_not_model_fullsource_approval=True))
 reports={}
 for stage,counts in [('matching-tests',(9,0,9)),('matching-fixed',(9,0,0)),('affected-callers',(8,0,0)),('late-binding-before',(2,2,0)),('late-binding-fixed',(6,0,0))]:
  data=json.loads((P/(stage+'-tests.json')).read_text())
  assert (data['tests'],data['failures'],data['errors'])==counts
  reports[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],report_sha256=sha((P/(stage+'-tests.json')).read_bytes()))
 private=json.loads((P/'private-after/summary.json').read_text());assert (private['controls'],private['passed'],private['failed'])==(5,5,0)
 assert len(private['actual_four_finite_children_waited'])==4 and all(type(row['status']) is int and row['status']==0 for row in private['actual_four_finite_children_waited'])
 commands=[]
 def git(*args):
  argv=['git','-C',str(R),*args];rec=dict(argv=argv,pid=None,status=None,stdout_eof=False,stderr_eof=False);commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);rec['handle']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate();rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (Q/('post-'+str(len(commands)-1)+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  put(Q/('post-'+str(len(commands)-1)+'-return.json'),{k:v for k,v in rec.items() if k!='handle'})
  assert type(rec['status']) is int and rec['status']==0
  lease.verify_identity();return stdout.decode()
 assert git('branch','--show-current').strip()=='codex/flatbuffers-native-perf-guard'
 assert git('rev-parse','HEAD').strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 status=git('status','--porcelain');rows=status.splitlines();assert len(rows)==20 and all(row.startswith('?? tool/') for row in rows)
 assert not git('diff','HEAD','--','packages','native')
 put(Q/'post-Git.json',[{k:v for k,v in row.items() if k!='handle'} for row in commands])
 for rel,digest in new.items():assert sha((R/rel).read_bytes())==digest
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='supporting_allocated_Popen_component_ROOT_qualified_not_canonical_or_admitted',hashes=new,baseline_hashes=old,source_sha256=new['tool/native_perf_build_producer.py'],test_sha256=new['tool/test_native_perf_build_producer.py'],
  implementation='Exact module-captured Popen class/resolved standard object allocator/initializer bindings checked beforeallocation and initializer; argument references bound beforeallocator. Distinct private allocated_process before initIO. Old attempt.process/self.process only normalreturn; None-only initresult. Exact first/staged errors before reporting/metadata. Typed DATA schema retains partial allocated actor and unknown start; no inventedpid/status/waitauthority. Mutable argv/env contents not frozen/copied.',
  unchanged_scope='Other original source/modulefunctions/factories/gates/emitters/Aux/owner methods except historycapture and other21 selected files exact; original spawn cleanup AST projects back exact after removing new stagefields and restoring constructor call. All20 untracked, uncommitted, uncanonical, unadmitted, production601 unedited; helperbundle20 excludes private controllers.',
  tests=dict(consumed_BEFORE_v3='Priorpublished5=4FAIL1PASS not rerun unchanged',private_AFTER_five=dict(controls=5,passed=5,actual_four_waits=private['actual_four_finite_children_waited']),distinct_source_test_reports=reports,new_methods=11,no_combined_full_final11_or_aggregate_canonical=True),
  setup_failures='First inserted test candidate indentation AST refusal precedes actual testfilewrite/testactors. Corrected append introduces NameError R in capsule filename: selected9ERROR before capsule compile/initpatch/Popenactors; corrected source path then9PASS. No state assertions softened; two existing seams explicitly migrated to captured initializer/argument refs. Not9production defects.',
  new_late_binding_regressions='ROOT finds globalinitializer reread after check and cwd/env evaluation afterallocator unlike originaltypecall:2NEWFAIL. Capturedinitializer and beforeallocator argumentref tuple fix;6selectedPASS separately including2new+normal/history+output/errorcaller. Before argumentdrift actualfinitechild receiveswrongcwd/env; globaldrift foreignhook1 before realinit. No actual originalSDK/kernel defect claim.',
  model_advice='Qwen38454 review direct0/reaped at initiala252; P0 False because nullablebool deliberately permitsNone; no popen_returned retag. ROOT narrows general cwd/env race to beforeallocator argument semantics and adds independent globalinitializer regression. New selected binding review40076 direct1/tokenlimit1300/stdout0/stderr528 with lastprogress5170visiblechars; fullpartialfinal ABSENT/reachable/reaped, no unchangedrepeat or approval. ROOT wholeaffectedcurrentmethods/tests/AST qualified, not model fullcurrent-source approval.',
  raw_limits='ActualfiniteOWN Python/Popen and tinyGit/sixshellversionSHIMS/Fixture receipt are not SDK/version/bootstrap/compiler/native/canonical. Errorobjects and exactrefs private; savedbooleans/nativeclassnames only. Unit SAMEPopen.wait signed0 before ownFD/logcleanup, source markersFalse/null notbackfilled; originalpubliccleanup mayclosecopiesearlier. No retiredFDreclose/closedreadEOF reconstruction, no liveunitcleanup/sourceflagretag. Legacy setup/API/overwrittenhandles and fullchild/FDjournals notallsaved; do not reconstruct. Private histories/counters not heapRSSbound.',
  coordinator_limits='Full implementation/test/model controllers serialized AFTERcalls; separate percall command-before receipts/sourcebuffers and privateaftercontroller savedBEFORErun remain distinct. Lastsix inprocess tests report6PASS atfinalhash; outer exec tool result was truncated/not preserved and is UNKNOWN, never inferred0. Resume initialcheckpoint read outsidelease recorded, later source/model/test/admin work officialleased. No beforeexecutionadmission claim.',
  physical_limits='Originalpublicspawn repr/add_note/pipe/end/finish cleanup unchanged/incomplete/maymask/closecopies. AuxiliaryPopen preconstructor, historicalcontinuation/logseal/transitivegenericFD/auditpartialunknownactors/write-end/interpreter-delegate-descendant/fullindependentactualofficialEX controller remainincomplete. No type/hash/status/EOF/join/closedobject/DATA snapshot grants release/admission.',
  next='Finish physical officialEX and original-runtime/SDK/bootstrap/first3locks-hiddenconfigs/current20canonical/newsourcepackage/OWNnative-driver-staticRLIB/compiler-tool-kernel/originalhost credentials-access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage then ROOT-qualified immutableCOMPLETEadmission beforediagnosticdata. No adoption/build/strictdispatch/transplant/borrowedcohort/favorableredo/SDKchange/futurepostGOaspreproof.',
  live=dict(provider_absent=True,gate_always_raises=True,controller_closed=True,ownership=None,capture_ready=False,source_admitted=False,live_admission=False,no_SDK_native_canonical_kernel_benchmark_capture=True,no_RAMcause_repair_acceptance=True),
  free_bytes=free,build_floor_bytes=12*1024**3,build_floor_open=free>=12*1024**3,test_floor_bytes=1024**3,cause_unmeasured=True,no_cleanup=True,post_Git_NEW_purpose=True)
 put(Q/'assessment.json',assessment);put(P/'current-hashes.json',new)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['popen_allocation_implementation']=dict(cache=str(P),root_assessment=str(Q/'assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],implementation_exists=True,matching_source_unit_coverage_exists=True,canonical_pending=True,publication_pending=True,source_uncommitted_uncanonical_unadmitted=True,all_admission_flags=False,distinct_counts_only=True,never_repeat_unchanged=True)
 n['popen_allocation_next_action']['unimplemented']=False;n['popen_allocation_next_action']['historical_selected_plan_now_implemented']=True
 n['last_free_bytes']=free;v['updated_utc']=assessment['utc'];c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],new_methods=11,postGit4_signed0_BOTHEOF=True,free=free,build_open=assessment['build_floor_open'])))
