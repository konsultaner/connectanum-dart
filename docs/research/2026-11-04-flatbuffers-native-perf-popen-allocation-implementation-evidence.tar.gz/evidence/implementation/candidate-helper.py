
    def _initialize_command_process(self,process,argv,writer):
        return _COMMAND_POPEN_INIT(process,argv,cwd=self.repo,stdin=subprocess.DEVNULL,
            stdout=writer,stderr=subprocess.STDOUT,close_fds=True,env=self.environment)

    def _allocate_command_process(self,attempt,argv,writer):
        cls=_COMMAND_POPEN_TYPE;allocator=_COMMAND_POPEN_NEW;initializer=_COMMAND_POPEN_INIT
        attempt['allocation_class']=cls;attempt['allocation_new']=allocator;attempt['allocation_init']=initializer
        def check():
            if (subprocess.Popen is not cls or _COMMAND_POPEN_TYPE is not cls
                or _COMMAND_POPEN_NEW is not allocator or _COMMAND_POPEN_INIT is not initializer
                or type(cls) is not type or allocator is not object.__new__
                or type.__getattribute__(cls,'__new__') is not allocator
                or type.__getattribute__(cls,'__init__') is not initializer):
                raise ProducerError('original command constructor binding changed')
        check()
        attempt['stage']='Popen_allocate';attempt['allocation_attempted']=True
        try:process=allocator(cls)
        except BaseException as error:
            self._command_history_error(attempt,'Popen_allocate',error)
            attempt['allocation_returned']=False
            raise
        # This exact object precedes initializer I/O, including constructor failure.
        attempt['allocated_process']=process;attempt['allocation_returned']=True
        if type(process) is not cls:raise ProducerError('exact allocated command object required')
        check()
        attempt['stage']='Popen_initialize';attempt['initializer_attempted']=True
        try:returned=self._initialize_command_process(process,argv,writer)
        except BaseException as error:
            self._command_history_error(attempt,'Popen_initialize',error)
            attempt['initializer_returned']=False
            raise
        attempt['initializer_result']=returned;attempt['initializer_returned']=True
        attempt['initializer_result_valid']=returned is None
        if returned is not None:
            label=type.__dict__['__name__'].__get__(type(returned),type)
            raise TypeError("__init__() should return None, not '"+label+"'")
        return process
