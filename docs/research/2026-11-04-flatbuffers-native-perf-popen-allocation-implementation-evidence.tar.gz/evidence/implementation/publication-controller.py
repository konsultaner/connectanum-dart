import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation');a=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='36356ddd2bf277e7a01e658fa965065c8f2a9fae'
 assert git('status','--porcelain')==''
 h=json.loads((p/'current-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 assert before>=1024**3+256*1024**2
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  controller_order_qualified_per_kind=True))
 base='2026-11-04-flatbuffers-native-perf-popen-allocation-implementation';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'implementation'),(a,'design'),(final_root,'root-final'),(pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-late-binding-review'),'late-binding-review')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-implementation-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='Full implementation/test/model controllers serialized aftercalls; private-after and ROOT assessment controllers saved beforeexecution, per-call command-before receipts distinct; no execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Allocated Popen retained before initialization\n\nThe direct-command producer now pins the original Popen class, resolved standard\nobject allocator and initializer, checks their bindings, and retains the exact\nallocated object before initializer I/O. Its existing process/current assignments\nstill follow normal construction. A non-None initializer result raises TypeError.\nPrivate first/staged errors precede reporting and metadata updates. Frozen command\nDATA now includes allocation/initializer facts and retains a partially initialized\nactor without inventing pid/status/liveness or permission to call methods.\n\nConstructor argv/cwd/DEVNULL/original writer/merged stderr/close_fds/environment\nreferences are bound before allocation, matching the original type-call argument\nevaluation order. They pass to the captured initializer as local references.\nMutable argv/environment contents are neither copied nor frozen. Binding checks\nare bounded observations, not atomic/global ABA, authentication, foreign mutation\nprevention, actual-image proof or physical EX release.\n\nThe earlier meaningful BEFORE5=4FAIL/1PASS is consumed and not rerun unchanged.\nAt the initial implementation epoch a separate private AFTER5 passes, including\nfour actual finite Python children with signed0 method-wait returns. Nine matching\nsource unit cases then pass, after two administrative setup failures. The first\ngenerated test candidate fails AST parsing before testfile write or actors.\nThe appended candidate subsequently yields9NameError errors from an undefined\ncapsule source-path variable, before capsule compilation/initializer patch/new\nPopen actors. Correcting that path yields9PASS; these are not nine production\ndefects. Two legacy test seams explicitly migrate from a replaced global factory\nto the captured initializer seam, preserving their state assertions and actual\nwriter behavior. Eight affected real factory/history/Fixture callers pass\nseparately. These finite fixtures are not canonical verification.\n\nROOT then finds two introduced binding gaps: the initial helper rereads the\nglobal initializer after its check, and evaluates cwd/environment after allocation\ninstead of before it. Two new controls fail. One calls a foreign initializer hook\nbefore native initialization; the other runs a real finite child in the changed\ncwd/environment. Capturing the initializer and pre-allocation argument-reference\ntuple fixes both. Six selected cases pass separately at the final source:\nthe two new controls, normal constructor and DATA history, and affected output/\ndeclared-error callers. Eleven new source test methods exist. There is no combined\nfull-final11, aggregate pass count or current20 canonical result.\n\nQwen38454 selected review completes0 and is reaped at the initial implementation.\nIts nullable-boolean finding is false: None is intentionally allowed for unknown\nstart data, which remains quarantined. ROOT narrows its cwd/environment race\nobservation to the actual argument evaluation change and adds the independent\nglobal-initializer control. A distinct final binding review40076 reaches token\nlimit1300, returns direct1, is reaped and has stdout0/stderr528 bytes. Its last\nprogress line reports5170 visible output characters; full partial/final output\nis absent. This is reachable, not global unavailability or approval. No unchanged\nreview repeats. ROOT checks whole affected final methods/tests and AST/file\ninvariants; no model has approved the full current source or physical closure.\n\nFinal producer:\n5e88c1d716ff01947b48154884c904e5b89c994d626e1988d6db156dd808cda6.\nFinal test:\n144a184e2055dd3a7fd842f7a74eed52fa44bf1e05079de0b598c9908286334c.\nOnly this pair changes from the phase baseline. The two new methods, allocation\nstage fields/constructor call in spawn, and history DATA schema are scoped changes.\nRemoving those fields and restoring the old constructor call projects the entire\nspawn AST back exactly, including its existing cleanup. Other original methods,\nmodule functions/factories/gates/emitters, AuxiliaryCommand, original test nodes\nexcept the two explicit seam migrations, and other18 helpers+3 bins are byteexact.\nFour new post-component Git commands return signed0 with both separate streams\nat EOF: expected branch, HEAD601, twenty untracked helpers and empty tracked\nproduction diff. These facts are not native output or loaded instruction proof.\nAll20 remain uncommitted, uncanonical and unadmitted; production601 is unedited.\nPrivate controllers remain separate artifacts outside HELPERBUNDLE20.\n\nNew controls use actual finite OWN Python/Popen, private capsules and synthetic\nboundary callbacks. The normal capsule is imported after its declared initializer\nwrapper is installed; that wrapper calls the actual original initializer before\nthe injected OSError/RuntimeError/False result. Fixture callers use tiny Git repos,\nsix shell version shims and synthetic outputs, not actual SDK/version/bootstrap/\ncompiler/native builds. Private ready/release/deadline controls are not a GO token\nor original workload. Source wait markers remainFalse/null; unit signed waits\nnever backfill them. Unit cleanup checks exact known creator FDs and writers,\nnever recloses retired numbers or reconstructs EOF on closed readers. Original\nsource cleanup may close pipe copies before child exit. No unit cleanup or\nfield restoration is a live recovery, release, source retag or admission.\n\nExact objects remain private; saved reports contain native type labels and\nidentity booleans. Legacy setup/API returns, overwritten handles and complete\nchild/FD journals are not all saved and are never reconstructed. The final six\nin-process tests have a saved successful report at the final hashes; their outer\nexec tool result was truncated/not retained and stays unknown, never invented0.\nFull implementation/test/model controllers are serialized after calls; distinct\nper-call command-before receipts/source buffers and the private AFTER controller\nsaved before execution retain their actual ordering. Initial resume checkpoint\nread outside a lease is recorded; subsequent work uses official leases.\nHistories and counters are not exact heap/RSS bounds.\n\nOriginal public spawn repr/add_note/pipe/error/end/finish cleanup remains\nunchanged, incomplete and may mask errors or close copies while a partial actor\nexists. Auxiliary pre-constructor retention, historical continuation/log sealing,\ntransitive generic FDs, audit partial/unknown actors, shared journal/historical\nwriters, interpreter/delegate/descendant coverage and the independent full actual\nofficialEX controller remain incomplete. Freeze owner_emit_attempted and old\nauxiliary predicates are unchanged. Status/EOF/join/closed objects/DATA snapshots\nnever grant release or admission.\n\nOriginal PATH/SDK/bootstrap/first3locks/hiddenconfigs/current20 canonical/new source\npackage/OWN native-driver-static RLIB/compiler-tool-kernel, actual original-host\ncredentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage and\nROOT-qualified immutable COMPLETE admission remain necessary before diagnostic\ndata. No source-branch commit/push/adoption/strict dispatch, borrowed cohort/config/\nnative transplant, favorable redo, SDK change or postGO as preproof.\n\nProvider absent, live gate always raises, controller closed, ownershipNone,\nall three flagsFalse. No actual SDK/native build/canonical/kernel/broker/benchmark/\ncapture, RAM cause/repair or strict acceptance. Assessment free7.38GB remains below\n12GiB: build floor CLOSED, recheck before any build. Scoped tests retain their\nseparate1GiB floor. Cause unmeasured/no cleanup. PR132 stays OPEN DRAFT on130;\nissue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Allocated direct Popen retained; physical closure incomplete\n\nThe producer retains its exact allocated Popen before initializer I/O, pins class/allocator/initializer bindings, preserves None-only construction and captures original argument references before allocation. Typed history DATA retains partial actors without wait/release authority. Private AFTER5PASS, corrected source9PASS and affected8PASS are separate. Two new binding controls fail then6selected pass at final5e88/144a;11new methods are not a full-final/canonical result. Setup parse/NameError errors and final review token limit remain retained. Other original code/gates and production601 stay exact;20helpers remain uncommitted/uncanonical/unadmitted. Original public cleanup, transitive actors/full physical EX/original-runtime admission remain incomplete. Build floor CLOSED below12GiB; cause unmeasured/no cleanup.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-popen-allocation-implementation-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-popen-allocation-implementation-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-popen-allocation-implementation-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: retain allocated Popen ownership repair evidence')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['popen_allocation_implementation'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['popen_allocation_implementation_GitHub_descriptions_pending']=True;n['popen_allocation_implementation_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
