

class AllocatedCommandProcessTests(unittest.TestCase):
    """Actual finite OWN Python capsules; no SDK/canonical/physical closure."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='allocated-popen-',dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.capsules=[];self.states=[];self.threads=[]
    def run_case(self,mode,observe_history=False):
        import pathlib,types,time,fcntl,errno
        P=self.base
        source=Path(producer.__file__).read_bytes()
        buffers={'tool/native_perf_build_producer.py':source}
        expected={'tool/native_perf_build_producer.py':digest(source)}
        sha=digest
        real_class=producer._COMMAND_POPEN_TYPE
        real_init=type.__getattribute__(real_class,'__init__')
        real_pipe=os.pipe
        child_code=("import sys,time,json,os\nfrom pathlib import Path\n"
            "ready,gate=map(Path,sys.argv[1:])\n"
            "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_ALLOC_UNIT')}))\n"
            "deadline=time.monotonic()+8\n"
            "while not gate.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
            "raise SystemExit(0 if gate.exists() else 78)\n")
        def put(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        def typename(value):return type.__dict__['__name__'].__get__(type(value),type)
        def identity(value):return (value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink)
        base=P/mode;base.mkdir();repo=base/'repo';repo.mkdir()
        ready=base/'ready.json';gate=base/'release';sentinel=base/'FORBIDDEN-next'
        argv=[sys.executable,'-c',child_code,str(ready),str(gate)]
        next_argv=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
        injected=OSError(5,'OWN injected AFTER real Popen initialization') if mode=='oserror' else RuntimeError('OWN injected AFTER real Popen initialization')
        state=dict(op=None,child=None,child_wait=None,pipe=[],before_init=None,real_init_returned=False,
         unexpected_initializations=[],foreign_calls=0,allocator_calls=0,factory_calls=0,args=None,kwargs=None,public_error=None,returned=False)
        self.states.append(state)
        def own_pipe():
         pair=real_pipe()
         if state['op'] is not None and not state['pipe']:
          # Exact returned creator descriptors retained before metadata.
          state['pipe']=[dict(fd=fd,identity=None,access=None) for fd in pair]
          for row in state['pipe']:
           row['identity']=identity(os.fstat(row['fd']))
           row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
         return pair
        def initializer(instance,*args,**kwargs):
         state['child']=instance
         if len(args)!=1 or args[0]!=argv:
          state['unexpected_initializations'].append(dict(argument_count=len(args)))
          raise RuntimeError('UNDECLARED initializer refused BEFORE native Popen init')
         state['args']=args;state['kwargs']=kwargs
         op=state['op'];attempt=op._command_attempt
         state['before_init']=dict(allocated_reference_present=attempt.get('allocated_process') is instance,
          returned_process_present=attempt.get('process') is instance,source_process_present=op.process is instance,
          actual_instance_exact_class=type(instance) is real_class)
         real_init(instance,*args,**kwargs)
         state['real_init_returned']=True;state['child_wait']=instance.wait
         state['pid_after_real_init']=instance.pid
         if mode in ('oserror','runtime'):raise injected
         if mode=='false_return':return False
         return None
        def foreign_allocator(cls,*args,**kwargs):
         state['allocator_calls']+=1
         raise RuntimeError('foreign allocator BEFORE native allocation')
        def foreign_factory(*args,**kwargs):
         state['factory_calls']+=1
         raise RuntimeError('foreign factory BEFORE native allocation')
        def foreign_initializer(instance,*args,**kwargs):
         state['foreign_calls']+=1;state['uninitialized_instance']=instance
         raise RuntimeError('OWN foreign initializer hook BEFORE native initializer')
        name='allocated_process_capsule_'+sha(str(base).encode())[:16]
        assert name not in sys.modules
        mod=types.ModuleType(name);mod.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[name]=mod
        self.capsules.append(mod)
        outer_init=real_init if mode in ('class_drift','allocator_drift','factory_drift') else initializer
        try:
         with mock.patch.object(real_class,'__init__',new=outer_init):
          exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
          actual_event=mod.CommandProducer._event;actual_producer_init=mod.CommandProducer.__init__
          def producer_init(op,*args,**kwargs):
           state['op']=op
           return actual_producer_init(op,*args,**kwargs)
          def event(op,event_name,**fields):
           if event_name=='command_start':state['op']=op
           return actual_event(op,event_name,**fields)
          def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
          factory_init=foreign_initializer if mode=='class_drift' else outer_init
          factory_new=foreign_allocator if mode=='allocator_drift' else real_class.__new__
          factory=foreign_factory if mode=='factory_drift' else real_class
          with mock.patch.object(mod.CommandProducer,'__init__',new=producer_init), \
               mock.patch.object(mod.CommandProducer,'_source_guard',lambda op:None), \
               mock.patch.object(mod.CommandProducer,'_input_guard',lambda op:None), \
               mock.patch.object(mod.CommandProducer,'_make_archive',archive), \
               mock.patch.object(mod.CommandProducer,'_event',event), \
               mock.patch.object(real_class,'__init__',new=factory_init), \
               mock.patch.object(real_class,'__new__',new=factory_new), \
               mock.patch.object(subprocess,'Popen',new=factory), \
               mock.patch.object(os,'pipe',new=own_pipe):
           try:
            environment=dict(os.environ);environment['OWN_ALLOC_UNIT']=mode
            result=mod.start_fixture(repo=repo,source_commit='a'*40,runtime_commit='a'*40,
             run_dir=base/'run',expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
             commands=[argv,next_argv],lease_check=lambda:None,env_delta={'OWN_ALLOC_UNIT':mode})
            state['returned']=True
           except BaseException as error:state['public_error']=error
        finally:
         sys.modules.pop(name)
        op=state['op'];data={} if op is None else op.__dict__
        attempt=data.get('_command_attempt');attempt={} if type(attempt) is not dict else attempt
        child=state['child'];before_buffer=data.get('output_buffer')
        if type(before_buffer) is bytes:
         with (base/'original-buffer-before-unit-cleanup.bin').open('xb') as out:out.write(before_buffer)
        report=dict(mode=mode,source_sha256=expected['tool/native_perf_build_producer.py'],
         scope='actual finite Popen/unit constructor boundary, not observed original SDK/kernel failure',
         before_init=state['before_init'],real_init_returned=state['real_init_returned'],
         source_call_returned=state['returned'],foreign_initializer_calls=state['foreign_calls'],
         foreign_allocator_calls=state['allocator_calls'],foreign_factory_calls=state['factory_calls'],
         unexpected_initializer_calls=state['unexpected_initializations'],
         public_error_type=None if state['public_error'] is None else typename(state['public_error']),
         private_primary_is_injected=data.get('_command_history_primary_error') is injected,
         private_primary_is_public=data.get('_command_history_primary_error') is state['public_error'],
         original_attempt_retains_allocated=child is not None and attempt.get('allocated_process') is child,
         original_attempt_retains_returned=child is not None and attempt.get('process') is child,
         source_process_is_child=child is not None and data.get('process') is child,
         producer_pending=data.get('pending') if type(data.get('pending')) is bool else None,
         producer_finished=data.get('finished') if type(data.get('finished')) is bool else None,
         original_wait_observed=attempt.get('wait_observed'),
         original_wait_status=attempt.get('wait_status'),source_record_count=len(data.get('records',[])),
         source_result_is_None=data.get('result') is None,
         native_wait_status=None,native_wait_observed=False,unit_FD_cleanup=[],unit_writer_cleanup=[],
         real_class_exact=child is None or type(child) is real_class)
        if state['kwargs'] is not None:
         kw=state['kwargs']
         report['constructor_arguments']=dict(argv_exact=state['args'][0]==argv,cwd_exact=kw.get('cwd')==repo,
          stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_creator_writer=bool(state['pipe']) and kw.get('stdout')==state['pipe'][1]['fd'],
          stderr_STDOUT=kw.get('stderr')==subprocess.STDOUT,close_fds=kw.get('close_fds'),
          environment_same_object=kw.get('env') is data.get('environment'),
          declared_unit_environment=kw.get('env',{}).get('OWN_ALLOC_UNIT')==mode)
        put(base/'before-unit-cleanup.json',report)
        if observe_history:
         owner=mod._RetainedPreflightOwner('fixture','d'*32,dict(lease_check=op.lease_check))
         owner._operation=op;owner._failed=True;owner._initialized=state['returned']
         owner._pending=op.pending;owner._finished=op.finished
         synthetic=RuntimeError('SYNTHETIC failed owner for DATA validation only')
         owner._first_error_object=synthetic;owner._first_error='RuntimeError'
         owner.freeze_command_history();thread=owner._thread;self.threads.append(thread)
         view=owner.observe(2);rows=owner.command_history_observations()
         report['history_view']=dict(view);report['history_rows']=[dict(row) for row in rows]
         put(base/'history-before-unit-cleanup.json',dict(view=dict(view),rows=report['history_rows']))
         self.assertTrue(view['call_done']);self.assertTrue(view['worker_joined'])
        
        if state['real_init_returned']:
         end=time.monotonic()+3
         while not ready.exists() and time.monotonic()<end:time.sleep(.005)
         report['ready_observed']=ready.exists()
         if ready.exists():
          ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw)
          report['ready_data']=json.loads(ready_raw)
         # This is a finite fixture release directory, never a GO token.
         gate.mkdir(mode=0o700)
         status=state['child_wait'](3)
         report['native_wait_status']=status;report['native_wait_observed']=True
         assert type(status) is int
         # Exact METHOD return saved before FD/writer cleanup or source metadata.
         put(base/'actual-wait-before-FD-cleanup.json',dict(pid=child.pid,status=status,method_return_exact_int=True,
          source_wait_marker_not_reconstructed=True,not_fresh_waitsyscall_or_physicalclosure=True))
        elif child is not None and not state['unexpected_initializations']:
         # A real initializer failure is outside the injected-after-normal-return fixture.
         # Preserve EX rather than infer absent child or release on partial state.
         put(base/'unexpected-native-initializer-refusal.json',dict(known_object_retained=True,status=None,
          no_invented_zero=True,physical_EX_retained=True))
         print('unexpected native initializer failure; official EX retained for independent assessment',flush=True)
         raise AssertionError('unexpected native initializer failure; exact state retained for teardown')
        # Retired numbers never grant close authority. These are original unit creator ends.
        for row in reversed(state['pipe']):
         fd=row['fd'];entry=dict(fd=fd,role='writer' if row['access']==os.O_WRONLY else 'reader',unit_only=True)
         try:now=os.fstat(fd)
         except OSError as error:
          entry['observed_errno']=error.errno;entry['normal_close_observed']=None
          assert error.errno==errno.EBADF
         else:
          assert identity(now)==tuple(row['identity'])
          assert fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
          if row['access']==os.O_RDONLY:
           chunks=[];eof=False
           while True:
            raw=os.read(fd,65536)
            if not raw:eof=True;break
            chunks.append(raw)
           suffix=b''.join(chunks)
           with (base/'unit-reader-suffix.bin').open('xb') as out:out.write(suffix)
           entry.update(eof=eof,size=len(suffix),sha256=sha(suffix))
          entry['close_intent']=True
          result=os.close(fd);entry['normal_close_observed']=result is None
         report['unit_FD_cleanup'].append(entry)
        writers=[] if op is None else [data.get('log'),data.get('output_log'),data.get('events')]
        seen=[]
        for writer in writers:
         if writer is None or any(writer is item for item in seen):continue
         seen.append(writer);entry=dict(closed_before_unit_cleanup=writer.closed)
         if not writer.closed:
          fd=writer.fileno();held=os.fstat(fd);path=pathlib.Path(writer.name)
          assert identity(held)==identity(path.stat())
          entry['close_intent']=True;result=writer.close()
          entry.update(normal_close_return=result is None,closed_after=writer.closed)
         report['unit_writer_cleanup'].append(entry)
        report['source_wait_marker_after_unit_cleanup']=attempt.get('wait_observed')
        report['forbidden_next_absent']=not sentinel.exists()
        report['no_library_backfill_or_source_retag']=attempt.get('wait_observed') is False
        for path in sorted((base/'run').glob('*.log')):
         raw=path.read_bytes()
         with (base/(path.name+'.retained')).open('xb') as out:out.write(raw)
        if mode=='normal':
         passed=(state['returned'] and state['public_error'] is None and report['original_attempt_retains_returned']
          and report['source_process_is_child'] and report['native_wait_status']==0 and all(report['constructor_arguments'].values()))
        elif mode in ('class_drift','allocator_drift','factory_drift'):passed=state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0
        else:passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present']
          and report['original_attempt_retains_allocated'] and report['native_wait_status']==0)
        report['expected_property_passed']=passed
        report['declared_boundary_reached']=(op is not None and bool(state['pipe']) and (mode in ('class_drift','allocator_drift','factory_drift') or state['real_init_returned']))
        put(base/'result.json',report);return report
        pass
    def test_retains_before_actual_init_then_OSError(self):
        row=self.run_case('oserror')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['original_attempt_retains_returned']);self.assertTrue(row['original_attempt_retains_allocated'])
    def test_retains_before_actual_init_then_RuntimeError(self):
        row=self.run_case('runtime')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['original_attempt_retains_returned']);self.assertTrue(row['original_attempt_retains_allocated'])
    def test_non_None_initializer_return_keeps_actual_instance(self):
        row=self.run_case('false_return')
        self.assertTrue(row['expected_property_passed']);self.assertEqual('TypeError',row['public_error_type'])
        self.assertTrue(row['private_primary_is_public'])
    def test_normal_constructor_arguments_and_return_are_preserved(self):
        row=self.run_case('normal')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['before_init']['allocated_reference_present'])
        self.assertTrue(row['original_attempt_retains_returned']);self.assertTrue(row['source_process_is_child'])
    def test_initializer_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('class_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_allocator_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('allocator_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_allocator_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_factory_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('factory_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_factory_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_normal_allocated_history_remains_checked_DATA_only(self):
        row=self.run_case('normal',True);rows=row['history_rows']
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        command=next(item for item in rows if item['role']=='command')
        self.assertTrue(command['retained_allocated_process']);self.assertEqual(command['pid'],command['allocated_pid'])
        self.assertTrue(command['initializer_result_valid'])
        for item in rows:
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(item[flag])
    def test_failed_initializer_allocated_actor_remains_unknown_DATA(self):
        row=self.run_case('oserror',True);rows=row['history_rows']
        self.assertFalse(rows[0]['snapshot_checked']);self.assertTrue(rows[0]['quarantined'])
        command=next(item for item in rows if item['role']=='command')
        self.assertTrue(command['retained_allocated_process']);self.assertFalse(command['retained_process'])
        self.assertIs(type(command['allocated_pid']),int);self.assertIsNone(command['allocated_cached_returncode'])
        self.assertTrue(command['start_outcome_unknown']);self.assertFalse(command['initializer_returned'])
    def tearDown(self):
        # SAME known unit handles only. This is never live closure/recovery.
        rows=[]
        for thread in self.threads:
            returned=thread.join(3);rows.append(dict(kind='thread',join_return_is_None=returned is None,alive=thread.is_alive()))
            self.assertFalse(thread.is_alive())
        for state in self.states:
            if state.get('real_init_returned') and state.get('child_wait') is not None:
                child=state['child'];status=state['child_wait'](3)
                rows.append(dict(kind='unit_repeated_cached_or_natural_wait',pid=child.pid,status=status,not_source_witness=True))
                self.assertEqual(0,status)
        with (self.base/'unit-final-teardown.json').open('x') as out:json.dump(rows,out,indent=2)
