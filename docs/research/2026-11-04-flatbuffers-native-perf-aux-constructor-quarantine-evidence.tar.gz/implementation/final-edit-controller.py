import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();expected=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 sp=R/'tool/native_perf_build_producer.py';tp=R/'tool/test_native_perf_build_producer.py';source=sp.read_text();tests=tp.read_text()
 tree=ast.parse(source);lines=source.splitlines(True);aux=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand');node=next(n for n in aux.body if isinstance(n,ast.FunctionDef) and n.name=='_constructor_guard')
 newguard="    def _constructor_guard(self):\n        # Raise an actual retained exception instance, never instantiate field data.\n        primary=self._constructor_primary_error\n        if primary is not None:\n            chain=type.__dict__['__mro__'].__get__(type(primary),type)\n            if any(kind is BaseException for kind in chain):raise primary\n        binding=self._constructor_quarantine_binding\n        if type(binding) is not tuple or len(binding)!=7:\n            raise ProducerError('auxiliary constructor quarantine binding changed')\n        record=binding[0]\n        if (type(record) is not dict or any(type(key) is not str for key in record)\n            or record is not self._constructor_quarantine):\n            raise ProducerError('auxiliary constructor quarantine record changed')\n        first=record.get('first_error')\n        if first is not None:\n            chain=type.__dict__['__mro__'].__get__(type(first),type)\n            if any(kind is BaseException for kind in chain):raise first\n            raise ProducerError('auxiliary constructor first error changed')\n        if (primary is not None or self._constructor_quarantined is not False\n            or record.get('quarantined') is not False):\n            raise ProducerError('auxiliary constructor outcome quarantined')\n"
 candidate=''.join(lines[:node.lineno-1])+newguard+''.join(lines[node.end_lineno:])
 tt=ast.parse(tests);tl=tests.splitlines(True);cls=next(n for n in tt.body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryConstructorQuarantineTests')
 newclass=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-review-errorclass-v2/new_test_class.py').read_text()
 finaltests=''.join(tl[:cls.lineno-1])+newclass+''.join(tl[cls.end_lineno:])
 ast.parse(candidate);ast.parse(finaltests)
 def nodes(text):
  out={}
  for c in ast.parse(text).body:
   if isinstance(c,ast.ClassDef):
    for n in c.body:
     if isinstance(n,ast.FunctionDef):out[(c.name,n.name)]=ast.dump(n,include_attributes=False)
   elif isinstance(c,ast.FunctionDef):out[('',c.name)]=ast.dump(c,include_attributes=False)
  return out
 old=nodes(source);new=nodes(candidate);assert all(new[k]==v for k,v in old.items() if k!=('AuxiliaryCommand','_constructor_guard'))
 oldtests=nodes(tests);newtests=nodes(finaltests);assert all(newtests[k]==v for k,v in oldtests.items() if k!=('AuxiliaryConstructorQuarantineTests','_case'))
 baseline=P/'pre-final-source';baseline.mkdir()
 for rel,digest in expected.items():
  data=(R/rel).read_bytes();out=baseline/rel;out.parent.mkdir(exist_ok=True);out.write_bytes(data)
 for name,text in [('final-candidate-producer.py',candidate),('final-candidate-tests.py',finaltests)]:
  with (P/name).open('x') as f:f.write(text)
 with (P/'final-edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='ROOT independent first-error field hardening only: native MRO validates exception instances; bound original first used after primary scalar loss/exception-class substitution; no field-data class construction/no flag retag',new_controls='postinit-fact1PASS+dropped-primary1FAIL separately; NEWerrorclass1FAIL after one EXprebody activecompanion refusal/zeroactors, corrected restoration helper before first execution; no unchanged source control repeat',source_before=expected,no_source_commit_push_adoption=True,all_other_source_nodes_ASTunchanged=True,all_other_test_nodes_ASTunchanged_except_new_casehelper_and3methods=True),f,indent=2)
 sp.write_text(candidate);tp.write_text(finaltests)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected}
 assert all(after[k]==v for k,v in expected.items() if k not in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'])
 with (P/'final-hashes.json').open('x') as f:json.dump(after,f,indent=2)
 lease.verify_identity();print(json.dumps(dict(producer=after['tool/native_perf_build_producer.py'],tests=after['tool/test_native_perf_build_producer.py'])))
