import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1');Q=P/'review-v1'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--reasoning-budget','384','--num-predict','1600','--max-input-chars','24000','--max-response-chars','9000','--timeout','300','--save-output',str(Q/'answer.txt')]
 with (Q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_sha256=hashlib.sha256((P/'review-context.txt').read_bytes()).hexdigest(),scope='complete new source diff + selected assertions; finite fixture helper omitted from modelcoverage; ROOTownswholeaffectedsource-tests; advisory only'),f,indent=2)
 inp=(P/'review-context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (Q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(cp.read_text());n=v['native_perf_only_diagnostic_design'];h=json.loads((P/'after-edit-hashes.json').read_text())
 n['aux_constructor_quarantine_implementation']=dict(path=str(P),new_before_path='/tmp/connectanum-native-perf-aux-quarantine-new-regressions-v1',new_before_tests=5,new_before_behavioral_failures=4,new_before_errors=0,new_before_normal_PASS=1,after_selected_tests=11,after_selected_failures=0,after_selected_errors=0,review_path=str(Q),review_pid=child.pid,review_pending=True,source_uncommitted_uncanonical_unadmitted=True,not_current20canonical_or_runtime_admission=True)
 n['current_helper_source_epoch'].update(producer_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'after-edit-hashes.json'),verification_scope='NEW narrow quarantine candidate37db/7abc: eleven selected finite OWN tests PASS, final ROOT/review pending; not current20canonical')
 v['active_turn_status']='Aux_constructor_quarantine37db_test7abc_after_selected11PASS_GLM_review_active_no_SDK_native_capture';cp.write_text(json.dumps(v,indent=2)+'\n')
 stdout,stderr=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',stdout),('stderr.bin',stderr)]:
  with (Q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),both_streams_consumed=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (Q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 lease.verify_identity();print(json.dumps(result));print(stdout.decode()[:11000]);print(stderr.decode()[-1200:])
