import sys,pathlib,json,hashlib,ast,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();sp=R/'tool/native_perf_build_producer.py';tp=R/'tool/test_native_perf_build_producer.py';source=sp.read_text();tests=tp.read_text()
 assert hashlib.sha256(source.encode()).hexdigest()=='221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd'
 assert hashlib.sha256(tests.encode()).hexdigest()=='89b36b7eb786ff3e1b2496c76232ee23fb1f512863bbaa877ec6bba8f8fc49b8'
 def replace(text,before,after,count=1):
  assert text.count(before)==count,(before[:80],text.count(before));return text.replace(before,after)
 tree=ast.parse(source);aux=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 lines=source.splitlines(keepends=True);body=''.join(lines[aux.lineno-1:aux.end_lineno]);original_body=body
 body=replace(body,"        self._process_allocation_binding=(allocation,self._allocation_secondary_errors)\n",'''        self._process_allocation_binding=(allocation,self._allocation_secondary_errors)
        self._constructor_primary_error=None;self._constructor_secondary_errors=[];self._constructor_quarantined=False
        quarantine=dict(attempted=False,returned=None,quarantined=False,first_error=None,
            secondary_errors=self._constructor_secondary_errors,streams=(),allocated_process=None,
            allocation_binding=self._process_allocation_binding)
        self._constructor_quarantine=quarantine
        self._constructor_quarantine_binding=(quarantine,self._process_allocation_binding,self.streams,
            self.streams['stdout'],self.streams['stderr'],self.lease_check,self._constructor_secondary_errors)
''')
 body=replace(body,"        self.started=True;allocation=None\n","        self.started=True;allocation=None;constructor_binding=None\n")
 body=replace(body,"            self.process=self._allocate_process(allocation)\n","            constructor_binding=self._arm_constructor()\n            self.process=self._allocate_process(allocation)\n            constructor_binding[0]['returned']=True\n")
 body=replace(body,"            self._retain_allocation_error(allocation,'start',error)\n","            self._retain_allocation_error(allocation,'start',error)\n            if constructor_binding is not None:\n                self._quarantine_constructor(constructor_binding,error)\n                raise self._constructor_primary_error\n")
 body=replace(body,"    def _allocate_process(self,record):\n","    def _allocate_process(self,record):\n        constructor=self._constructor_record()\n")
 body=replace(body,"        self._allocated_process=process;record['allocated_process']=process;record['allocation_returned']=True\n","        self._allocated_process=process;record['allocated_process']=process;record['allocation_returned']=True\n        constructor['allocated_process']=process\n")
 body=replace(body,"                raise ProducerError('original auxiliary constructor binding changed')\n","                raise ProducerError('original auxiliary constructor binding changed')\n            if self._constructor_record() is not constructor:\n                raise ProducerError('original auxiliary quarantine binding changed')\n")
 parsed=ast.parse(body);ac=parsed.body[0];bodylines=body.splitlines(keepends=True)
 for node in sorted([n for n in ac.body if isinstance(n,ast.FunctionDef) and n.name in ['start','wait','_defer','_close_slot','_complete','_observe_status','_wait_natural_status']],key=lambda n:n.lineno,reverse=True):
  bodylines.insert(node.lineno,'        self._constructor_guard()\n')
 body=''.join(bodylines)+"\n    def _constructor_guard(self):\n        # A retained primary is authoritative before any mutable ledger checks.\n        if self._constructor_primary_error is not None:raise self._constructor_primary_error\n        binding=self._constructor_quarantine_binding\n        if type(binding) is not tuple or len(binding)!=7:\n            raise ProducerError('auxiliary constructor quarantine binding changed')\n        record=binding[0]\n        if (type(record) is not dict or any(type(key) is not str for key in record)\n            or record is not self._constructor_quarantine\n            or self._constructor_quarantined is not False or record.get('quarantined') is not False):\n            raise ProducerError('auxiliary constructor outcome quarantined')\n\n    def _constructor_record(self):\n        self._constructor_guard()\n        binding=self._constructor_quarantine_binding;record=binding[0]\n        required={'attempted','returned','quarantined','first_error','secondary_errors',\n            'streams','allocated_process','allocation_binding'}\n        if (set(record)!=required or type(record['attempted']) is not bool\n            or record['returned'] is not None and type(record['returned']) is not bool\n            or record['first_error'] is not None\n            or record['secondary_errors'] is not binding[6] or type(binding[6]) is not list\n            or binding[6] is not self._constructor_secondary_errors\n            or record['allocation_binding'] is not binding[1]\n            or binding[1] is not self._process_allocation_binding\n            or binding[2] is not self.streams or type(binding[2]) is not dict\n            or any(type(key) is not str for key in binding[2])\n            or binding[2].get('stdout') is not binding[3] or binding[2].get('stderr') is not binding[4]\n            or binding[5] is not self.lease_check or type(record['streams']) is not tuple):\n            raise ProducerError('auxiliary constructor quarantine record changed')\n        return record\n\n    def _arm_constructor(self):\n        record=self._constructor_record();binding=self._constructor_quarantine_binding\n        if record['attempted']:raise ProducerError('auxiliary constructor attempt is permanently terminal')\n        rows=[]\n        for role,stream in [('stdout',binding[3]),('stderr',binding[4])]:\n            if (type(stream) is not dict or any(type(key) is not str for key in stream)\n                or type(stream.get('fd')) is not int or type(stream.get('writer')) is not int\n                or stream.get('log') is None):\n                raise ProducerError('original auxiliary constructor resources required')\n            rows.append((role,stream,stream['log'],stream['fd'],stream['writer']))\n        # Original known handles are retained before constructor/initializer I/O.\n        record['streams']=tuple(rows);record['attempted']=True\n        return binding\n\n    def _quarantine_constructor(self,binding,error):\n        # No repr/str/note/equality, callback, partial-object method or I/O here.\n        if self._constructor_primary_error is None:\n            first=self._allocation_primary_error\n            self._constructor_primary_error=error if first is None else first\n        else:list.append(binding[6],('constructor',error))\n        self._constructor_quarantined=True\n        record=binding[0]\n        if type(record) is dict and all(type(key) is str for key in record):\n            record['first_error']=self._constructor_primary_error;record['quarantined']=True\n        # Preserve later binding damage as a secondary occurrence, never mask first.\n        current=self._constructor_quarantine_binding\n        if (current is not binding or record is not self._constructor_quarantine\n            or self._process_allocation_binding is not binding[1] or self.streams is not binding[2]\n            or self.lease_check is not binding[5] or self._constructor_secondary_errors is not binding[6]):\n            list.append(binding[6],('constructor_binding',ProducerError('auxiliary quarantine bindings changed')))\n"
 candidate=source[:sum(len(x) for x in lines[:aux.lineno-1])]+body+source[sum(len(x) for x in lines[:aux.end_lineno]):]
 # Extend frozen DATA validation only; existing emit/freeze/auxiliary predicates stay intact.
 needle="            start_unknown=record.get('constructor_attempted') is True and record.get('constructor_returned') is not True\n"
 extra="""            quarantine=values.get('_constructor_quarantine');quarantine_binding=values.get('_constructor_quarantine_binding')
            hold(quarantine,True);hold(quarantine_binding)
            qnative=(type(quarantine) is dict and all(type(key) is str for key in quarantine))
            q=quarantine if qnative else {}
            qkeys={'attempted','returned','quarantined','first_error','secondary_errors','streams','allocated_process','allocation_binding'}
            qoriginal=(type(quarantine_binding) is tuple and len(quarantine_binding)==7
                and quarantine_binding[0] is quarantine and quarantine_binding[1] is allocation_binding
                and quarantine_binding[2] is values.get('streams')
                and quarantine_binding[5] is owner_callback
                and type(quarantine_binding[6]) is list and quarantine_binding[6] is values.get('_constructor_secondary_errors'))
            qokay=(qnative and set(q)==qkeys and qoriginal and type(q.get('attempted')) is bool
                and primitive(q.get('returned'),bool,True) and type(q.get('quarantined')) is bool
                and q.get('quarantined') is values.get('_constructor_quarantined')
                and q.get('first_error') is values.get('_constructor_primary_error')
                and q.get('secondary_errors') is values.get('_constructor_secondary_errors')
                and q.get('allocation_binding') is allocation_binding
                and q.get('allocated_process') is allocated and type(q.get('streams')) is tuple)
            constructor_quarantined=q.get('quarantined') is True or values.get('_constructor_primary_error') is not None
            start_unknown=(record.get('constructor_attempted') is True and record.get('constructor_returned') is not True
                or q.get('attempted') is True and q.get('returned') is not True or constructor_quarantined)
"""
 candidate=replace(candidate,needle,extra)
 candidate=replace(candidate,"            okay=(aux_data is not None and 'process' in values and child_ok and allocation_ok and not start_unknown\n","            okay=(aux_data is not None and 'process' in values and child_ok and allocation_ok and qokay and not start_unknown\n")
 candidate=replace(candidate,"                start_outcome_unknown=start_unknown,allocation_fields_valid=allocation_ok,\n","                start_outcome_unknown=start_unknown,allocation_fields_valid=allocation_ok,\n                constructor_quarantined=constructor_quarantined,constructor_quarantine_fields_valid=qokay,\n")
 # Explicitly migrate only the old observations whose reporting policy changes.
 migrated=replace(tests,"         public_error_is_hook_fault=mode=='repr_hook' and state['public_error'] is hook_fault,\n","         public_error_is_hook_fault=mode=='repr_hook' and state['public_error'] is hook_fault,\n         public_error_is_injected=state['public_error'] is injected,\n")
 migrated=replace(migrated,"report['public_error_is_hook_fault'] and report['repr_hook_calls']==1","report['public_error_is_injected'] and report['repr_hook_calls']==0")
 migrated=replace(migrated,"        self.assertFalse(row['source_process_is_child']);self.assertTrue(row['source_finished'])\n","        self.assertFalse(row['source_process_is_child']);self.assertFalse(row['source_finished'])\n        self.assertTrue(row['public_error_is_injected'])\n")
 migrated=replace(migrated,"    def test_private_first_error_precedes_old_repr_hook_failure(self):\n","    def test_private_first_error_survives_without_repr_hook(self):\n")
 migrated=replace(migrated,"        self.assertTrue(row['public_error_is_hook_fault']);self.assertEqual(1,row['repr_hook_calls'])\n","        self.assertTrue(row['public_error_is_injected']);self.assertEqual(0,row['repr_hook_calls'])\n")
 newtests=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-new-regressions-v1/new_test_class.py').read_text()
 finaltests=migrated+'\n\n'+newtests
 ast.parse(candidate);ast.parse(finaltests)
 # Pin unchanged non-Aux/non-history source nodes and all unchanged helper/bin files.
 before=ast.parse(source);after=ast.parse(candidate)
 def nodes(tree):
  out={}
  for node in tree.body:
   if isinstance(node,ast.ClassDef):
    for method in node.body:
     if isinstance(method,ast.FunctionDef):out[(node.name,method.name)]=ast.dump(method,include_attributes=False)
   elif isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):out[('',node.name)]=ast.dump(node,include_attributes=False)
  return out
 old=nodes(before);now=nodes(after)
 allowed={('AuxiliaryCommand',name) for name in ['__init__','start','wait','_defer','_close_slot','_complete','_observe_status','_wait_natural_status','_allocate_process']}|{('_RetainedPreflightOwner','_capture_command_history')}
 assert all(now[key]==value for key,value in old.items() if key not in allowed)
 baseline=P/'before-source';baseline.mkdir()
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/final-unverified-hashes.json').read_text())
 for rel,digest in expected.items():
  raw=(R/rel).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest
  dest=baseline/rel;dest.parent.mkdir(exist_ok=True);dest.write_bytes(raw)
 for name,text in [('candidate-producer.py',candidate),('candidate-tests.py',finaltests)]:
  with (P/name).open('x') as f:f.write(text)
 with (P/'edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW narrow private Auxiliary constructor-uncertainty quarantine + frozen DATA annotation + explicit affected old test-policy migrations + five new real regressions',new_before_result='five tests/four behavioralFAIL/one normalPASS/noAPIERROR at221e-89b3',source_before=hashlib.sha256(source.encode()).hexdigest(),tests_before=hashlib.sha256(tests.encode()).hexdigest(),no_source_commit_push_adoption=True,unchanged_non_scope_AST=True),f,indent=2)
 sp.write_text(candidate);tp.write_text(finaltests)
 hashes={rel:hashlib.sha256((R/rel).read_bytes()).hexdigest() for rel in expected}
 assert all(hashes[rel]==digest for rel,digest in expected.items() if rel not in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'])
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(hashes,f,indent=2)
 lease.verify_identity();print(json.dumps(dict(producer=hashes['tool/native_perf_build_producer.py'],tests=hashes['tool/test_native_perf_build_producer.py'],new_methods=4,non_scope_AST_unchanged=True)))
