import sys,pathlib,json,hashlib,tarfile,io,gzip,subprocess,datetime,os,stat
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();s=os.statvfs(D);assert s.f_bavail*s.f_frsize>=268435456
 calls=[]
 def git(*args):
  child=subprocess.Popen(['git','-C',str(D),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait()
  calls.append(dict(argv=['git','-C',str(D),*args],pid=child.pid,status=status,stdout=out.decode(),stderr=err.decode(),stdout_eof=True,stderr_eof=True))
  with (P/'publication-command-progress.json').open('w') as f:json.dump(calls,f,indent=2)
  assert type(status) is int and status==0,(args,err[:300])
  return out.decode().strip()
 assert git('branch','--show-current')=='codex/flatbuffers-acceptance-status' and not git('status','--porcelain')
 previous=git('rev-parse','HEAD')
 roots=[('implementation',P),('tests-design',pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-tests-design-v1')),('new-before',pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-new-regressions-v1')),('review-controls',pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-review-controls-v1')),('errorclass-prebody-refused',pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-review-errorclass-v1')),('errorclass-control',pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-review-errorclass-v2'))]
 selected=[]
 for prefix,root in roots:
  for current,dirs,files in os.walk(root,followlinks=False):
   for name in files:
    path=pathlib.Path(current,name)
    if path.is_symlink() or path==P/'publication-command-progress.json':continue
    selected.append((prefix+'/'+str(path.relative_to(root)),path))
 selected.sort();manifest=[];payload=[]
 for name,path in selected:
  a=path.stat();data=path.read_bytes();b=path.stat()
  assert stat.S_ISREG(a.st_mode) and (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns)
  manifest.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()));payload.append((name,data))
 prefix='docs/research/2026-11-04-flatbuffers-native-perf-aux-constructor-quarantine'
 archive=D/(prefix+'-evidence.tar.gz')
 with archive.open('xb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tf:
    for name,data in payload:
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tf.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(manifest)
  for member,row in zip(members,manifest):
   assert member.isfile() and member.name==row['path'];data=tf.extractfile(member).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
 archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest();assessment=json.loads((P/'ROOT-assessment/assessment.json').read_text())
 public=dict(assessment,evidence_archive_sha256=archive_sha,selected_regular_members=len(manifest),all_selected_regular_members_BYTEEXACT=True,selected_member_manifest=manifest,final_ROOT_invariants=json.loads((P/'ROOT-final-source-test-invariants.json').read_text()),remaining_work=json.loads((P/'source-component-remaining-work.json').read_text()))
 with (D/(prefix+'-assessment.json')).open('x') as f:json.dump(public,f,indent=2);f.write('\n')
 note='''# Auxiliary constructor-uncertainty quarantine — 2026-11-04

The supporting helper now quarantines an unconfirmed Auxiliary Popen constructor outcome before invoking old repr/defer/close/complete/reporting paths. Private state/bindings precede constructor intent/lease I/O; the known original stream/log/creator-FD references are retained before Popen constructor/initializer I/O, and the exact allocated actor is retained before initializer I/O. The earliest exception object is retained before later binding metadata. Re-entry through start/wait and old internal cleanup/poll/wait/reporting helpers refuses without those operations. Normal argument/environment copies, None-only initializer semantics and the old successful behavior project back to the original AST. Frozen history gains typed quarantine DATA; emit/freeze/auxiliary predicates remain unchanged. Earlier generic log/pipe acquisition, nonconstructor failure paths and enclosing producer reporting remain outside this narrow repair.

Five genuinely NEW finite behavioral controls at221e/89b3 reproduce4FAIL/1normalPASS with no API errors: after an actual original initializer returns, the old helper can report, close original creator handles, complete, or invoke a hostile repr hook. These are distinct from consumed allocation controls. Initial source37db/7abc passes11 selected tests:5matching NEW regressions plus6affected/policy-migrated callers. Old finished=True and repr-hook expectations are explicitly migrated; unrelated original tests and source functions remain unchanged.

The independent review controls are separate. At37db/7abc, a two-test selection is1PASS/1FAIL: an actual post-initializer check retains initializer_returned/result_valid separately while the whole checked constructor return remains unknown; dropping a private primary scalar and leaving a stale False flag masks the still-bound first object on re-entry. A further new error-class substitution control fails because a foreign exception constructor runs once. One earlier attempt was refused by the official exclusive lease before any test body/actor; a separate candidate fixes unit field-restoration setup before its first execution. The final guard uses native type-MRO descriptors and identity checks to raise exception instances without constructing field-provided classes, and recovers the original first object from its bound private record. Synthetic field restoration is unit cleanup, never live recovery or source-marker retagging.

Final producer90178cb083aa4aafd0a4a2be3f7f5f514553ff69db8f5371bd8d1573cab50fff/testa35e816cc38e15d0a9796960f086a3a3750c8f547e67deceda33bb8c13b4e0a7 passes6 selected tests:3matching new review controls plus the affected original error, normal wait and actual Fixture receipt callers. The earlier11PASS and final6PASS are not combined;8new quarantine test methods exist, not a full-final8/current20canonical result. Four new source Git calls return0 with both streams: branch native-perf-guard/HEAD601/exact20untracked/production packages-native diffempty DATA only. Other18 helpers and3 bins remain byteexact; production601 is unedited and all20 helpers remain uncommitted/uncanonical/unadmitted. Private controllers are not HELPERBUNDLE20 members.

Qwen5625 planning reaches its token limit:direct1/stdout0/stderr526/last4138 visible characters/full partial final absent. It was reachable/reaped; this is not unavailability or approval, and the request is not repeated. GLM8332 selected source-diff/assertion review completes0/reaped, but omits the fixture helper and precedes the final guard hunk. ROOT rejects its unguarded-close proposal and unmeasured leak claim, initializer-fact-loss claim (the separate allocation record retains it), and flag-allowance claim (each non-False flag refuses). ROOT independently adds the two actual first-error field controls above and reviews the whole final affected source/tests plus AST/file invariants. This is qualified ROOT review, not model full-current-source approval. Two additional final-edit attempts were refused before their bodies by another active companion reservation; no bypass, source change or actor resulted from those refusals. Some earlier complete tool API returns were not systematically serialized; no omitted return is reconstructed.

New fault cases use quiet finite OWN Python Popen children with private ready/release/deadline files. Original instance/handles precede native initializer I/O; actual SAME bound waits return signed0 before known-identity unit FD/log cleanup. Precleanup views and buffers precede assertions. The native wait table covers18new-case observations, not every legacy actor. Required legacy Fixture paths use tinyGit/six shell version SHIMS/synthetic outputs and are not SDK/bootstrap/compiler/native/canonical/workloads; their setup/actor/FD/API returns are not all serialized. No global scan/kill/relaunch, missing-observation reconstruction or whole-graph release claim. Unit waits, EOF/closed objects, restored fields and frozen DATA never authorize live recovery, physical EX release or admission. Retained objects/history are not an exact heap/RSS bound or atomic/ABA/auth/foreign-write-prevention proof.

All selected new regular evidence members read back BYTEEXACT. Sources, candidates, fixtures, raw results, model advice/limits and original controllers are retained; earlier invariant controller serialization is AFTER its call, while subsequent declared controllers are saved BEFORE calls. No old archive, campaign, selected8/old allocation control or unchanged model request is rerun. No source branch commit/push/adoption/strict dispatch, SDK/native build, canonical verification, kernel/broker/benchmark/capture or RAM-cause/repair/strict-acceptance result. ProviderABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse. PR132 remains OPEN DRAFT/base#130; issue103/milestoneOPEN. Next work remains nonconstructor cleanup, historical continuation/log sealing, transitive generic FD/audit partial actors/unknown starts/shared writers/interpreter-delegate-descendants and the independent actual physical EX controller, followed by original-runtime provenance and immutable COMPLETE admission before diagnostic data.

[Assessment, complete selected manifest and exact epochs](2026-11-04-flatbuffers-native-perf-aux-constructor-quarantine-assessment.json), [new selected evidence](2026-11-04-flatbuffers-native-perf-aux-constructor-quarantine-evidence.tar.gz).
'''
 with (D/(prefix+'-preparation.md')).open('x') as f:f.write(note)
 block='''## 2026-11-04 — Narrow Auxiliary constructor quarantine implemented

Unknown constructor outcomes now retain the earliest error/original actor-log-FD bindings and refuse reporting, closure, polling/waiting or pipeline re-entry. Typed error guards avoid constructing exception classes stored in damaged fields and recover the bound original first object. Normal argument-copy/None semantics and old emit/freeze/auxiliary gates remain intact.

NEW5 behavioral controls are4FAIL/1normalPASS at221e/89b3; initial37db/7abc selection11PASS. Separate new review controls expose first-error scalar loss and foreign exception-class construction; final90178/a35e selection6PASS. Counts are not combined/full-final8/current20canonical. Qwen planning token-limit and GLM selected review are retained/ROOT-qualified; model review precedes the final hunk and omits the fixture helper. ROOT whole-final source/tests/AST checks and four new Git0/BOTH streams/branch601/20untracked/productiondiffempty qualify this narrow component only.

No SDK/native build/canonical/kernel/benchmark/capture/source adoption or strict acceptance. Generic preconstructor resource/nonconstructor cleanup, enclosing producer, historical continuation/log sealing, transitive unknown actors/writers/delegates and independent physical EX/original-runtime admission remain incomplete. Storage floors are open after the separate lossless cleanup; recheck before operations.

'''
 for name,link in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  f=D/name;text=f.read_text();i=text.index('## 2026-11-04 — Eight final-source targeted allocation')
  refs='[Implementation, exact epochs and limits]('+link+pathlib.Path(prefix+'-preparation.md').name+'), [assessment]('+link+pathlib.Path(prefix+'-assessment.json').name+'), [evidence]('+link+pathlib.Path(prefix+'-evidence.tar.gz').name+').\n\n'
  f.write_text(text[:i]+block+refs+text[i:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 git('diff','--check');git('add','--',*paths);git('commit','-m','docs: record constructor uncertainty quarantine');head=git('rev-parse','HEAD');git('push','origin','codex/flatbuffers-acceptance-status');assert not git('status','--porcelain')
 result=dict(docs_commit=head,previous_docs_commit=previous,evidence_archive_sha256=archive_sha,selected_regular_members=len(manifest),all_selected_regular_members_BYTEEXACT=True,DOCS_ONLY=True,source_branch_uncommitted_uncanonical_unadmitted=True)
 with (P/'root-readback.json').open('x') as f:json.dump(result,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(cp.read_text());n=v['native_perf_only_diagnostic_design'];n['aux_constructor_quarantine_implementation'].update(publication_pending=False,ROOT_readback=str(P/'root-readback.json'),docs_commit=head,evidence_archive_sha256=archive_sha,selected_regular_members=len(manifest));cp.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(result))
