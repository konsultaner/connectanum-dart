import sys,pathlib,ast,copy,json,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 oldtext=(P/'before-source/tool/native_perf_build_producer.py').read_text();newtext=(R/'tool/native_perf_build_producer.py').read_text()
 old=ast.parse(oldtext);new=ast.parse(newtext)
 cls=lambda t,name:next(x for x in t.body if isinstance(x,ast.ClassDef) and x.name==name)
 methods=lambda c:{x.name:x for x in c.body if isinstance(x,ast.FunctionDef)}
 before=methods(cls(old,'AuxiliaryCommand'));after=methods(cls(new,'AuxiliaryCommand'));projected={}
 def unparse(node):return ast.unparse(node)
 for name in ['_defer','_close_slot','_complete','_observe_status','_wait_natural_status','wait']:
  node=copy.deepcopy(after[name]);assert ast.unparse(node.body[0])=='self._constructor_guard()';node.body=node.body[1:]
  assert ast.dump(node,include_attributes=False)==ast.dump(before[name],include_attributes=False),name;projected[name]=True
 node=copy.deepcopy(after['__init__'])
 node.body=[s for s in node.body if not isinstance(s,ast.Assign) or not any((isinstance(t,ast.Attribute) and t.attr.startswith('_constructor_')) or isinstance(t,ast.Name) and t.id=='quarantine' for t in s.targets)]
 assert ast.dump(node,include_attributes=False)==ast.dump(before['__init__'],include_attributes=False);projected['__init__']=True
 node=copy.deepcopy(after['start']);node.body=node.body[1:]
 node.body=[s for s in node.body if not (isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='constructor_binding' for t in s.targets))]
 tr=next(s for s in node.body if isinstance(s,ast.Try))
 tr.body=[s for s in tr.body if not (isinstance(s,ast.Assign) and (any(isinstance(t,ast.Name) and t.id=='constructor_binding' for t in s.targets) or any(isinstance(t,ast.Subscript) and 'constructor_binding' in ast.unparse(t) for t in s.targets)))]
 for handler in tr.handlers:handler.body=[s for s in handler.body if not (isinstance(s,ast.If) and ast.unparse(s.test)=='constructor_binding is not None')]
 assert ast.dump(node,include_attributes=False)==ast.dump(before['start'],include_attributes=False);projected['start']=True
 node=copy.deepcopy(after['_allocate_process'])
 node.body=[s for s in node.body if not (isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='constructor' or isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='constructor' for t in s.targets))]
 check=next(s for s in node.body if isinstance(s,ast.FunctionDef) and s.name=='check')
 check.body=[s for s in check.body if not (isinstance(s,ast.If) and 'self._constructor_record()' in ast.unparse(s.test))]
 assert ast.dump(node,include_attributes=False)==ast.dump(before['_allocate_process'],include_attributes=False);projected['_allocate_process']=True
 newmethods=set(after)-set(before);assert newmethods=={'_constructor_guard','_constructor_record','_arm_constructor','_quarantine_constructor'}
 for name in newmethods:
  text=ast.unparse(after[name]);assert not any(token in text for token in ['repr(', 'str(', 'add_note(', '.poll(', '.wait(', 'os.close(', 'os.read(', 'fsync(', '.flush(', '.write(', '_write_json(']),name
 def nodes(tree):
  out={}
  for n in tree.body:
   if isinstance(n,ast.ClassDef):
    for f in n.body:
     if isinstance(f,ast.FunctionDef):out[(n.name,f.name)]=ast.dump(f,include_attributes=False)
   elif isinstance(n,ast.FunctionDef):out[('',n.name)]=ast.dump(n,include_attributes=False)
  return out
 a=nodes(old);b=nodes(new)
 allowed={('AuxiliaryCommand',n) for n in projected}|{('_RetainedPreflightOwner','_capture_command_history')}
 assert all(b[k]==v for k,v in a.items() if k not in allowed)
 ot=nodes(ast.parse((P/'before-source/tool/test_native_perf_build_producer.py').read_text()));nt=nodes(ast.parse((R/'tool/test_native_perf_build_producer.py').read_text()))
 migrated={('AllocatedAuxiliaryProcessTests',n) for n in ['run_case','test_retains_before_actual_initializer_then_OSError','test_private_first_error_precedes_old_repr_hook_failure']}
 assert all(nt[k]==v for k,v in ot.items() if k not in migrated)
 expected=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 result=dict(projected_original_Auxiliary_methods=projected,new_methods=sorted(newmethods),new_methods_no_reporting_actor_or_FD_IO=True,all_other_original_source_methods_functions_gates_emitters_AST_unchanged=True,all_other_original_test_nodes_AST_unchanged_except_explicit_migrations=True,all23_current_hashes_byteexact_to_after_edit=True,normal_constructor_argument_copy_None_semantics_project_back_exactly=True,scope='ROOT source/test AST checks; not model full-source approval/physicalclosure/canonical/admission')
 with (P/'ROOT-source-test-invariants.json').open('x') as f:json.dump(result,f,indent=2)
 lease.verify_identity();print(json.dumps(result))
