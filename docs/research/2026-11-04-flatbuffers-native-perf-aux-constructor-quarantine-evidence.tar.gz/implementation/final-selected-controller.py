import sys,pathlib,json,hashlib,os,io,types,unittest,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();expected=json.loads((P/'final-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 stat=os.statvfs(R);free=stat.f_bavail*stat.f_frsize;assert free>=1073741824
 stage=P/'final-selected';stage.mkdir();fixtures=stage/'fixtures';fixtures.mkdir();snapshot=stage/'source';snapshot.mkdir()
 for rel,digest in expected.items():
  data=(R/rel).read_bytes();dest=snapshot/rel;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data);assert hashlib.sha256(data).hexdigest()==digest
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True
 with (stage/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='three matching NEW post-review controls + three affected normal/error/Fixture callers at final guard source epoch; earlier eleven selection not replayed/combined',free_bytes=free,source_sha256=expected),f,indent=2)
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer
 exec(compile((snapshot/'tool/native_perf_build_producer.py').read_bytes(),producer.__file__,'exec'),producer.__dict__)
 tests=types.ModuleType('new_aux_quarantine_selected_tests');tests.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tests.__name__]=tests
 exec(compile((snapshot/'tool/test_native_perf_build_producer.py').read_bytes(),tests.__file__,'exec'),tests.__dict__)
 names=['AuxiliaryConstructorQuarantineTests.'+name for name in ['test_post_initializer_check_preserves_separate_return_facts','test_missing_primary_scalar_uses_bound_original_first_error','test_error_class_in_primary_field_never_constructed','test_real_initializer_error_keeps_original_handles_without_reporting','test_normal_actual_constructor_and_existing_wait_stay_successful']]
 names+=['ProducerTests.test_receipt_fixture_canonical_links_actual_logs_and_inputs']
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,tests))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (stage/'tests.log').open('x') as f:f.write(out.getvalue())
 report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=expected,details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_runtime_admission=True)
 with (stage/'result.json').open('x') as f:json.dump(report,f,indent=2)
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 lease.verify_identity();print(json.dumps({k:report[k] for k in ['tests','failures','errors']}));print(out.getvalue()[-6500:])
