import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');P=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-tests-design-v1')
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert hashlib.sha256(source.encode()).hexdigest()=='221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd'
 assert hashlib.sha256(tests.encode()).hexdigest()=='89b36b7eb786ff3e1b2496c76232ee23fb1f512863bbaa877ec6bba8f8fc49b8'
 lines=source.splitlines();tree=ast.parse(source);aux=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 names={'__init__','start','_allocation_record','_retain_allocation_error','_allocate_process','_initialize_process','observe','wait','_close_slot','_defer','_complete'}
 selected='\n\n'.join('\n'.join(lines[x.lineno-1:x.end_lineno]) for x in aux.body if isinstance(x,ast.FunctionDef) and x.name in names)
 plan=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1-root-assessment/selected-quarantine-design.json').read_text()
 context='''NEW test-planning question, not a repeat of prior architecture review.
Current final selected8 checks PASS at221e/89b3. No source behavior changed yet. Old Aux BEFORE5/privateAFTER5 and selected8 are CONSUMED; do not propose rerunning them unchanged. Need genuinely NEW real BEFORE regressions for the next private constructor-uncertainty quarantine behavior.
Existing finite helper creates actual original Popen via captured original init; init returns normally THEN injected OSError/RuntimeError/False result; quiet child writes ready metadata and waits finite private release/deadline. Root retains exact instance, actual bound SAMEwait only after real init, original two pipe pairs with fstat/access and original log objects before faults. Precleanup reports precede assertions, then finite SAMEactor signed0/knownidentity FD/log cleanup, never library marker backfill or live recovery. Existing hostile repr case expects old hook invocation; that and old finished=True observations need EXPLICIT policy migration if affected, no assertion softening/fake row seeding.
Propose at most five precise new tests with source trigger, precleanup assertions, actual native actor/FD boundary and sameactor cleanup. Focus on no repr/_defer/_complete/failure-result publication/FD-log closure after unconfirmed constructor, earliest error identity despite binding drift, retained original refs and public wait/observe reentry refusal, normal behavior unchanged. Identify any needed DATA-schema/gate integration; do not invent API names as existing. Partial Popen methods forbidden in source; unit bound known-real-init wait only for cleanup. Keep old owner_emit_attempted/freeze/aux predicates fixed, no SDK/compiler/build/GC/flags/workload/capture/admission/physicalEX claims. No new staging/failure-output I/O workaround. Earliest exact error BEFORE later fallible binding/reporting checks.
ROOT selected scope:
'''+plan+'\nCURRENT SELECTED AUXILIARY METHODS:\n'+selected
 assert len(context)<23000
 with (P/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo',str(R),'--num-predict','1400','--max-input-chars','24000','--max-response-chars','8000','--save-output',str(P/'answer.txt')]
 with (P/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),purpose='NEW precise quarantine regression planning; no source/test execution'),f,indent=2)
 inp=(P/'context.txt').open('rb')
 child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (P/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
 stdout,stderr=child.communicate();status=child.wait();inp.close()
 for name,data in [('stdout.bin',stdout),('stderr.bin',stderr)]:
  with (P/name).open('xb') as f:f.write(data)
 with (P/'finish.json').open('x') as f:json.dump(dict(pid=child.pid,status=status,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),both_streams_consumed=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(pid=child.pid,status=status,stdout_size=len(stdout),stderr_size=len(stderr))));print(stdout.decode()[:10000])
