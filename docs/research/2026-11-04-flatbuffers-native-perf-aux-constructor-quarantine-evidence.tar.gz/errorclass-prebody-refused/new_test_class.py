class AuxiliaryConstructorQuarantineTests(unittest.TestCase):
    """NEW real constructor-uncertainty behavior, not old allocation controls."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='aux-quarantine-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        self.states=[]
    def _case(self,kind):
        import types,time,errno,fcntl
        C=self.base/kind;C.mkdir();repo=C/'repo';repo.mkdir();run=C/'run';run.mkdir()
        ready=C/'ready';release=C/'release'
        code="import sys,time\nfrom pathlib import Path\nr,g=map(Path,sys.argv[1:])\nr.write_bytes(b'READY')\nd=time.monotonic()+8\nwhile not g.exists() and time.monotonic()<d:time.sleep(.005)\nraise SystemExit(0 if g.exists() else 78)\n"
        argv=[sys.executable,'-c',code,str(ready),str(release)]
        raw=Path(producer.__file__).read_bytes()
        native_class=subprocess.Popen;native_init=native_class.__init__;native_wait=native_class.wait
        state=dict(kind=kind,aux=None,child=None,real_init_returned=False,bound_wait=None,
            wait_observed=False,wait_status=None,refs=[],fault=False,calls=[],repr_calls=0,public_error=None,returned=None)
        self.states.append(state)
        first=OSError(5,'NEW finite constructor uncertainty boundary')
        hook_error=RuntimeError('NEW repr hook must never execute')
        if kind=='hostile_repr':
            class Hostile(RuntimeError):
                def __repr__(self):
                    state['repr_calls']+=1
                    raise hook_error
            first=Hostile('NEW actual init then uncertainty')
        def initializer(instance,*args,**kwargs):
            state['child']=instance
            aux=state['aux'];state['original_binding']=aux._process_allocation_binding;state['original_streams']=aux.streams
            # Retain exact creator handles BEFORE metadata and native initializer I/O.
            state['refs']=[dict(role=role,stream=stream,log=stream['log'],reader=stream['fd'],writer=stream['writer'])
                for role,stream in aux.streams.items()]
            for row in state['refs']:
                row['fd_identity']={}
                for slot in ['reader','writer']:
                    fd=row[slot];st=os.fstat(fd)
                    row['fd_identity'][slot]=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
            native_init(instance,*args,**kwargs)
            state['real_init_returned']=True
            state['bound_wait']=native_wait.__get__(instance,native_class)
            if kind=='post_init_check':
                state['fault']=True;aux._process_allocation_binding=(None,None)
                return None
            if kind=='normal':return None
            state['fault']=True
            if kind=='binding_drift':
                aux._process_allocation_binding=(None,None)
                aux.streams={}
            if kind=='invalid_result':return False
            raise first
        name='_new_constructor_quarantine_'+kind
        capsule=types.ModuleType(name);capsule.__file__=producer.__file__;sys.modules[name]=capsule
        def typename(value):return type.__dict__['__name__'].__get__(type(value),type)
        def save(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        report=None
        try:
            with mock.patch.object(native_class,'__init__',initializer):
                exec(compile(raw,capsule.__file__,'exec'),capsule.__dict__)
                Aux=capsule.AuxiliaryCommand
                aux=object.__new__(Aux);state['aux']=aux
                def lease():
                    if state['fault']:state['calls'].append('lease')
                Aux.__init__(aux,directory=run,name='quarantine',argv=argv,cwd=repo,
                    environment=dict(os.environ),lease_check=lease,stdout_max=1024,stderr_max=1024)
                from contextlib import ExitStack
                with ExitStack() as stack:
                    for method in ['_defer','_complete','_close_slot']:
                        original=getattr(Aux,method)
                        def observed(current,*a,_name=method,_original=original,**kw):
                            if state['fault']:state['calls'].append(_name)
                            return _original(current,*a,**kw)
                        stack.enter_context(mock.patch.object(Aux,method,observed))
                    for helper in ['_write_json','_file_snapshot']:
                        original=getattr(capsule,helper)
                        def observed_helper(*a,_name=helper,_original=original,**kw):
                            if state['fault']:state['calls'].append(_name)
                            return _original(*a,**kw)
                        stack.enter_context(mock.patch.object(capsule,helper,observed_helper))
                    try:state['returned']=aux.start()
                    except BaseException as error:state['public_error']=error
                    primary=aux._allocation_primary_error
                    if kind in ('guard_field_drift','guard_class_drift'):
                        state['saved_primary']=aux._constructor_primary_error;state['saved_quarantined']=aux._constructor_quarantined
                        if kind=='guard_class_drift':
                            class ForeignError(RuntimeError):
                                def __init__(self,*args,**kwargs):
                                    state['foreign_error_constructor_calls']=state.get('foreign_error_constructor_calls',0)+1
                                    super().__init__(*args,**kwargs)
                            aux._constructor_primary_error=ForeignError
                        else:aux._constructor_primary_error=None
                        aux._constructor_quarantined=False
                    calls_before_reentry=list(state['calls'])
                    reentry=None
                    if kind!='normal':
                        try:aux.wait(0)
                        except BaseException as error:reentry=error
                    binding=getattr(aux,'_constructor_quarantine_binding',None)
                    q=binding[0] if type(binding) is tuple and binding and type(binding[0]) is dict else {}
                    source_fds=[]
                    for row in state['refs']:
                        for slot in ['reader','writer']:
                            fd=row[slot]
                            try:
                                st=os.fstat(fd);ident=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
                                source_fds.append(dict(role=row['role'],slot=slot,fd=fd,open_same_identity=ident==row['fd_identity'][slot],errno=None))
                            except OSError as error:
                                source_fds.append(dict(role=row['role'],slot=slot,fd=fd,open_same_identity=False,errno=error.errno))
                    retained=q.get('streams')
                    refs_retained=(type(retained) is tuple and len(retained)==2
                        and all(any(type(item) is tuple and len(item)==5 and item[0]==row['role']
                            and item[1] is row['stream'] and item[2] is row['log']
                            and item[3]==row['reader'] and item[4]==row['writer'] for item in retained)
                            for row in state['refs']))
                    report=dict(kind=kind,source_sha256=hashlib.sha256(raw).hexdigest(),
                        actual_native_initializer_returned=state['real_init_returned'],
                        public_error_is_primary=state['public_error'] is primary and primary is not None,
                        primary_is_injected=primary is first,primary_type=None if primary is None else typename(primary),
                        repr_hook_calls=state['repr_calls'],source_calls_after_fault=calls_before_reentry,
                        source_calls_after_reentry=list(state['calls']),reentry_error_is_primary=reentry is primary and primary is not None,
                        process_is_None=aux.process is None,pending=aux.pending,finished=aux.finished,status=aux.status,
                        natural_wait_observed=aux._natural_wait_observed,natural_wait_status=aux._natural_wait_status,
                        source_fds_before_unit_cleanup=source_fds,
                        original_logs_open_before_unit_cleanup=all(not row['log'].closed for row in state['refs']),
                        private_quarantined=q.get('quarantined') is True,
                        private_first_is_primary=q.get('first_error') is primary and primary is not None,
                        original_refs_retained=refs_retained,
                        original_allocation_binding_retained=q.get('allocation_binding') is state.get('original_binding'),
                        exact_allocated_actor_retained=q.get('allocated_process') is state['child'] and state['child'] is not None,
                        no_original_SDK_kernel_native_canonical_workload=True,unit_cleanup_never_live_recovery_or_marker_backfill=True)
                    original_allocation=state['original_binding'][0]
                    report['foreign_error_constructor_calls']=state.get('foreign_error_constructor_calls',0)
                    report['initializer_returned_recorded']=original_allocation['initializer_returned']
                    report['initializer_result_valid_recorded']=original_allocation['initializer_result_valid']
                    report['constructor_returned_recorded']=original_allocation['constructor_returned']
                    report['quarantine_whole_return_recorded']=q.get('returned')
                    save(C/'source-before-unit-cleanup.json',report)
                    if kind=='guard_field_drift':
                        aux._constructor_primary_error=state['saved_primary'];aux._constructor_quarantined=state['saved_quarantined']
                        report['synthetic_unit_fields_restored_not_live_recovery']=True
                    assert state['real_init_returned'],'declared native initializer boundary not reached'
                    until=time.monotonic()+3
                    while not ready.exists() and time.monotonic()<until:time.sleep(.005)
                    assert ready.read_bytes()==b'READY'
                    release.mkdir()
                    status=state['bound_wait'](3);state['wait_observed']=True;state['wait_status']=status
                    save(C/'actual-unit-wait-before-FD-cleanup.json',dict(pid=state['child'].pid,status=status,exact_int=type(status) is int,source_wait_before=report['natural_wait_observed']))
                    assert type(status) is int and status==0
                    if kind=='normal':
                        report['normal_source_wait_return']=aux.wait(3)
            cleanup=[]
            # Known finite unit cleanup only: close creator writers BEFORE reading EOF.
            for slot in ['writer','reader']:
                for row in state['refs']:
                    fd=row[slot];entry=dict(role=row['role'],slot=slot,fd=fd)
                    try:
                        st=os.fstat(fd);identity=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
                    except OSError as error:
                        assert error.errno==errno.EBADF;entry['errno']=error.errno
                    else:
                        assert identity==row['fd_identity'][slot]
                        if slot=='reader':
                            data=[]
                            while True:
                                part=os.read(fd,65536)
                                if not part:break
                                data.append(part)
                            suffix=b''.join(data)
                            with (C/(row['role']+'-unit-suffix.bin')).open('xb') as out:out.write(suffix)
                            entry.update(EOF=True,size=len(suffix),sha256=hashlib.sha256(suffix).hexdigest())
                        entry['close_attempted']=True;returned=os.close(fd);entry['close_return_None']=returned is None
                    cleanup.append(entry)
            for row in state['refs']:
                log=row['log']
                if not log.closed:
                    st=os.fstat(log.fileno());path=Path(log.name).stat();assert (st.st_dev,st.st_ino)==(path.st_dev,path.st_ino)
                    log.close()
            report['unit_cleanup']=cleanup;report['unit_wait_status']=state['wait_status']
            report['source_wait_after_unit']=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status)
            report['run_files']=[dict(name=p.name,size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(run.iterdir()) if p.is_file()]
            save(C/'result.json',report);return report
        finally:
            sys.modules.pop(name,None)
            if state['real_init_returned'] and not state['wait_observed']:
                if not release.exists():release.mkdir()
                value=state['bound_wait'](3);state['wait_observed']=True;state['wait_status']=value
                save(C/'exceptional-known-unit-wait.json',dict(status=value,no_source_backfill=True))
    def _assert_quarantine(self,row):
        self.assertTrue(row['actual_native_initializer_returned'])
        self.assertEqual([],row['source_calls_after_fault'])
        self.assertEqual([],row['source_calls_after_reentry'])
        self.assertTrue(row['public_error_is_primary'])
        self.assertTrue(row['reentry_error_is_primary'])
        self.assertEqual(0,row['repr_hook_calls'])
        self.assertTrue(row['process_is_None']);self.assertFalse(row['pending']);self.assertFalse(row['finished'])
        self.assertIsNone(row['status']);self.assertFalse(row['natural_wait_observed']);self.assertIsNone(row['natural_wait_status'])
        self.assertTrue(all(x['open_same_identity'] for x in row['source_fds_before_unit_cleanup']))
        self.assertTrue(row['original_logs_open_before_unit_cleanup'])
        self.assertTrue(row['private_quarantined']);self.assertTrue(row['private_first_is_primary'])
        self.assertTrue(row['original_refs_retained']);self.assertTrue(row['original_allocation_binding_retained'])
        self.assertTrue(row['exact_allocated_actor_retained']);self.assertEqual(0,row['unit_wait_status'])
    def test_real_initializer_error_keeps_original_handles_without_reporting(self):
        row=self._case('error');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_hostile_repr_never_runs_and_original_error_survives(self):
        row=self._case('hostile_repr');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_invalid_None_result_keeps_earliest_TypeError_and_handles(self):
        row=self._case('invalid_result');self._assert_quarantine(row);self.assertEqual('TypeError',row['primary_type'])
    def test_binding_and_stream_drift_retains_original_roots(self):
        row=self._case('binding_drift');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_normal_actual_constructor_and_existing_wait_stay_successful(self):
        row=self._case('normal')
        self.assertTrue(row['actual_native_initializer_returned'])
        self.assertEqual(0,row['unit_wait_status'])
        self.assertEqual('success',row['normal_source_wait_return']['status'])
    def tearDown(self):
        rows=[dict(kind=s['kind'],native_init_returned=s['real_init_returned'],actual_wait_observed=s['wait_observed'],status=s['wait_status']) for s in self.states]
        with (self.base/'known-unit-actors-final.json').open('x') as out:json.dump(rows,out,indent=2)
        for row in rows:
            if row['native_init_returned']:
                self.assertTrue(row['actual_wait_observed']);self.assertEqual(0,row['status'])

    def test_post_initializer_check_preserves_separate_return_facts(self):
        row=self._case('post_init_check');self._assert_quarantine(row)
        self.assertTrue(row['initializer_returned_recorded'])
        self.assertTrue(row['initializer_result_valid_recorded'])
        self.assertIsNone(row['constructor_returned_recorded'])
        self.assertIsNone(row['quarantine_whole_return_recorded'])
    def test_missing_primary_scalar_uses_bound_original_first_error(self):
        row=self._case('guard_field_drift');self._assert_quarantine(row)
        self.assertTrue(row['primary_is_injected'])

    def test_error_class_in_primary_field_never_constructed(self):
        row=self._case('guard_class_drift')
        self.assertEqual(0,row['foreign_error_constructor_calls'])
        self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
