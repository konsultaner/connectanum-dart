import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,tempfile,subprocess
from pathlib import Path
from unittest import mock
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=Path('/tmp/connectanum-native-perf-aux-quarantine-review-errorclass-v1');R=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');A=Path('/tmp/connectanum-native-perf-aux-allocation-implementation')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 s=os.statvfs(R);free=s.f_bavail*s.f_frsize;assert free>=1073741824
 stage=P/'before';stage.mkdir();fixtures=stage/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();new=(P/'new_test_class.py').read_bytes()
 for name,b in [('producer.py',source),('existing-tests.py',tests),('new-tests.py',new)]:
  with (stage/name).open('xb') as f:f.write(b)
 with (stage/'before-execution.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),existing_test_sha256=hashlib.sha256(tests).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),selection='five NEW quarantine behavior tests only; no old selectors'),f,indent=2)
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');assert producer.__name__ not in sys.modules;sys.modules[producer.__name__]=producer
 exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 namespace=dict(producer=producer,os=os,sys=sys,json=json,hashlib=hashlib,unittest=unittest,Path=Path,tempfile=tempfile,subprocess=subprocess,mock=mock,__name__='new_aux_constructor_quarantine_behaviour')
 exec(compile(new,str(P/'new_test_class.py'),'exec'),namespace)
 cls=namespace['AuxiliaryConstructorQuarantineTests'];names=['test_error_class_in_primary_field_never_constructed']
 suite=unittest.TestSuite(cls(name) for name in names);out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (stage/'tests.log').open('x') as f:f.write(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_canonical_or_SDK_native_benchmark=True)
 with (stage/'result.json').open('x') as f:json.dump(value,f,indent=2)
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 lease.verify_identity();print(json.dumps({k:value[k] for k in ['tests','failures','errors','source_sha256','new_test_sha256']}));print(out.getvalue()[-6000:])
