import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-runtime-epoch-package-v1");D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-runtime-epoch-package'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').open('x').write(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').open('x').write(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait()
  for name,raw in [('stdout',out),('stderr',err)]:(q/f'{i}-{name}.bin').open('xb').write(raw)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/f'{i}-result.json').open('x').write(json.dumps(commands[-1]))
  assert status==0,(argv,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='8908415e4c3ddd764315d1499eba95cfe9c40b81'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 ass=json.loads((P/'ROOT-assessment.json').read_text())
 files=[f for f in sorted(P.rglob('*')) if stat.S_ISREG(f.lstat().st_mode) and not f.relative_to(P).as_posix().startswith('docs-publication/')]
 selected=dict(selected=[dict(path=f.relative_to(P).as_posix(),size=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in files],scope='NEW candidate and continuation seal only; no prior archive opened; later publication bookkeeping excluded')
 mp=P/'selected-member-manifest.json';mp.open('x').write(json.dumps(selected,indent=2)+'\n');files.append(mp)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
  for f in files:tar.add(f,arcname=f.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  ms=tar.getmembers();assert len(ms)==len(files) and len({x.name for x in ms})==len(ms) and all(x.isfile() for x in ms)
  for member in ms:assert tar.extractfile(member).read()==(P/member.name).read_bytes()
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 ass['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(files),all_selected_BYTEEXACT=True)
 (D/(prefix+'-assessment.json')).write_text(json.dumps(ass,indent=2)+'\n')
 (D/(prefix+'-preparation.md')).write_text((P/'public-preparation.md').read_text()+'\nThe evidence archive contains '+str(len(files))+' selected regular members, all verified byte-exact. Evidence archive SHA256: '+digest+'. Later publication/readback bookkeeping is outside this snapshot.\n')
 common="## 2026-11-05 — Bind the current helper candidate and freeze the prior continuation\n\nA new input candidate contains the latest twenty helper files, six actual prior continuation snapshots and two metadata files. All twenty-eight regular members read back byte-exact. It explicitly distinguishes the older helper package and leaves the retained tracked-source archive opaque. No Source/test code was edited or executed, and the runtime checkout was untouched.\n\nFresh helper observations and four Source Git results bind this candidate to HEAD 601 and the expected branch with twenty untracked helpers. These point checks establish copied bytes, not immutable original runtime, atomic ABA protection, compiled canonical validation or ownership. The frozen checkpoint and receipts precede this scope and fill no missing historical records. Qwen's prospective controller review is complete and ROOT-qualified.\n\nThe candidate grants no adoption, bootstrap, build or capture authority. Original PATH SDK/bootstrap inputs, first locks/configurations, current-helper canonical validation, own production artifacts and complete original-host actor/FD/sampler admission remain pending. RAM repair, final strict 48/50 and clean final CI remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text();(q/(path.name+'-before.txt')).open('x').write(old);assert common.splitlines()[0] not in old
  name='2026-11-05-flatbuffers-native-perf-runtime-epoch-package'
  block=common+'[Declaration and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05');new=old[:pos]+block+old[pos:];path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 assert {x[3:] for x in git(['status','--porcelain','--untracked-files=all']).decode().splitlines()}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: seal current helper input candidate and continuation'])
 head=git(['rev-parse','HEAD']).decode().strip();git(['push','origin','codex/flatbuffers-acceptance-status']);assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(files),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 (P/'publication-readback.json').open('x').write(json.dumps(receipt,indent=2)+'\n')
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']
 n['runtime_epoch_package']=dict(directory=str(P),package_receipt=str(P/'package-receipt.json'),candidate_archive_sha256=ass['package_receipt']['archive']['sha256'],candidate_regular_members=28,ROOT_assessment=str(P/'ROOT-assessment.json'),publication=receipt,Source_test_edits=False,new_tests_run=0,current20_packaged_not_compiledcanonical=True,docs_pending=False,descriptions_pending=True,automation_pending=True,full_admission=False)
 n.setdefault('prior_helper_source_epoch_records',[]).append(n.get('current_helper_source_epoch'))
 n['current_helper_source_epoch']=dict(producer_sha256='2b74548180b01feb2c7684c52ba63dca578b7c40ed8badc60f9c6ded373fe70a',test_sha256='6594f3964f06a32fb7ac6bf880eb510642ac9b73e10e2cc4f19bfd9323270636',current20_candidate_receipt=str(P/'package-receipt.json'),source_HEAD_DATA='601108ea6216464bd00ae29c16cfaf0a59c71db6',branch_DATA='codex/flatbuffers-native-perf-guard',all20_untracked_uncommitted_uncanonical_unadmitted=True,validation_scope='No new tests; last4 scopedPASS are consumed finish-primary-kind epoch DATA, not current20 canonical',new_scope_Source_test_edits=False)
 constraints=n['next'][n['next'].index('\nNeed '):];n['next']="Next NEW declared original-PATH bootstrap/input-generation and actor-ownership preflight must identify exact wrapper/updater/SDK inputs, first3locks and hidden-config generation, own tracked601 provenance plus current20 candidate, all actual command/interpreter/delegate/descendant actors and FD/EX obligations BEFORE any possibly mutating SDK/bootstrap/build call. The current candidate is UNADMITTED/incomplete for execution: never overlay/adopt it or reuse the old helper20 package as current. No Source edit without actual meaningful BEFORE fail; no build/capture/strict dispatch without explicit qualified preflight/COMPLETE admission. New candidate28 members=20helpers+6actual prior-continuation files+declaration+manifest, archive717a1cc26d8c2d10528b360155621b524343348c56c2c99030fd0259100deb8f/814067B. All28readbackBYTEEXACT; current20 two regular nofollow reads same observed identities/bytes at2b7454/6594f3, fresh SourceGit4zeroBOTH/HEAD601 ownbranch20untracked-prodempty DATA only. Historical601 sourcearchive reference opaque/unopened; oldhelperpackage notcurrent. Frozencheckpoint/state/plan/3receipts are actual prior filebytes, NOTcurrentstate/omission reconstruction. Pointstats/hash notatomicABA/origin-auth/physicalEX/all-hiddenabsence/compiledcanonical/immutableoriginalruntime. Qwen51717 natural0/5098out652err/BOTH EOF/fullanswer ROOTqualified, rejects missingHEAD-branch/readidentity/countonly/tarextractclaims; v1scratchunexecuted/v2firstacquisition literal20+artifactcaps/CLOEXEC NOTproductionRAMbound. No newtests/Source-test edits/SDK-build-native-kernel-broker-benchmarkcapture-adoption-Sourcecommitpush-strictdispatch or oldtests/models/campaigns/archiveaudits/cleanup replay. Pending obligation ledger/providerABSENT/controllerCLOSED/ownershipNone/flagsFalse. RAMcause-repair-finalstrict48/50-cleanCI remain incomplete."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Runtime_epoch_package28_BYTEEXACT_docs_pushed_admin_pending');cp.write_text(json.dumps(c,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(docs_commit=head,evidence_archive_sha256=digest,evidence_members=len(files),candidate_members=28,admission=False)))
