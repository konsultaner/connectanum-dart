import sys,pathlib,json,subprocess,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-runtime-epoch-package-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();r=P/'planning-review';r.mkdir()
 context='Review NEW UNEXECUTED packaging controller, max3 material issues <=220words. It must only freeze latest20 untracked helper file bytes and6 previous continuation records, not run/import/adopt code or imply complete runtime admission. Historical archive is reference only/never reopened. No source fix without actual before-fail. Point stat/hash is explicitly not atomic ABA/auth. No SDK, tests, builds, capture, runtime checkout, cleanup, replay or source commits. Check candidate completeness, retention on error and false admission claims. An exception makes namespace terminal; no recovery. Existing namespaces never reused. Models advisory; ROOT verifies.\n'+(P/'declaration.json').read_text()+'\n'+(P/'capture-controller-v1.py').read_text()
 assert len(context)<24000;(r/'context.txt').open('x').write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--model','qwen3.8:27b','--stdin','--num-predict','1800','--timeout','180','--max-input-chars','24000','--max-response-chars','12000','--save-output',str(r/'answer.txt')]
 (r/'command-before.json').open('x').write(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),pid=None,Popen_attempted=True)))
 inp=(r/'context.txt').open('rb');p=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;(r/'start.json').open('x').write(json.dumps(dict(pid=p.pid)))
 out,err=p.communicate();status=wait();inp.close()
 for name,raw in [('stdout',out),('stderr',err)]:(r/(name+'.bin')).open('xb').write(raw)
 result=dict(pid=p.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());(r/'result.json').open('x').write(json.dumps(result,indent=2))
 l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-350:])
