import sys,pathlib,json,hashlib,os,stat,subprocess,datetime,io,tarfile,gzip,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-runtime-epoch-package-v1")
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
H='601108ea6216464bd00ae29c16cfaf0a59c71db6'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,b):
 with p.open('xb') as f:f.write(b)
def js(p,v):save(p,(json.dumps(v,indent=2)+'\n').encode())
def identity(s):return dict(dev=s.st_dev,ino=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,flags=getattr(s,'st_flags',None))
def read(p,owner=False,maximum=16*1024**2):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_size<=maximum,str(p)
 if owner:assert (a.st_uid,a.st_gid)==(501,20)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  b=os.fstat(fd);assert identity(a)==identity(b)
  chunks=[]
  while True:
   c=os.read(fd,1048576)
   if not c:break
   chunks.append(c)
  raw=b''.join(chunks);assert len(raw)<=maximum;z=os.fstat(fd)
 finally:os.close(fd)
 t=p.lstat();assert identity(a)==identity(z)==identity(t) and len(raw)==a.st_size
 return raw,identity(a)
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();q=P/'acquisition';q.mkdir();package=P/'candidate';package.mkdir()
 decl=json.loads((P/'declaration.json').read_text())
 historical=pathlib.Path('/tmp/connectanum-native-perf-finish-primary-kind-progress-v1/after-edit-hashes.json')
 prior_bytes,prior_stat=read(historical);expected=json.loads(prior_bytes)
 names=sorted(k for k in expected if k.startswith('tool/'));assert len(names)==20
 modules=('guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission')
 assert set(names)=={f'tool/{prefix}native_perf_{name}.py' for name in modules for prefix in ('','test_')}
 assert expected['tool/native_perf_build_producer.py']=='2b74548180b01feb2c7684c52ba63dca578b7c40ed8badc60f9c6ded373fe70a'
 assert expected['tool/test_native_perf_build_producer.py']=='6594f3964f06a32fb7ac6bf880eb510642ac9b73e10e2cc4f19bfd9323270636'
 entries=[];source_rows=[]
 for name in names:
  raw,ident=read(R/name,True);assert sha(raw)==expected[name],name
  dest=package/'helpers'/name;dest.parent.mkdir(parents=True,exist_ok=True);save(dest,raw)
  entries.append(dict(member=str(dest.relative_to(package)),size=len(raw),sha256=sha(raw),kind='current20_helper_file_DATA_not_validated_or_adopted'))
  source_rows.append(dict(path=name,identity=ident,sha256=sha(raw),size=len(raw)))
 js(q/'first-source-observations.json',source_rows)
 refs=[
 ('checkpoint-before-scope.json',pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')),
 ('project-state-before-scope.md',D/'docs/project_state.md'),
 ('active-plan-before-scope.md',D/'docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md'),
 ('last-phase-publication-readback.json',pathlib.Path('/tmp/connectanum-native-perf-finish-primary-kind-progress-v1/publication-readback.json')),
 ('last-phase-description-receipt.json',pathlib.Path('/tmp/connectanum-native-perf-finish-primary-kind-descriptions/receipt.json')),
 ('last-phase-admin-final-receipt.json',pathlib.Path('/tmp/connectanum-native-perf-finish-primary-kind-admin-v1/final-receipt.json'))]
 snapshots=[]
 for name,path in refs:
  raw,ident=read(path);dest=package/'continuation'/name;dest.parent.mkdir(exist_ok=True);save(dest,raw)
  entries.append(dict(member=str(dest.relative_to(package)),size=len(raw),sha256=sha(raw),kind='frozen_prior_continuation_actual_file'))
  snapshots.append(dict(label=name,actual_path=str(path),identity=ident,sha256=sha(raw),size=len(raw)))
 cp=json.loads((package/'continuation/checkpoint-before-scope.json').read_text());n=cp['native_perf_only_diagnostic_design']
 historic=n['runtime_source_archive_preparation']
 manifest=dict(kind='UNADMITTED_CURRENT20_INPUT_CANDIDATE_AND_FROZEN_PRIOR_CONTINUATION',declaration_sha256=sha((P/'declaration.json').read_bytes()),source_root=str(R),source_HEAD_expected=H,helper20_expected_from_actual_prior_manifest=dict(path=str(historical),sha256=sha(prior_bytes),identity=prior_stat),members=entries,source_observations=source_rows,continuation_observations=snapshots,historical_tracked_source_archive_reference_ONLY=dict(source_archive_sha256=historic['source_archive_sha256'],old_helper20_package_sha256_NOT_current=historic['helper20_package_sha256'],docs_commit=historic['docs_commit'],historical_only_not_opened_rehashed_reaudited_or_rebuilt=True),limits=decl['limits'],pending_obligations=decl['pending_obligations'])
 js(package/'manifest.json',manifest);save(package/'declaration.json',(P/'declaration.json').read_bytes())
 commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];js(q/f'git-{i}-before.json',dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait
  js(q/f'git-{i}-start.json',dict(pid=child.pid));out,err=child.communicate();status=wait(10)
  save(q/f'git-{i}-stdout.bin',out);save(q/f'git-{i}-stderr.bin',err)
  row=dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err));commands.append(row);js(q/f'git-{i}-result.json',row)
  assert type(status) is int and status==0 and not err
  return out
 assert git(['rev-parse','HEAD']).decode().strip()==H
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 lines=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert len(lines)==20 and {x[3:] for x in lines if x.startswith('?? ')}==set(names)
 assert git(['diff',H,'--stat','--','packages','native'])==b''
 files=sorted(x for x in package.rglob('*') if x.is_file());assert len(files)==28
 assert all(stat.S_ISREG(x.lstat().st_mode) and not x.is_symlink() for x in files)
 assert sum(x.stat().st_size for x in files)<=128*1024**2
 archive=P/'current20-continuation-input-candidate.tar.gz'
 with archive.open('xb') as rawout:
  with gzip.GzipFile(filename='',mode='wb',fileobj=rawout,mtime=0) as zipped:
   with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
    for f in files:
     raw=f.read_bytes();info=tarfile.TarInfo(str(f.relative_to(package)));info.size=len(raw);info.mode=0o644;info.uid=501;info.gid=20;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
 verified=[]
 with tarfile.open(archive,'r:gz') as tar:
  members=tar.getmembers();assert len(members)==28 and len({x.name for x in members})==28 and all(x.isfile() for x in members)
  assert {x.name for x in members}=={str(f.relative_to(package)) for f in files}
  for member in members:
   raw=tar.extractfile(member).read();assert raw==(package/member.name).read_bytes()
   verified.append(dict(member=member.name,size=len(raw),sha256=sha(raw)))
 second=[]
 for row in source_rows:
  raw,ident=read(R/row['path'],True);assert ident==row['identity'] and sha(raw)==row['sha256'];second.append(dict(path=row['path'],identity=ident,size=len(raw),sha256=sha(raw)))
 js(q/'second-source-observations.json',second)
 archive_raw,archive_ident=read(archive,maximum=128*1024**2)
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=dict(path=str(archive),sha256=sha(archive_raw),size=len(archive_raw),identity=archive_ident,regular_members=28,all28_readback_BYTEEXACT=True),member_hashes=verified,current20_two_reads_same_bytes_and_observed_identity=True,point_observations_NOT_atomic_ABA_or_immutable_runtime=True,SourceGit4=commands,Source_HEAD=H,Source_branch='codex/flatbuffers-native-perf-guard',Source_status_exact20_untracked=True,production_packages_native_diff_empty_DATA=True,Source_test_edits=False,SDK_tests_build_capture_adoption_dispatch=False,compiled_canonical=False,ownership_complete=False,admission=False,free_bytes_DATA=shutil.disk_usage(P).free)
 js(P/'package-receipt.json',receipt);lease.verify_identity();print(json.dumps(dict(archive_sha256=receipt['archive']['sha256'],archive_bytes=len(archive_raw),regular_members=28,source20_unchanged=True,admission=False)))
