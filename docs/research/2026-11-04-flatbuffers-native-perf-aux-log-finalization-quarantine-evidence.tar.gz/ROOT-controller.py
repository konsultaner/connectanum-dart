import sys,pathlib,json,hashlib,subprocess,datetime,os,ast,copy
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-finalization-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait();slot=len(calls);row=dict(argv=argv,pid=child.pid,status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   with (q/(str(slot)+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest()
  calls.append(row);(q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not production
 final=json.loads((P/'after-edit-hashes.json').read_text());before=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in final.items()) and all(final[k]==v for k,v in before.items() if 'build_producer.py' not in k)
 old=ast.parse((P/'before-producer.py').read_text());new=ast.parse((R/'tool/native_perf_build_producer.py').read_text());tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_finalization_error','_finalization_guard','_retain_finalization_error','_finalization_step'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','_complete','_constructor_guard'})
 projected=copy.deepcopy(nm['__init__']);projected.body=[x for x in projected.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr.startswith('_finalization_') for t in x.targets))]
 assert ast.dump(projected)==ast.dump(om['__init__'])
 projected=copy.deepcopy(nm['_constructor_guard']);projected.body=[x for x in projected.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='final_error' for t in x.targets)) and not(isinstance(x,ast.If) and ast.unparse(x.test)=='final_error is not None') and not(isinstance(x,ast.Expr) and ast.unparse(x)=='self._finalization_guard()')]
 assert ast.dump(projected)==ast.dump(om['_constructor_guard'])
 for x,y in zip(old.body,new.body):
  if isinstance(x,ast.ClassDef) and x.name=='_RetainedPreflightOwner':
   xm={z.name:z for z in x.body if isinstance(z,ast.FunctionDef)};ym={z.name:z for z in y.body if isinstance(z,ast.FunctionDef)}
   assert set(xm)==set(ym) and all(ast.dump(node)==ast.dump(ym[name]) for name,node in xm.items() if name!='_capture_command_history')
  elif x is not oc:assert ast.dump(x)==ast.dump(y)
 def result_literal(node):
  return next(x for x in ast.walk(node) if isinstance(x,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='whole_descendant_exit_proven' for k in x.keys))
 assert ast.dump(result_literal(om['_complete']))==ast.dump(result_literal(nm['_complete']))
 assert tests==(P/'before-existing-tests.py').read_text()+'\n\n'+(P/'new-tests.py').read_text()
 invariant=dict(ROOTwhole_final_affected_methods_6casehelper_review=True,old_init_ctor_guard_AST_projects_back=True,normal_result_literal_ASTexact=True,normal_native_API_order_executed_and_args_sourcequalified=True,all_original_test_bytes_unchanged=True,other18helpers_3bins_byteexact=True,all_other_original_functions_factories_gates_publicemitters_ASTexact=True,only_declared_init_complete_ctor_guard_4private_methods_and_typedAuxDATA=True,readiness_privatefacts_NOTphysicalEX_or_admission=True,model_full_current_source_approval=False,other_defer_streamreadwrite_initgeneric_paths_INCOMPLETE=True)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 reports=[];journals=[]
 for stage in ('before','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('finalization-before-cleanup.json')):
   d=json.loads(path.read_text());reports.append(dict(stage=stage,path=str(path),data=d))
   assert d['private_wait_observed'] is True and type(d['private_wait_status']) is int and d['private_wait_status']==0 and d['both_eof'] is True
   if stage=='after-selected' and d['mode']!='normal':
    assert d['calls']=={'defer':0,'repr':0} and d['raised_is_original'] is True and d['pending'] is True and d['finished'] is False and d['source_result_is_None'] is True
    assert d['trigger_index']+1==len(d['events'])
   if d['mode']=='normal':assert [r['stage'] for r in d['events']]==['flush','fileno','fsync','close','snapshot']*2+['result']
  for path in sorted((P/stage/'fixtures').rglob('finalization-unit-cleanup.json')):
   d=json.loads(path.read_text());assert all(type(r['status']) is int and r['status']==0 for r in d if r['kind']=='bound_same_finite_wait')
   journals.append(dict(stage=stage,path=str(path),data=d))
 with (q/'new-precleanup-reports.json').open('x') as f:json.dump(reports,f,indent=2)
 with (q/'new-unit-journals.json').open('x') as f:json.dump(journals,f,indent=2)
 a=json.loads((P/'before/result.json').read_text());z=json.loads((P/'after-selected/result.json').read_text());review=json.loads((P/'review/finish.json').read_text())
 assert (a['tests'],a['failures'],a['errors'])==(6,5,0) and (z['tests'],z['failures'],z['errors'])==(11,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],all23_hashes=final,NEWbefore6=dict(source='b3c8bc/421946',tests=6,failures=5,errors=0,normal_PASS=1),AFTERselected11=dict(source='49e30d/1063c6',tests=11,failures=0,errors=0,new=6,affected=5),not_combined_fullcurrent20canonical_or_originalruntime_admission=True,source_Git=dict(head=head,branch=branch,exact20untracked=True,production_packages_native_diffempty=True,four_actual_signed0_BOTHseparateEOF=True,DATA_only=True),planning=json.loads((P/'test-planning/finish.json').read_text()),review=review,review_tokenlimit1_stdout0_stderr1073_last6217outputchars_1111thinking_fullpartialfinalABSENT=True,reachable_reaped_NOTunavailable_or_approval_no_unchangedrepeat=True,Qwen39113_ROOTcorrections=json.loads((P/'selected-finalization-design.json').read_text())['Qwen39113_ROOT_rejected'],ROOT_independent_wholefinal_source_test_AST_qualification_NOTmodelfullapproval=True,all_candidates_UNEXECUTED_before_edit_no_candidatefailure_counts=True,new_finite_journal_files=len(journals),new_bound_same_finite_wait0_rows=sum(1 for item in journals for r in item['data'] if r['kind']=='bound_same_finite_wait'),API_facade_events_NOTexactkernel_syscalls_or_RSS_cause=True,all12cases_private_methodwait0_andEOF_before_finalizer=True,Root_knownrawfilecleanup_afterevidence_NOTlive_recovery_or_physicalEX=True,required_legacy_setup_actorFD_APIreturns_notall_serialized_no_reconstruction=True,all_named_source_model_test_edit_ROOT_controllers_saved_BEFOREcalls=True,other18helpers_3bins_byteexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_prior_cleanup_spacechange_cause_UNMEASURED=True,no_SDK_build_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_open_draft_base130_issue103_milestone_open=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_log_finalization_quarantine'].update(ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW finalization postcomponent4Git actual0/BOTHseparateEOF/branchcodex/flatbuffers-native-perf-guard/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Final49e30d/1063c6 eleven selected PASS=6matchingNEW+5affected; ROOTqualified NOTmodelfullapproval/current20canonical/admission')
 c['active_turn_status']='Aux_finalization49e30d_1063c6_selected11PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],tests=assessment['test_sha256'],NEWbefore6='5FAIL1PASS0ERROR',AFTERselected11='PASS',new_unit_journals=len(journals),new_boundwait0_rows=assessment['new_bound_same_finite_wait0_rows'],free_bytes=free)))
