import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-finalization-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();s=(R/'tool/native_perf_build_producer.py').read_text();t=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert hashlib.sha256(s.encode()).hexdigest()=='b3c8bcb395672b94cd7259158cf24f3ef6d8702e649368ca220e5a9e89278d44' and hashlib.sha256(t.encode()).hexdigest()=='421946cec0e0e3cf474201a2694c60400901b594d038b6fba68af6927e6e8f4f'
 for name,data in [('before-producer.py',s),('before-existing-tests.py',t)]:
  with (P/name).open('x') as f:f.write(data)
 c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');lines=s.splitlines()
 methods={x.name:'\n'.join(lines[x.lineno-1:x.end_lineno]) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in ('_complete','_defer','_constructor_guard','wait')}
 with (P/'source-context.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),methods=methods),f,indent=2)
 l.verify_identity();print('fresh declared b3c8bc/421946 baseline retained; selected finalization context')
