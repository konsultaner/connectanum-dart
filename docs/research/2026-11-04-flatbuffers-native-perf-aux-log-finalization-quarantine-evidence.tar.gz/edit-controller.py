import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-finalization-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1/after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 a=json.loads((P/'before/result.json').read_text());assert (a['tests'],a['failures'],a['errors'])==(6,5,0)
 source=(P/'candidate-v2-producer.py').read_text();oldtests=(R/'tool/test_native_perf_build_producer.py').read_text();new=(P/'new-tests.py').read_text();tests=oldtests+'\n\n'+new
 old=ast.parse((R/'tool/native_perf_build_producer.py').read_text());nt=ast.parse(source)
 oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in nt.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_finalization_error','_finalization_guard','_retain_finalization_error','_finalization_step'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','_complete','_constructor_guard'})
 for x,y in zip(old.body,nt.body):
  if isinstance(x,ast.ClassDef) and x.name=='_RetainedPreflightOwner':
   xm={z.name:z for z in x.body if isinstance(z,ast.FunctionDef)};ym={z.name:z for z in y.body if isinstance(z,ast.FunctionDef)}
   assert set(xm)==set(ym) and all(ast.dump(node)==ast.dump(ym[name]) for name,node in xm.items() if name!='_capture_command_history')
  elif x is not oc:assert ast.dump(x)==ast.dump(y)
 ast.parse(tests)
 with (P/'edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_hashes=h,scope='known naturalwait/EOF logfinalization only +typedAuxDATA',NEWbefore6='5FAIL1normalPASS0ERROR',model_review_tokenlimit1_fullpartialfinalABSENT_noapproval=True,ROOTwholecandidate_independentlyqualified=True,other_defer_streamreadwrite_initgeneric_physicalEX_INCOMPLETE=True),f,indent=2)
 (R/'tool/native_perf_build_producer.py').write_text(source);(R/'tool/test_native_perf_build_producer.py').write_text(tests)
 final={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert all(final[k]==v for k,v in h.items() if 'build_producer.py' not in k)
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(final,f,indent=2)
 for name,data in [('after-producer.py',source),('after-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(data)
 l.verify_identity();print(json.dumps({k:v for k,v in final.items() if 'build_producer' in k}))
