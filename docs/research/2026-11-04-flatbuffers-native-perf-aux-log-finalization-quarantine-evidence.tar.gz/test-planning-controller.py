import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-finalization-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'test-planning';q.mkdir();ctx=json.loads((P/'source-context.json').read_text())['methods']
 context="""NEW log-finalization test planning, not old creatorFD close/constructor/startup controls. Candidate UNIMPLEMENTED. Existing _complete sets pendingFalse/finishedTrue before I/O, drops public log then flush-fsync-finallyclose; exceptions invoke repr/defer/failureJSON and continue snapshot/otherlog/result. Need preserve original successful IOargs/order but unknown finalization must firsterror/quarantine/no finally-close/replay/report/pipelineadvance. Public completion/result only AFTER original resultpublication call returns normally; publicationattempt BEFORE call and uncertainty namespace terminal.
Proposed NEW6 finite tests after ACTUAL quietPython child/sourceSAMEwait0/EOF: stdout native flush then wrapperfault; native fsync thenfault; native raw logclose thenfault; actual file_snapshot helper return thenfault; actual ORIGINAL resultJSON write returns thenfault; normal success positive. Transparent root-owned facade wraps actual raw FileIO at original Path.open return BEFORE constructor arms, preserving actualwrite/fileno/flush/close/name/closed, allSourceCtor original refs use same facade. Not fakeSDK/heap/workload. Root precleanup records true privatewait/EOF, native operation order, firstidentity, repr/defer/writes/completion flags. BoundSAMEactorwait0 and knownnative-rootcleanup afterevidence onlyunit, never physicalEX release. No sourcepartialPopen methods or retagged sampler.
All creatorclose error guards stayunchanged; _defer and streamread/write/initgenericerrors OUTSIDE scope. Newpurpose-bound finalizationjournal beforeeachIO includingfileno, retain rawresult BEFOREpostcheck/knownslotclear; errorobject beforelater metadata. NativeNoneonly flush/fsync/close/resultwriter; snapshot/fileno actualreturns separated, errorNoReplay. State/type/EOF/status/sourceflags notownership/admission.
Give <=140words concrete omissions/false assumptions only, no code, no repr/close-on-error advice/stagingfile/retry/atomicclaims.
CURRENT_COMPLETE:\n"""+ctx['_complete']
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','1300','--max-input-chars','7000','--max-response-chars','5000','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),new_finalization_question=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-800:])
