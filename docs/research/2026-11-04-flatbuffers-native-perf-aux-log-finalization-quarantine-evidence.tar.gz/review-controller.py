import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-finalization-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'review';q.mkdir()
 context="""NEW Auxiliary log-finalization review; candidate-v2 PRIVATE UNIMPLEMENTED/UNEXECUTED, worktree b3c8bc/421946 unchanged. NEW6 real BEFORE =5FAIL1normalPASS0APIerrors. Transparent root-owned facade installed at nativePath.open return BEFORE constructor arms; actualFileIO.flush/fsync/close/helper-snapshot/resultwriter RETURN before fault. Same finite quiet Python child actually method-wait0+EOF beforeSource_complete; allrootcleanup knownunit after evidence, not SDK/physicalEX. Existing success actual IOorder asserted.
Candidate: record eachoperation BEFOREIO/actualreturn BEFOREchecks, known original log/ref/fileno retained; no finally-close/defer/failurefile/pipelineadvance after unknown, no replay/recovery/partialPopenmethods. Public result/pending/finished assigned onlyAFTER original resultpublication knownreturn; attempt flag BEFOREcall/neverreset. Readiness privatewait/EOF/creator-closereturn preconditions DATA notmethodauthority/EX/ownership; provider stillABSENT/gatealwaysraises. Normal args/order/observation shape/nonzero status handling preserved. _defer/streamreadwrite/initgeneric internals and full physicalcontroller remain OUTSIDE; oldgates fixed.
Qwen39113planning0 advice ROOTrejects publicationattemptFalse afterunknownwrite (must remainTrue/terminal), null-beforeIO, continue secondstream tocollectfaults, leak/immutability-auth claims. No forceGC/SDKflags/runtime/workload changes. New finalization error fastpath AFTER existing creator error fastpath; those prior phases guard entry so legitimateearliererror wins. Arbitrary foreign state writes not authenticated.
Review actual P0/P1/P2 bug only, <=220words. Include precise trigger/code evidence. Avoid proposing retry/automaticclose/status-as-release. Fullmodelresponse not physicalapproval.
WHOLE CANDIDATE DELTA:\n"""+(P/'candidate-v2.diff').read_text()+'\nWHOLE NEW6 TEST HELPER:\n'+(P/'new-tests.py').read_text()
 assert len(context)<42000
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--reasoning-budget','256','--num-predict','1800','--max-input-chars','42000','--max-response-chars','9000','--timeout','240','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),candidate_UNIMPLEMENTED=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_log_finalization_quarantine']=dict(path=str(P),candidate_UNIMPLEMENTED=True,historical_before_epoch='b3c8bc/421946',NEWbefore6='5FAIL1normalPASS0ERROR',review_pid=child.pid,review_pending=True,other_defer_streamreadwrite_initgeneric_and_physicalEX_admission_INCOMPLETE=True);c['active_turn_status']='Aux_finalization_NEWbefore5FAIL1PASS_sourceb3c8unchanged_candidateUNIMPLEMENTED_GLMreview';cp.write_text(json.dumps(c,indent=2)+'\n')
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-1000:])
