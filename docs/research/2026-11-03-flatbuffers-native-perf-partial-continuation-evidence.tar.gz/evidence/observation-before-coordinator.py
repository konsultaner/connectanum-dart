import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-partial-continuation')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'implemented-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
path=R/'tool/test_native_perf_build_producer.py';source=path.read_text()
marker="if __name__=='__main__':unittest.main()";assert source.count(marker)==1
source=source.replace(marker,"\n    def test_observation_error_never_calls_custom_exception_note(self):\n        owner,auxiliary,release,fault=self.start_partial();self.advance(owner);called=[]\n        class OwnSecondary(RuntimeError):\n            def add_note(self,note):\n                called.append(note)\n                raise AssertionError('custom exception hook must not run')\n        second=OwnSecondary('OWN later wait error')\n        original=producer._RetainedPreflightOwner._cache_auxiliary_observation\n        def cache(target,index,selected,stage):\n            if stage=='after_wait_error':raise producer.ProducerError('OWN synthetic metadata observation failure')\n            return original(target,index,selected,stage)\n        with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=second), \\\n                mock.patch.object(producer._RetainedPreflightOwner,'_cache_auxiliary_observation',cache):\n            owner.continue_auxiliary_wait(0,0);self.call_done(owner)\n        self.assertIs(owner._workers[-1]['_call_error_object'],second)\n        self.assertEqual([],called);self.assertIs(owner._first_error_object,fault)\n        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['auxiliary_observation_error'])\n        self.record('observation-error',owner)\n\n"+marker,1)
ast.parse(source);path.write_text(source)
summary=runtests('observation-before',['PartialAuxiliaryContinuationTests.test_observation_error_never_calls_custom_exception_note'])
lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
