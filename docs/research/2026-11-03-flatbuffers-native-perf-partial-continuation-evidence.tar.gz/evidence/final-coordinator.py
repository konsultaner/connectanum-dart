import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-partial-continuation')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'fixed-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
path=R/'tool/test_native_perf_build_producer.py';source=path.read_text()
marker="if __name__=='__main__':unittest.main()";assert source.count(marker)==1
source=source.replace(marker,"\n    def test_overlapping_auxiliary_call_refuses_while_same_worker_waits(self):\n        owner,auxiliary,release,fault=self.start_partial()\n        entered=self.threading.Event();unblock=self.threading.Event();self.events.append(unblock)\n        real=self.actual_wait;calls=[];refused=[];unexpected=[]\n        def wait(selected,timeout):\n            calls.append(selected);entered.set();unblock.wait(5)\n            return real(selected,timeout)\n        def second():\n            try:owner.continue_auxiliary_wait(0,0)\n            except producer.ProducerError as error:refused.append(type(error).__name__)\n            except BaseException as error:unexpected.append(error)\n        with mock.patch.object(producer.AuxiliaryCommand,'wait',wait):\n            owner.continue_auxiliary_wait(0,1)\n            try:\n                self.assertTrue(entered.wait(3));before=dict(owner.observe(0))\n                caller=self.threading.Thread(target=second,daemon=False);self.parents.append(caller)\n                caller.start();caller.join(3);self.assertFalse(caller.is_alive())\n                self.assertEqual(['ProducerError'],refused);self.assertEqual([],unexpected)\n                self.assertEqual(before,dict(owner.observe(0)))\n            finally:self.release(release);unblock.set();self.call_done(owner)\n        self.assertEqual([auxiliary],calls);self.assertEqual(0,auxiliary.result['returncode'])\n        self.record('overlapping-call-refused',owner)\n\n"+marker,1)
ast.parse(source);path.write_text(source)
summary=runtests('final',['PartialAuxiliaryContinuationTests.test_overlapping_auxiliary_call_refuses_while_same_worker_waits'])
lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
