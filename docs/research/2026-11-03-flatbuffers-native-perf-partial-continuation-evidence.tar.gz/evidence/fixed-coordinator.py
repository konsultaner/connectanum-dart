import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-partial-continuation')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'observation-before-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
path=R/'tool/native_perf_build_producer.py';source=path.read_text()
old="worker_entered=False,call_done=False,worker_joined=False,join_error=None,call_error=None,\n                _thread=None,_join_error_object=None,_call_error_object=None)"
new="worker_entered=False,call_done=False,worker_joined=False,join_error=None,call_error=None,\n                auxiliary_observation_error=None,_thread=None,_join_error_object=None,_call_error_object=None,\n                _auxiliary_observation_error_object=None)"
assert source.count(old)==1;source=source.replace(old,new,1)
old="            except BaseException as secondary:\n                error.add_note('auxiliary observation after wait error: '+type(secondary).__name__)"
new="            except BaseException as secondary:\n                with self._lock:\n                    record=self._workers[-1]\n                    record['auxiliary_observation_error']=type(secondary).__name__\n                    record['_auxiliary_observation_error_object']=secondary"
assert source.count(old)==1;source=source.replace(old,new,1)
ast.parse(source);path.write_text(source)
summary=runtests('fixed',['PartialAuxiliaryContinuationTests.test_observation_error_never_calls_custom_exception_note',
 'PartialAuxiliaryContinuationTests.test_new_wait_error_preserves_constructor_primary_and_handle'])
lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
