import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-partial-continuation')
C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snapshot(epoch):
 target=P/(epoch+'-source');target.mkdir()
 result={}
 for name in expected:
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 for name in ('bin/common.sh','bin/verify','bin/test-all'):
  data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
 writej(P/(epoch+'-hashes.json'),result)
 return result
def runtests(epoch,names):
 h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
 sys.dont_write_bytecode=True
 modules=[]
 for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
  data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
  mod=types.ModuleType(name);mod.__file__=str(R/rel)
  assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
  exec(compile(data,str(R/rel),'exec'),mod.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (P/(epoch+'-tests.log')).write_text(out.getvalue())
 summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
  successful=result.wasSuccessful(),source_sha256=h,
  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
 writej(P/(epoch+'-tests.json'),summary)
 for name in reversed(modules):sys.modules.pop(name)
 return summary

expected=json.loads((P/'before-hashes.json').read_text())
for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
writej(P/'before-error-root-qualification.json',dict(before_tests=8,before_errors=15,before_failures=0,all_errors_same_missing_public_API=True,invalid_argument_subtests_explain_extra7_errors=True,no_teardown_error=True,not15production_defects=True,debug89699_complete_reaped_direct0=True,rejected_debug='Actual _RetainedPreflightOwner class from producer, not stub/mock/mixin. Method absent BEFOREimplementation is expected source API absence, not fixture defect. No binding method into test mock or fixture reset.'))

path=R/'tool/native_perf_build_producer.py';source=path.read_text()
def replace(old,new):
 global source
 assert source.count(old)==1,old
 source=source.replace(old,new,1)
replace("        self._workers=[];self._joined_workers=0",
"""        self._workers=[];self._joined_workers=0
        self._partial_auxiliaries=None;self._auxiliary_views={};self._auxiliary_index=None
        self._auxiliary_quarantined=False;self._auxiliary_ledger_check_matched=None""")
replace("            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))",
"""            auxiliary_index=self._auxiliary_index,
            auxiliary_ledger_check_matched=self._auxiliary_ledger_check_matched,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))""")
replace("""                if self._index:raise ProducerError('constructor attempt is permanently terminal')
            elif (not self._initialized""",
"""                if self._index:raise ProducerError('constructor attempt is permanently terminal')
            elif action=='auxiliary_wait':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._auxiliary_quarantined):
                    raise ProducerError('partial auxiliary continuation not eligible')
                cached=self._auxiliary_views.get(value[0])
                if cached is not None and cached['terminal_result_observed']:
                    raise ProducerError('auxiliary wait is permanently terminal')
            elif (not self._initialized""")
replace("""worker_entered=False,call_done=False,worker_joined=False,join_error=None,
                _thread=None,_join_error_object=None)""",
"""worker_entered=False,call_done=False,worker_joined=False,join_error=None,call_error=None,
                _thread=None,_join_error_object=None,_call_error_object=None)""")
replace("            elif action=='wait':result=self._operation.wait(value)",
"""            elif action=='wait':result=self._operation.wait(value)
            elif action=='auxiliary_wait':result=self._wait_partial_auxiliary(*value)""")
replace("""            if error is not None:self._error_locked(error)
            self._last_result=result;self._call_done=True;self._busy=False;record['call_done']=True""",
"""            if error is not None:
                self._error_locked(error);record['call_error']=type(error).__name__;record['_call_error_object']=error
            self._last_result=result;self._call_done=True;self._busy=False;record['call_done']=True""")
replace("    def continue_wait(self,timeout):","\n    def _partial_auxiliary_ledger(self):\n        if threading.current_thread() is not self._thread or type(self._operation) is not CommandProducer:\n            raise ProducerError('partial auxiliary inspection requires the retained worker')\n        data=self._operation.__dict__\n        if (not {'pending','process','finished','auxiliary_operations'}<=data.keys()\n            or data['pending'] is not False or data['process'] is not None or data['finished'] is not True):\n            raise ProducerError('recipe actor or unknown partial producer remains unresolved')\n        ledger=data['auxiliary_operations']\n        if type(ledger) is not list or any(type(item) is not AuxiliaryCommand for item in ledger):\n            self._quarantine_auxiliary_ledger()\n            raise ProducerError('partial auxiliary ledger is unknown')\n        current=tuple(ledger)\n        if len({id(item) for item in current})!=len(current):\n            self._quarantine_auxiliary_ledger()\n            raise ProducerError('partial auxiliary ledger aliases an actor')\n        with self._lock:\n            if self._partial_auxiliaries is None:self._partial_auxiliaries=current\n            frozen=self._partial_auxiliaries\n        if len(current)!=len(frozen) or any(a is not b for a,b in zip(current,frozen)):\n            self._quarantine_auxiliary_ledger()\n            raise ProducerError('partial auxiliary ledger changed; exact handles retained')\n        with self._lock:\n            if self._auxiliary_quarantined:raise ProducerError('partial auxiliary ledger is quarantined')\n            self._auxiliary_ledger_check_matched=True\n            self._snapshot=self._snapshot_locked()\n        return frozen\n\n    def _quarantine_auxiliary_ledger(self):\n        with self._lock:\n            self._auxiliary_quarantined=True;self._auxiliary_ledger_check_matched=False\n            self._auxiliary_views={index:MappingProxyType({**dict(row),'ledger_check_matched':False})\n                for index,row in self._auxiliary_views.items()}\n            self._snapshot=self._snapshot_locked()\n\n    def _cache_auxiliary_observation(self,index,auxiliary,stage):\n        # Only the serialized worker reads raw actor state. Cached rows are data,\n        # never actor closure, authentication or physical lease-release authority.\n        if threading.current_thread() is not self._thread:\n            raise ProducerError('auxiliary observation requires the retained worker')\n        data=auxiliary.__dict__\n        required={'started','pending','finished','process','result','status','streams'}\n        if not required<=data.keys() or data['started'] is not True:\n            raise ProducerError('unknown auxiliary lifecycle')\n        if type(data['pending']) is not bool or type(data['finished']) is not bool:\n            raise ProducerError('invalid auxiliary state')\n        process=data['process'];status=data['status'];result=data['result'];streams=data['streams']\n        if (type(process) is not subprocess.Popen or type(process.pid) is not int or process.pid<=0\n            or (status is not None and type(status) is not int)\n            or (result is not None and type(result) is not dict)\n            or type(streams) is not dict or set(streams)!= {'stdout','stderr'}\n            or any(type(streams[key]) is not dict or type(streams[key].get('eof')) is not bool for key in streams)):\n            raise ProducerError('unknown auxiliary handle or stream state')\n        terminal=data['finished'] is True and data['pending'] is False and type(result) is dict\n        if terminal:\n            if result.get('returncode')!=status or type(result.get('returncode')) is not type(status):\n                raise ProducerError('auxiliary terminal status differs')\n        elif not (data['pending'] is True and data['finished'] is False and result is None):\n            raise ProducerError('incomplete auxiliary terminal state')\n        row=dict(index=index,pid=process.pid,direct_status=status,pending=data['pending'],\n            finished=data['finished'],stdout_eof=streams['stdout']['eof'],stderr_eof=streams['stderr']['eof'],\n            terminal_result_observed=terminal,stage=stage)\n        with self._lock:\n            row['ledger_check_matched']=self._auxiliary_ledger_check_matched\n            value=MappingProxyType(row);self._auxiliary_views[index]=value;self._auxiliary_index=index\n            self._snapshot=self._snapshot_locked()\n        return value\n\n    def _wait_partial_auxiliary(self,index,timeout):\n        frozen=self._partial_auxiliary_ledger()\n        # Freeze and retain before selecting; never reselect a different actor.\n        if index>=len(frozen):raise ProducerError('partial auxiliary index is not retained')\n        auxiliary=frozen[index]\n        before=self._cache_auxiliary_observation(index,auxiliary,'before_wait')\n        if before['terminal_result_observed']:raise ProducerError('auxiliary wait is permanently terminal')\n        try:result=auxiliary.wait(timeout)\n        except BaseException as error:\n            try:\n                self._cache_auxiliary_observation(index,auxiliary,'after_wait_error')\n                self._partial_auxiliary_ledger()\n            except BaseException as secondary:\n                error.add_note('auxiliary observation after wait error: '+type(secondary).__name__)\n            raise\n        after=self._cache_auxiliary_observation(index,auxiliary,'after_wait')\n        self._partial_auxiliary_ledger()\n        if (result is None and after['terminal_result_observed']) or (result is not None and result is not auxiliary.result):\n            raise ProducerError('auxiliary wait result differs from retained state')\n        return after\n\n    def auxiliary_observations(self):\n        \"\"\"Immutable selected-actor data; never a complete actor inventory.\"\"\"\n        with self._lock:return tuple(self._auxiliary_views[index] for index in sorted(self._auxiliary_views))\n\n    def continue_auxiliary_wait(self,index,timeout):\n        if type(index) is not int or index<0:raise ProducerError('nonnegative auxiliary index required')\n        return self._schedule('auxiliary_wait',(index,_preflight_timeout(timeout)))\n\n"+"    def continue_wait(self,timeout):")
ast.parse(source);path.write_text(source)
summary=runtests('implemented',['PartialAuxiliaryContinuationTests','PreflightEmissionDispatchTests',
 'OwnedPreflightTests.test_postspawn_primary_failure_keeps_same_known_child_until_natural_exit',
 'OwnedPreflightTests.test_blocked_constructor_observation_and_overlap_refusal',
 'OwnedPreflightTests.test_emit_attempt_is_terminal_and_keeps_first_error'])
lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','successful')}))
