
import sys,os,pathlib,json,hashlib,stat,types,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as companion
P=pathlib.Path('/private/tmp/connectanum-native-perf-runtime-root-preparation')
PLAN=pathlib.Path('/tmp/connectanum-native-perf-root-binding-orientation/runtime-preparation-execution-declaration.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
with companion.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir(mode=0o700)
 put(P/'attempt.json',dict(terminal=True,scope='new OWN frozen runtime source checkout ADMIN only'))
 raw_plan=PLAN.read_bytes();assert len(raw_plan)<=1024**2
 plan=json.loads(raw_plan);put(P/'declaration.json',plan)
 assert plan['helper_root']=='/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart'
 assert plan['runtime_root']=='/Users/konsultaner/.codex/worktrees/flatbuffers-native-preflight-runtime/connectanum-dart'
 put(P/'consumed-plan.json',dict(sha256=sha(raw_plan),size=len(raw_plan)))
 helper=pathlib.Path(plan['helper_root']);runtime=pathlib.Path(plan['runtime_root']);parent=runtime.parent
 assert parent.parent.resolve(strict=True)==parent.parent
 assert helper.resolve(strict=True)==helper
 assert not os.path.lexists(parent) and not os.path.lexists(runtime)
 free_before=os.statvfs(helper).f_bavail*os.statvfs(helper).f_frsize
 assert free_before>=plan['source_admin_floor_bytes']+plan['maximum_committed_blob_bytes']
 expected=plan['expected_helper_and_bin_sha256'];source_bytes={};metadata=[]
 for rel,digest in expected.items():
  path=helper/rel;fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
  try:
   before=os.fstat(fd)
   put(P/('input-'+str(len(metadata)).zfill(2)+'-before.json'),dict(path=rel,uid=before.st_uid,gid=before.st_gid,mode=before.st_mode,size=before.st_size,device=before.st_dev,inode=before.st_ino))
   assert stat.S_ISREG(before.st_mode) and before.st_size<=2*1024**2
   data=b''
   while len(data)<=before.st_size:
    part=os.read(fd,min(65536,before.st_size+1-len(data)))
    if not part:break
    data+=part
   stable=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
   assert len(data)==before.st_size and stable(before)==stable(os.fstat(fd))==stable(path.lstat())
   assert sha(data)==digest
   if rel.startswith('tool/'):
    assert before.st_uid==501 and before.st_gid==20 and stat.S_IMODE(before.st_mode)==0o644
   source_bytes[rel]=data;metadata.append(dict(path=rel,identity=stable(before),sha256=sha(data)))
  finally:os.close(fd)
 put(P/'helper-source-before.json',metadata)
 name='_owned_runtime_root_preparation_producer';assert name not in sys.modules
 module=types.ModuleType(name);module.__file__=str(helper/'tool/native_perf_build_producer.py');sys.modules[name]=module
 exec(compile(source_bytes['tool/native_perf_build_producer.py'],module.__file__,'exec'),module.__dict__)
 operations=[];commands=[];primary=None;cleanup_errors=[];fallback=[]
 try:
  git=shutil.which('git');assert git is not None
  def command(label,args,cwd=helper):
   argv=[git,*args]
   op=module.AuxiliaryCommand(directory=P,name=label,argv=argv,cwd=cwd,
     environment=dict(os.environ),lease_check=lease.verify_identity,stdout_max=32*1024**2,stderr_max=1024**2)
   operations.append(op) # Actual operation retained BEFORE child launch.
   op.start();result=op.result
   while result is None:result=op.wait(1)
   commands.append(result)
   put(P/(label+'-returned.json'),result)
   assert result['returncode']==0 and result['status']=='success'
   assert all(row['eof'] and row['snapshot_matches_stream'] for row in result['outputs'].values())
   return (P/(label+'.stdout')).read_bytes()
  commit=plan['source_commit']
  original_head=command('helper-head-before',['-C',str(helper),'rev-parse','HEAD']).decode().strip()
  assert original_head==commit
  raw=command('tree',['-C',str(helper),'ls-tree','-r','-l','-z',commit])
  entries=[];logical=0
  for entry in raw.split(b'\0'):
   if not entry:continue
   meta,path=entry.split(b'\t',1);mode,kind,object_id,size=meta.split()
   assert kind==b'blob' and mode in (b'100644',b'100755',b'120000')
   logical+=int(size);entries.append(os.fsdecode(path))
  assert logical<=plan['maximum_committed_blob_bytes']
  put(P/'tree-estimate.json',dict(entries=len(entries),logical_committed_blob_bytes=logical,
   scope='Git metadata only, not physical allocated space/all checkout bytes/canonical proof',
   current_helper_paths_in_tree=[rel for rel in expected if rel.startswith('tool/') and rel in entries]))
  parent.mkdir(mode=0o700)
  command('add-worktree',['-C',str(helper),'worktree','add','--detach',str(runtime),commit])
  assert runtime.resolve(strict=True)==runtime
  head=command('runtime-head',['-C',str(runtime),'rev-parse','HEAD'],runtime).decode().strip()
  branch=command('runtime-branch',['-C',str(runtime),'rev-parse','--abbrev-ref','HEAD'],runtime).decode().strip()
  assert branch=='HEAD'
  status=command('runtime-status',['-C',str(runtime),'status','--porcelain','--untracked-files=normal'],runtime)
  assert head==commit and status==b''
  after_head=command('helper-head-after',['-C',str(helper),'rev-parse','HEAD']).decode().strip()
  assert after_head==original_head
  for rel,digest in expected.items():assert sha((helper/rel).read_bytes())==digest
  put(P/'summary.json',dict(scope='OWN frozen runtime source checkout ADMIN metadata only',
   runtime_root=str(runtime),runtime_HEAD=head,runtime_detached_report=branch,
   reported_git_status_clean=True,helper_source_root=str(helper),helper_HEAD_unchanged=True,
   helper20_and_selected3bin_bytes_unchanged=True,whole_helper_worktree_still_unclean_unadmitted=True,
   commands=len(commands),direct_statuses=[row['returncode'] for row in commands],
   separate_stream_EOF_all=all(v['eof'] for row in commands for v in row['outputs'].values()),
   runtime_root_stat=dict(uid=runtime.stat().st_uid,gid=runtime.stat().st_gid,mode=runtime.stat().st_mode),
   generated_root_config_present=(runtime/'.dart_tool/package_config.json').exists(),
   native_transport_target_present=(runtime/'native/transport/target').exists(),
   native_bench_target_present=(runtime/'native/bench/target').exists(),
   no_build_test_SDK_or_native_execution=True,no_current_generated_config_actual_lock_cohort_or_compiled_output_transplanted=True,
   no_source_commit_push_adoption_or_strict_dispatch=True,no_cleanup=True,
   no_all_checkout_bytes_or_helper_canonical_or_execution_provenance=True,
   capture_ready=False,source_admitted=False,live_admission=False,
   free_before=free_before,free_after=os.statvfs(helper).f_bavail*os.statvfs(helper).f_frsize,
   space_change_cause='UNMEASURED'))
 except BaseException as error:
  primary=error
  try:put(P/'failure.json',dict(type=type(error).__name__,terminal=True,no_reset_retry_or_cleanup=True))
  except BaseException:pass
  raise

 finally:
  # Same actual commands finish naturally; original primary is retained.
  for op in operations:
   result=op.result
   while result is None:
    try:result=op.wait(1)
    except BaseException as secondary:
     cleanup_errors.append(dict(stage='same known command wait',type=type(secondary).__name__))
     if primary is None:primary=secondary
     if op.finished:
      # No terminal publication retry. This branch is admin-failure-only;
      # naturally wait the same retained direct Popen if present.
      if op.process is not None:
       while True:
        try:
         status=op.process.wait(timeout=1)
         fallback.append(dict(pid=op.process.pid,status=status,scope='admin failure-only known direct natural wait; no stream-completion claim'))
         break
        except module.subprocess.TimeoutExpired:continue
      break
  if sys.modules.get(name) is module:sys.modules.pop(name)
  try:lease.verify_identity()
  except BaseException as secondary:
   cleanup_errors.append(dict(stage='final lease identity',type=type(secondary).__name__))
   if primary is None:primary=secondary
  try:put(P/'finalization.json',dict(primary=None if primary is None else type(primary).__name__,cleanup_errors=cleanup_errors,fallback=fallback,all_admission_flags=False))
  except BaseException as secondary:
   if primary is None:primary=secondary
  if primary is not None:raise primary
print(json.dumps(dict(terminal=True,scope='OWN frozen runtime source checkout ADMIN only')))
