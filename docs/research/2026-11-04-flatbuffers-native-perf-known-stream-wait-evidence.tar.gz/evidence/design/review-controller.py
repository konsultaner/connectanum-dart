import sys,pathlib,json,difflib,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-known-stream-wait-design');E=pathlib.Path('/tmp/connectanum-native-perf-known-stream-wait')
 selected=''
 for rel in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'):
  old=(E/'original-source'/rel).read_text();new=(E/'fixed-source'/rel).read_text()
  selected+=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='before/'+rel,tofile='current/'+rel,n=3))
 with (P/'final-selected-diff.txt').open('x') as f:f.write(selected)
 prompt='Review NEW selected wait-only owner diff, max3 concrete bugs <=250words TOTAL/no code. Successful inventoryfreeze required; separate known_stream_wait only, old pipeline stillfrozen. Exact private actor/Popen/streamdict-FD-log-hash-path retained BEFOREcallback/fstat. Ownercallback then fullknownbinding/expectedmutableprogress+FDpathdirection checks BEFOREread/write/select/close/wait. Own expected buffers/hash/bytes/EOF/FD advance only knownIO. Unknowncount/read/close stickyquarantine/noreplay-reclose; signed actualwait retained BEFOREfalliblecache; Aux uses existing exactprocess witness. No _complete/endfinish/logclose/publication/pendingfinishedretag. Separatetypedimmutablecache/oldcachehistoric/terminalonlyrefuseswait, ownershipNone/allflagsFalse. Fixed19PASS=15new+4required after3new actual regressions(path/writer metadata ignored; unknown recipekey equalityhook ran). Positivefinite realcapacitystreams; negative IOhooks mocked, independent fixture suffixdrain/naturalteardown NEVERliveworkaround. Focus real lostbytes/identity/budget/exception errors. No global atomicity/ABA/auth/descendant/physicalEXclosure/current20canonical/originalhost claim; full logsealing/bridge incomplete. No invented APIs/cleanup-reset-cancel/SDK or workload controls.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--file',str(P/'final-selected-diff.txt'),'--prompt',prompt,'--num-predict','2400','--max-response-chars','12000','--timeout','180','--save-output',str(P/'review.txt')]
 with (P/'review-command.json').open('x') as f:json.dump(argv,f,indent=2)
 h=json.loads((E/'fixed-hashes.json').read_text())
 with (P/'review-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);status=proc.wait()
 with (P/'review-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,selected_chars=len(selected),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py']),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,answer_exists=(P/'review.txt').exists(),selected_chars=len(selected))))
