try:
    pending = [
        {"path": "/bin/sh", "role": "observed wrapper shebang reference"},
        {"path": "/sbin/ldconfig.real", "role": "observed wrapper exec source reference"},
    ]
    images = {}
    cursor = 0
    while cursor < len(pending):
        request = pending[cursor]
        cursor += 1
        source = Path(request["path"])
        if not source.is_absolute():
            raise RuntimeError("Actual interpreter reference is not absolute; no guessed search")
        if str(source) in images:
            images[str(source)]["source_references"].append(request)
            continue
        event({"operation": "path_observation_request_before_open", **request})
        path_stat = os.lstat(source)
        link_text = os.readlink(source) if source.is_symlink() else None
        resolved_path_observation = str(source.resolve(strict=True))
        row = preserve("reference-" + str(len(images)) + ".image", source)
        row["source_references"] = [request]
        row["path_observations"] = {
            "lstat_before_open": list(path_stat),
            "symlink_text_observed": link_text,
            "resolved_path_observed": resolved_path_observation,
            "qualification": "Separate point observations, not atomic path/FD/origin identity",
        }
        images[str(source)] = row
        elf = row["elf_header"]
        interpreter = None if elf is None else elf["interpreter_field"]
        if interpreter is not None:
            pending.append({"path": interpreter, "role": "actual saved ELF PT_INTERP field",
                            "requested_by": row["saved"]})
    report = {
        "purpose": "NEW original Actions wrapper-reference input images, no delegate execution",
        "workflow_revision": os.environ["GITHUB_SHA"],
        "run_id": os.environ["GITHUB_RUN_ID"],
        "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"],
        "independent_reference_origin": "Previously captured original-PATH wrapper source only; no wrapper reread or bypass",
        "uid": os.getuid(), "gid": os.getgid(), "cwd": str(root),
        "environment": {k: os.environ.get(k) for k in [
            "PATH", "RUSTUP_TOOLCHAIN", "ImageOS", "ImageVersion",
            "RUNNER_OS", "RUNNER_ARCH", "LD_LIBRARY_PATH", "LD_PRELOAD"]},
        "original_order_references": pending,
        "images": list(images.values()),
        "native_information_queries": [],
        "qualification": [
            "The two source references and actual saved ELF interpreter fields justify only this bounded acquisition",
            "Complete saved streams/readbacks and point metadata do not prove original exec, loaded mappings, ABA/origin/authentication, target ABI, cohort or actor/FD closure",
            "No shell, ldconfig delegate, compiler, cargo, bootstrap or dependency recipe is executed by this acquisition script",
            "DT_NEEDED, symbol versions, effective Cargo linker, C headers and generated-input/runtime authority remain unbound",
            "No Source20 edits/import/adoption, native build, driver, broker, perf, benchmark or numerical workload",
            "Original Actions setup remains unchanged; no favorable runner/cohort selection",
        ],
        "source_admitted": False, "live_admission": False,
        "capture_ready": False, "evidence_complete": False,
    }
    with (out / "wrapper-delegate-input-observations.json").open("x") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
finally:
    journal.close()
