import pathlib,sys,json,hashlib,importlib.util,os,stat,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_1939_regular_scope_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-regular-scope-v1';CP=B/'current-task-checkpoint.json';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration=v['declaration'];save('declaration.json',json.dumps(declaration,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));bindings=[]
 def read_bounded(path,size,expected,role):
  b={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));b['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];b['before']={k:getattr(before,k) for k in keys};b['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);b.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert b['before']==b['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:primary=error;b['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as error:
   b['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw
 source=declaration['exact_saved_input'];originalraw=read_bounded(pathlib.Path(source['path']),source['range'][1],source['sha256'],'original_ALL2308_metadata');save('original_ALL2308_metadata-bound-PRIVATE.json',originalraw);original=json.loads(originalraw)
 allmetadata=[r['original_separate_parent_child_metadata'] for r in original['ALL2308_original_child_relationships_with_NEW_counts']]
 counts={kind:sum(r['saved_type_derived_from_original_mode']==kind for r in allmetadata) for kind in ['regular','directory','symlink','other','unknown']}
 assert len(allmetadata)==2308 and counts=={'regular':2279,'directory':29,'symlink':0,'other':0,'unknown':0}
 relations=[]
 for original_position,row in enumerate(allmetadata):
  if row['saved_type_derived_from_original_mode']!='regular':continue
  parent=row['literal_parent_reference_SEPARATE'];name=row['literal_child_name_SEPARATE'];assert row['parent_child_NOT_joined_resolved_followed_or_executed'] is True and name not in ['','.','..'] and '/' not in name and '\0' not in name and os.fsdecode(bytes.fromhex(row['original_name_bytes_hex']))==name
  relations.append({'NEW_regular_scope_position_ONE_based':len(relations)+1,'original_entry_record_position_ZERO_based':original_position,'original_separate_parent_child_metadata_PRIVATE':row,'NEW_express_lexical_candidate_TEXT':parent+'/'+name,'NEW_declaration_epoch':'ALL2279_regular_BODYINPUT_scope_AFTER2308entry_intake_BEFORE_ANY_SDK_INPUT_IO','literal_text_only_NOTfilesystemjoin_resolution_or_alias':True,'original_parent_child_and_prior_query_epochs_unchanged':True,'UNOPENED_UNQUERIED_in_THIS_new_scope':True,'alias_identity':None,'query_permission':None,'unperformed_readlink_comparison_count':None,'unperformed_readlink_matches':None,'unperformed_readlink_nonmatches':None})
 refs=[r['NEW_express_lexical_candidate_TEXT'] for r in relations];assert len(refs)==2279
 private_scope={'phase':'NEW_ALL2279_regular_BODYINPUT_lexicalscope_DECLARED_NOT_queried','ALL2279_new_explicit_lexical_relations_PRIVATE':relations,'ALL2279_new_literal_regular_BODYINPUT_references':refs,'ALL2308_original_separate_child_metadata_PRIVATE':allmetadata,'ALL199_original_parent_query_records_PRIVATE_preserved':original['ALL199_original_parent_query_records_PRIVATE_preserved'],'original_ALL2308_name_namehex_link_summary_NOT_revalidated':original['summary'],'all_prior_metadata_epochs_field_sources_unchanged':source,'ALL2279_BODYinteriors_UNOPENED':True,'ALL29_childdirectories_DEFERRED':True,'NEW0_rawlinks_THISdataset':0,'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'new_regular_BODY_reads':0,'recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 privateraw=(json.dumps(private_scope,ensure_ascii=True,indent=2)+'\n').encode();save('ALL2279-private-exact-new-regular-lexical-scope-BEFORE-INPUT-IO.json',privateraw)
 def public_metadata(row):
  out={k:value for k,value in row.items() if k not in ['original_separate_lstat_full_stat_times_PRIVATE','original_full_child_record_PRIVATE','original_parent_query_record_except_children_PRIVATE']};s=row['original_separate_lstat_full_stat_times_PRIVATE'];out['EXPLICITLY_DERIVED_original_mode_UIDGID_nlink_size_only']=None if s is None else {k:s[k] for k in ['st_mode','st_uid','st_gid','st_nlink','st_size']};return out
 public_scope={k:value for k,value in private_scope.items() if k not in ['ALL2279_new_explicit_lexical_relations_PRIVATE','ALL2308_original_separate_child_metadata_PRIVATE','ALL199_original_parent_query_records_PRIVATE_preserved','original_ALL2308_name_namehex_link_summary_NOT_revalidated','all_prior_metadata_epochs_field_sources_unchanged']}
 public_scope.update(interpretation='EXPLICITLY_DERIVED_PUBLIC_SAFE_regular_BODYINPUT_metadata_scope_ONLY/fulloriginalstat-times-FD-privatecontexts PRIVATEretained/alloriginalfields-gates unchanged; expresslyNEWlexicalTEXT beforeSDKINPUT andbeforeCPcomparison/no automaticjoin-resolve-follow-recursion/permissionfrommetadata',ALL2279_new_explicit_lexical_relations=[{**{k:value for k,value in r.items() if k!='original_separate_parent_child_metadata_PRIVATE'},'original_separate_parent_child_metadata_EXPLICITLY_DERIVED_PUBLIC':public_metadata(r['original_separate_parent_child_metadata_PRIVATE'])} for r in relations],ALL2308_original_safe_separate_entry_metadata=[public_metadata(r) for r in allmetadata],original_private_scope_bytes=len(privateraw),original_private_scope_sha256=hashlib.sha256(privateraw).hexdigest(),original2308_savedmetadata_bytes=source['range'][1],original2308_savedmetadata_sha256=source['sha256'],all_prior_query_epochs_DEFERRED_flags_6and18links_oldncursesrawhexNULL_unchanged=True)
 publicraw=(json.dumps(public_scope,ensure_ascii=True,indent=2)+'\n').encode();save('ALL2279-new-exact-public-safe-regular-scope-BEFORE-INPUT-IO.json',publicraw)
 cpraw=read_bounded(CP,None,None,'prior_checkpoint_ALL_string_scalar_VALUES');save('prior-checkpoint-bound-PRIVATE.json',cpraw);priorcp=json.loads(cpraw);assert 'actions_include_great_great_grandchild_regular_scope_v1' not in priorcp
 scalars=[]
 def collect(value,path):
  if isinstance(value,str):scalars.append({'ordinal_ZERO_based':len(scalars),'location':path,'original_scalar_PRIVATE':value})
  elif isinstance(value,dict):
   for key,child in value.items():collect(child,path+[key])
  elif isinstance(value,list):
   for i,child in enumerate(value):collect(child,path+[i])
 collect(priorcp,[])
 def nonmatching_runs(matched):
  out=[];start=None
  for ordinal in range(len(scalars)):
   if ordinal not in matched:
    if start is None:start=ordinal
   elif start is not None:out.append([start,ordinal]);start=None
  if start is not None:out.append([start,len(scalars)])
  return out
 consumed=[];exactrefs=0;substringrefs=0;allscalarmatches=0;alloccurrences=0
 for ordinal,reference in enumerate(refs):
  matches=[];exact=[];hitpositions=set()
  for scalar in scalars:
   text=scalar['original_scalar_PRIVATE'];positions=[];start=0
   while True:
    pos=text.find(reference,start)
    if pos<0:break
    positions.append(pos);start=pos+1
   if positions:
    matches.append({'prior_CP_scalar_ordinal_ZERO_based':scalar['ordinal_ZERO_based'],'original_scalar_location':scalar['location'],'original_scalar_PRIVATE':text,'candidate_exact_scalar_equality':text==reference,'ALL_overlapping_character_offsets_ZERO_based':positions,'ALL_overlapping_UTF8_surrogatepass_scalar_byte_offsets_ZERO_based':[len(text[:pos].encode('utf-8','surrogatepass')) for pos in positions],'candidate_character_length':len(reference),'candidate_UTF8_surrogatepass_byte_length':len(reference.encode('utf-8','surrogatepass')),'offsets_NOT_rawJSONwire_or_SDKbyte_aliasidentity':True});hitpositions.add(scalar['ordinal_ZERO_based']);alloccurrences+=len(positions)
    if text==reference:exact.append(scalar['ordinal_ZERO_based'])
  exactrefs+=bool(exact);substringrefs+=bool(matches);allscalarmatches+=len(matches)
  consumed.append({'NEW_regular_scope_position_ONE_based':ordinal+1,'original_entry_record_position_ZERO_based':relations[ordinal]['original_entry_record_position_ZERO_based'],'NEW_express_lexical_candidate_TEXT':reference,'new_full_reference_CP_comparison_performed':True,'exact_scalar_match_count':len(exact),'exact_scalar_match_original_ordinals_ZERO_based':exact,'substring_scalar_match_count':len(matches),'ALL_matching_prior_CP_scalars_PRIVATE':matches,'ALL_nonmatching_prior_CP_scalar_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':nonmatching_runs(hitpositions),'unperformed_readlink_comparison_count':None,'unperformed_readlink_matches':None,'unperformed_readlink_nonmatches':None,'alias_identity':None,'query_permission_from_matches_or_nonmatches':None})
 assert len(consumed)==2279 and len(bindings)==2
 summary={'source_metadata_run_id':42403777505,'source_metadata_revision':'c4b4e6b2d7bce853d008b9c91cccb811088ad6ed','ALL2308_original_entries_preserved':2308,'ALL2279_original_mode_regular_scope_candidates':2279,'ALL29_original_mode_directory_DEFERRED':29,'NEW0_symlink_rawlink_records_THISdataset':0,'ALL2279_unperformed_readlink_counts_lists_NULL':True,'ALL199_original_parent_query_epochs_preserved':199,'private_scope_bytes':len(privateraw),'private_scope_sha256':hashlib.sha256(privateraw).hexdigest(),'explicitly_derived_public_safe_source_bytes':len(publicraw),'explicitly_derived_public_safe_source_sha256':hashlib.sha256(publicraw).hexdigest(),'prior_CP_top_level_nodes':len(priorcp),'prior_CP_actions_nodes_included':sum(str(k).startswith('actions_') for k in priorcp),'comparison_corpus_ENTIRE_prior_task_CP_stringSCALARVALUES_NOT_JSONkeys':True,'prior_checkpoint_ALL_string_scalar_VALUES':len(scalars),'new_regular_refs_with_exact_scalar_matches':exactrefs,'new_regular_refs_without_exact_scalar_matches':2279-exactrefs,'new_regular_refs_with_substring_scalar_matches':substringrefs,'new_regular_refs_without_substring_scalar_matches':2279-substringrefs,'all_matching_scalar_relations':allscalarmatches,'all_overlapping_matching_occurrences':alloccurrences,'saved_metadata_read_bindings':len(bindings),'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'new_regular_BODY_reads':0,'new_directory_queries':0,'recursive_queries':0,'candidate_executions':0,'query_permission_from_matches_or_nonmatches':None,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'NEW_ALL2279_private_exact_regular_scope_PRIVATE':private_scope,'NEW_ALL2279_explicitly_derived_public_safe_scope':public_scope,'ALL2279_NEW_fullreference_prior_CP_relationships_PRIVATE':consumed,'original2308_ALL_fields_PRIVATE_preserved':original,'original_prior_CP_ALL_fields_PRIVATE_preserved':priorcp,'ALL_prior_CP_scalars_PRIVATE':scalars,'ALL_two_savedmetadata_read_bindings_PRIVATE_fullstat_times':bindings}
 raw=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL2279-regular-scope-consumption-intake-PRIVATE.json',raw);descriptor={'result_saved':'ROOT-FIRST-ALL2279-regular-scope-consumption-intake-PRIVATE.json','result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-scope-result.json',before);d=json.loads(before);d['actions_include_great_great_grandchild_regular_scope_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL2279_regular_BODYINPUT_lexicalscope_and_priorCP_fullreference_relationships_NOT_queried_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(raw),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_grandchild_regular_scope='COMPLETE_CONSUMED_summary_publication_pending',next=v['after_scope_next']);d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
