import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0808_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-directory-inputs-v1';O=B/'2026-11-07-actions-include-regular-interiors-v1/FIRST-physical-directive-reader-v1/ALL160-exact-body-declaration-BEFORE-body-IO.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST ALL49saved directory explicit literalparent-plus-EACH-SINGLEbasename NEWcandidate-text declaration. One savedmetadata source only, no currentSDK/directoryquery/recursion/headerbody/Actions/build/Source20-runtime adoption. Original49DEFERRED flags remain unchanged at earlier epochs; newlexicalcandidate epoch distinct, does not imply effectivecompiler/sysroot/alias/access/ownership/admission. ALL210safe originalmetadata and160latelexicalepochs/1ncurses literal curses/readlinkhexNULL protected; no favorabletype/language-version-ABI filter. ALL576rawrelationships184matches391nonmatches1unperformedNULL notqueryauthority.',
 'exact_saved_source':str(O),'bounded_range':[0,440141],'saved_bytes':440141,'saved_sha256':'f900f8e7c61f96b1e1eabdd8268f06ec6b2076ff1ec8c5babe539779e9182834','all_admission_flags':False,'ownership':None}
 save('FIRST-lexical-scope-declaration.json',json.dumps(declaration,indent=2));save('FIRST-lexical-scope-controller.py',sys.argv[1])
 binding={'role':'FIRST_NEW_ALL49literal_candidate_text_metadata','path':str(O),'before_open_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};fd=os.open(O,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd
 try:
  s=os.fstat(fd);before={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']};assert stat.S_ISREG(s.st_mode) and s.st_size==440141
  pieces=[];h=hashlib.sha256()
  while True:
   chunk=os.read(fd,65536)
   if not chunk:break
   pieces.append(chunk);h.update(chunk)
  raw=b''.join(pieces);assert len(raw)==440141 and h.hexdigest()==declaration['saved_sha256'];z=os.fstat(fd);after={k:getattr(z,k) for k in before};assert before==after;binding.update(before=before,after=after,bytes=len(raw),sha256=h.hexdigest(),read_EOF=True)
 finally:os.close(fd);binding['close_return_fd']=fd
 d=json.loads(raw);ledger=d['preserved_original_metadata_NOT_revalidated'];safe=ledger['ALL210_include_original_safe_entry_metadata'];dirs=ledger['ALL49_include_deferred_directories_NO_query_recursion'];assert len(safe)==210 and len(dirs)==49
 assert [x for x in safe if x['saved_type_derived_from_original_mode']=='directory']==dirs
 relations=[]
 for entry in dirs:
  parent=entry['source_parent_reference'];name=entry['literal_entry_name'];assert parent=='/usr/include' and name not in ['','.','..'] and '/' not in name and '\0' not in name
  assert bytes.fromhex(entry['original_name_bytes_hex']).decode('utf-8','surrogateescape')==name and entry['reference_NOT_lexically_joined_expanded_followed_resolved_or_executed'] is True
  relations.append({'original_complete_separate_parent_name_metadata':entry,'NEW_explicit_lexical_candidate_text':parent+'/'+name,'NEW_declaration_epoch':'FIRST_ALL49_after_ALL576_source_relationships_COMPLETE_CONSUMED','relation':'EXPRESS_NEW_literal_parent_plus_SINGLEliteralbasename_TEXT_ONLY_NOT_resolve_alias_identity_defaultcompiler_sysroot_ABI_access_or_queryproof','original_epoch_flags_unchanged':True})
 refs=[r['NEW_explicit_lexical_candidate_text'] for r in relations];assert len(refs)==49 and len(set(refs))==49
 scope={'phase':'FIRST_ALL49_explicit_lexical_directory_INPUT_scope_DECLARED_NOT_queried','source_original_parent_run':42311168556,'source_original_parent_commit':'67481dc3b8e828b5720e35d1543727ec60669360','ALL49_new_literal_directory_references':refs,'ALL49_new_explicit_lexical_relations':relations,'preserved_original_metadata_NOT_revalidated':ledger,'ALL_original49_DEFERRED_epoch_flags_UNCHANGED':True,'new_directory_query_count':0,'candidate_execution_count':0,'recursive_walk_count':0,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 save('original-saved-declaration-bound-PRIVATE.json',raw);save('FIRST-lexical-metadata-binding-PRIVATE.json',json.dumps(binding,indent=2));save('ALL49-new-explicit-input-scope.json',json.dumps(scope,ensure_ascii=True,indent=2)+'\n')
 cp=B/'current-task-checkpoint.json';cpraw=cp.read_bytes();save('checkpoint-before-lexical-scope.json',cpraw);data=json.loads(cpraw);data['actions_include_directory_inputs_v1']={'directory':str(P),**scope,'public_documentation_pending':True};data['active_turn_status']['next']='ALL49NEWliteral directoryscope expresslydeclared, no query yet; prepare scoped ORIGINALActions onelevel metadata collector/source with unchanged29oldjobs/originalLinux-Dart-Rust settings and allpriorledgers before FIRSTnewreview/Actions execution. No oldworkreplay/candidateexecution/recursion/headerbodies/bootstrap/build/numerical/Source20-runtime adoption; allsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-FINALstrict48/50-cleanCI incomplete.';data['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();data['updated_at']=data['updated_utc'];cp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'phase':scope['phase'],'ALL49_NEW_explicit_candidate_texts':refs,'preserved_counts':{'ALL210':210,'ALL160latelexical':160,'ALL49originaldeferred':49,'ALL1symlink':1},'native_directory_queries':0,'all_admission_flags':False}),flush=True);lease.verify_identity()
