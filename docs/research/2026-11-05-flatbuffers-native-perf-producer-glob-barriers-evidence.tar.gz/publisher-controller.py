import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-glob-barriers-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-glob-barriers'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='e253c5f0a84e7fdbfcbd060a14fdf96c96d863ee'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Check glob context before consuming its iterator\n\nA native glob callback could replace the producer's outputs dictionary, yet the old compound expression consumed the filesystem iterator before checking that identity change. The glob branch now preserves its original evaluation order while recording each Path/parent/method/name/call/sorted intent and raw return, checking context before the next operation. Caller data remains changed; there is no restoration or copying away. Unknown parent/name/sorted returns stay unknown despite ROOT-known values. Known None glob return remains distinct from an unknown sorted TypeError return. These are Source DATA, not ownership or EX/admission.\n\nNEW6 at410d61/2b57de yields5FAIL/1normalPASS/0ERROR: one continued-iteration context gap and four stronger return-witness policies, not five spontaneous kernel bugs or a RAM cause. Finalbd0cfe/98a966 passes13selected=6matchingNEW+7affected glob controls. Existing affected tests strengthen only metadata assertions for the new row schema; behavior assertions remain exact. Old test prefix is not exact; reversing that edit and the new append restores all prior test bytes. Historical artifacts stay untouched. Twelve new views plus7affected views/12BEFORE26AFTER currentDarwinEX observations and same-bound ROOT waits remain UNIT facts, not full independent EX/originalLinuxcredentials. Qwen50119 hits tokenlimit1/full partial final ABSENT; GLM51011 completes0/fullanswer, ROOTqualified. Privatev1 is unexecuted before ROOTv2 normal metadata-oracle correction/first BEFORE; candidatev1 is unexecuted before edit. ROOT qualifies final whole source/tests/AST/projections,23hashes/other18helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty. No unchanged controls/models/numerical replay, aggregate/current20canonical/admission, SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-glob-barriers'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: guard glob context before iterator consumption'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_glob_barriers'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Remaining_glob/Path earlierattribute-bindings-metadata-returnshapes/calleeinteriorintent-globalconcurrentABA; otherend-enclosing-publicunknownCtorretention; writer-hash-init/nativeFD seams; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Currentbd0cfe/98a966 ONLYcompoundglob expanded originalPath1-parent-boundglob-Path2-name-call-sorted with percallintent/raw/contextAFTEReach, scoped13PASS=6matchingNEW7affectedglobcontrols. NEW6before410d61/2b57de=5FAIL1normalPASS0ERROR:1actualgloboutputsidentitydrift continuedFSiteration beforelatecontextrefusal+4returnwitness policies NOT5nativekernelbugs/RAMcause. Driftedoutputs remainsforeign/no restore-copyfreeze; knownSourceglob ROOTwrapperiterator/nativeunderlying distinct; unknownparent-name-sortedraw neverROOTknownrefs adopted; globNone knownNone-returnedTrue/sortedTypeError unknownreturnedFalse. Normalmixed3 globB-direct-globA/2nativeglobs/allbytes-SHA-hashorder preserved. OldtestPREFIX NOTexact/wholetestBYTEprojectback viaonlyaffectedclassmetadataassertionsstrengthened+newappend/behaviorassertionsexact/historyartifactsuntouched.12newviews+7affected/EX12before26after/6+6newRootwait0cached/7affectedseparate0 UNITnotfullEX-originalLinux/fullFD-delegate-descendantclosure; iterator/listrefs notfullFD-lifecycle/closed-exhausted/no cancellation-reset-recovery. Qwen50119limit1/0out527err/fullpartialfinalABSENT/reapednotunavailabilityapproval/GLM51011=0/full3487out848err/ROOTqualified/rejectFalseassertioneveryentry/attempt=>completion/iteratordiscarded/directpattern/priorfolderreuse-cleanup claims. Privatev1UNEXECUTED beforev2conditionalnormalnewrowassert BEFOREfirst6; candidatev1UNEXECUTEDbeforeedit/modelv1finalSource-privatev2/ROOTwholefinalASTqualified NOTwholecurrentapproval. AllotherSource-methods/helpers/end-wait/nativehash-writer/factories/frozenpredicates exact/23hashes/other18helpers3bins4NEWGit0-BOTH/601ownbranch20untrackedproductionempty DATA. No unchanged7BEFORE/model/numericalreplay-aggregate-current20canonical-admission. UnknownPopenCtorpermanentrefusal/no partialPopenmethods-fieldderivedownerclose; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_glob_barriers_selected13PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
