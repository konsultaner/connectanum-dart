"""NEW per-call glob barriers and owner-context regression controls."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class ProducerGlobBarrierTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)



    def _barrier_case(self,mode):
        calls=[];actors=[];seen={};leases=[];native_iterators=[];yielded=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT glob barrier first')
        native_allocate=producer.CommandProducer._allocate_command_process;native_preserve=producer.CommandProducer._preserve_failure
        native_hash=producer._regular_hash;native_write=producer._write_json;native_event=producer.CommandProducer._event
        native_glob=Path.glob;native_str=Path.__str__;native_parent=Path.parent.fget;native_name=Path.name.fget;native_sorted=sorted
        folder=self.base/'barrier-artifacts';foldertext=native_str(folder)
        patterns=[folder/'left-*.bin']
        files={'left-1.bin':b'BARRIER-left'}
        outputs={'glob_left':patterns[0]}
        if mode=='normal':
            patterns=[folder/'right-*.bin',folder/'left-*.bin'];files.update({'right-1.bin':b'BARRIER-right','direct.dat':b'BARRIER-direct'})
            outputs={'glob_right':patterns[0],'direct':folder/'direct.dat','glob_left':patterns[1]}
        patterntexts={native_str(x) for x in patterns};patternnames={native_name(x) for x in patterns}
        foreign_outputs={'foreign':folder/'not-read.dat'}
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def preserving(p,error):
            calls.append(dict(kind='forbidden_preserver'));return native_preserve(p,error)
        def parenting(path):
            raw=native_parent(path)
            if native_str(path) in patterntexts:
                calls.append(dict(kind='actual_parent'));seen['native_parent']=raw
                if mode=='parent_unknown':raise first
            return raw
        def naming(path):
            raw=native_name(path)
            if native_str(path) in patterntexts:
                calls.append(dict(kind='actual_name'));seen['native_name']=raw
                if mode=='name_unknown':raise first
            return raw
        def globbing(path,value,*args,**kwargs):
            if value not in patternnames or native_str(path)!=foldertext:return native_glob(path,value,*args,**kwargs)
            item=dict(native_iterator=None);native_iterators.append(item);calls.append(dict(kind='glob_attempt',pattern=value))
            raw=native_glob(path,value,*args,**kwargs);item['native_iterator']=raw;calls.append(dict(kind='actual_glob_return',pattern=value))
            if mode=='glob_None':
                seen['returned_iterator']=None;seen['glob_return_observed']=True;return None
            def delegating():
                for match in raw:
                    yielded.append(match);calls.append(dict(kind='actual_yield',name=native_name(match)));yield match
            returned=delegating();seen['returned_iterator']=returned;seen['glob_return_observed']=True
            if mode=='outputs_drift':
                seen['producer'].outputs=foreign_outputs;calls.append(dict(kind='ROOT_outputs_alias_changed'))
            return returned
        def sorting(value,*args,**kwargs):
            target=seen.get('glob_return_observed') is True and value is seen.get('returned_iterator')
            if target:calls.append(dict(kind='sorted_attempt'))
            raw=native_sorted(value,*args,**kwargs)
            if target:
                seen['native_sorted']=raw;calls.append(dict(kind='actual_sorted_return',names=[native_name(x) for x in raw]))
                if mode=='sorted_unknown':raise first
            return raw
        def hashing(path):
            if native_str(native_parent(path))==foldertext:calls.append(dict(kind='output_hash_attempt',name=native_name(path)))
            return native_hash(path)
        def writing(path,value):
            if native_name(path)=='result.json':calls.append(dict(kind='result_write_attempt'))
            return native_write(path,value)
        def event(p,name,**fields):
            if name=='finished':calls.append(dict(kind='finished_event_attempt'))
            return native_event(p,name,**fields)
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer.CommandProducer,'_preserve_failure',preserving),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer.CommandProducer,'_event',event):
                code="import os;os.mkdir("+repr(foldertext)+");"
                for name,data in files.items():
                    code+="fd=os.open("+repr(native_str(folder/name))+",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.write(fd,"+repr(data)+");os.close(fd);"
                code+="os.write(1,b'BARRIER-out');os.write(2,b'BARRIER-err')"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],outputs=outputs,lease_check=verifying);seen['producer']=p;seen['original_outputs']=p.outputs
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(Path,'parent',property(parenting)),mock.patch.object(Path,'name',property(naming)),mock.patch.object(Path,'glob',globbing),mock.patch.object(producer,'sorted',sorting,create=True):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                if mode!='normal':
                    try:producer._finish_publication_guard(p)
                    except BaseException as error:guard_error=error
            record=next(r for r in producer._FINISH_PUBLICATION_RECORDS if r['owner'] is p);rows=record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,received_type=None if received is None else type(received).__name__,received_first=received is first,
                pure_guard_same_received=received is not None and guard_error is received,Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],
                Source_evidence_complete=p.evidence_complete,Source_result_None=p.result is None,Source_outputs_foreign=p.outputs is foreign_outputs,
                record_original_outputs=record['outputs'] is seen['original_outputs'],record_original_journal=record['events'] is seen['journal']['obj'],record_primary_received=record['primary_error'] is received,record_completed=record['completed'],
                original_journal_closed=seen['journal']['obj'].closed,result_exists=(p.directory/'result.json').exists(),failure_exists=(p.directory/'failure.json').exists(),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_is_ROOTreturned_iterator='returned_iterator' in seen and r['raw'] is seen['returned_iterator'],error_first=r.get('error') is first) for r in rows],
                ROOT_yield_names=[native_name(x) for x in yielded],ROOT_native_sorted_known='native_sorted' in seen,ROOT_native_parent_known='native_parent' in seen,ROOT_native_name_known='native_name' in seen,
                calls=list(calls),leases=leases,limits='ActualnativePath-parent-name-glob/modulelocal sorted wrapper/ownunitfiles. Unknown Sourceparent-name-sortedraw neverROOTknownrefs adopted. Calleroutputsdrift remainsdrifted, no restore/freeze. Negativeonlypureguard; ROOTsameknownboundwait+FDdevino cleanup AFTERevidence UNITnotSourcecleanup-ownership-fullEX-originalLinux/fullactorclosure/admission. Nativeiterator lifecycle/FDclosed/exhaustion incomplete/no cancellation/recovery.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases));self.assertTrue(record['outputs'] is seen['original_outputs'])
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertTrue(record['completed']);self.assertTrue(p.evidence_complete);self.assertEqual('success',result['status'])
                self.assertEqual(['glob_right','direct','glob_left'],list(result['outputs']));expected=['right-1.bin','direct.dat','left-1.bin']
                self.assertEqual(expected,[x['name'] for x in calls if x['kind']=='output_hash_attempt'])
                self.assertEqual(b'BARRIER-outBARRIER-err',(p.directory/'command-000.log').read_bytes())
                for role,name in zip(outputs,expected):
                    self.assertEqual(files[name],(folder/name).read_bytes());self.assertEqual(hashlib.sha256(files[name]).hexdigest(),result['outputs'][role]['sha256'])
                self.assertEqual(2,len(native_iterators));self.assertEqual(['right-1.bin','left-1.bin'],[native_name(x) for x in yielded])
                self.assertEqual(2,sum(r['stage']=='output_glob_sorted' and r['returned'] for r in rows))
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(record['primary_error'] is received);self.assertFalse(record['completed'])
                if mode in ('parent_unknown','name_unknown','sorted_unknown'):self.assertTrue(received is first)
                elif mode=='glob_None':self.assertTrue(type(received) is TypeError)
                else:self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(p.outputs is foreign_outputs);self.assertFalse(any(x['kind']=='actual_yield' for x in calls))
                self.assertFalse(any(x['kind'] in ('forbidden_preserver','repr_first','note_first','output_hash_attempt','result_write_attempt','finished_event_attempt') for x in calls))
                self.assertFalse(p.evidence_complete);self.assertIsNone(p.result);self.assertFalse((p.directory/'result.json').exists());self.assertFalse((p.directory/'failure.json').exists());self.assertFalse(seen['journal']['obj'].closed)
                stage={'outputs_drift':'output_glob_call','glob_None':'output_glob_sorted','parent_unknown':'output_glob_parent','name_unknown':'output_glob_name','sorted_unknown':'output_glob_sorted'}[mode]
                self.assertTrue(any(r['stage']==stage for r in rows))
                row=next(r for r in rows if r['stage']==stage)
                if mode=='outputs_drift':self.assertTrue(row['returned']);self.assertTrue(row['raw'] is seen['returned_iterator']);self.assertFalse(any(r['stage']=='output_glob_sorted' for r in rows))
                else:self.assertFalse(row['returned']);self.assertIsNone(row['raw'])
                if mode=='glob_None':
                    entry=next(r for r in rows if r['stage']=='output_glob_call');self.assertTrue(entry['returned']);self.assertIsNone(entry['raw'])
                if mode in ('parent_unknown','name_unknown'):self.assertEqual(0,len(native_iterators))
                if mode=='sorted_unknown':self.assertTrue('native_sorted' in seen);self.assertEqual(['left-1.bin'],[native_name(x) for x in yielded])
                count=len(calls)
                try:producer._finish_publication_guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('globbarrier pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed and item['obj'] is not raw:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')


    def test_actual_glob_then_outputs_drift_stops_before_native_iteration(self):self._barrier_case('outputs_drift')
    def test_actual_native_sorted_then_error_keeps_Source_unknown_list(self):self._barrier_case('sorted_unknown')
    def test_actual_glob_then_None_records_knownNone_before_sorted_TypeError(self):self._barrier_case('glob_None')
    def test_actual_parent_getter_then_error_keeps_Source_unknown_parent(self):self._barrier_case('parent_unknown')
    def test_actual_name_getter_then_error_keeps_Source_unknown_name(self):self._barrier_case('name_unknown')
    def test_new_normal_two_globs_and_direct_preserve_order_and_bytes(self):self._barrier_case('normal')
