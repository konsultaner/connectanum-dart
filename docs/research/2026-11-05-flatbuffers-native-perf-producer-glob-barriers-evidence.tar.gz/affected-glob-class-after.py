class ProducerGlobCoverageTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)



    def _glob_case(self,mode):
        calls=[];actors=[];seen={};leases=[];native_iterators=[];yielded=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT glob first')
        native_allocate=producer.CommandProducer._allocate_command_process
        native_preserve=producer.CommandProducer._preserve_failure
        native_hash=producer._regular_hash;native_write=producer._write_json;native_event=producer.CommandProducer._event;native_glob=Path.glob;native_str=Path.__str__
        folder=self.base/'artifacts';foldertext=native_str(folder);pattern=folder/'one-*.bin'
        files={} if mode=='glob_zero' else {'one-1.bin':b'GLOB-one1'}
        if mode=='glob_two':files['one-2.bin']=b'GLOB-one2'
        if mode=='normal_multi':files.update({'direct-b.dat':b'GLOB-direct-b','direct-a.dat':b'GLOB-direct-a'})
        outputs={'glob':pattern}
        if mode=='normal_multi':outputs.update({'direct_b':folder/'direct-b.dat','direct_a':folder/'direct-a.dat'})
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def preserving(p,error):
            calls.append(dict(kind='forbidden_preserver',input_first=error is first));return native_preserve(p,error)
        def globbing(path,value,*args,**kwargs):
            target=value=='one-*.bin' and native_str(path)==foldertext
            if not target:return native_glob(path,value,*args,**kwargs)
            item=dict(native_iterator=None);native_iterators.append(item);calls.append(dict(kind='native_glob_attempt'))
            raw=native_glob(path,value,*args,**kwargs);item['native_iterator']=raw;calls.append(dict(kind='native_glob_actual_return'))
            if mode=='glob_enter_unknown':raise first
            if mode=='glob_False':return False
            def delegating():
                for match in raw:
                    yielded.append(match);calls.append(dict(kind='actual_native_yield',name=match.name));yield match
                    if mode=='glob_yield_unknown':raise first
            return delegating()
        def hashing(path):
            target=native_str(path.parent)==foldertext
            if target:calls.append(dict(kind='output_hash_attempt',name=path.name))
            return native_hash(path)
        def writing(path,value):
            if path.name=='result.json':calls.append(dict(kind='result_write_attempt'))
            return native_write(path,value)
        def event(p,name,**fields):
            if name=='finished':calls.append(dict(kind='finished_event_attempt'))
            return native_event(p,name,**fields)
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer.CommandProducer,'_preserve_failure',preserving),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer.CommandProducer,'_event',event):
                code="import os;os.mkdir("+repr(foldertext)+");"
                for name,data in files.items():
                    code+="fd=os.open("+repr(native_str(folder/name))+",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.write(fd,"+repr(data)+");os.close(fd);"
                code+="os.write(1,b'GLOB-out');os.write(2,b'GLOB-err')"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],outputs=outputs,lease_check=verifying)
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(Path,'glob',globbing):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                guard=producer._finish_publication_guard
                if not mode.startswith('normal'):
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in producer._FINISH_PUBLICATION_RECORDS if r.get('owner') is p];self.assertEqual(1,len(records))
            record=records[0];rows=record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,result_status=None if result is None else result['status'],
                received_type=None if received is None else type(received).__name__,received_first=received is first,
                Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],
                Source_evidence_complete=p.evidence_complete,Source_result_None=p.result is None,original_journal_closed=seen['journal']['obj'].closed,
                failure_exists=(p.directory/'failure.json').exists(),result_exists=(p.directory/'result.json').exists(),
                pure_guard_same_received=received is not None and guard_error is received,record_original_journal=record['events'] is seen['journal']['obj'],
                record_primary_received=record['primary_error'] is received,record_completed=record['completed'],
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None) for r in rows],
                ROOT_native_iterator_count=len(native_iterators),ROOT_yield_names=[x.name for x in yielded],
                Source_glob_return_serialized=False,Source_sorted_list_serialized=False,
                output_roles=None if result is None else list(result['outputs']),calls=list(calls),leases=leases,
                limits='CoverageONLY/producerunchanged. ROOTiterator/yield refs neverfillSource glob/sortedraw orpartiallist; percallglob APIs notSourcejournalled/notreconstructed. Allfield-handle-hash-status-closed facts DATA notauth-ownership-fullEX-originalcredentials/fullactorclosure/admission/RAMcause. Negativepureguardonly; ROOTsameboundwait+FDdevino cleanup AFTERevidence UNITnotSourcecleanup. Nativepartialiterator lifecyclenotfullFDcensus/closure; no generator cancellation/reset/recovery.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases));self.assertEqual(1,len(native_iterators))
            self.assertTrue(native_iterators[0]['native_iterator'] is not None)
            self.assertFalse(any(c['kind'] in ('forbidden_preserver','repr_first','note_first') for c in calls))
            if mode.startswith('normal'):
                self.assertTrue(returned);self.assertIsNone(received);self.assertEqual('success',result['status']);self.assertTrue(record['completed'])
                self.assertTrue(p.evidence_complete);self.assertEqual(b'GLOB-outGLOB-err',(p.directory/'command-000.log').read_bytes())
                self.assertEqual(list(outputs),list(result['outputs']))
                expected_names=['one-1.bin']+(['direct-b.dat','direct-a.dat'] if mode=='normal_multi' else [])
                self.assertEqual(expected_names,[x['name'] for x in calls if x['kind']=='output_hash_attempt'])
                for role,name in zip(outputs,expected_names):
                    self.assertEqual(files[name],(folder/name).read_bytes());self.assertEqual(hashlib.sha256(files[name]).hexdigest(),result['outputs'][role]['sha256'])
                    self.assertEqual(native_str(folder/name),result['outputs'][role]['path'])
                self.assertEqual(['one-1.bin'],[x.name for x in yielded])
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(record['primary_error'] is received)
                if mode in ('glob_enter_unknown','glob_yield_unknown'):self.assertTrue(received is first)
                elif mode=='glob_False':self.assertTrue(type(received) is TypeError)
                else:self.assertTrue(type(received) is producer.ProducerError)
                self.assertFalse(record['completed']);self.assertFalse(p.evidence_complete);self.assertIsNone(p.result)
                self.assertFalse((p.directory/'failure.json').exists());self.assertFalse((p.directory/'result.json').exists())
                self.assertFalse(seen['journal']['obj'].closed);self.assertTrue(p.events is seen['journal']['obj'])
                prefix=['output_pattern','output_glob_parent_path','output_glob_parent','output_glob_method','output_glob_name_path','output_glob_name','output_glob_call']
                self.assertEqual(prefix if mode=='glob_enter_unknown' else prefix+['output_glob_sorted'],[r['stage'] for r in rows]);self.assertTrue(rows[0]['returned'])
                if mode in ('glob_enter_unknown','glob_yield_unknown','glob_False'):self.assertFalse(rows[-1]['returned']);self.assertIsNone(rows[-1]['raw'])
                else:self.assertTrue(rows[-1]['returned']);self.assertTrue(type(rows[-1]['raw']) is list);self.assertEqual(2 if mode=='glob_two' else 0,len(rows[-1]['raw']))
                if mode=='glob_False':
                    entry=next(r for r in rows if r['stage']=='output_glob_call');self.assertTrue(entry['returned']);self.assertTrue(entry['raw'] is False)
                self.assertFalse(any(x['kind'] in ('output_hash_attempt','result_write_attempt','finished_event_attempt') for x in calls))
                expected_yields=1 if mode=='glob_yield_unknown' else (2 if mode=='glob_two' else 0)
                self.assertEqual(expected_yields,len(yielded))
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('glob pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed and item['obj'] is not raw:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')


    def test_actual_glob_entry_then_error_preserves_unknown_Source_return(self):self._glob_case('glob_enter_unknown')
    def test_actual_native_yield_then_error_preserves_first_and_no_partial_adoption(self):self._glob_case('glob_yield_unknown')
    def test_actual_glob_iterator_then_False_keeps_native_sorted_TypeError(self):self._glob_case('glob_False')
    def test_actual_zero_matches_refused_before_hash_or_publication(self):self._glob_case('glob_zero')
    def test_actual_two_matches_refused_before_hash_or_publication(self):self._glob_case('glob_two')
    def test_new_normal_single_glob_bytes_hash_resolved_path(self):self._glob_case('normal_glob')
    def test_new_normal_mixed_three_outputs_preserve_insertion_and_hash_order(self):self._glob_case('normal_multi')