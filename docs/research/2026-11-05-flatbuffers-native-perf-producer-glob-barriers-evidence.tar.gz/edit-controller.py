import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-glob-barriers-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in oldh.items())
 assert json.loads((P/'candidate-ROOT-projection.json').read_text())['wholeSource_BYTE_projectsback']
 source=(P/'candidate-v1.py').read_bytes();tests=(P/'affected-tests-updated-v1.py').read_bytes()+b'\n\n'+(P/'glob_barrier_regressions-v2.py').read_bytes();ast.parse(source);ast.parse(tests)
 oldclass=(P/'affected-glob-class-before.py').read_text();newclass=(P/'affected-glob-class-after.py').read_text()
 assert (P/'affected-tests-updated-v1.py').read_text().replace(newclass,oldclass,1)==(P/'before-tests.py').read_text()
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(tests)
 h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').open('xb').write(source);(P/'after-tests.py').open('xb').write(tests);(P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2))
 v=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],wholeSource_BYTE_projectsback=True,whole_existing_tests_BYTE_projectsback=True,oldtests_PREFIX_exact=False,affected_glob_class_only_metadata_assertions_strengthened=True,behaviorassertions_unchanged=True,other18helpers3bins_unchanged=True,only_glob_branch_Sourcechanged=True,no_historical_artifact_rewrite=True,no_ownership_fullEX_admission_authority=True)
 (P/'edit-result.json').open('x').write(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_glob_barriers'].update(Source_UNCHANGED=False,edit=v,model_pending=False,after_pending=True);c['active_turn_status']='Producer_glob_barriers_NEW6_before5FAIL1PASS_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
