import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-glob-barriers-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts-v1.json').read_text());private=(P/'glob_barrier_regressions-v2.py').read_bytes()
 assert source==(P/'candidate-v1.py').read_text() and source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 updated=(P/'affected-tests-updated-v1.py').read_bytes();assert tests==updated+b'\n\n'+private
 assert updated.decode().replace((P/'affected-glob-class-after.py').read_text(),(P/'affected-glob-class-before.py').read_text(),1)==(P/'before-tests.py').read_text()
 ast.parse(source);ast.parse(tests);assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(6,5,1,0);assert(a['tests'],a['failures'],a['errors'])==(13,0,0)
 assert len(b['leases'])==12 and len(a['leases'])==26 and all(x['raw_None'] for x in b['leases']+a['leases'])
 def views(path,key):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if key in v}
 old=views(P/'before-units/fixtures','Source_outputs_foreign');new=views(P/'after-selected/fixtures','Source_outputs_foreign');affected=views(P/'after-selected/fixtures','ROOT_native_iterator_count')
 assert len(old)==len(new)==6 and len(affected)==7
 assert old['outputs_drift'][0]['ROOT_yield_names']==['left-1.bin'] and old['outputs_drift'][0]['Source_outputs_foreign']
 waits={};cleanup={}
 for phase,data in [('before',old),('after-new',new),('after-affected',affected)]:
  rows=[x for v,d in data.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text())];w=[x for x in rows if x.get('kind')=='ROOT_same_original_bound_wait']
  assert len(w)==(7 if phase=='after-affected' else 6) and all(type(x['status']) is int and x['status']==0 for x in w)
  waits[phase]=w;cleanup[phase]=rows
  for x in rows:
   if x.get('kind') in ('ROOT_known_log','ROOT_known_journal'):assert x['raw_closed_after']
 for mode,(v,d) in new.items():
  assert v['public_producer_returned'] and not v['Source_pending'] and v['Source_finished'] and v['Source_returncode']==0 and v['record_original_outputs'] and v['record_original_journal']
  assert all(x['raw_None'] for x in v['leases'])
  assert not any(x['kind'] in ('forbidden_preserver','repr_first','note_first') for x in v['calls'])
  rows=v['Source_steps']
  if mode=='normal':
   assert v['wait_returned'] and v['record_completed'] and v['Source_evidence_complete'] and v['ROOT_yield_names']==['right-1.bin','left-1.bin']
   assert sum(x['stage']=='output_glob_sorted' and x['returned'] for x in rows)==2
   assert [x['name'] for x in v['calls'] if x['kind']=='output_hash_attempt']==['right-1.bin','direct.dat','left-1.bin']
  else:
   assert not v['wait_returned'] and v['pure_guard_same_received'] and v['record_primary_received'] and not v['record_completed'] and v['Source_result_None']
   assert not v['Source_evidence_complete'] and not v['result_exists'] and not v['failure_exists'] and not v['original_journal_closed']
   assert not any(x['kind'] in ('output_hash_attempt','result_write_attempt','finished_event_attempt') for x in v['calls'])
   if mode=='outputs_drift':
    assert v['Source_outputs_foreign'] and v['ROOT_yield_names']==[]
    row=next(x for x in rows if x['stage']=='output_glob_call');assert row['returned'] and row['raw_is_ROOTreturned_iterator']
    assert not any(x['stage']=='output_glob_sorted' for x in rows)
   elif mode=='glob_None':
    assert v['received_type']=='TypeError' and not v['received_first'] and not v['ROOT_native_sorted_known']
    row=next(x for x in rows if x['stage']=='output_glob_call');assert row['returned'] and row['raw_None']
    row=next(x for x in rows if x['stage']=='output_glob_sorted');assert not row['returned'] and row['raw_None']
   else:
    assert v['received_first'];stage={'parent_unknown':'output_glob_parent','name_unknown':'output_glob_name','sorted_unknown':'output_glob_sorted'}[mode]
    row=next(x for x in rows if x['stage']==stage);assert not row['returned'] and row['raw_None'] and row['error_first']
    if mode=='sorted_unknown':assert v['ROOT_native_sorted_known'] and v['ROOT_yield_names']==['left-1.bin']
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]}
 assert models['Qwen']['status']==1 and not(P/'test-planning/answer.txt').exists() and models['GLM']['status']==0
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'ONLYcompoundglobbranch expands exactoriginalevaluation order Path1-parent-boundglob-Path2-name-call-sorted with percallintent/raw/contextAFTEReach beforelaterIO. Normal2Pathconversions perglob unchanged/no extraresolve/callback/copyfreeze/restore. AllotherSource methods/modulehelpers/endcommand/wait/nativehash-writer/privatefirst/factories/sharedstep/frozenpredicates byteexact; wholeSourceBYTEprojectback.',
 'NEW6 BEFORE5FAIL1normalPASS0ERROR:1actualglob-thenoutputsidentitydrift continuednativeFSiteration beforelatecontextrefusal +4strongerreturnwitness policies(parent/name/sortedunknown/knownNoneiterator). Oldfirstalreadyescapesin4; NOT5nativekernelbugs/RAMcause. AFTER13PASS=6matchingNEW+7affectedglobcontrols. No previous7glob BEFORE/unchangednonglob-end-writer-hash/model-numericalreplay/aggregate-fullcurrent20canonical-admission.',
 'ActualnativePath.parent/name/actualsortedreturns thenROOTfirst SourceunknownrawNone-returnedFalse neverROOTknownparent-name-list adopted. Nativeglob underlyingiterator retainedROOT; SourceglobrawknownreturnedROOTwrapperiterator distinct. GlobNone rowknownNone-returnedTrue, sortedactualTypeError rowunknown-returnedFalse; actualSourceTypeErrorfirst notROOTFirst. Driftedcalleroutputs remainsforeign/no restore-copyfreeze; contextrefusesbefore sorted/yield afteractualglobreturn. Callerpostreturn cannotpreventops alreadyinsidecallee.',
 'Normaldistinctmixed3 globB-direct-globA/fullBARRIER-outBARRIER-err/unitfilebytes-nativeSHA-hashorder/2actualnativeglobs preserved. Sourcefields/refs/methods/Path/list/digest/completed DATA notsemanticimageauth-atomicABA-originalcredentials-ownership-EXrelease/admission. Iterator/list/traceback refs retainednotfullFD-lifecycle/exhaustion/closure; no cancellation-reset-recovery. Unitfiles NOTbenchmarkfreshbody-SDK-Dartbroker-admission.',
 '12newviews=6BEFORE6AFTERnew plus7affectedglobviews separate;12BEFORE26AFTER parentCURRENT officialDarwinEXverifyNone/SourcecallbacksNone UNITnotfullindependentEX-originalLinux/fullFD-interpreter-delegate-descendantclosure.6+6newRootboundwait10 signed0cached/7affectedseparate0. KnownFDpathdevino cleanup AFTERevidence UNITnotSourcecleanup-liveownership-EXrelease. Setup/internalFD/APIreturnsnotallserialized/no reconstruction-globalPIDscan-kill-globalabsence-fullreap.',
 'Existingaffected7class ONLYmetadataoracle strengthened fornewSource row schema; behaviorassertions exact. OldtestPREFIX NOTexact; reversingclassmetadatachange+newclassappend restoreswholeoldtestbytes. Historicalprivatev1/7PASS artifact untouched. PrivateNEWv1 UNEXECUTED beforeROOTv2 conditionalnormal-newrow assertion correction BEFOREfirstBEFORE (negativewitnesses strict). Candidatev1UNEXECUTEDbeforeedit/modelreviewv1 finalsource/privatev2. No inventedtestfailures or unchangedcontrolreplay.',
 'Qwen50119planning tokenlimit1/0stdout527stderr/BOTH EOF/reaped/fullpartialfinalABSENT/notreconstructed/reachableNOTunavailability-approval/no unchangedmodelrepeat. GLM51011review0/full3487stdout848stderr/fullanswer ROOTqualified/rejectFalseassertioneveryglobentry (onlyglob_False), sortedNoneattempt=>completion, nativeiteratordiscarded (retained), patternincludesdirect.dat, priorfolderreuse-cleanup speculation (freshmkdtemp/O_EXCL). No modelwholecurrentapproval/Sourcefixfromadvisory; ROOTwholefinalSource-tests-AST qualified.',
 'Strongowner-groups/primary-secondary/rows/Path-iterator-list-refs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact/23hashes/other18helpers3bins unchanged/4NEWGit0-BOTH/601ownbranch20untrackedproductionempty DATA. No Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse. Otherearliermetadata/calleeinterior/globalABA/historical-transitive/fullindependentEX-immutableCOMPLETEruntimeadmission incomplete. Storagefloors/recheck DATAnotbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.'
 ]
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=6,failures=5,passes=1,errors=0,scope='1owner-contextcontinuediteration gap+4percallwitness policies NOT5nativebugs/RAMcause'),after=a,
 ROOT=dict(wholeSource_BYTE_projectsback=True,whole_existing_tests_BYTE_projectsback=True,oldtests_PREFIX_exact=False,affected_glob_metadata_assertions_only_strengthened=True,behaviorassertions_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=12,affected_glob_views=7,parent_BEFORE_EXverify_None=12,parent_AFTER_EXverify_None=26,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup),models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True),limits=limits,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_glob_barriers'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,ROOT_pending=False,docs_pending=True);c['active_turn_status']='Producer_glob_barriers_selected13PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected13PASS=True,new_views=12,affected_views=7,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
