import sys,pathlib,json,hashlib,stat,errno,os
q=pathlib.Path(sys.argv[1]);q.mkdir()
def save(name,v):
 with (q/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
p=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=p.lstat();assert stat.S_ISREG(s.st_mode) and (s.st_uid,s.st_gid,s.st_size)==(501,20,35983);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
save('official-input-before-import.json',dict(path=str(p),uid=s.st_uid,gid=s.st_gid,size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),body_not_copied=True))
sys.path.insert(0,str(p.parent));import ollama_companion as m
try:
 with m.local_resource_lease(exclusive=True) as lease:
  lease.verify_identity();save('unexpected-acquired.json',dict(pid=os.getpid(),acquired=True));print(json.dumps(dict(event='EX_ACQUIRED_UNEXPECTED',pid=os.getpid())))
except m.LocalResourceLeaseError as error:
 cause=error.__cause__;matched=type(cause) is BlockingIOError and cause.errno in (errno.EAGAIN,errno.EACCES) and str(error)=='local resource lease unavailable: local companion request is active'
 row=dict(pid=os.getpid(),event='EX_REFUSED',error_type=type(error).__name__,text=str(error),native_cause_type=type(cause).__name__,native_errno=getattr(cause,'errno',None),matched_exact_native_conflict=matched)
 save('actual-native-refusal.json',row);print(json.dumps(row));raise SystemExit(78 if matched else 1)
