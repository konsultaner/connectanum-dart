import sys,pathlib,json,subprocess,hashlib
P=pathlib.Path("/tmp/connectanum-native-perf-keeper-release-order-v1");source=pathlib.Path(sys.argv[1]);phase=sys.argv[2];q=P/phase;q.mkdir();rows=[]
def save(name,v):
 with (q/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
for mode in ('publication-first','eof-caller'):
 argv=[sys.executable,str(P/'guarded-harness.py'),str(q/(mode+'-Source')),mode,str(source),str(q/(mode+'-ROOT'))]
 save(mode+'-attempt-before.json',dict(argv=argv,Popen_attempted=True,pid=None))
 p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;outstream=p.stdout;errstream=p.stderr;pid=p.pid
 save(mode+'-native-handles-before-IO.json',dict(pid=pid,original_bound_wait_and_streams_retained=True))
 out,err=p.communicate(input=b'observe\nfinish\n');status=wait(10)
 for name,raw in [('stdout',out),('stderr',err)]:
  with (q/(mode+'-'+name+'.bin')).open('xb') as f:f.write(raw)
 row=dict(mode=mode,pid=pid,status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());rows.append(row);save(mode+'-native-result.json',row)
 if status!=0:
  save('terminal-nonzero-before-unit-assertions.json',dict(rows=rows,no_same_actor_retry_or_next_case=True));print(json.dumps(dict(terminal_actor_error=True,rows=rows)));raise SystemExit(status)
save('BOTH-caller-outcomes-before-unit-assertions.json',dict(rows=rows))
details=[];failed=0
for row in rows:
 mode=row['mode'];d=q/(mode+'-ROOT');view=json.loads((d/'ALL-known-outcomes-BEFORE-unit-assertions.json').read_text())
 child_ok=len(view['child_rows'])==1 and all(x['status']==0 and x['signed_native_int'] and x['both_separate_EOF'] and x['original_communicate_attempts']==1 for x in view['child_rows'])
 context_ok=len(view['contexts'])==1 and view['contexts'][0]['actual_exit_attempts']==view['contexts'][0]['actual_exit_returns']==1
 premature=sum(not x['child_native_collection_observed'] for c in view['contexts'] for x in c['exit_attempts'])
 if mode=='publication-first':
  probe=json.loads((d/'contender/actual-native-refusal.json').read_text());probe_ok=len(view['probe_rows'])==1 and view['probe_rows'][0]['status']==78 and probe['matched_exact_native_conflict'] and probe['native_errno']==35
  ok=child_ok and context_ok and probe_ok and premature==0 and view['received_original_First']
 else:ok=child_ok and context_ok and premature==0 and view['received_type'] is None and not view['publication_fault_injected']
 failed+=not ok;details.append(dict(mode=mode,PASS=bool(ok),premature_exit_attempts=premature,received_type=view['received_type'],received_original_First=view['received_original_First'],context_native_exit_once_after_actual_collection=context_ok,native_child_rows=view['child_rows'],native_probe_rows=view['probe_rows'],actual_premature_native_exit=False))
result=dict(kind='NEW_GUARDED_PRIVATE_KEEPER_RELEASE_ORDER_FIXTURE_ONLY',tests=2,passes=2-failed,failures=failed,errors=0,details=details,parent_two_rows=rows,all_known_native_outcomes_before_unit_assertions=True,Source20_edits_import_or_SDK=False,no_native_premature_release_permitted=True,capture_ready=False,evidence_complete=False,readiness=False,admission=False)
save('result.json',result);print(json.dumps(dict(tests=2,passes=2-failed,failures=failed,errors=0,details=[{k:x[k] for k in ('mode','PASS','premature_exit_attempts','received_type','received_original_First')} for x in details],admission=False)));raise SystemExit(1 if failed else 0)
