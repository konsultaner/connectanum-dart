
import pathlib,hashlib,json,datetime,importlib.util,os,subprocess,stat,tarfile,io
P=pathlib.Path('/tmp/connectanum-native-perf-keeper-release-order-v1')
D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
EXPECTED='ea39756cfb2a49bafc1d1ac9518bc86b33162b47'
PREFIX='docs/research/2026-11-05-flatbuffers-native-perf-keeper-release-order'
SCOPE='NEW private keeper release-order BEFORE2/AFTER2; current20 Source/test unchanged; not SDK/live admission'
common="## 2026-11-05 — Preserve the keeper lease through a publication failure\n\nTwo new private Darwin cases expose one premature context-exit attempt before a known finite child was collected. BEFORE records one failure and one passing EOF caller. A TEST backstop intercepts the exit before native close, retains the original context, confirms an actual official EX conflict, then collects the same child and releases once. No unsafe kernel unlock occurred.\n\nA minimal private candidate collects the known child before attempting context exit. Matching AFTER records two passes, zero premature attempts and the original First exception identity. The EOF caller still passes. Five fixture actors per phase are separate from the two test cases; signed statuses, both streams and SHA/size records were retained before assertions. The private source reverse projection is byte-exact.\n\nQwen planning and GLM judgment are ROOT-qualified. GLM described hypothetical AFTER ordering as established before AFTER ran; the actual matching run was performed later. Unknown constructors, crashes, unexpected collection or context-exit failures, complete actor/FD closure and original Linux ownership remain unproved. This private candidate is not a live SDK controller.\n\nNo current twenty-helper Source/test edit/import, current HEAD/SDK census, runtime checkout operation, SDK/original recipe, build, production native or benchmark capture occurred. All readiness/admission flags remain false. RAM repair, immutable original-runtime admission, final strict 48/50 and clean final CI remain incomplete.\n\n"
note="# Private keeper release-order regression\n\n## 2026-11-05 — Preserve the keeper lease through a publication failure\n\nTwo new private Darwin cases expose one premature context-exit attempt before a known finite child was collected. BEFORE records one failure and one passing EOF caller. A TEST backstop intercepts the exit before native close, retains the original context, confirms an actual official EX conflict, then collects the same child and releases once. No unsafe kernel unlock occurred.\n\nA minimal private candidate collects the known child before attempting context exit. Matching AFTER records two passes, zero premature attempts and the original First exception identity. The EOF caller still passes. Five fixture actors per phase are separate from the two test cases; signed statuses, both streams and SHA/size records were retained before assertions. The private source reverse projection is byte-exact.\n\nQwen planning and GLM judgment are ROOT-qualified. GLM described hypothetical AFTER ordering as established before AFTER ran; the actual matching run was performed later. Unknown constructors, crashes, unexpected collection or context-exit failures, complete actor/FD closure and original Linux ownership remain unproved. This private candidate is not a live SDK controller.\n\nNo current twenty-helper Source/test edit/import, current HEAD/SDK census, runtime checkout operation, SDK/original recipe, build, production native or benchmark capture occurred. All readiness/admission flags remain false. RAM repair, immutable original-runtime admission, final strict 48/50 and clean final CI remain incomplete.\n\n\nThe declaration precedes the two NEW cases. The publication case injects First only after real ready-file IO returns to ROOT and before the private keeper receives that return. The native child/context handles are retained before publication IO. The backstop distinguishes an attempted exit from actual native release.\n\nBEFORE private source: `6108e1b8ad4e2b8b2b0f54f6bbba7d23ed564ae149e9bdae34887b68d12ebbd4`.\nAFTER private candidate: `205395029ca1a440118ba2bb6961a0bdacb1d32b314c519146a35d97ca8997df`.\nThe original fixture and current production helper bundle were not edited. The candidate has only a known finite-child cleanup path; it does not establish general cleanup or unknown-actor ownership.\n\nEach phase contains two harness keeper actors, two finite children and one negative contender. Each child naturally returns 0 with separate 25-byte stdout and stderr; the contender maps only the actual official lease conflict caused by native EAGAIN35 to fixture status78. A fresh 1GiB floor preceded each case. Storage observations grant no build/capture/deletion authority. ROOT support holds no competing lease while the fixture owns EX.\n\nThe full new declaration, private before/candidate, harness, raw streams, ordering journals, model answers and ROOT qualifications are retained in the evidence archive. No completed old keeper case, old Source suite/model/archive/campaign was replayed. Historical missing raw/API records remain missing.\n\nNext work must define original actor creation/exec/FD registration and independent generated-output/original-cohort authority. Unknown or incomplete actor outcomes remain permanent quarantine. This evidence supplies no original SDK invocation, adoption, production RAM repair or strict acceptance authority.\n"
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
spec=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def newjson(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();Q=P/'publication-v1';Q.mkdir();commands=[]
 def git(*args):
  index=len(commands);argv=['git',*args];newjson(Q/f'git-{index}-attempt-before.json',dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None))
  p=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
  newjson(Q/f'git-{index}-handles-before-IO.json',dict(pid=pid,original_bound_wait_and_streams_retained=True))
  out,err=p.communicate();status=wait(10)
  for role,b in [('stdout',out),('stderr',err)]:
   with (Q/f'git-{index}-{role}.bin').open('xb') as f:f.write(b)
  row=dict(argv=argv,pid=pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err));commands.append(row);newjson(Q/f'git-{index}-result.json',row);assert status==0
  return out
 assert git('rev-parse','HEAD').decode().strip()==EXPECTED
 assert git('branch','--show-current').decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git('status','--porcelain','--untracked-files=all')==b''
 files=[D/'docs/project_state.md',D/'docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',D/(PREFIX+'-preparation.md'),D/(PREFIX+'-assessment.json'),D/(PREFIX+'-evidence.tar.gz')]
 assert all(not f.exists() for f in files[2:])
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 selected=[]
 for f in sorted(P.rglob('*')):
  if Q in f.parents or f==Q:continue
  st=f.lstat()
  if stat.S_ISDIR(st.st_mode):continue
  assert stat.S_ISREG(st.st_mode),str(f)
  b=f.read_bytes();assert len(b)<=120*1024*1024
  selected.append(dict(path=str(f.relative_to(P)),size=len(b),sha256=sha(b)))
 manifest=dict(scope=SCOPE,selected_regular_members_without_this_manifest=len(selected),members=selected,official_helper_body_not_copied=True,no_current20_Runtime_SDK_or_old_archive_scan=True)
 newjson(P/'selected-member-manifest.json',manifest)
 archive_members=selected+[dict(path='selected-member-manifest.json',size=(P/'selected-member-manifest.json').stat().st_size,sha256=sha((P/'selected-member-manifest.json').read_bytes()))]
 with files[4].open('xb') as out:
  with tarfile.open(fileobj=out,mode='w:gz') as tf:
   for row in archive_members:
    b=(P/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'];info=tarfile.TarInfo(row['path']);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
 with tarfile.open(files[4],'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(archive_members) and all(v.isfile() for v in members)
  for v,row in zip(members,archive_members):
   b=tf.extractfile(v).read();assert v.name==row['path'] and len(b)==row['size'] and sha(b)==row['sha256'] and b==(P/row['path']).read_bytes()
 archive_sha=sha(files[4].read_bytes())
 assessment['public_evidence']=dict(archive=PREFIX+'-evidence.tar.gz',sha256=archive_sha,selected_regular_members=len(archive_members),all_selected_BYTEEXACT=True,scope=SCOPE)
 newjson(files[3],assessment)
 with files[2].open('x') as f:f.write(note+'\n[Assessment](2026-11-05-flatbuffers-native-perf-keeper-release-order-assessment.json), [evidence](2026-11-05-flatbuffers-native-perf-keeper-release-order-evidence.tar.gz).\n')
 for path,rel in [(files[0],'research/'),(files[1],'../research/')]:
  text=path.read_text();anchor='## 2026-11-05 — Observe an independent EX keeper through a finite client failure';assert text.count(anchor)==1
  links=f'[Declaration and limits]({rel}2026-11-05-flatbuffers-native-perf-keeper-release-order-preparation.md), [assessment]({rel}2026-11-05-flatbuffers-native-perf-keeper-release-order-assessment.json), [evidence]({rel}2026-11-05-flatbuffers-native-perf-keeper-release-order-evidence.tar.gz).\n\n'
  path.write_text(text.replace(anchor,common+links+anchor,1))
 names=[str(v.relative_to(D)) for v in files]
 changed=git('status','--porcelain','--untracked-files=all').decode().splitlines();assert {line[3:] for line in changed}==set(names)
 git('add','--',*names);git('diff','--cached','--check')
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(names)
 git('commit','-m','docs: record guarded keeper release-order repair')
 commit=git('rev-parse','HEAD').decode().strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert git('status','--porcelain','--untracked-files=all')==b''
 lease.verify_identity()
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=commit,archive_sha256=archive_sha,selected_regular_members=len(archive_members),all_selected_BYTEEXACT=True,scope=SCOPE,docs_only_files=names,git_commands=commands,Source_commitpush_adoption=False,full_admission=False)
 newjson(P/'publication-readback.json',receipt)
 cp_path=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');cp=json.loads(cp_path.read_text());n=cp['native_perf_only_diagnostic_design']
 n['keeper_release_order']=dict(directory=str(P),declaration=str(P/'declaration.json'),ROOT_assessment=str(P/'ROOT-assessment.json'),publication=receipt,before_counts='NEW2=1FAIL1PASS0ERROR',after_counts='matchingNEW2=2PASS0FAIL0ERROR',private_before_sha256=assessment['before']['source_sha256'],private_candidate_sha256=assessment['after']['source_sha256'],actual_premature_native_release=False,Source20_test_edit_import=False,full_admission=False,docs_pending=False,descriptions_pending=False,GitHub_description_update_not_needed='Private guarded cleanup case does not change production Source/runtime/admission claims; last saved description remains accurate.',automation_pending=True)
 n['phase']='Private_keeper_release_order_before1FAIL1PASS_after2PASS_docs_complete_admission_incomplete'
 n['next']=assessment['next']
 cp['status_docs_commit']=commit;cp['active_turn_status']='Private_keeper_release_order_NEW2_before1FAIL1PASS_after2PASS_docs_complete_admin_pending';cp['updated_utc']=receipt['utc']
 cp['last_heartbeat_summary']='NEW private keeper guarded release-order BEFORE2=1FAIL1PASS0ERROR; AFTER2=2PASS0FAIL0ERROR. TEST intercepts unsafe context-exit attempt before actual nativeclose; no premature kernel unlock permitted. Known same child collected naturally then actual context exit once. Private candidate only/current20 Source-test unchanged-unimported/no SourceHEAD20-SDK census or SDK/build/capture/adoption. Full ROOT assessment, raw streams, model qualifications and limits preserved in new docs/evidence. Immutable admission/RAMrepair/final48-50CI incomplete.'
 cp_path.write_text(json.dumps(cp,indent=2)+'\n')
 print(json.dumps({k:receipt[k] for k in ['docs_commit','archive_sha256','selected_regular_members','all_selected_BYTEEXACT']}))
