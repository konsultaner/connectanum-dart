import sys,pathlib,json,hashlib,os,stat,shutil,errno,subprocess,datetime
P=pathlib.Path("/tmp/connectanum-native-perf-independent-lease-keeper-v1")
OFFICIAL=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rawsave(p,b):
 with p.open('xb') as f:f.write(b)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_official(q):
 before=OFFICIAL.lstat();assert stat.S_ISREG(before.st_mode) and (before.st_uid,before.st_gid,before.st_size)==(501,20,35983)
 raw=OFFICIAL.read_bytes();after=OFFICIAL.lstat();assert (before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 assert sha(raw)=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
 save(q/'official-input-before-import.json',dict(path=str(OFFICIAL),uid=before.st_uid,gid=before.st_gid,size=len(raw),sha256=sha(raw),body_LOCALONLY_not_copied_or_published=True,point_identity_only=True))
 sys.path.insert(0,str(OFFICIAL.parent));import ollama_companion as m
 return m
def floor(q):
 free=shutil.disk_usage(P).free;save(q/'test-floor-before-body.json',dict(free_bytes=free,minimum_bytes=1024**3,test_only_not_build_capture_cleanup_authority=True));assert free>=1024**3
def blocked(error):
 cause=error.__cause__
 return type(cause) is BlockingIOError and cause.errno in (errno.EAGAIN,errno.EACCES) and str(error)=='local resource lease unavailable: local companion request is active'

q=pathlib.Path(sys.argv[1]);q.mkdir();assert sys.platform=='darwin'
m=load_official(q);cm=m.local_resource_lease(exclusive=True)
try:lease=cm.__enter__()
except m.LocalResourceLeaseError as error:
 save(q/'pre-body-refusal.json',dict(type=type(error).__name__,text=str(error),native_cause_type=type(error.__cause__).__name__,native_errno=getattr(error.__cause__,'errno',None),fixture_started=False))
 raise SystemExit(78 if blocked(error) else 1)
# Selected known-constructor/client-failure fixture only. No general error/crash/unknown-constructor closure claim.
try:
 lease.verify_identity();floor(q)
 payload_out=b'lease-keeper-fixture-out\n';payload_err=b'lease-keeper-fixture-err\n'
 child_code="import sys,time;time.sleep(3);sys.stdout.buffer.write("+repr(payload_out)+");sys.stderr.buffer.write("+repr(payload_err)+")"
 argv=[sys.executable,'-c',child_code];save(q/'child-attempt-before.json',dict(argv=argv,Popen_attempted=True,pid=None,fixture_only=True))
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 child_wait=child.wait;child_poll=child.poll;child_out=child.stdout;child_err=child.stderr;child_pid=child.pid
 save(q/'child-start-before-publication.json',dict(pid=child_pid,original_bound_wait_and_poll_retained_before_IO=True,stdout_fd=child_out.fileno(),stderr_fd=child_err.fileno(),current_uid=os.getuid(),current_gid=os.getgid()))
 ready=dict(event='READY',keeper_pid=os.getpid(),child_pid=child_pid,official_EX_entered_verified=True,fixture_only=True)
 rawsave(q/'ready-exact.bin',(json.dumps(ready)+'\n').encode());print(json.dumps(ready),flush=True)
 request=sys.stdin.buffer.readline();rawsave(q/'first-control-request.bin',request)
 witness=dict(event='WITNESS',keeper_pid=os.getpid(),child_pid=child_pid,actual_native_poll=child_poll(),lease_identity_verified=True,Source_fields_not_used=True)
 lease.verify_identity();rawsave(q/'witness-exact.bin',(json.dumps(witness)+'\n').encode());print(json.dumps(witness),flush=True)
 finish=sys.stdin.buffer.readline();rawsave(q/'finish-control-request.bin',finish)
 out,err=child.communicate();status=child_wait(10);rawsave(q/'child-stdout.bin',out);rawsave(q/'child-stderr.bin',err)
 result=dict(kind='FINITE_FIXTURE_ONLY_NOT_LIVE_RECEIPT',keeper_pid=os.getpid(),child_pid=child_pid,child_status=status,child_signed_native_int=type(status) is int,child_BOTH_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err),original_bound_wait_retained=True,control_observe_exact=request==b'observe\n',control_finish_exact=finish==b'finish\n',actual_native_poll_after_client_and_negative_probe=witness['actual_native_poll'],capture_ready=False,evidence_complete=False,readiness=False,admission=False)
 save(q/'result-before-release.json',result);lease.verify_identity()
 assert request==b'observe\n' and finish==b'finish\n' and type(status) is int and status==0 and out==payload_out and err==payload_err
finally:
 cm.__exit__(*sys.exc_info())
save(q/'official-context-exited.json',dict(keeper_pid=os.getpid(),selected_known_child_natural_completion_before_release=True,NOT_unknown_constructor_or_general_error_crash_proof=True))
