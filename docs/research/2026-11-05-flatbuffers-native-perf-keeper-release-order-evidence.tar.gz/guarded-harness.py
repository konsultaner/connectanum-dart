import sys,pathlib,json,hashlib,subprocess as native,types,time,traceback,os
P=pathlib.Path("/tmp/connectanum-native-perf-keeper-release-order-v1");source_dir=pathlib.Path(sys.argv[1]);mode=sys.argv[2];source=pathlib.Path(sys.argv[3]);root=pathlib.Path(sys.argv[4]);root.mkdir()
def save(name,v):
 with (root/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rawsave(name,b):
 with (root/name).open('xb') as f:f.write(b)
def sha(b):return hashlib.sha256(b).hexdigest()
class First(RuntimeError):pass
class PrematureExitAttempt(RuntimeError):pass
first=First('keeper-publication-First')
actors=[];contexts=[];probes=[];events=[];publication_fault=False
def quarantine(reason):
 save('UNRESOLVED-permanent-quarantine.json',dict(reason=reason,no_release_retry_partial_methods_or_kill=True))
 while True:time.sleep(1)
class ObservedPopen(native.Popen):
 def communicate(self,*args,**kwargs):
  row=next(x for x in actors if x['process'] is self)
  row['communicate_attempts']+=1
  out,err=native.Popen.communicate(self,*args,**kwargs)
  status=row['original_wait'](10)
  row.update(collected=True,out=out,err=err,status=status,both_EOF=True)
  events.append(dict(event='original_native_communicate_wait_BOTH_EOF_returned_to_ROOT',pid=row['pid'],status=status))
  return out,err
def capture_popen(*args,**kwargs):
 save('child-attempt-before-native-Popen.json',dict(argv=args[0] if args else kwargs.get('args'),Popen_attempted=True,pid=None))
 process=ObservedPopen(*args,**kwargs)
 row=dict(process=process,pid=process.pid,original_wait=native.Popen.wait.__get__(process,native.Popen),original_poll=native.Popen.poll.__get__(process,native.Popen),stdout=process.stdout,stderr=process.stderr,delegated_communicate=process.communicate,collected=False,communicate_attempts=0)
 actors.append(row)
 save('child-native-handles-before-publication-IO.json',dict(pid=row['pid'],stdout_fd=row['stdout'].fileno(),stderr_fd=row['stderr'].fileno(),original_bound_wait_poll_and_native_streams_retained=True))
 return process
def probe_actual_context():
 save('contender-attempt-before-Popen.json',dict(argv=[sys.executable,str(P/'guard-contender.py'),str(root/'contender')],Popen_attempted=True,pid=None))
 p=native.Popen([sys.executable,str(P/'guard-contender.py'),str(root/'contender')],stdout=native.PIPE,stderr=native.PIPE);wait=p.wait;stdout=p.stdout;stderr=p.stderr;pid=p.pid
 save('contender-native-handle-before-IO.json',dict(pid=pid,original_bound_wait_and_streams_retained=True))
 out,err=p.communicate();status=wait(10);rawsave('contender-stdout.bin',out);rawsave('contender-stderr.bin',err)
 row=dict(pid=pid,status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err));probes.append(row);save('contender-result.json',row)
class GuardContext:
 def __init__(self,actual):
  self.actual=actual;self.actual_exit=actual.__exit__;self.entered=False;self.exit_attempts=[];self.actual_exit_attempts=0;self.actual_exit_returns=0;self.manual_actual_exit=False
  contexts.append(self)
 def __enter__(self):
  value=self.actual.__enter__();self.entered=True;self.lease=value
  events.append(dict(event='original_official_EX_enter_returned'))
  return value
 def __exit__(self,*exc):
  collected=bool(actors) and all(x['collected'] for x in actors)
  attempt=dict(child_native_collection_observed=collected,native_poll=actors[0]['original_poll']() if actors else None,exception_type=getattr(exc[0],'__name__',None),before_any_actual_native_exit=True)
  self.exit_attempts.append(attempt);events.append(dict(event='Source_context_exit_attempt_before_native_close',**attempt))
  save('exit-attempt-before-native-close.json',attempt)
  if publication_fault:probe_actual_context()
  if not collected:
   if not actors:quarantine('Context exit with no confirmed creator child after launch uncertainty')
   raise PrematureExitAttempt('TEST blocks actual context exit before known native collection')
  return self.release(exc,manual=False)
 def release(self,exc,manual):
  if self.actual_exit_attempts:quarantine('No repeat of an already attempted actual native context exit')
  if not actors or not all(x['collected'] for x in actors):quarantine('No actual native close with known actor collection incomplete')
  self.lease.verify_identity();self.actual_exit_attempts+=1;self.manual_actual_exit=manual
  result=self.actual_exit(*exc);self.actual_exit_returns+=1
  events.append(dict(event='actual_original_context_exit_returned',manual=manual,after_native_collection=True))
  return result
text=source.read_text();boundary=text.index('q=pathlib.Path(sys.argv[1]);')
namespace={'__name__':'private_keeper_under_test','__file__':str(source)}
exec(compile(text[:boundary],str(source),'exec'),namespace)
actual_load=namespace['load_official'];actual_rawsave=namespace['rawsave']
def observed_load(q):
 module=actual_load(q)
 def factory(*,exclusive=False):
  actual=module.local_resource_lease(exclusive=exclusive)
  return GuardContext(actual)
 return types.SimpleNamespace(local_resource_lease=factory,LocalResourceLeaseError=module.LocalResourceLeaseError)
def observed_rawsave(path,data):
 global publication_fault
 result=actual_rawsave(path,data)
 if mode=='publication-first' and pathlib.Path(path).name=='ready-exact.bin':
  publication_fault=True
  save('publication-fault-after-real-IO-before-Source-return.json',dict(original_rawsave_returned_None=result is None,actual_ready_file_bytes=len(data),Root_First_before_Source_received_return=True))
  raise first
 return result
namespace['load_official']=observed_load
namespace['rawsave']=observed_rawsave
namespace['subprocess']=types.SimpleNamespace(Popen=capture_popen,PIPE=native.PIPE,DEVNULL=native.DEVNULL)
received=None
try:exec(compile(text[boundary:],str(source),'exec'),namespace)
except BaseException as error:received=error
if not actors:
 save('no-confirmed-child-terminal.json',dict(received_type=type(received).__name__ if received else None,no_fixture_child_confirmed=True))
 raise SystemExit(78)
for row in actors:
 if not row['collected']:
  if row['communicate_attempts']:quarantine('Original communicate outcome uncertain; no repeat')
  row['delegated_communicate']()
for context in contexts:
 if context.entered and context.actual_exit_attempts==0:context.release((None,None,None),manual=True)
 if context.entered and context.actual_exit_returns!=1:quarantine('Actual context exit outcome unresolved; no retry')
child_rows=[]
for i,row in enumerate(actors):
 rawsave(f'child-{i}-stdout.bin',row['out']);rawsave(f'child-{i}-stderr.bin',row['err'])
 child_rows.append(dict(pid=row['pid'],status=row['status'],signed_native_int=type(row['status']) is int,both_separate_EOF=row['both_EOF'],stdout_size=len(row['out']),stderr_size=len(row['err']),stdout_sha256=sha(row['out']),stderr_sha256=sha(row['err']),original_communicate_attempts=row['communicate_attempts'],native_outputs_retained_before_Source_return=True))
views=[dict(entered=x.entered,exit_attempts=x.exit_attempts,actual_exit_attempts=x.actual_exit_attempts,actual_exit_returns=x.actual_exit_returns,manual_actual_exit=x.manual_actual_exit) for x in contexts]
save('ALL-known-outcomes-BEFORE-unit-assertions.json',dict(child_rows=child_rows,probe_rows=probes,contexts=views,events=events,received_type=type(received).__name__ if received else None,received_original_First=received is first,received_context_original_First=received is not None and received.__context__ is first,publication_fault_injected=publication_fault,source_sha256=sha(text.encode()),Source_fields_not_filled_restored=True,actual_premature_native_exit=False,capture_ready=False,evidence_complete=False,readiness=False,admission=False))
