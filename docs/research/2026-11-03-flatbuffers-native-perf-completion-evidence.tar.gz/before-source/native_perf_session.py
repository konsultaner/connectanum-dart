#!/usr/bin/env python3
"""Private helper/auditor lifecycle, without a benchmark campaign entrypoint.

Linux/root CLI roles use verified source bytes, direct UNIX peers and pinned
ELF exec. Fixture backends are explicit Python-only injections; CLI input cannot
select them. Actual Linux capability/provenance controls still precede data.
"""
from __future__ import annotations

import argparse
import base64
import dataclasses
import fcntl
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import select
import signal
import socket
import stat
import subprocess
import sys
import time
import types


class SessionError(RuntimeError):
    pass


BUNDLE_FILES = tuple(sorted(f'tool/{prefix}{name}.py'
                           for name in ('native_perf_guard', 'native_perf_blocked_exec',
                                        'native_perf_proc_witness', 'native_perf_handoff', 'native_perf_session')
                           for prefix in ('', 'test_')))
MODULE_ORDER = ('native_perf_guard', 'native_perf_blocked_exec', 'native_perf_proc_witness', 'native_perf_handoff')
MAX_REPORT = 32 * 1024 * 1024


def _api():
    return types.SimpleNamespace(
        guard=importlib.import_module('native_perf_guard'),
        blocked=importlib.import_module('native_perf_blocked_exec'),
        proc=importlib.import_module('native_perf_proc_witness'),
        handoff=importlib.import_module('native_perf_handoff'))


def _digest(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def _int(value, minimum=0):
    return type(value) is int and value >= minimum


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _json(data):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise SessionError('duplicate session JSON field')
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda _value: (_ for _ in ()).throw(SessionError('nonfinite session JSON')))


def _bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def _same(actual, expected):
    return (type(actual) is dict and set(actual) == set(expected)
            and all(type(actual[k]) is type(v) and actual[k] == v for k, v in expected.items()))


def _fd_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns, info.st_mode)


def _read_file(path, expected_sha, maximum, *, owner=None):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_size > maximum
                or owner is not None and before.st_uid != owner):
            raise SessionError('invalid session input file')
        data = bytearray()
        while chunk := os.read(fd, min(1024 * 1024, maximum + 1 - len(data))):
            data.extend(chunk)
            if len(data) > maximum:
                raise SessionError('session input size limit')
        if (_fd_identity(os.fstat(fd)) != _fd_identity(before)
                or len(data) != before.st_size or _sha(data) != expected_sha):
            raise SessionError('session input changed or digest differs')
        return bytes(data)
    finally:
        os.close(fd)


def verified_bundle(root, manifest_path, expected_sha, owner):
    root = Path(root).resolve(strict=True)
    manifest = _json(_read_file(manifest_path, expected_sha, 65536, owner=owner))
    if (type(manifest) is not dict or set(manifest) != {'files'}
            or type(manifest['files']) is not dict or set(manifest['files']) != set(BUNDLE_FILES)
            or any(not _digest(v) for v in manifest['files'].values())):
        raise SessionError('invalid tool bundle manifest')
    sources = {}
    for relative in BUNDLE_FILES:
        path = root / relative
        info = path.lstat()
        if info.st_uid != owner or stat.S_IMODE(info.st_mode) & 0o022:
            raise SessionError('tool bundle ownership or permissions differ')
        sources[relative] = _read_file(path, manifest['files'][relative], 256 * 1024, owner=owner)
    return sources


def load_verified_modules(sources, root):
    # Compile these exact checked bytes; never trust own-module pyc or sys.modules caches.
    for name in MODULE_ORDER:
        module = types.ModuleType(name)
        module.__file__ = str(Path(root) / 'tool' / (name + '.py'))
        sys.modules[name] = module
        exec(compile(sources['tool/' + name + '.py'], module.__file__, 'exec', dont_inherit=True), module.__dict__)


class PrivateDirectory:
    def __init__(self, path, owner):
        if not Path(path).is_absolute() or not _int(owner):
            raise SessionError('invalid private directory declaration')
        self.path = Path(path).resolve(strict=True)
        original = Path(path).lstat()
        self.fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        self.identity = os.fstat(self.fd).st_dev, os.fstat(self.fd).st_ino
        self.owner = owner
        try:
            if stat.S_ISLNK(original.st_mode):
                raise SessionError('private directory must not be a symlink')
            self.verify()
        except BaseException:
            self.close()
            raise

    def verify(self):
        info, pinned = self.path.lstat(), os.fstat(self.fd)
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid != self.owner
                or stat.S_IMODE(info.st_mode) & 0o077
                or (info.st_dev, info.st_ino) != self.identity
                or (pinned.st_dev, pinned.st_ino) != self.identity):
            raise SessionError('private directory identity or permissions changed')

    def name(self, basename):
        if not isinstance(basename, str) or not re.fullmatch('[a-z0-9_-]{1,40}\\.(sock|json|data)', basename):
            raise SessionError('invalid private artifact name')
        self.verify()
        return self.path / basename

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1


class PrivateListener:
    def __init__(self, directory, basename, *, timeout=10.0):
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 60:
            raise SessionError('invalid listener deadline')
        self.directory, self.path = directory, directory.name(basename)
        if len(os.fsencode(self.path)) >= 100 or os.path.lexists(self.path):
            raise SessionError('listener path exists or is too long')
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.state = 'new'
        try:
            self.socket.settimeout(timeout)
            self.socket.bind(str(self.path))
            os.chmod(self.path, 0o600)
            node = self.path.lstat()
            self.identity = node.st_dev, node.st_ino
            self.verify()
            self.socket.listen(1)
        except BaseException:
            self.socket.close()
            raise

    def verify(self):
        self.directory.verify()
        node = self.path.lstat()
        if (not stat.S_ISSOCK(node.st_mode) or node.st_uid != self.directory.owner
                or stat.S_IMODE(node.st_mode) != 0o600
                or (node.st_dev, node.st_ino) != self.identity):
            raise SessionError('listener filesystem node changed')

    def accept(self, *, fixture_peer=None):
        if self.state != 'new':
            raise SessionError('listener attempt is terminal')
        self.state = 'failed'
        conn = None
        try:
            self.verify()
            conn, _address = self.socket.accept()
            self.verify()
            api = _api()
            wire = (api.handoff.HandoffWire.fixture(conn, fixture_peer)
                    if fixture_peer is not None else api.handoff.HandoffWire.live(conn, expected_uid=0, expected_gid=0))
            self.state = 'accepted'
            return conn, wire
        except BaseException:
            if conn is not None:
                conn.close()
            raise

    def close(self):
        self.socket.close()  # Retain filesystem node/evidence; never reclaim an uncertain path.


class PinnedElf:
    def __init__(self, path, expected_sha):
        if not Path(path).is_absolute() or not _digest(expected_sha):
            raise SessionError('invalid ELF declaration')
        self.named_path = Path(path)
        self.path = self.named_path.resolve(strict=True)
        self.fd = os.open(self.path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        self.expected_sha = expected_sha
        self.identity = _fd_identity(os.fstat(self.fd))
        try:
            self.verify()
        except BaseException:
            self.close()
            raise

    def verify(self):
        api = _api()
        info = os.fstat(self.fd)
        named = self.named_path.stat()
        if (self.fd <= 2 or not stat.S_ISREG(info.st_mode) or not info.st_mode & 0o111
                or info.st_mode & (stat.S_ISUID | stat.S_ISGID) or info.st_size > 128 * 1024 * 1024
                or os.pread(self.fd, 4, 0) != b'\x7fELF'
                or _fd_identity(info) != self.identity
                or (named.st_dev, named.st_ino) != self.identity[:2]
                or api.blocked._file_hash(self.fd) != self.expected_sha
                or _fd_identity(os.fstat(self.fd)) != self.identity):
            raise SessionError('pinned sampler ELF changed')

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1


@dataclasses.dataclass(frozen=True)
class SessionSpec:
    declaration: str
    nonce: str
    controller_pid: int
    controller_uid: int
    controller_gid: int
    directory: str
    wrapper_pid: int
    wrapper_start: int
    wrapper_image: str
    wrapper_argv: tuple[str, ...]
    driver_path: str
    driver_sha: str
    perf_path: str
    perf_sha: str
    bootstrap_image: str
    bundle_sha: str
    log_device: int
    log_inode: int

    def __post_init__(self):
        if (not all(_digest(v) for v in (self.declaration, self.wrapper_image, self.driver_sha,
                                        self.perf_sha, self.bootstrap_image, self.bundle_sha))
                or not isinstance(self.nonce, str) or re.fullmatch('[0-9a-f]{32}', self.nonce) is None
                or not all(_int(v, 1) for v in (self.controller_pid, self.wrapper_pid, self.wrapper_start, self.log_inode))
                or not all(_int(v) for v in (self.controller_uid, self.controller_gid, self.log_device))
                or self.controller_pid == self.wrapper_pid
                or any(not isinstance(v, str) or not Path(v).is_absolute() for v in (self.directory, self.driver_path, self.perf_path))
                or type(self.wrapper_argv) is not tuple or not self.wrapper_argv
                or any(not isinstance(v, str) or '\0' in v for v in self.wrapper_argv)):
            raise SessionError('invalid session specification')

    def context(self, mode):
        return {'declaration': self.declaration, 'nonce': self.nonce, 'mode': mode,
                'controller_pid': self.controller_pid, 'bundle_sha': self.bundle_sha}

    def perf_argv(self):
        # Unfiltered cpu-clock flat IPs: retain kernel/unknown records too.
        return (self.perf_path, 'record', '--pid', str(self.wrapper_pid), '--inherit', '--delay=-1',
                '--control=fd:0,1', '-e', 'cpu-clock', '-F', '999', '-o', str(Path(self.directory) / 'perf.data'))

    @classmethod
    def from_json(cls, value):
        if type(value) is not dict or set(value) != {field.name for field in dataclasses.fields(cls)}:
            raise SessionError('invalid session spec schema')
        value = dict(value)
        if type(value['wrapper_argv']) is not list:
            raise SessionError('invalid wrapper argv schema')
        value['wrapper_argv'] = tuple(value['wrapper_argv'])
        return cls(**value)


def _check_root_linux():
    if (sys.platform != 'linux' or os.execve not in os.supports_fd
            or (os.getuid(), os.geteuid(), os.getgid(), os.getegid()) != (0, 0, 0, 0)):
        raise SessionError('privileged Linux fd-exec context required')


def connect_wire(spec, basename, *, fixture_peer=None):
    directory = PrivateDirectory(spec.directory, spec.controller_uid)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        path = directory.name(basename)
        before = path.lstat()
        if (not stat.S_ISSOCK(before.st_mode) or before.st_uid != spec.controller_uid
                or stat.S_IMODE(before.st_mode) != 0o600):
            raise SessionError('unexpected controller socket')
        sock.settimeout(10)
        sock.connect(str(path))
        directory.verify()
        after = path.lstat()
        if (before.st_dev, before.st_ino, before.st_mode) != (after.st_dev, after.st_ino, after.st_mode):
            raise SessionError('controller socket changed during connect')
        api = _api()
        wire = (api.handoff.HandoffWire.fixture(sock, fixture_peer) if fixture_peer is not None
                else api.handoff.HandoffWire.live(sock, expected_uid=spec.controller_uid,
                                                 expected_gid=spec.controller_gid, expected_pid=spec.controller_pid))
        return sock, wire
    except BaseException:
        sock.close()
        raise
    finally:
        directory.close()


def helper_preface(wire, spec, mode, identity):
    with wire.once():
        request = wire.read_frame()
        if not _same(request, {'event': 'source_request', **spec.context(mode)}):
            raise SessionError('invalid source bootstrap request')
        expected = {'pid', 'start_ticks', 'image_sha256', 'fixture_only'}
        if (set(identity) != expected or not _int(identity['pid'], 1) or not _int(identity['start_ticks'], 1)
                or identity['pid'] != os.getpid() or not _digest(identity['image_sha256'])
                or type(identity['fixture_only']) is not bool or identity['fixture_only'] != wire.fixture_only):
            raise SessionError('invalid helper bootstrap identity')
        wire.send_frame({'event': 'source_boot', **spec.context(mode), **identity})


def controller_preface(wire, spec, mode):
    with wire.once():
        wire.send_frame({'event': 'source_request', **spec.context(mode)})
        boot = wire.read_frame()
        context = {'event': 'source_boot', **spec.context(mode)}
        if (set(boot) != set(context) | {'pid', 'start_ticks', 'image_sha256', 'fixture_only'}
                or any(type(boot[k]) is not type(v) or boot[k] != v for k, v in context.items())
                or not _int(boot['pid'], 1) or boot['pid'] != wire.peer.pid
                or not _int(boot['start_ticks'], 1) or boot['image_sha256'] != spec.bootstrap_image
                or type(boot['fixture_only']) is not bool or boot['fixture_only'] != wire.fixture_only):
            raise SessionError('helper source or instance bootstrap differs')
        return boot


def new_round(sock, previous_wire, *, spec, as_controller):
    api = _api()
    if previous_wire.state != 'complete':
        raise SessionError('unsuccessful bootstrap cannot advance')
    if previous_wire.fixture_only:
        return api.handoff.HandoffWire.fixture(sock, previous_wire.peer)
    return api.handoff.HandoffWire.live(sock, expected_uid=previous_wire.peer.uid,
                                       expected_gid=previous_wire.peer.gid, expected_pid=previous_wire.peer.pid)


def actual_identity():
    _check_root_linux()
    api = _api()
    parsed = api.guard.parse_process_stat(Path('/proc/self/stat').read_text())
    fd = os.open('/proc/self/exe', os.O_RDONLY | os.O_CLOEXEC)
    try:
        digest = api.blocked._file_hash(fd)
    finally:
        os.close(fd)
    return {'pid': parsed.pid, 'start_ticks': parsed.start_ticks, 'image_sha256': digest, 'fixture_only': False}


def execute_sampler(spec, image, ends, sock, *, directory=None, exec_callback=None):
    if exec_callback is None:
        _check_root_linux()
        if ends.fixture_only:
            raise SessionError('fixture endpoints cannot execute a live sampler')
    image.verify()
    info = os.fstat(2)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != spec.controller_uid
            or (info.st_dev, info.st_ino) != (spec.log_device, spec.log_inode)
            or fcntl.fcntl(2, fcntl.F_GETFL) & os.O_ACCMODE not in (os.O_WRONLY, os.O_RDWR)):
        raise SessionError('sampler stderr log differs')
    # This changes only the profiler's artifact mode inside the private0700 job dir.
    # It never changes the unprivileged driver environment/umask/worker policies.
    os.umask(0o022)
    os.dup2(ends.control_fd, 0)
    os.dup2(ends.ack_fd, 1)
    ends.close()
    sock.close()
    if directory is not None:
        directory.close()
    keep = {0, 1, 2, image.fd}
    for fd in _api().blocked._open_fds():
        if fd not in keep:
            os.close(fd)
    for name in ('SIGPIPE', 'SIGXFZ', 'SIGXFSZ'):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), signal.SIG_DFL)
    os.set_inheritable(image.fd, False)
    if exec_callback is not None:
        exec_callback(image.fd, spec.perf_argv(), dict(os.environ))
        return
    os.execve(image.fd, spec.perf_argv(), dict(os.environ))


def run_helper(spec, *, fixture_peer=None, identity=None, exec_callback=None):
    if fixture_peer is None:
        _check_root_linux()
        if spec.controller_uid == 0:
            raise SessionError('driver controller must remain unprivileged')
    directory = PrivateDirectory(spec.directory, spec.controller_uid)
    image, ends, sock = None, None, None
    try:
        if os.path.lexists(directory.name('perf.data')):
            raise SessionError('sampler output already exists; no overwrite')
        image = PinnedElf(spec.perf_path, spec.perf_sha)
        sock, wire = connect_wire(spec, 'sampler.sock', fixture_peer=fixture_peer)
        helper_preface(wire, spec, 'helper', actual_identity() if identity is None else identity())
        round_wire = new_round(sock, wire, spec=spec, as_controller=False)
        ends = _api().handoff.offer_endpoints(round_wire, spec.declaration, spec.nonce)
        directory.verify()
        image.verify()
        execute_sampler(spec, image, ends, sock, directory=directory, exec_callback=exec_callback)
    finally:
        if sock is not None:
            sock.close()
        if ends is not None:
            ends.close()
        if image is not None:
            image.close()
        directory.close()


def write_report(directory, basename, value):
    path = directory.name(basename)
    data = _bytes(value)
    if len(data) > MAX_REPORT:
        raise SessionError('audit report size limit')
    fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory.fd)
    try:
        offset = 0
        while offset < len(data):
            count = os.write(fd, data[offset:])
            if count <= 0:
                raise SessionError('invalid audit report write progress')
            offset += count
        if os.geteuid() == 0:
            os.fchown(fd, directory.owner, -1)
        os.fsync(fd)
        directory.verify()
        info = os.fstat(fd)
        os.fsync(directory.fd)
        return {'name': path.name, 'device': info.st_dev, 'inode': info.st_ino,
                'size': len(data), 'sha256': _sha(data)}
    finally:
        os.close(fd)  # Any existing/partial report remains terminal and retained.


def read_report(directory, receipt):
    if (type(receipt) is not dict or set(receipt) != {'name', 'device', 'inode', 'size', 'sha256'}
            or not all(_int(receipt[k]) for k in ('device', 'inode', 'size'))
            or receipt['size'] > MAX_REPORT or not _digest(receipt['sha256'])):
        raise SessionError('invalid audit report receipt')
    path = directory.name(receipt['name'])
    before = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size) != (receipt['device'], receipt['inode'], receipt['size']):
        raise SessionError('audit report identity differs')
    data = _read_file(path, receipt['sha256'], MAX_REPORT, owner=directory.owner)
    directory.verify()
    after = path.lstat()
    if _fd_identity(before) != _fd_identity(after):
        raise SessionError('audit report changed during admission')
    return _json(data)


def inspect_processes(spec, sampler, wrapper, control, ack, *, fixture_only):
    api = _api()
    if (sampler.fixture_only != fixture_only or wrapper.fixture_only != fixture_only
            or sampler.process.pid == wrapper.process.pid
            or wrapper.process != api.guard.ProcessStat(spec.wrapper_pid, spec.controller_pid, spec.wrapper_start)
            or wrapper.instance.executable_sha256 != spec.wrapper_image
            or wrapper.argv != spec.wrapper_argv
            or (wrapper.instance.effective_uid, wrapper.instance.effective_gid) != (spec.controller_uid, spec.controller_gid)):
        raise SessionError('blocked wrapper audit differs')
    if (sampler.argv != spec.perf_argv() or sampler.instance.executable_sha256 != spec.perf_sha
            or (sampler.instance.effective_uid, sampler.instance.effective_gid) != ((spec.controller_uid, spec.controller_gid) if fixture_only else (0, 0))):
        raise SessionError('actual sampler audit differs')
    logs = [fd for fd in sampler.fds if fd.number == 2]
    if (len(logs) != 1 or logs[0].kind != 'regular'
            or (logs[0].device, logs[0].inode) != (spec.log_device, spec.log_inode)
            or logs[0].flags & os.O_ACCMODE not in (os.O_WRONLY, os.O_RDWR)):
        raise SessionError('actual sampler log descriptor differs')
    api.proc.identify_sampler({sampler.process.pid: sampler}, expected_sha256=spec.perf_sha,
                             expected_argv=spec.perf_argv(), expected_uid=sampler.instance.effective_uid,
                             expected_gid=sampler.instance.effective_gid, control=control, ack=ack,
                             launcher_images=frozenset())
    api.proc.require_wrapper_private_channels_absent(wrapper, control, ack)


def _snapshot_json(value):
    return dataclasses.asdict(value)


def _audit_with_reader(spec, request, reader):
    api = _api()
    if (set(request) != {'sampler_pid', 'sampler_start', 'control', 'ack'}
            or not _int(request['sampler_pid'], 1) or not _int(request['sampler_start'], 1)):
        raise SessionError('invalid exact sampler audit request')
    control, ack = api.handoff._channel(request['control']), api.handoff._channel(request['ack'])
    # Only the one predeclared bootstrap image may wait for its same-PID exec.
    deadline = time.monotonic() + 10
    while True:
        pid = request['sampler_pid']
        cookie = reader._process_stat(Path(str(pid)) / 'stat', pid)
        if cookie.start_ticks != request['sampler_start']:
            raise SessionError('sampler instance changed before audit')
        _identity, digest = reader._image(Path(str(pid)) / 'exe')
        if digest == spec.perf_sha:
            break
        if digest != spec.bootstrap_image or time.monotonic() >= deadline:
            raise SessionError('unexpected sampler image or exec deadline')
        time.sleep(.01)
    sampler, wrapper = reader.snapshot(pid), reader.snapshot(spec.wrapper_pid)
    if sampler.process.start_ticks != request['sampler_start']:
        raise SessionError('sampler start cookie changed')
    inspect_processes(spec, sampler, wrapper, control, ack, fixture_only=False)
    # Verify the ACTUAL driver FD held by the blocked wrapper, not a convenient path.
    matches = [fd for fd in wrapper.fds if fd.kind == 'regular' and fd.target == str(Path(spec.driver_path).resolve(strict=True))]
    if len(matches) != 1:
        raise SessionError('blocked driver held image is missing or ambiguous')
    _identity, actual_driver = reader._image(Path(str(spec.wrapper_pid)) / 'fd' / str(matches[0].number))
    if actual_driver != spec.driver_sha:
        raise SessionError('actual blocked driver FD bytes differ')
    return {'fixture_only': False, 'sampler': _snapshot_json(sampler), 'wrapper': _snapshot_json(wrapper),
            'actual_driver_fd_sha256': actual_driver, 'raw_evidence': reader.evidence}


def live_audit(spec, request):
    _check_root_linux()
    reader = _api().proc.ProcReader()
    try:
        return _audit_with_reader(spec, request, reader)
    except BaseException as error:
        return {'fixture_only': False, 'error': {'type': type(error).__name__,
                'errno': getattr(error, 'errno', None),
                'reason': str(error) if isinstance(error, (SessionError, _api().guard.GuardError)) else None},
                'raw_evidence': reader.evidence}


def run_auditor(spec, phase):
    _check_root_linux()
    if phase not in ('before-enable', 'before-go'):
        raise SessionError('invalid audit phase')
    directory = PrivateDirectory(spec.directory, spec.controller_uid)
    sock = None
    try:
        sock, wire = connect_wire(spec, 'audit-' + phase + '.sock')
        helper_preface(wire, spec, 'audit-' + phase, actual_identity())
        followup = new_round(sock, wire, spec=spec, as_controller=False)
        with followup.once():
            request = followup.read_frame()
            expected = {'event': 'audit_request', **spec.context('audit-' + phase)}
            if set(request) != set(expected) | {'target'} or any(type(request[k]) is not type(v) or request[k] != v for k, v in expected.items()):
                raise SessionError('audit request context differs')
            report = live_audit(spec, request['target'])
            receipt = write_report(directory, 'audit-' + phase + '.json', {'context': spec.context('audit-' + phase), **report})
            followup.send_frame({'event': 'audit_report', **spec.context('audit-' + phase), 'receipt': receipt})
    finally:
        if sock is not None:
            sock.close()
        directory.close()


def _parse_snapshot(data):
    api = _api()
    required = {'process', 'instance', 'uid', 'gid', 'argv', 'image_identity', 'image_target', 'fds', 'fixture_only'}
    if type(data) is not dict or set(data) != required or type(data['fixture_only']) is not bool:
        raise SessionError('invalid process audit schema')
    p, i = data['process'], data['instance']
    if (type(p) is not dict or set(p) != {'pid', 'parent_pid', 'start_ticks'}
            or not _int(p['pid'], 1) or not _int(p['parent_pid']) or not _int(p['start_ticks'], 1)
            or type(i) is not dict or set(i) != {'pid', 'start_ticks', 'executable_sha256', 'effective_uid', 'effective_gid'}):
        raise SessionError('invalid process identity schema')
    process, instance = api.guard.ProcessStat(**p), api.guard.ProcessInstance(**i)
    if instance.pid != process.pid or instance.start_ticks != process.start_ticks:
        raise SessionError('inconsistent audit process instance')
    for key in ('uid', 'gid'):
        if type(data[key]) is not list or len(data[key]) != 4 or not all(_int(v) for v in data[key]):
            raise SessionError('invalid audit credentials')
    if (data['uid'][1] != instance.effective_uid or data['gid'][1] != instance.effective_gid
            or type(data['argv']) is not list or not data['argv']
            or any(not isinstance(v, str) or '\0' in v for v in data['argv'])
            or type(data['image_identity']) is not list or len(data['image_identity']) != 6
            or any(type(v) is not int for v in data['image_identity']) or not isinstance(data['image_target'], str)
            or type(data['fds']) is not list or len(data['fds']) > api.proc.ProcReader.MAX_FDS):
        raise SessionError('invalid process audit fields')
    fds = []
    for fd in data['fds']:
        if (type(fd) is not dict or set(fd) != {'number', 'kind', 'device', 'inode', 'flags', 'target'}
                or any(not _int(fd[k]) for k in ('number', 'device', 'inode', 'flags'))
                or fd['kind'] not in ('pipe', 'regular', 'other') or not isinstance(fd['target'], str)):
            raise SessionError('invalid audit descriptor schema')
        fds.append(api.proc.FdWitness(**fd))
    if len({fd.number for fd in fds}) != len(fds):
        raise SessionError('duplicate audit descriptors')
    return api.proc.ProcessWitness(process, instance, tuple(data['uid']), tuple(data['gid']), tuple(data['argv']),
                                  tuple(data['image_identity']), data['image_target'], tuple(fds), data['fixture_only'])


def admit_audit(spec, report, phase, sampler_boot, control, ack, *, fixture_only=False):
    if type(report) is dict and 'error' in report:
        raise SessionError('privileged audit refused; raw report retained')
    if (type(report) is not dict or set(report) != {'context', 'fixture_only', 'sampler', 'wrapper', 'actual_driver_fd_sha256', 'raw_evidence'}
            or not _same(report['context'], spec.context('audit-' + phase))
            or type(report['fixture_only']) is not bool or report['fixture_only'] != fixture_only
            or report['actual_driver_fd_sha256'] != spec.driver_sha or type(report['raw_evidence']) is not list):
        raise SessionError('invalid audit report context/provenance')
    sampler, wrapper = _parse_snapshot(report['sampler']), _parse_snapshot(report['wrapper'])
    if sampler.instance.pid != sampler_boot['pid'] or sampler.instance.start_ticks != sampler_boot['start_ticks']:
        raise SessionError('audited sampler instance differs from authenticated helper')
    inspect_processes(spec, sampler, wrapper, control, ack, fixture_only=fixture_only)
    return sampler, wrapper


class PidHandle:
    def __init__(self, pid):
        if sys.platform != 'linux' or not hasattr(os, 'pidfd_open'):
            raise SessionError('actual Linux pidfd support required')
        self.fd = os.pidfd_open(pid, 0)
        try:
            self.require_alive()
        except BaseException:
            self.close()
            raise

    def require_alive(self):
        if select.select([self.fd], [], [], 0)[0]:
            raise SessionError('authenticated helper process exited')

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1


def privileged_argv(spec_path, spec_sha, bundle_root, manifest_path, bundle_sha, mode, phase=None):
    if mode not in ('helper', 'audit') or mode == 'audit' and phase not in ('before-enable', 'before-go'):
        raise SessionError('invalid privileged role')
    argv = ('sudo', '-n', '--', '/usr/bin/python3', '-I', '-S',
            str(Path(bundle_root) / 'tool' / 'native_perf_session.py'),
            '--bundle-root', str(bundle_root), '--bundle-manifest', str(manifest_path), '--bundle-sha', bundle_sha,
            '--spec', str(spec_path), '--spec-sha', spec_sha, mode)
    return argv + (('--phase', phase) if phase is not None else ())


def arm_once(spec, blocked_child, policy, ends, boot, audit, *, marker_directory, fixture_only=False, on_release_attempt=None):
    """One original-UID driver release after TWO distinct successful audits.

    Caller must persist transcripts, hold the official resource lease, provide
    declaration/provenance/capability admission, own reaping, and let data finish
    naturally. This is not a campaign/capture-loop entrypoint.
    """
    api = _api()
    if ends.fixture_only != fixture_only or boot['fixture_only'] != fixture_only:
        raise SessionError('synthetic endpoint provenance cannot arm live data')
    first_sampler, first_wrapper = audit('before-enable')
    gate = api.guard.ArmingGate(first_sampler.instance, first_wrapper.instance, ends.control, ends.ack,
                               blocked_child.go_channel, policy, spec.declaration, spec.nonce)
    wrapper_pipes = frozenset(fd.pipe for fd in first_wrapper.fds if fd.pipe is not None)
    gate.blocked(first_wrapper.instance, wrapper_pipes)
    if api.guard.PipeIdentity.from_fd(ends.control_fd) != ends.control.write_end:
        raise SessionError('controller sampler-control pipe changed')
    if api.guard.PipeIdentity.from_fd(ends.ack_fd) != ends.ack.read_end:
        raise SessionError('controller sampler-ack pipe changed')
    command = gate.request_enable(first_sampler.instance)
    api.guard._write_all(ends.control_fd, command, os.write)
    ack = api.blocked._read_message(ends.ack_fd, 16, 10, require_eof=False)
    if api.guard.PipeIdentity.from_fd(ends.ack_fd) != ends.ack.read_end:
        raise SessionError('controller sampler-ack pipe changed')
    gate.acknowledge(ends.ack.read_end, ack, first_sampler.instance)
    second_sampler, second_wrapper = audit('before-go')
    if (second_sampler.instance != first_sampler.instance or second_wrapper.instance != first_wrapper.instance):
        raise SessionError('armed sampler/wrapper changed before marker')
    gate.consume(Path(marker_directory))
    if on_release_attempt is not None:
        on_release_attempt()  # Full/partial writes or close errors can still release the child.
    gate.release(blocked_child.go_fd, second_sampler.instance, second_wrapper.instance,
                 policy.argv, dict(policy.environment))
    blocked_child.close_go()
    return gate


class LiveBackend:
    fixture_only = False

    def __init__(self, spec, spec_path, spec_sha, bundle_root, manifest_path, log_fd):
        if (sys.platform != 'linux' or os.getuid() == 0 or os.getuid() != os.geteuid()
                or os.getgid() != os.getegid() or (os.geteuid(), os.getegid()) != (spec.controller_uid, spec.controller_gid)):
            raise SessionError('live controller must retain original unprivileged Linux identities')
        verified_bundle(bundle_root, manifest_path, spec.bundle_sha, spec.controller_uid)
        _read_file(spec_path, spec_sha, 65536, owner=spec.controller_uid)
        self.spec, self.log_fd = spec, log_fd
        self.spec_path, self.spec_sha = spec_path, spec_sha
        self.bundle_root, self.manifest_path = bundle_root, manifest_path
        self.children = []

    def launch(self, mode, phase=None):
        args = privileged_argv(self.spec_path, self.spec_sha, self.bundle_root,
                               self.manifest_path, self.spec.bundle_sha, mode, phase)
        child = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=self.log_fd, close_fds=True)
        self.children.append(child)
        return child

    def accept(self, listener, child):
        return listener.accept()

    def handle(self, peer):
        return PidHandle(peer.pid)

    def wait_auditor(self, child):
        if child.wait(timeout=30) != 0:
            raise SessionError('privileged auditor execution failed')


class SessionController:
    """One live/explicit-fixture lifecycle; never select a replacement helper.

    Scope is arming APIs and owned metadata. Caller admits canonical/provenance/
    immutable declaration/actual capability receipts before any data launch, holds
    the official machine lease, persists outputs, owns reaping and natural finish.
    """
    def __init__(self, spec, backend):
        self.spec, self.backend = spec, backend
        self.directory = PrivateDirectory(spec.directory, spec.controller_uid)
        self.state = 'new'
        self.ends = self.boot = self.handle = None
        self.sampler_child = None
        self.audited_phases = []
        self.release_attempted = False
        self.driver = None
        self.driver_exit = None
        self.cleanup_errors = []

    def _save(self, basename, mode, wires):
        return write_report(self.directory, basename, {'context': self.spec.context(mode),
                            'fixture_only': self.backend.fixture_only,
                            'rounds': [{'peer': dataclasses.asdict(wire.peer), 'state': wire.state,
                                        'fixture_only': wire.fixture_only, 'raw_evidence': wire.evidence} for wire in wires]})

    def _finish_protocol(self, basename, mode, wires, sock, listener, auditor_handle=None):
        # A secondary evidence/close failure must not erase the primary refusal.
        primary = sys.exception()
        actions = []
        if sock is not None:
            actions.append(sock.close)
        if auditor_handle is not None:
            actions.append(auditor_handle.close)
        actions.extend((listener.close, lambda: self._save(basename, mode, wires)))
        for action in actions:
            try:
                action()
            except BaseException as error:
                self.cleanup_errors.append({'type': type(error).__name__, 'errno': getattr(error, 'errno', None),
                                            'reason': str(error)})
                if primary is None:
                    primary = error
                    self.state = 'failed'
                else:
                    primary.add_note('protocol cleanup/evidence failure: ' + repr(error))
        if sys.exception() is None and primary is not None:
            raise primary

    def start_helper(self):
        if self.state != 'new':
            raise SessionError('helper lifecycle is terminal')
        self.state = 'failed'
        listener = PrivateListener(self.directory, 'sampler.sock')
        sock, wires = None, []
        try:
            self.sampler_child = self.backend.launch('helper')
            sock, wire = self.backend.accept(listener, self.sampler_child)
            wires.append(wire)
            if wire.fixture_only != self.backend.fixture_only:
                raise SessionError('helper connection provenance differs')
            self.handle = self.backend.handle(wire.peer)  # Bind actual peer BEFORE challenge.
            self.handle.require_alive()
            self.boot = controller_preface(wire, self.spec, 'helper')
            followup = new_round(sock, wire, spec=self.spec, as_controller=True)
            wires.append(followup)
            self.ends = _api().handoff.receive_endpoints(followup, self.spec.declaration, self.spec.nonce)
            self.handle.require_alive()
            self.state = 'handed_off'
            return self.ends
        finally:
            self._finish_protocol('controller-helper.json', 'helper', wires, sock, listener)

    def audit(self, phase):
        expected = 'before-enable' if not self.audited_phases else 'before-go'
        if (self.state not in ('handed_off', 'first_audited') or phase != expected
                or len(self.audited_phases) >= 2):
            raise SessionError('audit lifecycle is terminal or out of order')
        self.state = 'failed'
        self.handle.require_alive()
        listener = PrivateListener(self.directory, 'audit-' + phase + '.sock')
        sock, wires, auditor_handle = None, [], None
        try:
            child = self.backend.launch('audit', phase)
            sock, wire = self.backend.accept(listener, child)
            wires.append(wire)
            if wire.fixture_only != self.backend.fixture_only:
                raise SessionError('auditor connection provenance differs')
            auditor_handle = self.backend.handle(wire.peer)
            auditor_handle.require_alive()
            controller_preface(wire, self.spec, 'audit-' + phase)
            followup = new_round(sock, wire, spec=self.spec, as_controller=True)
            wires.append(followup)
            with followup.once():
                followup.send_frame({'event': 'audit_request', **self.spec.context('audit-' + phase),
                    'target': {'sampler_pid': self.boot['pid'], 'sampler_start': self.boot['start_ticks'],
                               'control': _api().handoff._channel_json(self.ends.control),
                               'ack': _api().handoff._channel_json(self.ends.ack)}})
                response = followup.read_frame()
                common = {'event': 'audit_report', **self.spec.context('audit-' + phase)}
                if (set(response) != set(common) | {'receipt'}
                        or any(type(response[k]) is not type(v) or response[k] != v for k, v in common.items())):
                    raise SessionError('audit receipt context differs')
                report = read_report(self.directory, response['receipt'])
            # The auditor may exit normally after its authenticated response;
            # the SAMPLER pidfd must remain alive throughout report admission.
            self.handle.require_alive()
            result = admit_audit(self.spec, report, phase, self.boot, self.ends.control, self.ends.ack,
                                 fixture_only=self.backend.fixture_only)
            self.backend.wait_auditor(child)
            self.audited_phases.append(phase)
            self.state = 'first_audited' if len(self.audited_phases) == 1 else 'both_audited'
            return result
        finally:
            self._finish_protocol('controller-' + phase + '.json', 'audit-' + phase,
                                  wires, sock, listener, auditor_handle)

    def arm(self, blocked_child, policy, marker_directory):
        if self.state != 'handed_off' or blocked_child.pid != self.spec.wrapper_pid:
            raise SessionError('session cannot rearm or change the owned driver')
        self.driver = blocked_child
        def release_attempt():
            self.release_attempted = True
            self.state = 'release_uncertain'
        try:
            gate = arm_once(self.spec, blocked_child, policy, self.ends, self.boot, self.audit,
                            marker_directory=marker_directory, fixture_only=self.backend.fixture_only,
                            on_release_attempt=release_attempt)
            if self.audited_phases != ['before-enable', 'before-go']:
                raise SessionError('required actual audits missing')
            self.state = 'released'
            return gate
        except BaseException:
            self.state = 'release_uncertain' if self.release_attempted else 'failed'
            raise

    def wait_driver(self, child, timeout=10.0):
        # The controller owns this wait. Never kill/retry/reclaim on a timeout.
        if (child is not self.driver or not self.release_attempted or self.state == 'driver_finished'
                or type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 60):
            raise SessionError('invalid owned driver natural-exit wait')
        result = child.wait(timeout)
        self.driver_exit = result
        self.state = 'driver_finished'
        write_report(self.directory, 'driver-exit.json', {'context': self.spec.context('driver-exit'),
                     'fixture_only': self.backend.fixture_only, 'exit': result})
        return result

    def close_metadata(self):
        # An ambiguous GO may have started a real workload. Keep the sampler alive.
        if self.release_attempted and self.state != 'driver_finished':
            raise SessionError('sampler metadata remains owned until driver natural exit')
        # No process signals/cancellation, capture retries, or marker reclamation.
        if self.ends is not None:
            self.ends.close()
        if self.handle is not None:
            self.handle.close()
        self.directory.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root', required=True)
    parser.add_argument('--bundle-manifest', required=True)
    parser.add_argument('--bundle-sha', required=True)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--spec-sha', required=True)
    parser.add_argument('mode', choices=('helper', 'audit'))
    parser.add_argument('--phase', choices=('before-enable', 'before-go'))
    args = parser.parse_args(argv)
    _check_root_linux()  # Never select fixture/root fallback from CLI data.
    raw = _json(_read_file(args.spec, args.spec_sha, 65536))
    spec = SessionSpec.from_json(raw)
    if spec.controller_uid == 0 or spec.bundle_sha != args.bundle_sha:
        raise SessionError('controller or bundle provenance differs')
    sources = verified_bundle(args.bundle_root, args.bundle_manifest, args.bundle_sha, spec.controller_uid)
    if sources['tool/native_perf_session.py'] != Path(__file__).read_bytes():
        raise SessionError('session bootstrap source differs')
    load_verified_modules(sources, args.bundle_root)
    if args.mode == 'helper':
        run_helper(spec)
    else:
        run_auditor(spec, args.phase)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        record = {'event': 'session_refused', 'type': type(error).__name__, 'errno': getattr(error, 'errno', None)}
        if isinstance(error, SessionError):
            record['reason'] = str(error)
        try:
            os.write(2, _bytes(record) + b'\n')
        finally:
            raise SystemExit(78)
