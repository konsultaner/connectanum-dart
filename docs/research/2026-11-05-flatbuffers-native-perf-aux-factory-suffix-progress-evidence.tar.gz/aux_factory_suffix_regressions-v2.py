"""NEW original factory suffix controls; no Source recovery after refusal."""
from pathlib import Path
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock
import native_perf_build_producer as producer


class AuxiliaryFactorySuffixTests(unittest.TestCase):
    def _suffix_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-suffix-'+mode+'-',dir=os.environ.get('CONNECTANUM_AUX_SUFFIX_FIXTURES',tempfile.gettempdir()))).resolve()
        directory=base/'a';directory.mkdir()
        owner=types.SimpleNamespace(directory=directory,repo=base,environment=dict(os.environ),lease_check=None,auxiliary_operations=[])
        original_list=owner.auxiliary_operations;events=[];actors=[];resources=[];render=[];leases=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after original suffix call')
        cls=producer.AuxiliaryCommand;native_start=cls.start;native_wait=cls.wait;native_allocate=cls._allocate_process
        foreign_marker={'status':'success','primary_error':None,'ROOT_foreign':True}
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        owner.lease_check=verifying
        def allocating(a,record):
            # Actual own resource references BEFORE further setup/native spawn.
            for role,stream in a.streams.items():
                item=dict(operation=a,role=role,fd=stream.get('fd'),log=stream.get('log'),path=stream['path'],fd_identity=None,log_identity=None,log_close=None)
                resources.append(item)
                if type(item['fd']) is int:
                    info=os.fstat(item['fd']);item['fd_identity']=(info.st_dev,info.st_ino)
                if item['log'] is not None:
                    item['log_close']=item['log'].close
                    info=os.fstat(item['log'].fileno());item['log_identity']=(info.st_dev,info.st_ino)
            raw=native_allocate(a,record)
            actors.append(dict(process=raw,bound_wait=raw.wait,operation=a))
            events.append(dict(kind='actual_process_return',is_main=a.name=='suffix-a',pid=raw.pid))
            return raw
        def foreign_wait(a,timeout):
            events.append(dict(kind='foreign_wait_called',timeout=timeout));return foreign_marker
        def starting(a):
            events.append(dict(kind='start_attempt',is_main=a.name=='suffix-a'))
            raw=native_start(a);events.append(dict(kind='actual_start_return',is_main=a.name=='suffix-a',raw_None=raw is None))
            if a.name=='suffix-a':
                seen['main']=a
                if mode=='owner_alias':owner.auxiliary_operations=[]
                if mode=='wait_alias':cls.wait=foreign_wait
                if mode=='start_fault':raise first
                if mode=='normal_false_none':return False
            return raw
        def waiting(a,timeout):
            is_main=a.name=='suffix-a';events.append(dict(kind='wait_attempt',is_main=is_main,timeout=timeout))
            if is_main and mode=='normal_false_none' and not seen.get('returned_None'):
                seen['returned_None']=True;events.append(dict(kind='ROOT_known_None_return'));return None
            raw=native_wait(a,timeout);events.append(dict(kind='actual_wait_return',is_main=is_main,raw_None=raw is None))
            if is_main:
                seen['main']=a;seen['actual_main_result']=raw
                if mode=='foreign_result':return seen['foreign_result']
                if mode=='wait_fault':raise first
                if mode=='wait_False':return False
            return raw
        marker=object();result=marker;received=None;guard_error=None
        try:
            with mock.patch.object(cls,'_allocate_process',allocating),mock.patch.object(cls,'start',starting),mock.patch.object(cls,'wait',waiting):
                if mode=='foreign_result':
                    bdir=base/'b';bdir.mkdir()
                    b=cls(directory=bdir,name='suffix-b',argv=[sys.executable,'-c',"import os;os.write(1,b'FOREIGN-B');os.write(2,b'B-err')"],cwd=base,environment=dict(os.environ),lease_check=verifying,stdout_max=1024)
                    seen['foreign_operation']=b;b.start();br=b.wait(10)
                    if br is None:raise AssertionError('OWN finite B fixture did not complete naturally')
                    seen['foreign_result']=br
                try:result=producer._observe_auxiliary(owner,'suffix-a',[sys.executable,'-c',"import os;os.write(1,b'OWN-A');os.write(2,b'A-err')"],stdout_max=1024)
                except BaseException as error:received=error
                if mode!='normal_false_none':
                    try:producer._auxiliary_factory_guard(owner)
                    except BaseException as error:guard_error=error
            found=[r for r in producer._AUXILIARY_FACTORY_ATTEMPTS if r.owner is owner];attempt=found[-1]
            a=attempt.operation
            rows=[r for r in attempt.steps if r['stage'].startswith('operation_') or r['stage'].startswith('suffix_') or r['stage']=='result_status']
            main_waits=[e for e in events if e['kind']=='wait_attempt' and e['is_main']]
            foreign_calls=[e for e in events if e['kind']=='foreign_wait_called']
            def raw_kind(v):
                if v is None:return 'None'
                return type(v).__name__
            view=dict(mode=mode,events=events,leases=leases,received_type=None if received is None else type(received).__name__,received_original=received is first,
                factory_completed=attempt.completed,factory_first_received=received is not None and attempt.first_error is received,pure_guard_first_is_received=received is not None and guard_error is received,
                returned_foreign_result=mode=='foreign_result' and result is seen.get('foreign_result'),returned_foreign_marker=result is foreign_marker,result_is_own_current=a is not None and result is a.result and result is not None,
                original_owner_count=len(original_list),current_owner_count=len(owner.auxiliary_operations),owner_alias_same=owner.auxiliary_operations is original_list,
                main_wait_attempts=len(main_waits),main_wait_args=[e['timeout'] for e in main_waits],foreign_wait_calls=len(foreign_calls),Source_render_before_asserts=list(render),
                actual_main_result_known='actual_main_result' in seen,actual_main_result_None=seen.get('actual_main_result') is None,
                Source_operation_pending=None if a is None else a.pending,Source_operation_finished=None if a is None else a.finished,
                Source_suffix_rows=[dict(stage=r['stage'],returned=r['returned'],raw_kind=raw_kind(r['raw']),raw_False=r['raw'] is False,raw_foreign=mode=='foreign_result' and r['raw'] is seen.get('foreign_result'),error_is_received=received is not None and r['error'] is received) for r in rows],
                limits='Caller after-return barrier only; actualcallee mayalreadyadvance. Known ROOTboundwait/resources afterevidence UNITnot Sourcecleanup-recovery/physicalEX/ownerrelease/ABA/originalruntimeadmission.')
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            try:
                self.assertEqual([],render);self.assertTrue(all(x['raw_None'] for x in leases))
                if mode=='normal_false_none':
                    self.assertIsNone(received);self.assertIs(result,a.result);self.assertEqual('success',result['status']);self.assertTrue(attempt.completed)
                    self.assertEqual([60,60],[e['timeout'] for e in main_waits]);self.assertEqual(b'OWN-A',(directory/'suffix-a.stdout').read_bytes());self.assertEqual(b'A-err',(directory/'suffix-a.stderr').read_bytes())
                    if rows:
                        self.assertTrue(any(r['stage']=='operation_start' and r['returned'] and r['raw'] is False for r in rows))
                        self.assertTrue(any(r['stage']=='operation_wait' and r['returned'] and r['raw'] is None for r in rows))
                else:
                    if mode in ('start_fault','wait_fault'):self.assertIs(received,first)
                    else:self.assertIs(type(received),producer.ProducerError,'legacy suffix accepted foreign/drift/invalid return or advanced to fallback')
                    self.assertIs(attempt.first_error,received);self.assertIs(guard_error,received);self.assertFalse(attempt.completed)
                    if mode in ('owner_alias','wait_alias','start_fault'):self.assertEqual([],main_waits);self.assertEqual([],foreign_calls)
                    self.assertTrue(rows,'Source suffix intent/raw attempts missing')
                    if mode=='start_fault':
                        row=next(r for r in rows if r['stage']=='operation_start');self.assertFalse(row['returned']);self.assertIsNone(row['raw']);self.assertIs(row['error'],received)
                    if mode=='wait_fault':
                        row=next(r for r in rows if r['stage']=='operation_wait');self.assertFalse(row['returned']);self.assertIsNone(row['raw']);self.assertIs(row['error'],received)
                    if mode=='wait_False':self.assertTrue(any(r['stage']=='operation_wait' and r['returned'] and r['raw'] is False for r in rows))
                    if mode=='foreign_result':self.assertTrue(any(r['stage']=='operation_wait' and r['returned'] and r['raw'] is seen['foreign_result'] for r in rows))
                    count=len(events)
                    try:producer._auxiliary_factory_guard(owner)
                    except BaseException as error:self.assertIs(error,received)
                    else:self.fail('permanently refused factory guard returned')
                    self.assertEqual(count,len(events))
            finally:
                pass
        finally:
            cleanup=[]
            for actor in actors:
                raw=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_bounded_wait',pid=actor['process'].pid,status=raw,cached_possible=True));self.assertTrue(type(raw) is int and raw==0)
            for index,item in enumerate(resources):
                if not evidence_ready:
                    cleanup.append(dict(kind='ROOT_resource_NOread_NOclose_before_evidence',role=item['role']));continue
                row=dict(kind='ROOT_known_unit_resource',role=item['role'],fd_close=False,log_close=False,fd_identity_match=None,log_identity_match=None)
                fd=item['fd']
                if type(fd) is int:
                    try:
                        info=os.fstat(fd);same=(info.st_dev,info.st_ino)==item['fd_identity'];row['fd_identity_match']=same
                        if same:
                            captured=b'';reads=[]
                            for _ in range(4):
                                try:part=os.read(fd,65536)
                                except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                                reads.append(dict(returned=True,size=len(part)));captured+=part
                                if not part:break
                            (base/('ROOT-pipe-'+str(index)+'.bin')).write_bytes(captured);row['ROOT_reads_after_evidence']=reads
                            os.close(fd);row['fd_close']=True
                    except OSError as error:row['fd_error_errno']=error.errno
                f=item['log']
                if f is not None and not f.closed:
                    try:
                        ainfo=os.fstat(f.fileno());binfo=item['path'].stat();same=(ainfo.st_dev,ainfo.st_ino)==item['log_identity']==(binfo.st_dev,binfo.st_ino);row['log_identity_match']=same
                        if same:item['log_close']();row['log_close']=True
                    except (OSError,ValueError) as error:row['log_error_type']=type(error).__name__
                cleanup.append(row)
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_wait_then_foreign_completed_operation_result_is_refused(self):self._suffix_case('foreign_result')
    def test_actual_start_then_owner_ledger_alias_stops_before_wait(self):self._suffix_case('owner_alias')
    def test_actual_start_then_ROOT_error_keeps_unknown_return(self):self._suffix_case('start_fault')
    def test_actual_wait_then_ROOT_error_keeps_unknown_return(self):self._suffix_case('wait_fault')
    def test_actual_wait_then_False_is_known_invalid_not_zero(self):self._suffix_case('wait_False')
    def test_actual_start_then_wait_alias_drift_stops_foreign_call(self):self._suffix_case('wait_alias')
    def test_new_normal_ignored_start_False_and_wait_None_preserve_full_bytes(self):self._suffix_case('normal_false_none')
