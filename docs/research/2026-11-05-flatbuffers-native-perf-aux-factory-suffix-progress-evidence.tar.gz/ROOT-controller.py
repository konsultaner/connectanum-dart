import sys,pathlib,json,ast,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-factory-suffix-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());beforeh=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'candidate-projection-parts.json').read_text())
 assert source==(P/'candidate-v1.py').read_text() and tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'aux_factory_suffix_regressions-v2.py').read_bytes()
 assert source.replace('from types import MappingProxyType, MethodType','from types import MappingProxyType',1).replace(parts['new_suffix'],parts['old_suffix'],1).replace(parts['new_fail'],parts['old_fail'],1)==(P/'before-producer.py').read_text()
 assert sorted(k for k in h if h[k]!=beforeh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(7,6,1,0);assert(a['tests'],a['failures'],a['errors'])==(28,0,0)
 assert len(b['leases'])==14 and len(a['leases'])==56 and all(row['raw_None'] for row in b['leases']+a['leases'])
 def views(path):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if 'Source_suffix_rows' in v}
 old=views(P/'before-units/fixtures');new=views(P/'after-selected/fixtures');assert len(old)==len(new)==7
 assert old['foreign_result'][0]['returned_foreign_result'] and not old['foreign_result'][0]['result_is_own_current']
 assert old['owner_alias'][0]['factory_completed'] and not old['owner_alias'][0]['owner_alias_same'] and old['owner_alias'][0]['main_wait_attempts']==1
 assert old['wait_alias'][0]['foreign_wait_calls']==1 and old['wait_alias'][0]['returned_foreign_marker']
 waits={};cleanups={}
 for phase,data in [('before',old),('after',new)]:
  rows=[row for v,d in data.values() for row in json.loads((d/'ROOT-unit-cleanup.json').read_text())];known=[r for r in rows if r['kind']=='ROOT_same_bounded_wait']
  assert len(known)==8 and all(type(r['status']) is int and r['status']==0 for r in known);waits[phase]=known;cleanups[phase]=rows
 for mode,(v,d) in new.items():
  assert v['Source_render_before_asserts']==[] and all(row['raw_None'] for row in v['leases'])
  rows=v['Source_suffix_rows'];assert rows
  if mode=='normal_false_none':
   assert v['received_type'] is None and v['factory_completed'] and v['result_is_own_current'] and v['main_wait_args']==[60,60]
   assert any(r['stage']=='operation_start' and r['returned'] and r['raw_False'] for r in rows)
   assert any(r['stage']=='operation_wait' and r['returned'] and r['raw_kind']=='None' for r in rows)
  else:
   assert v['factory_first_received'] and v['pure_guard_first_is_received'] and not v['factory_completed'] and not v['returned_foreign_result'] and not v['returned_foreign_marker']
   if mode in ('owner_alias','wait_alias','start_fault'):assert v['main_wait_attempts']==0 and v['foreign_wait_calls']==0
   if mode in ('start_fault','wait_fault'):
    stage='operation_start' if mode=='start_fault' else 'operation_wait';row=next(r for r in rows if r['stage']==stage);assert not row['returned'] and row['raw_kind']=='None' and row['error_is_received'] and v['received_original']
   if mode=='wait_False':
    assert rows[-1]['stage']=='operation_wait' and rows[-1]['returned'] and rows[-1]['raw_False']
   if mode=='foreign_result':assert any(r['stage']=='operation_wait' and r['returned'] and r['raw_foreign'] for r in rows)
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 before=dict(tests=7,failures=6,passes=1,errors=0,meaning='actualA.wait thenactualcompletedB.result isaccepted; owneralias ignored; foreignwait methodcalled afteralias drift;2oldfirst/witness policies andFalseclassification policy NOT6newkernelbugs/RAMcause'),after=a,
 ROOT=dict(whole_final_source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=14,parent_before_EXverify_None=14,parent_AFTER_EXverify_None=56,known_same_bounded_waits=waits,known_unit_resource_cleanup=cleanups,currentcallee_result_identity_and_methodbindings_DATA_notcredentials=True,shared_step_earlyinit_other_Aux_Popen_factories_frozenpredicates_resultliteral_exact=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM=json.loads((P/'candidate-review/result.json').read_text()),advisory_ROOTqualified_NOTwholecurrentapproval=True),scope='ONLYoriginal factorysuffix callintent/raw/originalbindings/context+ownresult return barrier; actualcallee mayalreadyadvance beforepostreturn check',
 limits=['Not6nativekernelbugs: controlledactualcallees/facades reveal1foreigncompletedresult integritygap plusowner/methoddrift andstrongerraw/first/invalidreturn policies; no SourceSDK-workload/RAMcausalclaim.',
 'NormalstartignoredNone-False-object contract andwaitNone loop60 unchanged; currenthelperrefusesbeforeanotherSourcewait/report/close/replay afterselectedfault. UnknownSourcecall raw remainsUNKNOWN despiteROOTknownNone/dict/finalizedfields.',
 'Methods/type/ownerrefs/resultidentity/status/finished/EOF/FD areDATA notsemanticimageauth-atomicABA-originalLinuxcredentials-ownership-physicalEX/admission. Completed meansfactoryresult only; historicalsuccessfulcontexts maynormallychange later.',
 'Callerpost-return checks doNOTpreventnativeops alreadyinsideactualstart/wait. Methodalias guard isbeforeforeigncall onlyafterstart returns; no earlierSourcebarrier claim.',
 '14views/14BEFORE56AFTER parentCURRENT officialDarwinEXverifyNone,8BEFORE8AFTER SAMEknownfiniteRootwait0/cachedpossible UNITnotindependentphysicalEX/allactorclosure. KnownoriginalFD/log refs andidentitychecked ROOTread-close AFTERevidence UNITnotSourcecleanup/recovery/liveEXrelease; error-drift no close/proof. OriginalactorFD/setup APIs notallserialized/no reconstruction/fullreap.',
 'Privatehelperv1UNEXECUTED/v2normalfunctionalcontrol skipsnewrowswhenabsent, AFTER_ROOTrequiresrows; knownRootwaits inouterfinally, FDread-close gatedbyevidence_ready. No invented oldnormalfailure.',
 'BEFOREtooloutput was truncated by2500token cap; preexistingfullresult.json/tests.log retained separately; omittedrawAPIbytes notreconstructed. No allRawAPIcompleteclaim.',
 'Statusfailure str(primary_error) reporting, metadataalteration, unsupportedmethod/returnshapes, deeperNativewait/start/transitiveunknownactors/sharedhistoricalwriters/backingFD, independentcontroller andactualoriginalruntime immutableCOMPLETE admission INCOMPLETE.',
 'Fullenv/journals/refs/closures/tracebacks/raw growthUNMEASURED/notexactheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority.',
 'All20helpers uncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact; no actualSDK-nativebuild-canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.'],
 remaining=['remainingwriter-hash-init APInegative seams/actualFileIO backingwriter-internalFD errors','enclosingproducer cleanup/reporting andsuffixstatusfailure rendering','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedjournalwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['auxiliary_factory_suffix_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Auxiliary_factory_suffix_selected28PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected28PASS=True,new_views=14,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
