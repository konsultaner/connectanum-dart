            self.stage='suffix'
            binding=dict(operation=operation,start=None,wait=None,completed=False)
            self.suffix_context=binding # Before public method lookup/start.
            start=call('operation_start_lookup',lambda:lambda:operation.start)
            wait=call('operation_wait_lookup',lambda:lambda:operation.wait)
            binding['start']=start;binding['wait']=wait

            def method_same(actual,expected):
                return (type(actual) is MethodType and type(expected) is MethodType
                    and actual.__self__ is operation and expected.__self__ is operation
                    and actual.__func__ is expected.__func__)

            def check_suffix():
                self.guard()
                if self.suffix_context is not binding or binding['operation'] is not operation:
                    raise ProducerError('auxiliary factory suffix binding changed')
                self._check_context(owner,context,values,argv,members+(operation,),constructor)
                actual_start=call('suffix_start_binding',lambda:lambda:operation.start)
                actual_wait=call('suffix_wait_binding',lambda:lambda:operation.wait)
                if not method_same(actual_start,start) or not method_same(actual_wait,wait):
                    raise ProducerError('auxiliary factory public method binding changed')

            check_suffix()
            call('operation_start',lambda:start) # Original ignored return, including False.
            check_suffix()
            result=call('operation_result',lambda:getattr,(operation,'result'))
            if result is not None and type(result) is not dict:
                raise ProducerError('unknown auxiliary operation result')
            check_suffix()
            while result is None:
                raw=call('operation_wait',lambda:wait,(60,))
                # Reject known invalid returns BEFORE another public lookup.
                if raw is not None and type(raw) is not dict:
                    raise ProducerError('unknown auxiliary wait return')
                check_suffix()
                current=call('operation_result',lambda:getattr,(operation,'result'))
                if raw is not current:
                    raise ProducerError('auxiliary wait returned a different result')
                check_suffix()
                result=raw
            status=call('result_status',lambda:result.__getitem__,('status',))
            check_suffix()
            if status!='success':raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+str(result['primary_error']))
            binding['completed']=True # Caller result only, never ownership/physical EX.
