import pathlib,sys,json,hashlib,importlib.util,os,stat,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('pr132_NEW_ALL14_math_dynamic_source_alias_intake_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-gcc-math-dynamic-reference-intake-v1';S=B/'2026-11-07-actions-gcc-math-regular-interiors-v1/ROOT-FIRST-ALL4-bounded-static-interpretation-PRIVATE.json';CP=B/'current-task-checkpoint.json';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 decl={'question':'FIRST NEW source/alias relationship metadata intake for ALL10orderedDT_NEEDED/five names plus ALL4DT_SONAME bindings/seven combined names from FIRST saved ALL4mathbody interpretation of originalActions42336634982. Exact inputs current CP and original saved bounded-interpretation JSON ONLY, no savedbody/parser/hash refresh, catalogue stdout/cache lookup, SDK/nativequery/Actions/acquisition/model/archive/numerical replay. Preserve complete original ordered request and EVERY tablebinding object, duplicates/unresolved explicit. Compare ALL7 literal names/hex and ALL4 exact source refs against ALL prior actions_* CP string scalars excluding latest math-interiors node. Retain ALL matching strings/locations/offsets and literal absolute-reference matches without favorablelanguage-version-ABI filter. Matches/nonmatches NOTglobalabsence/newness/bodycoverage/aliasidentity/query/acquisition/executionauthority. SONAME is distinct from NEEDED, no linkfollowing/pathguess/resolve.','all_admission_flags':False}
 save('declaration.json',json.dumps(decl,indent=2));save('controller.py',sys.argv[2]);save('available-new-startup-tool-context.json',json.dumps(v['actual_startup'],ensure_ascii=False,indent=2));bindings=[]
 def read(path,role):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
  try:
   s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);a={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};parts=[]
   while True:
    b=os.read(fd,65536)
    if not b:break
    parts.append(b)
   raw=b''.join(parts);s=os.fstat(fd);z={'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns};assert a==z and len(raw)==a['size'];bindings.append({'path':str(path),'role':role,'before':a,'after':z,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'read_EOF':True});return raw
  finally:os.close(fd)
 rawcp=read(CP,'prior_actions_source_catalogue_reference_metadata_NEW_math_relationship_question');d=json.loads(rawcp);raw=read(S,'saved_NEW_math_bounded_interpretation_metadata_NOT_body_parser_replay');source=json.loads(raw);assert source['source_run']==42336634982 and source['source_commit']=='d64668e660cc72efc53379245022e798aac4680c'
 rows=source['ALL4_bounded_interpretations'];assert len(rows)==4;requests=[];names=[]
 for ordinal,row in enumerate(rows):
  for seg in row.get('ALL_DYNAMIC_segments',[]):
   for req in seg.get('ALL_literal_string_requests',[]):
    item={'source_ordinal':ordinal,'source_reference':row['source_reference'],'DYNAMIC_program_header_ordinal':seg['program_header_ordinal'],'original_complete_string_request':req};requests.append(item)
    for binding in req['ALL_file_backed_table_bindings']:
     lit=binding['literal_string'];assert bytes.fromhex(lit['hex']).decode('utf-8','surrogateescape')==lit['utf8_surrogateescape']
     if lit['utf8_surrogateescape'] not in names:names.append(lit['utf8_surrogateescape'])
 assert len(requests)==14 and sum(x['original_complete_string_request']['tag']==1 for x in requests)==10 and sum(x['original_complete_string_request']['tag']==14 for x in requests)==4 and len(names)==7
 prior_nodes=[k for k in d if k.startswith('actions_') and k!='actions_gcc_math_regular_interiors_v1'];scalars=[]
 def walk(x,path,parent=None):
  if isinstance(x,dict):
   for k,z in x.items():walk(z,path+[k],x)
  elif isinstance(x,list):
   for i,z in enumerate(x):walk(z,path+[i],x)
  elif isinstance(x,str):scalars.append((path,x,parent))
 for key in prior_nodes:walk(d[key],[key])
 resultnames=[]
 for name in names:
  hexname=name.encode('utf-8','surrogateescape').hex();matches=[];absolute=[]
  for location,text,parent in scalars:
   hits=[]
   for role,needle in [('literal_name',name),('literal_bytes_hex',hexname)]:
    positions=[];start=0
    while True:
     pos=text.find(needle,start)
     if pos<0:break
     positions.append(pos);start=pos+len(needle)
    if positions:hits.append({'role':role,'exact_scalar':text==needle,'literal_substring_offsets':positions})
   if hits:matches.append({'JSON_location':location,'literal_scalar':text,'ALL_matches':hits})
   if text.startswith('/') and text.rsplit('/',1)[-1]==name:
    scalarfields={k:z for k,z in parent.items() if z is None or isinstance(z,(str,int,float,bool))} if isinstance(parent,dict) else None
    absolute.append({'JSON_location':location,'literal_absolute_reference':text,'immediate_parent_scalar_fields_UNNORMALIZED_PRIVATE':scalarfields})
  resultnames.append({'literal_name':name,'literal_bytes_hex':hexname,'ALL_source_request_roles':[{'source_ordinal':x['source_ordinal'],'source_reference':x['source_reference'],'tag':x['original_complete_string_request']['tag'],'dynamic_ordinal':x['original_complete_string_request']['dynamic_ordinal']} for x in requests if any(b['literal_string']['utf8_surrogateescape']==name for b in x['original_complete_string_request']['ALL_file_backed_table_bindings'])],'ALL_prior_CP_scalar_matches':matches,'ALL_literal_absolute_reference_matches':absolute,'literal_name_matching_scalar_count':sum(any(h['role']=='literal_name' for h in x['ALL_matches']) for x in matches),'literal_hex_matching_scalar_count':sum(any(h['role']=='literal_bytes_hex' for h in x['ALL_matches']) for x in matches),'scoped_matches_NOT_alias_bodycoverage_globalabsence_newness_permission':True})
 result={'phase':'FIRST_ALL14_math_dynamic_source_alias_intake_COMPLETE_CONSUMED_NOT_admitted','source_run':42336634982,'source_commit':source['source_commit'],'ALL4_source_references':[x['source_reference'] for x in rows],'ALL14_original_complete_string_requests':requests,'ALL7_literal_name_relationships':resultnames,'prior_CP_actions_nodes':prior_nodes,'prior_string_scalar_count':len(scalars),'preserved_prior_source_metadata_NOT_newly_revalidated':source['preserved_prior_source_metadata_NOT_newly_revalidated'],'qualification':'NEW relationship metadata only. ALL10NEEDED/4SONAME distinct fields/seven names/four sources kept, all original source-linkhex/latelexicalepochs/9pathsBOTHlibc/5priorrefs14INTERP exclusions/76earlierNEEDED15sources19records3plugins/unexpanded12plugin/v6/priorledgers preserved NOTbodyrevalidated. CP mentions/literal references are not aliases/bodycoverage/installedversion/default/Cargo/CFG/flavor/header-sysroot/loadedABI/cohort/ownership/access/permission proof. No old savedcatalogue stdout/cache/nativequery/bodyhash/parser/SDK/Actions/acquisition/model/archive/numerical replay, and no automaticname-resolution-follow-query-download-import-compile-execute authority. PointFD/stat/read/close NOTatomicABA-origin/globalnativeactorFD/continuousofficialphysicalEX-crash proof. Original setupUNADMITTED/allflagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.','separate_launcher_PID_pipe_EOF':None,'all_admission_flags':False}
 save('checkpoint-before-intake.json',rawcp);save('original-saved-bounded-metadata-PRIVATE.json',raw);save('metadata-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('ROOT-ALL14-math-dynamic-source-alias-intake-PRIVATE.json',json.dumps(result,ensure_ascii=True,indent=2)+'\n')
 summary={k:z for k,z in result.items() if k not in ['ALL7_literal_name_relationships','prior_CP_actions_nodes','preserved_prior_source_metadata_NOT_newly_revalidated','ALL14_original_complete_string_requests']};summary['ALL7_literal_name_summary']=[{'literal_name':x['literal_name'],'literal_bytes_hex':x['literal_bytes_hex'],'ALL_source_request_roles':x['ALL_source_request_roles'],'literal_name_matching_scalar_count':x['literal_name_matching_scalar_count'],'literal_hex_matching_scalar_count':x['literal_hex_matching_scalar_count'],'ALL_literal_absolute_references_first_order':list(dict.fromkeys(y['literal_absolute_reference'] for y in x['ALL_literal_absolute_reference_matches'])),'ALL_matching_CP_nodes_first_order':list(dict.fromkeys(y['JSON_location'][0] for y in x['ALL_prior_CP_scalar_matches']))} for x in resultnames]
 save('ROOT-ALL14-intake-summary.json',json.dumps(summary,ensure_ascii=True,indent=2)+'\n')
 d['actions_gcc_math_dynamic_reference_intake_v1']={'directory':str(P),**summary,'full_assessment':str(P/'ROOT-ALL14-math-dynamic-source-alias-intake-PRIVATE.json'),'public_documentation_pending':True,'preserved_ALL14_request_objects':True,'all_admission_flags':False};d['active_turn_status']['next']='NEWALL14math dynamic sourcealias intake COMPLETE_CONSUMED; scoped prior metadata mentions/literal refs NOTalias/bodycoverage/newness/permission. Summarize/publish NEWrelationships before any expresslydeclared further input acquisition; do not resolve/query/acquire named oldmath/libc/loader/libm by name. Alloriginalrecipe-preflight/flagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True);lease.verify_identity()
