import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('pr132_NEW_libm_saved_catalogue_metadata_locator_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-gcc-math-libm-catalogue-locator-v1';S=B/'2026-11-07-actions-gcc-math-dynamic-reference-intake-v1/checkpoint-before-intake.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'question':'FIRST bounded metadata locator for NEW libm.so.6 saved-catalogue relationship. ALL14intake gave exactly ONE prior CP name mention in actions_linkage_frontier_v1, no literal absolute-reference matches. This does NOTestablish absent/new/unread/alias/bodycoverage/permission. Read ONLY declared freshly saved CPsnapshot fields of prior linkage-frontier/linkage-inputs nodes to locate alreadyretained catalogue stdout by original metadata; no CPmatch replay/cataloguebytes read/cache/nativequery/SDKbody/hash/Actions/acquisition/model/archive/numerical execution.','source':'2026-11-07-actions-gcc-math-dynamic-reference-intake-v1/checkpoint-before-intake.json','all_admission_flags':False},indent=2));save('controller.py',sys.argv[1])
 d=json.loads(S.read_bytes());nodes={k:d[k] for k in ['actions_linkage_frontier_v1','actions_linkage_inputs_v1']};save('selected-prior-linkage-metadata-PRIVATE.json',json.dumps(nodes,ensure_ascii=False,indent=2));out={}
 for key,node in nodes.items():
  strings=[]
  def walk(x,p):
   if isinstance(x,dict):
    for k,v in x.items():walk(v,p+[k])
   elif isinstance(x,list):
    for i,v in enumerate(x):walk(v,p+[i])
   elif isinstance(x,str) and any(t in x.lower() for t in ['catalog','stdout','raw_directory','/tmp/','task-evidence']):strings.append({'JSON_location':p,'literal_scalar':x})
  walk(node,[key]);out[key]={'keys':list(node),'selected_literal_locator_strings':strings}
 save('ROOT-first-locator-metadata.json',json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out),flush=True);lease.verify_identity()
