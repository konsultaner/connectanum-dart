import pathlib,sys,json,hashlib,importlib.util,os,stat
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('pr132_NEW_libm_saved_catalogue_binding_metadata_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-gcc-math-libm-catalogue-binding-v1';S=B/'2026-11-06-actions-linkage-inputs-v1/actual-new-run-evidence/ROOT-first-linkage-acquisition-assessment.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'question':'FIRST actual retained-acquisition metadata binding for NEW libm.so.6 savedcatalogue question. Exact source comes from preceding CPmetadata locator, not guessed SDK path. Read ONLY original ROOT-first-linkage-acquisition-assessment.json to locate retained catalogue stdout metadata. No cataloguebytes/SDK/librarybody/query/Actions/acquisition/parser/model/archive/numerical replay. This NEWrelationship read is not current installedcache/query/SDK-hash refresh or origin/access/admission proof.','source':'2026-11-06-actions-linkage-inputs-v1/actual-new-run-evidence/ROOT-first-linkage-acquisition-assessment.json','all_admission_flags':False},indent=2));save('controller.py',sys.argv[1])
 fd=os.open(S,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode);before=(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns);parts=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   parts.append(b)
  raw=b''.join(parts);a=os.fstat(fd);assert before==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns) and len(raw)==a.st_size
 finally:os.close(fd)
 d=json.loads(raw);save('original-retained-assessment-metadata-PRIVATE.json',raw);out={'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'keys':list(d),'literal_locator_fields':[]}
 def walk(x,path):
  if isinstance(x,dict):
   if any('catalog' in str(k).lower() for k in x):out['literal_locator_fields'].append({'JSON_location':path,'matching_keys':[k for k in x if 'catalog' in str(k).lower()],'matching_values':{k:x[k] for k in x if 'catalog' in str(k).lower()}})
   for k,v in x.items():walk(v,path+[k])
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+[i])
 walk(d,[]);save('ROOT-retained-catalogue-binding-metadata.json',json.dumps(out,indent=2));print(json.dumps(out),flush=True);lease.verify_identity()
