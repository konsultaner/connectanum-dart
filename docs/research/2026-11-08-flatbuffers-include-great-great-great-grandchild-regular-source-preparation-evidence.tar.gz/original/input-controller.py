import pathlib,sys,json,hashlib,importlib.util,os,stat,contextlib,time,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_NEW375_source_inputs_EX',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-regular-inputs-v1';I=P/'source-preparation-inputs-v1';CP=B/'current-task-checkpoint.json';v=json.loads(sys.argv[1])
inputs=[
('original2279collector',B/'2026-11-07-actions-include-great-great-grandchild-regular-inputs-v1/source-generation-v1/collector.py',14622722,'35f18374649bde94ded2fff22b0f2747e4758ebb7974541d307aa0ddcec03a7e'),
('workflow38',B/'2026-11-07-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-local-static-binding-v1/workflow-bound-PRIVATE',487262,'d7621cd990b04cd238ae781d039d2be5ffc3dc2eb1ff81d467d25369a66c8e8a'),
('NEW375scope',B/'2026-11-07-actions-include-great-great-great-grandchild-regular-scope-v1/ALL375-new-exact-public-safe-regular-scope-BEFORE-INPUT-IO.json',1127177,'65995aaa53e0a93eeb5dca5b388939dd950db8692a0940a0ab06fc519356130e'),
('actual29DIRECTORYmetadata',B/'2026-11-07-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-originalActions-v1/ROOT-NEW-ALL29-directory-input-assessment-PRIVATE.json',302403302,'ecadd53c565423b839ac66309bdee9dfb8b8f95616949c3fa993208891b16ead'),
('actual2279BODYmetadata',B/'2026-11-07-actions-include-great-great-grandchild-regular-inputs-v1/FIRST-originalActions-v1/ROOT-NEW-ALL2279-regular-great-great-grandchild-input-assessment-PRIVATE.json',155697241,'f0fffc459d509f2777a510bb2b748f389a425555502cc8c5ce9dbc676265b1e3'),
('actual199DIRECTORYmetadata',B/'2026-11-07-actions-include-great-great-grandchild-directory-inputs-v1/FIRST-originalActions-v1/ROOT-NEW-ALL199-directory-input-assessment-PRIVATE.json',71009093,'c2b323eed056e924be51db8dff6e2b73f5c41ac5c873adcff17f087e7e98c78c'),
('actual4868BODYmetadata',B/'2026-11-07-actions-include-great-grandchild-regular-inputs-v1/FIRST-remaining-saved4868-verification-v1/ROOT-NEW-ALL4868-regular-great-grandchild-input-assessment-PRIVATE.json',63401479,'a49f18de7e725caedeebcae268c14669346acb1ea4de23f151f61c5d389854f0'),
('actual190DIRECTORYmetadata',B/'2026-11-07-actions-include-grandchild-directory-inputs-v1/FIRST-originalActions-v1/ROOT-NEW-ALL190-directory-input-assessment-PRIVATE.json',21618013,'7d1b45c39fc32fe52e446610d2aa022ea3489b795f75941dff9ead67d47a9082'),
('actual1229BODYmetadata',B/'2026-11-07-actions-include-grandchild-regular-inputs-v1/Actions-v1/ROOT-NEW-ALL1229-regular-grandchild-input-assessment-PRIVATE.json',14412328,'1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331')]
@contextlib.contextmanager
def first_body():
 for attempt in range(1,37):
  cm=m.local_resource_lease(exclusive=True)
  try:lease=cm.__enter__()
  except m.LocalResourceLeaseError as e:
   print(json.dumps({'official_EX_pretarget_refusal':attempt,'body_entered':False,'error':str(e)}),flush=True)
   if attempt==36:raise
   time.sleep(10);continue
  try:yield lease,attempt-1
  except BaseException:
   if not cm.__exit__(*sys.exc_info()):raise
  else:cm.__exit__(None,None,None)
  return
with first_body() as (lease,refusals):
 lease.verify_identity();P.mkdir();I.mkdir()
 def save(n,b):
  with (I/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':v['scope'],'exact_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':h} for r,p,n,h in inputs],'FIRST_new375_selected_original2279_tail_range':[14602722,14622722],'root_literal_selection':'FIRST NEW375 root literal selection ONLY physical lineboundary root = ; originalprefix otherwiseopaque/no oldAST-parser-originalscope-query-reverse-condition replay','prospective_bounded_metadata_copy':True,'saved_metadata_total_declared_bytes':sum(n for r,p,n,h in inputs),'original_metadata_JSON_topkeys_and_qualification_comparisons_UNPERFORMED':None,'all_admission_flags':False,'ownership':None},indent=2));save('controller.py',sys.argv[2]);save('actual-new-input-context.json',json.dumps(v,ensure_ascii=True,indent=2))
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];bindings=[];saved={}
 def snap(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 def readn(fd,n):
  parts=[];count=0
  while count<n:
   b=os.read(fd,n-count);assert b and len(b)<=n-count;parts.append(b);count+=len(b)
  return b''.join(parts)
 for role,path,size,sha in inputs:
  dest=I/(role+'-opaque-bound-PRIVATE');b={'role':role,'path':str(path),'range':[0,size],'expected_sha256':sha,'copy':str(dest),'open_return_fd':None,'close_return_fd':None,'output_open_return_fd':None,'output_close_return_fd':None,'file_EOF_probe':None};bindings.append(b);infd=None;outfd=None;primary=None;retained=[]
  try:
   infd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=infd;b['before'],b['before_atime_ns_POINT_ONLY']=snap(infd);assert b['before']['st_size']==size
   outfd=os.open(dest,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);b['output_open_return_fd']=outfd;b['output_before'],b['output_before_atime_ns_POINT_ONLY']=snap(outfd)
   h=hashlib.sha256();hc=hashlib.sha256();count=0
   while count<size:
    block=readn(infd,min(65536,size-count));sent=0
    while sent<len(block):
     n=os.write(outfd,block[sent:]);assert n>0;sent+=n
    os.lseek(outfd,count,os.SEEK_SET);check=readn(outfd,len(block));assert check==block;h.update(block);hc.update(check);count+=len(block)
    if role in ['original2279collector','NEW375scope']:retained.append(block)
   b['after'],b['after_atime_ns_POINT_ONLY']=snap(infd);b['output_after'],b['output_after_atime_ns_POINT_ONLY']=snap(outfd)
   b.update(bytes=count,sha256=h.hexdigest(),output_readback_sha256=hc.hexdigest(),ALL_bytes_same_OUTPUTFD_BYTEWISE_equal=True)
   assert b['before']==b['after'] and count==size and h.hexdigest()==hc.hexdigest()==sha and b['output_after']['st_size']==size
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  for field,fd in [('output_close_return_fd',outfd),('close_return_fd',infd)]:
   if fd is not None:
    try:os.close(fd);b[field]=fd
    except BaseException as e:
     b[field+'_error_unknown']={'kind':type(e).__name__,'text':str(e)}
     if primary is None:primary=e
  save(role+'-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  if retained:saved[role]=b''.join(retained)
 source=saved['original2279collector'];tail=source[14602722:14622722];save('FIRST-new375-selected-original2279-tail-14602722-14622722.txt',tail);roots=[];offset=0
 for line in source.splitlines(keepends=True):
  if line.startswith(b'root = '):roots.append({'range':[offset,offset+len(line)],'raw_line':line.decode(),'sha256':hashlib.sha256(line).hexdigest()})
  offset+=len(line)
 scope=json.loads(saved['NEW375scope']);refs=scope['ALL375_new_literal_regular_BODYINPUT_references'];assert len(refs)==375
 descriptor={'saved_metadata_bindings':len(bindings),'original_EX_pretarget_refusals':refusals,'original2279collector_bytes':len(source),'original2279collector_sha256':hashlib.sha256(source).hexdigest(),'FIRST_new375_root_candidates':roots,'FIRST_new375_control_tail_range':[14602722,14622722],'FIRST_new375_control_tail_bytes':len(tail),'FIRST_new375_control_tail_sha256':hashlib.sha256(tail).hexdigest(),'NEW375scope_topkeys':list(scope),'NEW375_count':len(refs),'ALL446_original_safe_entry_records':len(scope['ALL446_original_safe_separate_entry_metadata']),'original_prior_metadata_topkeys_UNPERFORMED':None,'prior_literal_qualification_comparisons_UNPERFORMED':None,'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 save('FIRST-input-bindings-and-selected-control-descriptor.json',json.dumps(descriptor,indent=2))
 before=CP.read_bytes();save('checkpoint-before-input-source-preparation.json',before);d=json.loads(before);assert 'actions_include_great_great_great_grandchild_regular_inputs_v1' not in d
 d['actions_include_great_great_great_grandchild_regular_inputs_v1']={'directory':str(P),'phase':'FIRST_NEW375_nine_input_bindings_controlselection_COMPLETE_CONSUMED_remaining_literal_qualification_AND_generation_PENDING_NOT_queried','source_control_and_ledger':descriptor,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_include_great_great_great_grandchild_regular_inputs='FIRSTninebindings-controlselection_complete_remaining_new375referencequalification-generation_pending',next='FIRSTremaining exact savedboundmetadata NEW375 literalreference qualification and selectedcontrol interpretation BEFOREnewsourcegeneration. No nineinputreader-root-tailselection replay; originalprior_metadata_topkeys NULL UNPERFORMED/no oldjournal-stream-bodyhash-query. Preserveoriginal2279 collector/38oldjobs/1199-1229-4868-2279scopesseparate-beforeNEW375loader-beforeINPUT, actualall375priorconsumptionqualification beforefutureSDKINPUT. No SDKINPUT-Actions-sourcecommit-dispatch-Source20runtimeadoption-build-cleanup/allsetupUNADMITTED-flagsFALSE-ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'descriptor':descriptor,'FIRST_selected_tail_UTF8':tail.decode()}),flush=True);lease.verify_identity()
