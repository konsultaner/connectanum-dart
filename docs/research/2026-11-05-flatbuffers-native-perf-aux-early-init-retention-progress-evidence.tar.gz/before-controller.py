import sys,pathlib,json,hashlib,types,unittest,io,os,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-retention-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'before-producer.py').read_bytes() and tests==(P/'before-tests.py').read_bytes()
 free=shutil.disk_usage(R).free;assert free>=1024**3
 q=P/'before-units';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_AUX_EARLY_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('aux_early_init_regressions');tm.__file__=str(P/'aux_early_init_regressions.py');tm.__dict__['official_ex_verify']=l.verify_identity;sys.modules[tm.__name__]=tm;helper=(P/'aux_early_init_regressions.py').read_bytes();exec(compile(helper,tm.__file__,'exec'),tm.__dict__)
 (q/'declaration.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),helper_sha256=hashlib.sha256(helper).hexdigest(),NEW_tests=6,same_process_current_officialEX=True,NOTindependent_physicalEX_or_admission=True),indent=2))
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(tm.AuxiliaryEarlyInitializationTests);out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (q/'tests.log').write_text(out.getvalue());value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],outer_controller_not_numerical_campaign=True,same_process_current_EX_not_fullindependentEX=True)
 (q/'result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_retention_progress'];n.update(summary_pending=False,before_result=value,NEWtests_UNEXECUTED=False,source_UNCHANGED=True,candidate_UNIMPLEMENTED=True);c['active_turn_status']='Auxiliary_early_initializer_NEW6_before_'+str(value['failures'])+'FAIL_'+str(value['errors'])+'ERROR_Source_unchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:v for k,v in value.items() if k!='details'}));print(out.getvalue()[-1500:])
