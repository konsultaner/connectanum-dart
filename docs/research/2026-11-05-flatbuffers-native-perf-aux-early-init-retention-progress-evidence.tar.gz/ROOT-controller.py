import sys,pathlib,json,ast,copy,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-retention-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'candidate-v1.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'aux_early_init_regressions.py').read_bytes()
 old=ast.parse((P/'before-producer.py').read_text());current=ast.parse(source)
 oa=next(n for n in old.body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand');ca=next(n for n in current.body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand')
 oi=next(n for n in oa.body if isinstance(n,ast.FunctionDef) and n.name=='__init__');body=next(n for n in ca.body if isinstance(n,ast.FunctionDef) and n.name=='_initialize_auxiliary');wrapper=next(n for n in ca.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
 assert ast.dump(oi.args,include_attributes=False)==ast.dump(body.args,include_attributes=False)==ast.dump(wrapper.args,include_attributes=False)
 assert [ast.dump(n,include_attributes=False) for n in oi.body]==[ast.dump(n,include_attributes=False) for n in body.body]
 projected=copy.deepcopy(ca);entries=[]
 for n in projected.body:
  if isinstance(n,ast.FunctionDef):
   if n.name=='__new__':continue
   if n.name=='_initialize_auxiliary':continue
   if n.name=='__init__':
    restored=copy.deepcopy(body);restored.name='__init__';entries.append(restored);continue
   if n.name=='_constructor_guard':n.body=n.body[2:]
  entries.append(n)
 projected.body=entries;assert ast.dump(projected,include_attributes=False)==ast.dump(oa,include_attributes=False)
 top=[]
 for n in current.body:
  if isinstance(n,ast.ClassDef) and n.name=='_AuxiliaryInitializationAttempt':continue
  if isinstance(n,ast.FunctionDef) and n.name=='_bind_auxiliary_initialization':continue
  if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='_AUXILIARY_INITIALIZATIONS' for v in n.targets):continue
  top.append(projected if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand' else n)
 assert [ast.dump(n,include_attributes=False) for n in top]==[ast.dump(n,include_attributes=False) for n in old.body]
 before=json.loads((P/'before-units/result.json').read_text());assert(before['tests'],before['failures'],before['passes'],before['errors'])==(6,4,2,0)
 after=json.loads((P/'after-selected/result.json').read_text());assert(after['tests'],after['failures'],after['errors'])==(33,0,0)
 views=lambda path:{v['mode']:v for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())]}
 b=views(P/'before-units/fixtures');a=views(P/'after-selected/fixtures');assert len(a)==len(b)==6
 for mode,v in a.items():
  assert v['Source_record_at_init_entry'] and v['record_present'] and v['record_origin']=='public_new' and v['allocation_returned'] is True
  assert v['Source_render_calls_before_unitasserts']==[]
  if mode not in ('normal','outside_False'):
   assert v['owner_count']==v['process_returns']==0 and v['record_first_is_received'] and v['guard_first_is_received']
   assert not v['initializer_completed'] and v['initializer_returned'] is None
  elif mode=='outside_False':
   assert v['received_type']=='TypeError' and v['owner_count']==v['process_returns']==0
   assert v['initializer_completed'] and v['initializer_returned'] is True and v['actual_initializer_return_None']
 for mode in ['directory_error','cwd_error','producer_hash_error']:
  assert a[mode]['Source_same_object_before_first_IO'] and not b[mode]['Source_same_object_before_first_IO']
 assert not any(e['kind']=='resolve_return' for e in a['invalid_declaration']['events'])
 observations=json.loads((P/'after-selected/Source-construction-observations-DATA-only.json').read_text());records=observations['records']
 assert records and all(r['public_constructor_returned'] is None for r in records)
 assert any(r['origin']=='direct_initializer_data_only' for r in records)
 assert all(r['allocation_returned'] is None for r in records if r['origin']=='direct_initializer_data_only')
 clean=[json.loads(f.read_text()) for f in (P/'after-selected/fixtures').glob('*/ROOT-unit-cleanup.json')]
 newwaits=[row for rows in clean for row in rows];assert len(clean)==6 and len(newwaits)==1 and newwaits[0]['status']==0
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''


 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=6,failures=4,passes=2,errors=0,interpretation='all4 first errors already escape original publicfactory; new explicitSource preIOobject retention and purefirstguard policies fail; NOT4nativebugs/globallylostobject/RAMcause'),after=after,ROOT=dict(whole_final_source_tests_AST_qualified=True,wholeSource_BYTE_projectsback_proof=json.loads((P/'candidate-ROOT-projection.json').read_text()),original_initializer_BODY_signature_exact=True,original_factory_and_other_Aux_methods_except_guardprefix_exact=True,oldtests_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,original_public_classcall_not_preallocation=True,Source_record_before_first_IO=True,allocation_initializer_vs_publicconstructor_facts_separate=True,outsideFalse_TypeError_preserved=True,logical_construction_record_count=observations['logical_count'],not_heap_RSS_EX_or_methodauthority=True,new_views=12,new_normal_ROOT_same_bounded_waits=1,cached_possible=True),models=dict(Gemma=dict(pid=95826,status=0,stdout_size=1507,stderr_size=323),GLM_architecture=dict(pid=96522,status=0,stdout_size=2408,stderr_size=602),Qwen=dict(pid=96971,status=0,stdout_size=2410,stderr_size=484),GLM_review=dict(pid=97945,status=0,stdout_size=6490,stderr_size=1125),all_reaped_advisory_ROOTqualified_NOT_wholecurrentapproval=True),scope='ONLY original ordinary allocation/early initializer explicitretention and firsterror/pureguard progress; outerclasscall/ownerappend barrier NOTcomplete',limits=['No callback/flag/type/record/object/initializerNone/complete/PID/FD/status facts grant partialPopen or owner methodauthority/credentials/physicalEX/runtimeadmission','public_constructor_returned remainsNone even normal; originalfactory appends actualreturnedobject beforestart, existing comment alreadytrue; outsideRootFalse maypublishintent BEFORE actualtypecallTypeError, samebaseline behavior/no deletion-recovery','Directinitializer registrations retain receivedself asDATA, allocation UNKNOWN/no retagging originalpublicfactoryproof','Before+after are sameprocess CURRENTactualofficialEX, not independent fullEX controller or originalLinuxcredential proof','No negativeSource start/wait/reinit, onlypurefirstguard; newnormalfinitePythonactor knownRootboundwait0afterraws UNITnotlivecontinuation/closure/EXrelease','Legacysetup/actorFD/interpreter/delegate/descendant APIreturns notall serialized; no missing-data reconstruction/fullreapclaim','Allocation/subclass/argumentbinding/metadatadamage/privatebodyFalse/outerclasscall/ownerappend/normalconstruction repeatedcontext negativebranches Sourceonly/unexecuted; no fullclosure claim','Registry/arguments/environments/sharedrefs/closure/traceback growth UNMEASURED, no exactheapRSSbound/leak/timing/cause/reset-evict-delete permission','Source tools all20uncommitted-uncanonical-unadmitted; production601 exact; no actualSDK-nativebuild-current20canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictdispatch','Provider absent/gate alwaysraises/controller closed/ownershipNone/all3flagsFalse'],remaining=['originalfactory classcall/rawreturn/ownerappend/context stop-barrier progress','pernative earlier initializer/writer/hash API-negative seams','actual FileIO backing writers/internalFDerrors','enclosingproducer cleanup/reporting','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').write_text(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_retention_progress'];n.update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False);c['active_turn_status']='Auxiliary_early_init_selected33PASS_ROOTqualified_DOCS_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],tests=33,git4_0_BOTH_EOF=True,logical_records=observations['logical_count'],free_bytes=free,full_admission=False)))
