import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-retention-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 h=json.loads((P/'after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1073741824
 q=P/'after-selected';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir()
 os.environ['CONNECTANUM_AUX_EARLY_FIXTURES']=str(fixtures);os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 classes=['AuxiliaryEarlyInitializationTests','AuxiliaryConstructorQuarantineTests','AuxiliaryInitLeaseProgressTests','AuxiliaryIntentCallProgressTests']
 names=[cls+'.'+name for cls in classes for name in unittest.defaultTestLoader.getTestCaseNames(getattr(tm,cls))]
 names+=['AllocatedAuxiliaryProcessTests.test_normal_allocated_Auxiliary_history_remains_DATA_only','AllocatedAuxiliaryProcessTests.test_failed_initializer_allocated_Auxiliary_stays_unknown_DATA','ProducerTests.test_receipt_fixture_canonical_links_actual_logs_and_inputs','AuxiliaryStartupResourceQuarantineTests.test_actual_nonblocking_return_then_fault_refuses_cleanup','AuxiliaryFinalizationQuarantineTests.test_normal_actual_natural_wait_log_finalization_and_result']
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,selection=names,expected_count=33,scope='6matchingNEW +27affected original ctor-Popen guards/INIT/intent/direct-allocation history/startup/finalization/FIXTUREreceipt at changed Auxiliary constructor epoch. Not current20canonical or runtimeadmission',hashes=h),f,indent=2)
 assert len(names)==33
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,tm))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (q/'tests.log').write_text(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_original_runtime_admission=True)
 (q/'result.json').write_text(json.dumps(value,indent=2))
 observations=[dict(origin=r.origin,allocation_attempted=r.allocation_attempted,allocation_returned=r.allocation_returned,initializer_attempted=r.initializer_attempted,initializer_returned=r.initializer_returned,initializer_completed=r.initializer_completed,public_constructor_returned=r.public_constructor_returned,first_error_type=None if r.first_error is None else type(r.first_error).__name__) for r in producer._AUXILIARY_INITIALIZATIONS]
 assert all(r['public_constructor_returned'] is None for r in observations)
 assert all(r['allocation_returned'] is None for r in observations if r['origin']=='direct_initializer_data_only')
 (q/'Source-construction-observations-DATA-only.json').write_text(json.dumps(dict(records=observations,logical_count=len(observations),not_heap_RSS_EX_or_methodauthority=True),indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_retention_progress'];n.update(after_pending=False,after_result=value);c['active_turn_status']='Auxiliary_early_init_AFTER_'+str(result.testsRun)+'_tests_'+str(len(result.failures))+'FAIL_'+str(len(result.errors))+'ERROR_ROOT_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(value));print(out.getvalue()[-1200:])
 if not result.wasSuccessful():sys.exit(1)
