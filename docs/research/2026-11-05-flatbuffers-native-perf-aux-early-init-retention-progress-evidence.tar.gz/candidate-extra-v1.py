# Allocation/initializer observations only; never public-constructor authority.
_AUXILIARY_INITIALIZATIONS = []


class _AuxiliaryInitializationAttempt(_JSONWriteAttempt):
    def __init__(self,origin,requested_class):
        super().__init__(None,None)
        self.origin=origin
        self.requested_class=requested_class
        self.constructor_arguments=None
        self.object=None
        self.allocation_attempted=False
        self.allocation_returned=None
        self.initializer_attempted=False
        self.initializer_returned=None
        self.initializer_result=None
        self.initializer_completed=False
        self.public_constructor_returned=None


def _bind_auxiliary_initialization(instance,record):
    record.object=instance
    def first_guard():
        record.guard() # Exact private first, before probing half-built fields.
        if record.initializer_attempted is not True:
            record._fail(ProducerError('auxiliary initializer entry is unconfirmed'))
    object.__setattr__(instance,'_initialization_progress',record)
    object.__setattr__(instance,'_initialization_first_guard',first_guard)
