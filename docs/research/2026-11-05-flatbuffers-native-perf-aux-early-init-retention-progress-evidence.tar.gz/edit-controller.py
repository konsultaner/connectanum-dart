import sys,pathlib,json,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-factory-retention-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();old=(P/'before-producer.py').read_bytes();oldtests=(P/'before-tests.py').read_bytes()
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==old
 assert (R/'tool/test_native_perf_build_producer.py').read_bytes()==oldtests
 proof=json.loads((P/'candidate-ROOT-projection.json').read_text());assert proof['whole_Source_BYTE_projects_back']
 source=(P/'candidate-v1.py').read_bytes();tests=oldtests+b'\n\n'+(P/'aux_early_init_regressions.py').read_bytes()
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(tests)
 previous=json.loads((P/'before-hashes.json').read_text());h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in previous}
 assert sorted(k for k in previous if previous[k]!=h[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').write_bytes(source);(P/'after-tests.py').write_bytes(tests);(P/'after-edit-hashes.json').write_text(json.dumps(h,indent=2))
 result=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],other18helpers3bins_unchanged=True,oldtests_PREFIX_exact=True,wholeSource_BYTEprojectsback=True,original_initializer_BODY_signature_exact=True,normalpublicfactory_BYTE_exact=True,SourceCtor_Popen_factories_gates_unchanged=True)
 (P/'edit-result.json').write_text(json.dumps(result,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['auxiliary_factory_retention_progress'];n.update(source_UNCHANGED=False,candidate_UNIMPLEMENTED=False,edit=result,after_pending=True,summary_pending=False);c['active_turn_status']='Auxiliary_early_init_NEW6_before4FAIL2PASS_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(result))
