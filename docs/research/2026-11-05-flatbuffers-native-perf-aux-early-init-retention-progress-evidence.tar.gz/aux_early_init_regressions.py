"""Original public-factory early-init units; records are not method authority."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock
import native_perf_build_producer as producer


class AuxiliaryEarlyInitializationTests(unittest.TestCase):
    def _early_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-early-'+mode+'-',dir=os.environ.get('CONNECTANUM_AUX_EARLY_FIXTURES',tempfile.gettempdir()))).resolve()
        payload=b'OWN-original-public-factory'
        owner=types.SimpleNamespace(directory=base,repo=base,environment=dict(os.environ),lease_check=None,auxiliary_operations=[])
        seen={};events=[];lease_rows=[];actors=[];render=[];early=False
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT early init fault')
        actual_init=producer.AuxiliaryCommand.__init__;actual_resolve=Path.resolve
        actual_hash=producer._regular_hash;actual_start=producer.AuxiliaryCommand.start
        actual_allocate=producer.AuxiliaryCommand._allocate_process

        def retained(a):
            records=getattr(producer,'_AUXILIARY_INITIALIZATIONS',None)
            if type(records) is not list:return None
            values=[r for r in records if getattr(r,'object',None) is a]
            return values[-1] if values else None

        def verify():
            raw=official_ex_verify()
            lease_rows.append(dict(returned=True,raw_is_None=raw is None))
            return raw
        owner.lease_check=verify
        def initializing(a,*args,**kwargs):
            nonlocal early
            seen['object']=a
            seen['record_at_public_init_entry']=retained(a)
            events.append(dict(kind='public_init_enter',source_retained=retained(a) is not None))
            try:
                raw=actual_init(a,*args,**kwargs)
                seen['actual_initializer_returned']=True;seen['actual_initializer_result']=raw
                events.append(dict(kind='original_init_return',raw_None=raw is None))
                if mode=='outside_False':return False
                return raw
            except BaseException as error:
                seen['body_error']=error
                raise
        def resolving(path,*args,**kwargs):
            nonlocal early
            raw=actual_resolve(path,*args,**kwargs)
            count=sum(e['kind']=='resolve_return' for e in events)+1
            a=seen.get('object');r=None if a is None else retained(a)
            events.append(dict(kind='resolve_return',count=count,source_retained=r is not None,source_same_object=r is not None and r.object is a))
            if mode=='directory_error' and count==1 or mode=='cwd_error' and count==2:
                early=True;raise first
            return raw
        def hashing(path,*args,**kwargs):
            nonlocal early
            raw=actual_hash(path,*args,**kwargs)
            events.append(dict(kind='hash_return',raw_string=type(raw) is str))
            if mode=='producer_hash_error':early=True;raise first
            return raw
        def starting(a):
            events.append(dict(kind='start_attempt',owner_retained=any(x is a for x in owner.auxiliary_operations)))
            return actual_start(a)
        def allocating(a,record):
            raw=actual_allocate(a,record)
            actors.append(dict(process=raw,bound_wait=raw.wait))
            events.append(dict(kind='process_return',pid=raw.pid))
            return raw

        received=None;guard_error=None;result=None
        argv=[] if mode=='invalid_declaration' else [sys.executable,'-c',"import os;os.write(1,"+repr(payload)+")"]
        try:
            with mock.patch.object(producer.AuxiliaryCommand,'__init__',initializing),mock.patch.object(Path,'resolve',resolving),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer.AuxiliaryCommand,'start',starting),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocating):
                try:result=producer._observe_auxiliary(owner,'original-public',argv,stdout_max=1024)
                except BaseException as error:received=error
                if mode not in ('normal','outside_False'):
                    try:seen['object']._constructor_guard()
                    except BaseException as error:guard_error=error
            a=seen['object'];record=retained(a)
            intent=base/'original-public-intent.json'
            view=dict(mode=mode,events=events,owner_count=len(owner.auxiliary_operations),process_returns=len(actors),
                actual_public_constructor_type_call=True,ROOT_init_facade_receives_actualself_NOT_preallocated=True,
                Source_record_at_init_entry=seen['record_at_public_init_entry'] is not None,
                Source_same_object_before_first_IO=next((e['source_same_object'] for e in events if e['kind']=='resolve_return'),None),
                record_present=record is not None,record_origin=None if record is None else record.origin,
                allocation_returned=None if record is None else record.allocation_returned,
                initializer_attempted=False if record is None else record.initializer_attempted,
                initializer_returned=None if record is None else record.initializer_returned,
                initializer_result_None=False if record is None else record.initializer_result is None,
                initializer_completed=False if record is None else record.initializer_completed,
                record_first_is_received=record is not None and record.first_error is received and received is not None,
                received_original=received is first,received_type=None if received is None else type(received).__name__,
                guard_first_is_received=received is not None and guard_error is received,
                guard_error_type=None if guard_error is None else type(guard_error).__name__,
                actual_initializer_returned=seen.get('actual_initializer_returned',False),
                actual_initializer_return_None=seen.get('actual_initializer_returned',False) and seen.get('actual_initializer_result') is None,
                Source_render_calls_before_unitasserts=list(render),lease_rows=lease_rows,
                intent_exists=intent.exists(),result_returned=result is not None,
                limits='Source allocation/initializer facts DATA only; outer public-classcall/ownerauthority/partialPopen/physicalEX/admission not inferred')
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n')
            self.assertEqual([],render)
            self.assertTrue(all(x['raw_is_None'] for x in lease_rows))
            if mode=='normal':
                self.assertTrue(received is None)
                self.assertEqual(1,len(owner.auxiliary_operations));self.assertTrue(owner.auxiliary_operations[0] is a)
                self.assertEqual('success',result['status'])
                self.assertEqual(payload,(base/'original-public.stdout').read_bytes())
                self.assertTrue(next(e['owner_retained'] for e in events if e['kind']=='start_attempt'))
            elif mode=='outside_False':
                self.assertTrue(type(received) is TypeError,'normal public type call must reject non-None initializer return')
                self.assertTrue(seen.get('actual_initializer_returned',False))
                self.assertTrue(seen.get('actual_initializer_result') is None)
                self.assertEqual(0,len(owner.auxiliary_operations));self.assertEqual([],actors)
                # Source initializer returned None; ROOT False is outside it.
                # Do NOT infer public classcall success or invoke object methods.
            else:
                if mode=='invalid_declaration':
                    self.assertTrue(type(received) is producer.ProducerError)
                    self.assertFalse(any(e['kind']=='resolve_return' for e in events))
                else:self.assertTrue(received is first,'earliest original error changed')
                self.assertEqual(0,len(owner.auxiliary_operations));self.assertEqual([],actors)
                self.assertTrue(record is not None,'Source did not retain original allocated object')
                self.assertTrue(seen['record_at_public_init_entry'] is record,'Source object retention must precede initializer and IO')
                self.assertTrue(record.object is a)
                self.assertTrue(record.first_error is received)
                self.assertTrue(guard_error is received,'pure guard probed missing fields instead of first')
                self.assertFalse(record.initializer_completed)
                self.assertIsNone(record.initializer_returned)
                count=len(events)
                try:a._constructor_guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('pure early guard accepted failed initialization')
                self.assertEqual(count,len(events))
        finally:
            cleanup=[]
            for row in actors:
                raw=row['bound_wait'](10)
                cleanup.append(dict(kind='ROOT_bounded_same_finite_wait',pid=row['process'].pid,status=raw,cached_possible=True))
                self.assertTrue(type(raw) is int and raw==0)
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_original_public_factory_directory_resolve_error_retains_first(self):self._early_case('directory_error')
    def test_original_public_factory_cwd_resolve_error_retains_first(self):self._early_case('cwd_error')
    def test_original_public_factory_producer_hash_error_retains_first(self):self._early_case('producer_hash_error')
    def test_original_public_factory_invalid_declaration_retains_before_IO(self):self._early_case('invalid_declaration')
    def test_normal_original_public_factory_keeps_bytes_and_owner_before_start(self):self._early_case('normal')
    def test_public_class_call_still_rejects_outside_initializer_False(self):self._early_case('outside_False')
