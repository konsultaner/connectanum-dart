import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 exec(compile("import ast,sys,pathlib,json,hashlib,os,io,types,unittest,datetime\nR=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')\nP=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation')\nsha=lambda b:hashlib.sha256(b).hexdigest()\ndef put(path,data):\n with path.open('x') as f:json.dump(data,f,indent=2);f.write('\\n')\ndef snapshot(stage):\n target=P/(stage+'-source');target.mkdir();h={}\n for rel in expected:\n  b=(R/rel).read_bytes();path=target/rel;path.parent.mkdir(exist_ok=True);path.write_bytes(b);h[rel]=sha(b)\n put(P/(stage+'-hashes.json'),h);return h\ndef run_tests(stage,names):\n h=snapshot(stage);fixtures=P/(stage+'-fixtures');fixtures.mkdir()\n os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True\n modules=[]\n for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('receipt_resources_selected_tests','tool/test_native_perf_build_producer.py')]:\n  mod=types.ModuleType(name);mod.__file__=str(R/rel);assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)\n  raw=(P/(stage+'-source')/rel).read_bytes();assert sha(raw)==h[rel];exec(compile(raw,str(R/rel),'exec'),mod.__dict__)\n suite=unittest.TestSuite()\n for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))\n output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)\n with (P/(stage+'-tests.log')).open('x') as f:f.write(output.getvalue())\n value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),\n  successful=result.wasSuccessful(),scope='NEW finite OWN unit fixtures only, not canonical/admission/runtime',source_sha256=h,\n  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],\n  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])\n put(P/(stage+'-tests.json'),value)\n for name in reversed(modules):sys.modules.pop(name)\n return value\n",'receipt-reader-strict-fixed-core.py','exec'))
 expected=json.loads((P/'strict-before-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in expected.items())
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/native_perf_build_producer.py';body=path.read_text();tree=ast.parse(body);lines=body.splitlines(keepends=True);edits=[]
 for node in tree.body:
  if not isinstance(node,ast.FunctionDef) or not node.name.startswith('_receipt_reader_'):continue
  value=ast.get_source_segment(body,node)
  if node.name=='_receipt_reader_guard':
   value=value.replace("or not any(item is reader for item in run._receipt_readers)\n            or reader['quarantined'] or reader['close_attempted']):",
    "or type(run._receipt_readers) is not list or not any(item is reader for item in run._receipt_readers)):")
   needle="        _receipt_reader_context(run,closing=closing)\n        purpose,path,kind,maximum,owners=reader['binding']"
   replacement="""        if (any(type(reader.get(key)) is not bool for key in ('quarantined','close_attempted','read_uncertain','eof','open_attempted'))
            or reader['quarantined'] is True or reader['close_attempted'] is True or reader.get('open_returned') is not True
            or type(reader.get('offset')) is not int or reader['offset']<0):
            raise ProducerError('unknown receipt reader progress fields')
        _receipt_reader_context(run,closing=closing)
        binding=reader['binding']
        if type(binding) is not tuple or len(binding)!=5:
            raise ProducerError('unknown receipt reader binding')
        purpose,path,kind,maximum,owners=binding
        if (type(purpose) is not str or type(kind) is not str or kind not in ('hash','snapshot','json','metadata')
            or type(maximum) is not int or maximum<0 or type(owners) is not frozenset
            or any(type(owner) is not int for owner in owners)
            or type(reader.get('role')) is not str or reader['role']!='reader:'+purpose):
            raise ProducerError('unknown receipt reader binding scalars')
        if (type(reader.get('path_before')) is not tuple or len(reader['path_before'])!=9
            or any(type(item) is not int for item in reader['path_before'])
            or (reader.get('identity') is not None and (type(reader['identity']) is not tuple
                or len(reader['identity'])!=9 or any(type(item) is not int for item in reader['identity'])))):
            raise ProducerError('unknown receipt reader identity fields')"""
   assert value.count(needle)==1;value=value.replace(needle,replacement)
   needle="        reader['quarantined']=True;run._receipt_resources_quarantined=True\n        raise"
   replacement="""        run._receipt_resources_quarantined=True
        if type(reader) is dict and all(type(key) is str for key in reader):reader['quarantined']=True
        raise"""
   assert value.count(needle)==1;value=value.replace(needle,replacement)
  if node.name=='_receipt_reader_open':
   needle="""        if reader['open_returned'] is None:reader['open_returned']=False
        _receipt_resource_error(run,reader,'reader_open:'+purpose,error,True)"""
   replacement="""        _receipt_reader_error(run,reader,'reader_open:'+purpose,error,True)
        if type(reader) is dict and all(type(key) is str for key in reader) and reader.get('open_returned') is None:
            reader['open_returned']=False"""
   assert value.count(needle)==1;value=value.replace(needle,replacement)
  if node.name=='_receipt_reader_read':
   needle="""        reader['read_uncertain']=True
        _receipt_resource_error(run,reader,'reader_read:'+reader['purpose'],error)"""
   replacement="""        _receipt_reader_error(run,reader,'reader_read',error,read_uncertain=True)"""
   assert value.count(needle)==1;value=value.replace(needle,replacement)
  if node.name=='_receipt_reader_close':
   needle="    if reader['quarantined'] or reader['close_attempted']:return"
   replacement="""    if (type(reader) is dict and all(type(key) is str for key in reader)
        and (reader.get('quarantined') is True or reader.get('close_attempted') is True)):return"""
   assert value.count(needle)==1;value=value.replace(needle,replacement)
   value=value.replace("_receipt_resource_error(run,reader,'reader_close:'+reader['purpose'],error,True,secondary=primary is not None)",
    "_receipt_reader_error(run,reader,'reader_close',error,True,secondary=primary is not None)")
  if node.name=='_receipt_reader_scan':
   needle="_receipt_resource_error(run,reader,'reader_body:'+purpose,error)"
   assert value.count(needle)==1;value=value.replace(needle,"_receipt_reader_error(run,reader,'reader_body:'+purpose,error)")
  if value!=ast.get_source_segment(body,node):edits.append((node.lineno-1,node.end_lineno,value+'\n'))
 assert len(edits)==5
 for begin,end,value in sorted(edits,reverse=True):lines[begin:end]=[value]
 body=''.join(lines)
 assert body.count('def _receipt_reader_context(')==1
 body=body.replace('def _receipt_reader_context(',"def _receipt_reader_error(run,reader,stage,error,uncertain=False,secondary=False,read_uncertain=False):\n    # Owner history precedes updates to possibly damaged per-reader dictionaries.\n    first=_retain_receipt_error(run,stage,error,secondary=secondary)\n    if uncertain:run._receipt_resources_quarantined=True\n    if type(reader) is dict and all(type(key) is str for key in reader):\n        if reader.get('first_error') is None:reader['first_error']=error\n        reader['error_stage']=stage\n        if uncertain:reader['quarantined']=True\n        if read_uncertain:reader['read_uncertain']=True\n    return first\n"+'\ndef _receipt_reader_context(',1)
 ast.parse(body);path.write_text(body)
 result=run_tests('strict-fixed',[
  'ReceiptReaderTests.test_ambient_native_close_error_preserved_without_hooks_or_new_IO',
  'ReceiptReaderTests.test_body_first_survives_native_close_BaseException_with_zero_hooks',
  'ReceiptReaderTests.test_exact_FD_retained_before_first_metadata_callback_fault',
  'ReceiptReaderTests.test_four_reader_kinds_preserve_bytes_hash_and_empty_snapshot',
  'ReceiptReaderTests.test_callback_same_file_foreign_FD_refuses_before_read',
  'ReceiptReaderTests.test_JSON_validation_remains_strict',
  'ReceiptReaderLinkTests.test_existing_archive_hardlink_is_read_without_copy_or_retag',
  'ReceiptReaderIntegrationTests.test_actual_Fixture_receipt_uses_all_direct_reader_bindings',
  'ReceiptReaderStrictTests.test_unknown_binding_never_invokes_custom_iterator',
  'ReceiptReaderStrictTests.test_unknown_purpose_never_runs_error_stage_hook',
  'ReceiptReaderStrictTests.test_callback_dropped_error_field_cannot_mask_exact_primary'])
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['receipt_reader_implementation_component'].update(source_sha256=result['source_sha256']['tool/native_perf_build_producer.py'],
  test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],
  NEWstrict_before=dict(tests=3,failures=3,errors=0),FINAL_selected=dict(tests=result['tests'],failures=result['failures'],errors=result['errors']),
  full_final_canonical=False,review_epoch='ece585/19e0 before NEW strict tests/guards; ROOT final inspection pending',review_pending=False)
 native['current_helper_source_epoch'].update(producer_sha256=result['source_sha256']['tool/native_perf_build_producer.py'],
  test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'strict-fixed-hashes.json'))
 value['active_turn_status']='receipt_reader_current_source_selected_controls_complete_ROOT_final_assessment_pending'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(tests=result['tests'],failures=result['failures'],errors=result['errors'],
 producer=result['source_sha256']['tool/native_perf_build_producer.py'],test=result['source_sha256']['tool/test_native_perf_build_producer.py'])))
