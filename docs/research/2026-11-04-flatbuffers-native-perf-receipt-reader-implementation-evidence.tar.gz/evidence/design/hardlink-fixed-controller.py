import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 exec(compile("import ast,sys,pathlib,json,hashlib,os,io,types,unittest,datetime\nR=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')\nP=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation')\nsha=lambda b:hashlib.sha256(b).hexdigest()\ndef put(path,data):\n with path.open('x') as f:json.dump(data,f,indent=2);f.write('\\n')\ndef snapshot(stage):\n target=P/(stage+'-source');target.mkdir();h={}\n for rel in expected:\n  b=(R/rel).read_bytes();path=target/rel;path.parent.mkdir(exist_ok=True);path.write_bytes(b);h[rel]=sha(b)\n put(P/(stage+'-hashes.json'),h);return h\ndef run_tests(stage,names):\n h=snapshot(stage);fixtures=P/(stage+'-fixtures');fixtures.mkdir()\n os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True\n modules=[]\n for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('receipt_resources_selected_tests','tool/test_native_perf_build_producer.py')]:\n  mod=types.ModuleType(name);mod.__file__=str(R/rel);assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)\n  raw=(P/(stage+'-source')/rel).read_bytes();assert sha(raw)==h[rel];exec(compile(raw,str(R/rel),'exec'),mod.__dict__)\n suite=unittest.TestSuite()\n for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))\n output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)\n with (P/(stage+'-tests.log')).open('x') as f:f.write(output.getvalue())\n value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),\n  successful=result.wasSuccessful(),scope='NEW finite OWN unit fixtures only, not canonical/admission/runtime',source_sha256=h,\n  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],\n  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])\n put(P/(stage+'-tests.json'),value)\n for name in reversed(modules):sys.modules.pop(name)\n return value\n",'receipt-reader-hardlink-fixed-core.py','exec'))
 expected=json.loads((P/'hardlink-before-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in expected.items())
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/native_perf_build_producer.py';body=path.read_text()
 needle='or info.st_nlink!=1 or not 0<=info.st_size<=maximum'
 assert body.count(needle)==1
 body=body.replace(needle,'or info.st_nlink<1 or not 0<=info.st_size<=maximum',1);ast.parse(body);path.write_text(body)
 result=run_tests('hardlink-fixed',['ReceiptReaderLinkTests.test_existing_archive_hardlink_is_read_without_copy_or_retag',
  'ReceiptReaderIntegrationTests.test_actual_Fixture_receipt_uses_all_direct_reader_bindings'])
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['receipt_reader_implementation_component'].update(source_sha256=result['source_sha256']['tool/native_perf_build_producer.py'],
  test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],
  initial_qualification='Initial7=6newPASS plus1requiredactualFixture ERROR from introduced single-link-only reader constraint. Fixture sourcearchive is existing exclusive hard-link publication; original hash reader permits this. Earlier failed caller known reader FD not systematically serialized/explicitly closed before coordinator naturalexit; no reconstruction/fullclosure claim.',
  hardlink_before=dict(tests=1,failures=1,errors=0),hardlink_fixed=dict(tests=result['tests'],failures=result['failures'],errors=result['errors']),
  no_combined_full_final_suite_or_canonical=True,review_pending=True)
 native['current_helper_source_epoch'].update(producer_sha256=result['source_sha256']['tool/native_perf_build_producer.py'],
  test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'hardlink-fixed-hashes.json'))
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(tests=result['tests'],failures=result['failures'],errors=result['errors'],
 producer=result['source_sha256']['tool/native_perf_build_producer.py'],test=result['source_sha256']['tool/test_native_perf_build_producer.py'])))
