import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation-design')
 source_path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
 source=source_path.read_bytes();assert hashlib.sha256(source).hexdigest()=='ece58515ebd36e9a3305332c3fa1b13c9dd56ba4a74e8d9a5bc9b4eec0bc90cd'
 text=source.decode();tree=ast.parse(text)
 names={'_receipt_reader_context','_receipt_reader_guard','_receipt_reader_open','_receipt_reader_read','_receipt_reader_close','_receipt_reader_scan','_receipt_read_json'}
 selected='\n\n'.join(ast.get_source_segment(text,node) for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names)
 context='NEW current direct receipt reader component. Generic helpers outside direct receipt calls remain byteexact. Private independent purpose ledger initialized in real ctor, shared sticky receipt quarantine. _receipt_resource_context validates original output ledger/callback/directory before and after callback; _receipt_resource_error keeps exact PRIVATE first/secondary without exception hooks and sets global quarantine when uncertain=True. Raw IO seam native open/read/close. Existing source.tar deliberately hardlink-published with stable nlink2; readers must preserve this, writer singlelink rules unchanged. Helper unit owners SYNTHETIC; one actual finite Git/6SHIMS/Python/FIXTURE emitter positive passes. No SDK/native/canonical/closure/admission proof. Read/context/FD checks bounded not atomic/globalABA/auth. No automatic uncertainclose/replay/retry/progress inference. Review max2 concrete source-supported bugs/max250words. Advisory ROOT verifies.\n\n'+selected
 assert len(context)<21000
 def put(name,value):
  with (work/name).open('x') as output_file:json.dump(value,output_file,indent=2);output_file.write('\n')
 with (work/'review-context.txt').open('x') as output_file:output_file.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','2100','--max-input-chars','21000','--max-response-chars','9000','--timeout','180','--save-output',str(work/'review.txt'),'--prompt','Max2 concrete actionable bugs/max250words in supplied reader source. Preserve quarantine/no retry/no guessed consumed bytes/no uncertain FD close. No global closure claims.']
 put('review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(source).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (work/('review-'+label+'.bin')).open('xb') as output_file:output_file.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),
  stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
