import sys,pathlib,json,ast,hashlib,datetime,os,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation')
 D=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation-design')
 root=pathlib.Path('/tmp/connectanum-native-perf-receipt-reader-implementation-root-assessment');root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as output_file:json.dump(value,output_file,indent=2);output_file.write('\n')
 put(root/'attempt.json',dict(scope='NEW receipt direct-reader final source component qualification only',no_source_or_runtime_edit=True,
  no_unchanged_before_control_or_oldarchive_repeat=True,no_canonical_or_admission=True))
 original=json.loads((P/'original-hashes.json').read_text());final=json.loads((P/'uncertain-fixed-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in final.items())
 assert {rel for rel in final if final[rel]!=original[rel]}=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 old=(P/'original-source/tool/native_perf_build_producer.py').read_text();new=(R/'tool/native_perf_build_producer.py').read_text()
 def nodes(text):
  return {node.name:ast.get_source_segment(text,node) for node in ast.parse(text).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
 old_nodes=nodes(old);new_nodes=nodes(new)
 for name,text in old_nodes.items():
  if name not in ('CommandProducer','_receipt_source_audit','_emit'):assert new_nodes[name]==text,name
 def methods(text,name):
  node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name==name)
  return {n.name:ast.get_source_segment(text,n) for n in node.body if isinstance(n,ast.FunctionDef)}
 old_methods=methods(old,'CommandProducer');new_methods=methods(new,'CommandProducer');assert set(old_methods)==set(new_methods)
 assert all(old_methods[name]==new_methods[name] for name in old_methods if name!='__init__')
 constructor_line='        self._receipt_readers=[];self._receipt_reader_ledger=self._receipt_readers'
 assert new_methods['__init__'].replace(constructor_line+'\n','')==old_methods['__init__']
 assert old_nodes['_emit'].split('run.receipt_attempted=True')[0]==new_nodes['_emit'].split('run.receipt_attempted=True')[0]
 assert not any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('_regular_hash','_file_snapshot','_read_json','_read_bound_metadata')
  for name in ('_emit','_receipt_source_audit') for node in ast.walk(ast.parse(new_nodes[name])))
 old_test=(P/'original-source/tool/test_native_perf_build_producer.py').read_text();new_test=(R/'tool/test_native_perf_build_producer.py').read_text()
 old_test_nodes=nodes(old_test);new_test_nodes=nodes(new_test)
 assert all(new_test_nodes[name]==text for name,text in old_test_nodes.items())
 new_classes=set(new_test_nodes)-set(old_test_nodes)
 assert new_classes=={'ReceiptReaderTests','ReceiptReaderLinkTests','ReceiptReaderIntegrationTests','ReceiptReaderStrictTests','ReceiptReaderUncertainTests'}
 new_declared_tests=sum(1 for name in new_classes for method in methods(new_test,name) if method.startswith('test_'))
 assert new_declared_tests==13
 put(root/'structural-qualification.json',dict(
  constructor_only_two_reader_initializers=True,other_CommandProducer_methods_byteexact=True,
  AuxiliaryCommand_and_all_owner_classes_byteexact=True,all_other_original_module_functions_including_generic_helpers_byteexact=True,
  original_emitter_gates_byteexact=True,direct_generic_receipt_calls_replaced=True,
  all_original_test_nodes_byteexact=True,new_test_classes=sorted(new_classes),new_declared_test_methods=new_declared_tests,
  other18tools_and_selected3bins_byteexact=True,
  new_functions=sorted(set(new_nodes)-set(old_nodes))))
 # ROOT final code checks include the new unknown-read refusal and close exception gate.
 guard=new_nodes['_receipt_reader_guard']
 assert "(reader['read_uncertain'] is True and not closing)" in guard
 assert "info.st_nlink<1" in guard and "type(binding) is not tuple" in guard
 assert "_retain_receipt_error(run,stage,error,secondary=secondary)" in new_nodes['_receipt_reader_error']
 assert "'reader_read',error,read_uncertain=True" in new_nodes['_receipt_reader_read']
 assert "'reader_close',error,True,secondary=primary is not None" in new_nodes['_receipt_reader_close']
 stages={}
 for stage in ['implemented','hardlink-before','hardlink-fixed','strict-before','strict-fixed','uncertain-before','uncertain-fixed']:
  path=P/(stage+'-tests.json');raw=path.read_bytes();data=json.loads(raw)
  stages[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],
   report_path=path.relative_to(P).as_posix(),report_sha256=sha(raw))
 assert [(row['tests'],row['failures'],row['errors']) for row in stages.values()]==[(7,0,1),(1,1,0),(2,0,0),(3,3,0),(11,0,0),(1,1,0),(2,0,0)]
 fixture_index=[]
 for stage in stages:
  for pattern in ['control-*.json','strict-before-cleanup.json','resource-control-before-cleanup.json','new-known-actors.json','fixture-only-known-reader*.json']:
   for path in sorted((P/(stage+'-fixtures')).rglob(pattern)):
    raw=path.read_bytes();data=json.loads(raw)
    fixture_index.append(dict(stage=stage,path=path.relative_to(P).as_posix(),sha256=sha(raw),size=len(raw),kind=pattern))
 model=json.loads((D/'review-finish.json').read_text());assert model['direct_status']==0 and model['reaped']
 commands=[];known_children=[]
 def git(*args):
  row=dict(argv=['git','-C',str(R),*args],pid=None,status=None);commands.append(row)
  child=subprocess.Popen(row['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);known_children.append(child);row['pid']=child.pid
  stdout,stderr=child.communicate();row['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (root/('post-'+str(len(commands))+'-'+label+'.bin')).open('xb') as output_file:output_file.write(raw)
   row[label+'_eof']=True;row[label+'_size']=len(raw);row[label+'_sha256']=sha(raw)
  put(root/('post-'+str(len(commands))+'-return.json'),row);assert row['status']==0;lease.verify_identity();return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain');production_diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify')
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert len(status.splitlines())==20 and {row[3:] for row in status.splitlines()}=={rel for rel in final if rel.startswith('tool/')}
 assert production_diff==''
 assessment=dict(kind='receipt_direct_reader_ownership_source_component',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],
  bundle20_plus3bins=final,original_hashes=original,source_branch=branch,source_HEAD=head,posttest_Git=commands,
  behavior='Independent private reader ledger reserved before open; exact raw FD retained before metadata/callback/read. Original ledger/ordered-record/field/callback/directory bindings checked around callback. _emit/_receipt_source_audit direct JSON/hash/snapshot/metadata calls use explicit purpose roles; every purpose terminal, distinct pre-existing purposes may share path without failed-purpose retry. Generic helpers outside direct sites remain byteexact. Reader shares durable run receipt quarantine; one native close intent/unknownclose no reclose/newopen/report, original first/staged secondary no hooks. Owner first error retained BEFORE per-reader mutable dict updates. Unknown binding/field types checked before custom iteration/concatenation; native error stage labels. Unknown read refuses further read, permits one identity-checked close without position inference. Raw output/write policy unchanged.',
  read_semantics='JSON receipt wrapper deliberately adds regular owner/mode/canonical/path/beforeafter identity checks. Hash nonempty/ownership/mode/canonical limits retained; snapshots allow empty16GiB streaming, metadata exactsize-fullSHA/max32MiB, JSON2MiB/SHA/object/duplicate/nonfinite checks. Full file identity includes stable linkcount; pre-existing exclusive hardlink publication of source.tar is preserved, no copy/unlink/retag. Reader does NOT require singlelink; output writer rules unchanged. Hash/snapshot do not collect whole body. JSON/metadata collected bytes/last chunk/history process-life, NOT exact heap/RSS bound or causal RAM evidence.',
  prior_before='Consumed direct genericJSON preparation c1100806:3controls2FAIL1PASS at5847; no repeat. Current wrapper after controls cover nativeclose OSError/ambient, body first+actualclose BaseException, no hooks/unknownclose no subsequent IO.',
  results='Initial7=6newunitPASS+1existing required actualFixture ERROR from introduced singlelink-only reader guard. NEW hardlink1FAIL ->corrected2PASS (hardlink+NEW actualFixture integration). NEW strict3FAIL (custom binding iterator/error-stage radd/missingfirst field masks exact callback) ->selected11PASS at706d/6e27. NEW uncertainread1FAIL (second MOCKED read attempted after first readerror at unchanged position) ->final2PASS separately (no reread + one sameFD identityclose).13new declared methods exist; NOT combined13/full-final13/canonical. Last pair9c771/29a959 differs from selected11 epoch only unknownread gate/test additions; ROOT final hunk qualified, no modelfinalfullsource approval.',
  fixtures='Ten initial new unit-owner cases use explicit SYNTHETIC SimpleNamespace owner fields/original callbacks, actual finite owned files/raw FD/nativeclose then faults; unit callback/read seams mocked. Three subsequent cases include synthetic unknownread controls and actual Fixture integration. Actual one owned Fixture producer tinyGit/six shell version SHIMS/finitePython/syntheticoutputs/Fixture receipt is NOT actual SDK/compiler/version/bootstrap/native/canonical. New integration source APIs close all direct reader FDs with EOF before fixturecleanup and snapshot row assertions. Stable hardlinks read without copy/ownership retag. Root actual officialEX through known finite commands/children/FD controls; no worker/broker/benchmark/capture.',
  raw_limits='Initial existing required actualFixture failure leaves a known reader FD not systematically serialized or explicitly closed before coordinator natural exit; no reconstruction/fullclosure claim. Traceback/source and later selected poststat nlink2 FILEDATA retained; source _make_archive uses os.link. Individual original predicate returns not serialized, not reconstructed. Later new integration saves reader rows/nativeclose+EOF before cleanup and available LASTrecipe/Aux naturalwait+EOF-FDpathdigest reports via inherited fixture. Earlier overwritten command handles and legacy setup/APIreturns not all saved. Synthetic error identities persisted as booleans/types, exact objects private. Fixture-only knownFD close/field restoration never live cleanup/controller authority, no source flag retag. Negative IO hooks/reread controls MOCKED, no actual wrongFD read.',
  model=dict(review=model,source_epoch='ece58515ebd36e9a3305332c3fa1b13c9dd56ba4a74e8d9a5bc9b4eec0bc90cd',test_epoch='19e0c6ddfb6ed83862787d9601b88cb7c4fb52c60eecc97b10076a0733a1aa57',
   qualification='Qwen selected seven-method review complete0/reaped; ROOT rejects automatic close on unconfirmed identity and wrong None/False postopen reading (retainedFD/openTrue remains after later guardfail). Model retracts its offset/type/bound/None/suppressed-secondary alternatives; no actionable P2 established. No uid change/ABA protection claimed. ROOT independently adds strict-field and unknownread regressions after review, checks all final affected source/tests+AST/file invariants; not model full-current-source approval. No unchanged model/control reruns. Prior GLM design/Qwen tests advice already consumed c110 not repeated.'),
  stages=stages,retained_fixture_report_index=fixture_index,all20_uncommitted_uncanonical_unadmitted=True,
  production_tracked_diff_empty=True,native_outputs_instructionclosure_not_newly_proved=True,other18tools_and3bins_byteexact=True,
  privatecontrollers_outside_HELPERBUNDLE20=True,no_source_commit_push_adoption_or_strictdispatch=True,
  wholephysical_controller_incomplete=True,
  remaining='Transitive generic helper FDs/receipt audit partialactors/unknownstarts/historical recipe-Git-interpreter-delegate/write-end-descendant coverage and independent actualofficialEX orchestration remain incomplete. Freezeowner_emit_attempted/oldauxpredicates unchanged. No FDclose/status/EOF/join/emptyledger/sourcefile grantsEXrelease/admission. Need originalPATH SDK/bootstrap/first3locks-hiddenconfigs/current20validation-canonical/newsourceepoch package/OWNnative-driver-staticRLIB/compiler-tool-kernel+actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage, qualifiedROOTreview+immutableCOMPLETEadmission beforediagnosticdata. No transplant/borrowedcohort/favorableredo/SDKchange/oldhash-futurepostGOaspreproof.',
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  no_actual_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['receipt_reader_implementation_component'].update(assessment=str(root/'assessment.json'),root_assessment=str(root),ROOT_final_assessment_pending=False,
  ROOT_final_affected_source_test_checks=True,implementation_unimplemented=False,publication_pending=True,never_repeat_unchanged=True,
  full_current_source_model_approval=False,all_known_own_models_and_control_calls_terminal=True)
 native['last_free_bytes']=assessment['free_after'];value['active_turn_status']='receipt_direct_reader_source_ROOT_qualified_publication_pending'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],stages={key:[v['tests'],v['failures'],v['errors']] for key,v in stages.items()},free=assessment['free_after'])))
