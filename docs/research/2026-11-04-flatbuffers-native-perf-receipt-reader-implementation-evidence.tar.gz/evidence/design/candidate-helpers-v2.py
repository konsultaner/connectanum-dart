
def _receipt_reader_context(run,closing=False):
    ledger=run._receipt_readers
    if type(ledger) is not list or ledger is not run._receipt_reader_ledger:
        raise ProducerError('receipt reader ledger changed')
    retained=[]
    for reader in ledger:
        if type(reader) is not dict or any(type(key) is not str for key in reader):
            raise ProducerError('unknown receipt reader fields')
        retained.append((reader,tuple(reader.items())))
    _receipt_resource_context(run,closing=closing)
    if run._receipt_readers is not ledger or run._receipt_reader_ledger is not ledger or len(ledger)!=len(retained):
        raise ProducerError('receipt reader ledger changed during callback')
    for current,(reader,fields) in zip(ledger,retained):
        if (current is not reader or type(reader) is not dict or len(reader)!=len(fields)
            or any(type(key) is not str for key in reader)
            or any(key not in reader or reader[key] is not value for key,value in fields)):
            raise ProducerError('receipt reader fields changed during callback')

def _receipt_reader_guard(run,reader,closing=False):
    try:
        if (type(reader) is not dict or any(type(key) is not str for key in reader)
            or not any(item is reader for item in run._receipt_readers)
            or reader['quarantined'] or reader['close_attempted']):
            raise ProducerError('receipt reader unavailable')
        _receipt_reader_context(run,closing=closing)
        purpose,path,kind,maximum,owners=reader['binding']
        if (reader['purpose'] is not purpose or reader['path'] is not path or reader['kind'] is not kind
            or reader['maximum'] is not maximum or reader['owners'] is not owners
            or type(path) is not type(Path()) or type(reader['fd']) is not int or reader['fd']<0):
            raise ProducerError('receipt reader binding changed')
        fd=reader['fd']
        info=os.fstat(fd);current_path=path.lstat()
        identity=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,
            value.st_nlink,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
        current=identity(info)
        import fcntl
        if (not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022
            or info.st_nlink!=1 or not 0<=info.st_size<=maximum
            or current!=identity(current_path) or current!=reader['path_before']
            or os.get_inheritable(fd) is not False or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_RDONLY):
            raise ProducerError('receipt reader FD/path/owner/mode/size differs')
        if kind=='hash' and info.st_size==0:raise ProducerError('receipt hash input empty')
        if reader['identity'] is None:
            reader['identity']=current;reader['initial_size']=info.st_size
        if current!=reader['identity']:raise ProducerError('receipt reader metadata drift')
        if not (closing and reader['read_uncertain']):
            position=os.lseek(fd,0,os.SEEK_CUR)
            if type(position) is not int or position!=reader['offset']:
                raise ProducerError('receipt reader position changed')
        for other in run._receipt_readers:
            if other is reader or other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:raise ProducerError('active receipt readers alias')
        for other in run._receipt_resources:
            if other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:raise ProducerError('receipt reader aliases output')
    except BaseException:
        reader['quarantined']=True;run._receipt_resources_quarantined=True
        raise

def _receipt_reader_open(run,purpose,path,kind,maximum,owners):
    if (type(purpose) is not str or not purpose or type(path) is not type(Path())
        or type(kind) is not str or kind not in ('hash','snapshot','json','metadata')
        or type(maximum) is not int or maximum<0 or type(owners) is not frozenset
        or not owners or any(type(owner) is not int or owner<0 for owner in owners)
        or run._receipt_resources_quarantined or type(run._receipt_readers) is not list
        or run._receipt_readers is not run._receipt_reader_ledger):
        raise ProducerError('receipt reader opening refused')
    for prior in run._receipt_readers:
        if type(prior) is not dict or any(type(key) is not str for key in prior) or type(prior.get('purpose')) is not str:
            raise ProducerError('unknown prior receipt reader')
        if prior['purpose']==purpose:raise ProducerError('receipt reader purpose permanently terminal')
    reader=dict(role='reader:'+purpose,purpose=purpose,path=path,kind=kind,maximum=maximum,owners=owners,
        binding=(purpose,path,kind,maximum,owners),path_before=None,fd=None,raw_open_return=None,
        open_attempted=False,open_returned=None,identity=None,initial_size=None,offset=0,
        read_uncertain=False,last_read=None,eof=False,collected=None,
        close_attempted=False,close_returned=None,quarantined=False,first_error=None,error_stage=None)
    run._receipt_readers.append(reader)
    try:
        _receipt_reader_context(run)
        if not path.is_absolute() or (kind in ('hash','json') and path.resolve(strict=True)!=path):
            raise ProducerError('receipt reader path is not canonical')
        info=path.lstat()
        reader['path_before']=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,
            info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
        _receipt_reader_context(run)
        reader['open_attempted']=True
        returned=_receipt_resource_io(reader,'open',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        reader['raw_open_return']=returned
        if type(returned) is not int or returned<0:raise ProducerError('unknown receipt reader open return')
        reader['fd']=returned;reader['open_returned']=True
        _receipt_reader_guard(run,reader)
        return reader
    except BaseException as error:
        if reader['open_returned'] is None:reader['open_returned']=False
        _receipt_resource_error(run,reader,'reader_open:'+purpose,error,True)
        raise

def _receipt_reader_read(run,reader,maximum):
    try:
        _receipt_reader_guard(run,reader)
        value=_receipt_resource_io(reader,'read',maximum);reader['last_read']=value
        if type(value) is not bytes or len(value)>maximum:raise ProducerError('unknown receipt reader read return')
        reader['offset']+=len(value)
        if not value:reader['eof']=True
        return value
    except BaseException as error:
        reader['read_uncertain']=True
        _receipt_resource_error(run,reader,'reader_read:'+reader['purpose'],error)
        raise

def _receipt_reader_close(run,reader,primary):
    if reader['quarantined'] or reader['close_attempted']:return
    try:
        _receipt_reader_guard(run,reader,closing=True)
        reader['close_attempted']=True
        try:
            returned=_receipt_resource_io(reader,'close')
            if returned is not None:raise ProducerError('unknown receipt reader close return')
        except BaseException:
            reader['close_returned']=False
            raise
        else:reader['close_returned']=True
    except BaseException as error:
        _receipt_resource_error(run,reader,'reader_close:'+reader['purpose'],error,True,secondary=primary is not None)
        if primary is None:raise

def _receipt_reader_scan(run,purpose,path,kind,maximum,*,owners=None,expected_sha=None,expected_size=None):
    owners=frozenset({os.getuid()}) if owners is None else frozenset(owners)
    reader=_receipt_reader_open(run,purpose,Path(path),kind,maximum,owners);primary=None
    try:
        parts=[];digest=hashlib.sha256()
        if expected_size is not None and reader['initial_size']!=expected_size:
            raise ProducerError('receipt metadata size differs')
        while True:
            part=_receipt_reader_read(run,reader,min(65536 if kind=='metadata' else 1024**2,maximum+1-reader['offset']))
            if not part:break
            digest.update(part)
            if kind in ('json','metadata'):parts.append(part)
            if reader['offset']>maximum:raise ProducerError('receipt reader grew beyond bound')
        _receipt_reader_guard(run,reader)
        if reader['offset']!=reader['initial_size']:raise ProducerError('receipt reader byte count differs')
        if kind in ('json','metadata'):reader['collected']=b''.join(parts)
        actual_sha=_sha(reader['collected']) if kind=='json' else digest.hexdigest()
        if expected_sha is not None and actual_sha!=expected_sha:raise ProducerError('receipt consumed digest differs')
        return dict(size=reader['offset'],sha256=actual_sha,data=reader['collected'])
    except BaseException as error:
        primary=error;_receipt_resource_error(run,reader,'reader_body:'+purpose,error)
        raise
    finally:_receipt_reader_close(run,reader,primary)

def _receipt_regular_hash(run,purpose,path,maximum=1024**3,*,owners=None):
    return _receipt_reader_scan(run,purpose,path,'hash',maximum,owners=owners)['sha256']

def _receipt_file_snapshot(run,purpose,path,maximum=16*1024**3):
    result=_receipt_reader_scan(run,purpose,path,'snapshot',maximum)
    return dict(size=result['size'],sha256=result['sha256'])

def _receipt_read_bound_metadata(run,purpose,path,expected,maximum=32*1024**2):
    if (type(expected) is not dict or any(type(key) is not str for key in expected)
        or set(expected)!={'size','sha256'} or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid receipt metadata bound before IO')
    return _receipt_reader_scan(run,purpose,path,'metadata',maximum,
        expected_sha=expected['sha256'],expected_size=expected['size'])['data']

def _receipt_read_json(run,purpose,path,expected):
    data=_receipt_reader_scan(run,purpose,path,'json',2*1024**2,expected_sha=expected)['data']
    def pairs(values):
        out={}
        for key,value in values:
            if key in out:raise ProducerError('duplicate JSON key')
            out[key]=value
        return out
    def constant(value):raise ProducerError('nonfinite JSON constant')
    try:result=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
    except (ValueError,UnicodeError) as error:raise ProducerError('malformed sealed JSON') from error
    if type(result) is not dict:raise ProducerError('sealed JSON must be an object')
    return result
