
class ReceiptReaderTests(unittest.TestCase):
    """Direct-reader finite fixtures; no SDK/live/canonical/physical admission."""
    def setUp(self):
        from types import SimpleNamespace
        root=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        self.base=Path(tempfile.mkdtemp(prefix='receipt-reader-',dir=root)).resolve()
        self.actions={};self.owners=[];self.SimpleNamespace=SimpleNamespace

    def owner(self):
        callback=lambda:self.actions['callback']() if 'callback' in self.actions else None
        ledger=[]
        run=self.SimpleNamespace(directory=self.base,lease_check=callback,_receipt_resource_lease=callback,
            _receipt_resource_directory=self.base,_receipt_resources=[],_receipt_resources_quarantined=False,
            _receipt_readers=ledger,_receipt_reader_ledger=ledger,_receipt_primary_error_object=None,
            _receipt_primary_error_stage=None,_receipt_secondary_error_objects=[])
        self.owners.append(run);return run

    def input(self,name,body):
        path=self.base/name
        with path.open('xb') as out:out.write(body)
        return path

    def capture(self,run,invoke,extra=None):
        caught=None;result=None
        try:result=invoke()
        except BaseException as error:caught=error
        rows=[dict(purpose=row['purpose'],fd=row['fd'],open_returned=row['open_returned'],
            close_attempted=row['close_attempted'],close_returned=row['close_returned'],
            offset=row['offset'],eof=row['eof'],read_uncertain=row['read_uncertain'],quarantined=row['quarantined'],
            first_error_type=None if row['first_error'] is None else type.__dict__['__name__'].__get__(type(row['first_error']),type),
            ownership_complete=None,all_admission_flags=False) for row in run._receipt_readers]
        value=dict(rows=rows,error_type=None if caught is None else type.__dict__['__name__'].__get__(type(caught),type),
            run_quarantined=run._receipt_resources_quarantined,synthetic_owner_fixture=True,no_SDK_or_actor_admission=True)
        if extra:value.update(extra())
        with (self.base/('control-'+str(len(list(self.base.glob('control-*.json'))))+'.json')).open('x') as out:json.dump(value,out,indent=2)
        return caught,result

    def test_ambient_native_close_error_preserved_without_hooks_or_new_IO(self):
        run=self.owner();body=b'{"OWN":1}\n';path=self.input('ambient.json',body);hooks=[];closed=[]
        class HookError(RuntimeError):pass
        class ClosingError(OSError):
            def __repr__(self):hooks.append('repr');raise HookError()
            def __str__(self):hooks.append('str');raise HookError()
            def add_note(self,note):hooks.append('note');raise HookError()
        error=ClosingError(5,'OWN close');actual=producer._receipt_resource_io
        def operation(reader,step,value=None):
            result=actual(reader,step,value)
            if step=='close' and reader['role']=='reader:ambient':
                closed.append(reader['fd']);raise error
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            try:raise RuntimeError('OWN caller handled error')
            except RuntimeError:
                caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'ambient',path,digest(body)),
                    lambda:dict(hooks=list(hooks),actual_native_closes=list(closed)))
        self.assertTrue(caught is error);self.assertEqual([],hooks);self.assertEqual(1,len(closed))
        self.assertTrue(run._receipt_primary_error_object is error);self.assertTrue(run._receipt_resources_quarantined)
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            producer._receipt_reader_close(run,run._receipt_readers[0],error)
            with self.assertRaises(producer.ProducerError):producer._receipt_read_json(run,'next',path,digest(body))
        calls.assert_not_called()

    def test_body_first_survives_native_close_BaseException_with_zero_hooks(self):
        run=self.owner();body=b'{"OWN":2}\n';path=self.input('body.json',body);hooks=[];closed=[]
        class First(RuntimeError):
            def __repr__(self):hooks.append('first_repr');raise RuntimeError()
            def __str__(self):hooks.append('first_str');raise RuntimeError()
            def add_note(self,note):hooks.append('first_note');raise RuntimeError()
        class Closing(BaseException):
            def __repr__(self):hooks.append('close_repr');raise RuntimeError()
        first=First('OWN body');secondary=Closing();actual=producer._receipt_resource_io
        def operation(reader,step,value=None):
            result=actual(reader,step,value)
            if step=='close':closed.append(reader['fd']);raise secondary
            return result
        with mock.patch.object(producer,'_sha',side_effect=first),mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'body',path,digest(body)),
                lambda:dict(hooks=list(hooks),actual_native_closes=list(closed)))
        self.assertTrue(caught is first);self.assertEqual([],hooks);self.assertEqual(1,len(closed))
        self.assertTrue(run._receipt_primary_error_object is first)
        self.assertTrue(any(error is secondary for stage,error in run._receipt_secondary_error_objects))
        self.assertTrue(run._receipt_readers[0]['first_error'] is first)

    def test_exact_FD_retained_before_first_metadata_callback_fault(self):
        run=self.owner();body=b'{"OWN":3}\n';path=self.input('retain.json',body);seen=[];failure=OSError(5,'OWN callback')
        def callback():
            for reader in run._receipt_readers:
                if reader['open_returned'] is True and reader['identity'] is None:
                    seen.append(reader['fd']);raise failure
        self.actions['callback']=callback
        caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'retained',path,digest(body)),
            lambda:dict(retained_before_metadata_callback=list(seen)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(seen))
        self.assertIs(type(run._receipt_readers[0]['fd']),int)
        self.assertFalse(run._receipt_readers[0]['close_attempted'])

    def test_four_reader_kinds_preserve_bytes_hash_and_empty_snapshot(self):
        run=self.owner();body=b'{"OWN":4}\n';path=self.input('all.json',body);empty=self.input('empty.log',b'')
        results={}
        def operation():
            results['json']=producer._receipt_read_json(run,'json',path,digest(body))
            results['hash']=producer._receipt_regular_hash(run,'hash',path)
            results['metadata']=producer._receipt_read_bound_metadata(run,'metadata',path,{'size':len(body),'sha256':digest(body)})
            results['snapshot']=producer._receipt_file_snapshot(run,'snapshot',empty)
        try:raise RuntimeError('OWN handled')
        except RuntimeError:caught,result=self.capture(run,operation)
        self.assertIsNone(caught);self.assertIsNone(run._receipt_primary_error_object)
        self.assertEqual({'OWN':4},results['json']);self.assertEqual(digest(body),results['hash'])
        self.assertEqual(body,results['metadata']);self.assertEqual({'size':0,'sha256':digest(b'')},results['snapshot'])
        self.assertTrue(all(row['close_returned'] is True for row in run._receipt_readers))
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            with self.assertRaises(producer.ProducerError):producer._receipt_regular_hash(run,'hash',path)
        calls.assert_not_called()

    def test_callback_same_file_foreign_FD_refuses_before_read(self):
        run=self.owner();body=b'{"OWN":5}\n';path=self.input('drift.json',body)
        reader=producer._receipt_reader_open(run,'drift',path,'json',2*1024**2,frozenset({os.getuid()}))
        original=reader['fd'];foreign=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        def callback():
            self.actions.pop('callback',None);reader['fd']=foreign
        self.actions['callback']=callback
        try:
            with mock.patch.object(producer,'_receipt_resource_io') as calls:
                caught,result=self.capture(run,lambda:producer._receipt_reader_read(run,reader,100),
                    lambda:dict(native_read_attempts=calls.call_count,original_fd=original,foreign_fd=foreign))
            calls.assert_not_called();self.assertIs(type(caught),producer.ProducerError)
        finally:
            reader['fd']=original;os.close(foreign)

    def test_JSON_validation_remains_strict(self):
        for index,body in enumerate([b'{"a":1,"a":2}',b'{"a":NaN}',b'[]',b'{"a":1}']):
            run=self.owner();path=self.input('invalid-'+str(index)+'.json',body)
            expected='0'*64 if index==3 else digest(body)
            with self.subTest(index=index):
                caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'invalid',path,expected))
                self.assertIs(type(caught),producer.ProducerError)
                self.assertTrue(run._receipt_readers[0]['close_returned'])

    def tearDown(self):
        self.actions.clear();closed=[]
        for run in self.owners:
            for reader in run._receipt_readers:
                if type(reader['fd']) is not int or reader['close_attempted']:continue
                info=os.fstat(reader['fd']);path=reader['path'].stat()
                self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino))
                os.close(reader['fd']);closed.append(dict(purpose=reader['purpose'],fd=reader['fd'],
                    fixture_only_close=True,source_flags_not_retagged=True))
        with (self.base/'fixture-only-known-reader-FD-closes.json').open('x') as out:json.dump(closed,out,indent=2)
