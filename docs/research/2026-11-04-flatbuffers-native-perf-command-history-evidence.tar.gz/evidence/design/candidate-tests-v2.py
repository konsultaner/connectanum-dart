
class CommandHistoryTests(ReceiptResourceTests):
    def setUp(self):
        self.external_known=[];self.history_notes=[]
        super().setUp()

    def test_all_actual_direct_commands_remain_retained_after_overwrite(self):
        run=self.start('ok','ok');first=run.process;first_log=run.log;self.external_known.append((first,first.wait))
        self.finish(run)
        history=run.__dict__.get('_command_attempts',[])
        notes=dict(command_count=len(run.commands),history_count=len(history),first_pid=first.pid,last_pid=run.process.pid,
            first_process_is_last=first is run.process,private_history_present='_command_attempts' in run.__dict__,
            rows=[dict(index=row['index'],pid=None if row['process'] is None else row['process'].pid,
                wait_observed=row['wait_observed'],wait_status=row['wait_status'],
                parent_writer_close_attempted=row['parent_writer_close_attempted'],
                parent_writer_close_returned=row['parent_writer_close_returned'],
                log_closed=None if row['log'] is None else row['log'].closed,
                ownership_complete=None,all_admission_flags=False) for row in history])
        self.history_notes.append(notes)
        self.assertEqual(len(run.commands),len(history))
        self.assertTrue(history[0]['process'] is first);self.assertTrue(history[0]['log'] is first_log)
        self.assertTrue(all(row['wait_observed'] is True and row['wait_status']==0 for row in history))
        self.assertTrue(all(row['process'] is not None for row in history))

    def test_attempt_precedes_first_event_failure_without_launch(self):
        actual=producer.CommandProducer._event;captured=[];failure=OSError(5,'OWN command_start')
        def event(current,kind,**fields):
            if kind=='command_start':
                if current not in self.runs:self.runs.append(current)
                history=current.__dict__.get('_command_attempts',[])
                captured.append(dict(history_count=len(history),
                    process_none=None if not history else history[-1]['process'] is None,
                    log_none=None if not history else history[-1]['log'] is None,
                    popen_attempted=None if not history else history[-1]['popen_attempted']))
                raise failure
            return actual(current,kind,**fields)
        with mock.patch.object(producer.CommandProducer,'_event',event):
            with self.assertRaises(OSError):self.start('ok')
        self.history_notes.append(dict(before_event=captured))
        self.assertEqual(1,len(captured));self.assertEqual(1,captured[0]['history_count'])
        self.assertTrue(captured[0]['process_none']);self.assertTrue(captured[0]['log_none'])
        self.assertFalse(captured[0]['popen_attempted'])

    def test_actual_wait_witness_survives_end_command_fault(self):
        run=self.start('ok');process=run.process;self.external_known.append((process,process.wait))
        actual=run._end_command;failure=OSError(5,'OWN postwait cache')
        with mock.patch.object(run,'_end_command',side_effect=failure):
            result=run.wait(2)
        history=run.__dict__.get('_command_attempts',[])
        row=None if not history else history[-1]
        self.history_notes.append(dict(after_wait_fault=dict(history_present=bool(history),
            process_same=None if row is None else row['process'] is process,
            wait_observed=None if row is None else row['wait_observed'],
            wait_status=None if row is None else row['wait_status'],
            raw_pending=run.pending,raw_finished=run.finished,result=result)))
        self.assertTrue(history);self.assertTrue(row['process'] is process)
        self.assertTrue(row['wait_observed']);self.assertIs(type(row['wait_status']),int)
        self.assertEqual(0,row['wait_status'])

    def capsule(self,code='pass'):
        from types import SimpleNamespace
        attempt=dict(index=0,record={'returncode':None},process=None,wait_process=None,wait_status=None,
            wait_observed=False,raw_wait_return=None,wait_uncertain=False,wait_timeouts=0,
            first_error=None,error_stage=None)
        owner=SimpleNamespace(process=None,records=[attempt['record']],_command_attempt=attempt,
            _command_attempts=[attempt],_command_history_primary_error=None,_command_history_primary_stage=None,
            _command_history_secondary_errors=[])
        owner._command_history_error=lambda row,stage,error,secondary=False:producer.CommandProducer._command_history_error(owner,row,stage,error,secondary)
        child=subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.external_known.append((child,child.wait))
        owner.process=child;attempt['process']=child
        return owner,attempt,child

    def test_poll_then_same_status_actual_method_wait_is_distinct(self):
        owner,row,child=self.capsule()
        deadline=time.monotonic()+2
        status=producer.CommandProducer._observe_direct_status(owner)
        while status is None and time.monotonic()<deadline:
            time.sleep(.005);status=producer.CommandProducer._observe_direct_status(owner)
        self.assertEqual(0,status);self.assertFalse(row['wait_observed']);self.assertIsNone(row['wait_status'])
        actual=producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(poll_then_wait=dict(pid=child.pid,poll_status=status,method_return=actual,
            observed=row['wait_observed'],marker_status=row['wait_status'],synthetic_capsule=True)))
        self.assertIs(type(actual),int);self.assertEqual(0,actual);self.assertTrue(row['wait_observed'])
        self.assertTrue(row['wait_process'] is child)

    def test_real_timeout_retains_same_child_until_natural_wait(self):
        owner,row,child=self.capsule('import time;time.sleep(.08)')
        with self.assertRaises(subprocess.TimeoutExpired):producer.CommandProducer._wait_command_natural(owner,0)
        self.assertFalse(row['wait_observed']);self.assertIsNone(row['wait_status']);self.assertTrue(row['wait_process'] is child)
        actual=producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(timeout_then_natural=dict(pid=child.pid,method_return=actual,
            timeouts=row['wait_timeouts'],same_process=row['wait_process'] is child,synthetic_capsule=True)))
        self.assertEqual(0,actual);self.assertTrue(row['wait_observed'])

    def test_malformed_bool_return_never_becomes_observed_zero(self):
        owner,row,child=self.capsule()
        with mock.patch.object(child,'wait',return_value=False):
            with self.assertRaises(producer.ProducerError):producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(bool_wait=dict(pid=child.pid,raw_type=type(row['raw_wait_return']).__name__,
            observed=row['wait_observed'],status=row['wait_status'],synthetic_capsule=True)))
        self.assertIs(row['raw_wait_return'],False);self.assertFalse(row['wait_observed'])
        self.assertIsNone(row['wait_status']);self.assertTrue(row['wait_uncertain'])

    def test_foreign_process_refuses_without_waiting_on_it(self):
        owner,row,child=self.capsule()
        foreign=subprocess.Popen([sys.executable,'-c','pass'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.external_known.append((foreign,foreign.wait));owner.process=foreign
        with mock.patch.object(foreign,'wait') as calls:
            with self.assertRaises(producer.ProducerError):producer.CommandProducer._wait_command_natural(owner,2)
        calls.assert_not_called();self.assertTrue(row['process'] is child);self.assertFalse(row['wait_observed'])


    def test_parent_writer_close_fault_retains_same_pending_Popen(self):
        import fcntl,stat
        actual_event=producer.CommandProducer._event;actual_close=os.close;captured=[];closed=[]
        failure=OSError(5,'OWN after actual parent writer close')
        def event(current,kind,**fields):
            if kind=='command_start':captured.append(current)
            return actual_event(current,kind,**fields)
        def close(fd):
            current=None if not captured else captured[-1]
            if current is not None and current.process is not None and current.pending and not closed:
                info=os.fstat(fd)
                if stat.S_ISFIFO(info.st_mode) and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY:
                    returned=actual_close(fd);closed.append(dict(fd=fd,native_returned_none=returned is None))
                    raise failure
            return actual_close(fd)
        with mock.patch.object(producer.CommandProducer,'_event',event),mock.patch.object(producer.os,'close',close):
            run=self.start('ok')
        process=run.process;self.external_known.append((process,process.wait))
        history=run.__dict__.get('_command_attempts',[])
        self.history_notes.append(dict(parent_close_fault=dict(history_count=len(history),actual_native_closes=closed,
            raw_pending=run.pending,raw_finished=run.finished,
            retained_process_same=None if not history else history[-1]['process'] is process,
            original_first_error_same=None if not history else history[-1]['first_error'] is failure)))
        self.assertTrue(run.pending);self.assertFalse(run.finished);self.assertEqual(1,len(closed))
        self.assertEqual(1,len(history));self.assertTrue(history[0]['process'] is process)
        self.assertTrue(history[0]['first_error'] is failure)
        self.assertTrue(history[0]['parent_writer_close_attempted'])
        self.assertFalse(history[0]['parent_writer_close_returned'])

    def tearDown(self):
        # Finite-unit teardown only; SAME known actors, no live controller recovery.
        for child,wait in self.external_known:
            status=wait(2)
            self.history_notes.append(dict(fixture_only_actual_Popen_wait=dict(pid=child.pid,status=status,
                source_marker_not_reconstructed=True,not_fresh_waitsyscall_proof=True)))
        with (self.base/'command-history-observations.json').open('x') as out:json.dump(self.history_notes,out,indent=2)
        super().tearDown()
