def _receipt_reader_io(reader,step,value=None):
    # Separate native seam: output-ledger resources never adopt reader records.
    if step=='open':return os.open(reader['path'],value,0o666)
    if step=='read':return os.read(reader['fd'],value)
    if step=='close':return os.close(reader['fd'])
    raise ProducerError('unknown receipt reader IO step')
