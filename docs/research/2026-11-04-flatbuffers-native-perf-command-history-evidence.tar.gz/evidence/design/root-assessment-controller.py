import sys,pathlib,json,ast,hashlib,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-command-history');D=pathlib.Path('/tmp/connectanum-native-perf-command-history-design')
 root=pathlib.Path('/tmp/connectanum-native-perf-command-history-root-assessment');root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 put(root/'attempt.json',dict(scope='NEW command history and reader IO-seam source qualification; no runtime/source edit',no_unchanged_controls_models_or_oldarchives_repeat=True,no_canonical_or_admission=True))
 original=json.loads((P/'original-hashes.json').read_text());final=json.loads((P/'review-fixed-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in final.items())
 assert {rel for rel in final if final[rel]!=original[rel]}=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 old=(P/'original-source/tool/native_perf_build_producer.py').read_text();new=(R/'tool/native_perf_build_producer.py').read_text()
 def nodes(text):
  return {node.name:ast.get_source_segment(text,node) for node in ast.parse(text).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
 def methods(text,name):
  cls=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name==name)
  return {n.name:ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef)}
 old_nodes=nodes(old);new_nodes=nodes(new);reader_names={'_receipt_reader_open','_receipt_reader_read','_receipt_reader_close'}
 for name,body in old_nodes.items():
  if name=='CommandProducer':continue
  if name in reader_names:assert new_nodes[name].replace('_receipt_reader_io(','_receipt_resource_io(')==body,name
  else:assert new_nodes[name]==body,name
 om=methods(old,'CommandProducer');nm=methods(new,'CommandProducer')
 assert set(nm)-set(om)=={'_command_history_error','_wait_command_natural'}
 assert all(nm[name]==om[name] for name in om if name not in ('__init__','_spawn','wait'))
 ctor_addition="\n        self._command_attempts=[];self._command_attempt=None\n        self._command_history_primary_error=None;self._command_history_primary_stage=None\n        self._command_history_secondary_errors=[]"
 assert nm['__init__'].replace(ctor_addition,'')==om['__init__']
 class Normalize(ast.NodeTransformer):
  def visit_Expr(self,node):
   if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='_command_history_error':return None
   return self.generic_visit(node)
  def visit_Call(self,node):
   node=self.generic_visit(node)
   if isinstance(node.func,ast.Attribute) and node.func.attr=='_wait_command_natural':
    return ast.Call(func=ast.Attribute(value=ast.Attribute(value=ast.Name(id='self',ctx=ast.Load()),attr='process',ctx=ast.Load()),attr='wait',ctx=ast.Load()),
     args=[],keywords=[ast.keyword(arg='timeout',value=node.args[0])])
   return node
 oldwait=ast.parse(om['wait']);newwait=Normalize().visit(ast.parse(nm['wait']))
 assert ast.dump(oldwait,include_attributes=False)==ast.dump(newwait,include_attributes=False)
 def selected_calls(text,name):
  return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr==name]
 assert selected_calls(om['_spawn'],'Popen')==selected_calls(nm['_spawn'],'Popen')
 assert selected_calls(om['_spawn'],'pipe')==selected_calls(nm['_spawn'],'pipe')
 assert len(selected_calls(om['_spawn'],'close'))==len(selected_calls(nm['_spawn'],'close'))==2
 assert 'attempt[\'process\']=self.process;attempt[\'popen_returned\']=True' in nm['_spawn']
 assert nm['_spawn'].index("attempt['process']=self.process")<nm['_spawn'].index("record['pid']=self.process.pid")
 assert nm['_spawn'].index('self._command_attempt=attempt')<nm['_spawn'].index("self._event('command_start'")
 assert nm['_wait_command_natural'].count('process.wait(timeout=timeout)')==1
 oldtest=(P/'original-source/tool/test_native_perf_build_producer.py').read_text();newtest=(R/'tool/test_native_perf_build_producer.py').read_text()
 ot=nodes(oldtest);nt=nodes(newtest)
 reader_classes={'ReceiptReaderTests','ReceiptReaderLinkTests','ReceiptReaderIntegrationTests','ReceiptReaderStrictTests','ReceiptReaderUncertainTests'}
 for name,body in ot.items():
  if name in reader_classes:assert nt[name].replace('_receipt_reader_io','_receipt_resource_io')==body,name
  else:assert nt[name]==body,name
 assert set(nt)-set(ot)=={'CommandHistoryTests','CommandHistoryReviewTests'}
 put(root/'structural-qualification.json',dict(
  constructor_only_history_initializers=True,other_original_CommandProducer_methods_except_spawn_wait_byteexact=True,
  wait_original_AST_after_removing_private_history_calls_and_method_wrapper=True,
  Popen_argv_env_stdio_and_pipe_calls_AST_byteexact=True,close_call_sites_unchanged=True,
  exact_process_retained_before_pid_close_journal=True,attempt_reserved_before_first_event=True,
  original_generic_helpers_output_IO_other_functions_Auxiliary_ownerclasses_byteexact=True,
  reader_3functions_only_IOseam_rename=True,reader_5testclasses_only_mock_seam_rename=True,
  other_original_test_nodes_byteexact=True,other18tools_and3bins_byteexact=True))
 stages={};fixture_index=[]
 for stage in ['before','implemented','review-controls','review-fixed']:
  path=P/(stage+'-tests.json');raw=path.read_bytes();data=json.loads(raw)
  stages[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],
   report=path.relative_to(P).as_posix(),sha256=sha(raw))
  for pattern in ['command-history-observations.json','resource-control-before-cleanup.json','control-*.json','new-known-actors.json']:
   for item in sorted((P/(stage+'-fixtures')).rglob(pattern)):
    raw=item.read_bytes();fixture_index.append(dict(stage=stage,path=item.relative_to(P).as_posix(),sha256=sha(raw),size=len(raw)))
 assert [(row['tests'],row['failures'],row['errors']) for row in stages.values()]==[(16,7,5),(22,0,0),(2,0,1),(1,0,0)]
 models={name:json.loads((D/(name+'-finish.json')).read_text()) for name in ['summary','judge','tests','debug','review']}
 assert all(value['direct_status']==0 and value['reaped'] for value in models.values())
 commands=[];known=[]
 def git(*args):
  row=dict(argv=['git','-C',str(R),*args],pid=None,status=None);commands.append(row)
  child=subprocess.Popen(row['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);known.append(child);row['pid']=child.pid
  stdout,stderr=child.communicate();row['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (root/('post-'+str(len(commands))+'-'+label+'.bin')).open('xb') as out:out.write(raw)
   row[label+'_eof']=True;row[label+'_size']=len(raw);row[label+'_sha256']=sha(raw)
  put(root/('post-'+str(len(commands))+'-return.json'),row);assert row['status']==0;lease.verify_identity();return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain');diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify')
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert len(status.splitlines())==20 and {row[3:] for row in status.splitlines()}=={rel for rel in final if rel.startswith('tool/')}
 assert diff==''
 assessment=dict(kind='direct_command_history_and_wait_method_witness_source_component',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],bundle20_plus3bins=final,
  behavior='Empty private history/current/global first-secondary initialized before ctor lease callback. Each direct command attempt retained before first command_start event/log/pipe/Popen IO; exact log/readerFD/parentwriterFD/Popen refs immediately after returns before later metadata. Historical process/log refs never discarded after self.process/log overwrite. Actual SAMEPopen.wait METHOD exact-int status retained before _end_command/public cache/flush/fsync/close. Poll notmarker; same cached poll status accepted; timeout keeps same actor/no invented0; bool/malformed/drift refuses. Private first/secondary retained before original spawn repr/add_note and wait failure publication; original public cleanup policy unchanged. No raw concurrent observer, arming, admission or physical release API.',
  reader_seam_repair='Accidental inherited old output callback control exposed private seam collision: direct readers used output _receipt_resource_io while belonging independent reader ledger. New _receipt_reader_io performs same native open/read/close calls;3readerfunctions and5reader testclasses only seam rename. Old output IO membership assertion and reader ownership remain; no ledger relaxation/native syscall/order/path/gate change.22selected includes13 explicitly migrated reader controls+1formerly failing output caller, not repeats of inherited7passing controls.',
  before_qualification='Test class selection accidentally included8inherited existing resource controls+8NEWcommandhistory methods=16.7failure occurrences+5error occurrences, not12production defects. Four NEWbody history absence failures;3missingwait API errors;1missinglocaltime import error;2pending teardown assertion failures+1Noneprocess teardown error;1inherited outputIO ownership assertion failure. Seven inherited controls passed and are NOT rerun unchanged. Known actors/FD journals from aborted initial teardown not complete; no reconstruction/fullclosure claim.',
  verification='After implementation/harness+seam correction:22PASS=8newcommandhistory+13migratedreader+1failingoutputcaller at78ae/7e270. Review controls2=1PASS exactbool/nonbounded rejection,1ERROR test event(kind) parameter collides with command_end record kind before proposed P0 observation. Corrected event_name/early finite-unit run retention=>onlyblockedcontrol1PASS separately atsameproducer78ae/finaltest8b723. No combined24/full-final24/canonical count.10new history/review declared methods; before inherited8 not new cases.',
  actual_scope='Actual finite OWN directPython recipes (self.start ok,ok=2commands, no6probes bydefault); actual Fixture receipt caller adds6shell version SHIMS+finitePython/tinyGit/syntheticoutputs. Units for poll/timeout/bool/drift use explicit SYNTHETIC capsule with REAL finite Popen. Parentwriter fault performs actual native close then ordinary injectedOSError, rawpendingTrue retained before SAMEactor publicwait teardown. Before-firstevent fault requests no direct child but ctorAux exists. Declared Popen fault raises BEFORE actualnativePopen, not liveunknownstartabsence proof. Root actualofficialEX through known finite controls; no SDK/compiler/version/bootstrap/native/canonical/benchmark/capture evidence.',
  raw_limits='New history notes retain available exactprocess/log/pipe refs, signed actual SAMEPopen method statuses, rawmalformedFalse separate from real unitteardown0, timeout/poll distinction and parentwriter close observations. Earlier before histories missing/overwritten pointers never backfilled; initial pending/None teardown failures abort complete known actor/FD report. First review callback-kind collision blocks intended P0 observation; failedctor/Aux/writer results not all serialized. Later fixed control is NEW, not gap repair. Fixture-only knownactor waits/public sameactor failure finish/known writerclose never live workaround, no sourceflag retag/FDnumberclose authority. Parentcreator copies and normalreturn flags not childwriter/delegate/descendant or instruction/role/credential proof. Raw/APIreturns not all systematic; refs/history not heapRSSbound.',
  models=models,ROOT_model_qualification='Gemma21242 rootcorrects firstcommand assumptions (configured commands, direct2 vs receipt6SHIMS), Aux objects retained before start not mere result metadata, parentwriter is creator copy not parentworkloadwriter. GLM21570 rootcorrects _end_command sets pendingFalse/returncode/ended_ns BEFORElogflush; accepts poll-then-equal actualwait and process retention through pending deferral. Qwen21813 reject fakePopen positives, syscallcount claims, mocked-only timeout/guessed names/errors/commands. Debug23170 rootrejects nonexistent eventbus/wrong commandhistory-ledger explanation/softeningteardown; correct physical SAMEactor cleanup+explicitselector/import/Nonehandling, isolate reader seam. Review23971 P0 tryexcept fallsintoelse FALSE; P1 type(True)isint FALSE. Two NEWcontrols substantiate exactsource semantics (first blocked by testparam collision, fixed onlyfailedcase). Residual uncertain FD handling/concurrency/hashcost remain original/unproved, not automatic-close authority or measured RAM cause. Selectedreview78ae BEFORElasttests, producerbyteexact; ROOTwholeaffectedfinalsource/test+AST invariants, not model fullcurrent-source approval.',
  stages=stages,retained_fixture_report_index=fixture_index,posttest_Git=commands,branch=branch,HEAD=head,
  all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,native_output_instructionclosure_not_newly_proved=True,
  other18tools_and3bins_byteexact=True,privatecontrollers_outside_HELPERBUNDLE20=True,no_source_commit_push_adoption_or_strictdispatch=True,
  remaining='Independent frozen historical actor inventory/continuation, transitive genericFD/auditpartialactors/unknownstarts/sharedjournal-historicalwriter/delegate-descendant coverage/fullactualofficialEX controller incomplete. Existing freeze owner_emit_attempted and oldauxpredicates unchanged; history fields/normalreturns/status/EOF/join/emptyledger/sourcefiles not release/admission. Need originalPATH SDK/bootstrap/first3locks-hiddenconfigs/current20validation-canonical/newsourceepochpackage/OWNnative-driver-staticRLIB/compiler-tool-kernel+actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage, qualifiedROOTreview+immutableCOMPLETEadmission before diagnosticdata. No transplant/borrowedcohort/favorable redo/SDKchange/postGO aspreproof.',
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  no_actual_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['command_history_component'].update(assessment=str(root/'assessment.json'),root_assessment=str(root),ROOT_final_assessment_pending=False,
  ROOT_final_affected_source_tests_checked=True,review_pending=False,publication_pending=True,never_repeat_unchanged=True,
  wholephysical_controller_incomplete=True,all_known_own_model_test_calls_terminal=True)
 native['last_free_bytes']=assessment['free_after'];value['active_turn_status']='command_history_ROOT_qualified_publication_pending'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],stages={k:[v['tests'],v['failures'],v['errors']] for k,v in stages.items()},free=assessment['free_after'])))
