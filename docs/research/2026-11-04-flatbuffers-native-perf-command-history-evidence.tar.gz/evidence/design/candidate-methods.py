class Candidate:

    def _command_history_error(self,attempt,stage,error,secondary=False):
        if self._command_history_primary_error is None:
            self._command_history_primary_error=error;self._command_history_primary_stage=stage
        elif secondary or error is not self._command_history_primary_error:
            self._command_history_secondary_errors.append((stage,error))
        if type(attempt) is dict and all(type(key) is str for key in attempt):
            if attempt.get('first_error') is None:attempt['first_error']=error
            attempt['error_stage']=stage

    def _wait_command_natural(self,timeout):
        if type(timeout) not in (int,float) or not 0<=timeout<=60:
            raise ProducerError('bounded command wait required')
        attempt=self._command_attempt
        if (type(attempt) is not dict or any(type(key) is not str for key in attempt)
            or type(self._command_attempts) is not list
            or not any(item is attempt for item in self._command_attempts)):
            raise ProducerError('exact retained command attempt required')
        process=self.process
        try:
            if (type(process) is not _COMMAND_POPEN_TYPE or attempt['process'] is not process
                or attempt['wait_uncertain'] is not False
                or (attempt['wait_process'] is not None and attempt['wait_process'] is not process)
                or type(attempt['index']) is not int or attempt['index']!=len(self.records)-1
                or attempt['record'] is not self.records[-1]):
                raise ProducerError('command wait identity or progress changed')
            if type(attempt['wait_observed']) is not bool:
                raise ProducerError('unknown command wait witness')
            previous=attempt['wait_status']
            if attempt['wait_observed'] and type(previous) is not int:
                raise ProducerError('unknown previous command wait status')
            cached=self.records[-1]['returncode']
            if cached is not None and type(cached) is not int:
                raise ProducerError('unknown cached command status')
            attempt['wait_process']=process
            try:status=process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                attempt['wait_timeouts']+=1
                raise
            attempt['raw_wait_return']=status
            if (type(status) is not int or (attempt['wait_observed'] and previous!=status)
                or (cached is not None and cached!=status)):
                raise ProducerError('command wait returned malformed or changed status')
            # This exact METHOD return precedes _end_command and all its metadata IO.
            attempt['wait_status']=status;attempt['wait_observed']=True
            return status
        except subprocess.TimeoutExpired:raise
        except BaseException as error:
            attempt['wait_uncertain']=True
            self._command_history_error(attempt,'command_wait',error)
            raise

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index]);kind,tool=self.task_kinds[index]
        attempt=dict(index=index,argv=tuple(argv),kind=kind,tool=tool,record=None,log=None,
            reader_fd=None,writer_fd=None,pipe_attempted=False,pipe_returned=None,
            popen_attempted=False,popen_returned=None,process=None,
            parent_writer_close_attempted=False,parent_writer_close_returned=None,
            cleanup_close_attempts=[],stage='reserved',first_error=None,error_stage=None,
            wait_process=None,wait_status=None,wait_observed=False,raw_wait_return=None,
            wait_uncertain=False,wait_timeouts=0)
        self._command_attempt=attempt
        self._command_attempts.append(attempt)
        try:
            attempt['stage']='command_start_event'
            self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
            attempt['stage']='log_open'
            self.log=(self.directory/f'command-{index:03}.log').open('xb',buffering=0)
            attempt['log']=self.log
            self.output_log=self.log;self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False
            self.output_hash=hashlib.sha256();self.output_bytes=0
            record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),
                    'returncode':None,'spawn_error':None,'output_eof':False,'log_complete':False,
                    'whole_descendant_exit_proven':False,'parent_output_write_close_confirmed':False}
            attempt['record']=record
            self.records.append(record)
            writer=None
            try:
                attempt['stage']='pipe';attempt['pipe_attempted']=True
                self.output_fd,writer=os.pipe()
                attempt['reader_fd']=self.output_fd;attempt['writer_fd']=writer;attempt['pipe_returned']=True
                attempt['stage']='pipe_flags'
                os.set_inheritable(self.output_fd,False);os.set_inheritable(writer,False)
                os.set_blocking(self.output_fd,False)
                attempt['stage']='Popen';attempt['popen_attempted']=True
                self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=writer,
                    stderr=subprocess.STDOUT,close_fds=True,env=self.environment)
                attempt['process']=self.process;attempt['popen_returned']=True
            except OSError as error:
                self._command_history_error(attempt,attempt['stage'],error)
                if attempt['popen_attempted'] and attempt['popen_returned'] is None:attempt['popen_returned']=False
                record['spawn_error']=repr(error)
                for fd in (writer,self.output_fd):
                    if fd is not None:
                        close=dict(fd=fd,attempted=True,returned=None)
                        attempt['cleanup_close_attempts'].append(close)
                        try:os.close(fd)
                        except OSError as secondary:
                            close['returned']=False
                            self._command_history_error(attempt,'unspawned_close',secondary,secondary=True)
                            error.add_note('unspawned output close failed: '+repr(secondary))
                        else:close['returned']=True
                self.output_fd=None;record['output_eof']=None
                self._end_command(None)
                self._finish('failed','command spawn failed: '+repr(error))
            else:
                # Exact returned Popen is retained above, before pid/close/journal IO.
                record['pid']=self.process.pid;self.pending=True
                try:
                    fd=writer;writer=None
                    attempt['stage']='parent_writer_close';attempt['parent_writer_close_attempted']=True
                    os.close(fd)
                except OSError as error:
                    attempt['parent_writer_close_returned']=False
                    self._command_history_error(attempt,'parent_writer_close',error)
                    record['parent_output_write_close_error']=repr(error)
                    self._defer_failure(error)
                else:
                    attempt['parent_writer_close_returned']=True
                    record['parent_output_write_close_confirmed']=True
                attempt['stage']='command_spawned_event'
                self._event('command_spawned',index=index,pid=self.process.pid)
                attempt['stage']='spawned'
        except BaseException as error:
            self._command_history_error(attempt,attempt['stage'],error)
            raise
