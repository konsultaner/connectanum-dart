import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 exec(compile("import ast,sys,pathlib,json,hashlib,os,io,types,unittest,datetime\nR=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')\nP=pathlib.Path('/tmp/connectanum-native-perf-command-history')\nsha=lambda b:hashlib.sha256(b).hexdigest()\ndef put(path,data):\n with path.open('x') as f:json.dump(data,f,indent=2);f.write('\\n')\ndef snapshot(stage):\n target=P/(stage+'-source');target.mkdir();h={}\n for rel in expected:\n  b=(R/rel).read_bytes();path=target/rel;path.parent.mkdir(exist_ok=True);path.write_bytes(b);h[rel]=sha(b)\n put(P/(stage+'-hashes.json'),h);return h\ndef run_tests(stage,names):\n h=snapshot(stage);fixtures=P/(stage+'-fixtures');fixtures.mkdir()\n os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True\n modules=[]\n for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('receipt_resources_selected_tests','tool/test_native_perf_build_producer.py')]:\n  mod=types.ModuleType(name);mod.__file__=str(R/rel);assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)\n  raw=(P/(stage+'-source')/rel).read_bytes();assert sha(raw)==h[rel];exec(compile(raw,str(R/rel),'exec'),mod.__dict__)\n suite=unittest.TestSuite()\n for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))\n output=io.StringIO();result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)\n with (P/(stage+'-tests.log')).open('x') as f:f.write(output.getvalue())\n value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),\n  successful=result.wasSuccessful(),scope='NEW finite OWN unit fixtures only, not canonical/admission/runtime',source_sha256=h,\n  failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],\n  errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])\n put(P/(stage+'-tests.json'),value)\n for name in reversed(modules):sys.modules.pop(name)\n return value\n",'command-history-review-fixed-core.py','exec'))
 expected=json.loads((P/'review-controls-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in expected.items())
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=1024**3
 path=R/'tool/test_native_perf_build_producer.py';body=path.read_text();tree=ast.parse(body);lines=body.splitlines(keepends=True)
 cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandHistoryReviewTests')
 node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='test_declared_Popen_OSError_finishes_failed_without_success_else')
 value=ast.get_source_segment(body,node)
 value=value.replace("patchers=[];requests=[]","patchers=[];requests=[];captured=[]")
 value=value.replace('def event(current,kind,**fields):','def event(current,event_name,**fields):\n            if event_name==\'command_start\':captured.append(current)')
 value=value.replace('actual_event(current,kind,**fields)','actual_event(current,event_name,**fields)')
 value=value.replace("if kind=='command_start' and not patchers:","if event_name=='command_start' and not patchers:")
 value=value.replace('for patcher in reversed(patchers):patcher.stop()','for patcher in reversed(patchers):patcher.stop()\n            for current in captured:\n                if not any(item is current for item in self.runs):self.runs.append(current)')
 lines[node.lineno-1:node.end_lineno]=['    '+value+'\n'];body=''.join(lines);ast.parse(body);path.write_text(body)
 result=run_tests('review-fixed',['CommandHistoryReviewTests.test_declared_Popen_OSError_finishes_failed_without_success_else'])
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['command_history_component'].update(test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],
  review_control_qualification='Review controls2=1PASS(bool/nonbounded rejection),1ERROR from test event(kind) param colliding with command_end record kind BEFORE P0 observation. Failed producer/Aux/writer returns not all serialized; no reconstruction. Fixed callback param/early unit run retention; only previously blocked control executes again, source unchanged.',
  review_fixed=dict(tests=result['tests'],failures=result['failures'],errors=result['errors']),ROOT_final_assessment_pending=True)
 native['current_helper_source_epoch'].update(test_sha256=result['source_sha256']['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'review-fixed-hashes.json'))
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(tests=result['tests'],failures=result['failures'],errors=result['errors'],
 producer=result['source_sha256']['tool/native_perf_build_producer.py'],test=result['source_sha256']['tool/test_native_perf_build_producer.py'])))
