import sys,pathlib,json,ast,hashlib,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 work=pathlib.Path('/tmp/connectanum-native-perf-command-history-design');work.mkdir()
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 put('declaration.json',dict(scope='NEW command Popen history retention design; readonly source/model/admin only',source_epoch='9c771de5d79774bcb7980a364e34099f1b15c036891e9af538749de6fd49544a',source_edit=False,SDK_build_capture_or_tests=False))
 path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd);pieces=[]
  while True:
   data=os.read(fd,65536)
   if not data:break
   pieces.append(data)
  raw=b''.join(pieces);assert hashlib.sha256(raw).hexdigest()=='9c771de5d79774bcb7980a364e34099f1b15c036891e9af538749de6fd49544a'
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  assert identity(before)==identity(os.fstat(fd))==identity(path.stat())
 finally:os.close(fd)
 text=raw.decode();tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandProducer')
 wanted={'__init__','_spawn','_observe_direct_status','_end_command','wait','_git'}
 selected='\n\n'.join(ast.get_source_segment(text,node) for node in cls.body if isinstance(node,ast.FunctionDef) and node.name in wanted)
 question='Summarize ONLY selected current source, max350words: first retention/spawn order, when current Popen is overwritten, where actual wait returns vs poll/status/metadata are retained, and which Aux references already persist. Identify precise missing history fields; do not invent methods or change policy. We need immutable/private lifetime references before fallibleIO; NOT descendant/unknownstart/physicalEXrelease/admission proof. No SDK/workload/test/build run proposed. No automatic close/kill/retry advice.'
 context=question+'\n\n'+selected
 with (work/'summary-context.txt').open('x') as out:out.write(context)
 assert len(context)<23000
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--stdin','--num-predict','1100','--max-input-chars','24000','--max-response-chars','7000','--timeout','180','--save-output',str(work/'summary.txt'),'--prompt',question]
 put('summary-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_identity=identity(before)))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('summary-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('summary-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-7000:])
