import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-command-history-design')
 path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py');raw=path.read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='78ae89da207c41d6bf05baf51df7d431d6098e45d557cb87a587ed243557be16'
 text=raw.decode();tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CommandProducer')
 selected='\n\n'.join(ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('_command_history_error','_wait_command_natural','_spawn','wait','_end_command'))
 selected+='\n\n'+ast.get_source_segment(text,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_receipt_reader_io'))
 context='NEW direct CommandProducer private history/wait witness component. Empty history/globalfirst fields initialized before ctor lease callback. Captured _COMMAND_POPEN_TYPE is original subprocess.Popen class. No public observer/raw concurrent API or release authority. Reserve attempt before event/log/pipe/Popen. Exact process/log/pipe refs kept for process life; parentFDnumbers never closeauthority. Actual SAMEPopen.wait METHOD return before _end_command; poll notmarker/equal cached status accepted, timeout sameactor/no cancel/retry. Source original OSError repr/add_note spawn cleanup deliberately UNCHANGED, private first retained BEFORE it; no claim public masking/uncertainFDcleanup fixed. Generic reader IO separated from output seam after existing callback ownership test exposed private seam collision; nativecalls unchanged and reader tests migrated explicitly.22selectedPASS=8newhistory +13migratedreader +1failingoutputcaller; earlierbefore accidentally inherited8resource cases, not rerun unchanged passing7. Unitroot actualEX/finitePython/directrecipes + actualFixtureGit/6shellSHIMS/receipt, NOTSDK/canonical/closure. Model advice advisory, max2 concrete bugs/max250words; no automatic uncertainclose/kill/retry/freshwaitsyscall/globalatomicity/auth claims.\n\n'+selected
 assert len(context)<22000
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 with (work/'review-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','2100','--max-input-chars','23000','--max-response-chars','9000','--timeout','180','--save-output',str(work/'review.txt'),'--prompt','Review selected current new history/wait code, max2 concrete source-supported bugs/max250words. No extra wait/retry/automatic uncertainFDclose/global closure suggestions. Preserve original public cleanup policy limitation.']
 put('review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('review-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
