import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-command-history-design')
 data=json.loads(pathlib.Path('/tmp/connectanum-native-perf-command-history/before-tests.json').read_text())
 context='NEW BEFORE harness triage only. Private command history/wait APIs not implemented. Suite accidentally selected inherited ReceiptResourceTests8 plus NEWCommandHistory8 =>16, no unchanged inherited rerun authorized/intent; preserve evidence and select explicit methods next. Cluster missing APIs vs test harness teardown/import faults vs old private IO seam integration. Existing source9c771 added owned reader records calling _receipt_resource_io but these live in separate _receipt_readers ledger, while inherited test_record_and_exact_FD callback asserts ALL IO resources in _receipt_resources. ROOT proposes separate reader-native seam, preserving old output seam; migrate new reader tests explicitly. New direct self.start(ok,ok) has2recipes, no6SHIMS unless receipt_fixture. Pending/None teardown must actual sameactor bounded wait and only known fixture cleanup, not live workaround. No source change/test rerun or SDK. Max350words/advisory ROOT verifies.\n\n'+json.dumps({key:data[key] for key in ['tests','failures','errors','failures_detail','errors_detail']},indent=2)
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 with (work/'debug-context.txt').open('x') as out:out.write(context)
 assert len(context)<24000
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','debug','--stdin','--num-predict','1400','--max-input-chars','25000','--max-response-chars','8000','--timeout','180','--save-output',str(work/'debug.txt'),'--prompt','Cluster NEW harness/missingAPI/private IO-seam failures, max350words. No kill/retry/live cleanup/false production defect counts.']
 put('debug-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (work/('debug-'+label+'.bin')).open('xb') as out:out.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('debug-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-8000:])
