import os,time
time.sleep(0.08)
os.write(1,b'PENDING-TRUE-NEW-out')
os.write(2,b'PENDING-TRUE-NEW-err')
