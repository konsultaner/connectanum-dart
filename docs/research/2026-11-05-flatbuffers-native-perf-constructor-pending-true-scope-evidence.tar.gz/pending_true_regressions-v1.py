import unittest,pathlib,tempfile,sys,os,hashlib,json,subprocess
import native_perf_build_producer as b
Path=pathlib.Path
def pending_true_sha(raw):return hashlib.sha256(raw).hexdigest()
class PendingTrueFirst(RuntimeError):pass
class PendingTrueSecond(RuntimeError):pass
class PendingTrueScopeTests(unittest.TestCase):
 def _case(self,mode):
  root=Path(os.environ['CONNECTANUM_PENDING_TRUE_FIXTURES']);root.mkdir(exist_ok=True)
  base=Path(tempfile.mkdtemp(prefix=mode+'-',dir=root)).resolve();repo=base/'repo';repo.mkdir();run=base/'run'
  setup=[];actors=[];pipes=[];files=[];groups=[];seen={'spawn_returned':False,'pending_native':[]}
  first=PendingTrueFirst('pending-true-root-first');second=PendingTrueSecond('pending-native-True-then-secondary')
  def git(*args):
   i=len(setup);argv=['git','-C',str(repo),*args];row={'argv':argv,'Popen_attempted':True,'pid':None};setup.append(row)
   (base/f'setup-{i}-before.json').write_text(json.dumps(row))
   process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=process.wait
   (base/f'setup-{i}-start.json').write_text(json.dumps({'pid':process.pid}))
   out,err=process.communicate();status=wait(10)
   (base/f'setup-{i}-stdout.bin').write_bytes(out);(base/f'setup-{i}-stderr.bin').write_bytes(err)
   row.update(pid=process.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=pending_true_sha(out),stderr_sha256=pending_true_sha(err))
   (base/'setup-commands.json').write_text(json.dumps(setup,indent=2))
   if status!=0:raise RuntimeError('new fixture setup refused')
   return out
  git('init','-q');git('config','user.email','pending-true@example.invalid');git('config','user.name','Pending True Fixture')
  (repo/'.gitignore').write_text('inputs/\n')
  (repo/'worker.py').write_text("import os,time\ntime.sleep(0.08)\nos.write(1,b'PENDING-TRUE-NEW-out')\nos.write(2,b'PENDING-TRUE-NEW-err')\n")
  git('add','.');git('commit','-qm','new pendingTrue catch fixture');head=git('rev-parse','HEAD').decode().strip()
  expected=pending_true_sha(git('archive','--format=tar',head));(repo/'inputs').mkdir();(repo/'inputs'/'context').write_bytes(b'pending-true-input-v1')
  inputs={'inputs/context':pending_true_sha((repo/'inputs'/'context').read_bytes())}
  native_os=b.os;native_open=Path.open;native_aux=b.AuxiliaryCommand._allocate_process;native_recipe=b.CommandProducer._allocate_command_process
  native_spawn=b.CommandProducer._spawn;native_get=b.CommandProducer.__getattribute__;native_group=b._failure_preservation_group
  def remember(process,kind):
   actors.append({'process':process,'wait':process.wait,'pid':process.pid,'kind':kind})
  class OSFacade:
   def __getattr__(self,name):return getattr(native_os,name)
   def pipe(self):
    pair=native_os.pipe();info=[]
    for fd in pair:
     st=native_os.fstat(fd);info.append({'fd':fd,'dev':st.st_dev,'ino':st.st_ino,'inheritable':native_os.get_inheritable(fd)})
    pipes.append({'pair':pair,'info':info})
    return pair
  def opened(path,*args,**kwargs):
   value=native_open(path,*args,**kwargs)
   if path.parent==run:
    raw=getattr(value,'raw',None)
    for stream in ([raw,value] if raw is not None and raw is not value else [value]):
     st=native_os.fstat(stream.fileno());files.append({'path':str(path),'stream':stream,'close':stream.close,'fd':stream.fileno(),'dev':st.st_dev,'ino':st.st_ino})
   return value
  def auxiliary(owner,record):
   process=native_aux(owner,record);remember(process,'Auxiliary');return process
  def recipe(owner,attempt,argv,writer):
   process=native_recipe(owner,attempt,argv,writer);remember(process,'recipe')
   matches=[row for row in reversed(pipes) if row['pair'][1]==writer];assert matches
   seen['recipe_pipe']=matches[0];seen['recipe_process']=process;return process
  def spawned(owner):
   raw=native_spawn(owner)
   seen.update(owner=owner,spawn_returned=True,spawn_raw_None=raw is None,actual_spawn_stage=owner._command_attempt['stage'])
   raise first
  def grouped(owner,error):
   value=native_group(owner,error)
   if seen['spawn_returned'] and seen.get('owner') is owner:groups.append(value)
   return value
  def gotten(owner,name):
   value=native_get(owner,name)
   if seen['spawn_returned'] and seen.get('owner') is owner and name=='pending':
    seen['pending_native'].append(value)
    if mode=='secondary' and not seen.get('pending_fault'):
     seen['pending_fault']=True;raise second
   return value
  received=None;returned=None;result=None;evidence_ready=False
  try:
   b.os=OSFacade();Path.open=opened;b.AuxiliaryCommand._allocate_process=auxiliary;b.CommandProducer._allocate_command_process=recipe
   b.CommandProducer._spawn=spawned;b.CommandProducer.__getattribute__=gotten;b._failure_preservation_group=grouped
   try:
    returned=b.CommandProducer(repo=repo,source_commit=head,runtime_commit=head,run_dir=run,expected_archive_sha256=expected,inputs=inputs,commands=[[sys.executable,str(repo/'worker.py')]],lease_check=lambda:None,provenance='fixture')
    b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
    if mode=='defer':result=returned.wait(10)
   except BaseException as error:received=error
   finally:
    b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
    b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   guard_error=None
   if mode=='secondary' and groups:
    try:groups[0][1]()
    except BaseException as error:guard_error=error
   owner=seen.get('owner')
   view={'pending_true_scope':mode,'spawn_returned_inside_ROOT':seen['spawn_returned'],'spawn_raw_None':seen.get('spawn_raw_None'),'spawn_stage':seen.get('actual_spawn_stage'),'pending_native_true_values':all(value is True for value in seen['pending_native']) and bool(seen['pending_native']),'pending_native_count':len(seen['pending_native']),'pending_fault':seen.get('pending_fault',False),'Source_returned_owner':returned is not None,'received_First':received is first,'received_Secondary':received is second,'received_type':None if received is None else type(received).__name__,'captured_private_guard_First':guard_error is first,'Source_pending_DATA':None if owner is None else native_get(owner,'pending'),'Source_finished_DATA':None if owner is None else native_get(owner,'finished'),'result_status':None if result is None else result['status'],'result_error':None if result is None else result['error'],'result_recipe_status':None if result is None else result['commands'][0]['returncode'],'Source_failure_attempted_DATA':None if owner is None else native_get(owner,'failure_attempted'),'actor_rows':[{'pid':row['pid'],'kind':row['kind']} for row in actors],'no_live_ownership_or_runtime_admission':True}
   (base/'view-before-ROOT-wait.json').write_text(json.dumps(view,indent=2));evidence_ready=True
   if mode=='defer':
    self.assertIsNone(received);self.assertIsNotNone(returned);self.assertEqual('failed',result['status']);self.assertIn('pending-true-root-first',result['error']);self.assertEqual(0,result['commands'][0]['returncode'])
    self.assertEqual(b'PENDING-TRUE-NEW-outPENDING-TRUE-NEW-err',(run/'command-000.log').read_bytes())
   else:
    self.assertTrue(received is first);self.assertIsNone(returned);self.assertTrue(view['pending_fault']);self.assertTrue(view['pending_native_true_values']);self.assertTrue(view['captured_private_guard_First']);self.assertTrue(view['Source_pending_DATA']);self.assertFalse(view['Source_finished_DATA'])
   self.assertTrue(view['spawn_raw_None']);self.assertEqual('spawned',view['spawn_stage']);self.assertTrue(view['pending_native_true_values'])
  finally:
   b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
   b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   if not evidence_ready:raise RuntimeError('ROOT evidence absent; no cleanup claim')
   rows=[]
   for row in actors:
    raw=row['wait'](10);rows.append({'kind':'same_original_bound_wait','actor_kind':row['kind'],'pid':row['pid'],'status':raw,'signed_native_int':type(raw) is int})
   if mode=='secondary':
    pipe=seen['recipe_pipe'];fd=pipe['pair'][0];identity=pipe['info'][0];st=native_os.fstat(fd)
    same=(st.st_dev,st.st_ino)==(identity['dev'],identity['ino']);assert same
    assert native_os.get_blocking(fd) is False
    data=native_os.read(fd,65536);tail=native_os.read(fd,1);(base/'ROOT-recipe-pipe.bin').write_bytes(data);(base/'ROOT-recipe-pipe-tail.bin').write_bytes(tail)
    record={'fd':fd,'same_devino':same,'existing_nonblocking':True,'size':len(data),'sha256':pending_true_sha(data),'tail_size':len(tail),'EOF':tail==b'','not_Source_log_reconstruction':True}
    (base/'ROOT-pipe-before-close.json').write_text(json.dumps(record,indent=2));rows.append({'kind':'recipe_raw_pipe','record':record})
    self.assertEqual(b'PENDING-TRUE-NEW-outPENDING-TRUE-NEW-err',data);self.assertEqual(b'',tail)
   (base/'ROOT-before-FDclose.json').write_text(json.dumps({'evidence_ready':True,'rows':rows},indent=2))
   for pipe in pipes:
    for info in pipe['info']:
     try:st=native_os.fstat(info['fd'])
     except OSError as error:rows.append({'kind':'creatorFD','fd':info['fd'],'already_closed_errno':error.errno});continue
     same=(st.st_dev,st.st_ino)==(info['dev'],info['ino']);rows.append({'kind':'creatorFD','fd':info['fd'],'same_devino':same,'closed_by_ROOT':same})
     if same:native_os.close(info['fd'])
   for item in files:
    if item['stream'].closed:continue
    try:st=native_os.fstat(item['fd'])
    except OSError as error:rows.append({'kind':'file','path':item['path'],'fd':item['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(item['dev'],item['ino']);record={'kind':'file','path':item['path'],'fd':item['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(record)
    if same:
     try:item['close']();record['closed_by_ROOT']=True
     except BaseException as error:record['close_error_type']=type(error).__name__
   (base/'ROOT-unit-cleanup.json').write_text(json.dumps({'evidence_ready':True,'rows':rows,'unit_not_live_ownership_fullFD_descendant_closure':True},indent=2))
 def test_new_pendingTrue_normal_deferral_after_whole_spawn_return(self):self._case('defer')
 def test_new_pendingTrue_native_get_then_secondary_retains_First(self):self._case('secondary')
