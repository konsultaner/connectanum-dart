import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-pending-true-scope-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-constructor-pending-true-scope'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='124d1ac0ce359fd5e2963c8ab48f2727e77e3c20'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common='## 2026-11-05 — Check pendingTrue deferral without changing Source\n\nTwo new private integration cases pass on unchanged producer ae1d1a and tests0265f8. A wrapper invokes the whole original spawn body, including actual fixture Git/archive operations, a returned native recipe Popen, parent-writer close and the durable spawned event. Only after that body returns None does ROOT raise First. This differs from the earlier command_spawned-event fault test, which is not replayed.\n\nNormal pendingTrue metadata returns the deferred producer; its actual wait returns a failed result preserving First, signed recipe status0 and the full40-byte log. When the native pending getter returns True inside ROOT and then raises Secondary, the constructor raises First and supplies no returned owner. The captured private guard raises that same First; ROOT uses separately retained original actor/pipe handles. PendingTrue remains metadata, with no liveness or ownership implication.\n\nOnly these two private cases execute. No Source/test edit or append, Source HEAD/current20 recensus, build, capture or adoption occurs. The earlier six selected tests and frozen25PASS/2ERROR epoch remain separate. Both bounded model calls finish; ROOT qualifies their claims and corrects an input byte count from38 to the actual40 without rerunning anything. Original Linux credentials, full independent EX, transitive actor/FD closure, immutable runtime admission and RAM repair remain incomplete.\n\n'
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-constructor-pending-true-scope'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: qualify private pendingTrue integration controls'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_pending_true_scope'].update(publication=receipt,docs_pending=False)
 n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Next genuinely NEW predeclared question: earlier private failure-group acquisition/binding/interior failure before a guard handle is returned, or historical/transitive actor and immutable original-runtime preflight. These are prospective; no Source edit without meaningful actual BEFORE-failing regression. PendingTrue is now covered ONLY by privateNEW2 at unchangedae1d1a/0265f8: actualwhole_spawn returnsNone insideROOT beforeRootFirst; normalmetadata defers with actualknownowner.wait10/failedresult/OriginalFirst/recipe0/full40B log; nativependingTrue thenSecondary keepsFirst/no Source-returnedowner/postfaultmethods, actualprivateguardcapturedBEFOREsecondary. Source fields data never liveness/ownership. Twelve sameoriginalboundwait rows6percase(5Aux1recipe), allsigned0/cachedpossible;14setupGit separate0-BOTH; secondaryRootcreatorreadFD native40B+EOF thenclose1pipe2files AFTERevidence/assertions, normalalreadySourceclosed/no reclose. ParentDarwinEX4None UNITnotphysicalEX-originalLinux/fullFD-interpreter-delegate-descendantclosure/admission. Unexpectedbeforeview/Rootwait-read failures maymask/preventlatercleanup, no generalall-errorcleanup/fullreap. Qwen3563=0/696out312err;GLM5570=0/4474out1030err/BOTH EOF-reaped/fullanswers-ROOTqualified notwholecurrentapproval. ROOTsaved-data assertssecondarypendingcount1/normal9, actualreturnNone-stage_spawned, realSource.wait andRootrecipe0/full40B; rejectsyntheticresult/missingguardfalsepass/pre-viewassertordering claims; modelinput38B wrongactual40 retainedcorrectedno replay. Source/test2freshbeforeafter unchanged/privateharnessUNAPPENDED; oldSourceHEAD601/helper20-productionnativeexact601 arepreviousDATA only/no SourceHEAD-current20recensus. No Source/test/harness edit afterexecution/old6-old27/completed25-old2bodies-old7suite replay/aggregatecurrentcanonical. Interruptedafterallknownunit-modelcompletion; exactfinaltoolAPIobjectsnotallretainedacrosstoolsupdate/no omissionreconstruction. Sourcegroups-closures-rawchunksprocesslife NOTfixedmemory/heapRSSgrowth-timing-leakcauseUNMEASURED/no RAMrepair-memorybound-trim-reset-evict-deleteauthority. All20uncommitteduncanonicalunadmitted/providerABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no Sourceadoption-build-capture-strictdispatch; frozenowner_emit_attempted/oldauxpredicates; UnknownPopenCtorPERMANENT/no partialmethods-fieldderivedsettlement.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Constructor_pendingTrue_privateNEW2PASS_SourceUNCHANGED_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
