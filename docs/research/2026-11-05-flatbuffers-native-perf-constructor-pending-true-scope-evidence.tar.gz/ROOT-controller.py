import sys,pathlib,json,hashlib,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-pending-true-scope-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();a=json.loads((P/'private-NEW2/result.json').read_text());assert (a['tests'],a['failures'],a['errors'])==(2,0,0)
 assert len(a['leases'])==4 and all(x['raw_None'] for x in a['leases']) and not a['Source_test_edits']
 expected={'tool/native_perf_build_producer.py':'ae1d1affd969a94137b886b20f3aefd231dd2fd4f3d7d95b2fbe382db31f7d79','tool/test_native_perf_build_producer.py':'0265f84d36016deb2c163c8af09cf0a5578a8f4367462fbca26fb22bda406e7d'}
 assert a['Source_test_fresh2_unchanged']==expected
 pre=json.loads((P/'harness-preexecution.json').read_text());assert hashlib.sha256((P/'pending_true_regressions-v1.py').read_bytes()).hexdigest()==pre['harness_sha256']
 rows=[]
 for d in sorted((P/'private-NEW2/fixtures').iterdir()):
  v=json.loads((d/'view-before-ROOT-wait.json').read_text());c=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text())
  assert v['spawn_returned_inside_ROOT'] and v['spawn_raw_None'] and v['spawn_stage']=='spawned' and v['pending_native_true_values']
  assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup)
  for i,x in enumerate(setup):
   for channel in ('stdout','stderr'):
    raw=(d/f'setup-{i}-{channel}.bin').read_bytes();assert len(raw)==x[channel+'_size'] and hashlib.sha256(raw).hexdigest()==x[channel+'_sha256']
  waits=[r for r in c['rows'] if r['kind']=='same_original_bound_wait'];assert len(waits)==6 and all(r['status']==0 and r['signed_native_int'] for r in waits)
  assert sum(r['actor_kind']=='recipe' for r in waits)==1
  journal=(d/'run/journal.jsonl').read_bytes();events=[json.loads(line) for line in journal.splitlines()];assert sum(e['event']=='command_spawned' for e in events)==1
  if v['pending_true_scope']=='secondary':
   assert v['pending_native_count']==1 and v['received_First'] and not v['received_Secondary'] and v['captured_private_guard_First'] and not v['Source_returned_owner']
   assert v['Source_pending_DATA'] is True and v['Source_finished_DATA'] is False and v['Source_failure_attempted_DATA'] is False
   raw=(d/'ROOT-recipe-pipe.bin').read_bytes();tail=(d/'ROOT-recipe-pipe-tail.bin').read_bytes();pipe=json.loads((d/'ROOT-pipe-before-close.json').read_text())
   assert raw==b'PENDING-TRUE-NEW-outPENDING-TRUE-NEW-err' and len(raw)==40 and tail==b''
   assert pipe['size']==40 and pipe['sha256']==hashlib.sha256(raw).hexdigest() and pipe['EOF'] and pipe['existing_nonblocking']
   assert (d/'run/command-000.log').read_bytes()==b''
   assert sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='creatorFD')==1
   assert sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='file')==2
  else:
   assert v['pending_true_scope']=='defer' and v['pending_native_count']==9 and v['Source_returned_owner'] and v['received_type'] is None
   assert v['result_status']=='failed' and 'pending-true-root-first' in v['result_error'] and v['result_recipe_status']==0
   assert v['Source_pending_DATA'] is False and v['Source_finished_DATA'] is True
   raw=(d/'run/command-000.log').read_bytes();assert raw==b'PENDING-TRUE-NEW-outPENDING-TRUE-NEW-err' and len(raw)==40
   assert sum(r.get('closed_by_ROOT',False) for r in c['rows'])==0
  rows.append(dict(view=v,original_waits=waits,setup_statuses=[x['status'] for x in setup],root_cleanup=c,journal_sha256=hashlib.sha256(journal).hexdigest()))
 assert len(rows)==2
 models={}
 for name in ('planning','review'):
  r=json.loads((P/name/'result.json').read_text());assert r['status']==0 and r['both_separate_EOF'] and (P/name/'answer.txt').is_file();models[name]=r
 corrections=json.loads("{\"Qwen\":\"Original _spawn returns None inside ROOT; ROOT then raises First. First does not return None. Fault hooks restore before the actual Source.wait; native capture delegates remain through that wait.\",\"GLM\":[\"Actual secondary pending_native_count is exactly1; ROOT checks saved count without unit replay. Do not stop recording later accesses, which would conceal evidence.\",\"Actual original whole_spawn returned None at stage spawned, both asserted. Root-local unique First is raised only after that actual return. The hypothetical producer-own First is not an executed counterexample; runtime aliases/interiors remain outside proof.\",\"Recipe status is not synthetic: known Source-returned owner.wait(10) executes; full40-byte Source log and actual ROOT original recipe wait signed0 independently agree with result returncode0. Cached possible/this is not physicalEX or original Linux admission.\",\"Missing groups cannot silently pass: captured_private_guard_First would be false and existing assertion fails. Actual guard raises the same First.\",\"View write and evidence_ready=True precede behavioral assertions. Claimed pre-view assertion ordering is wrong. Unexpected failures before view or during ROOT wait/read can still mask errors or prevent later cleanup; no general all-error cleanup or actor/FD closure is claimed.\",\"Monkeypatch/interpreter/delegate/descendant/concurrentABA and original Linux limits remain explicit. No source/test/harness change or unit/model replay justified by these review claims.\"],\"review_input_count_correction\":\"GLM context incorrectly said38B; actual literal payload, saved Source log and ROOT raw are40B. Original model input is frozen, not changed/replayed.\",\"interruption\":\"No tool call was in flight when interrupted after model completion. Exact final tool API objects are not all retained across the tools update; use saved actual unit/model journals and never reconstruct omitted API returns.\"}")
 (P/'ROOT-model-corrections.json').open('x').write(json.dumps(corrections,indent=2))
 free=shutil.disk_usage(P).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),Source_test_UNCHANGED=expected,private_NEW2_only=a,views=rows,Source_test_harness_edits=False,private_harness_not_appended_or_adopted=True,prior6_old27_old25_old2bodies_old7suite_replayed=False,SourceHEAD_current20_recensus=False,older_HEAD601_helpers20_production_native_epoch_DATA_only=True,SourceRuntime_compiledcanonical_originalLinux_EX_admission=False,models=models,ROOT_model_corrections=corrections,unit_only=True,source_groups_rawchunks_processlife_NOT_fixedmemory_RSSgrowth_timing_cause_UNMEASURED=True,no_build_capture_dispatch_adoption_RAMrepair_acceptance=True,unexpected_beforeview_wait_read_failure_cleanup_not_proved=True,available_API_only_no_omission_reconstruction=True,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_pending_true_scope'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,Source_test_edits=False,private2_only_not_combinedcanonical=True);c.update(updated_utc=assessment['utc'],active_turn_status='Constructor_pendingTrue_privateNEW2PASS_SourceUNCHANGED_ROOTqualified_DOCSpending');cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(privateNEW2PASS=True,Source_test_UNCHANGED=expected,actual_fullbytes40=True,known_original_wait_rows12_signed0=True,models_both_natural0=True,ROOT_qualified_scoped_ONLY=True,free_bytes=free,full_admission=False)))
