import sys,pathlib,json,hashlib,shutil,unittest,importlib.util,io,datetime,os
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-pending-true-scope-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'private-NEW2';q.mkdir();free=shutil.disk_usage(R).free;assert free>=1024**3
 expected={'tool/native_perf_build_producer.py':'ae1d1affd969a94137b886b20f3aefd231dd2fd4f3d7d95b2fbe382db31f7d79','tool/test_native_perf_build_producer.py':'0265f84d36016deb2c163c8af09cf0a5578a8f4367462fbca26fb22bda406e7d'}
 before={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert before==expected
 (q/'fresh2-source-test.json').write_text(json.dumps(before,indent=2));(q/'floor.json').write_text(json.dumps(dict(free_bytes=free,fresh_1GiB_floor=True,no_build_capture_deletion_authority=True)))
 os.environ['CONNECTANUM_PENDING_TRUE_FIXTURES']=str(q/'fixtures');sys.path.insert(0,str(R/'tool'))
 spec=importlib.util.spec_from_file_location('pending_true_scope',P/'pending_true_regressions-v1.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   leases.append(dict(test=str(test),position='before',raw_None=l.verify_identity() is None));super().startTest(test)
  def stopTest(self,test):
   leases.append(dict(test=str(test),position='after',raw_None=l.verify_identity() is None));super().stopTest(test)
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(module.PendingTrueScopeTests);stream=io.StringIO()
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(suite)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert after==before
 (q/'stdout.txt').write_text(stream.getvalue());out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),leases=leases,Source_test_fresh2_unchanged=after,Source_test_edits=False,private_NEW2_only=True,prior6_old27_completed25_old2bodies_old7suite_replayed=False,SourceHEAD_current20recensus_or_compiledcanonical_admission=False,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(out,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_pending_true_scope']={'directory':str(P),'declaration':str(P/'attempt-declaration.json'),'private_result':out,'ROOT_pending':True,'Source_test_edits':False,'SourceHEAD_current20_not_refreshed':True};c.update(updated_utc=out['utc'],active_turn_status='Constructor_pendingTrue_NEW2_private_recorded_ROOTpending');cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps({k:v for k,v in out.items() if k not in ('leases','details')}));print(stream.getvalue()[-7000:])
