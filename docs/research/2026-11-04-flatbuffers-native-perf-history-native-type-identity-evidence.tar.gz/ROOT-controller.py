import sys,pathlib,json,hashlib,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait();slot=len(calls)
  row=dict(argv=argv,pid=child.pid,status=status,stdout_eof=True,stderr_eof=True)
  for label,data in [('stdout',out),('stderr',err)]:
   with (q/(str(slot)+'-'+label+'.bin')).open('xb') as f:f.write(data)
   row[label+'_size']=len(data);row[label+'_sha256']=hashlib.sha256(data).hexdigest()
  calls.append(row);(q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();gitstatus=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in gitstatus.splitlines()) and {line[3:] for line in gitstatus.splitlines()}==names and not production
 expected=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 before=json.loads((P/'before/result.json').read_text());after=json.loads((P/'after-selected/result.json').read_text())
 assert (before['tests'],before['failures'],before['errors'])==(4,3,0) and (after['tests'],after['failures'],after['errors'])==(6,0,0)
 planning=json.loads((P/'test-planning/finish.json').read_text());review=json.loads((P/'review/finish.json').read_text())
 unitrows=[];reports=[]
 for stage in ('before','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('unit-teardown.json')):
   data=json.loads(path.read_text());assert all(type(row['status']) is int and row['status']==0 for row in data['actors']) and all(row['alive'] is False for row in data['threads'])
   unitrows.append(dict(stage=stage,path=str(path),actors=data['actors'],threads=data['threads'],knownfinite_only=True,wait_may_be_cached_not_fresh_syscall=True))
  for path in sorted((P/stage/'fixtures').rglob('opaque-type-before-cleanup.json')):
   data=json.loads(path.read_text());assert data['forbidden_actor_FD_calls']==[]
   if stage=='after-selected':assert data['type_equality_calls']==0 and data['original_error_retained'] and data['both_attempts_retained'] and not data['history_primary_is_foreign_hook']
   reports.append(dict(stage=stage,path=str(path),data=data))
 with (q/'new-unit-journals.json').open('x') as f:json.dump(unitrows,f,indent=2)
 with (q/'new-precleanup-reports.json').open('x') as f:json.dump(reports,f,indent=2)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),final_source_hashes=expected,new_BEFORE4=dict(source='90178/a35e',tests=4,failures=3,errors=0,normal_PASS=1),AFTERselected6=dict(source='5ba379/e05804',tests=6,failures=0,errors=0,new=4,affected=2),no_combined_or_fullfinal_current20canonical_claim=True,one_native_type_branch_replaced_only=True,all_original_test_nodes_and_bytes_unchanged=True,other18_helpers_and3_bins_byteexact=True,source_Git=dict(head=head,branch=branch,untracked_count=len(names),production_packages_native_diffempty=True,four_actual_signed0_BOTH_EOF=True,DATA_not_compiled_instructions_or_admission=True),model_planning=planning,model_review=review,model_inherited_fixture_helper_omitted_not_full_source_approval=True,ROOT_whole_affected_source_test_class_AST_and_originalfixture_qualification=True,unit_journal_files=len(unitrows),unit_actor_wait_rows=sum(len(row['actors']) for row in unitrows),knownfinite_unit_not_original_physical_EX=True,precleanup_reports=len(reports),no_aggregate_original_runtime_proof=True,admin_correction='edit-v1 asserts main guard must be final node BEFORE any declaration/source write; old tests append classes after earlier main guard; corrected v2 appends new class preserving all old nodes/bytes; no before/control rerun',planning_limit_not_backend_unavailable_or_approval=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,storage_change_cause_UNMEASURED=True,source20_uncommitted_uncanonical_unadmitted=True,production601_unedited=True,private_artifacts_outside_HELPERBUNDLE20=True,no_SDK_build_canonical_kernel_broker_benchmark_capture_cleanup_adoption=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_open_draft_base130_issue103_milestone_open=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['history_type_identity_implementation']
 v.update(review_pending=False,review_status=review['status'],ROOT_assessment=str(q/'assessment.json'),ROOT_qualification_complete=True,publication_pending=True,narrow_source_component_complete=True,remaining_physicalEX_and_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW history-native-type postcomponent fourGit actual0/BOTHseparateEOF/branchcodex/flatbuffers-native-perf-guard/HEAD601/exact20untracked/productiondiffempty DATAonly')
 n['next_new_source_question']['status']='COMPLETE_narrow_type_branch_fix_new_BEFORE3FAIL1PASS_AFTERselected6PASS_ROOTqualified'
 c['active_turn_status']='History_native_type_identity_5ba379_e05804_selected6PASS_ROOTqualified_publication_pending_no_SDK_native_capture'
 cp.write_text(json.dumps(c,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(HEAD=head,branch=branch,new_before='3FAIL1PASS0ERROR',after='6PASS',unit_journal_files=len(unitrows),unit_actor_wait_rows=assessment['unit_actor_wait_rows'],free_bytes=free,not_current20canonical_or_runtime_admission=True)))
