import sys,pathlib,json,hashlib,subprocess,datetime,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1')
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();q=P/'review';q.mkdir();ctx=json.loads((P/'source-context.json').read_text())['methods']
 prefix=ctx['_capture_command_history'].split('        def dictionary')[0]
 context="""NEW focused patch review, advisory only. Whole source/test delta is a single conditional plus one NEW regression class. No original gate/factory/emitter/test assertion changes. Need review only for actual bugs in native-type filtering and regression coverage. Do not propose closure/retry/wait authority from fields. This method is passive DATA; no actor/FD I/O. Actor/runtime ownership and independent physicalEX remain INCOMPLETE. No SDK/build/capture/admission.
Hypothesis confirmed at90178/a35e: 4 NEW explicit selected tests =3FAIL1nativecontainerPASS/0ERROR. False metaclass equality called6 times; True/throwing called1. True lies container and throwsTypeError; throwing replaces history error; root precleanup reports retained. The record's opaque error is synthetic DATA placement amid two real finite Python command actors, not an actual native runtime error. Native type identity must never invoke foreign equality.
Final5ba379/e05804 six selected PASS (4new+2affected list-swap/quarantine callers), not combined with any prior selection or wholecurrent20canonical. Original inherited finite helper/teardown NOT INCLUDED below: earlier exact known native SAMEactor waits/drains/identityclose only; ROOT inspects source and saved percase journals. Explicitselection avoids inherited test discovery. No model fullsource/helper approval.
BEFORE capture prefix:\n"""+prefix+"""\nONLY SOURCE CHANGE:
-            if kind not in (dict,list,tuple) or not deep:return
+            if not deep or (kind is not dict and kind is not list and kind is not tuple):return
Unchanged freeze wrapper:\n"""+ctx['_freeze_command_history']+'\nWHOLE NEW TEST CLASS:\n'+(P/'new-tests.py').read_text()+"""
Return concise findings with evidence. State if any concern is only inherited fixture limits or hypothetical. Avoid unsupported all-actor/physicalclosure/admission claims.
"""
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--reasoning-budget','256','--num-predict','1300','--max-input-chars','14000','--max-response-chars','7000','--timeout','240','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_sha256=hashlib.sha256(context.encode()).hexdigest(),context_chars=len(context),original_inherited_fixture_omitted=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];h=json.loads((P/'after-edit-hashes.json').read_text())
 n['history_type_identity_implementation']=dict(path=str(P),new_before=dict(tests=4,failures=3,errors=0,normal_PASS=1,source='90178/a35e'),after_selected=dict(tests=6,failures=0,errors=0,source='5ba379/e05804'),review_pid=child.pid,review_pending=True,source_uncommitted_uncanonical_unadmitted=True,not_original_runtime_or_physicalEX=True)
 n['current_helper_source_epoch'].update(producer_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'after-edit-hashes.json'),verification_scope='New native-type identity branch: six selected PASS=4new+2affected; ROOT final/review pending, not current20canonical/runtimeadmission',final_epoch_UNTESTED=False)
 n['next_new_source_question']['status']='CONFIRMED_NEW_BEFORE3FAIL1PASS_minimalfix_AFTERselected6PASS_reviewpending'
 c['active_turn_status']='History_native_type_identity_5ba379_e05804_selected6PASS_GLMreview_pending_no_SDK_native_capture'
 cp.write_text(json.dumps(c,indent=2)+'\n')
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 value=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (q/'finish.json').open('x') as f:json.dump(value,f,indent=2)
 lease.verify_identity();print(json.dumps(value));print(out.decode());print(err.decode()[-1200:])
