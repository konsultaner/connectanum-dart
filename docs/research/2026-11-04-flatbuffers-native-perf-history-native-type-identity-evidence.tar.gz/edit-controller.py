import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1/final-hashes.json').read_text())
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 result=json.loads((P/'before/result.json').read_text());assert (result['tests'],result['failures'],result['errors'])==(4,3,0)
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();new=(P/'new-tests.py').read_text()
 old='            if kind not in (dict,list,tuple) or not deep:return'
 replacement='            if not deep or (kind is not dict and kind is not list and kind is not tuple):return'
 assert source.count(old)==1;changed=source.replace(old,replacement)
 tree=ast.parse(tests);guard=[node for node in tree.body if isinstance(node,ast.If) and isinstance(node.test,ast.Compare) and ast.unparse(node.test)=="__name__ == '__main__'"]
 assert len(guard)==1 and guard[0] is tree.body[-1]
 lines=tests.splitlines(keepends=True);split=sum(map(len,lines[:guard[0].lineno-1]));changed_tests=tests[:split]+new+'\n\n'+tests[split:]
 ast.parse(changed);ast.parse(changed_tests)
 with (P/'edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='one native container type branch identity check; append four new explicit-selected regressions; no old expectation changes',new_before='4=3FAIL1PASS0ERROR',before_hashes=expected),f,indent=2)
 (R/'tool/native_perf_build_producer.py').write_text(changed)
 (R/'tool/test_native_perf_build_producer.py').write_text(changed_tests)
 final={name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in expected}
 assert all(final[name]==sha for name,sha in expected.items() if name not in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'))
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(final,f,indent=2)
 for name,data in [('after-producer.py',changed),('after-existing-tests.py',changed_tests)]:
  with (P/name).open('x') as f:f.write(data)
 lease.verify_identity();print(json.dumps({name:final[name] for name in final if 'build_producer' in name}))
