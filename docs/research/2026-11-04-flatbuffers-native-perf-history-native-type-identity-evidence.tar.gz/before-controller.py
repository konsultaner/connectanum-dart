import sys,pathlib,json,hashlib,os,io,types,unittest,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1/final-hashes.json').read_text())
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize;assert free>=1073741824
 stage=P/'before';stage.mkdir();fixtures=stage/'fixtures';fixtures.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();new=(P/'new-tests.py').read_bytes()
 for name,b in [('producer.py',source),('existing-tests.py',tests),('new-tests.py',new)]:
  with (stage/name).open('xb') as f:f.write(b)
 names=['test_opaque_error_type_false_equality_is_never_called','test_opaque_error_type_lying_equality_never_implies_container','test_opaque_error_type_throwing_equality_never_masks_history','test_exact_native_nested_container_bindings_remain_deep']
 with (stage/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),existing_test_sha256=hashlib.sha256(tests).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),selection=names,only_NEW_finite_regressions=True,old_controls_not_replayed=True),f,indent=2)
 sys.path.insert(0,str(R/'tool'))
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tests_module=types.ModuleType('test_native_perf_build_producer');tests_module.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tests_module.__name__]=tests_module;exec(compile(tests,tests_module.__file__,'exec'),tests_module.__dict__)
 exec(compile(new,str(P/'new-tests.py'),'exec'),tests_module.__dict__)
 cls=tests_module.HistoryOpaqueTypeIdentityTests;suite=unittest.TestSuite(cls(name) for name in names);out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (stage/'tests.log').open('x') as f:f.write(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),existing_test_sha256=hashlib.sha256(tests).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_SDK_native_benchmark=True)
 with (stage/'result.json').open('x') as f:json.dump(value,f,indent=2)
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 lease.verify_identity();print(json.dumps({k:value[k] for k in ['tests','failures','errors','source_sha256','new_test_sha256']}));print(out.getvalue()[-6500:])
