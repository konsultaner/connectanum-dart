class HistoryOpaqueTypeIdentityTests(FrozenCommandHistoryTests):
    def _opaque_history(self,mode):
        owner,op,sentinel=self.history_owner(True)
        attempts=tuple(op._command_attempts);calls=[];io_calls=[]
        poisoned=RuntimeError('foreign metaclass equality must never execute')
        class Meta(type):
            def __eq__(cls,other):
                calls.append('type-equality')
                if mode=='raise':raise poisoned
                return mode=='true'
            __hash__=type.__hash__
        class OpaqueError(RuntimeError,metaclass=Meta):pass
        opaque=OpaqueError('finite fixture retained error DATA')
        original=attempts[0]['first_error'];attempts[0]['first_error']=opaque
        original_owner_error=owner._first_error_object
        def forbidden(name):
            def fail(*args,**kwargs):
                io_calls.append(name);raise AssertionError('history actor/FD I/O forbidden: '+name)
            return fail
        patches=[mock.patch.object(producer.subprocess.Popen,name,side_effect=forbidden(name)) for name in ('poll','wait')]
        patches += [mock.patch.object(producer.os,name,side_effect=forbidden(name)) for name in ('fstat','read','close')]
        try:
            for patch in patches:patch.start()
            try:rows=self.freeze_history(owner)
            finally:
                for patch in reversed(patches):patch.stop()
            binding=owner._history_binding
            report=dict(mode=mode,scope='two actual finite command handles plus synthetic opaque error DATA placement; no SDK/admission',
                type_equality_calls=len(calls),forbidden_actor_FD_calls=io_calls,
                original_error_retained=any(item is opaque for item in binding),
                both_attempts_retained=all(any(item is attempt for item in binding) for attempt in attempts),
                owner_original_error_unchanged=owner._first_error_object is original_owner_error,
                history_primary_is_foreign_hook=owner._history_primary_error is poisoned,
                rows=[dict(row) for row in rows],pending=op.pending,finished=op.finished,
                no_next_command=not sentinel.exists())
            with (self.base/'opaque-type-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertEqual([],calls)
            self.assertEqual([],io_calls)
            self.assertTrue(report['original_error_retained']);self.assertTrue(report['both_attempts_retained'])
            self.assertTrue(report['owner_original_error_unchanged'])
            self.assertIsNone(owner._history_primary_error)
            self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
            self.assertEqual(2,len([row for row in rows if row['role']=='command']))
            self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
            self.assertFalse(op.log.closed);self.assertFalse(op.events.closed);self.assertFalse(sentinel.exists())
            for row in rows:
                self.assertIsNone(row['actor_ownership_complete'])
                for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[flag])
        finally:
            attempts[0]['first_error']=original

    def test_opaque_error_type_false_equality_is_never_called(self):
        self._opaque_history('false')

    def test_opaque_error_type_lying_equality_never_implies_container(self):
        self._opaque_history('true')

    def test_opaque_error_type_throwing_equality_never_masks_history(self):
        self._opaque_history('raise')

    def test_exact_native_nested_container_bindings_remain_deep(self):
        owner,op,sentinel=self.history_owner(True)
        attempt=op._command_attempts[0];cleanup=attempt['cleanup_close_attempts']
        marker=RuntimeError('opaque native-container leaf')
        leaf=[marker];middle={'native-list':leaf};outer=(middle,)
        cleanup.append(outer)
        try:
            rows=self.freeze_history(owner);binding=owner._history_binding
            retained=[any(item is value for item in binding) for value in (cleanup,outer,middle,leaf,marker)]
            with (self.base/'native-containers-before-cleanup.json').open('x') as f:
                json.dump(dict(retained=retained,rows=[dict(row) for row in rows],no_next=not sentinel.exists()),f,indent=2)
            self.assertEqual([True]*5,retained)
            self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
            self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
            self.assertFalse(sentinel.exists())
        finally:
            self.assertIs(outer,cleanup.pop())
