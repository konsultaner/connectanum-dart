import sys,pathlib,json,subprocess,datetime,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1')
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();q=P/'test-planning';q.mkdir()
 ctx=json.loads((P/'source-context.json').read_text())['methods']
 hold=ctx['_capture_command_history'].split('        def dictionary')[0]
 context="""NEW focused test planning. No old test/model replay.
Investigate whether tuple membership kind not in (dict,list,tuple) invokes a custom metaclass __eq__ for an opaque value's class, even when deep=False because the left side evaluates first. Source claims DATA only and must never invoke exception/foreign hooks, poll/wait/read/write/close. Hypothesis only, not confirmed.
Need 2-4 genuinely NEW finite regressions. A retained-worker fixture starts two actual quiet finite Python commands (first naturally reaped, second pending), then source wait is faulted to stop pipeline. Its history freeze action calls this real method on retained worker. Unit teardown exact known SAMEactor waits/drains/identitychecks only; no live cleanup/release authority.
Possible inject opaque custom-metaclass exception instance into actual retained attempt first_error DATA, then freeze. Three eq behaviors raise/False/True. Need precleanup hook count/actualfirstidentity/laterhandles/primitive rows noactorIO; no sourceflags or forged live receipts. A normal exactnative nestedcontainer positive should preserve deep binding traversal.
Suggest concise cases and important assertions, no implementation code. No SDK/build/benchmark/canonical/physicalEX claims. Likely minimalfix only the exact-native-type branch: identity comparisons and skip shallow first; preserve rest of method/gates.
CURRENT helper prefix:\n"""+hold
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','900','--max-input-chars','6000','--max-response-chars','5000','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_sha256=hashlib.sha256(context.encode()).hexdigest(),new_question_not_prior_review=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest())
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 lease.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-900:])
