import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();expected=json.loads((P/'after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize;assert free>=1073741824
 stage=P/'after-selected';stage.mkdir();fixtures=stage/'fixtures';fixtures.mkdir()
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 for name,b in [('producer.py',source),('existing-tests.py',tests)]:
  with (stage/name).open('xb') as f:f.write(b)
 new_names=['test_opaque_error_type_false_equality_is_never_called','test_opaque_error_type_lying_equality_never_implies_container','test_opaque_error_type_throwing_equality_never_masks_history','test_exact_native_nested_container_bindings_remain_deep']
 affected_names=['test_callback_list_swap_keeps_original_handles','test_command_quarantine_does_not_drop_available_data']
 with (stage/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),existing_test_sha256=hashlib.sha256(tests).hexdigest(),new_selection=new_names,affected_selection=affected_names,new_epoch_affected_callers_not_old_epoch_replay=True,not_whole_current20canonical=True),f,indent=2)
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 suite=unittest.TestSuite([tm.HistoryOpaqueTypeIdentityTests(name) for name in new_names]+[tm.FrozenCommandHistoryTests(name) for name in affected_names]);out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (stage/'tests.log').open('x') as f:f.write(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),new_selection=new_names,affected_selection=affected_names,source_sha256=hashlib.sha256(source).hexdigest(),existing_test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_runtime_admission=True)
 with (stage/'result.json').open('x') as f:json.dump(value,f,indent=2)
 old=(P/'before-producer.py').read_text();old_tests=(P/'before-existing-tests.py').read_text();newclass=(P/'new-tests.py').read_text()
 projected=source.decode().replace('            if not deep or (kind is not dict and kind is not list and kind is not tuple):return','            if kind not in (dict,list,tuple) or not deep:return')
 assert projected==old
 before_tree=ast.parse(old_tests);after_tree=ast.parse(tests.decode());after_tree.body=[x for x in after_tree.body if not(isinstance(x,ast.ClassDef) and x.name=='HistoryOpaqueTypeIdentityTests')]
 assert ast.dump(before_tree)==ast.dump(after_tree)
 assert tests.decode()==old_tests+'\n\n'+newclass
 assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in expected.items())
 beforehash=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-implementation-v1/final-hashes.json').read_text())
 unchanged=[name for name in expected if 'build_producer.py' not in name];assert len(unchanged)==21 and all(expected[name]==beforehash[name] for name in unchanged)
 with (P/'ROOT-invariants.json').open('x') as f:json.dump(dict(one_source_branch_line_only_all_other_bytes_exact=True,original_test_AST_and_bytes_unchanged=True,four_new_methods_one_helper_class=True,other18_helpers_and3_bins_byteexact=True,final23_hashes=expected,source_flag_gate_factory_publicemitter_unchanged=True,not_physical_EX_or_current20canonical=True),f,indent=2)
 lease.verify_identity();print(json.dumps({k:value[k] for k in ['tests','failures','errors','source_sha256','existing_test_sha256']}));print(out.getvalue()[-4500:])
