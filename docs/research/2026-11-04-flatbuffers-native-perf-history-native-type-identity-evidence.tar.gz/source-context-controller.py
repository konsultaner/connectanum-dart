import pathlib,json,sys,ast,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert hashlib.sha256(source.encode()).hexdigest()=='90178cb083aa4aafd0a4a2be3f7f5f514553ff69db8f5371bd8d1573cab50fff'
 assert hashlib.sha256(tests.encode()).hexdigest()=='a35e816cc38e15d0a9796960f086a3a3750c8f547e67deceda33bb8c13b4e0a7'
 owner=next(x for x in ast.parse(source).body if isinstance(x,ast.ClassDef) and x.name=='_RetainedPreflightOwner')
 names={'_capture_command_history','_freeze_command_history','freeze_command_history','_record_error','_set_error'}
 lines=source.splitlines()
 methods={x.name:'\n'.join(lines[x.lineno-1:x.end_lineno]) for x in owner.body if isinstance(x,ast.FunctionDef) and (x.name in names or 'histor' in x.name)}
 ttree=ast.parse(tests);tlines=tests.splitlines()
 classes=[dict(name=x.name,methods=[z.name for z in x.body if isinstance(z,ast.FunctionDef)]) for x in ttree.body if isinstance(x,ast.ClassDef) and ('Histor' in x.name or 'Frozen' in x.name)]
 out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),methods=methods,test_classes=classes,free_bytes=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize)
 with (P/'source-context.json').open('x') as f:json.dump(out,f,indent=2)
 for name,data in [('before-producer.py',source),('before-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(data)
 lease.verify_identity();print(json.dumps(out))
