"""OWN non-benchmark producer fixtures; never real canonical/build admission."""
from pathlib import Path
import hashlib
import base64
import json
import os
import signal
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import native_perf_build_producer as producer


def digest(data):
    return hashlib.sha256(data).hexdigest()


class ProducerTests(unittest.TestCase):
    def setUp(self):
        evidence = os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:
            Path(evidence).mkdir(exist_ok=True)
        self.base = Path(tempfile.mkdtemp(prefix='producer-', dir=evidence)).resolve()
        self.git_path=shutil.which('git')
        self.repo = self.base / 'repo'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.email', 'fixture@example.invalid')
        self.git('config', 'user.name', 'Owned Fixture')
        (self.repo / '.gitignore').write_text('inputs/\n')
        (self.repo / 'worker.py').write_text("""import os,sys,time,signal
from pathlib import Path
mode=sys.argv[1]
if mode=='sleep':
    Path(sys.argv[2]).write_text('running')
    time.sleep(0.12)
elif mode=='drift':
    Path(sys.argv[2]).write_text('changed')
    time.sleep(0.08)
    Path(sys.argv[3]).write_text('natural-exit')
elif mode=='large':
    os.write(1,b'A'*9000);os.write(2,b'B'*7000)
elif mode=='nonzero':
    print('failed-with-bytes',flush=True);sys.exit(7)
elif mode=='signal':
    print('before-signal',flush=True);os.kill(os.getpid(),signal.SIGTERM)
elif mode=='environment':
    assert os.environ['PERF_FIXTURE_SECRET']=='preserved-value'
    print('environment-preserved')
else:
    print('fixture-ok')
""")
        self.git('add', '.')
        self.git('commit', '-qm', 'tiny owned fixture')
        self.head = self.git('rev-parse', 'HEAD').decode().strip()
        self.archive_sha = digest(self.git('archive', '--format=tar', self.head))
        self.inputs = {}
        for name in ('pub', 'transport', 'bench', 'package_config'):
            path = self.repo / 'inputs' / name
            path.parent.mkdir(exist_ok=True)
            path.write_text('fixture-' + name)
            self.inputs['inputs/' + name] = digest(path.read_bytes())
        self.runs = []

    def tearDown(self):
        for run in self.runs:
            if run.pending:
                if run.finished:
                    status=run.process.wait(2)
                    run._end_command(status)
                    if run.events is not None:run.events.close();run.events=None
                    (self.base/'fixture-fallback-reaped.json').write_text(json.dumps({'pid':run.child_pid,'status':status,'scope':'OWN finite fixture teardown only; no live controller workaround'}))
                else:
                    run.wait(2)
        # Evidence deliberately remains, including failed/partial source archives.

    def git(self, *args):
        return subprocess.check_output(['git', '-C', str(self.repo), *args], stderr=subprocess.PIPE)

    def start(self, *modes, **overrides):
        kwargs = dict(repo=self.repo, source_commit=self.head, runtime_commit=self.head,
                      run_dir=self.base / 'run', expected_archive_sha256=self.archive_sha,
                      inputs=self.inputs, commands=[[sys.executable, 'worker.py', *mode] for mode in modes],
                      lease_check=lambda: None)
        kwargs.update(overrides)
        run = producer.start_fixture(**kwargs)
        self.runs.append(run)
        return run

    def finish(self, run):
        result = run.result if run.finished else None
        while result is None:result = run.wait(2)
        self.assertIsNotNone(result)
        return result

    def test_positive_exact_source_commands_and_output_bytes(self):
        run = self.start(('large',), ('ok',))
        result = self.finish(run)
        self.assertEqual('fixture-command-evidence-v1', result['kind'])
        self.assertEqual('success', result['status'])
        self.assertEqual(2, len(result['commands']))
        raw = (self.base / 'run' / 'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000, raw)
        self.assertEqual(digest(raw), result['commands'][0]['log_sha256'])
        self.assertEqual(self.archive_sha, result['source_archive_sha256'])
        self.assertFalse(result['capture_ready'])

    def test_existing_run_directory_is_terminal_before_any_command(self):
        directory=self.base/'run';directory.mkdir();(directory/'partial').write_bytes(b'keep')
        with self.assertRaises(FileExistsError): self.start(('ok',))
        self.assertEqual(['partial'], [p.name for p in directory.iterdir()])

    def test_completed_run_cannot_run_again(self):
        run=self.start(('ok',));self.finish(run)
        before={p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()}
        with self.assertRaises(producer.ProducerError):run.wait(0)
        with self.assertRaises(FileExistsError):self.start(('ok',))
        self.assertEqual(before,{p.name:p.read_bytes() for p in (self.base/'run').iterdir() if p.is_file()})

    def test_nonzero_exit_preserves_log_and_prevents_next_command(self):
        result=self.finish(self.start(('nonzero',),('ok',)))
        self.assertEqual('failed',result['status']);self.assertEqual(7,result['commands'][0]['returncode'])
        self.assertEqual(1,len(result['commands']));self.assertIn(b'failed-with-bytes',(self.base/'run'/'command-000.log').read_bytes())

    def test_negative_signal_status_is_not_success(self):
        result=self.finish(self.start(('signal',)))
        self.assertEqual(-signal.SIGTERM,result['commands'][0]['returncode']);self.assertEqual('failed',result['status'])
        self.assertIn(b'before-signal',(self.base/'run'/'command-000.log').read_bytes())

    def test_spawn_failure_retains_null_status_no_retry(self):
        run=self.start(('ok',),commands=[['/nonexistent/owned-fixture-command']])
        result=run.result
        self.assertEqual('failed',result['status']);self.assertIsNone(result['commands'][0]['returncode'])
        self.assertIn('FileNotFoundError',result['commands'][0]['spawn_error'])

    def test_timeout_only_waits_same_owned_process(self):
        run=self.start(('sleep',str(self.base/'started')))
        pid=run.child_pid;self.assertIsNone(run.wait(0));self.assertEqual(pid,run.child_pid)
        result=self.finish(run);self.assertEqual('success',result['status']);self.assertEqual(1,len(result['commands']))

    def test_input_drift_waits_for_natural_child_exit(self):
        done=self.base/'done'
        result=self.finish(self.start(('drift',str(self.repo/'inputs/pub'),str(done))))
        self.assertEqual('natural-exit',done.read_text());self.assertEqual('failed',result['status'])
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertIn('input',result['error'])

    def test_dirty_source_refused_before_command(self):
        (self.repo/'worker.py').write_text('raise SystemExit(99)')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'failure.json').is_file())

    def test_wrong_archive_refused_before_command(self):
        with self.assertRaises(producer.ProducerError):self.start(('ok',),expected_archive_sha256='0'*64)
        self.assertFalse((self.base/'run'/'command-000.log').exists())
        self.assertTrue((self.base/'run'/'source.tar').is_file())

    def test_head_drift_refused_before_command(self):
        (self.repo/'extra').write_text('new');self.git('add','.');self.git('commit','-qm','new')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_input_symlink_refused(self):
        p=self.repo/'inputs/pub';p.rename(self.repo/'inputs/old');p.symlink_to('old')
        with self.assertRaises(producer.ProducerError):self.start(('ok',))
        self.assertFalse((self.base/'run'/'command-000.log').exists())

    def test_lease_refusal_before_reservation(self):
        def refuse():raise RuntimeError('lease unavailable')
        with self.assertRaisesRegex(RuntimeError,'lease unavailable'):self.start(('ok',),lease_check=refuse)
        self.assertFalse((self.base/'run').exists())

    def test_environment_inherited_without_values_in_metadata(self):
        old=os.environ.get('PERF_FIXTURE_SECRET');os.environ['PERF_FIXTURE_SECRET']='preserved-value'
        try: result=self.finish(self.start(('environment',)))
        finally:
            if old is None:os.environ.pop('PERF_FIXTURE_SECRET')
            else:os.environ['PERF_FIXTURE_SECRET']=old
        self.assertEqual('success',result['status'])
        for p in (self.base/'run').glob('*.json*'):self.assertNotIn('preserved-value',p.read_text())

    def test_source_archive_members_match_committed_bytes(self):
        result=self.finish(self.start(('ok',)))
        self.assertEqual(self.head,result['source_commit'])
        self.assertEqual(2,result['source_entries'])
        self.assertEqual(self.git('archive','--format=tar',self.head),(self.base/'run'/'source.tar').read_bytes())

    def test_mutating_caller_input_dictionary_does_not_change_snapshot(self):
        run=self.start(('sleep',str(self.base/'started')))
        self.inputs.clear()
        self.assertEqual('success',self.finish(run)['status'])

    def test_production_factory_refuses_nonlinux_before_reservation(self):
        if sys.platform=='linux':self.skipTest('Darwin negative only')
        with self.assertRaises(producer.ProducerError):
            producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=self.inputs,lease_check=lambda:None)
        self.assertFalse((self.base/'run').exists())

    def test_postspawn_journal_error_keeps_owned_child_waitable(self):
        original_event=producer.CommandProducer._event
        original_spawn=producer.CommandProducer._spawn
        observed=[]
        def spawn(run):
            observed.append(run)
            return original_spawn(run)
        def event(run,kind,**kwargs):
            if kind=='command_spawned':raise OSError('injected post-spawn journal fault')
            return original_event(run,kind,**kwargs)
        try:
            with mock.patch.object(producer.CommandProducer,'_spawn',spawn),mock.patch.object(producer.CommandProducer,'_event',event):
                run=self.start(('sleep',str(self.base/'started')))
            self.assertTrue(run.pending)
            result=self.finish(run)
            self.assertEqual('failed',result['status'])
            self.assertIn('injected post-spawn',result['error'])
            self.assertEqual(0,result['commands'][0]['returncode'])
        finally:
            # Actual first counterexample must retain/reap its OWN finite child.
            for run in observed:
                if run not in self.runs:self.runs.append(run)

    def test_single_wait_budget_decreases_across_commands(self):
        run=self.start(('sleep',str(self.base/'one')),('sleep',str(self.base/'two')))
        original=producer.subprocess.Popen.wait;timeouts=[]
        def waiting(child,timeout=None):
            if child.args and child.args[0]==sys.executable:timeouts.append(timeout)
            return original(child,timeout=timeout)
        with mock.patch.object(producer.subprocess.Popen,'wait',waiting):self.finish(run)
        self.assertEqual(2,len(timeouts))
        self.assertLess(timeouts[1],timeouts[0])

    def test_log_hashing_does_not_load_whole_output_into_memory(self):
        run=self.start(('large',));original=Path.read_bytes
        def read(path):
            if path.name.startswith('command-') and path.suffix=='.log':raise AssertionError('whole log read forbidden')
            return original(path)
        with mock.patch.object(Path,'read_bytes',read):result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(16000,result['commands'][0]['log_bytes'])

    def test_wait_status_retained_before_uncertain_log_close(self):
        run=self.start(('ok',));original=run.log;calls=[]
        class Fault:
            def flush(self):return original.flush()
            def fileno(self):return original.fileno()
            def close(self):
                calls.append('close');original.close();raise OSError('injected ambiguous log close')
        run.log=Fault()
        with self.assertRaisesRegex(OSError,'ambiguous log close'):run.wait(2)
        self.assertEqual(0,run.records[0]['returncode'])
        self.assertEqual(['close'],calls);self.assertIsNone(run.log)
        with self.assertRaises(producer.ProducerError):run.wait(0)
        self.assertEqual(['close'],calls)

    def test_production_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer.sys,'platform','linux'),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            result=producer.start_production(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'},lease_check=lambda:None)
        self.assertEqual('fixture-placeholder',result)
        kwargs=cls.call_args.kwargs
        self.assertEqual([['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],kwargs['commands'])
        self.assertEqual({'CARGO_TARGET_DIR':str(self.base/'run/target')},kwargs['env_delta'])
        self.assertFalse((self.base/'run').exists())

    def test_canonical_recipe_factory_only_synthetic_argv_observation(self):
        inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock','.dart_tool/package_config.json')}
        with mock.patch.dict(os.environ,{},clear=True),mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            producer.start_canonical(repo=self.repo,source_commit=self.head,runtime_commit=self.head,run_dir=self.base/'run',expected_archive_sha256=self.archive_sha,inputs=inputs,tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'},lease_check=lambda:None)
        self.assertEqual([['bin/verify']],cls.call_args.kwargs['commands'])
        self.assertFalse((self.base/'run').exists())

    def make_tool(self,version='1.0',mutate=False):
        directory=self.base/'tools';directory.mkdir(exist_ok=True)
        target=self.base/'real-python3'
        body="#!/bin/sh\nprintf 'Fixture %s "+version+"\\n' \"${0##*/}\"\n"
        if mutate:body+="printf '#changed\\n' >> \"$0\"\n"
        target.write_text(body);target.chmod(0o755)
        entry=directory/'python3';entry.symlink_to(target)
        return directory,entry,target

    def test_tool_entry_basename_and_fixed_version_argv_preserved(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('success',result['status'])
        self.assertEqual([str(entry),'--version'],result['commands'][0]['argv'])
        self.assertEqual('tool_version',result['commands'][0]['kind'])
        self.assertEqual('recipe',result['commands'][1]['kind'])
        self.assertEqual(str(target),result['tools']['python3']['target'])
        self.assertEqual(b'Fixture python3 1.0\n',(self.base/'run/command-000.log').read_bytes())

    def test_tool_wrong_version_preserves_raw_and_blocks_recipe(self):
        directory,entry,target=self.make_tool(version='9.0')
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('version',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])
        self.assertIn(b'9.0',(self.base/'run/command-000.log').read_bytes())

    def test_tool_path_lookup_drift_refuses_before_any_probe(self):
        directory,entry,target=self.make_tool()
        alternative=self.base/'different';alternative.mkdir();(alternative/'python3').symlink_to(target)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            with mock.patch.dict(os.environ,{'PATH':str(alternative)+os.pathsep+os.environ['PATH']}):
                with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_symlink_retarget_even_equal_bytes_refuses(self):
        directory,entry,target=self.make_tool();other=self.base/'equal-bytes';other.write_bytes(target.read_bytes());other.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            entry.unlink();entry.symlink_to(other)
            with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_tool_mutation_during_probe_blocks_following_recipe(self):
        directory,entry,target=self.make_tool(mutate=True)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('tool',result['error'])
        self.assertEqual(1,len(result['commands']));self.assertEqual(0,result['commands'][0]['returncode'])

    def test_tool_caller_spec_mutation_does_not_change_pinned_snapshot(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0');tools={'python3':spec}
            run=self.start(('ok',),tools=tools);spec['sha256']='0'*64;tools.clear()
            result=self.finish(run)
        self.assertEqual('success',result['status'])
        self.assertEqual(hashlib.sha256(target.read_bytes()).hexdigest(),result['tools']['python3']['sha256'])

    def test_tool_unknown_name_and_empty_version_rejected(self):
        with self.assertRaises(producer.ProducerError):producer.describe_tool('untrusted-build-command','anything')
        with self.assertRaises(producer.ProducerError):producer.describe_tool('python3','')

    def test_tool_review_intent_is_durable_before_version_child(self):
        directory,entry,target=self.make_tool()
        text=target.read_text();text=text.replace('#!/bin/sh\n','#!/bin/sh\nif [ ! -s "$PRODUCER_INTENT" ]; then printf missing-intent >&2; exit 55; fi\n');target.write_text(text)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH'],'PRODUCER_INTENT':str(self.base/'run/intent.json')}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('success',result['status'])
        intent=json.loads((self.base/'run/intent.json').read_text())
        self.assertEqual({'python3':spec},intent['tools'])
        self.assertEqual(self.inputs,intent['inputs']);self.assertEqual(self.archive_sha,intent['expected_archive_sha256'])

    def test_tool_review_numeric_prefix_collision_blocks_recipe(self):
        directory,entry,target=self.make_tool(version='1.00')
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0')
            result=self.finish(self.start(('ok',),tools={'python3':spec}))
        self.assertEqual('failed',result['status']);self.assertIn('version',result['error'])
        self.assertEqual(1,len(result['commands']))

    def test_tool_review_boolean_identity_schema_rejected_before_reservation(self):
        directory,entry,target=self.make_tool()
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            spec=producer.describe_tool('python3','Fixture python3 1.0');spec['entry_uid']=False
            with self.assertRaises(producer.ProducerError):self.start(('ok',),tools={'python3':spec})
        self.assertFalse((self.base/'run').exists())

    def receipt_fixture(self,phase='canonical',dart='3.13.1',config='3.13.1'):
        real_git=self.git_path
        (self.repo/'.gitignore').write_text('inputs/\npubspec.lock\nnative/\n.dart_tool/\n')
        self.git('add','.gitignore');self.git('commit','-qm','receipt fixture ignores generated input roles')
        self.head=self.git('rev-parse','HEAD').decode().strip();self.archive_sha=digest(self.git('archive','--format=tar',self.head))
        inputs={}
        for relative in ('pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'):
            path=self.repo/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('OWN synthetic lock '+relative);inputs[relative]=digest(path.read_bytes())
        path=self.repo/'.dart_tool/package_config.json';path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps({'configVersion':2,'generator':'pub','generatorVersion':config,'packages':[{'name':'owned_fixture','rootUri':'../','packageUri':'lib/'}]}))
        inputs['.dart_tool/package_config.json']=digest(path.read_bytes())
        bindings={'server':'.dart_tool/package_config.json','client':'.dart_tool/package_config.json'}
        directory=self.base/'receipt-tools';directory.mkdir()
        versions={'dart':'Dart SDK version: '+dart+' (stable) fixture','git':'Fixture git 1','bash':'Fixture bash 1','python3':'Fixture python3 1','cargo':'Fixture cargo 1','rustc':'Fixture rustc 1'}
        for name,line in versions.items():
            path=directory/name
            path.write_text('#!/bin/sh\nif [ "$1" = "--version" ]; then printf "%s\\n" "'+line+'"; exit 0; fi\nexec "'+real_git+'" "$@"\n')
            path.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':str(directory)+os.pathsep+os.environ['PATH']}):
            tools={name:producer.describe_tool(name,'Dart SDK version: ' if name=='dart' else versions[name]) for name in versions}
            roles=['canonical_native'] if phase=='canonical' else ['native_elf','driver_elf','static_rlib']
            outputs={}
            for role in roles:
                blob=self.base/(role+'.synthetic');blob.write_bytes(('OWN synthetic '+role).encode());outputs[role]=blob
            run=self.start(('ok',),inputs=inputs,tools=tools,outputs=outputs,census_id='a'*32,expected_sdk='3.13.1',config_bindings=bindings)
            result=self.finish(run)
        return run,result,inputs,bindings

    def test_receipt_fixture_canonical_links_actual_logs_and_inputs(self):
        run,result,inputs,bindings=self.receipt_fixture()
        receipt=producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual('fixture-canonical-v1',receipt['kind']);self.assertEqual('3.13.1',receipt['sdk'])
        self.assertEqual('a'*32,receipt['census_id']);self.assertEqual(self.archive_sha,receipt['source_archive_sha256'])
        self.assertEqual({k:inputs[p] for k,p in bindings.items()},receipt['package_configs'])
        raw=b''.join((self.base/f'run/command-{i:03}.log').read_bytes() for i in range(len(result['commands'])))
        self.assertEqual(raw,(self.base/'run/complete-command.log').read_bytes());self.assertEqual(digest(raw),receipt['log_sha256'])
        self.assertTrue((self.base/'run/receipt-binding.json').is_file())

    def test_receipt_fixture_production_keeps_fixture_kind_and_output_links(self):
        run,result,_,_=self.receipt_fixture('execution');receipt=producer.emit_fixture_receipt(run,'execution')
        self.assertEqual('fixture-production-v1',receipt['kind']);self.assertEqual([],receipt['features'])
        self.assertEqual({k:v['sha256'] for k,v in result['outputs'].items()},receipt['outputs'])

    def test_receipt_live_emitter_rejects_fixture_without_publication(self):
        run,_,_,_=self.receipt_fixture()
        with self.assertRaises(producer.ProducerError):producer.emit_receipt(run)
        self.assertFalse((self.base/'run/receipt-attempt.json').exists())
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_declared_sdk_mismatch_blocks_recipe(self):
        run,result,_,_=self.receipt_fixture(dart='3.13.5')
        self.assertEqual('failed',result['status']);self.assertIn('SDK',result['error'])
        self.assertFalse(any(r['kind']=='recipe' for r in result['commands']))

    def test_receipt_config_generator_mismatch_refuses_before_child(self):
        with self.assertRaises(producer.ProducerError):self.receipt_fixture(config='3.13.5')
        self.assertFalse((self.base/'run/command-000.log').exists())

    def test_receipt_partial_publication_is_terminal_without_second_read(self):
        run,_,_,_=self.receipt_fixture();actual=producer._receipt_resource_io;attempts=[]
        def operation(resource,step,value=None):
            if resource['role']=='input_receipt' and step=='write':
                attempts.append('write');os.write(resource['fd'],b'OWN-partial');raise OSError(28,'injected ENOSPC')
            return actual(resource,step,value)
        try:
            with mock.patch.object(producer,'_receipt_resource_io',operation):
                with self.assertRaises(OSError):producer.emit_fixture_receipt(run,'canonical')
            self.assertEqual(b'OWN-partial',(self.base/'run/input-receipt.json').read_bytes())
            with mock.patch.object(producer,'_regular_hash',side_effect=AssertionError('second read forbidden')):
                with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
            self.assertEqual(['write'],attempts);self.assertFalse((self.base/'run/receipt-binding.json').exists())
        finally:
            for resource in run._receipt_resources:
                if resource['role']=='input_receipt' and not resource['close_attempted']:
                    info=os.fstat(resource['fd']);path=resource['path'].stat()
                    self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino));os.close(resource['fd'])

    def test_receipt_sealed_result_tamper_refuses(self):
        run,_,_,_=self.receipt_fixture();path=self.base/'run/result.json';path.with_suffix('.before').write_bytes(path.read_bytes());path.write_bytes(path.read_bytes()+b' ')
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertTrue((self.base/'run/receipt-attempt.json').is_file());self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_log_tamper_refuses(self):
        run,_,_,_=self.receipt_fixture();path=self.base/'run/command-000.log';path.with_suffix('.before').write_bytes(path.read_bytes());path.write_bytes(path.read_bytes()+b'changed')
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_nonce_mutation_cannot_relabel_completed_run(self):
        run,_,_,_=self.receipt_fixture();run.census_id='b'*32
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((self.base/'run/input-receipt.json').exists())

    def test_receipt_binding_dictionary_mutation_does_not_relabel_context(self):
        run,_,inputs,bindings=self.receipt_fixture();bindings.clear()
        receipt=producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual({'server':inputs['.dart_tool/package_config.json'],'client':inputs['.dart_tool/package_config.json']},receipt['package_configs'])

    def test_receipt_pending_child_cannot_be_published(self):
        run=self.start(('sleep',str(self.base/'started')))
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertTrue(run.pending);self.assertFalse((self.base/'run/receipt-attempt.json').exists())

    def test_receipt_review_mutable_retagging_stops_at_provenance_boundary(self):
        run,_,_,_=self.receipt_fixture();run.provenance='canonical_recipe'
        with self.assertRaisesRegex(producer.ProducerError,'provenance'):producer.emit_receipt(run)
        self.assertFalse((self.base/'run/receipt-attempt.json').exists())

    def package_observation(self):
        nonce='c'*32
        config=json.dumps({'configVersion':2,'generator':'pub','generatorVersion':'3.13.1','packages':[{'name':'one','rootUri':'../one/','packageUri':'lib/'},{'name':'two','rootUri':'../two/','packageUri':'lib/'}]}).encode()
        value={'kind':'dart-package-config-observation-v1','script':'file:///owned/probe.dart','sdk':'3.13.1 (stable) fixture',
               'config_uri':'file:///owned/.dart_tool/package_config.json','config_b64':base64.b64encode(config).decode(),
               'mappings':[{'name':'one','uri':'file:///owned/one/lib/'},{'name':'two','uri':None}],
               'missing_name':'__native_perf_absent_'+nonce,'missing_uri':None}
        context={'expected_sdk':'3.13.1','expected_script_uri':value['script'],'expected_config_uri':value['config_uri'],'expected_config_bytes':config,'nonce':nonce}
        return value,context

    def test_package_observation_preserves_all_mappings_and_null_without_readiness(self):
        value,context=self.package_observation();record=producer.validate_package_observation(value,**context)
        self.assertEqual((('one','file:///owned/one/lib/'),('two',None)),record['mappings'])
        self.assertEqual(2,record['package_count']);self.assertEqual(1,record['other_or_null'])
        self.assertFalse(record['capture_ready']);self.assertEqual('helper_package_config_observation_only',record['scope'])

    def test_package_observation_null_config_negative(self):
        value,context=self.package_observation();value.update(config_uri=None,config_b64=None,mappings=[]);context.update(expected_config_uri=None,expected_config_bytes=None)
        record=producer.validate_package_observation(value,**context);self.assertEqual(0,record['package_count'])
        self.assertIsNone(record['config_sha256']);self.assertFalse(record['capture_ready'])

    def test_package_observation_sdk_and_script_context_mismatch(self):
        value,context=self.package_observation()
        for key,bad in [('sdk','3.13.5 (stable) other'),('script','file:///other/probe.dart')]:
            with self.subTest(key=key):
                changed={**value,key:bad}
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation(changed,**context)

    def test_package_observation_exact_config_uri_and_bytes(self):
        value,context=self.package_observation()
        for change in [{'config_uri':'file:///different/package_config.json'},{'config_b64':base64.b64encode(context['expected_config_bytes']+b' ').decode()}]:
            with self.subTest(change=change):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,**change},**context)

    def test_package_observation_subset_or_reordering_refused(self):
        value,context=self.package_observation()
        for mappings in [value['mappings'][:1],list(reversed(value['mappings']))]:
            with self.subTest(mappings=mappings):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,'mappings':mappings},**context)

    def test_package_observation_absent_query_must_be_null(self):
        value,context=self.package_observation()
        for bad in ['file:///exists/lib/','https://example.invalid/pkg/']:
            with self.subTest(bad=bad):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation({**value,'missing_uri':bad},**context)

    def test_package_observation_nonce_replay_refused(self):
        value,context=self.package_observation();context['nonce']='d'*32
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_observation_unresolved_or_invalid_uri_refused_other_schemes_retained(self):
        value,context=self.package_observation()
        for bad in ['package:one/',False,'file:///bad/%GG']:
            changed={**value,'mappings':[{'name':'one','uri':bad},value['mappings'][1]]}
            with self.subTest(bad=bad):
                with self.assertRaises(producer.ProducerError):producer.validate_package_observation(changed,**context)
        changed={**value,'mappings':[{'name':'one','uri':'https://example.invalid/source/'},value['mappings'][1]]}
        record=producer.validate_package_observation(changed,**context);self.assertEqual(2,record['other_or_null'])
        self.assertEqual('https://example.invalid/source/',record['mappings'][0][1])

    def test_package_observation_duplicate_config_entries_refused(self):
        value,context=self.package_observation();config=json.loads(context['expected_config_bytes']);config['packages'][1]['name']='one';raw=json.dumps(config).encode();context['expected_config_bytes']=raw;value['config_b64']=base64.b64encode(raw).decode()
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_review_base64_length_refuses_before_decoder(self):
        value,context=self.package_observation();value['config_b64']+='AAAA'
        with mock.patch('base64.b64decode',side_effect=AssertionError('decoder must not receive wrong-length payload')):
            with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)

    def test_package_review_extra_authority_field_is_not_admitted(self):
        value,context=self.package_observation();value['capture_ready']=True
        with self.assertRaises(producer.ProducerError):producer.validate_package_observation(value,**context)




class CanonicalOutputPathTests(unittest.TestCase):
    """Synthetic platform/path guards; never execute a build or emit a receipt."""

    def setUp(self):
        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:Path(evidence).mkdir(exist_ok=True)
        self.base=Path(tempfile.mkdtemp(prefix='canonical-path-',dir=evidence)).resolve()
        self.repo=self.base/'repo';self.repo.mkdir()
        self.kwargs=dict(repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,
            run_dir=self.base/'run',expected_archive_sha256='b'*64,
            inputs={k:'0'*64 for k in ('pubspec.lock','native/transport/Cargo.lock',
                'native/bench/Cargo.lock','.dart_tool/package_config.json')},
            tools={k:{} for k in producer.VERSION_ARGS},census_id='a'*32,
            expected_sdk='3.13.1',config_bindings={'server':'.dart_tool/package_config.json',
                'client':'.dart_tool/package_config.json'},lease_check=lambda:None)

    def factory(self,platform='darwin',environment=None):
        with mock.patch.dict(os.environ,environment or {},clear=True),\
                mock.patch.object(producer.sys,'platform',platform),\
                mock.patch.object(producer,'CommandProducer',return_value='fixture-placeholder') as cls:
            result=producer.start_canonical(**self.kwargs)
        self.assertEqual('fixture-placeholder',result)
        self.assertFalse((self.base/'run').exists())
        return cls.call_args.kwargs

    def shell_path(self,platform):
        import re
        root=Path(__file__).resolve().parents[1]
        common=(root/'bin/common.sh').read_bytes()
        names=('native_lib_file_name','native_ffi_test_lib_path')
        functions=[]
        for name in names:
            matches=re.findall(rb'(?ms)^'+name.encode()+rb'\(\) \{\n.*?^\}',common)
            self.assertEqual(1,len(matches));functions.append(matches[0])
        script=(b'set -euo pipefail\nROOT_DIR="$1"\nfixture_platform="$2"\n'
            b'uname() { printf "%s\\n" "$fixture_platform"; }\n'+b'\n'.join(functions)+
            b'\nnative_ffi_test_lib_path\n')
        path=self.base/'selected-functions.sh';path.write_bytes(script)
        argv=['/bin/bash',str(path),str(self.repo),platform]
        result=subprocess.run(argv,capture_output=True,check=False)
        (self.base/'bash.stdout').write_bytes(result.stdout)
        (self.base/'bash.stderr').write_bytes(result.stderr)
        (self.base/'bash-result.json').write_text(json.dumps(dict(
            scope='OWN extracted path functions with SYNTHETIC uname; no build',
            argv=argv,returncode=result.returncode,both_output_eof=True,
            common_sha256=digest(common),script_sha256=digest(script))))
        self.assertEqual(0,result.returncode);self.assertEqual(b'',result.stderr)
        return Path(result.stdout.decode().strip())

    def test_darwin_factory_matches_exact_selected_shell_functions(self):
        self.assertEqual(self.shell_path('Darwin'),self.factory()['outputs']['canonical_native'])

    def test_linux_factory_matches_exact_selected_shell_functions(self):
        self.assertEqual(self.shell_path('Linux'),self.factory('linux')['outputs']['canonical_native'])

    def test_configured_own_ffi_test_path_is_accepted(self):
        expected=self.repo/'native/transport/target/ffi-test/release/libct_ffi.dylib'
        actual=self.factory(environment={'CONNECTANUM_NATIVE_LIB':str(expected)})
        self.assertEqual(expected,actual['outputs']['canonical_native'])

    def test_configured_standard_release_path_refused_before_constructor(self):
        standard=self.repo/'native/transport/target/release/libct_ffi.dylib'
        with mock.patch.dict(os.environ,{'CONNECTANUM_NATIVE_LIB':str(standard)},clear=True),\
                mock.patch.object(producer.sys,'platform','darwin'),\
                mock.patch.object(producer,'CommandProducer') as cls:
            with self.assertRaises(producer.ProducerError):
                producer.start_canonical(**self.kwargs)
        cls.assert_not_called();self.assertFalse((self.base/'run').exists())

    def test_ci_artifact_override_refused_before_constructor(self):
        with mock.patch.dict(os.environ,{'CONNECTANUM_CI_NATIVE_DIR':'retained-artifacts'},clear=True),\
                mock.patch.object(producer,'CommandProducer') as cls:
            with self.assertRaises(producer.ProducerError):
                producer.start_canonical(**self.kwargs)
        cls.assert_not_called();self.assertFalse((self.base/'run').exists())

    def test_empty_ci_override_preserves_fixed_recipe(self):
        for environment in ({},{'CONNECTANUM_CI_NATIVE_DIR':''}):
            with self.subTest(environment=environment):
                actual=self.factory(environment=environment)
                self.assertEqual([['bin/verify']],actual['commands'])
                self.assertEqual('canonical_recipe',actual['provenance'])



class OwnedOutputLocationTests(unittest.TestCase):
    """Pure location predicates only; do not produce/adopt live evidence."""

    def setUp(self):
        from types import SimpleNamespace
        evidence=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        if evidence:Path(evidence).mkdir(exist_ok=True)
        self.base=Path(tempfile.mkdtemp(prefix='output-location-',dir=evidence)).resolve()
        self.run=SimpleNamespace(repo=self.base/'repo',directory=self.base/'run')

    def test_canonical_ffi_test_locations_for_two_synthetic_platforms(self):
        for platform,filename in (('darwin','libct_ffi.dylib'),('linux','libct_ffi.so')):
            with self.subTest(platform=platform),mock.patch.object(producer.sys,'platform',platform):
                path=self.run.repo/'native/transport/target/ffi-test/release'/filename
                producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)
        self.assertFalse(self.run.directory.exists())

    def test_canonical_rejects_standard_release_and_foreign_output(self):
        with mock.patch.object(producer.sys,'platform','darwin'):
            for path in (self.run.repo/'native/transport/target/release/libct_ffi.dylib',
                    self.base/'foreign/native/transport/target/ffi-test/release/libct_ffi.dylib'):
                with self.subTest(path=str(path)),self.assertRaises(producer.ProducerError):
                    producer._validate_owned_output_path(self.run,'canonical','canonical_native',path)

    def test_three_production_locations_preserved(self):
        for role,suffix in (('native_elf','libct_ffi.so'),('driver_elf','http_stream'),
                ('static_rlib','deps/libct_core-Ab09_.rlib')):
            with self.subTest(role=role):
                producer._validate_owned_output_path(self.run,'execution',role,
                    self.run.directory/'target/release'/suffix)

    def test_production_rejects_wrong_targets_and_rlib_names(self):
        cases=(('native_elf',self.run.repo/'native/transport/target/release/libct_ffi.so'),
            ('driver_elf',self.base/'foreign/target/release/http_stream'),
            ('static_rlib',self.run.directory/'target/release/deps/libct_core-.rlib'),
            ('static_rlib',self.run.directory/'target/release/deps/libct_core-x.y.rlib'),
            ('static_rlib',self.run.directory/'target/release/libct_core-Ab09.rlib'))
        for role,path in cases:
            with self.subTest(role=role,path=str(path)),self.assertRaises(producer.ProducerError):
                producer._validate_owned_output_path(self.run,'execution',role,path)

    def test_phase_and_role_mismatches_refused(self):
        for phase,role in (('canonical','native_elf'),('execution','canonical_native'),
                ('unknown','driver_elf'),('execution','unknown')):
            with self.subTest(phase=phase,role=role),self.assertRaises(producer.ProducerError):
                producer._validate_owned_output_path(self.run,phase,role,
                    self.run.directory/'target/release/http_stream')



class OwnedPreflightTests(unittest.TestCase):
    """Retained phase workers over OWN finite fixtures; no live admission."""
    git=ProducerTests.git

    def setUp(self):
        import threading
        ProducerTests.setUp(self)
        self.owners=[];self.releases=[];self.threading=threading;self.sequence=0

    def tearDown(self):
        for event in self.releases:event.set()
        for owner in self.owners:
            view=owner.observe(2)
            if view['initialized'] and not view['failed'] and not view['producer_finished']:
                self.drive(owner)
            owner.observe(2)
        ProducerTests.tearDown(self)

    def arguments(self,lease_check=lambda:None):
        return dict(repo=self.repo,source_commit=self.head,runtime_commit=self.head,
            run_dir=self.base/('run-'+str(self.sequence)),expected_archive_sha256=self.archive_sha,
            inputs=self.inputs,commands=[[sys.executable,'worker.py','ok']],lease_check=lease_check)

    def start_owned(self,lease_check=lambda:None):
        self.sequence+=1
        nonce=digest((str(self.base)+str(self.sequence)).encode())[:32]
        owner=producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments(lease_check))
        self.owners.append(owner)
        return owner

    def drive(self,owner):
        for _ in range(100):
            view=owner.observe(1)
            if not view['call_done']:continue
            self.assertFalse(view['failed'],view)
            if view['producer_finished'] and not view['producer_pending']:return view
            owner.continue_wait(.2)
        self.fail('OWN finite worker did not complete within declared fixture observations')

    def blocked_lease(self,raise_after=False):
        entered=self.threading.Event();release=self.threading.Event();self.releases.append(release)
        def check():
            entered.set();release.wait()
            if raise_after:raise RuntimeError('synthetic early lease failure')
        return check,entered,release

    def test_early_lease_failure_retains_uninitialized_exact_operation(self):
        def check():raise RuntimeError('synthetic lease failure before IO')
        owner=self.start_owned(check);view=owner.observe(2)
        self.assertEqual('raised',view['call_state']);self.assertTrue(view['failed'])
        self.assertTrue(view['retained_operation']);self.assertFalse(view['initialized'])
        self.assertIsNone(view['producer_pending']);self.assertIsNone(view['actor_ownership_complete'])
        self.assertFalse(owner._operation.__dict__.get('pending',False))
        self.assertNotIn('pending',owner._operation.__dict__)
        self.assertFalse((self.base/'run-1').exists())

    def test_blocked_constructor_observation_and_overlap_refusal(self):
        check,entered,release=self.blocked_lease()
        owner=self.start_owned(check)
        try:
            self.assertTrue(entered.wait(2))
            view=owner.observe(0)
            self.assertFalse(view['call_done']);self.assertTrue(view['retained_operation'])
            self.assertFalse(view['initialized']);self.assertFalse(owner._thread.daemon)
            self.assertNotIn('pending',owner._operation.__dict__)
            with self.assertRaises(TypeError):view['call_done']=True
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
            with self.assertRaises(producer.ProducerError):owner.emit('canonical')
        finally:release.set()
        self.drive(owner)

    def test_postspawn_primary_failure_keeps_same_known_child_until_natural_exit(self):
        original=producer.CommandProducer._event;observed=[]
        def event(run,kind,**kwargs):
            if kind=='command_spawned':
                observed.append(run.process)
                raise OSError('synthetic postspawn publication failure')
            return original(run,kind,**kwargs)
        with mock.patch.object(producer.CommandProducer,'_event',event):
            owner=self.start_owned();owner.observe(2)
        self.assertTrue(observed);child=observed[0]
        self.assertIs(child,owner._operation.process)
        self.drive(owner);run=owner._operation
        self.assertEqual(child.pid,run.result['commands'][0]['pid'])
        self.assertEqual(0,child.returncode)
        self.assertEqual('failed',run.result['status'])
        self.assertEqual(0,run.result['commands'][0]['returncode'])
        self.assertTrue(run.result['commands'][0]['output_eof'])
        self.assertIsNone(owner.observe(0)['actor_ownership_complete'])

    def test_actual_thread_start_then_error_retains_slot_without_restart(self):
        check,entered,release=self.blocked_lease(raise_after=True)
        original=self.threading.Thread.start;calls=[]
        def start(thread):
            calls.append(thread);original(thread)
            self.assertTrue(entered.wait(2))
            raise RuntimeError('synthetic launch return uncertainty after actual thread start')
        with mock.patch.object(self.threading.Thread,'start',start):
            owner=self.start_owned(check)
        try:
            view=owner.observe(0)
            self.assertTrue(view['retained_operation']);self.assertTrue(view['failed'])
            self.assertFalse(view['call_done']);self.assertEqual('start_uncertain',view['call_state'])
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        finally:release.set()
        view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed']);self.assertEqual(1,len(calls))
        self.assertIs(calls[0],owner._thread);self.assertFalse(owner._thread.is_alive())
        self.assertFalse((self.base/'run-1').exists())

    def test_caller_mutation_does_not_change_frozen_commands_or_inputs(self):
        check,entered,release=self.blocked_lease()
        self.sequence+=1;kwargs=self.arguments(check)
        nonce=digest((str(self.base)+'copy').encode())[:32]
        owner=producer.start_owned_preflight('fixture',owner_id=nonce,**kwargs);self.owners.append(owner)
        try:
            self.assertTrue(entered.wait(2))
            kwargs['commands'][0][-1]='nonzero';kwargs['inputs'].clear()
            self.assertIs(check,owner._kwargs['lease_check'])
        finally:release.set()
        self.drive(owner)
        self.assertEqual('success',owner._operation.result['status'])
        self.assertEqual('ok',owner._operation.result['commands'][0]['argv'][-1])

    def test_emit_attempt_is_terminal_and_keeps_first_error(self):
        owner=self.start_owned();self.drive(owner)
        owner.emit('canonical');view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed']);self.assertTrue(view['owner_emit_attempted'])
        first=view['first_error'];self.assertTrue(first)
        with self.assertRaises(producer.ProducerError):owner.emit('canonical')
        self.assertEqual(first,owner.observe(0)['first_error'])
        self.assertTrue((self.base/'run-1/receipt-attempt.json').exists())

    def test_invalid_wait_values_and_forged_entry_hook_refuse(self):
        owner=self.start_owned();owner.observe(2)
        for value in (True,float('nan'),float('inf'),-1,61,'0'):
            with self.subTest(value=repr(value)),self.assertRaises(producer.ProducerError):
                owner.observe(value)
            with self.subTest(wait_value=repr(value)),self.assertRaises(producer.ProducerError):
                owner.continue_wait(value)
        called=[]
        with self.assertRaises(producer.ProducerError):
            producer.CommandProducer(**self.arguments(lambda:called.append(True)),
                provenance='fixture',_preflight_owner=object())
        self.assertEqual([],called)
        with self.assertRaises(producer.ProducerError):
            producer.start_owned_preflight('fixture',owner_id='c'*32,
                **self.arguments(),_preflight_owner=object())
        self.drive(owner)

    def test_duplicate_owner_id_is_permanently_retained(self):
        owner=self.start_owned(lambda:(_ for _ in ()).throw(RuntimeError('synthetic refusal')))
        owner.observe(2);nonce=owner.observe(0)['owner_id']
        with self.assertRaises(producer.ProducerError):
            producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments())
        self.assertIs(owner,producer._PREFLIGHT_OWNERS[nonce])


    def test_exception_representation_is_not_executed_by_observer_publication(self):
        called=[]
        class Error(RuntimeError):
            def __repr__(self):
                called.append(True)
                return 'synthetic dynamic representation'
        def check():raise Error('retained actual exception')
        owner=self.start_owned(check);view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertTrue(view['failed'])
        self.assertEqual([],called)


    def test_registry_capacity_refuses_new_attempt_without_discarding_owners(self):
        nonce=digest((str(self.base)+'capacity').encode())[:32];rejected=False;owner=None
        with mock.patch.object(producer,'_PREFLIGHT_OWNER_LIMIT',0,create=True):
            try:
                owner=producer.start_owned_preflight('fixture',owner_id=nonce,
                    **self.arguments(lambda:(_ for _ in ()).throw(RuntimeError('synthetic capacity before failure'))))
            except producer.ProducerError:rejected=True
        if owner is not None:self.owners.append(owner);owner.observe(2)
        self.assertTrue(rejected)
        self.assertNotIn(nonce,producer._PREFLIGHT_OWNERS)

    def test_thread_object_setup_failure_retains_returned_quarantine(self):
        nonce=digest((str(self.base)+'thread-setup').encode())[:32];caught=None;owner=None
        with mock.patch.object(self.threading,'Thread',side_effect=OSError('synthetic thread object allocation failure')):
            try:owner=producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments())
            except OSError as error:caught=error;owner=producer._PREFLIGHT_OWNERS[nonce]
        self.owners.append(owner)
        self.assertIsNone(caught)
        view=owner.observe(0);self.assertTrue(view['failed']);self.assertFalse(view['call_done'])
        self.assertEqual('start_uncertain',view['call_state']);self.assertIsNone(owner._thread)
        self.assertFalse(view['retained_operation'])
        with self.assertRaises(producer.ProducerError):owner.continue_wait(0)





class PreflightEmissionDispatchTests(unittest.TestCase):
    """Mocked factory/emitter interfaces; actual producer provenance stays fixture."""
    git=ProducerTests.git
    setUp=OwnedPreflightTests.setUp
    tearDown=OwnedPreflightTests.tearDown
    arguments=OwnedPreflightTests.arguments
    drive=OwnedPreflightTests.drive

    def constructed(self,kind):
        self.sequence+=1
        nonce=digest((str(self.base)+kind+str(self.sequence)).encode())[:32]
        # Only the selected factory interface is replaced. Never retag the
        # actual fixture producer or publish an own-canonical/production receipt.
        def fixture_factory(**kwargs):return producer.start_fixture(**kwargs)
        factory='start_canonical' if kind=='canonical' else 'start_production'
        if kind=='fixture':
            owner=producer.start_owned_preflight(kind,owner_id=nonce,**self.arguments())
            self.owners.append(owner);self.drive(owner)
        else:
            with mock.patch.object(producer,factory,fixture_factory):
                owner=producer.start_owned_preflight(kind,owner_id=nonce,**self.arguments())
                self.owners.append(owner);self.drive(owner)
        self.assertEqual('fixture',owner._operation.provenance)
        return owner

    def one_argument_boundary(self,kind,phase):
        owner=self.constructed(kind);calls=[]
        def emit(run):
            calls.append(run)
            return {'kind':'fixture-interface-only','capture_ready':False}
        with mock.patch.object(producer,'emit_receipt',autospec=True,side_effect=emit):
            owner.emit(phase);view=owner.observe(2)
        if view['failed']:
            (self.base/'dispatch-error.json').write_text(json.dumps({
                'type':type(owner._first_error_object).__name__,
                'message':str(owner._first_error_object),
                'scope':'MOCKED factory/emitter call boundary only'}))
        self.assertTrue(view['call_done']);self.assertFalse(view['failed'],view)
        self.assertEqual([owner._operation],calls)
        self.assertEqual('fixture-interface-only',owner._last_result['kind'])
        self.assertFalse(view['capture_ready']);self.assertFalse(view['source_admitted'])
        self.assertFalse((self.base/'run-1/input-receipt.json').exists())

    def mismatch(self,kind,phase):
        owner=self.constructed(kind);before=dict(owner.observe(0));calls=[]
        def emit(run):
            calls.append(run)
            return {'kind':'fixture-interface-only','capture_ready':False}
        with mock.patch.object(producer,'emit_receipt',autospec=True,side_effect=emit):
            try:
                with self.assertRaises(producer.ProducerError):owner.emit(phase)
            finally:owner.observe(2)
        after=dict(owner.observe(0))
        self.assertEqual(before,after);self.assertFalse(after['owner_emit_attempted'])
        self.assertEqual([],calls)
        self.assertFalse((self.base/'run-1/input-receipt.json').exists())

    def test_canonical_owned_branch_calls_one_argument_emitter(self):
        self.one_argument_boundary('canonical','canonical')

    def test_production_owned_branch_calls_one_argument_emitter(self):
        self.one_argument_boundary('production','execution')

    def test_canonical_wrong_phase_refused_before_owner_attempt(self):
        self.mismatch('canonical','execution')

    def test_production_wrong_phase_refused_before_owner_attempt(self):
        self.mismatch('production','canonical')

    def test_fixture_owned_branch_keeps_two_argument_emitter(self):
        owner=self.constructed('fixture');calls=[]
        def emit(run,phase):
            calls.append((run,phase))
            return {'kind':'fixture-interface-only','capture_ready':False}
        with mock.patch.object(producer,'emit_fixture_receipt',autospec=True,side_effect=emit):
            owner.emit('canonical');view=owner.observe(2)
        self.assertTrue(view['call_done']);self.assertFalse(view['failed'])
        self.assertEqual([(owner._operation,'canonical')],calls)
        self.assertEqual('fixture',owner._operation.provenance)
        self.assertFalse(view['live_admission'])
        self.assertFalse((self.base/'run-1/input-receipt.json').exists())


class PreflightWorkerJoinTests(unittest.TestCase):
    """Exact OWN finite Thread joins; call completion is not actor admission."""
    git=ProducerTests.git
    setUp=OwnedPreflightTests.setUp
    arguments=OwnedPreflightTests.arguments
    start_owned=OwnedPreflightTests.start_owned
    blocked_lease=OwnedPreflightTests.blocked_lease

    def drive(self,owner):
        for _ in range(100):
            view=owner.observe(1)
            if not view['call_done'] or not view.get('worker_joined',True):continue
            self.assertFalse(view['failed'],view)
            if view['producer_finished'] and not view['producer_pending']:return view
            owner.continue_wait(.2)
        self.fail('OWN finite phase did not complete within fixture observations')

    def tearDown(self):
        for event in self.releases:event.set()
        cleanup=[]
        for thread in getattr(self,'held_threads',[]):
            if thread.ident is not None:
                thread.join(5);self.assertFalse(thread.is_alive())
                cleanup.append({'ident':thread.ident,'joined':True,'scope':'known OWN fixture Thread only'})
        for owner in self.owners:
            view=owner.observe(2)
            if view['initialized'] and not view['failed'] and not view['producer_finished']:
                self.drive(owner)
            owner.observe(2)
        (self.base/'worker-cleanup.json').write_text(json.dumps(cleanup))
        ProducerTests.tearDown(self)

    def tail_owner(self):
        entered=self.threading.Event();release=self.threading.Event()
        self.releases.append(release);self.held_threads=[]
        original=producer._RetainedPreflightOwner._work
        def work(owner,*args):
            original(owner,*args)
            if args[0]=='construct':
                entered.set();release.wait(5)
        patcher=mock.patch.object(producer._RetainedPreflightOwner,'_work',work)
        patcher.start();self.addCleanup(patcher.stop)
        owner=self.start_owned();thread=owner._thread;self.held_threads.append(thread)
        self.assertTrue(entered.wait(3))
        return owner,thread,release

    def test_call_return_cannot_replace_unjoined_actual_thread(self):
        owner,thread,release=self.tail_owner()
        view=owner.observe(0)
        self.assertTrue(view['call_done']);self.assertTrue(thread.is_alive())
        try:
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        finally:
            if owner._thread is not thread:self.held_threads.append(owner._thread)
            release.set()
        self.assertIs(thread,owner._thread)

    def test_lifecycle_is_immutable_and_join_confirmation_is_separate(self):
        owner,thread,release=self.tail_owner()
        partial=owner.observe(0);history=owner.worker_lifecycle()
        self.assertTrue(partial['call_done']);self.assertFalse(partial['worker_joined'])
        self.assertFalse(partial['all_workers_joined'])
        self.assertEqual(1,len(history));self.assertTrue(history[0]['worker_entered'])
        self.assertTrue(history[0]['call_done']);self.assertFalse(history[0]['worker_joined'])
        with self.assertRaises(TypeError):history[0]['worker_joined']=True
        release.set();done=owner.observe(2)
        self.assertTrue(done['worker_joined']);self.assertTrue(done['all_workers_joined'])
        self.assertFalse(history[0]['worker_joined'])
        self.assertIsNone(done['actor_ownership_complete'])
        self.assertFalse(done['capture_ready']);self.assertFalse(done['source_admitted']);self.assertFalse(done['live_admission'])

    def test_join_error_keeps_same_handle_and_first_producer_error(self):
        check,entered,release=self.blocked_lease(raise_after=True)
        owner=self.start_owned(check);self.assertTrue(entered.wait(3))
        thread=owner._thread;self.held_threads=[thread]
        real_join=thread.join;fault=OSError(5,'OWN synthetic join observation error');calls=[]
        def join(timeout=None):
            unlocked=owner._lock.acquire(blocking=False)
            self.assertTrue(unlocked,'join must run outside observer lock')
            if unlocked:owner._lock.release()
            calls.append(timeout)
            if len(calls)==1:raise fault
            return real_join(timeout)
        release.set()
        with mock.patch.object(thread,'join',side_effect=join):
            partial=owner.observe(2)
            self.assertTrue(partial['failed']);self.assertTrue(partial['call_done'])
            self.assertFalse(partial['worker_joined'])
            self.assertEqual('RuntimeError',partial['first_error'])
            self.assertEqual('OSError',owner.worker_lifecycle()[0]['join_error'])
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
            done=owner.observe(2)
        self.assertGreaterEqual(len(calls),2);self.assertTrue(done['worker_joined'])
        self.assertEqual('RuntimeError',done['first_error'])
        self.assertEqual('OSError',owner.worker_lifecycle()[0]['join_error'])
        self.assertIs(thread,owner._thread)

    def test_uncertain_start_keeps_unjoined_actual_handle(self):
        with mock.patch.object(self.threading.Thread,'start',side_effect=OSError(5,'OWN start uncertainty')):
            owner=self.start_owned()
        thread=owner._thread;self.assertIsNotNone(thread);self.assertIsNone(thread.ident)
        view=owner.observe(0);history=owner.worker_lifecycle()
        self.assertFalse(view['call_done']);self.assertFalse(view['worker_joined'])
        self.assertTrue(history[0]['thread_created']);self.assertTrue(history[0]['start_attempted'])
        self.assertFalse(history[0]['start_returned']);self.assertFalse(history[0]['worker_joined'])
        with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        self.assertIs(thread,owner._thread)

    def test_all_phase_records_require_join_and_keep_order(self):
        owner=self.start_owned();view=self.drive(owner)
        before=owner.worker_lifecycle()
        def emit(run,phase):return {'kind':'fixture-interface-only','capture_ready':False}
        with mock.patch.object(producer,'emit_fixture_receipt',autospec=True,side_effect=emit):
            owner.emit('canonical');view=owner.observe(2)
        history=owner.worker_lifecycle()
        self.assertEqual(list(range(1,len(history)+1)),[v['call_index'] for v in history])
        self.assertEqual('construct',history[0]['action']);self.assertEqual('emit',history[-1]['action'])
        self.assertTrue(all(v['call_done'] and v['worker_joined'] for v in history))
        self.assertEqual(len(before)+1,len(history));self.assertTrue(view['all_workers_joined'])
        self.assertIsNone(view['actor_ownership_complete']);self.assertFalse(view['live_admission'])


    def test_joined_worker_does_not_settle_parent_start_outcome(self):
        start_return=self.threading.Event();release=self.threading.Event()
        self.releases.append(release);self.held_threads=[]
        real_start=self.threading.Thread.start;results=[];errors=[]
        nonce=digest((str(self.base)+'start-outcome').encode())[:32]
        self.sequence+=1
        def start(thread):
            real_start(thread)
            start_return.set();release.wait(5)
        def call():
            try:
                with mock.patch.object(self.threading.Thread,'start',start):
                    results.append(producer.start_owned_preflight('fixture',owner_id=nonce,**self.arguments()))
            except BaseException as error:errors.append(error)
        caller=self.threading.Thread(target=call,daemon=False)
        self.held_threads.append(caller);caller.start()
        try:
            self.assertTrue(start_return.wait(3))
            owner=producer._PREFLIGHT_OWNERS[nonce];self.owners.append(owner)
            self.held_threads.append(owner._thread)
            view=owner.observe(2)
            self.assertTrue(view['call_done']);self.assertTrue(view['worker_joined'])
            self.assertFalse(view['worker_start_settled'])
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        finally:
            release.set();caller.join(5);self.assertFalse(caller.is_alive())
        self.assertEqual([],errors);self.assertEqual([owner],results)
        self.assertTrue(owner.observe(0)['worker_start_settled'])


class PartialAuxiliaryContinuationTests(unittest.TestCase):
    """Fresh finite OWN auxiliary fixtures; no live preparation admission."""
    def setUp(self):
        import tempfile,threading,time
        self.threading=threading;self.time=time
        root=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        self.base=Path(tempfile.mkdtemp(prefix='partial-aux-',dir=root)).resolve(strict=True)
        self.repo=self.base/'repo';self.repo.mkdir()
        self.owners=[];self.known=[];self.gates=[];self.events=[];self.parents=[];self.sequence=0
        self.owner_registered=threading.Event()
        self.actual_wait=producer.AuxiliaryCommand.wait

    def call_done(self,owner):
        for _ in range(30):
            view=owner.observe(1)
            if view['call_done'] and view['worker_joined'] and view['worker_start_settled']:return view
        self.fail('OWN worker call did not finish within fixture observations')

    def record(self,label,owner):
        value=dict(view=dict(owner.observe(0)),workers=[dict(x) for x in owner.worker_lifecycle()])
        if hasattr(owner,'auxiliary_observations'):
            value['auxiliary']=[dict(x) for x in owner.auxiliary_observations()]
        with (self.base/(label+'.json')).open('x') as f:json.dump(value,f,indent=2)
        return value

    def release(self,path):
        if not path.exists():
            with path.open('x') as f:f.write('OWN finite fixture release; not GO\n')

    def start_partial(self):
        self.sequence+=1
        ready=self.base/('ready-'+str(self.sequence));release=self.base/('release-'+str(self.sequence))
        self.gates.append(release)
        code=("import os,sys,time\nfrom pathlib import Path\n"
            "ready,release=map(Path,sys.argv[1:])\n"
            "os.write(1,b'OWN-out-before\\n');os.write(2,b'OWN-err-before\\n');ready.write_text('ready')\n"
            "end=time.monotonic()+10\n"
            "while not release.exists() and time.monotonic()<end:time.sleep(.005)\n"
            "os.write(1,b'OWN-out-after\\n');os.write(2,b'OWN-err-after\\n')\n"
            "raise SystemExit(0 if release.exists() else 78)\n")
        argv=[sys.executable,'-c',code,str(ready),str(release)]
        original=self.actual_wait;fault=OSError(5,'OWN constructor auxiliary escape');raised=[]
        def guard(operation,observe=None):
            self.assertIsNone(observe)
            return producer._observe_auxiliary(operation,'own-probe',argv,stdout_max=65536)
        def wait(auxiliary,timeout):
            if not raised:
                self.known.append(auxiliary);raised.append(True);raise fault
            return original(auxiliary,timeout)
        nonce=digest((str(self.base)+str(self.sequence)).encode())[:32]
        patches=[mock.patch.object(producer.CommandProducer,'_source_guard',guard),
            mock.patch.object(producer.AuxiliaryCommand,'wait',wait)]
        for patch in patches:patch.start()
        owner=None
        try:
            owner=producer.start_owned_preflight('fixture',owner_id=nonce,repo=self.repo,
                source_commit='a'*40,runtime_commit='a'*40,
                run_dir=self.base/('run-'+str(self.sequence)),expected_archive_sha256='0'*64,
                inputs={'never-read.fixture':'0'*64},commands=[[sys.executable,'-c','raise SystemExit(99)']],
                lease_check=lambda:None)
            self.owners.append(owner);self.owner_registered.set();self.call_done(owner)
        finally:
            if owner is not None:self.call_done(owner)
            for patch in reversed(patches):patch.stop()
        end=self.time.monotonic()+3
        while not ready.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(ready.exists())
        auxiliary=owner._operation.auxiliary_operations[0]
        self.assertIs(auxiliary,self.known[-1]);self.assertIs(owner._first_error_object,fault)
        self.assertIsNone(auxiliary.process.poll())
        self.record('created-'+str(self.sequence),owner)
        return owner,auxiliary,release,fault

    def advance(self,owner,timeout=0):
        owner.continue_auxiliary_wait(0,timeout);view=self.call_done(owner)
        return view,owner.auxiliary_observations()[0]

    def complete(self,owner,release):
        self.release(release)
        for _ in range(30):
            view,row=self.advance(owner,1)
            if row['terminal_result_observed']:return view,row
        self.fail('OWN auxiliary did not finish within fixture observations')

    def tearDown(self):
        for event in self.events:event.set()
        for path in self.gates:self.release(path)
        for thread in self.parents:
            thread.join(5);self.assertFalse(thread.is_alive())
        for owner in self.owners:self.call_done(owner)
        actors=[]
        for auxiliary in self.known:
            used_direct=False;result=auxiliary.result
            while result is None:
                used_direct=True;result=self.actual_wait(auxiliary,1)
            actors.append(dict(pid=auxiliary.process.pid,status=auxiliary.process.returncode,
                stdout_eof=result['outputs']['stdout']['eof'],stderr_eof=result['outputs']['stderr']['eof'],
                fixture_only_direct_teardown_wait=used_direct))
        with (self.base/'known-actors.json').open('x') as f:json.dump(actors,f,indent=2)
        for row in actors:
            self.assertEqual(0,row['status']);self.assertTrue(row['stdout_eof']);self.assertTrue(row['stderr_eof'])

    def test_pending_then_same_auxiliary_natural_completion(self):
        owner,auxiliary,release,fault=self.start_partial();calls=[];root_thread=self.threading.current_thread()
        real=self.actual_wait
        def wait(selected,timeout):
            self.assertIsNot(self.threading.current_thread(),root_thread)
            calls.append(selected);return real(selected,timeout)
        with mock.patch.object(producer.AuxiliaryCommand,'wait',wait):
            view,row=self.advance(owner)
            self.record('pending',owner)
            self.assertTrue(row['pending']);self.assertFalse(row['finished'])
            self.assertIsNone(row['direct_status']);self.assertFalse(row['terminal_result_observed'])
            with self.assertRaises(TypeError):row['pending']=False
            view,row=self.complete(owner,release)
        self.assertTrue(calls);self.assertTrue(all(x is auxiliary for x in calls))
        self.assertEqual(auxiliary.process.pid,row['pid']);self.assertEqual(0,row['direct_status'])
        self.assertTrue(row['stdout_eof']);self.assertTrue(row['stderr_eof'])
        self.assertFalse(view['initialized']);self.assertTrue(view['failed'])
        self.assertIs(owner._first_error_object,fault);self.assertIsNone(view['actor_ownership_complete'])
        for key in ('capture_ready','source_admitted','live_admission'):self.assertFalse(view[key])
        self.record('completed',owner)

    def test_terminal_repeat_refuses_before_new_worker(self):
        owner,auxiliary,release,fault=self.start_partial()
        self.advance(owner);self.complete(owner,release);before=dict(owner.observe(0))
        with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=AssertionError('terminal wait repeated')):
            with self.assertRaises(producer.ProducerError):owner.continue_auxiliary_wait(0,0)
        self.assertEqual(before,dict(owner.observe(0)));self.record('terminal-refusal',owner)

    def test_ledger_replacement_quarantines_before_wait(self):
        owner,auxiliary,release,fault=self.start_partial();self.advance(owner)
        owner._operation.auxiliary_operations[0]=object.__new__(producer.AuxiliaryCommand)
        with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=AssertionError('drift reached IO')):
            owner.continue_auxiliary_wait(0,0);view=self.call_done(owner)
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
        self.assertIs(owner._first_error_object,fault);self.assertFalse(view['auxiliary_ledger_check_matched'])
        before=dict(view)
        with self.assertRaises(producer.ProducerError):owner.continue_auxiliary_wait(0,0)
        self.assertEqual(before,dict(owner.observe(0)));self.record('drift-refusal',owner)

    def test_recipe_or_missing_fields_refuse_without_auxiliary_IO(self):
        for mode in ('missing','recipe'):
            owner,auxiliary,release,fault=self.start_partial()
            if mode=='missing':owner._operation.__dict__.pop('pending')
            else:owner._operation.pending=True;owner._operation.process=auxiliary.process
            with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=AssertionError('unknown recipe reached IO')):
                owner.continue_auxiliary_wait(0,0);view=self.call_done(owner)
            self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertEqual((),owner.auxiliary_observations())
            self.assertIs(owner._first_error_object,fault);self.assertIsNone(view['actor_ownership_complete'])
            self.record(mode+'-refusal',owner)

    def test_invalid_arguments_do_not_schedule(self):
        owner,auxiliary,release,fault=self.start_partial();before=dict(owner.observe(0))
        for index,timeout in ((True,0),(False,0),(-1,0),(1.0,0),(0,True),(0,-1),(0,61),(0,float('nan'))):
            with self.subTest(index=index,timeout=timeout),self.assertRaises(producer.ProducerError):
                owner.continue_auxiliary_wait(index,timeout)
        self.assertEqual(before,dict(owner.observe(0)));self.record('invalid-arguments',owner)

    def test_new_wait_error_preserves_constructor_primary_and_handle(self):
        owner,auxiliary,release,fault=self.start_partial();self.advance(owner)
        second=RuntimeError('OWN later auxiliary wait escape')
        with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=second):
            owner.continue_auxiliary_wait(0,0);self.call_done(owner)
        self.assertIs(owner._first_error_object,fault)
        self.assertIs(owner._workers[-1]['_call_error_object'],second)
        self.assertEqual('RuntimeError',owner.worker_lifecycle()[-1]['call_error'])
        self.assertIs(owner._partial_auxiliaries[0],auxiliary)
        self.record('later-error',owner)
        self.complete(owner,release);self.assertIs(owner._partial_auxiliaries[0],auxiliary)

    def test_previous_target_tail_blocks_partial_wait(self):
        entered=self.threading.Event();release_tail=self.threading.Event();self.events.append(release_tail)
        original=producer._RetainedPreflightOwner._work
        def work(owner,*args):
            original(owner,*args)
            if args[0]=='construct':entered.set();release_tail.wait(5)
        # Construct directly here: start_partial intentionally joins its worker.
        with mock.patch.object(producer._RetainedPreflightOwner,'_work',work):
            # The tail is held after the constructor call has returned.
            # Run fixture setup in a known parent, retaining it through the tail release.
            result=[];errors=[]
            def create():
                try:result.append(self.start_partial())
                except BaseException as error:errors.append(error)
            thread=self.threading.Thread(target=create,daemon=False);self.parents.append(thread);thread.start()
            try:
                self.assertTrue(entered.wait(3));self.assertTrue(self.owner_registered.wait(3))
                owner=self.owners[0];view=owner.observe(0)
                self.assertTrue(view['call_done']);self.assertFalse(view['worker_joined'])
                with self.assertRaises(producer.ProducerError):owner.continue_auxiliary_wait(0,0)
            finally:
                release_tail.set();thread.join(5);self.assertFalse(thread.is_alive())
            self.assertEqual([],errors)
        self.record('tail-overlap-refused',owner)

    def test_nonselected_drift_after_wait_keeps_actual_raw_result(self):
        owner,auxiliary,release,fault=self.start_partial()
        owner._operation.auxiliary_operations.append(object.__new__(producer.AuxiliaryCommand))
        self.advance(owner);self.release(release);real=self.actual_wait
        def wait(selected,timeout):
            result=real(selected,timeout)
            if result is not None:owner._operation.auxiliary_operations[1]=object.__new__(producer.AuxiliaryCommand)
            return result
        with mock.patch.object(producer.AuxiliaryCommand,'wait',wait):
            owner.continue_auxiliary_wait(0,1);view=self.call_done(owner)
        self.assertEqual(0,auxiliary.result['returncode'])
        self.assertTrue(all(x['eof'] for x in auxiliary.result['outputs'].values()))
        self.assertFalse(view['auxiliary_ledger_check_matched'])
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
        self.assertIs(owner._first_error_object,fault);self.record('post-wait-drift',owner)


    def test_observation_error_never_calls_custom_exception_note(self):
        owner,auxiliary,release,fault=self.start_partial();self.advance(owner);called=[]
        class OwnSecondary(RuntimeError):
            def add_note(self,note):
                called.append(note)
                raise AssertionError('custom exception hook must not run')
        second=OwnSecondary('OWN later wait error')
        original=producer._RetainedPreflightOwner._cache_auxiliary_observation
        def cache(target,index,selected,stage):
            if stage=='after_wait_error':raise producer.ProducerError('OWN synthetic metadata observation failure')
            return original(target,index,selected,stage)
        with mock.patch.object(producer.AuxiliaryCommand,'wait',side_effect=second), \
                mock.patch.object(producer._RetainedPreflightOwner,'_cache_auxiliary_observation',cache):
            owner.continue_auxiliary_wait(0,0);self.call_done(owner)
        self.assertIs(owner._workers[-1]['_call_error_object'],second)
        self.assertEqual([],called);self.assertIs(owner._first_error_object,fault)
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['auxiliary_observation_error'])
        self.record('observation-error',owner)


    def test_overlapping_auxiliary_call_refuses_while_same_worker_waits(self):
        owner,auxiliary,release,fault=self.start_partial()
        entered=self.threading.Event();unblock=self.threading.Event();self.events.append(unblock)
        real=self.actual_wait;calls=[];refused=[];unexpected=[]
        def wait(selected,timeout):
            calls.append(selected);entered.set();unblock.wait(5)
            return real(selected,timeout)
        def second():
            try:owner.continue_auxiliary_wait(0,0)
            except producer.ProducerError as error:refused.append(type(error).__name__)
            except BaseException as error:unexpected.append(error)
        with mock.patch.object(producer.AuxiliaryCommand,'wait',wait):
            owner.continue_auxiliary_wait(0,1)
            try:
                self.assertTrue(entered.wait(3));before=dict(owner.observe(0))
                caller=self.threading.Thread(target=second,daemon=False);self.parents.append(caller)
                caller.start();caller.join(3);self.assertFalse(caller.is_alive())
                self.assertEqual(['ProducerError'],refused);self.assertEqual([],unexpected)
                self.assertEqual(before,dict(owner.observe(0)))
            finally:self.release(release);unblock.set();self.call_done(owner)
        self.assertEqual([auxiliary],calls);self.assertEqual(0,auxiliary.result['returncode'])
        self.record('overlapping-call-refused',owner)


class PartialCommandContinuationTests(unittest.TestCase):
    """Finite OWN recipe fixtures; not canonical/SDK/whole-actor proof."""
    def setUp(self):
        import threading,time
        self.threading=threading;self.time=time
        root=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        self.base=Path(tempfile.mkdtemp(prefix='partial-command-',dir=root)).resolve()
        self.repo=self.base/'repo';self.repo.mkdir()
        self.owners=[];self.known=[];self.gates=[];self.barriers=[];self.sequence=0
        self.actual_drain=producer.CommandProducer._drain_output

    def done(self,owner):
        for _ in range(20):
            view=owner.observe(1)
            if view['call_done'] and view['worker_joined'] and view['worker_start_settled']:return view
        self.fail('OWN finite worker did not settle')

    def save(self,label,owner):
        row=dict(view=dict(owner.observe(0)),workers=[dict(x) for x in owner.worker_lifecycle()])
        if hasattr(owner,'command_observation'):
            row['command']=dict(owner.command_observation())
        with (self.base/(label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def release(self,path):
        if not path.exists():
            with path.open('x') as f:f.write('OWN finite fixture release; NOT GO\n')

    def start_partial(self):
        self.sequence+=1
        ready=self.base/('ready-'+str(self.sequence));gate=self.base/('release-'+str(self.sequence))
        sentinel=self.base/('FORBIDDEN-next-'+str(self.sequence));self.gates.append(gate)
        code=("import os,sys,time\nfrom pathlib import Path\n"
              "ready,gate=map(Path,sys.argv[1:])\n"
              "os.write(1,b'OWN-out-before\\n');os.write(2,b'OWN-err-before\\n');ready.write_text('ready')\n"
              "end=time.monotonic()+10\n"
              "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
              "os.write(1,b'OWN-out-after\\n');os.write(2,b'OWN-err-after\\n')\n"
              "raise SystemExit(0 if gate.exists() else 78)\n")
        first=[sys.executable,'-c',code,str(ready),str(gate)]
        second=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
        fault=OSError(5,'OWN factory escape after actual recipe ctor return')
        actual_factory=producer.start_fixture
        def factory(**kwargs):
            operation=actual_factory(**kwargs)
            self.known.append(operation)
            raise fault
        def archive(operation):
            operation.source_archive_sha256='0'*64;operation.source_entries=1
        nonce=digest((str(self.base)+str(self.sequence)).encode())[:32]
        with mock.patch.object(producer.CommandProducer,'_source_guard',lambda operation:None),\
             mock.patch.object(producer.CommandProducer,'_make_archive',archive),\
             mock.patch.object(producer.CommandProducer,'_input_guard',lambda operation:None),\
             mock.patch.object(producer,'start_fixture',factory):
            owner=producer.start_owned_preflight('fixture',owner_id=nonce,repo=self.repo,
                source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/('run-'+str(self.sequence)),
                expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
                commands=[first,second],lease_check=lambda:None)
            self.owners.append(owner);self.done(owner)
        end=self.time.monotonic()+3
        while not ready.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(ready.exists())
        operation=owner._operation
        self.assertIs(operation,self.known[-1]);self.assertIs(owner._first_error_object,fault)
        self.assertFalse(owner.observe(0)['initialized']);self.assertTrue(operation.pending)
        self.assertIsNone(operation.process.poll());self.assertEqual(1,len(operation.records))
        self.save('created-'+str(self.sequence),owner)
        return owner,operation,gate,sentinel,fault

    def advance(self,owner,timeout=0):
        owner.continue_command_wait(timeout);self.done(owner)
        return owner.command_observation()

    def complete(self,owner,gate):
        self.release(gate)
        for _ in range(15):
            row=self.advance(owner,1)
            if row['terminal_observed']:return row
        self.fail('OWN command natural status/merged EOF not observed')

    def tearDown(self):
        for event in self.barriers:event.set()
        for gate in self.gates:self.release(gate)
        for owner in self.owners:self.done(owner)
        actors=[]
        for operation in self.known:
            used_drain=False
            while not operation.records[-1]['output_eof']:
                used_drain=True;self.actual_drain(operation,self.time.monotonic()+1)
            while True:
                try:status=operation.process.wait(timeout=1);break
                except subprocess.TimeoutExpired:continue
            log=operation.output_log
            if log is not None and not log.closed:log.flush();os.fsync(log.fileno());log.close()
            if operation.events is not None and not operation.events.closed:operation.events.close()
            data=(operation.directory/'command-000.log').read_bytes()
            actors.append(dict(pid=operation.process.pid,status=status,merged_output_eof=operation.records[-1]['output_eof'],
                bytes=len(data),sha256=digest(data),stream_sha256=operation.output_hash.hexdigest(),
                fixture_only_direct_drain=used_drain,fixture_only_log_close=True,record_count=len(operation.records)))
        with (self.base/'known-actors.json').open('x') as f:json.dump(actors,f,indent=2)
        for row in actors:
            self.assertEqual(0,row['status']);self.assertTrue(row['merged_output_eof'])
            self.assertEqual(row['sha256'],row['stream_sha256']);self.assertEqual(1,row['record_count'])

    def test_same_recipe_natural_exit_without_pipeline_advancement(self):
        owner,op,gate,sentinel,fault=self.start_partial()
        with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
        with mock.patch.object(producer.CommandProducer,'_spawn',side_effect=AssertionError('new spawn')),\
             mock.patch.object(producer.CommandProducer,'_source_guard',side_effect=AssertionError('new audit')),\
             mock.patch.object(producer.CommandProducer,'_end_command',side_effect=AssertionError('pipeline end')),\
             mock.patch.object(producer.CommandProducer,'_finish',side_effect=AssertionError('pipeline finish')):
            before=self.advance(owner,0);self.assertFalse(before['terminal_observed'])
            row=self.complete(owner,gate)
        self.assertEqual(0,row['direct_status']);self.assertTrue(row['natural_wait_observed']);self.assertTrue(row['output_eof'])
        self.assertTrue(row['log_open']);self.assertTrue(op.pending);self.assertFalse(op.finished)
        self.assertFalse(sentinel.exists());self.assertIs(owner._first_error_object,fault)
        self.assertIsNone(owner.observe(0)['actor_ownership_complete'])
        for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(owner.observe(0)[flag])
        self.save('complete',owner)

    def test_terminal_cache_refuses_before_scheduling(self):
        owner,op,gate,_,_=self.start_partial();self.complete(owner,gate)
        before=dict(owner.observe(0));threads=len(owner.worker_lifecycle())
        with self.assertRaises(producer.ProducerError):owner.continue_command_wait(0)
        self.assertEqual(before,dict(owner.observe(0)));self.assertEqual(threads,len(owner.worker_lifecycle()))

    def test_invalid_timeouts_do_not_schedule(self):
        owner,op,gate,_,_=self.start_partial();before=dict(owner.observe(0))
        for value in (-1,61,True,float('nan'),float('inf'),'1'):
            with self.subTest(value=type(value).__name__):
                with self.assertRaises(producer.ProducerError):owner.continue_command_wait(value)
        self.assertEqual(before,dict(owner.observe(0)))

    def test_missing_process_refuses_without_drain(self):
        owner,op,gate,_,fault=self.start_partial();process=op.process
        try:
            del op.process
            with mock.patch.object(producer.CommandProducer,'_drain_output',side_effect=AssertionError('unknown IO')):
                self.advance(owner,0)
            self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertIs(owner._first_error_object,fault)
        finally:op.process=process # Fixture-only known actor restoration, never live recovery.
        self.save('missing-process',owner)

    def test_record_identity_drift_stays_quarantined(self):
        owner,op,gate,_,_=self.start_partial();self.advance(owner,0)
        original=op.records[-1];op.records[-1]=dict(original)
        try:
            with mock.patch.object(producer.CommandProducer,'_drain_output',side_effect=AssertionError('drift IO')):
                self.advance(owner,0)
            self.assertTrue(owner.command_observation()['quarantined'])
        finally:op.records[-1]=original # Does not reset owner quarantine.
        with self.assertRaises(producer.ProducerError):owner.continue_command_wait(0)
        self.save('drift',owner)

    def test_new_wait_exception_keeps_original_primary_and_same_actor(self):
        owner,op,gate,_,fault=self.start_partial();process=op.process
        error=OSError(13,'OWN one drain exception')
        with mock.patch.object(producer.CommandProducer,'_drain_output',side_effect=error):
            self.advance(owner,0)
        self.assertIs(owner._workers[-1]['_call_error_object'],error)
        self.assertIs(owner._first_error_object,fault);self.assertIs(op.process,process)
        self.complete(owner,gate);self.save('wait-error-continued',owner)

    def test_uncertain_write_does_not_replay_output(self):
        owner,op,gate,_,_=self.start_partial();op.output_write_uncertain=True
        try:
            row=self.advance(owner,0)
            self.assertTrue(row['output_write_uncertain']);self.assertFalse(row['terminal_observed'])
            self.assertEqual(0,op.output_bytes);self.assertEqual(b'',op.output_buffer)
        finally:op.output_write_uncertain=False # Synthetic fixture flag only; no uncertain write actually occurred.
        self.complete(owner,gate)

    def test_busy_guard_refuses_second_worker(self):
        owner,op,gate,_,_=self.start_partial();entered=self.threading.Event();release=self.threading.Event()
        self.barriers.append(release);actual=self.actual_drain
        def drain(operation,deadline):
            entered.set();release.wait(3)
            return actual(operation,deadline)
        with mock.patch.object(producer.CommandProducer,'_drain_output',drain):
            owner.continue_command_wait(0);self.assertTrue(entered.wait(2))
            before=dict(owner.observe(0))
            with self.assertRaises(producer.ProducerError):owner.continue_command_wait(0)
            self.assertEqual(before,dict(owner.observe(0)))
            release.set();self.done(owner)
        self.complete(owner,gate)

    def test_lease_callback_drift_refuses_before_pipe_IO(self):
        owner,op,gate,_,fault=self.start_partial()
        original_fd=op.output_fd;read_fd,write_fd=os.pipe();os.close(write_fd)
        def check():
            op.output_fd=read_fd
        op.lease_check=check
        called=[]
        try:
            with mock.patch.object(producer.CommandProducer,'_drain_output',side_effect=lambda *args:called.append(True) or False):
                self.advance(owner,0)
            self.assertEqual([],called)
            self.assertTrue(owner.command_observation()['quarantined'])
            self.assertIs(owner._first_error_object,fault)
        finally:
            op.output_fd=original_fd # OWN fixture handle restoration, never live recovery.
            os.close(read_fd)
        self.save('callback-drift',owner)

    def test_unknown_kind_never_calls_custom_equality(self):
        owner,op,gate,_,fault=self.start_partial();record=op.records[-1];original=record['kind'];called=[]
        class UnknownKind:
            def __eq__(self,other):
                called.append(True);return False
        record['kind']=UnknownKind()
        try:
            self.advance(owner,0)
            self.assertEqual([],called)
            self.assertTrue(owner.command_observation()['quarantined'])
            self.assertIs(owner._first_error_object,fault)
        finally:record['kind']=original # Fixture-only malformed field restoration; owner remains quarantined.
        self.save('unknown-kind',owner)

    def test_scalar_cache_rejects_postcheck_non_scalar(self):
        owner,op,gate,_,fault=self.start_partial();token=object();calls=[]
        actual=producer._RetainedPreflightOwner._checked_partial_command
        def check(current):
            frozen=actual(current);calls.append(True)
            if len(calls)==2:op.output_bytes=token
            return frozen
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_checked_partial_command',check):
                self.advance(owner,0)
            view=owner.command_observation()
            leaked=view.get('output_bytes') is token
            with (self.base/'scalar-leak-observation.json').open('x') as f:
                json.dump(dict(raw_non_scalar_in_view=leaked),f)
            self.assertFalse(leaked)
            self.assertIs(owner._first_error_object,fault)
        finally:op.output_bytes=0 # No pipe IO occurred; fixture-only malformed scalar restoration.



class ParentWriterSealTests(unittest.TestCase):
    """Finite parent-writer object fixtures; never live cleanup/admission."""
    setUp=PartialCommandContinuationTests.setUp
    done=PartialCommandContinuationTests.done
    release=PartialCommandContinuationTests.release
    start_partial=PartialCommandContinuationTests.start_partial
    advance=PartialCommandContinuationTests.advance
    complete=PartialCommandContinuationTests.complete
    tearDown=PartialCommandContinuationTests.tearDown

    def save(self,label,owner):
        row=dict(view=dict(owner.observe(0)),workers=[dict(x) for x in owner.worker_lifecycle()],
                 command=dict(owner.command_observation()))
        if hasattr(owner,'parent_writer_observations'):
            row['writers']=[dict(x) for x in owner.parent_writer_observations()]
        with (self.base/(label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def ready_owner(self):
        owner,op,gate,sentinel,fault=self.start_partial()
        self.complete(owner,gate)
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed)
        return owner,op,sentinel,fault

    def seal(self,owner):
        owner.seal_parent_writers();self.done(owner)
        return owner.parent_writer_observations()

    def test_real_close_of_both_known_objects_without_pipeline_retag(self):
        owner,op,sentinel,fault=self.ready_owner();log=op.log;journal=op.events
        with mock.patch.object(producer.CommandProducer,'_event',side_effect=AssertionError('new event')),\
             mock.patch.object(producer.CommandProducer,'_end_command',side_effect=AssertionError('pipeline end')),\
             mock.patch.object(producer.CommandProducer,'_finish',side_effect=AssertionError('pipeline finish')),\
             mock.patch.object(producer.CommandProducer,'_spawn',side_effect=AssertionError('new spawn')):
            rows=self.seal(owner)
        self.assertEqual(['command_log','journal'],[x['role'] for x in rows])
        for row in rows:
            self.assertTrue(row['flush_returned']);self.assertTrue(row['fsync_returned'])
            self.assertTrue(row['close_attempted']);self.assertTrue(row['close_returned']);self.assertTrue(row['closed_observed'])
            self.assertIsNone(row['actor_ownership_complete'])
            for key in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[key])
        self.assertIs(op.log,log);self.assertIs(op.events,journal)
        self.assertTrue(log.closed);self.assertTrue(journal.closed)
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
        self.assertFalse(sentinel.exists());self.assertEqual(1,len(op.records))
        self.assertIs(owner._first_error_object,fault)
        self.save('real-seal',owner)

    def test_repeat_refuses_before_new_worker(self):
        owner,op,_,_=self.ready_owner();self.seal(owner)
        before=dict(owner.observe(0));count=len(owner.worker_lifecycle())
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.assertEqual(before,dict(owner.observe(0)));self.assertEqual(count,len(owner.worker_lifecycle()))

    def test_ineligible_before_natural_status_EOF_does_not_schedule(self):
        owner,op,gate,_,_=self.start_partial();before=dict(owner.observe(0))
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.assertEqual(before,dict(owner.observe(0)))
        self.assertFalse((op.directory/'owned-parent-writers').exists())

    def test_preexisting_namespace_is_terminal_and_untouched(self):
        owner,op,_,fault=self.ready_owner()
        namespace=op.directory/'owned-parent-writers';namespace.mkdir();marker=namespace/'retained'
        marker.write_bytes(b'OWN preexisting terminal namespace\n')
        rows=self.seal(owner)
        self.assertEqual('FileExistsError',owner.worker_lifecycle()[-1]['call_error'])
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed)
        self.assertEqual(b'OWN preexisting terminal namespace\n',marker.read_bytes())
        self.assertIs(owner._first_error_object,fault)
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.save('preexisting',owner)

    def test_fsync_error_preserves_primary_and_still_one_close_per_role(self):
        owner,op,_,fault=self.ready_owner();error=OSError(13,'OWN fsync failure');actual=os.fsync;calls=[]
        def fsync(fd):
            calls.append(fd)
            if len(calls)==1:raise error
            return actual(fd)
        with mock.patch.object(os,'fsync',fsync):rows=self.seal(owner)
        self.assertIs(owner._workers[-1]['_call_error_object'],error)
        self.assertIs(owner._first_error_object,fault)
        self.assertFalse(rows[0]['fsync_returned']);self.assertTrue(rows[0]['close_returned'])
        self.assertTrue(op.log.closed);self.assertTrue(op.events.closed)
        self.assertEqual(2,len(calls))
        self.save('fsync-error',owner)

    def test_journal_flush_error_never_attempts_close_or_replay(self):
        owner,op,_,fault=self.ready_owner();error=OSError(5,'OWN journal flush failure')
        actual=producer._RetainedPreflightOwner._parent_writer_io;calls=[]
        def io_call(current,index,step):
            role=current._parent_writers[index]['role'];calls.append((role,step))
            if role=='journal' and step=='flush':raise error
            return actual(current,index,step)
        with mock.patch.object(producer._RetainedPreflightOwner,'_parent_writer_io',io_call):
            rows=self.seal(owner)
        self.assertIs(owner._workers[-1]['_call_error_object'],error);self.assertIs(owner._first_error_object,fault)
        journal=rows[1];self.assertTrue(journal['quarantined'])
        self.assertFalse(journal['flush_returned']);self.assertFalse(journal['close_attempted'])
        self.assertIsNone(journal['close_returned']);self.assertFalse(op.events.closed);self.assertTrue(op.log.closed)
        self.assertEqual([('journal','flush')],[x for x in calls if x[0]=='journal'])
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.save('journal-flush-quarantine',owner)

    def test_close_then_error_is_not_normal_close_return_or_retried(self):
        owner,op,_,fault=self.ready_owner();error=OSError(5,'OWN post-close uncertainty')
        actual=producer._RetainedPreflightOwner._parent_writer_io;calls=[]
        def io_call(current,index,step):
            role=current._parent_writers[index]['role'];calls.append((role,step))
            result=actual(current,index,step)
            if role=='command_log' and step=='close':raise error
            return result
        with mock.patch.object(producer._RetainedPreflightOwner,'_parent_writer_io',io_call):rows=self.seal(owner)
        self.assertTrue(rows[0]['close_attempted']);self.assertFalse(rows[0]['close_returned'])
        self.assertTrue(rows[0]['closed_observed']);self.assertTrue(rows[0]['quarantined'])
        self.assertIs(owner._workers[-1]['_call_error_object'],error);self.assertIs(owner._first_error_object,fault)
        self.assertEqual(1,calls.count(('command_log','close')));self.assertEqual(1,calls.count(('journal','close')))
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.save('close-uncertain',owner)

    def test_unknown_journal_refuses_without_known_writer_close(self):
        owner,op,_,fault=self.ready_owner();journal=op.events;op.events=object()
        try:
            self.seal(owner)
            self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertFalse(op.log.closed);self.assertFalse(journal.closed)
            self.assertIs(owner._first_error_object,fault)
        finally:op.events=journal # Fixture-only malformed field restoration.
        self.save('unknown-journal',owner)

    def test_raw_method_shadow_is_rejected_without_hook(self):
        owner,op,_,fault=self.ready_owner();raw=op.events.raw;touched=[]
        raw.close=lambda:touched.append(True)
        try:
            self.seal(owner)
            self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertEqual([],touched);self.assertFalse(op.log.closed);self.assertFalse(op.events.closed)
            self.assertIs(owner._first_error_object,fault)
        finally:del raw.close
        self.save('shadow-refused',owner)

    def test_borrowed_journal_FD_is_not_closed_or_adopted(self):
        import io
        owner,op,_,_=self.ready_owner();journal=op.events
        fd=os.dup(journal.fileno());raw=io.FileIO(fd,'wb',closefd=False);borrowed=io.BufferedWriter(raw)
        op.events=borrowed
        try:
            self.seal(owner)
            self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertFalse(op.log.closed);self.assertFalse(borrowed.closed);os.fstat(fd)
        finally:
            op.events=journal;borrowed.close();os.close(fd) # Known OWN fixture-only borrowed wrapper/FD cleanup.
        self.save('borrowed-refused',owner)

    def test_fsync_outside_observer_lock_and_busy_refusal(self):
        owner,op,_,_=self.ready_owner();entered=self.threading.Event();release=self.threading.Event()
        self.barriers.append(release);actual=os.fsync;calls=[]
        def fsync(fd):
            calls.append(fd)
            if len(calls)==1:entered.set();release.wait(3)
            return actual(fd)
        with mock.patch.object(os,'fsync',fsync):
            owner.seal_parent_writers();self.assertTrue(entered.wait(2))
            view=owner.observe(0);self.assertFalse(view['call_done'])
            row=owner.parent_writer_observations()[0]
            self.assertTrue(row['fsync_attempted']);self.assertIsNone(row['fsync_returned'])
            with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
            release.set();self.done(owner)
        self.assertTrue(op.log.closed);self.assertTrue(op.events.closed);self.save('busy',owner)

    def test_callback_journal_drift_refuses_before_writer_IO(self):
        owner,op,gate,_,fault=self.start_partial();journal=op.events;armed=[];calls=[]
        def check():
            if armed:
                calls.append(True)
                if len(calls)==2:op.events=object()
        op.lease_check=check
        self.complete(owner,gate)
        armed.append(True);io_calls=[]
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_parent_writer_io',
                                   side_effect=lambda *args:io_calls.append(True)):
                self.seal(owner)
            self.assertEqual([],io_calls);self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
            self.assertFalse(op.log.closed);self.assertFalse(journal.closed);self.assertIs(owner._first_error_object,fault)
        finally:op.events=journal # Fixture-only pointer restoration; no owner reset.
        self.save('callback-drift',owner)

    def test_thread_start_then_error_keeps_same_worker_and_one_seal(self):
        owner,op,_,fault=self.ready_owner();actual=self.threading.Thread.start;started=[]
        def start(thread):
            started.append(thread);actual(thread);raise OSError(5,'OWN start returned uncertainty')
        with mock.patch.object(self.threading.Thread,'start',start):
            owner.seal_parent_writers();self.done(owner)
        self.assertEqual(1,len(started));self.assertIs(owner._thread,started[0])
        self.assertTrue(op.log.closed);self.assertTrue(op.events.closed)
        self.assertIs(owner._first_error_object,fault)
        with self.assertRaises(producer.ProducerError):owner.seal_parent_writers()
        self.save('start-uncertain',owner)

    def tearDown(self):
        before=[dict(pid=op.process.pid,log_closed_before_fixture_cleanup=op.output_log.closed,
                     journal_closed_before_fixture_cleanup=op.events.closed) for op in self.known]
        PartialCommandContinuationTests.tearDown(self)
        with (self.base/'parent-writers-before-fixture-cleanup.json').open('x') as f:json.dump(before,f,indent=2)

    def test_normal_close_return_without_closed_object_quarantines(self):
        owner,op,_,fault=self.ready_owner()
        actual=producer._RetainedPreflightOwner._parent_writer_io;calls=[]
        def io_call(current,index,step):
            role=current._parent_writers[index]['role'];calls.append((role,step))
            if role=='command_log' and step=='close':return None
            return actual(current,index,step)
        with mock.patch.object(producer._RetainedPreflightOwner,'_parent_writer_io',io_call):
            rows=self.seal(owner)
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])
        self.assertTrue(rows[0]['close_returned']);self.assertFalse(rows[0]['closed_observed'])
        self.assertTrue(rows[0]['quarantined']);self.assertFalse(op.log.closed);self.assertTrue(op.events.closed)
        self.assertEqual(1,calls.count(('command_log','close')))
        self.assertIs(owner._first_error_object,fault)
        self.save('normal-return-not-closed',owner)



class KnownActorInventoryTests(unittest.TestCase):
    """New finite known-handle snapshots; never whole-actor/EX admission."""
    done=PartialCommandContinuationTests.done
    release=PartialCommandContinuationTests.release
    start_partial=PartialCommandContinuationTests.start_partial

    def setUp(self):
        PartialCommandContinuationTests.setUp(self)
        self.aux=[];self.actions={};self.saved=0
        self.actual_aux_wait=producer.AuxiliaryCommand.wait

    def save(self,label,owner):
        self.saved+=1
        row=dict(view=dict(owner.observe(0)),workers=[dict(x) for x in owner.worker_lifecycle()])
        if hasattr(owner,'known_actor_observations'):
            row['actors']=[dict(x) for x in owner.known_actor_observations()]
        with (self.base/(str(self.saved)+'-'+label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def argv(self,label):
        ready=self.base/(label+'-ready');gate=self.base/(label+'-release');self.gates.append(gate)
        code=("import os,sys,time\nfrom pathlib import Path\n"
              "ready,gate=map(Path,sys.argv[1:])\n"
              "os.write(1,b'OWN-inventory-out\\n');os.write(2,b'OWN-inventory-err\\n');ready.write_text('ready')\n"
              "end=time.monotonic()+10\n"
              "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
              "raise SystemExit(0 if gate.exists() else 78)\n")
        return [sys.executable,'-c',code,str(ready),str(gate)],ready

    def ready(self,path):
        end=self.time.monotonic()+3
        while not path.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(path.exists())

    def new_aux(self,operation,label):
        argv,ready=self.argv(label)
        auxiliary=producer.AuxiliaryCommand(directory=operation.directory,name=label,argv=argv,
            cwd=operation.repo,environment=operation.environment,lease_check=operation.lease_check,stdout_max=65536)
        operation.auxiliary_operations.append(auxiliary);self.aux.append(auxiliary)
        auxiliary.start()
        return auxiliary,ready

    def initialized(self,mixed=False,parent_start_error=False):
        argv,ready=self.argv('recipe')
        sentinel=self.base/'FORBIDDEN-inventory-next'
        next_argv=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
        def lease_check():
            action=self.actions.get('callback')
            if action is not None:action()
        def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
        actual_factory=producer.start_fixture
        def factory(**kwargs):
            op=actual_factory(**kwargs);self.known.append(op);return op
        fault=OSError(5,'OWN later wait escape after exact auxiliary launch')
        start_fault=RuntimeError('OWN parent start raises after actual construct worker joined')
        actual_start=self.threading.Thread.start
        def start(thread):
            actual_start(thread);thread.join(3)
            self.assertFalse(thread.is_alive())
            raise start_fault
        patches=[mock.patch.object(producer.CommandProducer,'_source_guard',lambda op:None),
            mock.patch.object(producer.CommandProducer,'_make_archive',archive),
            mock.patch.object(producer.CommandProducer,'_input_guard',lambda op:None),
            mock.patch.object(producer,'start_fixture',factory)]
        if parent_start_error:patches.append(mock.patch.object(self.threading.Thread,'start',start))
        for patch in patches:patch.start()
        try:
            owner=producer.start_owned_preflight('fixture',owner_id=digest(str(self.base).encode())[:32],
                repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/'initialized-run',
                expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},commands=[argv,next_argv],lease_check=lease_check)
            self.owners.append(owner);self.done(owner)
        finally:
            for patch in reversed(patches):patch.stop()
        op=self.known[-1];self.ready(ready);self.assertTrue(owner.observe(0)['initialized'])
        if mixed:
            starts=[]
            def wait(current,timeout):
                self.assertIs(current,op)
                auxiliary,aux_ready=self.new_aux(op,'inventory-aux');starts.append((auxiliary,aux_ready));raise fault
            with mock.patch.object(producer.CommandProducer,'wait',wait):
                owner.continue_wait(0);self.done(owner)
            self.ready(starts[0][1]);self.assertIs(owner._first_error_object,fault)
        elif parent_start_error:self.assertIs(owner._first_error_object,start_fault)
        self.save('initialized',owner)
        return owner,op,sentinel,(start_fault if parent_start_error else fault)

    def ctor_aux(self):
        argv,_=self.argv('unused-recipe')
        ready=[];fault=OSError(5,'OWN constructor escapes with retained started auxiliary')
        def guard(op):
            _,path=self.new_aux(op,'constructor-aux');ready.append(path);raise fault
        with mock.patch.object(producer.CommandProducer,'_source_guard',guard):
            owner=producer.start_owned_preflight('fixture',owner_id=digest(str(self.base).encode())[:32],
                repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/'ctor-aux-run',
                expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},commands=[argv],lease_check=lambda:None)
            self.owners.append(owner);self.done(owner)
        self.ready(ready[0]);self.assertFalse(owner.observe(0)['initialized'])
        self.assertIs(owner._first_error_object,fault);self.save('ctor-aux',owner)
        return owner,owner._operation,fault

    def freeze(self,owner):
        result=owner.freeze_known_actors();self.assertIs(result,owner);self.done(owner)
        rows=owner.known_actor_observations()
        self.assertIs(type(rows),tuple)
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertIn(type(value),(str,int,bool,type(None)))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[flag])
        self.save('frozen',owner)
        return rows

    def test_constructor_has_started_auxiliary_not_prestart_only(self):
        owner,op,fault=self.ctor_aux();aux=self.aux[0];rows=self.freeze(owner)
        self.assertEqual(['producer','recipe','auxiliary'],[r['role'] for r in rows])
        self.assertFalse(rows[0]['owner_initialized']);self.assertEqual('construct',rows[0]['origin_action'])
        self.assertIsNone(rows[1]['pid']);self.assertTrue(rows[2]['retained_process'])
        self.assertEqual(aux.process.pid,rows[2]['pid']);self.assertTrue(rows[2]['pending'])
        self.assertIsNone(rows[2]['cached_returncode']);self.assertIs(owner._first_error_object,fault)
        self.assertTrue(aux.pending);self.assertFalse(aux.finished)

    def test_constructor_recipe_views_immutable_and_no_actor_IO(self):
        owner,op,gate,sentinel,fault=self.start_partial()
        with mock.patch.object(subprocess.Popen,'poll',side_effect=AssertionError('new poll')),\
             mock.patch.object(subprocess.Popen,'wait',side_effect=AssertionError('new wait')),\
             mock.patch.object(producer.CommandProducer,'_drain_output',side_effect=AssertionError('new drain')),\
             mock.patch.object(producer.CommandProducer,'_spawn',side_effect=AssertionError('new spawn')):
            rows=self.freeze(owner)
        self.assertEqual(op.process.pid,rows[1]['pid']);self.assertIsNone(rows[1]['cached_returncode'])
        with self.assertRaises(TypeError):rows[1]['pid']=0
        self.assertIs(rows,owner.known_actor_observations())
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertFalse(op.log.closed)
        self.assertFalse(sentinel.exists());self.assertIs(owner._first_error_object,fault)

    def test_initialized_later_failure_retains_both_handles_blocks_pipeline(self):
        owner,op,sentinel,fault=self.initialized(mixed=True);aux=self.aux[0];rows=self.freeze(owner)
        self.assertTrue(rows[0]['owner_initialized']);self.assertEqual('wait',rows[0]['origin_action'])
        self.assertEqual('OSError',rows[0]['origin_call_error'])
        self.assertEqual([op.process.pid,aux.process.pid],[row['pid'] for row in rows[1:]])
        self.assertTrue(all(row['pending'] for row in rows[1:]));self.assertTrue(op.pending)
        count=len(owner.worker_lifecycle())
        for action in (lambda:owner.continue_wait(0),lambda:owner.continue_auxiliary_wait(0,0),
                       lambda:owner.continue_command_wait(0),lambda:owner.seal_parent_writers(),lambda:owner.emit('canonical'),
                       owner.freeze_known_actors):
            with self.assertRaises(producer.ProducerError):action()
        self.assertEqual(count,len(owner.worker_lifecycle()));self.assertFalse(sentinel.exists())
        self.assertIs(owner._first_error_object,fault)

    def test_healthy_initialized_owner_refuses_without_freeze_attempt(self):
        owner,op,_,_=self.initialized()
        before=dict(owner.observe(0));count=len(owner.worker_lifecycle())
        with self.assertRaises(producer.ProducerError):owner.freeze_known_actors()
        self.assertEqual(before,dict(owner.observe(0)));self.assertEqual(count,len(owner.worker_lifecycle()))
        self.assertEqual((),owner.known_actor_observations())

    def test_early_registration_missing_fields_explicit_unknown(self):
        calls=[];fault=OSError(5,'OWN first entry lease callback fault')
        def lease():
            calls.append(True)
            if len(calls)==1:raise fault
        owner=producer.start_owned_preflight('fixture',owner_id=digest(str(self.base).encode())[:32],
            repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/'early-run',
            expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
            commands=[[sys.executable,'-c','raise SystemExit(99)']],lease_check=lease)
        self.owners.append(owner);self.done(owner);rows=self.freeze(owner)
        self.assertFalse(rows[0]['ledger_known']);self.assertIsNone(rows[0]['ledger_entries'])
        self.assertTrue(rows[0]['quarantined']);self.assertIsNone(rows[1]['pending'])
        self.assertIsNone(rows[1]['cached_returncode']);self.assertIs(owner._first_error_object,fault)
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])

    def test_parent_start_error_not_invented_wait_failure(self):
        owner,op,_,fault=self.initialized(parent_start_error=True);rows=self.freeze(owner)
        self.assertTrue(rows[0]['owner_initialized']);self.assertEqual('construct',rows[0]['origin_action'])
        self.assertIsNone(rows[0]['origin_call_error']);self.assertTrue(rows[0]['origin_start_attempted'])
        self.assertFalse(rows[0]['origin_start_returned']);self.assertIs(owner._first_error_object,fault)

    def test_callback_drift_preserves_pre_callback_exact_handles(self):
        owner,op,_,_=self.initialized(mixed=True);aux=self.aux[0];marker=object();seen=[]
        def drift():
            self.assertIs(owner._known_actor_producer,op)
            self.assertIs(owner._known_actor_processes[0],op.process)
            self.assertIs(owner._known_actor_processes[1],aux.process)
            seen.append(True);op.auxiliary_operations[:]=[marker]
        self.actions['callback']=drift
        try:rows=self.freeze(owner)
        finally:self.actions.pop('callback',None);op.auxiliary_operations[:]=[aux]
        self.assertEqual([True],seen);self.assertTrue(rows[0]['quarantined'])
        self.assertIs(owner._known_actor_auxiliaries[0],aux)
        self.assertEqual('ProducerError',owner.worker_lifecycle()[-1]['call_error'])

    def test_hostile_scalar_and_cached_status_never_escape_or_run_hooks(self):
        owner,op,_,_=self.initialized(mixed=True);aux=self.aux[0];calls=[]
        class Hostile:
            def __bool__(self):calls.append('bool');raise AssertionError('bool hook')
            def __repr__(self):calls.append('repr');raise AssertionError('repr hook')
            def __str__(self):calls.append('str');raise AssertionError('str hook')
            def __eq__(self,other):calls.append('eq');raise AssertionError('eq hook')
        old_pending=aux.pending;old_status=op.process.returncode
        aux.pending=Hostile();op.process.returncode=Hostile()
        try:rows=self.freeze(owner)
        finally:aux.pending=old_pending;op.process.returncode=old_status
        self.assertEqual([],calls);self.assertIsNone(rows[1]['cached_returncode'])
        self.assertIsNone(rows[2]['pending']);self.assertTrue(rows[0]['quarantined'])
        self.assertIs(type(owner.observe(0)['producer_pending']),bool)

    def test_duplicate_auxiliary_ledger_quarantines_without_dedup_loss(self):
        owner,op,_,_=self.initialized(mixed=True);aux=self.aux[0]
        op.auxiliary_operations.append(aux)
        try:rows=self.freeze(owner)
        finally:op.auxiliary_operations[:]=[aux]
        self.assertTrue(rows[0]['quarantined']);self.assertEqual(2,rows[0]['ledger_entries'])
        self.assertIs(owner._known_actor_auxiliaries[0],aux);self.assertIs(owner._known_actor_auxiliaries[1],aux)

    def test_busy_callback_views_cached_and_terminal_attempt(self):
        owner,op,_,_=self.initialized(mixed=True)
        entered=self.threading.Event();release=self.threading.Event();self.barriers.append(release)
        def block():entered.set();self.assertTrue(release.wait(3))
        self.actions['callback']=block
        owner.freeze_known_actors()
        try:
            self.assertTrue(entered.wait(3));rows=owner.known_actor_observations()
            self.assertGreaterEqual(len(rows),3);self.assertEqual('retained_before_lease',rows[0]['stage'])
            self.save('busy-retained',owner)
            count=len(owner.worker_lifecycle())
            with self.assertRaises(producer.ProducerError):owner.freeze_known_actors()
            with self.assertRaises(producer.ProducerError):owner.continue_wait(0)
            self.assertEqual(count,len(owner.worker_lifecycle()))
        finally:release.set();self.actions.pop('callback',None);self.done(owner)
        self.save('after-busy',owner)
        with self.assertRaises(producer.ProducerError):owner.freeze_known_actors()


    def test_missing_cached_returncode_is_unknown_not_checked(self):
        owner,op,_,_,_=self.start_partial()
        old=op.process.__dict__.pop('returncode')
        try:rows=self.freeze(owner)
        finally:op.process.returncode=old
        self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[1]['fields_valid'])
        self.assertIsNone(rows[1]['cached_returncode'])

    def test_foreign_producer_lease_field_not_accepted_as_original_owner_callback(self):
        owner,op,_,_,_=self.start_partial();old=op.lease_check
        op.lease_check=object()
        try:rows=self.freeze(owner)
        finally:op.lease_check=old
        self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[0]['fields_valid'])



    def test_callback_foreign_producer_keeps_original_handles_and_historical_owner_scalars(self):
        owner,op,_,fault=self.initialized(mixed=True);aux=self.aux[0]
        foreign=object.__new__(producer.CommandProducer)
        def swap():owner._operation=foreign
        self.actions['callback']=swap
        try:rows=self.freeze(owner)
        finally:owner._operation=op;self.actions.pop('callback',None)
        self.assertTrue(rows[0]['quarantined']);self.assertEqual(op.process.pid,rows[1]['pid'])
        self.assertIs(owner._known_actor_producer,op)
        self.assertIs(owner._known_actor_processes[0],op.process)
        self.assertIs(owner._known_actor_processes[1],aux.process)
        self.assertIs(type(owner.observe(0)['producer_pending']),bool)
        self.assertIs(owner._first_error_object,fault)
        self.save('foreign-producer-restored-fixture-only',owner)


    def tearDown(self):
        for event in self.barriers:event.set()
        for gate in self.gates:self.release(gate)
        for owner in self.owners:self.done(owner)
        auxiliary=[]
        for aux in self.aux:
            result=None
            while result is None:result=self.actual_aux_wait(aux,1)
            status=aux.process.wait(timeout=3)
            auxiliary.append(result)
            self.assertEqual(0,status);self.assertEqual(0,result['returncode'])
            for stream in result['outputs'].values():
                self.assertTrue(stream['eof']);self.assertTrue(stream['snapshot_matches_stream'])
        with (self.base/'known-auxiliary-actors.json').open('x') as f:json.dump(auxiliary,f,indent=2)
        journals=[]
        for owner in self.owners:
            op=owner._operation
            if op is not None and all(op is not item for item in self.known):
                journal=op.__dict__.get('events')
                before=None if journal is None else journal.closed
                if journal is not None and not journal.closed:journal.close()
                journals.append(dict(closed_before_fixture_cleanup=before,closed_after=None if journal is None else journal.closed))
        with (self.base/'aux-only-parent-fixture-cleanup.json').open('x') as f:json.dump(journals,f,indent=2)
        PartialCommandContinuationTests.tearDown(self)



class AuxiliaryNaturalWaitWitnessTests(unittest.TestCase):
    """Finite direct method witnesses; never actor/descendant/EX admission."""
    def setUp(self):
        import time
        self.time=time;self.base=Path(tempfile.mkdtemp(prefix='aux-wait-witness-',
            dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.actors=[];self.gates=[];self.sequence=0;self.saved=0;self.malformed=[]

    def start(self,code=0,close_early=False):
        self.sequence+=1;label='aux-'+str(self.sequence)
        directory=self.base/label;directory.mkdir();ready=self.base/(label+'-ready');gate=self.base/(label+'-release')
        self.gates.append(gate)
        script=("import os,sys,time\nfrom pathlib import Path\n"
                "ready,gate=map(Path,sys.argv[1:3]);status=int(sys.argv[3]);early=sys.argv[4]=='yes'\n"
                "if early:os.close(1);os.close(2)\n"
                "else:os.write(1,b'OWN-witness-out\\n');os.write(2,b'OWN-witness-err\\n')\n"
                "ready.write_text('ready');end=time.monotonic()+10\n"
                "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
                "raise SystemExit(status if gate.exists() else 78)\n")
        op=producer.AuxiliaryCommand(directory=directory,name='witness',argv=[sys.executable,'-c',script,
            str(ready),str(gate),str(code),'yes' if close_early else 'no'],cwd=self.base,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=65536,stderr_max=65536)
        self.actors.append((op,code));op.start()
        end=self.time.monotonic()+3
        while not ready.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(ready.exists());return op,gate

    def release(self,gate):
        if not gate.exists():
            with gate.open('x') as f:f.write('OWN finite release, NOT GO\n')

    def state(self,label,op):
        self.saved+=1
        row=dict(pid=op.process.pid,cached_Popen_returncode=op.process.returncode,status=op.status,pending=op.pending,
            finished=op.finished,stdout_eof=op.streams['stdout']['eof'],stderr_eof=op.streams['stderr']['eof'],
            wait_observed=getattr(op,'_natural_wait_observed',None),wait_status=getattr(op,'_natural_wait_status',None),
            wait_process_bound=getattr(op,'_natural_wait_process',None) is op.process,
            whole_actor_ownership_complete=None,capture_ready=False)
        with (self.base/(str(self.saved)+'-'+label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def complete(self,op):
        for _ in range(15):
            result=op.wait(1)
            if result is not None:return result
        self.fail('known finite auxiliary did not complete')

    def poll_exit(self,op):
        end=self.time.monotonic()+3
        while op.status is None and self.time.monotonic()<end:
            op._observe_status()
            if op.status is None:self.time.sleep(.005)
        self.assertIs(type(op.status),int)

    def test_actual_wait_witness_survives_prebody_complete_error(self):
        op,gate=self.start();self.release(gate);fault=OSError(5,'OWN complete prebody failure after actual wait')
        with mock.patch.object(op,'_complete',side_effect=fault):
            with self.assertRaises(OSError) as caught:self.complete(op)
        self.assertIs(caught.exception,fault);row=self.state('after-complete-error-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertTrue(row['pending']);self.assertFalse(row['finished'])
        self.assertIsNone(op.result)

    def test_poll_cached_zero_is_not_wait_method_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op)
        self.state('poll-only-zero-before-fixture-cleanup',op)
        self.assertEqual(0,op.status);self.assertEqual(0,op.process.returncode)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)
        self.assertIsNone(op._natural_wait_process)

    def test_wait_timeout_retains_exact_process_then_same_actor_completion(self):
        op,gate=self.start(close_early=True);process=op.process
        self.assertIsNone(op.wait(.02));self.state('after-real-wait-timeout',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)
        self.assertIsNone(op._natural_wait_status);self.assertTrue(op.pending);self.assertFalse(op.finished)
        self.release(gate);result=self.complete(op);self.state('same-process-natural-completion',op)
        self.assertIs(op.process,process);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)

    def test_normal_completion_records_exact_process_and_signed_zero(self):
        op,gate=self.start();self.release(gate);result=self.complete(op)
        self.state('normal-completion',op)
        self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_natural_nonzero_is_retained_not_invented_zero(self):
        op,gate=self.start(code=78);self.release(gate);result=self.complete(op)
        self.state('natural-nonzero',op)
        self.assertEqual('failed',result['status']);self.assertEqual(78,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(78,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process)

    def test_boolean_wait_return_refuses_without_false_zero_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op);caught=None;self.malformed.append(op)
        with mock.patch.object(op.process,'wait',return_value=False):
            try:self.complete(op)
            except producer.ProducerError as error:caught=error
        self.state('malformed-bool-method-return-before-fixture-cleanup',op)
        self.assertIsNotNone(caught)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)

    def test_process_drift_after_timeout_refuses_second_actor_wait(self):
        op,gate=self.start(close_early=True);other,other_gate=self.start(close_early=True)
        process=op.process;self.assertIsNone(op.wait(.02))
        op.process=other.process
        try:
            with self.assertRaises(producer.ProducerError):op._wait_natural_status(0)
        finally:op.process=process
        self.state('foreign-process-refused-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)

    def tearDown(self):
        for gate in self.gates:self.release(gate)
        rows=[]
        for op,code in self.actors:
            self.state('before-private-fixture-completion',op)
            # Same known actor completion ONLY for finite unit teardown.
            result=op.result if op.finished else self.complete(op)
            status=op.process.wait(timeout=3)
            self.assertIs(type(status),int);self.assertEqual(code,status)
            if type(result['returncode']) is int:self.assertEqual(code,result['returncode'])
            else:self.assertIs(type(result['returncode']),bool);self.assertTrue(any(op is actor for actor in self.malformed))
            for stream in result['outputs'].values():
                self.assertTrue(stream['eof']);self.assertTrue(stream['snapshot_matches_stream'])
            rows.append(dict(pid=op.process.pid,actual_same_Popen_final_wait=status,raw_result=result))
        with (self.base/'known-auxiliary-actors.json').open('x') as f:json.dump(rows,f,indent=2)



class KnownStreamWaitTests(unittest.TestCase):
    """Finite wait-only actor controls; no physical closure/admission."""
    done=KnownActorInventoryTests.done
    release=KnownActorInventoryTests.release
    start_partial=KnownActorInventoryTests.start_partial
    initialized=KnownActorInventoryTests.initialized
    ready=KnownActorInventoryTests.ready

    def setUp(self):
        KnownActorInventoryTests.setUp(self)
        self.large=False;self.close_early=False;self.exit_code=0;self.extra_fds=[]

    def argv(self,label):
        ready=self.base/(label+'-ready');gate=self.base/(label+'-release');self.gates.append(gate)
        size=131072 if self.large else 19
        script=("import os,sys,time\nfrom pathlib import Path\n"
            "ready,gate=map(Path,sys.argv[1:3]);n=int(sys.argv[3]);code=int(sys.argv[4]);early=sys.argv[5]=='yes'\n"
            "if early:os.close(1);os.close(2)\n"
            "ready.write_text('ready');end=time.monotonic()+10\n"
            "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
            "if not early:os.write(1,b'A'*n);os.write(2,b'B'*n)\n"
            "raise SystemExit(code if gate.exists() else 78)\n")
        return [sys.executable,'-c',script,str(ready),str(gate),str(size),str(self.exit_code),
                'yes' if self.close_early else 'no'],ready

    def new_aux(self,operation,label):
        argv,ready=self.argv(label)
        aux=producer.AuxiliaryCommand(directory=operation.directory,name=label,argv=argv,cwd=operation.repo,
            environment=operation.environment,lease_check=operation.lease_check,stdout_max=2**20,stderr_max=2**20)
        operation.auxiliary_operations.append(aux);self.aux.append(aux);aux.start()
        return aux,ready

    def save(self,label,owner):
        self.saved+=1
        value=dict(view=dict(owner.observe(0)),workers=[dict(x) for x in owner.worker_lifecycle()])
        if hasattr(owner,'known_actor_observations'):value['inventory']=[dict(x) for x in owner.known_actor_observations()]
        if hasattr(owner,'known_actor_wait_observations'):value['waits']=[dict(x) for x in owner.known_actor_wait_observations()]
        with (self.base/(str(self.saved)+'-'+label+'.json')).open('x') as f:json.dump(value,f,indent=2)
        return value

    def freeze(self,owner):
        owner.freeze_known_actors();self.done(owner)
        rows=owner.known_actor_observations();self.assertTrue(rows[0]['snapshot_checked'])
        self.save('frozen',owner);return rows

    def row(self,owner,role,index=0):
        rows=owner.known_actor_wait_observations()
        self.assertIs(type(rows),tuple)
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertTrue(any(type(value) is kind for kind in (str,int,bool,type(None))))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[flag])
        return next(row for row in rows if row['role']==role and row['index']==index)

    def advance(self,owner,role,index=0,timeout=0):
        self.assertIs(owner.continue_known_actor_wait(role,index,timeout),owner);self.done(owner)
        self.save('after-'+role,owner);return self.row(owner,role,index)

    def complete_actor(self,owner,role,index=0):
        for _ in range(20):
            row=self.advance(owner,role,index,1)
            if row['terminal_observed']:return row
            self.assertFalse(row['quarantined'])
        self.fail('known finite selected actor did not finish direct wait/output')

    def release_all(self):
        for gate in self.gates:self.release(gate)

    def test_initialized_recipe_and_auxiliary_capacity_drain_no_pipeline_or_log_close(self):
        self.large=True;owner,op,sentinel,fault=self.initialized(mixed=True);aux=self.aux[0]
        frozen=self.freeze(owner);self.release_all()
        with mock.patch.object(producer.CommandProducer,'_end_command',side_effect=AssertionError('end')),\
             mock.patch.object(producer.CommandProducer,'_finish',side_effect=AssertionError('finish')),\
             mock.patch.object(producer.AuxiliaryCommand,'_complete',side_effect=AssertionError('complete')):
            recipe=self.complete_actor(owner,'recipe');other=self.complete_actor(owner,'auxiliary')
        self.assertEqual(0,recipe['direct_status']);self.assertEqual(0,other['direct_status'])
        self.assertTrue(recipe['wait_method_observed']);self.assertTrue(other['wait_method_observed'])
        self.assertEqual(262144,recipe['stream_bytes']);self.assertEqual(262144,other['stream_bytes'])
        self.assertEqual(b'A'*131072+b'B'*131072,(op.directory/'command-000.log').read_bytes())
        self.assertEqual(b'A'*131072,aux.streams['stdout']['path'].read_bytes())
        self.assertEqual(b'B'*131072,aux.streams['stderr']['path'].read_bytes())
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertFalse(op.log.closed)
        self.assertTrue(aux.pending);self.assertFalse(aux.finished);self.assertIsNone(aux.result)
        self.assertTrue(all(not s['log'].closed for s in aux.streams.values()))
        self.assertIs(frozen,owner.known_actor_observations());self.assertFalse(sentinel.exists())
        self.assertIs(owner._first_error_object,fault)

    def test_uninitialized_recipe_timeout_then_same_process_natural_wait(self):
        owner,op,gate,_,fault=self.start_partial();process=op.process;self.freeze(owner)
        row=self.advance(owner,'recipe');self.assertFalse(row['wait_method_observed']);self.assertIsNone(row['direct_status'])
        self.release(gate);row=self.complete_actor(owner,'recipe')
        self.assertIs(op.process,process);self.assertEqual(0,row['direct_status'])
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIs(owner._first_error_object,fault)

    def test_natural_nonzero_is_not_zero_or_pipeline_advance(self):
        self.exit_code=78;owner,op,sentinel,fault=self.initialized(parent_start_error=True)
        self.freeze(owner);self.release_all();row=self.complete_actor(owner,'recipe')
        self.assertEqual(78,row['direct_status']);self.assertTrue(row['terminal_observed'])
        self.assertFalse(sentinel.exists());self.assertTrue(op.pending);self.assertFalse(op.finished)
        self.assertIs(owner._first_error_object,fault)

    def test_eof_before_exit_still_pending_without_invented_zero(self):
        self.close_early=True;owner,op,_,_=self.initialized(mixed=True);self.freeze(owner)
        row=self.advance(owner,'auxiliary',timeout=.02)
        self.assertTrue(row['stdout_eof']);self.assertTrue(row['stderr_eof'])
        self.assertFalse(row['wait_method_observed']);self.assertIsNone(row['direct_status'])
        self.assertFalse(row['terminal_observed']);self.assertIsNone(self.aux[0].process.poll())
        self.release_all();row=self.complete_actor(owner,'auxiliary')
        self.assertEqual(0,row['direct_status']);self.assertTrue(row['terminal_observed'])

    def test_invalid_arguments_do_not_schedule(self):
        owner,_,_,_,_=self.start_partial();self.freeze(owner);count=len(owner.worker_lifecycle())
        for args in [('other',0,0),('recipe',True,0),('recipe',1,0),('auxiliary',-1,0),('recipe',0,True),('recipe',0,float('nan'))]:
            with self.subTest(args=args):
                with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait(*args)
        self.assertEqual(count,len(owner.worker_lifecycle()))

    def test_mutable_progress_callback_drift_refuses_before_read(self):
        owner,op,_,_=self.initialized(mixed=True);self.freeze(owner)
        def drift():op.output_buffer=b'FOREIGN-buffer'
        self.actions['callback']=drift
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',side_effect=AssertionError('read reached')):
                row=self.advance(owner,'recipe')
        finally:self.actions.pop('callback',None)
        self.assertTrue(row['quarantined']);self.assertIsNone(row['direct_status'])
        self.assertEqual(b'FOREIGN-buffer',op.output_buffer)

    def test_callback_descriptor_swap_refuses_before_IO(self):
        owner,op,_,_=self.initialized(mixed=True);self.freeze(owner);old=op.output_fd
        duplicate=os.dup(old);self.extra_fds.append(duplicate);os.set_inheritable(duplicate,False)
        def drift():op.output_fd=duplicate
        self.actions['callback']=drift
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',side_effect=AssertionError('read reached')):
                row=self.advance(owner,'recipe')
        finally:op.output_fd=old;self.actions.pop('callback',None)
        self.assertTrue(row['quarantined']);self.assertIsNone(row['direct_status'])

    def test_malformed_write_count_quarantines_without_replay(self):
        owner,op,gate,_,fault=self.start_partial();self.freeze(owner);self.release(gate);calls=[]
        def write(current,stream,data):calls.append(len(data));return False
        with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_write',write):
            row=self.advance(owner,'recipe',timeout=1)
        self.assertEqual(1,len(calls));self.assertTrue(row['quarantined']);self.assertGreater(row['buffered_bytes'],0)
        self.assertTrue(op.output_write_uncertain);self.assertEqual(0,op.output_bytes)
        count=len(owner.worker_lifecycle())
        with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('recipe',0,0)
        self.assertEqual(count,len(owner.worker_lifecycle()));self.assertIs(owner._first_error_object,fault)

    def test_actual_close_then_error_is_not_reclosed(self):
        owner,op,gate,_,fault=self.start_partial();self.freeze(owner);self.release(gate)
        actual=producer._RetainedPreflightOwner._known_stream_close;calls=[];error=OSError(5,'OWN close returned then injected error')
        def close(current,stream):
            calls.append(stream['original_fd']);actual(current,stream);raise error
        with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_close',close):
            row=self.advance(owner,'recipe',timeout=1)
        self.assertEqual(1,len(calls));self.assertTrue(row['quarantined']);self.assertFalse(row['read_close_confirmed'])
        self.assertIsNone(op.output_fd);self.assertIs(owner._known_wait_bindings[('recipe',0)]['primary_error'],error)
        with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('recipe',0,0)
        self.assertEqual(1,len(calls));self.assertIs(owner._first_error_object,fault)

    def test_actual_aux_wait_fact_survives_cache_error_without_complete(self):
        owner,op,_,fault=self.initialized(mixed=True);aux=self.aux[0];self.freeze(owner);self.release_all()
        actual=producer._RetainedPreflightOwner._cache_known_wait;error=OSError(5,'OWN cache after actual wait')
        def cache(current,binding,stage):
            if stage=='after_wait':raise error
            return actual(current,binding,stage)
        with mock.patch.object(producer._RetainedPreflightOwner,'_cache_known_wait',cache),\
             mock.patch.object(producer.AuxiliaryCommand,'_complete',side_effect=AssertionError('complete reached')):
            row=self.advance(owner,'auxiliary',timeout=1)
        self.assertTrue(aux._natural_wait_observed);self.assertEqual(0,aux._natural_wait_status)
        self.assertTrue(row['wait_method_observed']);self.assertEqual(0,row['direct_status']);self.assertTrue(row['quarantined'])
        self.assertTrue(aux.pending);self.assertFalse(aux.finished);self.assertIsNone(aux.result)
        self.assertIs(owner._known_wait_bindings[('auxiliary',0)]['primary_error'],error)
        self.assertIs(owner._first_error_object,fault)

    def test_busy_callback_observer_and_terminal_refusal(self):
        owner,op,_,_=self.initialized(mixed=True);self.freeze(owner)
        entered=self.threading.Event();release=self.threading.Event();self.barriers.append(release)
        def block():entered.set();self.assertTrue(release.wait(3))
        self.actions['callback']=block;owner.continue_known_actor_wait('recipe',0,0)
        try:
            self.assertTrue(entered.wait(3));row=self.row(owner,'recipe')
            self.assertFalse(row['terminal_observed']);count=len(owner.worker_lifecycle())
            with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('auxiliary',0,0)
            self.assertEqual(count,len(owner.worker_lifecycle()));self.save('during-callback',owner)
        finally:release.set();self.actions.pop('callback',None);self.done(owner)
        self.release_all();self.complete_actor(owner,'recipe');count=len(owner.worker_lifecycle())
        with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('recipe',0,0)
        self.assertEqual(count,len(owner.worker_lifecycle()))

    def test_new_error_never_calls_repr_str_or_add_note(self):
        owner,op,gate,_,fault=self.start_partial();self.freeze(owner);calls=[]
        class HookError(OSError):
            def __repr__(self):calls.append('repr');return 'forbidden'
            def __str__(self):calls.append('str');return 'forbidden'
            def add_note(self,note):calls.append('note')
        error=HookError(5,'OWN read fault')
        with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',side_effect=error):
            row=self.advance(owner,'recipe')
        self.assertTrue(row['quarantined']);self.assertEqual([],calls)
        self.assertIs(owner._known_wait_bindings[('recipe',0)]['primary_error'],error)
        self.assertIs(owner._first_error_object,fault)


    def test_callback_auxiliary_path_drift_is_refused_before_read(self):
        owner,op,_,_=self.initialized(mixed=True);aux=self.aux[0];self.freeze(owner);reads=[]
        state=aux.streams['stdout'];path=state['path'];actual=producer._RetainedPreflightOwner._known_stream_read
        def drift():state['path']=self.base/'FOREIGN-log-path'
        def read(current,stream):reads.append(stream['role']);return actual(current,stream)
        self.actions['callback']=drift
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',read):
                row=self.advance(owner,'auxiliary')
        finally:state['path']=path;self.actions.pop('callback',None)
        with (self.base/'path-drift-control.json').open('x') as f:json.dump(dict(read_calls=reads,quarantined=row['quarantined']),f)
        self.assertTrue(row['quarantined']);self.assertEqual([],reads)

    def test_callback_auxiliary_writer_confirmation_drift_is_refused_before_read(self):
        owner,op,_,_=self.initialized(mixed=True);aux=self.aux[0];self.freeze(owner);reads=[]
        state=aux.streams['stdout'];actual=producer._RetainedPreflightOwner._known_stream_read
        def drift():state['write_close_confirmed']=False
        def read(current,stream):reads.append(stream['role']);return actual(current,stream)
        self.actions['callback']=drift
        try:
            with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',read):
                row=self.advance(owner,'auxiliary')
        finally:state['write_close_confirmed']=True;self.actions.pop('callback',None)
        with (self.base/'writer-confirmation-drift-control.json').open('x') as f:json.dump(dict(read_calls=reads,quarantined=row['quarantined']),f)
        self.assertTrue(row['quarantined']);self.assertEqual([],reads)

    def test_unknown_recipe_record_key_does_not_call_custom_equality(self):
        owner,op,_,_,_=self.start_partial();self.freeze(owner);calls=[]
        class Key:
            def __hash__(self):return hash('output_read_errors')
            def __eq__(self,other):calls.append('eq');raise AssertionError('record equality hook')
        key=Key();source=op.records[-1];source[key]='unknown'
        try:row=self.advance(owner,'recipe')
        finally:del source[key]
        with (self.base/'unknown-key-control.json').open('x') as f:json.dump(dict(hooks=calls,quarantined=row['quarantined']),f)
        self.assertEqual([],calls);self.assertTrue(row['quarantined'])



    def test_select_primary_and_secondary_cache_error_keep_private_quarantine_authoritative(self):
        import select
        owner,op,gate,_,fault=self.start_partial();self.freeze(owner)
        primary=OSError(5,'OWN select fault');secondary=ValueError('OWN error-cache fault')
        actual=producer._RetainedPreflightOwner._cache_known_wait
        def cache(current,binding,stage):
            if stage=='after_wait_error':raise secondary
            return actual(current,binding,stage)
        with mock.patch.object(select,'select',side_effect=primary),\
             mock.patch.object(producer._RetainedPreflightOwner,'_cache_known_wait',cache):
            self.advance(owner,'recipe',timeout=.1)
        binding=owner._known_wait_bindings[('recipe',0)]
        self.assertIs(binding['primary_error'],primary);self.assertIs(binding['secondary_errors'][0],secondary)
        self.assertTrue(binding['quarantined']);self.assertIs(owner._workers[-1]['_call_error_object'],primary)
        self.assertIs(owner._workers[-1]['_known_wait_observation_error_object'],secondary)
        self.save('primary-secondary-before-forbidden-repeat',owner)
        before=len(owner.worker_lifecycle());read_calls=[];read=producer._RetainedPreflightOwner._known_stream_read
        def observe_read(current,stream):read_calls.append(stream['role']);return read(current,stream)
        refused=None
        with mock.patch.object(producer._RetainedPreflightOwner,'_known_stream_read',observe_read):
            try:owner.continue_known_actor_wait('recipe',0,0)
            except producer.ProducerError as error:refused=error
            self.done(owner)
        self.save('after-forbidden-repeat',owner)
        with (self.base/'private-quarantine-control.json').open('x') as f:
            json.dump(dict(refused=refused is not None,new_workers=len(owner.worker_lifecycle())-before,
                reads_after_private_quarantine=read_calls),f,indent=2)
        self.assertIsNotNone(refused);self.assertEqual(before,len(owner.worker_lifecycle()));self.assertEqual([],read_calls)
        self.assertIs(owner._first_error_object,fault)


    def tearDown(self):
        import select,io
        for event in self.barriers:event.set()
        self.actions.pop('callback',None);self.release_all()
        for owner in self.owners:self.done(owner)
        streams=[];actors=[]
        for number,op in enumerate(self.known):
            record=op.records[-1]
            streams.append(dict(role='recipe',data=op.__dict__,fdkey='output_fd',bufferkey='output_buffer',
                log=op.output_log,hash=op.output_hash,bytes=op.output_bytes,pid=op.process.pid))
            actors.append(op.process)
        for aux in self.aux:
            for role,state in aux.streams.items():
                streams.append(dict(role=role,data=state,fdkey='fd',bufferkey='buffer',log=state['log'],
                    hash=state['hash'],bytes=state['bytes'],pid=aux.process.pid))
            actors.append(aux.process)
        active={};files=[];metadata=[]
        for number,stream in enumerate(streams):
            buf=stream['data'][stream['bufferkey']]
            with (self.base/('fixture-buffer-'+str(number)+'.bin')).open('xb') as f:f.write(buf)
            target=self.base/('fixture-suffix-'+str(number)+'.bin');out=target.open('xb');files.append(out)
            row=dict(role=stream['role'],pid=stream['pid'],original_buffer_size=len(buf),original_buffer_sha256=digest(buf),
                original_stream_bytes=stream['bytes'],original_stream_sha256=stream['hash'].hexdigest(),
                fixture_suffix_file=target.name,fixture_only_independent_drain=True)
            metadata.append(row);fd=stream['data'][stream['fdkey']]
            if type(fd) is int:active[fd]=(stream,out)
        while active:
            for fd in select.select(list(active),[],[],1)[0]:
                stream,out=active[fd]
                try:part=os.read(fd,65536)
                except (BlockingIOError,InterruptedError):continue
                if part:out.write(part)
                else:
                    stream['data'][stream['fdkey']]=None;active.pop(fd);os.close(fd)
        for out in files:out.close()
        results=[]
        for process in actors:
            status=process.wait(timeout=3);self.assertIs(type(status),int)
            self.assertEqual(self.exit_code if self.exit_code else 0,status)
            results.append(dict(pid=process.pid,fixture_actual_same_Popen_final_wait=status))
        for stream in streams:
            log=stream['log']
            if log is not None and not log.closed:io.FileIO.flush(log);io.FileIO.close(log)
        for owner in self.owners:
            op=owner._operation
            if op is not None:
                journal=op.__dict__.get('events')
                if journal is not None and not journal.closed:journal.close()
        for fd in self.extra_fds:os.close(fd)
        with (self.base/'fixture-known-actors.json').open('x') as f:json.dump(dict(actors=results,streams=metadata,
            no_original_buffer_log_replay_or_live_workaround=True),f,indent=2)



class KnownLogSealTests(unittest.TestCase):
    """Finite original-object seals; never actor/physical EX/admission authority."""
    done=KnownStreamWaitTests.done
    release=KnownStreamWaitTests.release
    start_partial=KnownStreamWaitTests.start_partial
    initialized=KnownStreamWaitTests.initialized
    ready=KnownStreamWaitTests.ready
    setUp=KnownStreamWaitTests.setUp
    argv=KnownStreamWaitTests.argv
    new_aux=KnownStreamWaitTests.new_aux
    save=KnownStreamWaitTests.save
    freeze=KnownStreamWaitTests.freeze
    row=KnownStreamWaitTests.row
    advance=KnownStreamWaitTests.advance
    complete_actor=KnownStreamWaitTests.complete_actor
    release_all=KnownStreamWaitTests.release_all
    tearDown=KnownStreamWaitTests.tearDown

    def prepared(self,mixed=True,partial=False):
        if partial:
            owner,op,gate,sentinel,fault=self.start_partial()
        else:owner,op,sentinel,fault=self.initialized(mixed=mixed)
        self.freeze(owner);self.release_all();self.complete_actor(owner,'recipe')
        for index in range(len(op.auxiliary_operations)):self.complete_actor(owner,'auxiliary',index)
        writers=[op.output_log]
        for auxiliary in op.auxiliary_operations:
            writers.extend(auxiliary.streams[name]['log'] for name in ('stdout','stderr'))
        writers.append(op.events)
        self.assertTrue(all(not writer.closed for writer in writers))
        return owner,op,writers,sentinel,fault

    def seal(self,owner):
        self.assertIs(owner.seal_known_actor_logs(),owner);self.done(owner)
        rows=owner.known_log_observations();self.assertIs(type(rows),tuple)
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertTrue(any(type(value) is kind for kind in (str,int,bool,type(None))))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertIs(row[flag],False)
        with (self.base/'seal-before-fixture-cleanup.json').open('x') as f:
            json.dump(dict(rows=[dict(row) for row in rows],lifecycle=[dict(row) for row in owner.worker_lifecycle()],
                producer_pending=owner._operation.pending,producer_finished=owner._operation.finished,
                producer_result_is_none=owner._operation.result is None),f,indent=2)
        return rows

    def test_actual_initialized_recipe_aux_logs_and_journal_close_without_retag(self):
        owner,op,writers,sentinel,fault=self.prepared()
        frozen=owner.known_actor_observations();waited=owner.known_actor_wait_observations()
        with mock.patch.object(producer.CommandProducer,'_end_command',side_effect=AssertionError('end')),\
             mock.patch.object(producer.CommandProducer,'_finish',side_effect=AssertionError('finish')),\
             mock.patch.object(producer.AuxiliaryCommand,'_complete',side_effect=AssertionError('complete')):
            rows=self.seal(owner)
        self.assertEqual(4,len(rows));self.assertTrue(all(w.closed for w in writers))
        self.assertTrue(all(r['close_returned'] is True and r['closed_observed'] is True for r in rows))
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
        self.assertTrue(all(a.pending and not a.finished and a.result is None for a in self.aux))
        self.assertIs(owner._first_error_object,fault);self.assertFalse(sentinel.exists())
        self.assertIs(frozen,owner.known_actor_observations());self.assertEqual(waited,owner.known_actor_wait_observations())
        self.assertTrue(all(a is b for a,b in zip(waited,owner.known_actor_wait_observations())))
        self.assertIs(op.log,writers[0]);self.assertIs(op.events,writers[-1])

    def test_actual_uninitialized_recipe_and_journal_close(self):
        owner,op,writers,sentinel,fault=self.prepared(partial=True)
        rows=self.seal(owner);self.assertEqual(2,len(rows));self.assertTrue(all(w.closed for w in writers))
        self.assertFalse(owner.observe(0)['initialized']);self.assertIs(owner._first_error_object,fault)
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertFalse(sentinel.exists())

    def test_missing_selected_aux_wait_refuses_before_any_writer_IO(self):
        owner,op,sentinel,fault=self.initialized(mixed=True)
        self.freeze(owner);self.release_all();self.complete_actor(owner,'recipe')
        with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
        calls.assert_not_called();self.assertTrue(owner._known_log_quarantined)
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed)
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()

    def test_unknown_read_close_confirmation_is_never_reconstructed(self):
        owner,op,writers,sentinel,fault=self.prepared()
        record=owner._known_wait_bindings[('recipe',0)];stream=record['streams'][0]
        stream['close_confirmed']=None
        with mock.patch.object(type(owner),'_known_log_io') as calls:rows=self.seal(owner)
        calls.assert_not_called();self.assertIsNone(stream['close_confirmed'])
        self.assertTrue(owner._known_log_quarantined);self.assertTrue(all(not w.closed for w in writers))

    def test_flush_failure_never_fsyncs_or_closes(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN explicit flush failure');calls=[]
        def operation(current,index,step):
            calls.append((index,step))
            if step=='flush':raise failure
            return actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertEqual([(0,'flush')],calls);self.assertTrue(all(not w.closed for w in writers))
        self.assertIs(owner._known_log_errors[0][2],failure);self.assertTrue(rows[0]['quarantined'])
        self.assertFalse(rows[0]['close_attempted'])

    def test_fsync_failure_permits_one_actual_close_then_stops(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN fsync failure');calls=[]
        def operation(current,index,step):
            calls.append((index,step))
            if step=='fsync':raise failure
            return actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertEqual([(0,'flush'),(0,'fsync'),(0,'close')],calls)
        self.assertTrue(writers[0].closed);self.assertTrue(all(not w.closed for w in writers[1:]))
        self.assertIs(owner._known_log_errors[0][2],failure)
        self.assertIs(rows[0]['fsync_returned'],False);self.assertIs(rows[0]['close_returned'],True)

    def test_actual_close_then_error_never_recloses(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN after native close');calls=[]
        def operation(current,index,step):
            calls.append((index,step));result=actual(current,index,step)
            if step=='close':raise failure
            return result
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertTrue(writers[0].closed);self.assertEqual(1,calls.count((0,'close')))
        self.assertIs(rows[0]['close_returned'],False);self.assertIs(rows[0]['closed_observed'],True)
        index=owner._index
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertEqual(index,owner._index);self.assertIs(owner._known_log_errors[0][2],failure)

    def test_normal_close_return_with_open_objects_quarantines(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io
        def operation(current,index,step):
            return None if step=='close' else actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertFalse(writers[0].closed);self.assertIs(rows[0]['close_returned'],True)
        self.assertIs(rows[0]['closed_observed'],False);self.assertTrue(rows[0]['quarantined'])

    def test_callback_pending_drift_refuses_before_native_writer_IO(self):
        owner,op,writers,sentinel,fault=self.prepared()
        self.actions['callback']=lambda:setattr(op,'pending',False)
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            calls.assert_not_called();self.assertTrue(all(not w.closed for w in writers))
        finally:self.actions.pop('callback',None);op.pending=True

    def test_writer_alias_refuses_without_close(self):
        owner,op,writers,sentinel,fault=self.prepared()
        original=op.events;op.events=op.log
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            calls.assert_not_called();self.assertFalse(op.log.closed)
        finally:op.events=original

    def test_namespace_collision_is_permanently_terminal(self):
        owner,op,writers,sentinel,fault=self.prepared()
        namespace=op.directory/'owned-known-logs';namespace.mkdir()
        with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
        calls.assert_not_called();self.assertTrue(namespace.is_dir())
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertTrue(all(not w.closed for w in writers))

    def test_flush_primary_cache_secondary_exact_private_no_exception_hooks(self):
        owner,op,writers,sentinel,fault=self.prepared()
        hooks=[]
        class HookError(OSError):
            def __repr__(self):hooks.append('repr');raise AssertionError('repr')
            def __str__(self):hooks.append('str');raise AssertionError('str')
            def add_note(self,note):hooks.append('note');raise AssertionError('note')
        primary=HookError(5,'OWN first flush');secondary=ValueError('OWN failed cache')
        actual=type(owner)._cache_known_logs
        def cache(current,stage):
            if stage=='failed':raise secondary
            return actual(current,stage)
        with mock.patch.object(type(owner),'_known_log_io',side_effect=primary),\
             mock.patch.object(type(owner),'_cache_known_logs',cache):
            self.seal(owner)
        self.assertIs(owner._known_log_errors[0][2],primary);self.assertIs(owner._known_log_errors[-1][2],secondary)
        self.assertIs(owner._workers[-1]['_call_error_object'],primary);self.assertEqual([],hooks)
        self.assertTrue(all(not w.closed for w in writers))
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()

    def test_busy_worker_observer_outside_IO_lock_and_terminal_refusal(self):
        owner,op,writers,sentinel,fault=self.prepared()
        entered=self.threading.Event();release=self.threading.Event();self.barriers.append(release)
        def callback():
            self.assertTrue(owner._lock.acquire(False));owner._lock.release()
            entered.set();release.wait(3)
        self.actions['callback']=callback
        owner.seal_known_actor_logs();self.assertTrue(entered.wait(2))
        owner.known_log_observations();index=owner._index
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertEqual(index,owner._index);release.set();self.done(owner);self.actions.pop('callback',None)
        self.assertTrue(all(w.closed for w in writers))
        with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('recipe',0,0)

    def test_success_keeps_exact_writer_refs_and_refuses_all_pipeline_actions(self):
        owner,op,writers,sentinel,fault=self.prepared()
        self.seal(owner);index=owner._index
        for action in (lambda:owner.seal_known_actor_logs(),lambda:owner.continue_wait(0),
            lambda:owner.continue_known_actor_wait('auxiliary',0,0),lambda:owner.freeze_known_actors()):
            with self.assertRaises(producer.ProducerError):action()
        self.assertEqual(index,owner._index);self.assertTrue(all(w.closed for w in writers))
        self.assertFalse(sentinel.exists());self.assertIs(op.output_log,writers[0]);self.assertIs(op.events,writers[-1])

    def test_callback_dropped_private_stream_group_cannot_hide_raw_buffer_drift(self):
        owner,op,writers,sentinel,fault=self.prepared()
        record=owner._known_wait_bindings[('recipe',0)]
        original=record['streams'];buffer=op.output_buffer
        def callback():
            if owner._known_log_writers:
                record['streams']=[]
                op.output_buffer=b'OWN-SYNTHETIC-unwritten-marker'
        self.actions['callback']=callback
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            observed=dict(writer_IO_attempts=[list(call.args) for call in calls.call_args_list],
                current_private_streams=len(record['streams']),synthetic_raw_buffer_size=len(op.output_buffer),
                writer_closed_before_fixture_cleanup=[writer.closed for writer in writers],
                negative_writer_IO_mocked=True,no_original_buffer_or_log_replay=True)
            with (self.base/'dropped-stream-control.json').open('x') as f:json.dump(observed,f,indent=2)
            calls.assert_not_called()
            self.assertTrue(all(not w.closed for w in writers));self.assertTrue(owner._known_log_quarantined)
        finally:
            self.actions.pop('callback',None);record['streams']=original;op.output_buffer=buffer

    def test_callback_unknown_private_role_never_calls_custom_equality(self):
        owner,op,writers,sentinel,fault=self.prepared()
        record=owner._known_wait_bindings[('recipe',0)];original=record['role'];hooks=[]
        class Role:
            def __eq__(self,value):hooks.append('eq');return value=='recipe'
        foreign=Role()
        def callback():
            if owner._known_log_writers:record['role']=foreign
        self.actions['callback']=callback
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            with (self.base/'unknown-role-control.json').open('x') as f:
                json.dump(dict(hooks=hooks,writer_IO_attempts=[list(c.args) for c in calls.call_args_list]),f,indent=2)
            self.assertEqual([],hooks);calls.assert_not_called()
        finally:self.actions.pop('callback',None);record['role']=original

    def test_callback_unknown_recipe_key_is_typed_before_dictionary_lookup(self):
        owner,op,writers,sentinel,fault=self.prepared()
        source=op.records[-1];original=dict(source);hooks=[]
        class Key:
            def __hash__(self):return hash('output_read_errors')
            def __eq__(self,value):hooks.append('eq');return False
        key=Key();changed=[]
        def callback():
            if owner._known_log_writers and not changed:
                source.pop('output_read_errors',None);source[key]=None;changed.append(True);hooks.clear()
        self.actions['callback']=callback
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            with (self.base/'unknown-record-key-control.json').open('x') as f:
                json.dump(dict(hooks=hooks,writer_IO_attempts=[list(c.args) for c in calls.call_args_list]),f,indent=2)
            self.assertEqual([],hooks);calls.assert_not_called()
        finally:self.actions.pop('callback',None);source.clear();source.update(original)





class ReceiptErrorRetentionTests(unittest.TestCase):
    """New exact-error controls; finite FIXTURE shims are never SDK evidence."""
    start=ProducerTests.start
    finish=ProducerTests.finish
    make_tool=ProducerTests.make_tool
    receipt_fixture=ProducerTests.receipt_fixture

    def setUp(self):
        self.setup_children=[];self.setup_records=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        number=len(self.setup_records)
        child=subprocess.Popen(['git','-C',str(self.repo),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.setup_children.append(child)
        stdout,stderr=child.communicate();status=child.wait()
        row=dict(pid=child.pid,argv=list(args),status=status,stdout_eof=True,stderr_eof=True)
        for name,data in [('stdout',stdout),('stderr',stderr)]:
            with (self.base/('setup-'+str(number)+'-'+name+'.bin')).open('xb') as f:f.write(data)
            row[name+'_size']=len(data);row[name+'_sha256']=digest(data)
        self.setup_records.append(row)
        self.assertEqual(0,status)
        return stdout

    def hooks(self):
        calls=[]
        class HookTrip(RuntimeError):pass
        class HookError(OSError):
            def __repr__(self):calls.append('repr');raise HookTrip('OWN repr hook')
            def __str__(self):calls.append('str');raise HookTrip('OWN str hook')
            def add_note(self,note):calls.append('note');raise HookTrip('OWN note hook')
        return calls,HookError

    def capture(self,run,primary,invoke,hooks,extra=None):
        caught=None
        try:invoke()
        except BaseException as error:caught=error
        first=run.__dict__.get('_receipt_primary_error_object')
        secondaries=run.__dict__.get('_receipt_secondary_error_objects',[])
        path=run.directory/'receipt-failure.json'
        public=path.read_bytes() if path.exists() else None
        row=dict(caught_type=None if caught is None else type.__getattribute__(type(caught),'__name__'),
            caught_is_primary=caught is primary,retained_first_is_primary=first is primary,
            primary_stage=run.__dict__.get('_receipt_primary_error_stage'),hooks=list(hooks),
            secondary_stages=[entry[0] for entry in secondaries],
            secondary_types=[type.__getattribute__(type(entry[1]),'__name__') for entry in secondaries],
            receipt_attempted=run.receipt_attempted,
            public_failure_hex=None if public is None else public.hex(),
            public_failure_sha256=None if public is None else digest(public),
            no_input_receipt=not (run.directory/'input-receipt.json').exists(),
            no_binding=not (run.directory/'receipt-binding.json').exists())
        if extra is not None:row.update(extra())
        with (self.base/'error-control-before-cleanup.json').open('x') as f:json.dump(row,f,indent=2)
        return caught,secondaries,public

    def assert_first(self,run,primary,caught,hooks):
        self.assertTrue(caught is primary)
        self.assertTrue(run.__dict__.get('_receipt_primary_error_object') is primary)
        self.assertEqual([],hooks);self.assertTrue(run.receipt_attempted)
        self.assertFalse((run.directory/'input-receipt.json').exists())
        self.assertFalse((run.directory/'receipt-binding.json').exists())

    def test_source_primary_never_calls_repr_str_or_add_note(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks();primary=Error(5,'OWN private source failure')
        with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary):
            caught,secondary,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
        self.assert_first(run,primary,caught,hooks)
        self.assertEqual([],secondary)
        self.assertEqual({'primary_error':'HookError','terminal':True},json.loads(raw))

    def test_partial_failure_publication_keeps_primary_secondary_and_no_retry(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN source');secondary=Error(28,'OWN publication');writes=[];actual=producer._receipt_resource_io
        def operation(resource,step,value=None):
            if resource['role']=='failure' and step=='write':
                writes.append('publication');os.write(resource['fd'],b'OWN-partial-failure');raise secondary
            return actual(resource,step,value)
        try:
            with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary),\
                 mock.patch.object(producer,'_receipt_resource_io',operation):
                caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
            self.assert_first(run,primary,caught,hooks)
            self.assertEqual(b'OWN-partial-failure',raw);self.assertEqual(['publication'],writes)
            self.assertEqual('failure_publication',errors[-1][0]);self.assertTrue(errors[-1][1] is secondary)
            with mock.patch.object(producer,'_regular_hash',side_effect=AssertionError('second artifact read')):
                with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
            self.assertEqual(b'OWN-partial-failure',(run.directory/'receipt-failure.json').read_bytes())
        finally:
            # Fixture-only close of exact own unattempted raw FD; no live recovery.
            for resource in run._receipt_resources:
                if resource['role']=='failure' and not resource['close_attempted']:
                    info=os.fstat(resource['fd']);path=resource['path'].stat()
                    self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino));os.close(resource['fd'])

    def audit_close(self,body_error):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN source body') if body_error else None
        close_error=Error(5,'OWN after actual audit close');closed=[]
        actual=producer._receipt_resource_io
        def operation(resource,step,value=None):
            result=actual(resource,step,value)
            if resource['role']=='source_audit' and step=='close':
                closed.append(True);raise close_error
            return result
        def source_guard(current,observe=None):
            if primary is not None:raise primary
        wanted=primary if primary is not None else close_error
        with mock.patch.object(producer,'_receipt_resource_io',operation),mock.patch.object(producer.CommandProducer,'_source_guard',source_guard):
            caught,errors,raw=self.capture(run,wanted,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks,
                lambda:dict(actual_audit_close_returned=list(closed),raw_FD_close_seam=True))
        self.assert_first(run,wanted,caught,hooks);self.assertEqual([True],closed)
        if body_error:self.assertTrue(errors[0][1] is close_error)
        else:self.assertEqual([],errors)
        self.assertTrue(raw is None) # Unknown close suppresses further failure-artifact IO.

    def test_actual_audit_close_secondary_never_replaces_source_primary(self):
        self.audit_close(True)

    def test_actual_audit_close_without_body_error_is_exact_primary(self):
        self.audit_close(False)

    def copy_failure(self,close_fd=False,close_output=False,open_input=False):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN copy read');fd_error=Error(5,'OWN after FD close');out_error=Error(5,'OWN after output close')
        closed=[];output_closed=[];actual=producer._receipt_resource_io
        def operation(resource,step,value=None):
            incoming=resource['role'].startswith('copy_input-')
            if incoming and step=='open' and open_input:raise primary
            if incoming and step=='read':raise primary
            result=actual(resource,step,value)
            if incoming and step=='close':
                closed.append(resource['fd'])
                if close_fd:raise fd_error
            if resource['role']=='complete_log' and step=='close':
                output_closed.append(True)
                if close_output:raise out_error
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks,
                lambda:dict(actual_fd_close_count=len(closed),actual_output_close_returned=list(output_closed),raw_FD_seams=True))
        self.assert_first(run,primary,caught,hooks);self.assertEqual(0 if open_input else 1,len(closed))
        if close_fd:self.assertTrue(any(error is fd_error for stage,error in errors))
        if close_output:
            self.assertTrue(any(error is out_error for stage,error in errors));self.assertEqual([True],output_closed)
        if close_fd or close_output or open_input:self.assertTrue(raw is None)
        else:self.assertEqual('HookError',json.loads(raw)['primary_error'])

    def test_copy_read_primary_survives_actual_FD_close_secondary(self):
        self.copy_failure(close_fd=True)

    def test_earliest_copy_error_survives_actual_output_context_close(self):
        self.copy_failure(close_fd=True,close_output=True)

    def test_same_primary_object_at_publication_retains_secondary_occurrence(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks();primary=Error(5,'OWN repeated object')
        actual=producer._receipt_resource_io
        def operation(resource,step,value=None):
            if resource['role']=='failure' and step=='write':raise primary
            return actual(resource,step,value)
        try:
            with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary),mock.patch.object(producer,'_receipt_resource_io',operation):
                caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
            self.assert_first(run,primary,caught,hooks)
            self.assertTrue(raw is not None and raw==b'');self.assertEqual(1,len(errors))
            self.assertEqual('failure_publication',errors[0][0]);self.assertTrue(errors[0][1] is primary)
        finally:
            for resource in run._receipt_resources:
                if resource['role']=='failure' and not resource['close_attempted']:
                    info=os.fstat(resource['fd']);path=resource['path'].stat()
                    self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino));os.close(resource['fd'])

    def tearDown(self):
        actors=[];streams=[];command_records=[]
        for run in self.runs:
            self.assertFalse(run.pending);self.assertTrue(run.finished)
            command_records.extend(dict(record) for record in run.records)
            processes=[('last_recipe_only',run.process)]
            for index,auxiliary in enumerate(run.auxiliary_operations):
                self.assertTrue(auxiliary.finished)
                processes.append(('auxiliary-'+str(index),auxiliary.process))
                for role,stream in auxiliary.streams.items():
                    self.assertTrue(stream['eof']);self.assertIsNone(stream['fd'])
                    path=stream['path'];fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
                    try:
                        first=os.fstat(fd);parts=[]
                        self.assertLessEqual(first.st_size,2*1024**2)
                        while True:
                            part=os.read(fd,65536)
                            if not part:break
                            parts.append(part)
                        raw=b''.join(parts);after=os.fstat(fd);info=path.stat()
                        identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
                        self.assertEqual(identity(first),identity(after));self.assertEqual(identity(first),identity(info))
                    finally:os.close(fd)
                    self.assertEqual(stream['bytes'],len(raw));self.assertEqual(stream['hash'].hexdigest(),digest(raw))
                    streams.append(dict(auxiliary_index=index,role=role,pid=auxiliary.process.pid,eof=stream['eof'],
                        fd_is_none=stream['fd'] is None,path=path.relative_to(self.base).as_posix(),
                        size=len(raw),sha256=digest(raw),held_before_after_path_identity=identity(first)))
            for role,process in processes:
                status=process.wait(timeout=2);self.assertIs(type(status),int);self.assertEqual(0,status)
                actors.append(dict(role=role,pid=process.pid,actual_same_Popen_final_wait=status))
        with (self.base/'new-known-actors.json').open('x') as f:
            json.dump(dict(setup_Git=self.setup_records,actors=actors,streams=streams,reported_command_records=command_records,
                previous_command_Popen_handles_NOT_retained_or_reconstructed=True,all_recorded_final_wait_statuses_zero=True,
                no_live_workaround=True,not_complete_descendant_instruction_or_FDclosure=True),f,indent=2)

    def test_input_open_primary_survives_actual_output_context_close(self):
        self.copy_failure(open_input=True,close_output=True)

    def test_ambient_handled_exception_is_not_a_receipt_primary(self):
        run,_,_,_=self.receipt_fixture()
        ambient=RuntimeError('OWN caller handled exception')
        try:raise ambient
        except RuntimeError:
            receipt=producer.emit_fixture_receipt(run,'canonical')
        row=dict(receipt_kind=receipt['kind'],
            ambient_wrongly_retained=run.__dict__.get('_receipt_primary_error_object') is ambient,
            first_is_none=run.__dict__.get('_receipt_primary_error_object') is None,
            secondary_count=len(run.__dict__.get('_receipt_secondary_error_objects',[])),
            fixture_only_not_actual_canonical=True)
        with (self.base/'ambient-context-control.json').open('x') as f:json.dump(row,f,indent=2)
        self.assertEqual('fixture-canonical-v1',receipt['kind'])
        self.assertTrue(run.__dict__.get('_receipt_primary_error_object') is None)
        self.assertEqual([],run.__dict__.get('_receipt_secondary_error_objects',[]))




class ReceiptResourceTests(unittest.TestCase):
    """New raw-resource controls; none establish live/SDK/physical admission."""
    receipt_fixture=ProducerTests.receipt_fixture
    finish=ProducerTests.finish
    make_tool=ProducerTests.make_tool
    git=ReceiptErrorRetentionTests.git

    def setUp(self):
        self.setup_children=[];self.setup_records=[];self.actions={};self.current_run=None
        self.fixture_fd_closes=[]
        ProducerTests.setUp(self)

    def start(self,*modes,**overrides):
        overrides['lease_check']=self.lease_check
        return ProducerTests.start(self,*modes,**overrides)

    def lease_check(self):
        action=self.actions.get('callback')
        if action is not None:action()

    def prepared(self):
        run,_,_,_=self.receipt_fixture();self.current_run=run
        return run

    def rows(self,run):
        rows=[]
        for resource in run.__dict__.get('_receipt_resources',[]):
            error=resource['first_error']
            rows.append(dict(role=resource['role'],path=resource['path'].name,direction=resource['direction'],
                fd=resource['fd'],open_attempted=resource['open_attempted'],open_returned=resource['open_returned'],
                close_attempted=resource['close_attempted'],close_returned=resource['close_returned'],
                offset=resource['offset'],write_uncertain=resource['write_uncertain'],read_uncertain=resource['read_uncertain'],
                pending_size=None if resource['pending_payload'] is None else len(resource['pending_payload']),
                pending_offset=resource['pending_offset'],quarantined=resource['quarantined'],
                first_error_type=None if error is None else type.__getattribute__(type(error),'__name__'),
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
        return rows

    def capture(self,run,invoke,extra=None):
        caught=None;result=None
        try:result=invoke()
        except BaseException as error:caught=error
        value=dict(rows=self.rows(run),error_type=None if caught is None else type.__getattribute__(type(caught),'__name__'),
            result_kind=None if result is None else result.get('kind'),
            quarantined=run.__dict__.get('_receipt_resources_quarantined'),
            failure_file_exists=(run.directory/'receipt-failure.json').exists(),
            receipt_attempted=run.receipt_attempted)
        if extra is not None:value.update(extra())
        with (self.base/'resource-control-before-cleanup.json').open('x') as out:json.dump(value,out,indent=2)
        return caught,result,value

    def resource(self,run,role):
        return next(row for row in run._receipt_resources if row['role']==role)

    def test_postwrite_fault_never_replays_audit_bytes_or_closes_uncertain_output(self):
        import io
        run=self.prepared();target=[];writes=[];native_open=Path.open;native_os_open=os.open;native_write=os.write
        failure=OSError(5,'OWN after actual raw metadata write');detached=[]
        class Raw(io.RawIOBase):
            def __init__(self,actual):self.actual=actual
            def writable(self):return True
            def fileno(self):return self.actual.fileno()
            def write(self,data):return os.write(self.actual.fileno(),data)
            def close(self):
                if not self.closed:self.actual.close()
                return super().close()
        def opening(path,*args,**kwargs):
            writer=native_open(path,*args,**kwargs)
            if path.name=='receipt-source-audit.jsonl' and args and args[0]=='xb':
                if type(writer) is io.BufferedWriter:
                    actual=writer.detach();detached.append(writer);target.append(actual.fileno())
                    return io.BufferedWriter(Raw(actual))
                target.append(writer.fileno())
            return writer
        def opening_fd(path,*args,**kwargs):
            fd=native_os_open(path,*args,**kwargs)
            if Path(path).name=='receipt-source-audit.jsonl':target.append(fd)
            return fd
        def write(fd,data):
            count=native_write(fd,data)
            if target and fd==target[-1]:
                writes.append(bytes(data))
                if len(writes)==1:raise failure
            return count
        def source_guard(current,observe=None):
            self.assertTrue(callable(observe));observe('status','--porcelain')
        with mock.patch.object(Path,'open',opening),mock.patch.object(producer.os,'open',opening_fd),\
             mock.patch.object(producer.os,'write',write),mock.patch.object(producer.CommandProducer,'_source_guard',source_guard):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_raw_write_calls=len(writes),written_piece_sizes=[len(part) for part in writes],
                    audit_file_sha256=digest((run.directory/'receipt-source-audit.jsonl').read_bytes()),
                    before_BufferedWriter_over_controlledRaw_actualFileIO=True))
        self.assertTrue(caught is failure);self.assertEqual(1,len(writes))
        resource=self.resource(run,'source_audit')
        self.assertTrue(resource['write_uncertain']);self.assertFalse(resource['close_attempted'])
        self.assertFalse((run.directory/'receipt-failure.json').exists())

    def test_all_receipt_resources_retained_retired_and_JSON_bytes_equivalent(self):
        run=self.prepared();caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'))
        self.assertIsNone(caught);self.assertEqual('fixture-canonical-v1',result['kind'])
        roles={row['role'] for row in run._receipt_resources}
        self.assertTrue({'attempt','source_audit','complete_log','input_receipt','binding'}<=roles)
        self.assertTrue(all(row['close_returned'] is True for row in run._receipt_resources))
        for name in ('receipt-attempt.json','input-receipt.json','receipt-binding.json'):
            raw=(run.directory/name).read_bytes()
            self.assertEqual((json.dumps(json.loads(raw),sort_keys=True,indent=2)+'\n').encode(),raw)
        for line in (run.directory/'receipt-source-audit.jsonl').read_bytes().splitlines():
            self.assertEqual(json.dumps(json.loads(line),sort_keys=True).encode(),line)
        self.assertTrue(all(row['actor_ownership_complete'] is None for row in value['rows']))

    def test_record_and_exact_FD_are_retained_before_following_callback(self):
        run=self.prepared();actual=producer._receipt_resource_io;observed=[]
        def operation(resource,step,value=None):
            if step=='open':
                self.assertTrue(any(item is resource for item in run._receipt_resources))
                self.assertIsNone(resource['fd'])
            return actual(resource,step,value)
        def callback():
            for resource in run._receipt_resources:
                if resource['open_returned'] is True and resource['identity'] is None:
                    self.assertIs(type(resource['fd']),int);observed.append(resource['role'])
        self.actions['callback']=callback
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(observed_FD_before_callback=list(observed)))
        self.assertIsNone(caught);self.assertIn('attempt',observed);self.assertIn('source_audit',observed)

    def test_known_short_write_advances_only_unwritten_suffix(self):
        run=self.prepared();actual=producer._receipt_resource_io;pieces=[]
        def operation(resource,step,value=None):
            if resource['role']=='attempt' and step=='write':
                pieces.append(bytes(value))
                if len(pieces)==1:return actual(resource,step,value[:3])
            return actual(resource,step,value)
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(piece_sizes=[len(part) for part in pieces],suffix_correct=len(pieces)>1 and pieces[1]==pieces[0][3:]))
        self.assertIsNone(caught);self.assertEqual(2,len(pieces));self.assertEqual(pieces[0][3:],pieces[1])

    def test_fsync_failure_allows_one_known_close_and_first_error(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN metadata fsync');closes=[]
        def operation(resource,step,value=None):
            if resource['role']=='source_audit' and step=='fsync':raise failure
            result=actual(resource,step,value)
            if resource['role']=='source_audit' and step=='close':closes.append(resource['fd'])
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_same_audit_close_count=len(closes)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(closes))
        self.assertTrue(self.resource(run,'source_audit')['close_returned'])
        self.assertEqual('OSError',json.loads((run.directory/'receipt-failure.json').read_bytes())['primary_error'])

    def test_actual_close_then_error_is_never_reclosed_or_followed_by_publication(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN after metadata close');closes=[]
        def operation(resource,step,value=None):
            result=actual(resource,step,value)
            if resource['role']=='source_audit' and step=='close':
                closes.append(resource['fd']);raise failure
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_close_calls=len(closes)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(closes))
        resource=self.resource(run,'source_audit');self.assertFalse(resource['close_returned'])
        self.assertFalse((run.directory/'receipt-failure.json').exists())
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            producer._receipt_resource_close(run,resource,failure)
        calls.assert_not_called()

    def test_input_close_uncertainty_prevents_next_copy_input_open(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN input close uncertainty');opened=[]
        def operation(resource,step,value=None):
            if step=='open':opened.append(resource['role'])
            result=actual(resource,step,value)
            if resource['role']=='copy_input-000' and step=='close':raise failure
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(opened_roles=list(opened)))
        self.assertTrue(caught is failure);self.assertNotIn('copy_input-001',opened)
        self.assertFalse((run.directory/'receipt-failure.json').exists())

    def test_second_emit_refuses_before_resource_IO(self):
        run=self.prepared();producer.emit_fixture_receipt(run,'canonical')
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        calls.assert_not_called()

    def tearDown(self):
        self.actions.pop('callback',None)
        for run in self.runs:
            for resource in run.__dict__.get('_receipt_resources',[]):
                if type(resource['fd']) is not int or resource['close_attempted']:continue
                # NEW finite-unit-only known-FD cleanup, never controller permission.
                info=os.fstat(resource['fd']);path=resource['path'].stat()
                self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino))
                os.close(resource['fd']);self.fixture_fd_closes.append(dict(role=resource['role'],
                    fd=resource['fd'],fixture_only_close_returned=True,source_flags_not_retagged=True))
        with (self.base/'fixture-only-resource-closes.json').open('x') as out:json.dump(self.fixture_fd_closes,out,indent=2)
        ReceiptErrorRetentionTests.tearDown(self)


if __name__=='__main__':unittest.main()


class CommandOutputCompletionTests(unittest.TestCase):
    """Actual finite OWN direct children; no orphan descendants or benchmark."""
    def setUp(self):
        self.fixture=ProducerTests('runTest');self.fixture.setUp()
        self.base=self.fixture.base
        self.extra=[];self.release=self.base/'release-output-writer'
        self.ready=self.base/'output-writer-ready'

    def tearDown(self):
        self.release.touch(exist_ok=True)
        statuses=[]
        for child in self.extra:
            statuses.append({'pid':child.pid,'returncode':child.wait(5),'role':'OWN separately parented command-output writer'})
        self.fixture.tearDown()
        for run in self.fixture.runs:
            statuses.append({'pid':run.child_pid,'returncode':run.process.returncode,'role':'OWN recipe direct child'})
        (self.base/'owned-output-actors.json').write_text(json.dumps({'scope':'finite OWN direct Popen actors only, not descendants/kernel/capture','actors':statuses}))

    def start_with_writer(self,mode='ok',next_command=True):
        real_popen=producer.subprocess.Popen
        actual_initializer=producer.CommandProducer._initialize_command_process
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:])
ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-stdout\\n');os.write(2,b'late-owned-stderr\\n')
"""
        def initialize(current,initializer,process,arguments):
            argv=arguments[0];writer=arguments[3]
            if list(argv)==[sys.executable,'worker.py',mode]:
                child=real_popen([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=writer,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,close_fds=True)
                self.extra.append(child)
            return actual_initializer(current,initializer,process,arguments)
        with mock.patch.object(producer.CommandProducer,'_initialize_command_process',initialize):
            run=self.fixture.start((mode,),('ok',)) if next_command else self.fixture.start((mode,))
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        return run

    def test_command_output_exit_before_eof_blocks_next_and_receipt(self):
        run=self.start_with_writer()
        self.assertEqual(0,run.process.wait(2))
        self.assertIsNone(run.wait(0),'direct exit cannot finalize while an actual OWN output writer holds stdout')
        self.assertTrue(run.pending);self.assertEqual(1,len(run.records))
        with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'receipt-attempt.json').exists())
        self.release.touch()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertEqual(2,len(result['commands']))
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertIn(b'late-owned-stdout',raw);self.assertIn(b'late-owned-stderr',raw)
        self.assertTrue(result['commands'][0]['output_eof'])
        self.assertFalse(result['commands'][0]['whole_descendant_exit_proven'])

    def test_command_output_nonzero_waits_writer_without_next_command(self):
        run=self.start_with_writer('nonzero')
        self.assertEqual(7,run.process.wait(2))
        self.assertIsNone(run.wait(0))
        self.assertEqual(7,run.records[0]['returncode'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn(b'late-owned-stderr',(run.directory/'command-000.log').read_bytes())

    def test_command_output_large_pipe_drains_without_wait_deadlock(self):
        code="import os;data=b'A'*65536;[os.write(1,data) for _ in range(40)];os.write(2,b'END')"
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code]])
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status'])
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(40*65536+3,len(raw));self.assertEqual(digest(raw),result['commands'][0]['log_sha256'])
        self.assertTrue(result['commands'][0]['output_eof'])

    def test_command_output_eof_before_exit_keeps_child_owned(self):
        code="""import os,sys,time
from pathlib import Path
os.close(1);os.close(2)
ready,release=map(Path,sys.argv[1:]);ready.write_text('closed')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
"""
        run=self.fixture.start(('ok',),commands=[[sys.executable,'-c',code,str(self.ready),str(self.release)]])
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists())
        self.assertIsNone(run.wait(.03));self.assertIsNone(run.process.returncode);self.assertTrue(run.pending)
        self.assertTrue(run.records[0]['output_eof'])
        self.release.touch();result=self.fixture.finish(run)
        self.assertEqual(0,result['commands'][0]['returncode']);self.assertEqual('success',result['status'])


    def test_command_output_later_read_error_preserves_first_journal_failure(self):
        original=producer.CommandProducer._event
        def event(run,kind,**fields):
            if kind=='command_spawned':raise OSError(13,'PRIMARY postspawn journal fault')
            return original(run,kind,**fields)
        with mock.patch.object(producer.CommandProducer,'_event',event):run=self.fixture.start(('ok',),('ok',))
        original_read=producer.os.read;fd=run.output_fd
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY pipe read fault')
            return original_read(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))
        self.assertIn('PRIMARY',result['error'])
        self.assertTrue(any('SECONDARY' in x for x in result['commands'][0]['secondary_errors']))
        self.assertFalse(result['commands'][0]['log_complete'])

    def test_command_output_short_writes_keep_bytes_and_fd_flags(self):
        run=self.fixture.start(('large',));original=run.output_log
        self.assertFalse(os.get_inheritable(run.output_fd));self.assertFalse(os.get_blocking(run.output_fd))
        class Short:
            def write(self,data):return original.write(data[:17])
        run.output_log=Short()
        result=self.fixture.finish(run)
        self.assertEqual('success',result['status']);self.assertIsNone(run.output_fd)
        raw=(run.directory/'command-000.log').read_bytes()
        self.assertEqual(b'A'*9000+b'B'*7000,raw)
        self.assertTrue(result['commands'][0]['parent_output_write_close_confirmed'])

    def test_command_output_eof_close_error_consumes_fd_once(self):
        run=self.fixture.start(('ok',));fd=run.output_fd;original_close=producer.os.close;calls=[]
        def close(target):
            if target==fd:
                calls.append(target);original_close(target);raise OSError(5,'uncertain EOF descriptor close')
            return original_close(target)
        with mock.patch.object(producer.os,'close',close):self.assertIsNone(run.wait(2))
        result=self.fixture.finish(run)
        self.assertEqual([fd],calls);self.assertIsNone(run.output_fd)
        self.assertEqual('failed',result['status']);self.assertEqual(0,run.records[0]['returncode'])
        self.assertIn('uncertain EOF descriptor close',result['error'])

    def test_command_output_write_failure_quarantines_without_replay(self):
        run=self.fixture.start(('large',));original=run.output_log;calls=[]
        class Fault:
            def write(self,data):calls.append(len(data));raise OSError(28,'injected log-space fault')
        run.output_log=Fault()
        try:
            self.assertIsNone(run.wait(2));fd=run.output_fd
            self.assertTrue(run.output_write_uncertain);self.assertTrue(run.output_buffer)
            self.assertIsNone(run.wait(0));self.assertEqual(1,len(calls))
            self.assertEqual(fd,run.output_fd);self.assertTrue(run.pending)
            self.assertFalse(run.evidence_complete);self.assertFalse((run.directory/'result.json').exists())
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
            raw=json.loads((run.directory/'failure.json').read_text())
            self.assertEqual(run.output_buffer,base64.b64decode(raw['unwritten_output_base64']))
        finally:
            # Tiny finite OWN child fits available pipe capacity: no kill/cancel,
            # no producer recovery, no live cleanup workaround or success receipt.
            status=run.process.wait(3)
            (self.base/'fixture-quarantined-output.json').write_text(json.dumps({
                'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit; producer stays quarantined/unadmitted',
                'pid':run.child_pid,'returncode':status,'unwritten_sha256':digest(run.output_buffer),
                'unwritten_base64':base64.b64encode(run.output_buffer).decode('ascii')}))
            self.extra.append(run.process)
            fd=run.output_fd;run.output_fd=None
            if fd is not None:os.close(fd)
            original.close();run.log=None;run.output_log=None
            if run.events is not None:run.events.close();run.events=None
            self.fixture.runs.remove(run)


    def test_command_output_partial_failure_evidence_never_retried(self):
        original_event=producer.CommandProducer._event;original_write=producer._write_json;calls=[]
        def event(run,event_name,**fields):
            if event_name=='command_spawned':raise OSError(13,'PRIMARY journal fault')
            return original_event(run,event_name,**fields)
        def write(path,value):
            if Path(path).name=='failure.json':
                calls.append(str(path))
                if len(calls)==1:
                    with Path(path).open('xb') as f:f.write(b'PARTIAL-ORIGINAL-FAILURE')
                    raise OSError(28,'secondary failure-publication space error')
            return original_write(path,value)
        with mock.patch.object(producer.CommandProducer,'_event',event),mock.patch.object(producer,'_write_json',write):
            run=self.fixture.start(('ok',),('ok',));fd=run.output_fd;real_read=producer.os.read
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY stream fault')
                return real_read(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(run.wait(2))
            result=self.fixture.finish(run)
        self.assertEqual(1,len(calls));self.assertIn('PRIMARY',result['error'])
        self.assertEqual(b'PARTIAL-ORIGINAL-FAILURE',(run.directory/'failure.json').read_bytes())
        self.assertEqual('failed',result['status']);self.assertEqual(1,len(run.records))


class GitOutputTests(unittest.TestCase):
    """Actual OWN Git/extra finite writers, separate output endpoints, no orphan."""
    def setUp(self):
        self.f=ProducerTests('runTest');self.f.setUp();self.base=self.f.base
        self.actors=[];self.release=self.base/'release-git-writer';self.ready=self.base/'git-writer-ready'
        self.threads=[];self.parent=None;self.operations=[]

    def tearDown(self):
        self.release.touch(exist_ok=True)
        for thread in self.threads:
            thread.join(6)
            self.assertFalse(thread.is_alive(),'OWN finite observer thread must finish naturally')
        for operation in self.operations:
            if operation.pending:self.finish_auxiliary(operation)
            if operation.process is not None:self.actors.append(operation.process)
        statuses=[{'pid':child.pid,'returncode':child.wait(5)} for child in self.actors]
        self.f.tearDown()
        if self.parent is not None and self.parent.events is not None:self.parent.events.close();self.parent.events=None
        (self.base/'owned-git-output-actors.json').write_text(json.dumps({'scope':'OWN main-parented finite Popen actors only; no descendants/kernel/capture','statuses':statuses}))

    def gate_observation(self,call,match):
        import threading,time
        real=producer.subprocess.Popen;selected=[];outcome={};done=threading.Event()
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:]);ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-git-output\\n');os.write(2,b'late-owned-git-stderr\\n')
"""
        def popen(argv,*args,**kw):
            if not selected and match(list(argv)):
                writer=real([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=kw['stdout'],stderr=kw['stderr'],stdin=subprocess.DEVNULL,close_fds=True)
                self.actors.append(writer)
                child=real(argv,*args,**kw);selected.append(child);self.actors.append(child)
                return child
            return real(argv,*args,**kw)
        def observe():
            try:outcome['value']=call()
            except BaseException as error:outcome['error']=error
            finally:done.set()
        with mock.patch.object(producer.subprocess,'Popen',popen):
            thread=threading.Thread(target=observe);self.threads.append(thread);thread.start()
            try:
                end=time.monotonic()+2
                while (not self.ready.exists() or not selected) and time.monotonic()<end:time.sleep(.005)
                self.assertTrue(selected);self.assertTrue(self.ready.exists())
                self.assertEqual(0,selected[0].wait(2))
                self.assertFalse(done.wait(.10),'Git observation completed before actual retained stdout/stderr writer EOF')
            finally:
                self.release.touch(exist_ok=True);thread.join(6)
        self.assertFalse(thread.is_alive())
        return outcome

    def test_git_initial_observer_waits_both_real_output_writers(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'direct';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb')
        outcome=self.gate_observation(lambda:run._git('rev-parse','HEAD'),lambda argv:argv[-2:]==['rev-parse','HEAD'])
        if 'error' in outcome:raise outcome['error']
        self.assertIn(b'late-owned-git-output',outcome['value'])
        self.assertIn(b'late-owned-git-stderr',(run.directory/'git-000.stderr').read_bytes())

    def test_git_receipt_observer_refuses_late_dirty_status_bytes(self):
        run=self.f.receipt_fixture()[0]
        outcome=self.gate_observation(lambda:producer.emit_fixture_receipt(run,'canonical'),
            lambda argv:argv[-3:]==['status','--porcelain','--untracked-files=normal'])
        self.assertIsInstance(outcome.get('error'),producer.ProducerError)
        self.assertIn('not clean',str(outcome['error']))
        self.assertFalse((run.directory/'input-receipt.json').exists())
        self.assertTrue((run.directory/'receipt-failure.json').exists())


    def make_auxiliary(self,code,**kw):
        directory=self.base/'auxiliary';directory.mkdir(mode=0o700)
        op=producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c',code],
            cwd=self.f.repo,environment=dict(os.environ),lease_check=lambda:None,**kw)
        self.operations.append(op)
        return op

    def finish_auxiliary(self,op):
        import time
        end=time.monotonic()+6
        result=op.result
        while result is None and time.monotonic()<end:result=op.wait(2)
        self.assertIsNotNone(result,'OWN finite observation must complete naturally')
        return result

    def test_git_auxiliary_intent_and_owner_before_spawn(self):
        op=self.make_auxiliary("print('owned')");real=producer.subprocess.Popen;observed=[]
        def popen(*args,**kwargs):
            self.assertIn(op,self.operations)
            self.assertEqual(op.intent_sha256,digest((op.directory/'probe-intent.json').read_bytes()))
            self.assertTrue((op.directory/'probe-started.json').is_file());observed.append(True)
            return real(*args,**kwargs)
        with mock.patch.object(producer.subprocess,'Popen',popen):op.start()
        self.assertEqual([True],observed)
        self.assertFalse(os.get_inheritable(op.streams['stdout']['fd']))
        self.assertFalse(os.get_blocking(op.streams['stderr']['fd']))
        result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status']);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_git_auxiliary_declaration_drift_is_prechild_terminal(self):
        op=self.make_auxiliary("print('original')")
        op.argv=(sys.executable,'-c',"print('changed')");op.intent['argv']=list(op.argv)
        op.start()
        self.assertIsNone(op.process);self.assertEqual('failed',op.result['status'])
        self.assertIn('plan changed',op.result['primary_error'])
        with self.assertRaises(producer.ProducerError):op.start()

    def test_git_auxiliary_drains_two_capacity_streams(self):
        op=self.make_auxiliary("import os;[os.write(1,b'A'*65536) for _ in range(20)];[os.write(2,b'B'*65536) for _ in range(17)]")
        op.start();result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status'])
        for role,raw in [('stdout',b'A'*(20*65536)),('stderr',b'B'*(17*65536))]:
            self.assertEqual(raw,(op.directory/('probe.'+role)).read_bytes())
            self.assertEqual(digest(raw),result['outputs'][role]['stream_sha256'])
            self.assertTrue(result['outputs'][role]['eof']);self.assertTrue(result['outputs'][role]['snapshot_matches_stream'])

    def test_git_auxiliary_postspawn_first_error_and_secondary_retained(self):
        op=self.make_auxiliary("print('finite-owned')");original=producer._write_json
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(28,'PRIMARY postspawn observation publication')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):op.start()
        self.assertTrue(op.pending);self.assertIsNotNone(op.process)
        real=producer.os.read;fd=op.streams['stdout']['fd']
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY output read')
            return real(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
        result=self.finish_auxiliary(op)
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIn('PRIMARY',result['primary_error']);self.assertTrue(any('SECONDARY' in x for x in result['secondary_errors']))

    def test_git_auxiliary_eof_close_ownership_consumed_once(self):
        op=self.make_auxiliary("print('finite')");op.start();fd=op.streams['stdout']['fd'];real=producer.os.close;calls=[]
        def close(target):
            if target==fd and not calls:
                calls.append(target);real(target);raise OSError(5,'ambiguous read-end close')
            return real(target)
        with mock.patch.object(producer.os,'close',close):result=self.finish_auxiliary(op)
        self.assertEqual([fd],calls);self.assertIsNone(op.streams['stdout']['fd'])
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        with self.assertRaises(producer.ProducerError):op.wait(0)

    def test_git_auxiliary_ambiguous_write_quarantines_without_replay(self):
        op=self.make_auxiliary("import os;os.write(1,b'tiny-raw')");op.start();original=op.streams['stdout']['log'];calls=[]
        class Fault:
            def write(self,data):calls.append(bytes(data));raise OSError(28,'injected auxiliary space fault')
        op.streams['stdout']['log']=Fault()
        try:
            self.assertIsNone(op.wait(2));self.assertTrue(op.streams['stdout']['quarantined'])
            self.assertIsNone(op.wait(0));self.assertEqual([b'tiny-raw'],calls)
            self.assertTrue(op.pending);self.assertIsNone(op.result)
            raw=json.loads((op.directory/'probe-failure.json').read_text())
            self.assertEqual(b'tiny-raw',base64.b64decode(raw['unwritten_base64']['stdout']))
        finally:
            status=op.process.wait(3)
            (self.base/'fixture-auxiliary-quarantine-cleanup.json').write_text(json.dumps({'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit, NO producer recovery/admission',
                'pid':op.process.pid,'returncode':status,'unwritten_base64':base64.b64encode(op.streams['stdout']['buffer']).decode('ascii')}))
            self.actors.append(op.process);self.operations.remove(op)
            for stream in op.streams.values():
                for name in ('fd','writer'):
                    fd=stream[name];stream[name]=None
                    if fd is not None:os.close(fd)
                if stream['log'] is not None and stream['log'] is not op.streams['stdout']['log']:stream['log'].close()
                stream['log']=None
            original.close()

    def test_git_auxiliary_eof_before_child_exit_remains_pending(self):
        code="import os,time;from pathlib import Path;os.close(1);os.close(2);p=Path("+repr(str(self.ready))+");p.write_text('ready');r=Path("+repr(str(self.release))+");end=time.monotonic()+4\nwhile not r.exists() and time.monotonic()<end:time.sleep(.005)"
        op=self.make_auxiliary(code);op.start()
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists());self.assertIsNone(op.wait(.03));self.assertIsNone(op.status)
        self.assertTrue(all(s['eof'] for s in op.streams.values()));self.release.touch()
        self.assertEqual('success',self.finish_auxiliary(op)['status'])

    def test_git_auxiliary_boolean_bounds_refuse_before_io(self):
        directory=self.base/'invalid';directory.mkdir()
        with self.assertRaises(producer.ProducerError):producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c','pass'],cwd=self.f.repo,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=True)
        self.assertEqual([],list(directory.iterdir()))

    def test_git_auxiliary_partial_failure_evidence_has_one_attempt(self):
        op=self.make_auxiliary("print('finite')");original=producer._write_json;calls=[]
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(13,'PRIMARY postspawn')
            if Path(path).name=='probe-failure.json':
                calls.append(True)
                with Path(path).open('xb') as f:f.write(b'PARTIAL-OWN-FAILURE')
                raise OSError(28,'secondary publication space failure')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):
            op.start();real=producer.os.read;fd=op.streams['stdout']['fd']
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY read')
                return real(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
            result=self.finish_auxiliary(op)
        self.assertEqual([True],calls);self.assertIn('PRIMARY',result['primary_error'])
        self.assertEqual(b'PARTIAL-OWN-FAILURE',(op.directory/'probe-failure.json').read_bytes())
        self.assertEqual('failed',result['status'])


    def test_git_consume_initial_rejects_changed_bytes_after_snapshot(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'consume';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb');original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            path=owner.directory/(name+'.stdout');raw=path.read_bytes()
            with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
            self.assertNotEqual(b'0'*40+b'\n',raw);path.write_bytes(b'0'*40+b'\n')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):run._git('rev-parse','HEAD')

    def test_git_consume_receipt_rejects_forged_empty_dirty_status(self):
        run=self.f.receipt_fixture()[0]
        (self.f.repo/'OWN-new-untracked-input').write_text('OWN synthetic dirty source control')
        original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            if argv[-3:]==['status','--porcelain','--untracked-files=normal']:
                path=owner.directory/(name+'.stdout');raw=path.read_bytes();self.assertTrue(raw)
                with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
                path.write_bytes(b'')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'input-receipt.json').exists())

class ReceiptResourceCallbackTests(ReceiptResourceTests):
    def test_callback_ledger_detachment_refuses_before_write(self):
        run=self.prepared()
        resource=producer._receipt_resource_open(run,'callback_control',run.directory/'callback-control.log','write')
        retained_ledger=run._receipt_resources
        def callback():
            self.actions.pop('callback',None)
            run._receipt_resources=[]
        self.actions['callback']=callback
        try:
            with mock.patch.object(producer,'_receipt_resource_io',return_value=4) as native_io:
                caught,result,value=self.capture(run,lambda:producer._receipt_resource_write(run,resource,b'OWN!'),
                    lambda:dict(native_IO_attempts=native_io.call_count,retained_original_fd=resource['fd'],
                        original_record_still_in_retained_ledger=any(item is resource for item in retained_ledger),
                        native_IO_mocked_no_wrong_FD_write=True))
            self.assertEqual(0,native_io.call_count)
            self.assertIs(type(caught),producer.ProducerError)
            self.assertTrue(run._receipt_resources_quarantined)
        finally:
            # Explicit finite-unit field restore preserves exact OWN FD for teardown.
            run._receipt_resources=retained_ledger

    def test_callback_same_file_borrowed_FD_refuses_before_write(self):
        run=self.prepared()
        resource=producer._receipt_resource_open(run,'callback_control',run.directory/'callback-control.log','write')
        original_fd=resource['fd']
        borrowed_fd=os.open(resource['path'],os.O_WRONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        self.assertNotEqual(original_fd,borrowed_fd)
        def callback():
            self.actions.pop('callback',None)
            resource['fd']=borrowed_fd
        self.actions['callback']=callback
        try:
            with mock.patch.object(producer,'_receipt_resource_io',return_value=4) as native_io:
                caught,result,value=self.capture(run,lambda:producer._receipt_resource_write(run,resource,b'OWN!'),
                    lambda:dict(native_IO_attempts=native_io.call_count,original_fd=original_fd,
                        borrowed_fd=borrowed_fd,native_IO_mocked_no_wrong_FD_write=True))
            self.assertEqual(0,native_io.call_count)
            self.assertIs(type(caught),producer.ProducerError)
            self.assertTrue(run._receipt_resources_quarantined)
        finally:
            # Separate fixture-owned FD and synthetic-field restore, never live recovery.
            resource['fd']=original_fd
            os.close(borrowed_fd)

class ReceiptReaderTests(unittest.TestCase):
    """Direct-reader finite fixtures; no SDK/live/canonical/physical admission."""
    def setUp(self):
        from types import SimpleNamespace
        root=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES')
        self.base=Path(tempfile.mkdtemp(prefix='receipt-reader-',dir=root)).resolve()
        self.actions={};self.owners=[];self.SimpleNamespace=SimpleNamespace

    def owner(self):
        callback=lambda:self.actions['callback']() if 'callback' in self.actions else None
        ledger=[]
        run=self.SimpleNamespace(directory=self.base,lease_check=callback,_receipt_resource_lease=callback,
            _receipt_resource_directory=self.base,_receipt_resources=[],_receipt_resources_quarantined=False,
            _receipt_readers=ledger,_receipt_reader_ledger=ledger,_receipt_primary_error_object=None,
            _receipt_primary_error_stage=None,_receipt_secondary_error_objects=[])
        self.owners.append(run);return run

    def input(self,name,body):
        path=self.base/name
        with path.open('xb') as out:out.write(body)
        return path

    def capture(self,run,invoke,extra=None):
        caught=None;result=None
        try:result=invoke()
        except BaseException as error:caught=error
        rows=[dict(purpose=row['purpose'],fd=row['fd'],open_returned=row['open_returned'],
            close_attempted=row['close_attempted'],close_returned=row['close_returned'],
            offset=row['offset'],eof=row['eof'],read_uncertain=row['read_uncertain'],quarantined=row['quarantined'],
            first_error_type=None if row['first_error'] is None else type.__dict__['__name__'].__get__(type(row['first_error']),type),
            ownership_complete=None,all_admission_flags=False) for row in run._receipt_readers]
        value=dict(rows=rows,error_type=None if caught is None else type.__dict__['__name__'].__get__(type(caught),type),
            run_quarantined=run._receipt_resources_quarantined,synthetic_owner_fixture=True,no_SDK_or_actor_admission=True)
        if extra:value.update(extra())
        with (self.base/('control-'+str(len(list(self.base.glob('control-*.json'))))+'.json')).open('x') as out:json.dump(value,out,indent=2)
        return caught,result

    def test_ambient_native_close_error_preserved_without_hooks_or_new_IO(self):
        run=self.owner();body=b'{"OWN":1}\n';path=self.input('ambient.json',body);hooks=[];closed=[]
        class HookError(RuntimeError):pass
        class ClosingError(OSError):
            def __repr__(self):hooks.append('repr');raise HookError()
            def __str__(self):hooks.append('str');raise HookError()
            def add_note(self,note):hooks.append('note');raise HookError()
        error=ClosingError(5,'OWN close');actual=producer._receipt_reader_io
        def operation(reader,step,value=None):
            result=actual(reader,step,value)
            if step=='close' and reader['role']=='reader:ambient':
                closed.append(reader['fd']);raise error
            return result
        with mock.patch.object(producer,'_receipt_reader_io',operation):
            try:raise RuntimeError('OWN caller handled error')
            except RuntimeError:
                caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'ambient',path,digest(body)),
                    lambda:dict(hooks=list(hooks),actual_native_closes=list(closed)))
        self.assertTrue(caught is error);self.assertEqual([],hooks);self.assertEqual(1,len(closed))
        self.assertTrue(run._receipt_primary_error_object is error);self.assertTrue(run._receipt_resources_quarantined)
        with mock.patch.object(producer,'_receipt_reader_io') as calls:
            producer._receipt_reader_close(run,run._receipt_readers[0],error)
            with self.assertRaises(producer.ProducerError):producer._receipt_read_json(run,'next',path,digest(body))
        calls.assert_not_called()

    def test_body_first_survives_native_close_BaseException_with_zero_hooks(self):
        run=self.owner();body=b'{"OWN":2}\n';path=self.input('body.json',body);hooks=[];closed=[]
        class First(RuntimeError):
            def __repr__(self):hooks.append('first_repr');raise RuntimeError()
            def __str__(self):hooks.append('first_str');raise RuntimeError()
            def add_note(self,note):hooks.append('first_note');raise RuntimeError()
        class Closing(BaseException):
            def __repr__(self):hooks.append('close_repr');raise RuntimeError()
        first=First('OWN body');secondary=Closing();actual=producer._receipt_reader_io
        def operation(reader,step,value=None):
            result=actual(reader,step,value)
            if step=='close':closed.append(reader['fd']);raise secondary
            return result
        with mock.patch.object(producer,'_sha',side_effect=first),mock.patch.object(producer,'_receipt_reader_io',operation):
            caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'body',path,digest(body)),
                lambda:dict(hooks=list(hooks),actual_native_closes=list(closed)))
        self.assertTrue(caught is first);self.assertEqual([],hooks);self.assertEqual(1,len(closed))
        self.assertTrue(run._receipt_primary_error_object is first)
        self.assertTrue(any(error is secondary for stage,error in run._receipt_secondary_error_objects))
        self.assertTrue(run._receipt_readers[0]['first_error'] is first)

    def test_exact_FD_retained_before_first_metadata_callback_fault(self):
        run=self.owner();body=b'{"OWN":3}\n';path=self.input('retain.json',body);seen=[];failure=OSError(5,'OWN callback')
        def callback():
            for reader in run._receipt_readers:
                if reader['open_returned'] is True and reader['identity'] is None:
                    seen.append(reader['fd']);raise failure
        self.actions['callback']=callback
        caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'retained',path,digest(body)),
            lambda:dict(retained_before_metadata_callback=list(seen)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(seen))
        self.assertIs(type(run._receipt_readers[0]['fd']),int)
        self.assertFalse(run._receipt_readers[0]['close_attempted'])

    def test_four_reader_kinds_preserve_bytes_hash_and_empty_snapshot(self):
        run=self.owner();body=b'{"OWN":4}\n';path=self.input('all.json',body);empty=self.input('empty.log',b'')
        results={}
        def operation():
            results['json']=producer._receipt_read_json(run,'json',path,digest(body))
            results['hash']=producer._receipt_regular_hash(run,'hash',path)
            results['metadata']=producer._receipt_read_bound_metadata(run,'metadata',path,{'size':len(body),'sha256':digest(body)})
            results['snapshot']=producer._receipt_file_snapshot(run,'snapshot',empty)
        try:raise RuntimeError('OWN handled')
        except RuntimeError:caught,result=self.capture(run,operation)
        self.assertIsNone(caught);self.assertIsNone(run._receipt_primary_error_object)
        self.assertEqual({'OWN':4},results['json']);self.assertEqual(digest(body),results['hash'])
        self.assertEqual(body,results['metadata']);self.assertEqual({'size':0,'sha256':digest(b'')},results['snapshot'])
        self.assertTrue(all(row['close_returned'] is True for row in run._receipt_readers))
        with mock.patch.object(producer,'_receipt_reader_io') as calls:
            with self.assertRaises(producer.ProducerError):producer._receipt_regular_hash(run,'hash',path)
        calls.assert_not_called()

    def test_callback_same_file_foreign_FD_refuses_before_read(self):
        run=self.owner();body=b'{"OWN":5}\n';path=self.input('drift.json',body)
        reader=producer._receipt_reader_open(run,'drift',path,'json',2*1024**2,frozenset({os.getuid()}))
        original=reader['fd'];foreign=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        def callback():
            self.actions.pop('callback',None);reader['fd']=foreign
        self.actions['callback']=callback
        try:
            with mock.patch.object(producer,'_receipt_reader_io') as calls:
                caught,result=self.capture(run,lambda:producer._receipt_reader_read(run,reader,100),
                    lambda:dict(native_read_attempts=calls.call_count,original_fd=original,foreign_fd=foreign))
            calls.assert_not_called();self.assertIs(type(caught),producer.ProducerError)
        finally:
            reader['fd']=original;os.close(foreign)

    def test_JSON_validation_remains_strict(self):
        for index,body in enumerate([b'{"a":1,"a":2}',b'{"a":NaN}',b'[]',b'{"a":1}']):
            run=self.owner();path=self.input('invalid-'+str(index)+'.json',body)
            expected='0'*64 if index==3 else digest(body)
            with self.subTest(index=index):
                caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'invalid',path,expected))
                self.assertIs(type(caught),producer.ProducerError)
                self.assertTrue(run._receipt_readers[0]['close_returned'])

    def tearDown(self):
        self.actions.clear();closed=[]
        for run in self.owners:
            for reader in run._receipt_readers:
                if type(reader['fd']) is not int or reader['close_attempted']:continue
                info=os.fstat(reader['fd']);path=reader['path'].stat()
                self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino))
                os.close(reader['fd']);closed.append(dict(purpose=reader['purpose'],fd=reader['fd'],
                    fixture_only_close=True,source_flags_not_retagged=True))
        with (self.base/'fixture-only-known-reader-FD-closes.json').open('x') as out:json.dump(closed,out,indent=2)

class ReceiptReaderLinkTests(ReceiptReaderTests):
    def test_existing_archive_hardlink_is_read_without_copy_or_retag(self):
        run=self.owner();body=b'OWN linked archive bytes\n';path=self.input('archive-source.bin',body)
        linked=self.base/'source.tar';os.link(path,linked,follow_symlinks=False)
        before=linked.stat()
        caught,result=self.capture(run,lambda:producer._receipt_regular_hash(run,'archive_hash',linked),
            lambda:dict(nlink_before=before.st_nlink,devino_before=[before.st_dev,before.st_ino],
                second_path=str(path),no_copy_or_unlink=True))
        self.assertIsNone(caught);self.assertEqual(digest(body),result)
        after=linked.stat();self.assertEqual((before.st_dev,before.st_ino,before.st_nlink),(after.st_dev,after.st_ino,after.st_nlink))

class ReceiptReaderIntegrationTests(ReceiptResourceTests):
    def test_actual_Fixture_receipt_uses_all_direct_reader_bindings(self):
        run=self.prepared()
        def reader_rows():
            return dict(reader_rows=[dict(purpose=row['purpose'],fd=row['fd'],close_attempted=row['close_attempted'],
                close_returned=row['close_returned'],offset=row['offset'],eof=row['eof'],
                native_link_count=None if row['identity'] is None else row['identity'][5],
                ownership_complete=None,all_admission_flags=False) for row in run._receipt_readers])
        caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),reader_rows)
        self.assertIsNone(caught);self.assertEqual('fixture-canonical-v1',result['kind'])
        self.assertTrue(all(row['close_returned'] is True and row['eof'] is True for row in run._receipt_readers))
        roles={row['purpose'] for row in run._receipt_readers}
        self.assertTrue({'intent','result','journal_hash','archive_hash','audit_hash','complete_hash','input_receipt_hash'}<=roles)
        self.assertTrue(any(role.startswith('audit_stdout-') for role in roles))
        self.assertTrue(any(role.startswith('audit_result-') for role in roles))
        self.assertTrue(any(role.startswith('command_snapshot-') for role in roles))
        self.assertTrue(any(role.startswith('output_hash-') for role in roles))
    def tearDown(self):
        self.actions.pop('callback',None);closed=[]
        for run in self.runs:
            for reader in run._receipt_readers:
                if type(reader['fd']) is not int or reader['close_attempted']:continue
                info=os.fstat(reader['fd']);path=reader['path'].stat()
                self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino))
                os.close(reader['fd']);closed.append(dict(purpose=reader['purpose'],fd=reader['fd'],
                    fixture_only_close=True,source_flags_not_retagged=True))
        with (self.base/'fixture-only-known-reader-integration-closes.json').open('x') as out:json.dump(closed,out,indent=2)
        super().tearDown()

class ReceiptReaderStrictTests(ReceiptReaderTests):
    def observe_strict(self,run,reader,invoke,hooks):
        caught=None
        try:invoke()
        except BaseException as error:caught=error
        value=dict(error_type=None if caught is None else type.__dict__['__name__'].__get__(type(caught),type),
            hooks=list(hooks),first_error_is_caught=run._receipt_primary_error_object is caught,
            fd=reader['fd'],quarantined=run._receipt_resources_quarantined,
            ownership_complete=None,all_admission_flags=False,native_IO_mocked=True)
        with (self.base/'strict-before-cleanup.json').open('x') as out:json.dump(value,out,indent=2)
        return caught

    def test_unknown_binding_never_invokes_custom_iterator(self):
        run=self.owner();body=b'{"OWN":"binding"}';path=self.input('binding.json',body)
        reader=producer._receipt_reader_open(run,'binding',path,'json',2*1024**2,frozenset({os.getuid()}))
        original=reader['binding'];hooks=[]
        class Unknown:
            def __iter__(self):hooks.append('iter');raise RuntimeError('OWN iterator')
        reader['binding']=Unknown()
        try:
            with mock.patch.object(producer,'_receipt_reader_io') as calls:
                caught=self.observe_strict(run,reader,lambda:producer._receipt_reader_read(run,reader,100),hooks)
            calls.assert_not_called();self.assertEqual([],hooks);self.assertIs(type(caught),producer.ProducerError)
        finally:reader['binding']=original

    def test_unknown_purpose_never_runs_error_stage_hook(self):
        run=self.owner();body=b'{"OWN":"purpose"}';path=self.input('purpose.json',body)
        reader=producer._receipt_reader_open(run,'purpose',path,'json',2*1024**2,frozenset({os.getuid()}))
        original=reader['purpose'];hooks=[]
        class Unknown:
            def __radd__(self,other):hooks.append('radd');raise RuntimeError('OWN stage')
        reader['purpose']=Unknown()
        try:
            with mock.patch.object(producer,'_receipt_reader_io') as calls:
                caught=self.observe_strict(run,reader,lambda:producer._receipt_reader_read(run,reader,100),hooks)
            calls.assert_not_called();self.assertEqual([],hooks);self.assertIs(type(caught),producer.ProducerError)
            self.assertTrue(run._receipt_primary_error_object is caught)
        finally:reader['purpose']=original

    def test_callback_dropped_error_field_cannot_mask_exact_primary(self):
        run=self.owner();body=b'{"OWN":"error"}';path=self.input('error.json',body)
        reader=producer._receipt_reader_open(run,'error',path,'json',2*1024**2,frozenset({os.getuid()}))
        failure=OSError(5,'OWN callback');hooks=[]
        def callback():
            self.actions.pop('callback',None);reader.pop('first_error');raise failure
        self.actions['callback']=callback
        try:
            with mock.patch.object(producer,'_receipt_reader_io') as calls:
                caught=self.observe_strict(run,reader,lambda:producer._receipt_reader_read(run,reader,100),hooks)
            calls.assert_not_called();self.assertTrue(caught is failure)
            self.assertTrue(run._receipt_primary_error_object is failure)
        finally:
            if 'first_error' not in reader:reader['first_error']=None

class ReceiptReaderUncertainTests(ReceiptReaderTests):
    def test_uncertain_read_never_allows_another_native_read(self):
        run=self.owner();body=b'{"OWN":"uncertain"}';path=self.input('uncertain.json',body)
        reader=producer._receipt_reader_open(run,'uncertain',path,'json',2*1024**2,frozenset({os.getuid()}))
        first=OSError(5,'OWN read uncertainty')
        with mock.patch.object(producer,'_receipt_reader_io',side_effect=first):
            with self.assertRaises(OSError):producer._receipt_reader_read(run,reader,100)
        with mock.patch.object(producer,'_receipt_reader_io',return_value=b'OWN') as calls:
            caught,result=self.capture(run,lambda:producer._receipt_reader_read(run,reader,100),
                lambda:dict(second_native_read_attempts=calls.call_count,first_read_fault_before_nativeIO=True))
        self.assertEqual(0,calls.call_count);self.assertIs(type(caught),producer.ProducerError)
        self.assertTrue(run._receipt_primary_error_object is first)

    def test_uncertain_read_still_allows_one_exact_identity_close(self):
        run=self.owner();body=b'{"OWN":"close"}';path=self.input('read-close.json',body)
        first=OSError(5,'OWN read error');actual=producer._receipt_reader_io;closes=[]
        def operation(reader,step,value=None):
            if step=='read':raise first
            returned=actual(reader,step,value)
            if step=='close':closes.append(reader['fd'])
            return returned
        with mock.patch.object(producer,'_receipt_reader_io',operation):
            caught,result=self.capture(run,lambda:producer._receipt_read_json(run,'read-close',path,digest(body)),
                lambda:dict(actual_native_close_FDs=list(closes),no_read_retry=True))
        self.assertTrue(caught is first);self.assertEqual(1,len(closes))
        self.assertTrue(run._receipt_readers[0]['close_returned'])
        self.assertFalse(run._receipt_resources_quarantined)

class CommandHistoryTests(ReceiptResourceTests):
    def setUp(self):
        self.external_known=[];self.history_notes=[]
        super().setUp()

    def test_all_actual_direct_commands_remain_retained_after_overwrite(self):
        run=self.start('ok','ok');first=run.process;first_log=run.log;self.external_known.append((first,first.wait))
        self.finish(run)
        history=run.__dict__.get('_command_attempts',[])
        notes=dict(command_count=len(run.commands),history_count=len(history),first_pid=first.pid,last_pid=run.process.pid,
            first_process_is_last=first is run.process,private_history_present='_command_attempts' in run.__dict__,
            rows=[dict(index=row['index'],pid=None if row['process'] is None else row['process'].pid,
                wait_observed=row['wait_observed'],wait_status=row['wait_status'],
                parent_writer_close_attempted=row['parent_writer_close_attempted'],
                parent_writer_close_returned=row['parent_writer_close_returned'],
                log_closed=None if row['log'] is None else row['log'].closed,
                ownership_complete=None,all_admission_flags=False) for row in history])
        self.history_notes.append(notes)
        self.assertEqual(len(run.commands),len(history))
        self.assertTrue(history[0]['process'] is first);self.assertTrue(history[0]['log'] is first_log)
        self.assertTrue(all(row['wait_observed'] is True and row['wait_status']==0 for row in history))
        self.assertTrue(all(row['process'] is not None for row in history))

    def test_attempt_precedes_first_event_failure_without_launch(self):
        actual=producer.CommandProducer._event;captured=[];failure=OSError(5,'OWN command_start')
        def event(current,kind,**fields):
            if kind=='command_start':
                if not any(item is current for item in self.runs):self.runs.append(current)
                history=current.__dict__.get('_command_attempts',[])
                captured.append(dict(history_count=len(history),
                    process_none=None if not history else history[-1]['process'] is None,
                    log_none=None if not history else history[-1]['log'] is None,
                    popen_attempted=None if not history else history[-1]['popen_attempted']))
                raise failure
            return actual(current,kind,**fields)
        with mock.patch.object(producer.CommandProducer,'_event',event):
            with self.assertRaises(OSError):self.start('ok')
        self.history_notes.append(dict(before_event=captured))
        self.assertEqual(1,len(captured));self.assertEqual(1,captured[0]['history_count'])
        self.assertTrue(captured[0]['process_none']);self.assertTrue(captured[0]['log_none'])
        self.assertFalse(captured[0]['popen_attempted'])

    def test_actual_wait_witness_survives_end_command_fault(self):
        run=self.start('ok');process=run.process;self.external_known.append((process,process.wait))
        actual=run._end_command;failure=OSError(5,'OWN postwait cache')
        with mock.patch.object(run,'_end_command',side_effect=failure):
            result=run.wait(2)
        history=run.__dict__.get('_command_attempts',[])
        row=None if not history else history[-1]
        self.history_notes.append(dict(after_wait_fault=dict(history_present=bool(history),
            process_same=None if row is None else row['process'] is process,
            wait_observed=None if row is None else row['wait_observed'],
            wait_status=None if row is None else row['wait_status'],
            raw_pending=run.pending,raw_finished=run.finished,result=result)))
        self.assertTrue(history);self.assertTrue(row['process'] is process)
        self.assertTrue(row['wait_observed']);self.assertIs(type(row['wait_status']),int)
        self.assertEqual(0,row['wait_status'])

    def capsule(self,code='pass'):
        from types import SimpleNamespace
        attempt=dict(index=0,record={'returncode':None},process=None,wait_process=None,wait_status=None,
            wait_observed=False,raw_wait_return=None,wait_uncertain=False,wait_timeouts=0,
            first_error=None,error_stage=None)
        owner=SimpleNamespace(process=None,records=[attempt['record']],_command_attempt=attempt,
            _command_attempts=[attempt],_command_history_primary_error=None,_command_history_primary_stage=None,
            _command_history_secondary_errors=[])
        owner._command_history_error=lambda row,stage,error,secondary=False:producer.CommandProducer._command_history_error(owner,row,stage,error,secondary)
        child=subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.external_known.append((child,child.wait))
        owner.process=child;attempt['process']=child
        return owner,attempt,child

    def test_poll_then_same_status_actual_method_wait_is_distinct(self):
        import time
        owner,row,child=self.capsule()
        deadline=time.monotonic()+2
        status=producer.CommandProducer._observe_direct_status(owner)
        while status is None and time.monotonic()<deadline:
            time.sleep(.005);status=producer.CommandProducer._observe_direct_status(owner)
        self.assertEqual(0,status);self.assertFalse(row['wait_observed']);self.assertIsNone(row['wait_status'])
        actual=producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(poll_then_wait=dict(pid=child.pid,poll_status=status,method_return=actual,
            observed=row['wait_observed'],marker_status=row['wait_status'],synthetic_capsule=True)))
        self.assertIs(type(actual),int);self.assertEqual(0,actual);self.assertTrue(row['wait_observed'])
        self.assertTrue(row['wait_process'] is child)

    def test_real_timeout_retains_same_child_until_natural_wait(self):
        owner,row,child=self.capsule('import time;time.sleep(.08)')
        with self.assertRaises(subprocess.TimeoutExpired):producer.CommandProducer._wait_command_natural(owner,0)
        self.assertFalse(row['wait_observed']);self.assertIsNone(row['wait_status']);self.assertTrue(row['wait_process'] is child)
        actual=producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(timeout_then_natural=dict(pid=child.pid,method_return=actual,
            timeouts=row['wait_timeouts'],same_process=row['wait_process'] is child,synthetic_capsule=True)))
        self.assertEqual(0,actual);self.assertTrue(row['wait_observed'])

    def test_malformed_bool_return_never_becomes_observed_zero(self):
        owner,row,child=self.capsule()
        with mock.patch.object(child,'wait',return_value=False):
            with self.assertRaises(producer.ProducerError):producer.CommandProducer._wait_command_natural(owner,2)
        self.history_notes.append(dict(bool_wait=dict(pid=child.pid,raw_type=type(row['raw_wait_return']).__name__,
            observed=row['wait_observed'],status=row['wait_status'],synthetic_capsule=True)))
        self.assertIs(row['raw_wait_return'],False);self.assertFalse(row['wait_observed'])
        self.assertIsNone(row['wait_status']);self.assertTrue(row['wait_uncertain'])

    def test_foreign_process_refuses_without_waiting_on_it(self):
        owner,row,child=self.capsule()
        foreign=subprocess.Popen([sys.executable,'-c','pass'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.external_known.append((foreign,foreign.wait));owner.process=foreign
        with mock.patch.object(foreign,'wait') as calls:
            with self.assertRaises(producer.ProducerError):producer.CommandProducer._wait_command_natural(owner,2)
        calls.assert_not_called();self.assertTrue(row['process'] is child);self.assertFalse(row['wait_observed'])


    def test_parent_writer_close_fault_retains_same_pending_Popen(self):
        import fcntl,stat
        actual_event=producer.CommandProducer._event;actual_close=os.close;captured=[];closed=[]
        failure=OSError(5,'OWN after actual parent writer close')
        def event(current,kind,**fields):
            if kind=='command_start':captured.append(current)
            return actual_event(current,kind,**fields)
        def close(fd):
            current=None if not captured else captured[-1]
            if current is not None and current.process is not None and current.pending and not closed:
                info=os.fstat(fd)
                if stat.S_ISFIFO(info.st_mode) and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY:
                    returned=actual_close(fd);closed.append(dict(fd=fd,native_returned_none=returned is None))
                    raise failure
            return actual_close(fd)
        with mock.patch.object(producer.CommandProducer,'_event',event),mock.patch.object(producer.os,'close',close):
            run=self.start('ok')
        process=run.process;self.external_known.append((process,process.wait))
        history=run.__dict__.get('_command_attempts',[])
        self.history_notes.append(dict(parent_close_fault=dict(history_count=len(history),actual_native_closes=closed,
            raw_pending=run.pending,raw_finished=run.finished,
            retained_process_same=None if not history else history[-1]['process'] is process,
            original_first_error_same=None if not history else history[-1]['first_error'] is failure)))
        self.assertTrue(run.pending);self.assertFalse(run.finished);self.assertEqual(1,len(closed))
        self.assertEqual(1,len(history));self.assertTrue(history[0]['process'] is process)
        self.assertTrue(history[0]['first_error'] is failure)
        self.assertTrue(history[0]['parent_writer_close_attempted'])
        self.assertFalse(history[0]['parent_writer_close_returned'])

    def tearDown(self):
        # These are finite-unit known actors; never a live controller workaround.
        waited=[]
        for child,wait in self.external_known:
            if any(item is child for item in waited):continue
            status=wait(2);waited.append(child)
            self.history_notes.append(dict(fixture_only_actual_Popen_wait=dict(pid=child.pid,status=status,
                source_marker_not_reconstructed=True,not_fresh_waitsyscall_proof=True)))
        for run in self.runs:
            if run.pending:self.finish(run) # SAME actor/public bounded wait, deferred failures stop next spawn.
            self.assertFalse(run.pending)
            process=run.process
            if process is not None and not any(item is process for item in waited):
                status=process.wait(2);waited.append(process)
                self.history_notes.append(dict(fixture_only_last_recipe_wait=dict(pid=process.pid,status=status)))
            for operation in run.auxiliary_operations:
                process=operation.process
                if process is not None and not any(item is process for item in waited):
                    status=process.wait(2);waited.append(process)
                    self.history_notes.append(dict(fixture_only_auxiliary_wait=dict(pid=process.pid,status=status)))
            for field in ('log','events'):
                writer=getattr(run,field,None)
                if writer is None or writer.closed:continue
                fd=writer.fileno();info=os.fstat(fd);path=Path(writer.name);current=path.stat()
                self.assertEqual((info.st_dev,info.st_ino),(current.st_dev,current.st_ino))
                writer.close()
                self.history_notes.append(dict(fixture_only_known_writer_close=dict(field=field,fd=fd,
                    closed=writer.closed,source_fields_not_retagged=True)))
        with (self.base/'command-history-observations.json').open('x') as out:json.dump(self.history_notes,out,indent=2)

class CommandHistoryReviewTests(CommandHistoryTests):
    def test_declared_Popen_OSError_finishes_failed_without_success_else(self):
        actual_event=producer.CommandProducer._event;actual_popen=subprocess.Popen;patchers=[];requests=[];captured=[]
        failure=OSError(5,'OWN declared before native Popen call')
        def refusing(current,initializer,allocated,arguments):
            requests.append(dict(argv=list(arguments[0]),native_initializer_called=False))
            raise failure
        def event(current,event_name,**fields):
            if event_name=='command_start':captured.append(current)
            returned=actual_event(current,event_name,**fields)
            if event_name=='command_start' and not patchers:
                patcher=mock.patch.object(producer.CommandProducer,'_initialize_command_process',refusing)
                patchers.append(patcher);patcher.start()
            return returned
        try:
            with mock.patch.object(producer.CommandProducer,'_event',event):
                run=self.start('ok')
        finally:
            for patcher in reversed(patchers):patcher.stop()
            for current in captured:
                if not any(item is current for item in self.runs):self.runs.append(current)
        history=run._command_attempts
        self.history_notes.append(dict(declared_before_Popen_fault=dict(requests=requests,
            raw_finished=run.finished,raw_pending=run.pending,result_status=run.result['status'],
            process_none=history[-1]['process'] is None,popen_attempted=history[-1]['popen_attempted'],
            popen_returned=history[-1]['popen_returned'],stage=history[-1]['stage'],
            no_actor_absence_authority_for_live_unknown_start=True)))
        self.assertEqual(1,len(requests));self.assertTrue(run.finished);self.assertFalse(run.pending)
        self.assertEqual('failed',run.result['status']);self.assertIsNone(history[-1]['process'])
        self.assertFalse(history[-1]['wait_observed'])
        self.assertTrue(history[-1]['first_error'] is failure)
        self.assertNotEqual('command_spawned_event',history[-1]['stage'])

    def test_bool_and_nonbounded_timeout_rejected_before_actor_fields(self):
        import math
        for value in [True,False,-.1,60.1,math.nan,math.inf]:
            with self.subTest(value_type=type(value).__name__):
                with self.assertRaises(producer.ProducerError):
                    producer.CommandProducer._wait_command_natural(None,value)
        self.history_notes.append(dict(exact_type_timeout_guard=dict(bool_rejected=True,
            nonbounded_rejected=True,actor_not_needed=True)))

class OwnerErrorLabelTests(unittest.TestCase):
    """SYNTHETIC owners/operations with actual finite Threads, no SDK/child."""
    def setUp(self):
        self.saved_threads=[]
        root=Path(os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])
        self.evidence=Path(tempfile.mkdtemp(prefix='owner-label-',dir=root))
    def tearDown(self):
        rows=[]
        for thread in self.saved_threads:
            returned=producer.threading.Thread.join(thread,2)
            rows.append(dict(ident=thread.ident,join_return_is_None=returned is None,alive=thread.is_alive()))
        (self.evidence/'teardown.json').write_text(json.dumps(rows,indent=2)+'\n')
        self.assertTrue(all(not row['alive'] for row in rows))
    @staticmethod
    def native_name(value):
        return type.__dict__['__name__'].__get__(type(value),type)
    def safe(self,value):
        if value is None or type(value) in (str,int,bool,float):return value
        if type(value) in (tuple,list):return [self.safe(item) for item in value]
        if type(value) is dict:return {key:self.safe(item) for key,item in value.items()}
        return dict(nonprimitive_native_type=self.native_name(value))
    def save(self,name,owner,error,hooks,extra=None):
        view=owner._snapshot
        rows=[dict(row) for row in owner.worker_lifecycle()]
        records=owner._workers
        result=dict(scope='SYNTHETIC owner/operation; actual finite Thread only; no Popen SDK or release',
            hooks=list(hooks),view=self.safe(dict(view)),lifecycle=self.safe(rows),
            private_first_is_error=owner._first_error_object is error,
            private_call_is_error=bool(records) and records[-1]['_call_error_object'] is error,
            private_join_is_error=bool(records) and records[-1]['_join_error_object'] is error,
            busy=owner._busy,call_done=owner._call_done,event_set=owner._event.is_set(),
            first_label_native_type=self.native_name(owner._first_error),extra=self.safe(extra))
        (self.evidence/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    def error(self,hooks,return_marker=False):
        class NameHookFailure(RuntimeError):pass
        marker=object()
        class Meta(type):
            def __getattribute__(cls,name):
                if name=='__name__':
                    hooks.append('metaclass_name')
                    if return_marker:return marker
                    raise NameHookFailure('synthetic metadata hook')
                return type.__getattribute__(cls,name)
        class Error(RuntimeError,metaclass=Meta):
            def __repr__(self):hooks.append('repr');raise AssertionError('repr hook')
            def __str__(self):hooks.append('str');raise AssertionError('str hook')
            def add_note(self,note):hooks.append('add_note');raise AssertionError('note hook')
            def __eq__(self,other):hooks.append('equality');raise AssertionError('equality hook')
        return Error(),NameHookFailure
    def failed_worker(self,error,hooks,prior=None):
        from types import SimpleNamespace
        owner=producer._RetainedPreflightOwner('fixture','f'*32,{})
        uncaught=[]
        def fail(*args,**kwargs):raise error
        if prior is None:patch=mock.patch.object(producer,'start_fixture',side_effect=fail);action='construct';value=None
        else:
            owner._operation=SimpleNamespace(wait=fail,pending=True,finished=False)
            owner._initialized=True;owner._pending=True;owner._finished=False
            owner._error_locked(prior)
            patch=mock.patch.object(producer,'start_fixture',side_effect=AssertionError('unused factory'))
            action='wait';value=0
        with patch,mock.patch.object(producer.threading,'excepthook',side_effect=lambda args:uncaught.append(args.exc_value)):
            returned=owner._schedule(action,value);thread=owner._thread;self.saved_threads.append(thread)
            observed=owner.observe(.25)
        self.save('worker',owner,error,hooks,dict(returned_same=returned is owner,
            uncaught_types=[self.native_name(item) for item in uncaught],
            uncaught_is_original=[item is error for item in uncaught],thread_alive=thread.is_alive(),
            observed=self.safe(dict(observed)),prior_preserved=owner._first_error_object is prior))
        return owner,uncaught
    def test_constructor_metaclass_error_retained_before_label(self):
        hooks=[];error,_=self.error(hooks);owner,uncaught=self.failed_worker(error,hooks)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(error,owner._first_error_object);self.assertIs(error,owner._workers[-1]['_call_error_object'])
        self.assertEqual('Error',owner._first_error);self.assertTrue(owner._call_done)
        self.assertTrue(owner._event.is_set());self.assertFalse(owner._busy)
        self.assertTrue(owner._workers[-1]['worker_joined'])
    def test_later_call_metaclass_error_keeps_earliest_and_current(self):
        hooks=[];error,_=self.error(hooks);prior=ValueError('synthetic earlier primary')
        owner,uncaught=self.failed_worker(error,hooks,prior)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(prior,owner._first_error_object);self.assertEqual('ValueError',owner._first_error)
        self.assertIs(error,owner._workers[-1]['_call_error_object'])
        self.assertEqual('Error',owner._workers[-1]['call_error'])
        self.assertTrue(owner._call_done);self.assertTrue(owner._event.is_set());self.assertFalse(owner._busy)
    def test_nonscalar_metaclass_name_never_reaches_view(self):
        hooks=[];error,_=self.error(hooks,True);owner,uncaught=self.failed_worker(error,hooks)
        self.assertEqual([],hooks);self.assertEqual([],uncaught)
        self.assertIs(type(owner._snapshot['first_error']),str)
        self.assertEqual('Error',owner._snapshot['first_error'])
        self.assertIs(type(owner.worker_lifecycle()[-1]['call_error']),str)
    def test_actual_join_then_metaclass_error_retained_without_recovery(self):
        from types import SimpleNamespace
        hooks=[];error,_=self.error(hooks)
        owner=producer._RetainedPreflightOwner('fixture','e'*32,{})
        def factory(**kwargs):
            operation=SimpleNamespace(pending=False,finished=True)
            kwargs['_preflight_owner']._operation=operation
            return operation
        with mock.patch.object(producer,'start_fixture',side_effect=factory):owner._schedule('construct')
        thread=owner._thread;self.saved_threads.append(thread)
        real_join=producer.threading.Thread.join;native_returns=[];caught=None;observed=None
        def joined_then_fault(same,timeout=None):
            self.assertIs(thread,same);native_returns.append(real_join(same,timeout))
            raise error
        try:
            with mock.patch.object(producer.threading.Thread,'join',new=joined_then_fault):observed=owner.observe(2)
        except BaseException as failure:caught=failure
        self.save('join',owner,error,hooks,dict(native_join_returns=native_returns,
            caught_type=None if caught is None else self.native_name(caught),
            caught_is_original=caught is error,observed=None if observed is None else self.safe(dict(observed)),
            actual_thread_alive=thread.is_alive()))
        self.assertEqual([],hooks);self.assertIsNone(caught);self.assertEqual([None],native_returns)
        self.assertIs(error,owner._workers[-1]['_join_error_object'])
        self.assertEqual('Error',owner.worker_lifecycle()[-1]['join_error'])
        self.assertFalse(owner._workers[-1]['worker_joined'])
        self.assertIs(thread,owner._workers[-1]['_thread'])
        self.assertIsNone(owner._first_error_object)
    def test_thread_setup_metaclass_error_stays_start_uncertain(self):
        hooks=[];error,_=self.error(hooks)
        owner=producer._RetainedPreflightOwner('fixture','d'*32,{})
        returned=None;caught=None
        try:
            with mock.patch.object(producer.threading,'Thread',side_effect=error):returned=owner._schedule('construct')
        except BaseException as failure:caught=failure
        self.save('setup',owner,error,hooks,dict(returned_same=returned is owner,
            caught_type=None if caught is None else self.native_name(caught)))
        self.assertEqual([],hooks);self.assertIsNone(caught);self.assertIs(owner,returned)
        self.assertIs(error,owner._first_error_object);self.assertEqual('Error',owner._snapshot['first_error'])
        self.assertEqual('start_uncertain',owner._snapshot['call_state'])
        self.assertTrue(owner._busy);self.assertFalse(owner._call_done)
        self.assertFalse(owner._workers[-1]['thread_created']);self.assertTrue(owner._workers[-1]['start_settled'])

class OwnerErrorJoinReviewTests(unittest.TestCase):
    def test_timed_join_none_return_does_not_mark_live_worker_joined(self):
        from types import SimpleNamespace
        entered=producer.threading.Event();finite_deadline=producer.threading.Event()
        owner=producer._RetainedPreflightOwner('fixture','c'*32,{})
        evidence=Path(tempfile.mkdtemp(prefix='owner-join-review-',dir=Path(os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])))
        def factory(**kwargs):
            entered.set();finite_deadline.wait(.35)
            operation=SimpleNamespace(pending=False,finished=True)
            kwargs['_preflight_owner']._operation=operation
            return operation
        thread=None
        try:
            with mock.patch.object(producer,'start_fixture',side_effect=factory):
                owner._schedule('construct');thread=owner._thread
                self.assertTrue(entered.wait(1))
                before=owner.observe(.01)
                row=dict(owner.worker_lifecycle()[-1])
                alive=thread.is_alive()
                (evidence/'before-natural-completion.json').write_text(json.dumps(dict(
                    scope='actual finite Thread timeout; synthetic factory/operation; no Popen/SDK',
                    view=dict(before),lifecycle=row,actual_thread_alive=alive,
                    exact_thread_retained=owner._workers[-1]['_thread'] is thread),indent=2)+'\n')
                self.assertTrue(alive);self.assertFalse(row['worker_joined'])
                self.assertFalse(before['call_done']);self.assertIs(thread,owner._workers[-1]['_thread'])
                after=owner.observe(2)
                (evidence/'after-natural-completion.json').write_text(json.dumps(dict(
                    view=dict(after),lifecycle=dict(owner.worker_lifecycle()[-1]),
                    actual_thread_alive=thread.is_alive()),indent=2)+'\n')
                self.assertTrue(after['call_done']);self.assertTrue(after['worker_joined'])
                self.assertFalse(thread.is_alive())
        finally:
            if thread is not None:
                returned=producer.threading.Thread.join(thread,2)
                (evidence/'teardown.json').write_text(json.dumps(dict(join_return_is_None=returned is None,alive=thread.is_alive()),indent=2)+'\n')
                self.assertFalse(thread.is_alive())

class FrozenCommandHistoryTests(KnownActorInventoryTests):
    """New selectors only; finite OWN Python/Fixture, never SDK or release."""
    def setUp(self):
        super().setUp();self.history_sources=[];self.history_threads=[];self.history_reports=[]
    def done(self,owner):
        thread=owner._thread
        if thread is not None and all(thread is not item for item in self.history_threads):self.history_threads.append(thread)
        return super().done(owner)
    def history_owner(self,two=False):
        if not two:
            owner,op,sentinel,fault=self.initialized(mixed=True)
        else:
            first,first_ready=self.argv('history-first');second,second_ready=self.argv('history-second')
            sentinel=self.base/'FORBIDDEN-history-third'
            last=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
            def check():
                action=self.actions.get('callback')
                if action is not None:action()
            def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
            actual=producer.start_fixture;actual_hash=producer._regular_hash
            def archive_hash(path):
                if Path(path)==self.base/'history-run/source.tar':return '0'*64
                return actual_hash(path)
            def factory(**kwargs):
                run=actual(**kwargs);self.known.append(run);return run
            with mock.patch.object(producer.CommandProducer,'_source_guard',lambda op:None), \
                 mock.patch.object(producer.CommandProducer,'_make_archive',archive), \
                 mock.patch.object(producer.CommandProducer,'_input_guard',lambda op:None), \
                 mock.patch.object(producer,'start_fixture',factory), \
                 mock.patch.object(producer,'_regular_hash',archive_hash):
                owner=producer.start_owned_preflight('fixture',owner_id=digest(str(self.base).encode())[:32],
                    repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/'history-run',
                    expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
                    commands=[first,second,last],lease_check=check)
                self.owners.append(owner);self.done(owner);op=self.known[-1]
                self.history_sources.append(dict(owner=owner,op=op,history=op._command_attempts,
                    attempts=tuple(op._command_attempts),current=op._command_attempt,events=op.events,sentinel=sentinel))
                self.ready(first_ready);first_process=op.process
                self.release(self.base/'history-first-release')
                first_status=first_process.wait(3)
                self.history_reports.append(dict(fixture_only_first_actual_wait=dict(pid=first_process.pid,status=first_status)))
                self.assertEqual(0,first_status)
                owner.continue_wait(.01);self.done(owner);self.ready(second_ready)
            self.assertEqual(2,len(op._command_attempts))
            fault=RuntimeError('OWN failure after second finite command starts')
            def fail(current,timeout):self.assertIs(op,current);raise fault
            with mock.patch.object(producer.CommandProducer,'wait',fail):owner.continue_wait(0);self.done(owner)
        known=next((item for item in self.history_sources if item['op'] is op),None)
        if known is None:self.history_sources.append(dict(owner=owner,op=op,history=op._command_attempts,
            attempts=tuple(op._command_attempts),current=op._command_attempt,events=op.events,sentinel=sentinel))
        else:known.update(attempts=tuple(op._command_attempts),current=op._command_attempt)
        return owner,op,sentinel
    def history_snapshot(self,label,owner):
        rows=owner.command_history_observations() if hasattr(owner,'command_history_observations') else ()
        result=dict(scope='finite Fixture/SYNTHETIC callbacks only, no SDK/canonical/physical closure',
            view=dict(owner.observe(0)),workers=[dict(row) for row in owner.worker_lifecycle()],
            rows=[dict(row) for row in rows])
        with (self.base/(label+'.json')).open('x') as out:json.dump(result,out,indent=2)
        return rows
    def freeze_history(self,owner):
        self.assertIs(owner,owner.freeze_command_history());self.done(owner)
        return self.history_snapshot('history-frozen-'+str(len(owner._workers)),owner)
    def test_two_actual_commands_retained_and_no_actor_IO(self):
        owner,op,sentinel=self.history_owner(True)
        attempts=tuple(op._command_attempts);first,second=[item['process'] for item in attempts]
        self.assertIsNot(first,second);self.assertTrue(attempts[0]['wait_observed'])
        with mock.patch.object(producer.subprocess.Popen,'poll',side_effect=AssertionError('poll forbidden')), \
             mock.patch.object(producer.subprocess.Popen,'wait',side_effect=AssertionError('wait forbidden')), \
             mock.patch.object(producer.os,'fstat',side_effect=AssertionError('fstat forbidden')), \
             mock.patch.object(producer.os,'read',side_effect=AssertionError('read forbidden')), \
             mock.patch.object(producer.os,'close',side_effect=AssertionError('close forbidden')):
            rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        commands=[row for row in rows if row['role']=='command'];self.assertEqual(2,len(commands))
        self.assertEqual([first.pid,second.pid],[row['pid'] for row in commands])
        self.assertEqual([True,False],[row['method_wait_observed'] for row in commands])
        self.assertIs(first,owner._history_attempt_refs[0]['process'])
        self.assertIs(second,owner._history_attempt_refs[1]['process'])
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed);self.assertFalse(sentinel.exists())
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertIn(type(value),(str,int,bool,type(None)))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[flag])
        with self.assertRaises(TypeError):rows[0]['pending']=False
        for action in [owner.freeze_command_history,owner.freeze_known_actors,lambda:owner.continue_wait(0)]:
            with self.assertRaises(producer.ProducerError):action()
    def test_command_quarantine_does_not_drop_available_data(self):
        owner,op,_=self.history_owner();owner._command_quarantined=True
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['snapshot_checked'])
        self.assertTrue(owner._command_quarantined);self.assertIs(op,owner._history_producer)
        self.assertTrue(any(row['role']=='auxiliary' for row in rows))
    def test_current_outside_list_retained_and_quarantined(self):
        owner,op,_=self.history_owner();current=op._command_attempt
        op._command_attempts=[]
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[0]['snapshot_checked'])
        self.assertTrue(rows[0]['current_outside_history']);self.assertIs(current,owner._history_current_attempt)
        self.assertIs(op.process,current['process']);self.assertIsNotNone(owner._history_primary_error)
    def test_callback_list_swap_keeps_original_handles(self):
        owner,op,_=self.history_owner();original=op._command_attempts;child=op.process
        self.actions['callback']=lambda:setattr(op,'_command_attempts',list(original))
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['quarantined']);self.assertIs(child,owner._history_attempt_refs[0]['process'])
        self.assertTrue(any(item is original for item in owner._history_binding))
        self.assertTrue(op.pending);self.assertIsNone(op.result)
    def test_hostile_public_record_key_never_invokes_equality(self):
        owner,op,_=self.history_owner();record=op.records[-1];previous=record.pop('returncode');calls=[]
        class Key:
            def __hash__(self):return hash('returncode')
            def __eq__(self,other):calls.append('equality');raise AssertionError('custom equality')
        key=Key();record[key]=None
        try:
            rows=self.freeze_history(owner)
            self.assertEqual([],calls);self.assertTrue(rows[0]['quarantined'])
            self.assertIs(op.process,owner._history_attempt_refs[0]['process'])
        finally:
            del record[key];record['returncode']=previous
    def test_unknown_start_is_not_invented_no_actor_or_zero(self):
        owner,op,_=self.history_owner();attempt=op._command_attempt
        prior=attempt['popen_returned'];attempt['popen_returned']=False
        try:
            rows=self.freeze_history(owner);command=next(row for row in rows if row['role']=='command')
            self.assertTrue(rows[0]['quarantined']);self.assertTrue(command['start_outcome_unknown'])
            self.assertTrue(command['retained_process']);self.assertIsNone(command['method_wait_status'])
            self.assertIs(op.process,owner._history_current_attempt['process'])
        finally:attempt['popen_returned']=prior
    def test_old_inventory_and_history_are_mutually_terminal(self):
        owner,op,_=self.history_owner();self.freeze(owner)
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
        self.assertFalse(owner._history_attempted)
    def test_emit_attempt_refusal_is_unchanged(self):
        owner,op,_=self.history_owner();owner._owner_emit_attempted=True
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
        self.assertFalse(owner._history_attempted);self.assertIs(op,owner._operation)
    def test_thread_setup_attempt_stays_terminal(self):
        owner,op,_=self.history_owner();error=RuntimeError('OWN history Thread setup fault before native constructor')
        with mock.patch.object(producer.threading,'Thread',side_effect=error):
            self.assertIs(owner,owner.freeze_command_history())
        self.history_snapshot('setup-terminal',owner)
        self.assertTrue(owner._history_attempted);self.assertIsNone(owner._workers[-1]['_thread'])
        self.assertFalse(owner._workers[-1]['call_done']);self.assertTrue(owner._workers[-1]['start_settled'])
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
    def test_private_primary_survives_cache_secondary_and_stale_rows(self):
        owner,op,_=self.history_owner();original=op._command_attempts
        self.actions['callback']=lambda:setattr(op,'_command_attempts',list(original))
        actual=producer._RetainedPreflightOwner._cache_command_history
        error=OSError(5,'OWN cache publication fault');calls=[]
        def cache(current,rows,checked,quarantined):
            calls.append((checked,quarantined))
            if len(calls)>1:raise error
            return actual(current,rows,checked,quarantined)
        with mock.patch.object(producer._RetainedPreflightOwner,'_cache_command_history',cache):
            rows=self.freeze_history(owner)
        self.assertTrue(owner._history_quarantined);self.assertIsNotNone(owner._history_primary_error)
        self.assertIsNot(error,owner._history_primary_error);self.assertIs(error,owner._history_secondary_errors[0])
        self.assertFalse(rows[0]['quarantined']) # old PUBLIC row is historical; private state rules
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
    def tearDown(self):
        # Exact finite-unit handles only. No source finish/next spawn or marker backfill.
        pre=[];buffers=[]
        operations=[]
        for owner in self.owners:
            if owner._operation is not None and all(owner._operation is not op for op in operations):operations.append(owner._operation)
        for op in self.known:
            if all(op is not item for item in operations):operations.append(op)
        for op in operations:
            data=op.__dict__;buffer=data.get('output_buffer')
            if type(buffer) is bytes:
                with (self.base/('before-buffer-'+str(len(buffers))+'.bin')).open('xb') as out:out.write(buffer)
                buffers.append(dict(size=len(buffer),sha256=digest(buffer)))
            pre.append(dict(pending=data.get('pending') if type(data.get('pending')) is bool else None,
                finished=data.get('finished') if type(data.get('finished')) is bool else None,
                result_is_None=data.get('result') is None,records=len(data.get('records',[]))))
        with (self.base/'before-unit-teardown.json').open('x') as out:json.dump(pre,out,indent=2)
        self.actions.clear()
        for event in self.barriers:event.set()
        for gate in self.gates:self.release(gate)
        threads=[]
        for owner in self.owners:
            thread=owner._thread
            if thread is not None and all(thread is not item for item in self.history_threads):self.history_threads.append(thread)
        for thread in self.history_threads:
            returned=thread.join(3);threads.append(dict(ident=thread.ident,join_return_is_None=returned is None,alive=thread.is_alive()))
        actors=[];waited=[];closed=[]
        for op in operations:
            data=op.__dict__;records=data.get('records')
            if type(records) is list and records and data.get('process') is not None:
                while records[-1]['output_eof'] is not True:self.actual_drain(op,self.time.monotonic()+1)
            source=next((item for item in self.history_sources if item['op'] is op),None)
            attempts=() if source is None else source['attempts']
            for attempt in attempts:
                child=attempt['process']
                if child is not None and all(child is not item for item in waited):
                    status=child.wait(3);waited.append(child)
                    actors.append(dict(role='command',pid=child.pid,status=status,method_marker_not_backfilled=True))
            for aux in data.get('auxiliary_operations',[]):
                if aux.process is None:continue
                result=None
                while result is None:result=self.actual_aux_wait(aux,1)
                child=aux.process
                if all(child is not item for item in waited):
                    status=child.wait(3);waited.append(child)
                    actors.append(dict(role='auxiliary',pid=child.pid,status=status,
                        outputs=result.get('outputs'),returncode=result.get('returncode')))
            writers=[attempt.get('log') for attempt in attempts]
            writers += [data.get('log'),data.get('events')]
            for writer in writers:
                if writer is None or any(writer is item for item in closed):continue
                closed.append(writer)
                if writer.closed:continue
                fd=writer.fileno();held=os.fstat(fd);path=Path(writer.name);now=path.stat()
                self.assertEqual((held.st_dev,held.st_ino),(now.st_dev,now.st_ino))
                writer.close()
                self.history_reports.append(dict(fixture_only_known_writer_close=dict(fd=fd,closed=writer.closed)))
            if source is not None:
                self.assertFalse(source['sentinel'].exists())
                output=Path(data['output_log'].name).read_bytes()
                stream=data['output_hash'].hexdigest()
                self.history_reports.append(dict(current_merged_output=dict(size=len(output),sha256=digest(output),stream_sha256=stream,eof=records[-1]['output_eof'])))
                self.assertEqual(digest(output),stream);self.assertTrue(records[-1]['output_eof'])
        with (self.base/'unit-teardown.json').open('x') as out:json.dump(dict(threads=threads,actors=actors,original_buffers=buffers,notes=self.history_reports),out,indent=2)
        self.assertTrue(all(not row['alive'] for row in threads))
        self.assertTrue(all(row['status']==0 for row in actors))

    def test_foreign_current_Popen_quarantines_without_losing_either(self):
        owner,op,_=self.history_owner();original=op.process;foreign=op.auxiliary_operations[-1].process
        self.assertIsNot(original,foreign);op.process=foreign
        try:
            rows=self.freeze_history(owner)
            self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[0]['snapshot_checked'])
            self.assertTrue(any(item is original for item in owner._history_binding))
            self.assertTrue(any(item is foreign for item in owner._history_binding))
        finally:op.process=original
    def test_current_public_record_must_match_last_record(self):
        owner,op,_=self.history_owner();original=op.records[-1];copy=dict(original);op.records.append(copy)
        try:
            rows=self.freeze_history(owner)
            self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[0]['snapshot_checked'])
            self.assertIs(original,owner._history_current_attempt['record'])
        finally:self.assertIs(copy,op.records.pop())
    def test_callback_cannot_clear_original_immutable_binding(self):
        owner,op,_=self.history_owner();child=op.process
        self.actions['callback']=lambda:owner._history_binding.clear()
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['quarantined'])
        self.assertIs(type(owner._history_binding),tuple)
        self.assertTrue(any(item is child for item in owner._history_binding))



class AllocatedCommandProcessTests(unittest.TestCase):
    """Actual finite OWN Python capsules; no SDK/canonical/physical closure."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='allocated-popen-',dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.capsules=[];self.states=[];self.threads=[]
    def run_case(self,mode,observe_history=False):
        import pathlib,types,time,fcntl,errno
        P=self.base
        source=Path(producer.__file__).read_bytes()
        buffers={'tool/native_perf_build_producer.py':source}
        expected={'tool/native_perf_build_producer.py':digest(source)}
        sha=digest
        real_class=producer._COMMAND_POPEN_TYPE
        real_init=type.__getattribute__(real_class,'__init__')
        real_pipe=os.pipe
        child_code=("import sys,time,json,os\nfrom pathlib import Path\n"
            "ready,gate=map(Path,sys.argv[1:])\n"
            "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_ALLOC_UNIT')}))\n"
            "deadline=time.monotonic()+8\n"
            "while not gate.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
            "raise SystemExit(0 if gate.exists() else 78)\n")
        def put(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        def typename(value):return type.__dict__['__name__'].__get__(type(value),type)
        def identity(value):return (value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink)
        base=P/mode;base.mkdir();repo=base/'repo';repo.mkdir()
        ready=base/'ready.json';gate=base/'release';sentinel=base/'FORBIDDEN-next'
        argv=[sys.executable,'-c',child_code,str(ready),str(gate)]
        next_argv=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
        injected=OSError(5,'OWN injected AFTER real Popen initialization') if mode=='oserror' else RuntimeError('OWN injected AFTER real Popen initialization')
        state=dict(op=None,child=None,child_wait=None,pipe=[],before_init=None,real_init_returned=False,
         unexpected_initializations=[],foreign_calls=0,allocator_calls=0,factory_calls=0,args=None,kwargs=None,public_error=None,returned=False)
        self.states.append(state)
        def own_pipe():
         pair=real_pipe()
         if state['op'] is not None and not state['pipe']:
          # Exact returned creator descriptors retained before metadata.
          state['pipe']=[dict(fd=fd,identity=None,access=None) for fd in pair]
          for row in state['pipe']:
           row['identity']=identity(os.fstat(row['fd']))
           row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
         return pair
        def initializer(instance,*args,**kwargs):
         state['child']=instance
         if len(args)!=1 or args[0]!=argv:
          state['unexpected_initializations'].append(dict(argument_count=len(args)))
          raise RuntimeError('UNDECLARED initializer refused BEFORE native Popen init')
         state['args']=args;state['kwargs']=kwargs
         op=state['op'];attempt=op._command_attempt
         state['before_init']=dict(allocated_reference_present=attempt.get('allocated_process') is instance,
          returned_process_present=attempt.get('process') is instance,source_process_present=op.process is instance,
          actual_instance_exact_class=type(instance) is real_class)
         real_init(instance,*args,**kwargs)
         state['real_init_returned']=True;state['child_wait']=instance.wait
         state['pid_after_real_init']=instance.pid
         if mode in ('oserror','runtime'):raise injected
         if mode=='false_return':return False
         return None
        def foreign_allocator(cls,*args,**kwargs):
         state['allocator_calls']+=1
         raise RuntimeError('foreign allocator BEFORE native allocation')
        def foreign_factory(*args,**kwargs):
         state['factory_calls']+=1
         raise RuntimeError('foreign factory BEFORE native allocation')
        def foreign_initializer(instance,*args,**kwargs):
         state['foreign_calls']+=1;state['uninitialized_instance']=instance
         raise RuntimeError('OWN foreign initializer hook BEFORE native initializer')
        name='allocated_process_capsule_'+sha(str(base).encode())[:16]
        assert name not in sys.modules
        mod=types.ModuleType(name);mod.__file__=str(Path(producer.__file__).resolve());sys.modules[name]=mod
        self.capsules.append(mod)
        outer_init=real_init if mode in ('class_drift','allocator_drift','factory_drift') else initializer
        try:
         with mock.patch.object(real_class,'__init__',new=outer_init):
          exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
          actual_event=mod.CommandProducer._event;actual_producer_init=mod.CommandProducer.__init__
          def producer_init(op,*args,**kwargs):
           state['op']=op
           return actual_producer_init(op,*args,**kwargs)
          def event(op,event_name,**fields):
           if event_name=='command_start':state['op']=op
           return actual_event(op,event_name,**fields)
          def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
          factory_init=foreign_initializer if mode=='class_drift' else outer_init
          factory_new=foreign_allocator if mode=='allocator_drift' else mod._COMMAND_POPEN_NEW
          factory=foreign_factory if mode=='factory_drift' else real_class
          actual_dispatch=mod.CommandProducer._initialize_command_process
          def dispatch(current,*callargs):
           if mode=='initializer_global_drift':
            saved=mod._COMMAND_POPEN_INIT;mod._COMMAND_POPEN_INIT=foreign_initializer
            try:return actual_dispatch(current,*callargs)
            finally:mod._COMMAND_POPEN_INIT=saved
           if mode=='initializer_arguments_drift':
            saved_repo=current.repo;saved_environment=current.environment
            alternate=base/'alternate-repo';alternate.mkdir()
            current.repo=alternate;current.environment=dict(saved_environment);current.environment['OWN_ALLOC_UNIT']='DRIFT'
            try:return actual_dispatch(current,*callargs)
            finally:current.repo=saved_repo;current.environment=saved_environment
           return actual_dispatch(current,*callargs)
          with mock.patch.object(mod.CommandProducer,'__init__',new=producer_init), \
               mock.patch.object(mod.CommandProducer,'_source_guard',lambda op:None), \
               mock.patch.object(mod.CommandProducer,'_input_guard',lambda op:None), \
               mock.patch.object(mod.CommandProducer,'_make_archive',archive), \
               mock.patch.object(mod.CommandProducer,'_event',event), \
               mock.patch.object(mod.CommandProducer,'_initialize_command_process',dispatch), \
               mock.patch.object(real_class,'__init__',new=factory_init), \
               mock.patch.object(mod,'_COMMAND_POPEN_NEW',new=factory_new), \
               mock.patch.object(subprocess,'Popen',new=factory), \
               mock.patch.object(os,'pipe',new=own_pipe):
           try:
            environment=dict(os.environ);environment['OWN_ALLOC_UNIT']=mode
            result=mod.start_fixture(repo=repo,source_commit='a'*40,runtime_commit='a'*40,
             run_dir=base/'run',expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
             commands=[argv,next_argv],lease_check=lambda:None,env_delta={'OWN_ALLOC_UNIT':mode})
            state['returned']=True
           except BaseException as error:state['public_error']=error
        finally:
         sys.modules.pop(name)
        op=state['op'];data={} if op is None else op.__dict__
        attempt=data.get('_command_attempt');attempt={} if type(attempt) is not dict else attempt
        child=state['child'];before_buffer=data.get('output_buffer')
        if type(before_buffer) is bytes:
         with (base/'original-buffer-before-unit-cleanup.bin').open('xb') as out:out.write(before_buffer)
        report=dict(mode=mode,source_sha256=expected['tool/native_perf_build_producer.py'],
         scope='actual finite Popen/unit constructor boundary, not observed original SDK/kernel failure',
         before_init=state['before_init'],real_init_returned=state['real_init_returned'],
         source_call_returned=state['returned'],foreign_initializer_calls=state['foreign_calls'],
         foreign_allocator_calls=state['allocator_calls'],foreign_factory_calls=state['factory_calls'],
         unexpected_initializer_calls=state['unexpected_initializations'],
         public_error_type=None if state['public_error'] is None else typename(state['public_error']),
         private_primary_is_injected=data.get('_command_history_primary_error') is injected,
         private_primary_is_public=data.get('_command_history_primary_error') is state['public_error'],
         original_attempt_retains_allocated=child is not None and attempt.get('allocated_process') is child,
         original_attempt_retains_returned=child is not None and attempt.get('process') is child,
         source_process_is_child=child is not None and data.get('process') is child,
         producer_pending=data.get('pending') if type(data.get('pending')) is bool else None,
         producer_finished=data.get('finished') if type(data.get('finished')) is bool else None,
         original_wait_observed=attempt.get('wait_observed'),
         original_wait_status=attempt.get('wait_status'),source_record_count=len(data.get('records',[])),
         source_result_is_None=data.get('result') is None,
         native_wait_status=None,native_wait_observed=False,unit_FD_cleanup=[],unit_writer_cleanup=[],
         real_class_exact=child is None or type(child) is real_class)
        if state['kwargs'] is not None:
         kw=state['kwargs']
         report['constructor_arguments']=dict(argv_exact=state['args'][0]==argv,cwd_exact=kw.get('cwd')==repo,
          stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_creator_writer=bool(state['pipe']) and kw.get('stdout')==state['pipe'][1]['fd'],
          stderr_STDOUT=kw.get('stderr')==subprocess.STDOUT,close_fds=kw.get('close_fds'),
          environment_same_object=kw.get('env') is data.get('environment'),
          declared_unit_environment=kw.get('env',{}).get('OWN_ALLOC_UNIT')==mode)
        put(base/'before-unit-cleanup.json',report)
        if observe_history:
         owner=mod._RetainedPreflightOwner('fixture','d'*32,dict(lease_check=op.lease_check))
         owner._operation=op;owner._failed=True;owner._initialized=state['returned']
         owner._pending=op.pending;owner._finished=op.finished
         synthetic=RuntimeError('SYNTHETIC failed owner for DATA validation only')
         owner._first_error_object=synthetic;owner._first_error='RuntimeError'
         owner.freeze_command_history();thread=owner._thread;self.threads.append(thread)
         view=owner.observe(2);rows=owner.command_history_observations()
         report['history_view']=dict(view);report['history_rows']=[dict(row) for row in rows]
         put(base/'history-before-unit-cleanup.json',dict(view=dict(view),rows=report['history_rows']))
         self.assertTrue(view['call_done']);self.assertTrue(view['worker_joined'])
        
        if state['real_init_returned']:
         end=time.monotonic()+3
         while not ready.exists() and time.monotonic()<end:time.sleep(.005)
         report['ready_observed']=ready.exists()
         if ready.exists():
          ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw)
          report['ready_data']=json.loads(ready_raw)
         # This is a finite fixture release directory, never a GO token.
         gate.mkdir(mode=0o700)
         status=state['child_wait'](3)
         state['unit_wait_observed']=True;state['unit_wait_status']=status
         report['native_wait_status']=status;report['native_wait_observed']=True
         assert type(status) is int
         # Exact METHOD return saved before FD/writer cleanup or source metadata.
         put(base/'actual-wait-before-FD-cleanup.json',dict(pid=child.pid,status=status,method_return_exact_int=True,
          source_wait_marker_not_reconstructed=True,not_fresh_waitsyscall_or_physicalclosure=True))
        elif child is not None and not state['unexpected_initializations']:
         # A real initializer failure is outside the injected-after-normal-return fixture.
         # Preserve EX rather than infer absent child or release on partial state.
         put(base/'unexpected-native-initializer-refusal.json',dict(known_object_retained=True,status=None,
          no_invented_zero=True,physical_EX_retained=True))
         state['unexpected_native_initializer_failure']=True
         raise AssertionError('unexpected native initializer failure; exact state retained for teardown')
        # Retired numbers never grant close authority. These are original unit creator ends.
        for row in reversed(state['pipe']):
         fd=row['fd'];entry=dict(fd=fd,role='writer' if row['access']==os.O_WRONLY else 'reader',unit_only=True)
         try:now=os.fstat(fd)
         except OSError as error:
          entry['observed_errno']=error.errno;entry['normal_close_observed']=None
          assert error.errno==errno.EBADF
         else:
          assert identity(now)==tuple(row['identity'])
          assert fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
          if row['access']==os.O_RDONLY:
           chunks=[];eof=False
           while True:
            raw=os.read(fd,65536)
            if not raw:eof=True;break
            chunks.append(raw)
           suffix=b''.join(chunks)
           with (base/'unit-reader-suffix.bin').open('xb') as out:out.write(suffix)
           entry.update(eof=eof,size=len(suffix),sha256=sha(suffix))
          entry['close_intent']=True
          result=os.close(fd);entry['normal_close_observed']=result is None
         report['unit_FD_cleanup'].append(entry)
        writers=[] if op is None else [data.get('log'),data.get('output_log'),data.get('events')]
        seen=[]
        for writer in writers:
         if writer is None or any(writer is item for item in seen):continue
         seen.append(writer);entry=dict(closed_before_unit_cleanup=writer.closed)
         if not writer.closed:
          fd=writer.fileno();held=os.fstat(fd);path=pathlib.Path(writer.name)
          assert identity(held)==identity(path.stat())
          entry['close_intent']=True;result=writer.close()
          entry.update(normal_close_return=result is None,closed_after=writer.closed)
         report['unit_writer_cleanup'].append(entry)
        report['source_wait_marker_after_unit_cleanup']=attempt.get('wait_observed')
        report['forbidden_next_absent']=not sentinel.exists()
        report['no_library_backfill_or_source_retag']=attempt.get('wait_observed') is False
        for path in sorted((base/'run').glob('*.log')):
         raw=path.read_bytes()
         with (base/(path.name+'.retained')).open('xb') as out:out.write(raw)
        if mode in ('normal','initializer_global_drift','initializer_arguments_drift'):
         passed=(state['returned'] and state['public_error'] is None and report['original_attempt_retains_returned']
          and report['source_process_is_child'] and report['native_wait_status']==0 and all(report['constructor_arguments'].values()))
        elif mode in ('class_drift','allocator_drift','factory_drift'):passed=state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0
        else:passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present']
          and report['original_attempt_retains_allocated'] and report['native_wait_status']==0)
        report['expected_property_passed']=passed
        report['declared_boundary_reached']=(op is not None and bool(state['pipe']) and (mode in ('class_drift','allocator_drift','factory_drift') or state['real_init_returned']))
        put(base/'result.json',report);return report
        pass
    def test_retains_before_actual_init_then_OSError(self):
        row=self.run_case('oserror')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['original_attempt_retains_returned']);self.assertTrue(row['original_attempt_retains_allocated'])
    def test_retains_before_actual_init_then_RuntimeError(self):
        row=self.run_case('runtime')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['original_attempt_retains_returned']);self.assertTrue(row['original_attempt_retains_allocated'])
    def test_non_None_initializer_return_keeps_actual_instance(self):
        row=self.run_case('false_return')
        self.assertTrue(row['expected_property_passed']);self.assertEqual('TypeError',row['public_error_type'])
        self.assertTrue(row['private_primary_is_public'])
    def test_normal_constructor_arguments_and_return_are_preserved(self):
        row=self.run_case('normal')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['before_init']['allocated_reference_present'])
        self.assertTrue(row['original_attempt_retains_returned']);self.assertTrue(row['source_process_is_child'])
    def test_initializer_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('class_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_allocator_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('allocator_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_allocator_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_factory_binding_drift_refuses_foreign_hook(self):
        row=self.run_case('factory_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_factory_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_normal_allocated_history_remains_checked_DATA_only(self):
        row=self.run_case('normal',True);rows=row['history_rows']
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        command=next(item for item in rows if item['role']=='command')
        self.assertTrue(command['retained_allocated_process']);self.assertEqual(command['pid'],command['allocated_pid'])
        self.assertTrue(command['initializer_result_valid'])
        for item in rows:
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(item[flag])
    def test_failed_initializer_allocated_actor_remains_unknown_DATA(self):
        row=self.run_case('oserror',True);rows=row['history_rows']
        self.assertFalse(rows[0]['snapshot_checked']);self.assertTrue(rows[0]['quarantined'])
        command=next(item for item in rows if item['role']=='command')
        self.assertTrue(command['retained_allocated_process']);self.assertFalse(command['retained_process'])
        self.assertIs(type(command['allocated_pid']),int);self.assertIsNone(command['allocated_cached_returncode'])
        self.assertTrue(command['start_outcome_unknown']);self.assertFalse(command['initializer_returned'])
    def tearDown(self):
        # SAME known unit handles only. This is never live closure/recovery.
        rows=[]
        for thread in self.threads:
            returned=thread.join(3);rows.append(dict(kind='thread',join_return_is_None=returned is None,alive=thread.is_alive()))
            self.assertFalse(thread.is_alive())
        for state in self.states:
            if state.get('real_init_returned') and state.get('child_wait') is not None:
                child=state['child']
                if state.get('unit_wait_observed'):status=state['unit_wait_status'];origin='already_recorded_actual_unit_wait'
                else:status=state['child_wait'](3);origin='actual_unit_teardown_wait'
                rows.append(dict(kind=origin,pid=child.pid,status=status,not_source_witness=True))
                self.assertEqual(0,status)
        with (self.base/'unit-final-teardown.json').open('x') as out:json.dump(rows,out,indent=2)

    def test_captured_initializer_is_invoked_despite_late_global_rebind(self):
        row=self.run_case('initializer_global_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertTrue(row['real_init_returned']);self.assertEqual(0,row['native_wait_status'])
    def test_constructor_arguments_are_bound_before_initializer_seam(self):
        row=self.run_case('initializer_arguments_drift')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['real_init_returned'])
        self.assertTrue(all(row['constructor_arguments'].values()))
        self.assertEqual('initializer_arguments_drift',row['ready_data']['case'])



class AllocatedAuxiliaryProcessTests(unittest.TestCase):
    """Actual finite Auxiliary capsules; no SDK/canonical/physical closure."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='aux-allocated-',dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.states=[];self.owners=[]
    def run_case(self,mode,observe_history=False):
        import pathlib,types,fcntl,errno,time
        P=self.base;R=Path(producer.__file__).resolve().parent.parent
        source=Path(producer.__file__).read_bytes();h={'tool/native_perf_build_producer.py':digest(source)}
        buffers={'tool/native_perf_build_producer.py':source};sha=digest
        def put(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        def identity(st):return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink)
        def native_name(value):return type.__dict__['__name__'].__get__(type(value),type)
        real_class=producer._COMMAND_POPEN_TYPE;real_init=real_class.__init__;real_pipe=os.pipe
        child_code=("import os,time,json,sys\nfrom pathlib import Path\nready,release=map(Path,sys.argv[1:])\n"
          "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_AUX_ALLOC_UNIT')}))\n"
          "deadline=time.monotonic()+8\n"
          "while not release.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
          "raise SystemExit(0 if release.exists() else 78)\n")
        C=P/mode;C.mkdir(mode=0o700);repo=C/'repo';repo.mkdir();run=C/'run';run.mkdir()
        ready=C/'ready.json';release=C/'release'
        argv=[sys.executable,'-c',child_code,str(ready),str(release)]
        environment=dict(os.environ);environment['OWN_AUX_ALLOC_UNIT']=mode
        injected=OSError(5,'OWN AUX fault AFTER real original init') if mode=='oserror' else RuntimeError('OWN AUX fault AFTER real original init')
        state=dict(mode=mode,aux=None,child=None,wait=None,real_init_returned=False,before_init=None,args=None,kwargs=None,foreign_calls=0,init_entered=False,pipe_pairs=[],known_logs=[],public_error=None,start_return=None,unit_wait_observed=False,unit_wait_status=None,repr_hook_calls=0,allocator_calls=0,factory_calls=0)
        self.states.append(state);state['unit_release']=release
        if mode=='repr_hook':
         hook_fault=RuntimeError('OWN old repr hook fault')
         class BadRepr(RuntimeError):
          def __repr__(self):
           state['repr_hook_calls']+=1
           raise hook_fault
         injected=BadRepr('OWN AFTER actual Auxiliary init')
        def foreign_new(cls,*args,**kwargs):
         state['allocator_calls']+=1
         raise RuntimeError('OWN foreign allocator BEFORE native allocation')
        def foreign_factory(*args,**kwargs):
         state['factory_calls']+=1
         raise RuntimeError('OWN foreign factory BEFORE native allocation')
        def own_pipe():
         pair=real_pipe()
         if not state['init_entered'] and len(state['pipe_pairs'])<2:
          rows=[dict(fd=fd,identity=None,access=None) for fd in pair];state['pipe_pairs'].append(rows)
          for row in rows:
           row['identity']=identity(os.fstat(row['fd']));row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
         return pair
        def initializer(instance,*args,**kwargs):
         # Exact object and original callable retained before any real initializer I/O.
         state['child']=instance;state['init_entered']=True;state['args']=args;state['kwargs']=kwargs
         assert len(args)==1 and args[0]==argv
         aux=state['aux'];record=getattr(aux,'_process_allocation',None)
         for stream in aux.streams.values():
          if stream['log'] is not None:state['known_logs'].append(stream['log'])
         state['before_init']=dict(source_record_native=type(record) is dict,
          allocated_reference_present=type(record) is dict and record.get('allocated_process') is instance,
          returned_process_present=aux.process is instance,pending=aux.pending,finished=aux.finished,
          source_argv_tuple=type(aux.argv) is tuple,source_environment_mappingproxy=type(aux.environment) is types.MappingProxyType,
          actual_instance_exact_class=type(instance) is real_class)
         put(C/'before-real-initializer.json',state['before_init'])
         real_init(instance,*args,**kwargs)
         state['real_init_returned']=True;state['wait']=instance.wait
         if mode in ('oserror','runtime','repr_hook'):raise injected
         if mode=='false_return':return False
         return None
        def outer_init(instance,*args,**kwargs):return initializer(instance,*args,**kwargs)
        def foreign_init(instance,*args,**kwargs):
         state['foreign_calls']+=1;state['uninitialized_instance']=instance
         raise RuntimeError('OWN foreign Auxiliary initializer BEFORE real native init')
        name='_aux_allocation_after_'+mode;mod=types.ModuleType(name);mod.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[name]=mod
        try:
         with mock.patch.object(real_class,'__init__',outer_init):
          exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
          aux=object.__new__(mod.AuxiliaryCommand);state['aux']=aux
          actual_dispatch=mod.AuxiliaryCommand._initialize_process
          def dispatch(current,initializer,instance,arguments):
           if mode=='initializer_global_drift':
            saved=mod._COMMAND_POPEN_INIT;mod._COMMAND_POPEN_INIT=foreign_init
            try:return actual_dispatch(current,initializer,instance,arguments)
            finally:mod._COMMAND_POPEN_INIT=saved
           if mode=='initializer_arguments_drift':
            saved_cwd=current.cwd;saved_environment=current.environment
            alternate=C/'alternate-repo';alternate.mkdir()
            current.cwd=alternate;current.environment=types.MappingProxyType({'OWN_AUX_ALLOC_UNIT':'DRIFT'})
            try:return actual_dispatch(current,initializer,instance,arguments)
            finally:current.cwd=saved_cwd;current.environment=saved_environment
           return actual_dispatch(current,initializer,instance,arguments)
          checks=[0]
          def callback():
           checks[0]+=1
           if mode=='ledger_drift' and checks[0]==2:
            state['original_allocation']=aux._process_allocation
            aux._process_allocation=dict(aux._process_allocation)
          mod.AuxiliaryCommand.__init__(aux,directory=run,name='owned-aux',argv=argv,cwd=repo,environment=environment,lease_check=callback,stdout_max=1024**2,stderr_max=1024**2)
          with mock.patch.object(real_class,'__init__',foreign_init if mode=='class_drift' else outer_init), \
               mock.patch.object(mod,'_COMMAND_POPEN_NEW',foreign_new if mode=='allocator_drift' else mod._COMMAND_POPEN_NEW), \
               mock.patch.object(subprocess,'Popen',foreign_factory if mode=='factory_drift' else real_class), \
               mock.patch.object(mod.AuxiliaryCommand,'_initialize_process',dispatch),mock.patch.object(os,'pipe',own_pipe):
           try:state['start_return']=aux.start()
           except BaseException as error:state['public_error']=error
        finally:sys.modules.pop(name)
        child=state['child'];record=getattr(aux,'_process_allocation',None)
        report=dict(mode=mode,source_sha256=h['tool/native_perf_build_producer.py'],actual_real_init_returned=state['real_init_returned'],source_before_init=state['before_init'],
         source_allocated_reference_after=child is not None and type(record) is dict and record.get('allocated_process') is child,
         source_process_is_child=child is not None and aux.process is child,
         source_process_None=aux.process is None,source_pending=aux.pending,source_finished=aux.finished,
         source_status=aux.status,source_natural_wait_before_unit=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status,process_is_child=child is not None and aux._natural_wait_process is child),
         source_result_type=native_name(state['start_return']),public_error_type=None if state['public_error'] is None else native_name(state['public_error']),
         source_spawn_error_is_string=type(aux.spawn_error) is str,foreign_initializer_calls=state['foreign_calls'],
         private_primary_is_injected=aux._allocation_primary_error is injected,private_primary_type=None if aux._allocation_primary_error is None else native_name(aux._allocation_primary_error),
         native_wait_observed=False,native_wait_status=None,unit_FD_cleanup=[],unit_writer_cleanup=[],
         no_original_SDK_kernel_RAM_defect_claim=True,no_source_state_backfill_or_retag=True,
         repr_hook_calls=state['repr_hook_calls'],foreign_allocator_calls=state['allocator_calls'],foreign_factory_calls=state['factory_calls'],
         public_error_is_hook_fault=mode=='repr_hook' and state['public_error'] is hook_fault,
         public_error_is_injected=state['public_error'] is injected,
         ledger_original_retained=mode=='ledger_drift' and aux._process_allocation_binding[0] is state.get('original_allocation'))
        state['report']=report
        if state['kwargs'] is not None:
         kw=state['kwargs'];stdout=aux.streams['stdout'];stderr=aux.streams['stderr']
         writers=[rows[1]['fd'] for rows in state['pipe_pairs']]
         report['constructor_arguments']=dict(exact_class=type(child) is real_class,argv_exact=state['args'][0]==argv,
          cwd_exact=kw.get('cwd')==repo,environment_equal=kw.get('env')==environment,
          environment_is_original_start_copy=type(kw.get('env')) is dict and kw.get('env') is not aux.environment and kw.get('env') is not environment,
          stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_writer=len(writers)==2 and kw.get('stdout')==writers[0],
          stderr_original_writer=len(writers)==2 and kw.get('stderr')==writers[1],writers_distinct=len(writers)==2 and writers[0]!=writers[1],close_fds=kw.get('close_fds') is True)
        put(C/'source-after-call-before-unit-wait.json',report)
        if observe_history:
         op=object.__new__(mod.CommandProducer)
         op._command_attempts=[];op._command_attempt=None;op.records=[];op.auxiliary_operations=[aux]
         op.process=None;op.pending=False;op.finished=True;op.lease_check=aux.lease_check
         owner=mod._RetainedPreflightOwner('fixture','e'*32,dict(lease_check=aux.lease_check))
         self.owners.append(owner);owner._operation=op;owner._failed=True;owner._initialized=True
         owner._pending=False;owner._finished=True
         original=RuntimeError('SYNTHETIC failed owner for Auxiliary DATA only')
         owner._first_error_object=original;owner._first_error='RuntimeError'
         owner.freeze_command_history();view=owner.observe(2);rows=owner.command_history_observations()
         report['history_view']=dict(view);report['history_rows']=[dict(row) for row in rows]
         private=owner._history_primary_error
         report['history_private_error_type']=None if private is None else native_name(private)
         frames=[]
         if private is not None:
             tb=BaseException.__dict__['__traceback__'].__get__(private,BaseException)
             while tb is not None:
                 frames.append(dict(file=tb.tb_frame.f_code.co_filename,line=tb.tb_lineno,function=tb.tb_frame.f_code.co_name));tb=tb.tb_next
         report['history_private_error_frames']=frames
         put(C/'history-before-unit-wait.json',dict(view=dict(view),rows=report['history_rows']))

        if state['real_init_returned']:
         until=time.monotonic()+3
         while not ready.exists() and time.monotonic()<until:time.sleep(.005)
         assert ready.exists()
         ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw);report['ready_data']=json.loads(ready_raw)
         assert report['ready_data']==dict(cwd=str(repo),case=mode)
         release.mkdir(mode=0o700)
         status=state['wait'](3);state['unit_wait_observed']=True;state['unit_wait_status']=status
         report['native_wait_observed']=True;report['native_wait_status']=status
         # Save exact SAMEPopen.wait return BEFORE root FD/log cleanup or later source wait API.
         put(C/'actual-wait-before-root-FD-cleanup.json',dict(pid=child.pid,status=status,exact_signed_int=type(status) is int,source_wait_before_unit=report['source_natural_wait_before_unit'],root_early_instance_only_unit_cleanup_not_sourcebackfill=True,not_fresh_syscall_or_physicalclosure_proof=True))
         assert type(status) is int and status==0
         if mode in ('normal','initializer_global_drift','initializer_arguments_drift'):
          # One affected actual Auxiliary caller. Its wait may return cached status0, not fresh syscall proof.
          returned=aux.wait(3);report['normal_source_wait_API_return']=returned
          put(C/'normal-source-wait-API-return.json',dict(returned=returned,natural_wait_observed=aux._natural_wait_observed,natural_wait_status=aux._natural_wait_status,pending=aux.pending,finished=aux.finished))
        elif child is not None:
         put(C/'unknown-real-init-quarantine.json',dict(exact_object_retained=True,status=None,no_invented_zero=True))
         raise AssertionError('unexpected real initializer failure; actual EX must remain with retained state')
        for pair in reversed(state['pipe_pairs']):
         for row in reversed(pair):
          fd=row['fd'];entry=dict(fd=fd,unit_only=True,normal_close_observed=None)
          try:now=os.fstat(fd)
          except OSError as error:
           assert error.errno==errno.EBADF;entry['observed_errno']=error.errno
          else:
           assert identity(now)==tuple(row['identity']) and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
           if row['access']==os.O_RDONLY:
            pieces=[]
            while True:
             raw=os.read(fd,65536)
             if not raw:break
             pieces.append(raw)
            suffix=b''.join(pieces)
            with (C/('unit-reader-'+str(fd)+'-suffix.bin')).open('xb') as out:out.write(suffix)
            entry.update(actual_reader_EOF=True,size=len(suffix),sha256=sha(suffix))
           entry['close_intent']=True;returned=os.close(fd);entry['normal_close_observed']=returned is None
          report['unit_FD_cleanup'].append(entry)
        seen=[]
        for log in state['known_logs']+[stream['log'] for stream in aux.streams.values()]:
         if log is None or any(log is item for item in seen):continue
         seen.append(log);entry=dict(closed_before_unit_cleanup=log.closed)
         if not log.closed:
          fd=log.fileno();held=os.fstat(fd);assert identity(held)==identity(pathlib.Path(log.name).stat())
          entry['close_intent']=True;returned=log.close();entry['normal_close_return']=returned is None;entry['closed_after']=log.closed
         report['unit_writer_cleanup'].append(entry)
        report['source_natural_wait_after_unit']=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status)
        for path in sorted(run.iterdir()):
         if path.is_file():
          raw=path.read_bytes()
          with (C/(path.name+'.retained')).open('xb') as out:out.write(raw)
        if mode in ('normal','initializer_global_drift','initializer_arguments_drift'):
         passed=(report['actual_real_init_returned'] and report['native_wait_status']==0 and report['source_process_is_child'] and all(report['constructor_arguments'].values()) and report['normal_source_wait_API_return']['status']=='success')
        elif mode in ('class_drift','allocator_drift','factory_drift'):passed=state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0
        elif mode=='ledger_drift':passed=report['ledger_original_retained'] and not state['real_init_returned'] and not state['pipe_pairs']
        elif mode=='repr_hook':passed=report['source_allocated_reference_after'] and report['private_primary_is_injected'] and report['public_error_is_injected'] and report['repr_hook_calls']==0
        else:
         passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present'] and report['source_allocated_reference_after'] and report['native_wait_status']==0)
        report['expected_property_passed']=passed
        report['declared_boundary_reached']=(not state['pipe_pairs'] and not state['real_init_returned'] if mode=='ledger_drift' else len(state['pipe_pairs'])==2 and ((state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0 and type(record) is dict and record.get('constructor_attempted') is True) if mode in ('class_drift','allocator_drift','factory_drift') else state['real_init_returned']))

        state['unit_cleanup_complete']=True
        put(C/'result.json',report);return report

    def test_retains_before_actual_initializer_then_OSError(self):
        row=self.run_case('oserror')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['source_process_is_child']);self.assertFalse(row['source_finished'])
        self.assertTrue(row['public_error_is_injected'])
    def test_retains_before_actual_initializer_then_RuntimeError(self):
        row=self.run_case('runtime')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['source_process_is_child'])
    def test_non_None_initializer_return_preserves_allocated_instance(self):
        row=self.run_case('false_return')
        self.assertTrue(row['expected_property_passed']);self.assertEqual('TypeError',row['private_primary_type'])
        self.assertFalse(row['source_process_is_child'])
    def test_normal_original_arguments_two_writers_and_environment_copies(self):
        row=self.run_case('normal')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(all(row['constructor_arguments'].values()))
        self.assertTrue(row['source_before_init']['allocated_reference_present'])
        self.assertFalse(row['source_before_init']['returned_process_present'])
    def test_initializer_drift_refuses_foreign_hook(self):
        row=self.run_case('class_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_allocator_drift_refuses_foreign_hook(self):
        row=self.run_case('allocator_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_allocator_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_factory_drift_refuses_foreign_hook(self):
        row=self.run_case('factory_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_factory_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_captured_initializer_survives_late_global_rebind(self):
        row=self.run_case('initializer_global_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertEqual(0,row['native_wait_status'])
    def test_argument_copies_bind_before_late_initializer_seam(self):
        row=self.run_case('initializer_arguments_drift')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(all(row['constructor_arguments'].values()))
        self.assertEqual('initializer_arguments_drift',row['ready_data']['case'])
    def test_private_first_error_survives_without_repr_hook(self):
        row=self.run_case('repr_hook')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertTrue(row['public_error_is_injected']);self.assertEqual(0,row['repr_hook_calls'])
    def test_replaced_ledger_refuses_before_Popen(self):
        row=self.run_case('ledger_drift')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['ledger_original_retained'])
        self.assertIsNone(row['native_wait_status'])
    def test_normal_allocated_Auxiliary_history_remains_DATA_only(self):
        row=self.run_case('normal',True);rows=row['history_rows']
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        auxiliary=next(item for item in rows if item['role']=='auxiliary')
        self.assertTrue(auxiliary['retained_allocated_process']);self.assertEqual(auxiliary['pid'],auxiliary['allocated_pid'])
        self.assertTrue(auxiliary['constructor_returned']);self.assertFalse(auxiliary['start_outcome_unknown'])
        for item in rows:
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(item[flag])
    def test_failed_initializer_allocated_Auxiliary_stays_unknown_DATA(self):
        row=self.run_case('oserror',True);rows=row['history_rows']
        self.assertFalse(rows[0]['snapshot_checked']);self.assertTrue(rows[0]['quarantined'])
        auxiliary=next(item for item in rows if item['role']=='auxiliary')
        self.assertTrue(auxiliary['retained_allocated_process']);self.assertFalse(auxiliary['retained_process'])
        self.assertIs(type(auxiliary['allocated_pid']),int);self.assertIsNone(auxiliary['allocated_cached_returncode'])
        self.assertTrue(auxiliary['start_outcome_unknown']);self.assertFalse(auxiliary['initializer_returned'])
    def tearDown(self):
        rows=[]
        for owner in self.owners:
            thread=owner._thread
            if thread is not None:
                returned=thread.join(3)
                rows.append(dict(kind='known_unit_thread',join_return_None=returned is None,alive=thread.is_alive()))
                self.assertFalse(thread.is_alive())
        for state in self.states:
            if state.get('real_init_returned'):
                if state.get('unit_wait_observed'):
                    status=state['unit_wait_status'];origin='already_recorded_actual_unit_wait'
                else:
                    gate=state.get('unit_release')
                    if gate is not None and not gate.exists():gate.mkdir(mode=0o700)
                    status=state['wait'](3);origin='actual_unit_teardown_wait'
                rows.append(dict(kind=origin,pid=state['child'].pid,status=status,not_library_witness=True))
                self.assertEqual(0,status)
        with (self.base/'unit-final-teardown.json').open('x') as out:json.dump(rows,out,indent=2)


class AuxiliaryConstructorQuarantineTests(unittest.TestCase):
    """NEW real constructor-uncertainty behavior, not old allocation controls."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='aux-quarantine-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        self.states=[]
    def _case(self,kind):
        import types,time,errno,fcntl
        C=self.base/kind;C.mkdir();repo=C/'repo';repo.mkdir();run=C/'run';run.mkdir()
        ready=C/'ready';release=C/'release'
        code="import sys,time\nfrom pathlib import Path\nr,g=map(Path,sys.argv[1:])\nr.write_bytes(b'READY')\nd=time.monotonic()+8\nwhile not g.exists() and time.monotonic()<d:time.sleep(.005)\nraise SystemExit(0 if g.exists() else 78)\n"
        argv=[sys.executable,'-c',code,str(ready),str(release)]
        raw=Path(producer.__file__).read_bytes()
        native_class=subprocess.Popen;native_init=native_class.__init__;native_wait=native_class.wait
        state=dict(kind=kind,aux=None,child=None,real_init_returned=False,bound_wait=None,
            wait_observed=False,wait_status=None,refs=[],fault=False,calls=[],repr_calls=0,public_error=None,returned=None)
        self.states.append(state)
        first=OSError(5,'NEW finite constructor uncertainty boundary')
        hook_error=RuntimeError('NEW repr hook must never execute')
        if kind=='hostile_repr':
            class Hostile(RuntimeError):
                def __repr__(self):
                    state['repr_calls']+=1
                    raise hook_error
            first=Hostile('NEW actual init then uncertainty')
        def initializer(instance,*args,**kwargs):
            state['child']=instance
            aux=state['aux'];state['original_binding']=aux._process_allocation_binding;state['original_streams']=aux.streams
            # Retain exact creator handles BEFORE metadata and native initializer I/O.
            state['refs']=[dict(role=role,stream=stream,log=stream['log'],reader=stream['fd'],writer=stream['writer'])
                for role,stream in aux.streams.items()]
            for row in state['refs']:
                row['fd_identity']={}
                for slot in ['reader','writer']:
                    fd=row[slot];st=os.fstat(fd)
                    row['fd_identity'][slot]=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
            native_init(instance,*args,**kwargs)
            state['real_init_returned']=True
            state['bound_wait']=native_wait.__get__(instance,native_class)
            if kind=='post_init_check':
                state['fault']=True;aux._process_allocation_binding=(None,None)
                return None
            if kind=='normal':return None
            state['fault']=True
            if kind=='binding_drift':
                aux._process_allocation_binding=(None,None)
                aux.streams={}
            if kind=='invalid_result':return False
            raise first
        name='_new_constructor_quarantine_'+kind
        capsule=types.ModuleType(name);capsule.__file__=producer.__file__;sys.modules[name]=capsule
        def typename(value):return type.__dict__['__name__'].__get__(type(value),type)
        def save(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        report=None
        try:
            with mock.patch.object(native_class,'__init__',initializer):
                exec(compile(raw,capsule.__file__,'exec'),capsule.__dict__)
                Aux=capsule.AuxiliaryCommand
                aux=object.__new__(Aux);state['aux']=aux
                def lease():
                    if state['fault']:state['calls'].append('lease')
                Aux.__init__(aux,directory=run,name='quarantine',argv=argv,cwd=repo,
                    environment=dict(os.environ),lease_check=lease,stdout_max=1024,stderr_max=1024)
                from contextlib import ExitStack
                with ExitStack() as stack:
                    for method in ['_defer','_complete','_close_slot']:
                        original=getattr(Aux,method)
                        def observed(current,*a,_name=method,_original=original,**kw):
                            if state['fault']:state['calls'].append(_name)
                            return _original(current,*a,**kw)
                        stack.enter_context(mock.patch.object(Aux,method,observed))
                    for helper in ['_write_json','_file_snapshot']:
                        original=getattr(capsule,helper)
                        def observed_helper(*a,_name=helper,_original=original,**kw):
                            if state['fault']:state['calls'].append(_name)
                            return _original(*a,**kw)
                        stack.enter_context(mock.patch.object(capsule,helper,observed_helper))
                    try:state['returned']=aux.start()
                    except BaseException as error:state['public_error']=error
                    primary=aux._allocation_primary_error
                    if kind in ('guard_field_drift','guard_class_drift'):
                        state['saved_primary']=aux._constructor_primary_error;state['saved_quarantined']=aux._constructor_quarantined
                        if kind=='guard_class_drift':
                            class ForeignError(RuntimeError):
                                def __init__(self,*args,**kwargs):
                                    state['foreign_error_constructor_calls']=state.get('foreign_error_constructor_calls',0)+1
                                    super().__init__(*args,**kwargs)
                            aux._constructor_primary_error=ForeignError
                        else:aux._constructor_primary_error=None
                        aux._constructor_quarantined=False
                    calls_before_reentry=list(state['calls'])
                    reentry=None
                    if kind!='normal':
                        try:aux.wait(0)
                        except BaseException as error:reentry=error
                    binding=getattr(aux,'_constructor_quarantine_binding',None)
                    q=binding[0] if type(binding) is tuple and binding and type(binding[0]) is dict else {}
                    source_fds=[]
                    for row in state['refs']:
                        for slot in ['reader','writer']:
                            fd=row[slot]
                            try:
                                st=os.fstat(fd);ident=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
                                source_fds.append(dict(role=row['role'],slot=slot,fd=fd,open_same_identity=ident==row['fd_identity'][slot],errno=None))
                            except OSError as error:
                                source_fds.append(dict(role=row['role'],slot=slot,fd=fd,open_same_identity=False,errno=error.errno))
                    retained=q.get('streams')
                    refs_retained=(type(retained) is tuple and len(retained)==2
                        and all(any(type(item) is tuple and len(item)==5 and item[0]==row['role']
                            and item[1] is row['stream'] and item[2] is row['log']
                            and item[3]==row['reader'] and item[4]==row['writer'] for item in retained)
                            for row in state['refs']))
                    report=dict(kind=kind,source_sha256=hashlib.sha256(raw).hexdigest(),
                        actual_native_initializer_returned=state['real_init_returned'],
                        public_error_is_primary=state['public_error'] is primary and primary is not None,
                        primary_is_injected=primary is first,primary_type=None if primary is None else typename(primary),
                        repr_hook_calls=state['repr_calls'],source_calls_after_fault=calls_before_reentry,
                        source_calls_after_reentry=list(state['calls']),reentry_error_is_primary=reentry is primary and primary is not None,
                        process_is_None=aux.process is None,pending=aux.pending,finished=aux.finished,status=aux.status,
                        natural_wait_observed=aux._natural_wait_observed,natural_wait_status=aux._natural_wait_status,
                        source_fds_before_unit_cleanup=source_fds,
                        original_logs_open_before_unit_cleanup=all(not row['log'].closed for row in state['refs']),
                        private_quarantined=q.get('quarantined') is True,
                        private_first_is_primary=q.get('first_error') is primary and primary is not None,
                        original_refs_retained=refs_retained,
                        original_allocation_binding_retained=q.get('allocation_binding') is state.get('original_binding'),
                        exact_allocated_actor_retained=q.get('allocated_process') is state['child'] and state['child'] is not None,
                        no_original_SDK_kernel_native_canonical_workload=True,unit_cleanup_never_live_recovery_or_marker_backfill=True)
                    original_allocation=state['original_binding'][0]
                    report['foreign_error_constructor_calls']=state.get('foreign_error_constructor_calls',0)
                    report['initializer_returned_recorded']=original_allocation['initializer_returned']
                    report['initializer_result_valid_recorded']=original_allocation['initializer_result_valid']
                    report['constructor_returned_recorded']=original_allocation['constructor_returned']
                    report['quarantine_whole_return_recorded']=q.get('returned')
                    save(C/'source-before-unit-cleanup.json',report)
                    if kind in ('guard_field_drift','guard_class_drift'):
                        aux._constructor_primary_error=state['saved_primary'];aux._constructor_quarantined=state['saved_quarantined']
                        report['synthetic_unit_fields_restored_not_live_recovery']=True
                    assert state['real_init_returned'],'declared native initializer boundary not reached'
                    until=time.monotonic()+3
                    while not ready.exists() and time.monotonic()<until:time.sleep(.005)
                    assert ready.read_bytes()==b'READY'
                    release.mkdir()
                    status=state['bound_wait'](3);state['wait_observed']=True;state['wait_status']=status
                    save(C/'actual-unit-wait-before-FD-cleanup.json',dict(pid=state['child'].pid,status=status,exact_int=type(status) is int,source_wait_before=report['natural_wait_observed']))
                    assert type(status) is int and status==0
                    if kind=='normal':
                        report['normal_source_wait_return']=aux.wait(3)
            cleanup=[]
            # Known finite unit cleanup only: close creator writers BEFORE reading EOF.
            for slot in ['writer','reader']:
                for row in state['refs']:
                    fd=row[slot];entry=dict(role=row['role'],slot=slot,fd=fd)
                    try:
                        st=os.fstat(fd);identity=(st.st_dev,st.st_ino,st.st_mode,fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)
                    except OSError as error:
                        assert error.errno==errno.EBADF;entry['errno']=error.errno
                    else:
                        assert identity==row['fd_identity'][slot]
                        if slot=='reader':
                            data=[]
                            while True:
                                part=os.read(fd,65536)
                                if not part:break
                                data.append(part)
                            suffix=b''.join(data)
                            with (C/(row['role']+'-unit-suffix.bin')).open('xb') as out:out.write(suffix)
                            entry.update(EOF=True,size=len(suffix),sha256=hashlib.sha256(suffix).hexdigest())
                        entry['close_attempted']=True;returned=os.close(fd);entry['close_return_None']=returned is None
                    cleanup.append(entry)
            for row in state['refs']:
                log=row['log']
                if not log.closed:
                    st=os.fstat(log.fileno());path=Path(log.name).stat();assert (st.st_dev,st.st_ino)==(path.st_dev,path.st_ino)
                    log.close()
            report['unit_cleanup']=cleanup;report['unit_wait_status']=state['wait_status']
            report['source_wait_after_unit']=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status)
            report['run_files']=[dict(name=p.name,size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(run.iterdir()) if p.is_file()]
            save(C/'result.json',report);return report
        finally:
            sys.modules.pop(name,None)
            if state['real_init_returned'] and not state['wait_observed']:
                if not release.exists():release.mkdir()
                value=state['bound_wait'](3);state['wait_observed']=True;state['wait_status']=value
                save(C/'exceptional-known-unit-wait.json',dict(status=value,no_source_backfill=True))
    def _assert_quarantine(self,row):
        self.assertTrue(row['actual_native_initializer_returned'])
        self.assertEqual([],row['source_calls_after_fault'])
        self.assertEqual([],row['source_calls_after_reentry'])
        self.assertTrue(row['public_error_is_primary'])
        self.assertTrue(row['reentry_error_is_primary'])
        self.assertEqual(0,row['repr_hook_calls'])
        self.assertTrue(row['process_is_None']);self.assertFalse(row['pending']);self.assertFalse(row['finished'])
        self.assertIsNone(row['status']);self.assertFalse(row['natural_wait_observed']);self.assertIsNone(row['natural_wait_status'])
        self.assertTrue(all(x['open_same_identity'] for x in row['source_fds_before_unit_cleanup']))
        self.assertTrue(row['original_logs_open_before_unit_cleanup'])
        self.assertTrue(row['private_quarantined']);self.assertTrue(row['private_first_is_primary'])
        self.assertTrue(row['original_refs_retained']);self.assertTrue(row['original_allocation_binding_retained'])
        self.assertTrue(row['exact_allocated_actor_retained']);self.assertEqual(0,row['unit_wait_status'])
    def test_real_initializer_error_keeps_original_handles_without_reporting(self):
        row=self._case('error');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_hostile_repr_never_runs_and_original_error_survives(self):
        row=self._case('hostile_repr');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_invalid_None_result_keeps_earliest_TypeError_and_handles(self):
        row=self._case('invalid_result');self._assert_quarantine(row);self.assertEqual('TypeError',row['primary_type'])
    def test_binding_and_stream_drift_retains_original_roots(self):
        row=self._case('binding_drift');self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
    def test_normal_actual_constructor_and_existing_wait_stay_successful(self):
        row=self._case('normal')
        self.assertTrue(row['actual_native_initializer_returned'])
        self.assertEqual(0,row['unit_wait_status'])
        self.assertEqual('success',row['normal_source_wait_return']['status'])
    def tearDown(self):
        rows=[dict(kind=s['kind'],native_init_returned=s['real_init_returned'],actual_wait_observed=s['wait_observed'],status=s['wait_status']) for s in self.states]
        with (self.base/'known-unit-actors-final.json').open('x') as out:json.dump(rows,out,indent=2)
        for row in rows:
            if row['native_init_returned']:
                self.assertTrue(row['actual_wait_observed']);self.assertEqual(0,row['status'])

    def test_post_initializer_check_preserves_separate_return_facts(self):
        row=self._case('post_init_check');self._assert_quarantine(row)
        self.assertTrue(row['initializer_returned_recorded'])
        self.assertTrue(row['initializer_result_valid_recorded'])
        self.assertIsNone(row['constructor_returned_recorded'])
        self.assertIsNone(row['quarantine_whole_return_recorded'])
    def test_missing_primary_scalar_uses_bound_original_first_error(self):
        row=self._case('guard_field_drift');self._assert_quarantine(row)
        self.assertTrue(row['primary_is_injected'])

    def test_error_class_in_primary_field_never_constructed(self):
        row=self._case('guard_class_drift')
        self.assertEqual(0,row['foreign_error_constructor_calls'])
        self._assert_quarantine(row);self.assertTrue(row['primary_is_injected'])
