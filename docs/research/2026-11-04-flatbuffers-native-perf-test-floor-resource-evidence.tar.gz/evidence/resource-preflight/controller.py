import sys,pathlib,json,os,stat,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 assert R.resolve(strict=True)==R
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,v):
  with path.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 oldpath=pathlib.Path('/private/tmp/connectanum-native-perf-current-owned-cache-reclaim/plan.json')
 raw=oldpath.read_bytes();assert len(raw)<16*1024**2;prior=json.loads(raw)
 old92={row['path'] for row in prior['eligible']};oldids={(int(row['identity']['st_dev']),int(row['identity']['st_ino'])) for row in prior['eligible']}
 prior_protected=set(prior['protected']);assert len(old92)==92 and len(prior_protected)==14377
 protected_ids={(int(row['identity']['st_dev']),int(row['identity']['st_ino'])) for row in prior['protected'].values()}
 roots=[R/'native/transport/target',R/'native/bench/target']
 h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/current-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in h.items())
 put(P/'scope-before-workspace-scan.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),roots=[str(x) for x in roots],read_only_metadata_inventory_only=True,no_deletion=True,old92_and_prior14377_paths_and_identities_EXCLUDED_not_reused_as_freshproof=True,prior_plan_input_sha256=sha(raw),current_helper_hashes=h,columns=['path_relative_to_owned_root','kind','identity','exclusion'],identity_columns=['dev','ino','mode','uid','gid','nlink','size','blocks','mtime_ns','ctime_ns','flags'],output_limit_bytes=8*1024**2,entry_limit=50000,no_source_HEAD_tests_build_SDK_native_execution_model_capture_or_cleanup=True,no_symlink_follow_outside_roots=True,no_inactivity_global_atomicity_or_physicalreclaim_proof=True))
 put(P/'conservative-exclusions.json',dict(prior_plan_sha256=sha(raw),old92_paths=sorted(old92),prior_protected_paths=sorted(prior_protected),use='POSITIVE exclusion only; no oldstats-hashes-inactivity evidence reused as fresh eligibility'))
 def ident(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_blocks,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None)]
 counts={};totals={'entries':0,'regular':0,'logical_regular_bytes':0,'allocated_regular_bytes':0,'potential_new_cache_leaves':0,'potential_new_logical_bytes':0,'potential_new_allocated_bytes':0,'symlinks':0,'errors':0};potential=[];rootrows=[];output_bytes=0
 def emit(out,row):
  global_dummy=None
  raw=(json.dumps(row,separators=(',',':'),ensure_ascii=True)+'\n').encode()
  return raw
 with (P/'current-metadata.jsonl').open('xb') as out:
  for root in roots:
   lease.verify_identity()
   try:first=root.lstat()
   except OSError as error:
    row=[root.relative_to(R).as_posix(),'root-error',None,dict(error_type=type.__dict__['__name__'].__get__(type(error),type),errno=error.errno)]
    data=emit(out,row);out.write(data);output_bytes+=len(data);totals['errors']+=1;continue
   if not stat.S_ISDIR(first.st_mode) or root.resolve(strict=True)!=root:
    rootrows.append(dict(root=str(root),refused_not_canonical_directory=True,identity=ident(first)));continue
   rootrows.append(dict(root=str(root),before_identity=ident(first)));stack=[root]
   while stack:
    directory=stack.pop()
    try:
     with os.scandir(directory) as entries:paths=sorted((pathlib.Path(e.path) for e in entries),key=lambda p:p.name)
    except OSError as error:
     data=emit(out,[directory.relative_to(R).as_posix(),'directory-error',None,dict(error_type=type.__dict__['__name__'].__get__(type(error),type),errno=error.errno)])
     assert output_bytes+len(data)<=8*1024**2;out.write(data);output_bytes+=len(data);totals['errors']+=1;continue
    for path in paths:
     assert totals['entries']<50000;totals['entries']+=1
     try:s=path.lstat()
     except OSError as error:
      row=[path.relative_to(R).as_posix(),'stat-error',None,dict(error_type=type.__dict__['__name__'].__get__(type(error),type),errno=error.errno)];totals['errors']+=1
     else:
      key=(s.st_dev,s.st_ino);absolute=str(path)
      if stat.S_ISDIR(s.st_mode):
       kind='directory';reason='metadata-only';stack.append(path)
      elif stat.S_ISLNK(s.st_mode):
       kind='symlink';reason='never-follow';totals['symlinks']+=1
      elif stat.S_ISREG(s.st_mode):
       kind='regular';totals['regular']+=1;totals['logical_regular_bytes']+=s.st_size;totals['allocated_regular_bytes']+=s.st_blocks*512
       if absolute in old92 or key in oldids:reason='old92-terminal-excluded'
       elif absolute in prior_protected or key in protected_ids:reason='prior-protected-positive-exclusion'
       elif s.st_mode&0o111 or path.suffix.lower() in ('.a','.rlib','.so','.dylib','.dll','.exe','.tar','.gz','.zip','.json','.log'):reason='protected-kind'
       elif s.st_uid!=os.getuid() or s.st_gid!=os.getgid() or s.st_nlink!=1 or getattr(s,'st_flags',0)!=0:reason='metadata-owner-link-flags-refusal'
       elif path.suffix in ('.o','.rmeta','.d') or path.name in ('dep-graph.bin','query-cache.bin','work-products.bin'):
        reason='potential-new-cache-METADATA-ONLY-not-eligible'
        potential.append(dict(path=absolute,identity=ident(s),content_not_read=True,not_ownership_inactivity_or_reclaim_proof=True))
        totals['potential_new_cache_leaves']+=1;totals['potential_new_logical_bytes']+=s.st_size;totals['potential_new_allocated_bytes']+=s.st_blocks*512
       else:reason='protected-unclassified'
      else:kind='special';reason='never-open'
      counts[reason]=counts.get(reason,0)+1;row=[path.relative_to(R).as_posix(),kind,ident(s),reason]
     data=emit(out,row);assert output_bytes+len(data)<=8*1024**2;out.write(data);output_bytes+=len(data)
   rootrows[-1]['after_identity']=ident(root.lstat())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in h.items())
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='READ_ONLY_NEW_DISJOINT_OWN_RESOURCE_METADATA_PREFLIGHT',totals=totals,exclusion_counts=counts,roots=rootrows,potential_new_cache_metadata_only=potential,inventory_size=output_bytes,inventory_sha256=sha((P/'current-metadata.jsonl').read_bytes()),all23_helper_bin_hashes_unchanged=True,no_source_HEAD_tests_build_SDK_native_execution_or_cleanup=True,deletion_attempts=0,no_old92_plan_resume=True,no_prior829_repeat=True,no_global_PID_scan_or_other_task_data_access=True,old_identities_used_for_exclusion_ONLY=True,protected_content_not_read_or_rehashed=True,no_fresh_ownership_inactivity_protectedhash_admission=True,no_physicalreclaim_or_cause_claim=True,free_bytes=free,test_floor_bytes=1073741824,test_floor_open=free>=1073741824,build_floor_bytes=12884901888,build_floor_open=free>=12884901888)
 result['decision']='NO_DISJOINT_NEW_CACHE_METADATA_COHORT_ZERO_DELETION_TERMINAL' if totals['potential_new_cache_leaves']==0 else 'POTENTIAL_METADATA_ONLY_REQUIRES_NEW_DECLARATION_INACTIVITY_PROTECTEDHASHES_AND_EX_BEFORE_ANY_ACTION'
 put(P/'result.json',result)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(checkpoint.read_text());n=v['native_perf_only_diagnostic_design'];n['test_floor_resource_preflight'].update(workspace_inventory_not_started=False,result=str(P/'result.json'),decision=result['decision'],potential_metadata_only=totals['potential_new_cache_leaves'],zero_deletion=True,no_repeat_unchanged_inventory=True);n['last_free_bytes']=free;v['updated_utc']=result['utc'];checkpoint.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(totals=totals,exclusions=counts,decision=result['decision'],free_bytes=free,test_floor_open=result['test_floor_open'])))
