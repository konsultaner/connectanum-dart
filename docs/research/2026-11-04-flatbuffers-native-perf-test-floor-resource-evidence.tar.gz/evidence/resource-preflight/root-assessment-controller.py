import sys,pathlib,json,hashlib,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1');D=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-design');Q=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1-root-assessment');Q.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,v):
  with path.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 result=json.loads((P/'result.json').read_text());assert result['decision']=='NO_DISJOINT_NEW_CACHE_METADATA_COHORT_ZERO_DELETION_TERMINAL'
 rows=regular=directories=old92=protected=0;logical=allocated=0
 with (P/'current-metadata.jsonl').open() as f:
  for line in f:
   path,kind,identity,reason=json.loads(line);rows+=1
   assert path.startswith(('native/transport/target/','native/bench/target/'))
   if kind=='regular':
    regular+=1;logical+=identity[6];allocated+=identity[7]*512
    if reason=='old92-terminal-excluded':old92+=1
    elif reason=='prior-protected-positive-exclusion':protected+=1
    else:raise AssertionError('unexpected new unprotected regular')
   elif kind=='directory':directories+=1
   else:raise AssertionError('unexpected non-directory/regular')
 assert (rows,regular,directories,old92,protected)==(15544,14443,1101,92,14351)
 assert logical==result['totals']['logical_regular_bytes'] and allocated==result['totals']['allocated_regular_bytes']
 assert sha((P/'current-metadata.jsonl').read_bytes())==result['inventory_sha256']
 h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/current-hashes.json').read_text());assert all(sha((R/rel).read_bytes())==digest for rel,digest in h.items())
 model=json.loads((D/'finish.json').read_text());assert model['direct_status']==0 and model['reaped'] and model['stdout_eof'] and model['stderr_eof']
 source=(R/'tool/native_perf_build_producer.py').read_text();aux=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand');methods={n.name:ast.get_source_segment(source,n) for n in aux.body if isinstance(n,ast.FunctionDef)}
 assert 'self.process' not in methods['_retain_allocation_error'] and 'record' in methods['_retain_allocation_error']
 assert "record['initializer_returned']=False" in methods['_allocate_process']
 proposed=dict(unimplemented=True,scope='Source-only narrow private Auxiliary constructor-uncertainty quarantine design, not physicalEX controller/admission',
  boundary='For constructor_attempted without constructor_returned normalTrue, retain earliest exact error FIRST, then durable private quarantine with original actor/FD/log/binding refs. Do not use public pending-finished-process scalars as absence/closure. Same object re-raise remains private primary; later binding/reporting errors are ordered secondary occurrences.',
  no_new_IO='Do not invoke old repr/_defer/_complete or open a replacement/staging/failure JSON, drain/read/flush/fsync/close/retry/replay or pipelineadvance from the quarantined exception path. Do not erase numeric FD/handle refs or call methods on partial Popen. Any future one-attempt settlement needs independently authorized exact handles/identity/progress, sameactor waits and actual outer officialEX retained through allknownactors.',
  limitation='Narrow Aux guard does not fix enclosing CommandProducer reporting or guarantee complete transitive FD/interpreter/delegate/writer/instruction coverage or physical EX retention. Independent officialEX controller still required; unknownstart cannot be turned into close/release authority from fields/type/PID/EOF/status/join/frozenDATA.',
  regression_plan='No new controls executed or old BEFORE5/privateAFTER5 replay. Existing retained evidence of old public finished/publication before later native wait is orientation only. After1GiBfloor opens first run preparedtargeted8 at current221e-89b3; any new quarantine behavior then requires declared real meaningful new BEFORE failure/actor-IO boundaries, minimal change, matching AFTER+affectedcallers. Current source remains unchanged by this design.',
  no_SDK_flag_env_argv_UID_stdio_worker_window_or_capture_changes=True,no_live_provider_or_admission=True)
 put(Q/'selected-quarantine-design.json',proposed)
 corrections=[
  'GLM R1 self receiver is AuxiliaryCommand, NOT partially initialized Popen. _retain_allocation_error touches Auxiliary private error/binding/record fields and calls no Popen method. Reject invented unsafe partial-Popen receiver; do not change that helper for this claim.',
  'Accept narrow private constructor-uncertainty quarantine as next design boundary, without treating it as complete outerEX solution.',
  'GLM R2 suggested failure publication/staging file is not accepted. New output I/O is not authorized by quarantine; preserve private state first and refuse old complete/failure/staging publication from uncertain path until separate settlement authority.',
  'GLM R3 overwrite-order claim unsupported: normal _defer appends secondary repr strings in call order. Hook masking/old public cleanup remain known limitations, not a new proved overwrite defect.',
  'GLM R4 check-before-recording is rejected: fallible binding check must not replace earliest actual initializer error. Retain exact first error BEFORE any check; later drift/check errors are secondary.',
  'No model fullcurrent-source/implementation/physicalclosure/release or cleanup approval. No SDK/kernel/native/build/test requested; source hash current221e/test89b3 remain unchanged and untested.'
 ]
 put(Q/'ROOT-model-qualifications.json',dict(model=model,corrections=corrections))
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='NEW_readonly_disjoint_OWN_resource_preflight_terminal_ZERO_DELETION_and_quarantine_design_UNIMPLEMENTED',hashes=h,
  inventory=dict(entries=rows,regular=regular,directories=directories,old92_excluded=old92,prior_protected_excluded=protected,errors=0,symlinks=0,potential_new_disjoint_metadata_cohort=0,logical_regular_bytes=logical,stat_allocated_regular_bytes=allocated,inventory_sha256=result['inventory_sha256']),
  limits='Scope only canonical OWN native/transport/target and native/bench/target. Old92 and priorprotected14377 paths/identities are positive exclusions, NOT fresh hash/ownership/inactivity proof.14351priorprotected appear under these roots; no assertion about26outside scope. Files not content-read/rehashed, allregular excluded; no globally exhaustive resource/ownership/inactivity/atomicity/physicalreclaim proof. Metadata byte totals never reclaim authority. Priorplan data read only for new exclusion purpose, never executed/resumed/no oldarchives or numerical evidence read.',
  terminal='No disjoint new cache metadata cohort in these two roots, zero deletion attempts; do not repeat unchanged scan or resume old92/829cleanup. No eligible deletion/protectedhash/inactivity/execution admission produced. Other-task/root/mqtt/ObjectBox data and runtimecheckout untouched.',
  source_unchanged=True,no_source_HEAD_query_in_readonly_phase=True,all23_current_helper_bin_hashes_unchanged=True,current221e_test89b3_UNTESTED=True,models=dict(judge=model,ROOT_corrections=corrections),quarantine_design=proposed,
  provenance='Resource and GLM controller originals saved BEFORE execution; new ROOT original also saved beforecall; no execution admission or physicalEX proof. ScopeSH for readonly artifacts/model/admin only. No source edit/tests/build/SDK/version/native/kernel/broker/benchmark/capture/sourcecommitpushadoption/strictdispatch or cleanup.',
  next='Do not rerun this terminal inventory. Wait for safely available1GiB, or independently declared different OWN-safe scope/static work, then run preparedfinal-targeted8 at exact currentepoch with actualEX+freshfloor. Quarantine plan remains source-only/unimplemented.12GiB beforeanybuild; fullphysical/originalruntime provenance/ROOT-qualified immutableCOMPLETEadmission beforediagnosticdata.',
  free_bytes=free,test_floor_bytes=1073741824,test_floor_open=free>=1073741824,build_floor_bytes=12884901888,build_floor_open=free>=12884901888,cause_unmeasured=True,cleanup_performed=False,all_admission_flags=False,provider_absent=True,gate_always_raises=True,ownership=None,no_RAMcause_repair_acceptance=True,PR_open_draft_base130=True,issue103_milestone_open=True)
 put(Q/'assessment.json',assessment);put(P/'current-hashes.json',h)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design'];n['test_floor_resource_preflight'].update(root_assessment=str(Q/'assessment.json'),ROOT_assessed=True,publication_pending=True,decision=result['decision'],new_disjoint_cohort=0,deletion_attempts=0,never_repeat_unchanged=True);n['aux_quarantine_design']=dict(path=str(Q/'selected-quarantine-design.json'),unimplemented=True,source_unchanged=True,model_pid=model['pid'],model_direct_status=0,ROOT_qualified_not_approval=True);n['last_free_bytes']=free;v['updated_utc']=assessment['utc'];c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(entries=rows,regular=regular,new_disjoint=0,deletions=0,source_unchanged=True,quarantine_unimplemented=True,free_bytes=free)))
