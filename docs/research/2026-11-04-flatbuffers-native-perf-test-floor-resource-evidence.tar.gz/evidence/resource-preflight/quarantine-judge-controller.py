import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();D=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-design');D.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/current-hashes.json').read_text())
 raw=(R/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==h['tool/native_perf_build_producer.py']
 s=raw.decode();c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand')
 selected='\n\n'.join(ast.get_source_segment(s,n) for n in c.body if isinstance(n,ast.FunctionDef) and n.name in ('start','_complete','_defer','_close_slot','_allocate_process'))
 declaration=dict(scope='NEW independent source-only next public-cleanup/outer-EX quarantine architecture; NO implementation/tests/native/SDK/admission',source_hash=h['tool/native_perf_build_producer.py'],test_hash=h['tool/test_native_perf_build_producer.py'],current_corrected_epoch_UNTESTED_testfloor_closed=True,resource_preflight='NEW readonly15544entries/14443regular; all92terminal+14351priorprotected excluded; ZERO disjointpotentialcache/deletion; do not repeat unchangedscan',current_problem='Private allocated Aux Popen now retained before init, but old except path still repr/defer/closes parent FD slots and _complete marks finished/publishes after uncertain initializer. Retained actual finite oldsource observations already show childexists until later sameactorwait; no beforecontrols rerun/newfailurecount.',question='Choose smallest next DESIGN boundary: narrow Aux private quarantine on constructor uncertainty vs independent outer officialEX lease controller first. Need exact private primary/stagedsecondary/actor-FD-originalbindings retained BEFOREfallibleIO; cannot call methods on uninitialized object from fields/type/pid alone. No raw concurrentproducerobserver/reset/retry/pipelineadvance/publicationreplay/cancel/kill/globalPIDscan/oldauxpredicate-owner_emit_attempted waiver. No status/EOF/join/closedobject/frozenDATA automatically grants EXrelease/admission. Official helper lease+verify_identity ONLY; never customlock/bypass. BEFOREANYGO nativeEOF/notokenrefusal permitted; AFTERANYuncertainGO sampler through BOTHnaturaldriver-and-actualsamplerexit. Originalargv-env-UID-GID-stdio/SDK/GC/allocator/workers/windows unchanged. Actual originalhost pidfd-FDexec/credentials/inheritance/arming/roles-clock/fulltransitiveimage-instructionclosure remainsunproved/providerABSENT/gatealwaysraises/all3flagsFalse. Max2 necessary source-supported nextdesign corrections/max220words. No implementation/fullsource/closure approval; no requests to run below1GiBfloor or new SDK/kernel.')
 def put(name,v):
  with (D/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 put('declaration.json',declaration)
 context=json.dumps(declaration,indent=2)+'\n\n'+selected;assert len(context)<15000
 (D/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','judge','--stdin','--reasoning-budget','384','--num-predict','1400','--max-input-chars','15000','--max-response-chars','7500','--timeout','180','--save-output',str(D/'judge.txt'),'--prompt',declaration['question']]
 put('command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);put('started.json',dict(pid=child.pid))
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (D/(label+'.bin')).open('xb') as f:f.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-7500:])
