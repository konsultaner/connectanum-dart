import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1');a=pathlib.Path('/tmp/connectanum-native-perf-aux-quarantine-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-preflight-v1-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='2dc8511cd5eb69bb13fc1ef59f2285195ac223cf'
 assert git('status','--porcelain')==''
 h=json.loads((p/'current-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 logical_budget=sum(path.stat().st_size for root in [p,a,final_root] for path in root.rglob('*') if path.is_file() and not path.is_symlink())
 assert before>=64*1024**2+2*logical_budget
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  controller_order_qualified_per_kind=True,administrative_archive_budget_only_bytes=64*1024**2+2*logical_budget,logical_regular_bytes_preflight=logical_budget,test_1GiB_build_12GiB_NOT_waived=True))
 base='2026-11-04-flatbuffers-native-perf-test-floor-resource';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'resource-preflight'),(a,'quarantine-design'),(final_root,'root-final')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-test-floor-resource-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='Survey/model/correctedROOT/controller originals saved BEFOREcalls; initialbadquoting inline fullbody notregularfile and dependentCLI missingfile beforebody. No execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Read-only OWN resource preflight and next quarantine design\n\nA newly declared metadata-only survey covers the two canonical OWN Rust target\nroots. It records15544 entries:14443 regular files and1101 directories, with no\nsymlinks or stat/traversal errors. All regular files are excluded:92 by the\nterminal old candidate plan and14351 by prior protected paths/identities.\nThere is no disjoint new cache metadata cohort within these two roots and zero\ndeletion attempts. The result is terminal; do not repeat the unchanged survey.\n\nThe old92 NoDeletion plan is neither executed nor resumed. Its paths/identities\nand the prior14377 protected paths/identities are positive exclusions only,\nnot reused as fresh content-hash, ownership or inactivity proof. Twenty-six\nprior protected entries are outside the two-root inventory; no absence claim\nis made about them. Regular-file logical/stat-allocated totals are accounting\ndata, never recoverable-space estimates or deletion authority. File contents\nare not read/rehashed. This is not a globally exhaustive OWN resource search,\nan atomic snapshot, global inactivity proof or physical reclaim measurement.\nOther-task/root/MQTT/ObjectBox data and the runtime checkout are untouched.\n\nThe new declaration precedes workspace inventory. Paths outside the OWN roots\nand symlinks are not followed; no global process scan, cleanup, old archive read,\nsource/HEAD mutation, test, build, SDK/version/native/kernel/broker/benchmark or\ncapture occurs. Current23 helper/bin hashes remain unchanged at producer\n221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd\nand test89b36b7eb786ff3e1b2496c76232ee23fb1f512863bbaa877ec6bba8f8fc49b8.\nTheir corrected epoch remains UNTESTED. The1GiB test and12GiB build floors\nremain unchanged and closed. Source/metadata/model work does not waive them.\n\nWhile tests are blocked, a bounded source-only architecture question addresses\nthe next known Auxiliary cleanup boundary. GLM67054 completes0, is reaped and\nremains advisory. ROOT accepts designing a narrow private quarantine for\nconstructor uncertainty before broadening the physical EX controller.\nThe selected design is UNIMPLEMENTED: retain the exact earliest error first,\nthen durable quarantine with original actor/FD/log/binding references. Refuse\nold repr/defer/complete, new failure/staging output, read/drain/write/flush/\nfsync/close/retry/replay or pipeline advancement in that uncertain path.\nDo not invoke partial-Popen methods based on fields/type/PID alone. Any later\none-attempt settlement needs independently authorized exact handles, identity\nand progress, bounded same-actor waits and actual official EX retention.\n\nROOT rejects several model claims. Its R1 mistakes the receiver of\nretain_allocation_error for a partial Popen: self is AuxiliaryCommand, and that\nmethod touches its private error/binding/record state without calling a Popen\nmethod. Keep private error retention. Its R2 failure/staging-file suggestion is\nnot accepted; quarantine does not authorize new output I/O. Its R3 overwrite\nclaim is unsupported: ordinary defer appends secondary repr strings in call\norder; existing hook masking/cleanup limitations remain. Its R4 binding check\nbefore error recording would risk replacing the actual earliest initializer\nerror. Retain that exact object before any fallible check; later check errors\nare secondary occurrences. No model implementation/full-source/cleanup/\nphysical-closure or release approval is inferred.\n\nA narrow Auxiliary quarantine cannot fix enclosing producer reporting or prove\nthe complete interpreter/delegate/writer/FD/instruction graph. The independent\nofficial EX controller remains necessary. Pending/finished/processNone, source\nfacts, object types, status, EOF, join and frozen DATA never grant release or\nadmission. Original argv/environment/UID/GID/stdio/SDK/GC/allocator/workers/\nwindows and all emit/freeze/auxiliary predicates remain unchanged.\n\nNo new controls run and no old BEFORE/private AFTER controls replay. Existing\nretained observations of public completion before later same-actor exit are\norientation only, not a new failing-test count. When a fresh1GiB check passes,\nfirst run the prepared eight targeted checks at current221e/89b3 under actual EX.\nAny new quarantine behavior then needs its own declared meaningful real BEFORE\nregression, minimal change, matching AFTER and affected callers. Current source\nis unchanged by the design.\n\nAn initial ROOT assessment preparation has a quoting SyntaxError before its\ncontroller file or assessment body exists. The dependent CLI then returns2 on\nthe missing file before any lease body/workspace action. These are retained\nadministrative failures, not backend unavailability or actor/control failures.\nThe corrected controller is saved before execution. Its independent readback\nvalidates all inventory records/counts/SHA and verifies source hashes without\nrerunning the workspace survey or reconstructing missing data. Original model/\nsurvey/controller files precede their calls; no execution admission follows.\n\nNext wait for safely available space or use a separately declared different\nOWN-safe/static scope, never this terminal survey or the old92/829 cleanup.\nFuture deletion still requires fresh inactive OWN/protected-hash/receipt/EX\nauthority and excludes evidence/raws/archives/sources/natives/RLIBs/executables/\nother-task data. No cleanup is performed. Original public cleanup, historical\ncontinuation/log sealing, transitive generic FDs, partial/unknown actors,\nshared journals/historical writers, interpreter/delegate/descendant coverage,\nfull actual official EX and original-runtime provenance remain incomplete.\nROOT-qualified immutable COMPLETE admission is required before diagnostic data;\nno source adoption/strict dispatch, transplant/borrowed cohort, favorable redo,\nSDK change or postGO as preproof.\n\nProvider absent, gate always raises, controller closed, ownershipNone,\nall three flagsFalse. No actual SDK/native build/canonical/kernel/broker/\nbenchmark/capture, RAM cause/repair or strict acceptance. Latest assessment\nfree465903616B remains below both floors; cause unmeasured, no cleanup.\nPR132 stays OPEN DRAFT on130; issue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Read-only OWN resource preflight finds no disjoint cache cohort\n\nA new two-root metadata survey records15544 entries/14443 regular files:92 terminal-old candidates and14351 prior protected entries are excluded, leaving zero new disjoint metadata candidates. No cleanup or other-task access; old hashes/identities are exclusions, not fresh eligibility proof. The result is terminal and must not repeat unchanged. Current221e/89b3 source remains unchanged/UNTESTED below the1GiB test and12GiB build floors. A ROOT-qualified, source-only Auxiliary constructor-uncertainty quarantine design is UNIMPLEMENTED; model receiver/publication/check-order claims are corrected. Full physical EX/original-runtime admission and strict acceptance remain incomplete.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-test-floor-resource-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-test-floor-resource-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-test-floor-resource-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: record disjoint OWN resource preflight and quarantine design')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['test_floor_resource_preflight'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['test_floor_resource_GitHub_descriptions_pending']=True;n['test_floor_resource_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
