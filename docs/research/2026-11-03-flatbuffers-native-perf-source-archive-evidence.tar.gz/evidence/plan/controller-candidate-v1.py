import os,sys,pathlib,json,hashlib,stat,tarfile,types,shutil,io
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as companion

PLAN=pathlib.Path('/tmp/connectanum-native-perf-source-archive-plan/declaration.json')
P=pathlib.Path('/private/tmp/connectanum-native-perf-source-archive-preparation-v1')
H=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-native-preflight-runtime/connectanum-dart')
COMMIT='601108ea6216464bd00ae29c16cfaf0a59c71db6'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=True);f.write('\n')
def identity(s):
    return {k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_flags')}
def exact_regular(path,cap,label,expected=None,mode=None,owner=None,retain=None):
    # Input metadata exists before the ownership/mode/size guard. No atime equality.
    path_before=path.lstat()
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        put(P/(label+'-before.json'),dict(path=str(path),path_stat=identity(path_before),held_stat=identity(before)))
        assert stat.S_ISREG(before.st_mode) and before.st_size<=cap and before.st_nlink>=1
        assert identity(path_before)==identity(before)
        if mode is not None:assert stat.S_IMODE(before.st_mode)==mode
        if owner is not None:assert (before.st_uid,before.st_gid)==owner
        parts=[];size=0
        while True:
            part=os.read(fd,min(65536,cap+1-size))
            if not part:break
            parts.append(part);size+=len(part)
            assert size<=cap
        data=b''.join(parts)
        after=identity(os.fstat(fd));path_after=identity(path.lstat())
        put(P/(label+'-after.json'),dict(held_stat=after,path_stat=path_after,size=size,sha256=sha(data)))
        assert len(data)==before.st_size and identity(before)==after==path_after
        if expected is not None:assert sha(data)==expected
        if retain is not None:
            with retain.open('xb') as f:f.write(data)
        return data
    finally:os.close(fd)

with companion.local_resource_lease(exclusive=True) as lease:
    lease.verify_identity()
    P.mkdir(mode=0o700) # Every partial/existing attempt stays terminal forever.
    put(P/'attempt.json',dict(terminal=True,scope='new OWN source files and source archive DATA observations only',
        capture_ready=False,source_admitted=False,live_admission=False))
    primary=None;secondary=[];ops=[];results=[];module=None;name='_owned_source_archive_producer'
    try:
        raw=exact_regular(PLAN,1024**2,'plan')
        plan=json.loads(raw);put(P/'consumed-declaration.json',plan)
        assert pathlib.Path(plan['attempt'])==P and pathlib.Path(plan['helper_root'])==H and pathlib.Path(plan['runtime_root'])==R
        assert plan['commit']==COMMIT and len(plan['helper_sha256'])==20
        assert plan['source_floor_bytes']==1024**3 and plan['build_floor_bytes']==12*1024**3
        assert plan['archive_max_bytes']==256*1024**2 and plan['blob_max_bytes']==128*1024**2
        assert H.resolve(strict=True)==H and R.resolve(strict=True)==R
        free_before=shutil.disk_usage(R).free
        assert free_before>=plan['source_floor_bytes']+2*plan['archive_max_bytes']
        put(P/'space-before.json',dict(free=free_before,build_floor=plan['build_floor_bytes'],no_build=True))
        (P/'helper-inputs').mkdir(mode=0o700)
        helper_bytes={}
        for index,(rel,digest) in enumerate(sorted(plan['helper_sha256'].items())):
            assert rel.startswith('tool/') and pathlib.PurePosixPath(rel).parts==('tool',pathlib.PurePosixPath(rel).name)
            helper_bytes[rel]=exact_regular(H/rel,2*1024**2,'helper-'+str(index).zfill(2),digest,0o644,(501,20),P/'helper-inputs'/pathlib.Path(rel).name)
        assert name not in sys.modules
        module=types.ModuleType(name);module.__file__=str(H/'tool/native_perf_build_producer.py');sys.modules[name]=module
        exec(compile(helper_bytes['tool/native_perf_build_producer.py'],module.__file__,'exec'),module.__dict__)
        git=shutil.which('git');assert git is not None
        def command(label,args,maximum=1024**2):
            op=module.AuxiliaryCommand(directory=P,name=label,argv=[git,'-C',str(R),*args],
                cwd=R,environment=dict(os.environ),lease_check=lease.verify_identity,
                stdout_max=maximum,stderr_max=1024**2)
            ops.append(op) # Exact operation retained BEFORE child launch.
            op.start();result=op.result
            while result is None:result=op.wait(1)
            results.append(result);put(P/(label+'-returned.json'),result)
            assert result['returncode']==0 and result['status']=='success'
            assert all(v['eof'] and v['snapshot_matches_stream'] for v in result['outputs'].values())
            return P/(label+'.stdout')
        head=exact_regular(command('runtime-head-before',['rev-parse','HEAD']),1024,'head-before').decode().strip()
        assert head==COMMIT
        assert exact_regular(command('runtime-status-before',['status','--porcelain','--untracked-files=all']),1024**2,'status-before')==b''
        tree_raw=exact_regular(command('source-tree',['ls-tree','-r','-l','-z',COMMIT],8*1024**2),8*1024**2,'tree')
        tree={};logical=0
        for row in tree_raw.split(b'\0'):
            if not row:continue
            meta,path=row.split(b'\t',1);mode,kind,oid,size=meta.split()
            rel=os.fsdecode(path);parts=pathlib.PurePosixPath(rel).parts
            assert rel not in tree and parts and not rel.startswith('/') and '..' not in parts and '.' not in parts
            assert kind==b'blob' and mode in (b'100644',b'100755',b'120000') and len(oid)==40
            size=int(size);assert 0<=size<=plan['blob_max_bytes']
            tree[rel]=dict(mode=mode.decode(),git_blob=oid.decode(),size=size);logical+=size
        assert logical<=plan['archive_max_bytes']
        put(P/'tree.json',dict(entries=tree,logical_blob_bytes=logical))
        archive=command('source-archive',['archive','--format=tar',COMMIT],plan['archive_max_bytes'])
        # New archive only. Embedded committed archive files remain opaque source blobs.
        fd=os.open(archive,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
        try:
            before=os.fstat(fd);put(P/'archive-before.json',identity(before))
            assert stat.S_ISREG(before.st_mode) and before.st_size<=plan['archive_max_bytes']
            stream=os.fdopen(os.dup(fd),'rb')
            full=hashlib.sha256()
            with os.fdopen(os.dup(fd),'rb') as raw_archive:
                while True:
                    part=raw_archive.read(65536)
                    if not part:break
                    full.update(part)
            os.lseek(fd,0,os.SEEK_SET)
            found=set();observations=[]
            with stream,tarfile.open(fileobj=stream,mode='r:') as tar:
                for member in tar:
                    if member.isdir():
                        assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
                        continue
                    rel=member.name;assert rel in tree and rel not in found
                    item=tree[rel];mode=item['mode'];path=R/rel
                    # Parent resolution is an observation, not an atomic path/ABA guarantee.
                    assert path.parent.resolve(strict=True)==path.parent
                    if mode=='120000':
                        assert member.issym()
                        data=os.fsencode(member.linkname);assert len(data)==item['size']
                        before_link=path.lstat()
                        put(P/('tracked-'+str(len(found)).zfill(4)+'-before.json'),dict(path=rel,stat=identity(before_link),symlink=True))
                        assert stat.S_ISLNK(before_link.st_mode) and (before_link.st_uid,before_link.st_gid)==(501,20)
                        checkout=os.fsencode(os.readlink(path));after_link=path.lstat()
                        row=dict(path=rel,git_mode=mode,size=len(data),archive_sha256=sha(data),checkout_sha256=sha(checkout),
                            before=identity(before_link),after=identity(after_link),kind='symlink_lstat_readlink_lstat_only')
                        assert data==checkout and identity(before_link)==identity(after_link)
                        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
                    else:
                        assert member.isfile() and mode in ('100644','100755') and member.size==item['size']
                        assert bool(member.mode&0o111)==(mode=='100755')
                        file_fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
                        try:
                            first=os.fstat(file_fd);path_first=path.lstat()
                            put(P/('tracked-'+str(len(found)).zfill(4)+'-before.json'),dict(path=rel,held_stat=identity(first),path_stat=identity(path_first)))
                            assert stat.S_ISREG(first.st_mode) and first.st_size==member.size and first.st_nlink>=1
                            assert (first.st_uid,first.st_gid)==(501,20)
                            assert stat.S_IMODE(first.st_mode)==(0o755 if mode=='100755' else 0o644)
                            assert identity(first)==identity(path_first)
                            ah=hashlib.sha256();ch=hashlib.sha256();gh=hashlib.sha1(b'blob '+str(member.size).encode()+b'\0')
                            consumed=0
                            with tar.extractfile(member) as archived:
                                while True:
                                    part=archived.read(65536)
                                    if not part:break
                                    ah.update(part);gh.update(part)
                                    actual=b''
                                    while len(actual)<len(part):
                                        chunk=os.read(file_fd,len(part)-len(actual))
                                        if not chunk:break
                                        actual+=chunk
                                    ch.update(actual);consumed+=len(part)
                                    assert actual==part
                            assert not os.read(file_fd,1) and consumed==member.size
                            last=os.fstat(file_fd);path_last=path.lstat()
                            row=dict(path=rel,git_mode=mode,size=consumed,archive_sha256=ah.hexdigest(),checkout_sha256=ch.hexdigest(),
                                before=identity(first),after=identity(last),path_after=identity(path_last),kind='regular_same_held_FD')
                            assert identity(first)==identity(last)==identity(path_last)
                            blob=gh.hexdigest()
                        finally:os.close(file_fd)
                    assert blob==item['git_blob']
                    row['git_blob']=blob;put(P/('tracked-'+str(len(found)).zfill(4)+'-observed.json'),row)
                    observations.append(row);found.add(rel)
            assert found==set(tree)
            after=os.fstat(fd);path_after=archive.lstat()
            put(P/'archive-after.json',dict(held_stat=identity(after),path_stat=identity(path_after),sha256=full.hexdigest()))
            assert identity(before)==identity(after)==identity(path_after)
        finally:os.close(fd)
        # Separate package of exactly the already consumed20 source files, never canonical.
        with tarfile.open(P/'helper20-source.tar','x:') as out:
            for rel,data in sorted(helper_bytes.items()):
                item=tarfile.TarInfo(rel);item.size=len(data);item.mode=0o644;item.uid=501;item.gid=20;item.mtime=0
                out.addfile(item,io.BytesIO(data))
        package=exact_regular(P/'helper20-source.tar',8*1024**2,'helper-package')
        with tarfile.open(fileobj=io.BytesIO(package),mode='r:') as tar:
            members=tar.getmembers();assert [x.name for x in members]==sorted(helper_bytes)
            assert all(x.isfile() and tar.extractfile(x).read()==helper_bytes[x.name] for x in members)
        for index,(rel,digest) in enumerate(sorted(plan['helper_sha256'].items())):
            exact_regular(H/rel,2*1024**2,'helper-post-'+str(index).zfill(2),digest,0o644,(501,20))
        assert exact_regular(command('runtime-head-after',['rev-parse','HEAD']),1024,'head-after').decode().strip()==COMMIT
        assert exact_regular(command('runtime-status-after',['status','--porcelain','--untracked-files=all']),1024**2,'status-after')==b''
        put(P/'summary.json',dict(scope='new OWN tracked runtime source/opaque source archive and separate20helper source DATA only',
            runtime_HEAD=COMMIT,runtime_reported_clean_before_after=True,tracked_entries=len(found),
            regular_entries=sum(x['kind']=='regular_same_held_FD' for x in observations),
            symlink_entries=sum(x['kind']=='symlink_lstat_readlink_lstat_only' for x in observations),
            logical_blob_bytes=logical,source_archive_sha256=full.hexdigest(),source_archive_bytes=before.st_size,
            helper20_source_package_sha256=sha(package),helper20_unchanged=True,
            actual_direct_statuses=[x['returncode'] for x in results],
            both_output_EOF_all=all(v['eof'] for x in results for v in x['outputs'].values()),
            new_source_observations_not_atomic_or_executable_or_loaded_image_proof=True,
            no_current20_helper_canonical_or_build_or_SDK_or_native_or_benchmark_or_capture=True,
            no_ignored_hidden_files_absence_or_full_compiled_closure_claim=True,
            no_source_edit_commit_push_adoption_cleanup_or_strict_dispatch=True,
            capture_ready=False,source_admitted=False,live_admission=False,
            free_before=free_before,free_after=shutil.disk_usage(R).free,space_change_cause='UNMEASURED'))
    except BaseException as error:
        primary=error
        try:put(P/'failure.json',dict(type=type(error).__name__,terminal=True,no_reset_retry_or_cleanup=True))
        except BaseException as error:secondary.append(dict(stage='failure-record',type=type(error).__name__))
    finally:
        # No relaunch, reset, replay, cancellation, or publication retry. Same known actor only.
        for op in ops:
            while op.result is None and not op.finished:
                try:op.wait(1)
                except BaseException as error:
                    secondary.append(dict(stage='same-actor-wait',type=type(error).__name__))
                    if primary is None:primary=error
        if module is not None and sys.modules.get(name) is module:sys.modules.pop(name)
        try:lease.verify_identity()
        except BaseException as error:
            secondary.append(dict(stage='lease-identity',type=type(error).__name__))
            if primary is None:primary=error
        try:put(P/'finalization.json',dict(primary=None if primary is None else type(primary).__name__,
            secondary=secondary,known_commands=len(ops),all_returned=len(results),
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
        except BaseException as error:
            if primary is None:primary=error
        if primary is not None:raise primary
print(json.dumps(dict(terminal=True,scope='source archive DATA only; no live admission')))
