import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,ast,gzip,base64,shutil,datetime,subprocess
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-grandchild-directory-inputs-v1';N=P/'FIRST-remaining-source-generation-v1';Q=P/'FIRST-local-static-binding-v1'
O63=B/'2026-11-07-actions-include-child-directory-scope-v1/new63-FIRST-remaining-static-binding-Actions-v1/ROOT-NEW-ALL63-directory-input-assessment-PRIVATE.json'
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 inputs=[('collector',N/'collector.py',1613289,'cab8351afb91aa946d151e472ee302d8800aa3f8351e1b51ae842138041d6fc2'),('workflow',N/'candidate-wamp-profile-benchmarks.yml',482286,'9fee182f28e886a235d74765660982e6054722636c517878857b337e3388b1f2'),('NEW190scope',N/'NEW190-exact-publicsafe-scope.json',1774384,'36f6fa44cdf0e79c41decd92ce87ee44535be0b4f3174a1efc4af99f702db05f'),('NEW190runtimeledger',N/'NEW190-derived-runtime-reference-ledgers.json',6135014,'002d23aad10c6d2ba86a00a976f1aaa102e97555901bebf76effb1b976c441eb'),('original_new_validation',N/'FIRST-source-validation.json',8445,'ffab2ee41427c97c30148eac4a078959d03e087b4c54f630f8cb1eb567b8efd0'),('original33conditionsPASS_NOTreevaluate',N/'ALL33-original-condition-source-preflight-BEFOREdispatch.json',7764,'8c3f234fed40e524ae8f36366319348b469c85f1d4c47c253bb73b0dabc65a1d'),('original63actual_staticmetadata_carrier_ONLY',O63,13814766,'85e36d181b234b30d651ff094f1b979d578dea0e564755c4392aac077fc44b3e')]
 declaration={'scope':'FIRST expresslydeclared NEW190collector-workflow STATICbinding/preflight. ExactsevenOWNsavedmetadata/source inputs-ranges-SHA BEFOREIO. ASTsemanticfieldbinding purposeONLY/notconsumedcandidateASTsyntax/reverse/33conditions/refcomparisons rerun. No targetexec-eval-import/globals-execution/SDK/headerbody/Actions/API query-sourcecommit-dispatch/native-build-bootstrap-dependency-driver-perf-numerical/Source20-runtime adoption. Sourceprefix imports inspectedasmetadata only; old63actualreport-static-fields immutablecarrier NOToldsource/parser/hash/journal revalidation. Decode ONLYNEW190exactliteralmetadata payloads/comparewholebytes-JSONSTRING-PythonALLfields toexactalreadydeclarednewscope-runtimeledger; no old63payload decoder replay. Original33conditionPASSraw copyBYTEEXACT NOTreevaluate; actualskip pending. Preservealloldfields/privatefullmetadata/stat-times/1425-63-1229epochs/190DEFERRED6UNEXPANDED/priorledgers-oldncursesrawhexNOTsavedNULL. Currentreview82188tokenlimitNOFINALANSWER/notapproval-unavailability-relaunch; noclaimmodeladmission. BindactualNEW190refs-scope-ledger/reportfields separatelyfromold63metadata andpendingruntimedynamicfields NULL/unmeasured, notfabricatedzero. PointFD-staticproof NOTatomicABA-origin-pathchain-originaldriveraccess-credentials-effectivecompilerABI-globalactorFD-continuousphysicalEX-crash admission; separateouterPID-EOFNULL/unknownpartial-crash quarantine.','exact_saved_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':sha} for r,p,n,sha in inputs],'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);free=shutil.disk_usage(Q).free;save('fresh-scoped-static-check-floor.json',json.dumps({'free_bytes':free,'required_bytes':1073741824,'not_build_authority':True}));assert free>=1073741824;bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and h.hexdigest()==expected;raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw


 raws={}
 for role,path,size,sha in inputs:
  raw=read_bounded(path,size,sha,role);raws[role]=raw;save(role+'-bound-PRIVATE',raw)
 save('ALL-seven-input-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2))
 validation=json.loads(raws['original_new_validation']);conditions=json.loads(raws['original33conditionsPASS_NOTreevaluate'])
 assert validation['ALL33_old_jobs_unchanged'] and validation['whole_original_workflow_reverse_projection_BYTEEXACT'] and validation['whole_original_collector_reverse_projection_BYTEEXACT'] and validation['ALL_original_metadata_functions_guards_fields_preserved'] and validation['old63_guards_before_NEW190_loader_before_INPUTIO'] and validation['whole_scope_BYTEEXACT_JSONSTRING_PythonALLfield_equality'] and validation['ALL33_oldconditions_SOURCE_false_BEFOREdispatch']
 assert len(conditions)==33 and all(r['NEW_dispatch_SOURCE_false_NOT_actualskip'] is True for r in conditions) and [{k:r[k] for k in ['job','if']} for r in conditions]==validation['ALL33_original_job_conditions']
 save('original33-condition-PASS-BYTEEXACT-NOT-reevaluated.json',raws['original33conditionsPASS_NOTreevaluate'])
 scope=json.loads(raws['NEW190scope']);ledger=json.loads(raws['NEW190runtimeledger']);old=json.loads(raws['original63actual_staticmetadata_carrier_ONLY']);text=raws['collector'].decode();tree=ast.parse(text)
 imports=[a.asname or a.name.split('.')[0] for node in tree.body if isinstance(node,ast.Import) for a in node.names];assert all(k in imports for k in ['json','hashlib','base64','gzip','os','stat','pathlib','sys'])
 reportassigns=[node for node in ast.walk(tree) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='report' for t in node.targets)];assert len(reportassigns)==1 and isinstance(reportassigns[0].value,ast.Dict)
 nodes={ast.literal_eval(k):val for k,val in zip(reportassigns[0].value.keys,reportassigns[0].value.values)}
 def assignment(name):
  found=[node for node in ast.walk(tree) if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id==name];assert len(found)==1,name;return found[0]
 def payload(name,expected,gzbytes,gzsha):
  node=assignment(name);call=node.value;assert isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and isinstance(call.func.value,ast.Name) and call.func.value.id=='gzip' and call.func.attr=='decompress' and len(call.args)==1 and not call.keywords
  b64=call.args[0];assert isinstance(b64,ast.Call) and isinstance(b64.func,ast.Attribute) and isinstance(b64.func.value,ast.Name) and b64.func.value.id=='base64' and b64.func.attr=='b64decode' and len(b64.args)==1 and not b64.keywords
  encoded=ast.literal_eval(b64.args[0]);assert isinstance(encoded,str);gz=base64.b64decode(encoded,validate=True);assert len(gz)==gzbytes and hashlib.sha256(gz).hexdigest()==gzsha
  decoded=gzip.decompress(gz);assert decoded==expected and decoded.decode()==expected.decode() and json.loads(decoded)==json.loads(expected)
  return node,{'target':name,'line':node.lineno,'encoded_characters':len(encoded),'gzip_bytes':len(gz),'gzip_sha256':hashlib.sha256(gz).hexdigest(),'decoded_bytes':len(decoded),'decoded_sha256':hashlib.sha256(decoded).hexdigest(),'whole_bytes_JSONSTRING_Python_ALLfields_equal':True}
 newraw,newbinding=payload('NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW',raws['NEW190scope'],50835,'a68ade250e3fd6d306bb554ee4514940a5bca848da4e793a08a2d9eb89e9e8b0')
 ledraw,ledbinding=payload('NEW190_PRIOR_REFERENCE_LEDGERS_RAW',raws['NEW190runtimeledger'],499172,'014a459f7dacd643c4ca4282928f15f3e18e876fd161969737ff289ebb672b4d')
 for name,rawname in [('NEW_GRANDCHILD_DIRECTORY_SCOPE','NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW'),('NEW190_PRIOR_REFERENCE_LEDGERS','NEW190_PRIOR_REFERENCE_LEDGERS_RAW')]:
  assert ast.dump(assignment(name).value)==ast.dump(ast.parse('json.loads('+rawname+')',mode='eval').body)
 priorrefs=assignment('PRIOR_CHILD_DIRECTORY_REFERENCES');assert isinstance(priorrefs.value,ast.Name) and priorrefs.value.id=='DIRECTORY_REFERENCES'
 refassigns=[node for node in ast.walk(tree) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DIRECTORY_REFERENCES' for t in node.targets) and isinstance(node.value,ast.Subscript) and isinstance(node.value.value,ast.Name) and node.value.value.id=='NEW_GRANDCHILD_DIRECTORY_SCOPE'];assert len(refassigns)==1;refassign=refassigns[0];assert ast.literal_eval(refassign.value.slice)=='ALL190_new_literal_directory_references'
 refs=scope['ALL190_new_literal_directory_references'];assert len(refs)==190 and refs==[r['NEW_express_lexical_candidate_TEXT'] for r in scope['ALL190_new_explicit_lexical_relations']]
 scopewrites=[node for node in ast.walk(tree) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='scope_written' for t in node.targets)];assert len(scopewrites)==1 and ast.dump(scopewrites[0].value)==ast.dump(ast.parse('save_json("scope-before-INPUT-IO.json", NEW_GRANDCHILD_DIRECTORY_SCOPE)',mode='eval').body)
 loops=[node for node in ast.walk(tree) if isinstance(node,ast.For) and isinstance(node.iter,ast.Call) and isinstance(node.iter.func,ast.Name) and node.iter.func.id=='enumerate' and len(node.iter.args)==1 and isinstance(node.iter.args[0],ast.Name) and node.iter.args[0].id=='DIRECTORY_REFERENCES'];assert len(loops)==1
 assert newraw.lineno<ledraw.lineno<priorrefs.lineno<refassign.lineno<scopewrites[0].lineno<loops[0].lineno
 outertry=[node for node in tree.body if isinstance(node,ast.Try) and newraw in node.body];assert len(outertry)==1
 assert not any(isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NEW_SCOPE' for t in node.targets) for node in outertry[0].body)
 guard=ast.parse('scope_written["bytes"] == len(NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW) and scope_written["sha256"] == hashlib.sha256(NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW).hexdigest()',mode='eval').body
 assert any(isinstance(node,ast.Assert) and ast.dump(node.test)==ast.dump(guard) and scopewrites[0].lineno<node.lineno<loops[0].lineno for node in outertry[0].body)
 oldstatic=dict(old['ALL_preserved_static_report_fields']);oldqualification=oldstatic['qualification'];assert ast.literal_eval(nodes['prior_ALL63_qualification_metadata_only'])==oldqualification
 # Immutable actualold63 staticmetadata supplies oldunchanged values; no oldprefixpayload decoding/globals execution.
 allowed_old_names={'NEW_SCOPE','PRIOR_ALL49_SCOPE','PRIOR_DIRECTORY_REFERENCES','PRIOR_DECLARED_METADATA'}
 oldbindings={}
 for key,value in oldstatic.items():
  assert key in nodes,key
  node=nodes[key]
  if key in ['source_directory_references','qualification']:continue
  if isinstance(node,ast.Name):
   assert node.id in allowed_old_names
   if node.id in oldbindings:assert oldbindings[node.id]==value
   oldbindings[node.id]=value
  elif key=='NEW_scope_exact_JSON_bytes':assert ast.dump(node)==ast.dump(ast.parse('len(NEW_CHILD_DIRECTORY_SCOPE_RAW)',mode='eval').body)
  elif key=='NEW_scope_exact_JSON_sha256':assert ast.dump(node)==ast.dump(ast.parse('hashlib.sha256(NEW_CHILD_DIRECTORY_SCOPE_RAW).hexdigest()',mode='eval').body)
  else:assert ast.literal_eval(node)==value,key
 expected={**oldstatic,'source_directory_references':refs,'NEW_ALL190_explicit_input_scope':scope,'prior_ALL63_directory_references_NOT_requeried':old['ALL63_source_refs'],'NEW190_scope_exact_JSON_bytes':len(raws['NEW190scope']),'NEW190_scope_exact_JSON_sha256':hashlib.sha256(raws['NEW190scope']).hexdigest(),'NEW190_prior_actual_reference_ledger_metadata':ledger,'qualification':ast.literal_eval(nodes['qualification']),'prior_ALL63_qualification_metadata_only':oldqualification,'directory_INPUT_open_attempts':190}
 names={'source_directory_references':'DIRECTORY_REFERENCES','NEW_ALL190_explicit_input_scope':'NEW_GRANDCHILD_DIRECTORY_SCOPE','prior_ALL63_directory_references_NOT_requeried':'PRIOR_CHILD_DIRECTORY_REFERENCES','NEW190_prior_actual_reference_ledger_metadata':'NEW190_PRIOR_REFERENCE_LEDGERS'}
 for key,name in names.items():assert isinstance(nodes[key],ast.Name) and nodes[key].id==name
 assert ast.dump(nodes['directory_INPUT_open_attempts'])==ast.dump(ast.parse('len(DIRECTORY_REFERENCES)',mode='eval').body)
 assert ast.dump(nodes['NEW190_scope_exact_JSON_bytes'])==ast.dump(ast.parse('len(NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW)',mode='eval').body) and ast.dump(nodes['NEW190_scope_exact_JSON_sha256'])==ast.dump(ast.parse('hashlib.sha256(NEW_GRANDCHILD_DIRECTORY_SCOPE_RAW).hexdigest()',mode='eval').body)
 assert len(expected['source_directory_references'])==190 and len(expected['prior_ALL63_directory_references_NOT_requeried'])==63 and len(expected['prior_ALL49_directory_references_NOT_requeried'])==49 and expected['NEW_ALL63_explicit_input_scope']==oldbindings['NEW_SCOPE'] and len(expected['NEW_ALL63_explicit_input_scope']['ALL63_new_literal_directory_references'])==63
 assert expected['NEW_scope_exact_JSON_bytes']==5531267 and expected['NEW_scope_exact_JSON_sha256']=='42116723f7fcf899e46be761a74a45aa2e0b19ef07e5e4ae22683840383fde99'
 assert len(expected['NEW190_prior_actual_reference_ledger_metadata']['ALL_prior_captured_static_literal_values'])==168954 and [len(r['literal_values']) for r in expected['NEW190_prior_actual_reference_ledger_metadata']['groups']]==[1229,1199,160,63,49]
 pending={k:{'AST_kind':type(node).__name__,'source_line':node.lineno,'runtime_value_UNMEASURED':None} for k,node in nodes.items() if k not in expected}
 save('FIRST-NEW190-static-report-field-bindings-PRIVATE.json',json.dumps({'new_source_import_bindings':imports,'expected_static_report_fields':expected,'all_runtime_dynamic_fields_UNMEASURED_PRIVATE':pending,'source_literal_payload_bindings':[newbinding,ledbinding],'old63_immutable_static_carrier_NOT_revalidated':True,'no_original_or_candidate_source_executed':True,'no_old_AST_syntax_or_conditions_or_refcomparisons_repeated':True},ensure_ascii=True,indent=2))
 ruby='require "yaml";require "json";v=YAML.load(File.binread(ARGV[0]));j=v.fetch("jobs").fetch("flatbuffers-include-grandchild-directory-inputs");puts JSON.generate(j)'
 args=['ruby','-e',ruby,str(N/'candidate-wamp-profile-benchmarks.yml')];save('FIRST-newjob-static-binding-native-request.json',json.dumps({'argv':args,'cwd':str(Q),'purpose':'ONLYnewjob python3dash collector-reference-uploader/toolchain metadata binding/no old33condition reevaluation'},indent=2));p=subprocess.Popen(args,cwd=Q,stdout=subprocess.PIPE,stderr=subprocess.PIPE);known=p;save('FIRST-newjob-static-binding-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_before_IO':True},indent=2));out,err=p.communicate();status=p.wait();save('FIRST-newjob-static-binding.stdout',out);save('FIRST-newjob-static-binding.stderr',err);completion={'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(out),'stderr_bytes':len(err),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()};save('FIRST-newjob-static-binding-completion.json',json.dumps(completion,indent=2));assert status==0
 job=json.loads(out);runs=[r['run'] for r in job['steps'] if isinstance(r.get('run'),str) and 'python3 - < .github/collectors/pr132_include_grandchild_directory_inputs.py' in r['run']];uploaders=[r for r in job['steps'] if isinstance(r.get('uses'),str) and r['uses'].startswith('actions/upload-artifact@')];assert len(runs)==1 and len(uploaders)==1 and uploaders[0]['with']['path']=='${{ runner.temp }}/native-perf-include-grandchild-directory-inputs'
 save('FIRST-newjob-collector-uploader-bindings.json',json.dumps({'new_job':job,'declared_regularfile_stdin_NOTidenticalFDtopology':True,'old33condition_PASSraw_reused_NOTreevaluated':True},indent=2))
 summary={'collector_bytes':1613289,'collector_sha256':'cab8351afb91aa946d151e472ee302d8800aa3f8351e1b51ae842138041d6fc2','workflow_bytes':482286,'workflow_sha256':'9fee182f28e886a235d74765660982e6054722636c517878857b337e3388b1f2','NEW190_literal_scope_field_count':len(refs),'expected_static_report_field_count':len(expected),'pending_runtime_field_names':list(pending),'pending_runtime_values_UNMEASURED':None,'old63_scope_separate_from_NEW190scope':True,'OLD63_guards_prefix_BYTEEXACT_proof_from_consumed_generation_NOT_replayed':True,'NEW190_loader_before_scope_write_before_directory_INPUT_loop':True,'source_import_bindings':imports,'source_literal_payload_bindings':[newbinding,ledbinding],'prior_actual_literal_ledger_group_counts':[1229,1199,160,63,49],'prior_static_literal_values_count':168954,'prior_reference_comparisons_NOT_reexecuted':True,'ALL33_condition_PASSraw_BYTEEXACT_reused_NOT_reevaluated':True,'first_newjob_static_binding_completion':completion,'saved_input_read_bindings':len(bindings),'new_SDK_or_Actions_queries':0,'source_commit':None,'run_id':None,'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipe_EOF':None}
 save('FIRST-NEW190-static-binding-preflight-summary.json',json.dumps(summary,indent=2));cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-static-binding-result.json',before);d=json.loads(before);node=d['actions_include_grandchild_directory_inputs_v1'];node.update(phase='FIRST_NEW190_localSTATIC_report_payload_import_job_binding_COMPLETE_CONSUMED_NOT_dispatched_queried_admitted',static_binding_directory=str(Q),static_binding_summary=summary,all_admission_flags=False)
 d['active_turn_status'].update(new_include_grandchild_directory_inputs='FIRSTlocalSTATIC_bindings_complete_NOremote_IO',next='FIRSTnewlargecollector GitHubAPI fullbyte-readback transport documentation/qualification beforeanyfirstsourcecommit-dispatch-query. Currentnew190staticpayload-import-old63/new190-report-job-uploader binding/33PASSrawcopy consumed; no oldsource-parser-model-SDK-Actions/acquisition replay. AllsetupUNADMITTED/no build-adoption-numerical.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True);lease.verify_identity()
