import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,time
Q=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-07-actions-include-grandchild-directory-inputs-v1/GitHub-blob-readback-docs-v1');v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':'FIRST newofficialGitHubREST documentation intake for1613289Bcollector fullbyte-readback transport; exacttwo officialGitHubdocs URLs declaredBEFOREwebIO. Existingcontents-readback behavior/limits notguessed. NotoldPR-description/API/Actions/sourcequery refresh orSDK/compiler-bodyquery/model-review retry. Fullactualwebtoolrequest-return metadata PRIVATE/notfullHTTPwire. OfficialSHheldacrosswebcall/retention/receipt; no runtime/sourceadoption/build oradmission authority.','exact_web_request':v,'all_admission_flags':False,'ownership':None},indent=2));save('holder-controller.py',sys.argv[2]);save('exact-web-request-BEFORE-call.json',json.dumps(v,ensure_ascii=True,separators=(',',':')))
 print(json.dumps({'official_SH_holder_pid':os.getpid(),'held_across_web_request_return_retention':True}),flush=True)
 while not (Q/'release-after-web-retention.json').exists():time.sleep(1)
 lease.verify_identity();save('holder-release-receipt.json',json.dumps({'holder_pid':os.getpid(),'identity_verified_before_context_exit':True},indent=2))
print('OFFICIAL_SH_DOCS_CONTEXT_EXIT_RETURNED',flush=True)
