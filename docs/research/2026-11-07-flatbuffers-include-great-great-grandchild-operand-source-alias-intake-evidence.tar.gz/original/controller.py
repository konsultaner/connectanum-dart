import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_NEW9026_operand_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)






import os,stat,collections,datetime,contextlib
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-operand-source-alias-intake-v1';v=json.loads(sys.argv[1]);declaration=v['declaration']
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));bindings=[];outputs=[]
 helper=B/'2026-11-07-actions-include-great-grandchild-operand-source-alias-intake-v1/FIRST-streaming-publication-preparation-v1/bounded_json.py';hb=helper.read_bytes();assert len(hb)==7283 and hashlib.sha256(hb).hexdigest()=='631f2976b157f1c5d42437f9ca8d1ef8fa3cd99c9535b4bdc7b2aaf3b00b6cae'
 sb=importlib.util.spec_from_file_location('own_artifact_new9026_intake',helper);bj=importlib.util.module_from_spec(sb);sys.modules[sb.name]=bj;sb.loader.exec_module(bj)
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def snap(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 class NewOutput:
  def __init__(self,path,role):
   self.path=path;self.binding={'role':role,'path':str(path),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(self.binding);self.fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);self.binding['open_return_fd']=self.fd;self.binding['before'],self.binding['before_atime_ns_POINT_ONLY']=snap(self.fd);self.count=0;self.h=hashlib.sha256()
  def emit(self,raw):
   if isinstance(raw,str):raw=raw.encode()
   for start in range(0,len(raw),65536):
    block=raw[start:start+65536];sent=0
    while sent<len(block):
     n=os.write(self.fd,block[sent:]);assert n>0;sent+=n
    os.lseek(self.fd,self.count,os.SEEK_SET);parts=[];count=0
    while count<len(block):
     x=os.read(self.fd,len(block)-count);assert x;parts.append(x);count+=len(x)
    assert b''.join(parts)==block
    self.h.update(block);self.count+=len(block)
  def close(self):
   self.binding['after'],self.binding['after_atime_ns_POINT_ONLY']=snap(self.fd);assert self.binding['after']['st_size']==self.count
   self.binding.update(bytes=self.count,sha256=self.h.hexdigest(),whole_same_OUTPUTFD_BYTEWISE_countSHA_readback=True)
   os.close(self.fd);self.binding['close_return_fd']=self.fd
   save(self.binding['role']+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(self.binding,indent=2))
 def extract(source,targetkey):
  role=source['role'];size=source['range'][1];expected=source['sha256'];b={'role':role,'path':source['path'],'range':source['range'],'expected_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(source['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==size
  copy=NewOutput(P/(role+'-bound-PRIVATE.json'),role+'_bound_copy');primary=None;selected=[];occurrences0=0
  try:
   def tee(n):
    raw=os.read(fd,n);copy.emit(raw);return raw
   rr=bj.BoundedJSON(tee,size)
   for key in rr.object_keys():
    if key==targetkey:
     occurrences0+=1
     if role=='original_new_physical_result':
      for op in rr.array_values():selected.append(op)
     else:
      for row in rr.array_values():selected.append(row['original_separate_parent_child_metadata'])
    else:rr.skip_value()
   rr.finish();b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);b.update(bytes=rr.bytes_read,sha256=rr.digest.hexdigest());assert b['before']==b['after'] and rr.bytes_read==size and rr.digest.hexdigest()==expected and occurrences0==1 and copy.count==size and copy.h.hexdigest()==expected
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:copy.close()
  except BaseException as e:
   b['copy_close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return selected
 ops=extract(declaration['exact_saved_inputs'][0],'ALL_include_operand_rows_PRIVATE');entries=extract(declaration['exact_saved_inputs'][1],'ALL2308_original_child_relationships_with_NEW_counts')
 assert len(ops)==9026 and len(entries)==2308 and len(bindings)==2
 for op in ops:assert op['comparison_performed'] is False and op['comparison_match_count_UNPERFORMED'] is None and op['comparison_matches_UNPERFORMED'] is None and op['comparison_nonmatches_UNPERFORMED'] is None and op['comparison_nonmatch_count_UNPERFORMED'] is None
 resultname='ROOT-FIRST-ALL9026-great-great-grandchild-operand-source-alias-intake-PRIVATE.json';out=NewOutput(P/resultname,'FIRST_new9026_result');out.emit('{"execution_declaration":');out.emit(json.dumps(declaration,ensure_ascii=True));out.emit(',"ALL9026_NEW_operand_entry_relationships_PRIVATE":[');relation_first=True
 def append_relationship(row):
  global relation_first
  if not relation_first:out.emit(',')
  out.emit(json.dumps(row,ensure_ascii=True,separators=(',',':')));relation_first=False
 entryrows=[];typecounts=collections.Counter()
 for ordinal,row in enumerate(entries):
  mode=row['original_separate_lstat_full_stat_times_PRIVATE'];mode=None if mode is None else mode['st_mode'];typ=row['saved_type_derived_from_original_mode'];typecounts[typ]+=1
  flags={'original_mode_regular':None if mode is None else stat.S_ISREG(mode),'original_mode_directory':None if mode is None else stat.S_ISDIR(mode),'original_mode_symlink':None if mode is None else stat.S_ISLNK(mode),'original_mode_other':None if mode is None else not(stat.S_ISREG(mode) or stat.S_ISDIR(mode) or stat.S_ISLNK(mode))}
  entryrows.append({'original_record_ordinal_ZERO_based':ordinal,'ALLoriginal_separate_parent_child_metadata_PRIVATE':row,'original_mode_type_flags':flags})
 assert typecounts['regular']==2279 and typecounts['directory']==29 and typecounts['symlink']==typecounts['other']==typecounts['unknown']==0
 assert all(row['original_separate_readlink_literal_UNEXPANDED_UNFOLLOWED'] is None and row['original_separate_readlink_rawhex_UNEXPANDED_UNFOLLOWED'] is None for row in entries)
 def occurrences(hay,needle):
  if needle=='':return list(range(len(hay)+1))
  out=[];start=0
  while True:
   pos=hay.find(needle,start)
   if pos<0:return out
   out.append(pos);start=pos+1
 def locs(hay,needle,chars):
  try:utf8=[len(hay[:pos].encode('utf-8')) for pos in chars];error=None
  except UnicodeEncodeError as err:utf8=None;error={'kind':type(err).__name__,'start':err.start,'end':err.end,'reason':err.reason}
  return {'character_offsets_ZERO_based':chars,'UTF8_byte_offsets_ZERO_based':utf8,'UTF8_offset_encoding_error_UNMEASURED_if_valid':error,'needle_character_count':len(needle),'original_haystack_literal_UNCHANGED':hay,'original_needle_literal_UNCHANGED':needle}
 def pair(left,right):
  forward=occurrences(right,left);reverse=occurrences(left,right)
  if not forward and not reverse:return None
  return {'exact_scalar_equality':left==right,'operand_in_entry_saved_scalar_ALLoverlap_locations':locs(right,left,forward),'entry_saved_scalar_in_operand_ALLoverlap_locations':locs(left,right,reverse)}
 def complement_runs(matched):
  out=[];start=None
  for ordinal in range(len(entries)):
   if ordinal not in matched:
    if start is None:start=ordinal
   elif start is not None:out.append([start,ordinal]);start=None
  if start is not None:out.append([start,len(entries)])
  return out
 relationships_count=0;performed=0;unperformed=0;name_candidates_matched=0;hex_candidates_matched=0;union_candidates_matched=0;relation_count=0;participating=set();relation_types=collections.Counter();eligiblelinks=sum(row['original_separate_readlink_literal_UNEXPANDED_UNFOLLOWED'] is not None for row in entries)
 for operandordinal,op in enumerate(ops):
  literal=op['literal_operand_UTF8'];literalhex=op['literal_operand_bytes_hex']
  if op['physical_operand_kind'] not in ['angle_delimited_literal','quote_delimited_literal']:
   unperformed+=1;append_relationship({'new_operand_position_ZERO_based':operandordinal,'original_operand_ALLfields_UNCHANGED':op,'new_delimited_literal_comparison_performed':False,'new_comparison_unperformed_reason':'original_physical_undelimited_macro_or_other_operand','name_exact_or_substring_match_count_UNPERFORMED':None,'namehex_exact_or_substring_match_count_UNPERFORMED':None,'ALL_matching_entry_relationships_PRIVATE_UNPERFORMED':None,'ALL_nonmatching_name_entry_ordinal_runs_UNPERFORMED':None,'ALL_nonmatching_namehex_entry_ordinal_runs_UNPERFORMED':None,'readlink_literal_comparison_performed':False,'readlink_rawhex_comparison_performed':False,'readlink_literal_match_count_UNPERFORMED':None,'readlink_rawhex_match_count_UNPERFORMED':None,'ALL_readlink_literal_matches_UNPERFORMED':None,'ALL_readlink_rawhex_matches_UNPERFORMED':None,'ALL_readlink_literal_nonmatches_UNPERFORMED':None,'ALL_readlink_rawhex_nonmatches_UNPERFORMED':None,'alias_identity':None,'effective_include':None,'query_permission':None});continue
  assert isinstance(literal,str) and isinstance(literalhex,str)
  performed+=1;matches=[];nm=set();hm=set()
  for entryordinal,row in enumerate(entries):
   name=row['literal_child_name_SEPARATE'];hexname=row['original_name_bytes_hex'];n=pair(literal,name);h=pair(literalhex,hexname)
   if n is not None:nm.add(entryordinal)
   if h is not None:hm.add(entryordinal)
   if n is not None or h is not None:
    matches.append({'original_entry_record_ordinal_ZERO_based':entryordinal,'original_entry_metadata_location':['ALL2308_original_child_relationships_with_NEW_counts',entryordinal,'original_separate_parent_child_metadata'],'original_parent_query_ordinal_ZERO_based':row['parent_query_ordinal_ZERO_based'],'original_child_entry_ordinal_ZERO_based':row['child_entry_ordinal_ZERO_based'],'original_mode_type_flags':entryrows[entryordinal]['original_mode_type_flags'],'four_metadata_relation_flags':{'name_exact':literal==name,'namehex_exact':literalhex==hexname,'name_substring_either_direction':n is not None,'namehex_substring_either_direction':h is not None},'name_pair_ALL_matching_overlapping_locations':n,'namehex_pair_ALL_matching_overlapping_locations':h,'entry_saved_name_in_operand_absolute_physical_file_byte_offsets':None if n is None or n['entry_saved_scalar_in_operand_ALLoverlap_locations']['UTF8_byte_offsets_ZERO_based'] is None else [op['literal_operand_file_byte_range'][0]+x for x in n['entry_saved_scalar_in_operand_ALLoverlap_locations']['UTF8_byte_offsets_ZERO_based']],'entry_saved_name_in_operand_absolute_physical_file_character_offsets_UTF8':None if n is None or op['literal_operand_file_character_range_UTF8'] is None else [op['literal_operand_file_character_range_UTF8'][0]+x for x in n['entry_saved_scalar_in_operand_ALLoverlap_locations']['character_offsets_ZERO_based']],'name_pair_match_count':0 if n is None else len(n['operand_in_entry_saved_scalar_ALLoverlap_locations']['character_offsets_ZERO_based'])+len(n['entry_saved_scalar_in_operand_ALLoverlap_locations']['character_offsets_ZERO_based']),'namehex_pair_match_count':0 if h is None else len(h['operand_in_entry_saved_scalar_ALLoverlap_locations']['character_offsets_ZERO_based'])+len(h['entry_saved_scalar_in_operand_ALLoverlap_locations']['character_offsets_ZERO_based']),'readlink_literal_comparison_performed':False,'readlink_rawhex_comparison_performed':False,'readlink_literal_match_count_UNPERFORMED':None,'readlink_rawhex_match_count_UNPERFORMED':None,'ALL_readlink_literal_matches_UNPERFORMED':None,'ALL_readlink_rawhex_matches_UNPERFORMED':None,'alias_identity':None,'effective_include':None,'query_permission':None});participating.add(entryordinal);relation_types[row['saved_type_derived_from_original_mode']]+=1
  name_candidates_matched+=bool(nm);hex_candidates_matched+=bool(hm);union_candidates_matched+=bool(matches);relation_count+=len(matches)
  append_relationship({'new_operand_position_ZERO_based':operandordinal,'original_operand_ALLfields_UNCHANGED':op,'new_delimited_literal_comparison_performed':True,'name_exact_or_substring_match_count':len(nm),'namehex_exact_or_substring_match_count':len(hm),'union_matching_original_entry_records_count':len(matches),'ALL_matching_entry_relationships_PRIVATE':matches,'ALL_nonmatching_name_entry_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':complement_runs(nm),'ALL_nonmatching_namehex_entry_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':complement_runs(hm),'ALL_nonmatching_union_entry_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':complement_runs(nm|hm),'readlink_literal_comparison_performed':False,'readlink_rawhex_comparison_performed':False,'readlink_literal_match_count_UNPERFORMED':None,'readlink_rawhex_match_count_UNPERFORMED':None,'ALL_readlink_literal_matches_UNPERFORMED':None,'ALL_readlink_rawhex_matches_UNPERFORMED':None,'ALL_readlink_literal_nonmatches_UNPERFORMED':None,'ALL_readlink_rawhex_nonmatches_UNPERFORMED':None,'alias_identity':None,'effective_include':None,'query_permission':None})
 assert performed==9026 and unperformed==0 and performed+unperformed==9026 and eligiblelinks==0
 summary={'source_physical_run_id':42412749412,'source_physical_revision':'aa9c430cf80c09215b3cfc125591c0cfbafd65b9','source_metadata_run_id':42403777505,'source_metadata_revision':'c4b4e6b2d7bce853d008b9c91cccb811088ad6ed','ALL9026_operand_rows':len(ops),'delimited_comparisons_performed':performed,'undelimited_macro_other_UNPERFORMED':unperformed,'undelimited_macro_matchcount_matchlists_NULL':True,'original_metadata_records':len(entries),'original_metadata_type_counts_from_saved_modes':{k:typecounts[k] for k in ['regular','directory','symlink','other','unknown']},'eligible_saved_link_records_THISdataset':eligiblelinks,'ALL_operand_readlink_comparisons_UNPERFORMED_counts_lists_NULL':True,'name_candidates_with_matches':name_candidates_matched,'name_candidates_without_matches':performed-name_candidates_matched,'namehex_candidates_with_matches':hex_candidates_matched,'namehex_candidates_without_matches':performed-hex_candidates_matched,'union_candidates_with_matches':union_candidates_matched,'union_candidates_without_matches':performed-union_candidates_matched,'matching_operand_entry_relations':relation_count,'original_entry_record_positions_participating_NOT_alias_dedup':len(participating),'original_entry_record_positions_without_relations':len(entries)-len(participating),'matching_relation_original_type_counts':{k:relation_types[k] for k in ['regular','directory','symlink','other','unknown']},'saved_metadata_read_bindings':len(bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_header_body_reads':0,'new_body_parser_executions':0,'new_recursive_directory_queries':0,'candidate_executions':0,'alias_identity':None,'effective_includes':None,'query_permission':None,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None}

 out.emit('],"summary":');out.emit(json.dumps(summary,ensure_ascii=True));out.emit(',"ALL2308_original_metadata_records_and_mode_flags_PRIVATE":');out.emit(json.dumps(entryrows,ensure_ascii=True,separators=(',',':')))
 def embed(source,key):
  path=P/(source['role']+'-bound-PRIVATE.json');out.emit(','+json.dumps(key)+':');fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);before,atime=snap(fd);assert before['st_size']==source['range'][1];count=0;h=hashlib.sha256()
  try:
   while count<source['range'][1]:
    raw=os.read(fd,min(65536,source['range'][1]-count));assert raw;out.emit(raw);h.update(raw);count+=len(raw)
   after,atime2=snap(fd);assert before==after and h.hexdigest()==source['sha256']
  finally:os.close(fd)
  save(source['role']+'-WHOLE-raw-JSON-value-embedding-binding-PRIVATE.json',json.dumps({'path':str(path),'range':[0,count],'sha256':h.hexdigest(),'sameFD_before':before,'sameFD_after':after,'before_atime_ns_POINT_ONLY':atime,'after_atime_ns_POINT_ONLY':atime2,'file_EOF_probe':None,'closed_FD':fd,'ALL_original_raw_JSON_bytes_fields_PRIVATE_unchanged_no_normalization':True},indent=2))
 embed(declaration['exact_saved_inputs'][0],'ALL_original_physical_result_fields_PRIVATE_UNCHANGED');embed(declaration['exact_saved_inputs'][1],'ALL_original2308_metadata_intake_fields_PRIVATE_UNCHANGED')
 out.emit(',"ALL_two_new_savedmetadata_read_bindings_PRIVATE":');out.emit(json.dumps(bindings,ensure_ascii=True));out.emit(',"matching_original_entry_record_positions_ZERO_based":');out.emit(json.dumps(sorted(participating)));out.emit(',"qualification":');out.emit(json.dumps(declaration['scope']));out.emit('}\n');out.close()
 descriptor={'result_saved':resultname,'result_bytes':out.count,'result_sha256':out.h.hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 CP=B/'current-task-checkpoint.json';before=CP.read_bytes();save('checkpoint-before-intake-result.json',before);d=json.loads(before);d['actions_include_great_great_grandchild_operand_source_alias_intake_v1']={'phase':'COMPLETE_CONSUMED_FIRST_ALL9026_operand_saved_entry_relationships_NOT_admitted','directory':str(P),'original_saved_result':str(P/resultname),'original_saved_result_bytes':out.count,'original_saved_result_sha256':out.h.hexdigest(),'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_grandchild_operand_source_alias_intake='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST boundedsummary-publication originalNEW9026relationship result ONLY/no oldsource-body-reader-parser-model-SDKquery-imagehash-Actionsacquisition-archive-numerical/schemaaudit replay/allprivatefields-stat-times-epochs-29DEFERRED-6and18links-oldncursesrawhexNULL unchanged/allsetupUNADMITTED/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
