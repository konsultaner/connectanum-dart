class AuxiliaryInitLeaseProgressTests(unittest.TestCase):
    """NEW original INIT method on an actual preallocated/retained source object."""
    def _init_lease_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-init-lease-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        verify=official_ex_verify;initialize=producer.AuxiliaryCommand.__init__;a=object.__new__(producer.AuxiliaryCommand)
        actors=[];calls=[];operations=[];foreign_calls=[];cleanup=[];fault=False;raised=None;guard_error=None;loss_guard_error=None
        init_returned=False;init_value=None
        native_write=producer._write_json;native_hash=producer._regular_hash;real_allocate=producer.AuxiliaryCommand._allocate_process
        class OriginalFault(OSError):
            def __repr__(self):raise AssertionError('INIT first error must never be rendered')
        first=OriginalFault(5,'OWN verify return hidden by ROOT INIT callback fault');payload=b'OWN-init-lease-output'
        argv=[sys.executable,'-c',"import os;os.write(1,"+repr(payload)+")"];original_argv=list(argv)
        def rows():
            value=getattr(a,'_init_lease_journal',None)
            return value if type(value) is list else []
        def foreign_callback():foreign_calls.append(True);return None
        def callback():
            nonlocal fault
            ordinal=len(calls)+1;row=rows()[-1] if rows() else {}
            value=verify();calls.append(dict(ordinal=ordinal,actual_CURRENT_official_verify_returned=True,raw_is_None=value is None,
                INIT_intent_before_delegate=(ordinal!=1 or (row.get('object') is a and row.get('callback') is callback and row.get('callback_attempted') is True and row.get('returned') is None))))
            if ordinal==1:
                if mode in ('buffer-drift','intent-drift','alias-drift','unknown-return','lost-primary'):
                    fault=True
                    if mode=='buffer-drift':a.streams['stdout']['buffer']=b'ROOT-INIT-buffer'
                    if mode=='intent-drift':a.intent['argv'][0]='ROOT-INIT-injected'
                    if mode=='alias-drift':a.lease_check=foreign_callback
                    if mode in ('unknown-return','lost-primary'):raise first
                if mode=='false':return False
            return value
        def writing(*args,**kwargs):
            if fault:operations.append(dict(kind='_write_json',attempted=True))
            value=native_write(*args,**kwargs)
            if fault:operations[-1]['returned']=True
            return value
        def hashing(*args,**kwargs):
            if fault:operations.append(dict(kind='_regular_hash',attempted=True))
            value=native_hash(*args,**kwargs)
            if fault:operations[-1]['returned']=True
            return value
        def allocate(current,record):
            if fault:operations.append(dict(kind='_allocate_process',attempted=True))
            value=real_allocate(current,record);actors.append(dict(process=value,bound_wait=value.wait,name=current.name));return value
        try:
            with mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate):
                try:
                    init_value=initialize(a,directory=base,name='init-source',argv=argv,cwd=base,environment=dict(os.environ),lease_check=callback)
                    init_returned=True
                    if mode in ('none','false'):a.start();a.wait(timeout=10)
                except BaseException as error:raised=error
                if mode not in ('none','false'):
                    # Pure guard only: never start/wait a failed or changed INIT object.
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
                    if mode=='lost-primary':
                        a._init_lease_primary_error=OriginalFault;a._init_lease_quarantined=False
                        try:a._constructor_guard()
                        except BaseException as error:loss_guard_error=error
            row=rows()[0] if rows() else {};intent_path=base/'init-source-intent.json';intent_bytes=intent_path.read_bytes() if intent_path.exists() else None
            saved=row.get('intent_bytes_before');saved_intent=json.loads(saved) if type(saved) is bytes else None
            report=dict(mode=mode,preallocated_original_object_retained_BEFORE_original_INIT=True,not_original_enclosing_factory_retention_or_fullpublicconstructor_admission=True,
                init_method_returned=init_returned,init_raw_is_None=init_value is None,callback_calls=calls,foreign_callback_calls=len(foreign_calls),
                after_fault_source_attempts=operations,source_process_returns=len(actors),raised_is_original=raised is first,raised_is_ProducerError=type(raised) is producer.ProducerError,
                pureguard_raises_received=raised is not None and guard_error is raised,loss_pureguard_raises_original=loss_guard_error is first,
                private_first_is_received=raised is not None and getattr(a,'_init_lease_primary_error',None) is raised,
                original_callback_binding=a._constructor_quarantine_binding[5] is callback,
                started=a.started,pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                intent_exists=intent_bytes is not None,intent_hex=None if intent_bytes is None else intent_bytes.hex(),
                published_intent_argv=None if intent_bytes is None else json.loads(intent_bytes)['argv'],
                original_argv=original_argv,row_original_object=row.get('object') is a,row_original_callback=row.get('callback') is callback,
                row_attempted=row.get('callback_attempted'),row_returned=row.get('returned'),row_raw_is_None=row.get('raw_return') is None,
                row_raw_is_False=row.get('raw_return') is False,row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                row_saved_intent_argv=None if saved_intent is None else saved_intent['argv'])
            with (base/'init-lease-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_callback_binding']);self.assertEqual(0,len(foreign_calls))
            self.assertTrue(all(x['actual_CURRENT_official_verify_returned'] and x['raw_is_None'] for x in calls))
            if mode in ('none','false'):
                self.assertIsNone(raised);self.assertTrue(init_returned);self.assertIsNone(init_value);self.assertEqual(3,len(calls))
                self.assertTrue(a.finished);self.assertFalse(a.pending);self.assertEqual(original_argv,report['published_intent_argv'])
                self.assertEqual(payload,(base/'init-source.stdout').read_bytes());self.assertEqual(0,a.status)
            else:
                self.assertEqual(1,len(calls));self.assertEqual([],operations);self.assertEqual([],actors);self.assertFalse(init_returned)
                if mode in ('unknown-return','lost-primary'):self.assertIs(first,raised)
                else:self.assertIs(type(raised),producer.ProducerError)
                self.assertIs(raised,guard_error);self.assertTrue(report['row_original_object']);self.assertTrue(report['row_original_callback'])
                self.assertTrue(report['row_error_is_received']);self.assertEqual(original_argv,report['row_saved_intent_argv'])
                self.assertTrue(calls[0]['INIT_intent_before_delegate']);self.assertFalse(report['intent_exists'])
                self.assertFalse(a.started);self.assertFalse(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
                if mode=='lost-primary':self.assertIs(first,loss_guard_error)
                else:self.assertTrue(report['private_first_is_received'])
                if mode in ('unknown-return','lost-primary'):self.assertIsNone(report['row_returned'])
                else:self.assertIs(report['row_returned'],True)
        finally:
            for actor in actors:
                value=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_bound_same_finite_wait',pid=actor['process'].pid,status=value,expected=0,cached_possible=True))
                self.assertIs(type(value),int);self.assertEqual(0,value)
            with (base/'init-lease-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_actual_INIT_verify_then_buffer_drift_stops_before_intent(self):self._init_lease_case('buffer-drift')
    def test_actual_INIT_verify_then_nested_intent_drift_stops_before_publication(self):self._init_lease_case('intent-drift')
    def test_actual_INIT_verify_then_alias_drift_stops_before_intent(self):self._init_lease_case('alias-drift')
    def test_actual_INIT_verify_then_fault_keeps_first_and_original_context(self):self._init_lease_case('unknown-return')
    def test_INIT_bound_first_survives_primary_class_and_flag_damage(self):self._init_lease_case('lost-primary')
    def test_normal_INIT_actual_verify_None_preserves_intent_and_output(self):self._init_lease_case('none')
    def test_INIT_ignored_False_return_preserves_original_contract(self):self._init_lease_case('false')
