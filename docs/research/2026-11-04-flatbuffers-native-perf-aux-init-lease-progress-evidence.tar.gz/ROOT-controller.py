import sys,pathlib,json,hashlib,ast,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-init-lease-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();h=json.loads((P/'after-edit-hashes.json').read_text());actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert actual==h
 s=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();ast.parse(s);ast.parse(tests)
 assert s==(P/'candidate-producer-v2.py').read_text()
 oldtests=(P/'before-existing-tests.py').read_bytes();assert tests==oldtests+b'\n'+(P/'new-tests-v2.py').read_bytes()
 assert json.loads((P/'ROOT-candidate-invariants.json').read_text())['candidate_BYTEprojectsback'] is True
 before=json.loads((P/'before-v2/result.json').read_text());after=json.loads((P/'after-selected/result.json').read_text());assert (before['tests'],before['failures'],before['errors'])==(7,5,0);assert (after['tests'],after['failures'],after['errors'])==(25,0,0)
 commands=[['git','rev-parse','HEAD'],['git','branch','--show-current'],['git','status','--short','--untracked-files=all'],['git','diff','--name-only','HEAD','--','packages','native']]
 git=[]
 for index,argv in enumerate(commands):
  prefix=q/('git-'+str(index))
  with prefix.with_suffix('.before.json').open('x') as f:json.dump(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None),f)
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  with prefix.with_suffix('.start.json').open('x') as f:json.dump(dict(pid=child.pid),f)
  out,err=child.communicate();status=child.wait()
  for name,raw in [('stdout.bin',out),('stderr.bin',err)]:
   with pathlib.Path(str(prefix)+'.'+name).open('xb') as f:f.write(raw)
  result=dict(argv=argv,pid=child.pid,status=status,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),stdout_size=len(out),stderr_size=len(err),both_EOF=True)
  with prefix.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
  assert status==0 and err==b'';git.append((out,result))
 assert git[0][0].decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6';assert git[1][0].decode().strip()=='codex/flatbuffers-native-perf-guard'
 statuslines=git[2][0].decode().splitlines();assert len(statuslines)==20 and all(x.startswith('?? tool/') for x in statuslines);assert git[3][0]==b''
 reports=[];waitrows=[];verifyrows=[]
 for phase in ['before-v2','after-selected']:
  for path in sorted((P/phase/'fixtures').glob('*/init-lease-before-cleanup.json')):
   r=json.loads(path.read_text());cleanup=json.loads(path.with_name('init-lease-unit-cleanup.json').read_text());reports.append(dict(phase=phase,path=str(path),mode=r['mode']))
   verifyrows+=r['callback_calls'];waitrows+=[x for x in cleanup if x['kind']=='ROOT_bound_same_finite_wait']
   if phase=='after-selected':
    assert r['source_repr_calls_BEFORE_unit_assertions']==0
    if r['mode'] not in ['none','false']:
     assert r['after_fault_source_attempts']==[] and r['source_process_returns']==0 and r['pureguard_raises_received']
     assert r['row_original_object'] and r['row_original_callback'] and r['row_error_is_received'] and r['row_saved_intent_argv']==r['original_argv']
     assert r['started'] is False and r['pending'] is False and r['finished'] is False and r['result_is_None'] is True and r['intent_exists'] is False and r['init_method_returned'] is False
     assert r['row_returned'] is (None if r['mode'] in ['unknown-return','lost-primary'] else True)
     if r['mode']=='lost-primary':assert r['loss_pureguard_raises_original']
 assert len(reports)==14 and len(waitrows)==4 and all(type(x['status']) is int and x['status']==0 for x in waitrows)
 assert len(verifyrows)==22 and all(x['actual_CURRENT_official_verify_returned'] and x['raw_is_None'] for x in verifyrows)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='INIT-site callback before original intent writer ONLY; later writer/hash/earlier init/enclosing factory/fullphysicalEX/runtimeadmission/RAMrepair/acceptance incomplete',
 source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],NEWbefore7='5FAIL2PASS0APIerrors at5fc083/fe34de; nestedintent actuallywritten; othercontextpublication/unknownfirstpolicies NOTfive nativebugs',
 AFTERselected25='7matchingNEW+18affected PASS/newepochONLY/notaggregate/fullcurrent20canonical/admission',
 whole_final_source_tests_AST_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_unchanged=True,original_othermethods_factories_gates_resultliteral_Popenconstructorfacts_exact=True,
 source_git_new4_actual0_BOTHstreams=True,branch='codex/flatbuffers-native-perf-guard',HEAD='601108ea6216464bd00ae29c16cfaf0a59c71db6',exact20_untracked_uncommitted_uncanonical_unadmitted=True,tracked_packages_native_diffempty_DATA_only=True,
 new_unit_journals=14,new_ROOT_boundwait_rows=4,all_signed0_cached_possible=True,actual_A_facade_CURRENT_official_EX_verify_None_rows=22,not_all_setup_controller_verifier_calls=True,
 unit_seam='Actual raw Auxiliary object preallocated by original object.__new__ and retained BEFOREcalling exact source __init__; normalinitializer returnNone separatecallbackNone; NOToriginal enclosing factory retention/publicconstructor/nativePopeninstance admission',
 new_negative_source_actor_returns0_no_intent_namespace_or_later_write_hash=True,first_recovered_after_class_scalar_and_flag_damage_without_class_construction=True,raw_return_knownNone_vs_unknown_distinct=True,
 no_negative_SourceSTART_wait_or_second_INIT=True,postcallback_native_shape_no_foreign_render_serialization='SOURCEqualified only for unsupported foreign/cyclic metadata; sevenexecuted contexts NOTglobal closure/auth/ABA',
 GLM80373='review0/reaped/stdout7707stderr1288/input36868/fullanswer/ROOTqualified NOTwholecurrentapproval',Qwen79159='planning0/reaped/stdout1148stderr395/fullanswer/ROOTqualified BEFORE7thlosscontrol',
 before_controller_v1='AttributeError wrongPathparentheses BEFOREhashread-floor-qmkdir-compile-testbody; zero tests; new before-v2 setup correction only',
 prepared_controls='planningv1 phase label/testhelperv1 precall-evidence/editv1 Path expression corrected BEFOREthose executions, UNEXECUTED/no inventedfailurecounts',
 rawlimits='Only two normal finite actors perbefore-after group; RootSAMEwaits afterrawreport/cachedpossible. Normal sourceFD-log APIs notallsystematicallyserialized/no allchildFD/interpreter-delegate-descendant/instructionclosure or physicalEX. Legacysetup/actorFD/tool/inlineartifactAPI returnsnotall files/no reconstruction.',
 initial_controllers='Source reader declared inline actualtoolinput BEFOREcall; named model/edit/test/ROOTcontrollers savedBEFOREcalls; artifactinline APIreturns notall serialized',
 free_bytes=free,storage_floor='OPEN' if free>=12884901888 else 'CLOSED',storage_cause_outside_old_lossless_cleanup_UNMEASURED_no_deletion_authority=True,
 provider_ABSENT=True,gate_alwaysraises=True,controller_CLOSED=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_adoption_cleanup_RAMrepair_strictacceptance=True,reports=reports,git=[x[1] for x in git])
 for path in [q/'assessment.json',P/'ROOT-final-invariants.json']:
  with path.open('x') as f:json.dump(result,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_init_lease_progress'];v.update(ROOT_pending=False,ROOT_assessment=str(q/'assessment.json'),ROOT_qualified=True,source_component_only_COMPLETE=True,publication_pending=True,source_new_epoch_UNTESTED=False,never_repeat_unchanged=True)
 n['current_helper_source_epoch'].update(producer_sha256=result['source_sha256'],test_sha256=result['test_sha256'],hashes_file=str(P/'after-edit-hashes.json'),final_epoch_UNTESTED=False,verification_scope='1b3e08/21b6fd selected25PASS=7new18affected ROOTqualified NOTmodelwholecurrentapproval/current20canonical/admission',latest_postflight=str(q/'assessment.json'))
 c['active_turn_status']='Aux_INIT_lease1b3e08_21b6fd_selected25PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity()
 print(json.dumps({k:result[k] for k in ['source_sha256','test_sha256','NEWbefore7','AFTERselected25','new_unit_journals','new_ROOT_boundwait_rows','actual_A_facade_CURRENT_official_EX_verify_None_rows','free_bytes']}))
