import sys,pathlib,json,hashlib,os,io,types,unittest,datetime
from pathlib import Path
from unittest import mock
import tempfile,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-init-lease-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads(P/'before-hashes.json'.read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize;assert free>=1073741824
 q=P/'before';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();new=(P/'new-tests-v2.py').read_bytes()
 for name,b in [('producer.py',source),('existing-tests.py',tests),('new-tests-v2.py',new)]:
  with (q/name).open('xb') as f:f.write(b)
 names=["test_actual_INIT_verify_then_buffer_drift_stops_before_intent","test_actual_INIT_verify_then_nested_intent_drift_stops_before_publication","test_actual_INIT_verify_then_alias_drift_stops_before_intent","test_actual_INIT_verify_then_fault_keeps_first_and_original_context","test_INIT_bound_first_survives_primary_class_and_flag_damage","test_normal_INIT_actual_verify_None_preserves_intent_and_output","test_INIT_ignored_False_return_preserves_original_contract"]
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),selection=names,NEW_INIT_original_method_on_preallocated_RAWobject_CURRENT_EX_ONLY_NOToriginalfactory_fullphysicalEX_admission=True),f,indent=2)
 sys.path.insert(0,str(R/'tool'));producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 ns=dict(producer=producer,Path=Path,os=os,sys=sys,json=json,hashlib=hashlib,unittest=unittest,tempfile=tempfile,subprocess=subprocess,mock=mock,official_ex_verify=l.verify_identity,__name__='new_aux_init_lease_progress')
 exec(compile(new,str(P/'new-tests-v2.py'),'exec'),ns);suite=unittest.TestSuite(ns['AuxiliaryInitLeaseProgressTests'](name) for name in names);out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (q/'tests.log').open('x') as f:f.write(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),new_test_sha256=hashlib.sha256(new).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_canonical_or_SDK_native_workload=True)
 with (q/'result.json').open('x') as f:json.dump(value,f,indent=2)
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 l.verify_identity();print(json.dumps({k:value[k] for k in ['tests','failures','errors','source_sha256','new_test_sha256']}));print(out.getvalue()[-6500:])
