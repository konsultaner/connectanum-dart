import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-status-poll-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW Aux native poll status: original normal-constructor handle, per-call lookup/attempt/rawreturn progress, field drift and invalid return; source/test read only; no model/tests/SDK/nativebuild/HEAD/Git/archive/cleanup',producer_expected='64e8016b9898f68fedbd49e3598106607e5b6da194c4012287cb9dcb550045f3',test_expected='4f53f80ceeeb4e28972fea9a28698041961fe6e78becf31ee82c2661feea1630',actual_official_EX=True,prior_components_consumed_no_repeat=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='64e8016b9898f68fedbd49e3598106607e5b6da194c4012287cb9dcb550045f3' and hashlib.sha256(tests).hexdigest()=='4f53f80ceeeb4e28972fea9a28698041961fe6e78becf31ee82c2661feea1630'
 for name,data in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(data)
 source=source.decode();c=next(x for x in ast.parse(source).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 methods={x.name:ast.get_source_segment(source,x) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in ('_observe_status','_constructor_record','_constructor_guard','_arm_constructor')}
 with (P/'selected-source.json').open('x') as f:json.dump(methods,f,indent=2)
 l.verify_identity();print(json.dumps({k:v for k,v in methods.items() if k in ('_observe_status','_arm_constructor')}))
