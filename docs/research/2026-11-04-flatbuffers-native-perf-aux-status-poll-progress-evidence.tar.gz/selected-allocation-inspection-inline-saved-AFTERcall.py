import sys,pathlib,ast,json
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-status-poll-progress-v1');s=(p/'source-before.py').read_text();c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_allocate_process')
 body=ast.get_source_segment(s,node)
 with (p/'selected-normal-allocation.txt').open('x') as f:f.write(body)
 print('\n'.join(line for line in body.splitlines() if any(k in line for k in ['initializer','allocated_process','result','returned'])))
 l.verify_identity()
