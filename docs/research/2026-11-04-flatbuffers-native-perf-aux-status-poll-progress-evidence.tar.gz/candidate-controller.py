import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-status-poll-progress-v1');before=(p/'source-before.py').read_text();s=before
 methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema.py.txt').read_text();full=(p/'candidate-complete-guard.txt').read_text()
 c=next(x for x in ast.parse(before).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');old=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_observe_status')
 rows=before.splitlines(True);oldblock=''.join(rows[old.lineno-1:old.end_lineno]);assert s.count(oldblock)==1;s=s.replace(oldblock,methods,1)
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='        self._buffer_write_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._buffer_write_guard()\n        self._status_poll_guard()\n\n    def _constructor_record',1)
 c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_complete')
 body=ast.get_source_segment(s,node);needle='        self._constructor_guard()\n';assert body.count(needle)==1;replacement=body.replace(needle,needle+full,1);assert s.count(body)==1;s=s.replace(body,replacement,1)
 needle="            buffer_state=values.get('_buffer_write_state');buffer_journal=values.get('_buffer_write_journal')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 fields="                status_poll_fields_valid=poll_ok,status_poll_quarantined=poll_quarantined,\n                status_poll_entries=len(poll_journal) if type(poll_journal) is list else None,\n                status_poll_returned=poll_last.get('returned') if type(poll_last.get('returned')) is bool else None,\n                status_poll_raw_status=poll_last.get('raw_return') if type(poll_last.get('raw_return')) is int else None,\n                status_poll_value_valid=poll_last.get('value_valid') if type(poll_last.get('value_valid')) is bool else None,\n                status_poll_completed=poll_last.get('completed') if type(poll_last.get('completed')) is bool else None,\n"
 needle='                buffer_write_fields_valid=buffer_ok,buffer_write_quarantined=buffer_quarantined,';assert s.count(needle)==1;s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer.py',s),('old-observe-status-block.txt',oldblock),('candidate-data-fields.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='64e801-before',tofile='NEW-status-poll-candidate')))
 l.verify_identity();print('private poll candidate UNEXECUTED; no source edit')
