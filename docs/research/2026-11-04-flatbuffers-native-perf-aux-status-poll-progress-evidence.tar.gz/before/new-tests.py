class AuxiliaryStatusPollProgressTests(unittest.TestCase):
    """NEW original-handle/poll boundaries; no sampler or SDK admission."""
    def _poll_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-status-poll-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        release=base/'finite-pending-release';auxiliaries=[];actors=[];logs={};pipes=[];closed=[];closed_numbers=set()
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close
        real_allocate=producer.AuxiliaryCommand._allocate_process
        events=[];cleanup=[];a=None;b=None;raised=None;guard_error=None;returned=object();first=OSError(5,'OWN native poll return hidden by ROOT fault')
        def allocate(current,record):
            value=real_allocate(current,record)
            actors.append(dict(name=current.name,process=value,bound_wait=value.wait,bound_poll=value.poll,expected=7 if current.name=='poll-source' and mode=='nonzero' else 0))
            return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for name in ('poll-source','poll-foreign'):
                for role in ('stdout','stderr'):
                    if path==base/(name+'.'+role):logs[name+'.'+role]=value
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            value=native_close(fd);closed_numbers.add(fd);closed.append(dict(fd=fd,raw_None=value is None));return value
        def latest():
            journal=getattr(a,'_status_poll_journal',None)
            return journal[-1] if type(journal) is list and journal and type(journal[-1]) is dict else {}
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                if mode=='pending':
                    code="import pathlib,time;p=pathlib.Path("+repr(str(release))+");end=time.monotonic()+8\nwhile not p.exists() and time.monotonic()<end: time.sleep(.005)"
                else:code='raise SystemExit('+str(7 if mode=='nonzero' else 0)+')'
                a=producer.AuxiliaryCommand(directory=base,name='poll-source',argv=[sys.executable,'-c',code],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);auxiliaries.append(a);a.start()
                b=producer.AuxiliaryCommand(directory=base,name='poll-foreign',argv=[sys.executable,'-c','pass'],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);auxiliaries.append(b);b.start()
                original=next(x for x in actors if x['name']=='poll-source')
                foreign=next(x for x in actors if x['name']=='poll-foreign')
                if mode!='pending':
                    status=original['bound_wait'](10);events.append(dict(stage='ROOT_pre_wait_source',status=status,cached_possible=True))
                    self.assertEqual(original['expected'],status)
                status=foreign['bound_wait'](10);events.append(dict(stage='ROOT_pre_wait_foreign',status=status,cached_possible=True));self.assertEqual(0,status)
                def source_poll():
                    row=latest();intent=(row.get('process') is original['process']
                        and row.get('poll_attempted') is True and row.get('returned') is None)
                    value=original['bound_poll']()
                    events.append(dict(stage='native_source_poll',raw_return=value,source_intent_before_native=intent))
                    if mode=='drift':a.process=foreign['process']
                    if mode=='invalid-bool':return False
                    if mode=='unknown-return':raise first
                    return value
                def foreign_poll():
                    value=foreign['bound_poll']();events.append(dict(stage='native_foreign_poll',raw_return=value));return value
                original['process'].poll=source_poll;foreign['process'].poll=foreign_poll
                if mode=='foreign-before':a.process=foreign['process']
                try:returned=a._observe_status()
                except BaseException as error:raised=error
                if mode in ('foreign-before','drift','invalid-bool','unknown-return'):
                    # Pure guard only; never a second native poll/wait after error.
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            row=latest();native_calls=[x for x in events if x['stage'].startswith('native_')]
            report=dict(mode=mode,events=events,raised_is_injected=raised is first,
                raised_is_ProducerError=type(raised) is producer.ProducerError,
                guard_raises_received_first=raised is not None and guard_error is raised,
                original_handle_retained=a._constructor_quarantine.get('allocated_process') is original['process'],
                public_handle_is_original=a.process is original['process'],
                source_status_is_None=a.status is None,source_status=a.status,method_return_is_None=returned is None,
                pending=a.pending,finished=a.finished,source_result_is_None=a.result is None,
                source_private_first=raised is not None and getattr(a,'_deferred_primary_error',None) is raised,
                row_present=bool(row),row_original_process=row.get('process') is original['process'],
                row_lookup_attempted=row.get('lookup_attempted'),row_lookup_returned=row.get('lookup_returned'),
                row_poll_attempted=row.get('poll_attempted'),row_returned=row.get('returned'),
                row_raw_value=row.get('raw_return'),row_value_valid=row.get('value_valid'),
                row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                known_ROOT_created_parent_pipe_slots=pipes,known_ROOT_native_close_returns=closed,
                scope='TWO own finite SourceAux commands and ROOT bound native poll/wait; cached returns possible; source facts not actor ownership/auth/physicalEX/SDK')
            with (base/'poll-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_handle_retained'])
            if mode in ('zero','nonzero','pending'):
                self.assertIsNone(raised);self.assertIsNone(returned)
                self.assertEqual(1,len(native_calls));self.assertEqual('native_source_poll',native_calls[0]['stage'])
                if mode=='pending':self.assertIsNone(a.status);self.assertIsNone(native_calls[0]['raw_return'])
                else:self.assertIs(type(a.status),int);self.assertEqual(7 if mode=='nonzero' else 0,a.status)
            else:
                if mode=='foreign-before':
                    self.assertEqual([],native_calls);self.assertIs(type(raised),producer.ProducerError)
                elif mode in ('drift','invalid-bool'):
                    self.assertIs(type(raised),producer.ProducerError);self.assertEqual(1,len(native_calls))
                    self.assertEqual('native_source_poll',native_calls[0]['stage'])
                else:self.assertIs(first,raised);self.assertEqual(1,len(native_calls))
                self.assertIs(raised,guard_error);self.assertTrue(report['source_private_first'])
                self.assertTrue(report['row_original_process']);self.assertTrue(report['row_error_is_received'])
                self.assertIsNone(a.status);self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
                self.assertFalse(report['row_completed'])
                if mode=='foreign-before':self.assertFalse(report['row_poll_attempted'])
                else:
                    self.assertTrue(native_calls[0]['source_intent_before_native'])
                    if mode=='unknown-return':self.assertIsNone(report['row_returned']);self.assertIsNone(report['row_raw_value'])
                    else:
                        self.assertIs(report['row_returned'],True)
                        if mode=='invalid-bool':self.assertIs(report['row_raw_value'],False);self.assertIsNot(report['row_value_valid'],True)
                        else:self.assertIs(type(report['row_raw_value']),int);self.assertEqual(0,report['row_raw_value'])
        finally:
            # Root-only finite release is never a source continuation/cleanup API.
            try:
                if not release.exists():
                    with release.open('x') as f:f.write('OWN finite unit release only')
            finally:
                for actor in actors:
                    value=actor['bound_wait'](10)
                    cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=actor['expected'],cached_possible=True))
                    self.assertIs(type(value),int);self.assertEqual(actor['expected'],value)
                for item in pipes:
                    fd=item['fd']
                    if fd in closed_numbers:continue
                    st=os.fstat(fd);self.assertEqual((item['dev'],item['ino']),(st.st_dev,st.st_ino));value=native_close(fd)
                    cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
                for name,log in logs.items():
                    if not log.closed:
                        fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                        log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',name=name,fd=fd,returned=True))
                with (base/'poll-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_foreign_actual_handle_refuses_before_native_poll(self):self._poll_case('foreign-before')
    def test_actual_poll_return_then_pointer_drift_refuses_status_publish(self):self._poll_case('drift')
    def test_actual_poll_return_then_bool_is_not_status_zero(self):self._poll_case('invalid-bool')
    def test_actual_poll_return_then_fault_retains_unknown_and_first(self):self._poll_case('unknown-return')
    def test_normal_cached_zero_return_preserves_None_method_result(self):self._poll_case('zero')
    def test_normal_cached_nonzero_status_preserved(self):self._poll_case('nonzero')
    def test_actual_pending_None_is_known_pending_not_exit_zero(self):self._poll_case('pending')
