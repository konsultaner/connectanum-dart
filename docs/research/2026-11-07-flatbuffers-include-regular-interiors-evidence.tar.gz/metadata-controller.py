import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
A=B/'2026-11-07-actions-include-regular-inputs-v1/transport-Actions-v1'
P=B/'2026-11-07-actions-include-regular-interiors-v1'
import os,stat,datetime
declaration={
 'new_question':'FIRST metadata mapping ONLY to declare all160 exact saved header body ranges for NEW physical-directive/operand static interpretation',
 'source_run':42350609933,'source_commit':'5c05963bc6d2697c414cbb9e657cfbae6fadac56',
 'exact_initial_input':str(A/'actual-new-artifact-member-index.json'),
 'report_locator':'Exactly one original index member with single literal basename include-regular-inputs.json; index ONLYlocates it, no archive/journal/oldstreamcomparison/SDK query',
 'report_before_IO':'Save exact mapped report path and [0, original index bytes) declaration before report read',
 'body_IO_in_this_metadata_scope':False,
 'all_prior_210_160_49_1_ledgers_and_epochs':'Preserved byte fields, no revalidation or normalization; dirs deferred; ncurses.h/curses.h unexpanded-unfollowed/readlinkhexNULL',
 'all_admission_flags':False,
 'no_source_runtime_SDK_Actions_build_numerical_cleanup':True
}
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('FIRST-metadata-declaration.json',json.dumps(declaration,indent=2))
 save('FIRST-metadata-controller.py',sys.argv[1])
 bindings=[]
 def read(path,role,expected=None):
  row={'path':str(path),'role':role,'before_open_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};bindings.append(row)
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);row['open_return_fd']=fd
  try:
   s=os.fstat(fd);row['before']={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']};assert stat.S_ISREG(s.st_mode)
   pieces=[];h=hashlib.sha256();count=0
   while True:
    chunk=os.read(fd,65536)
    if not chunk:break
    pieces.append(chunk);count+=len(chunk);h.update(chunk)
   row.update(bytes=count,sha256=h.hexdigest(),read_EOF=True)
   after=os.fstat(fd);row['after']={k:getattr(after,k) for k in row['before']};assert row['before']==row['after'] and count==s.st_size
   if expected is not None:assert count==expected['bytes'] and row['sha256']==expected['sha256']
   return b''.join(pieces)
  finally:os.close(fd);row['close_return_fd']=fd
 index=json.loads(read(A/'actual-new-artifact-member-index.json','saved_member_locator'))
 assert len({r['name'] for r in index})==len(index)
 reports=[r for r in index if pathlib.PurePosixPath(r['name']).name=='include-regular-inputs.json'];assert len(reports)==1
 rr=reports[0];relative=pathlib.PurePosixPath(rr['name']);assert not relative.is_absolute() and '..' not in relative.parts
 rp=A/'artifact-members'/relative
 save('FIRST-exact-report-declaration-before-read.json',json.dumps({'path':str(rp),'range':[0,rr['bytes']],'original_index_record':rr,'only_mapping_not_old_journal_comparison':True},indent=2))
 report=json.loads(read(rp,'saved_report_mapping',rr))
 assert str(report['run_id'])=='42350609933' and report['workflow_revision']=='5c05963bc6d2697c414cbb9e657cfbae6fadac56'
 observations=report['observations'];assert len(observations)==160
 rows=[]
 for obs in observations:
  assert 'absent_at_open_only' not in obs
  members=[r for r in index if r['name']==obs['saved_member']];assert len(members)==1
  x=members[0];rel=pathlib.PurePosixPath(x['name']);assert not rel.is_absolute() and '..' not in rel.parts
  assert x['bytes']==obs['bytes'] and x['sha256']==obs['sha256']
  rows.append({'source_reference':obs['source_reference'],'original_observation_ordinal':obs['ordinal'],'saved_member':x['name'],'saved_path':str(A/'artifact-members'/rel),'bounded_range':[0,x['bytes']],'original_saved_bytes':x['bytes'],'original_saved_sha256':x['sha256']})
 assert len({r['source_reference'] for r in rows})==160 and sum(r['original_saved_bytes'] for r in rows)==3387853
 keys=['source_regular_references','ALL210_include_original_safe_entry_metadata','ALL160_include_explicit_lexical_relations','ALL49_include_deferred_directories_NO_query_recursion','ALL1_include_original_symlink_UNEXPANDED_UNFOLLOWED']
 preserved={k:report[k] for k in keys}
 save('ALL160-exact-saved-body-range-plan.json',json.dumps({'source_run':42350609933,'source_commit':report['workflow_revision'],'ALL160_exact_body_sources_and_ranges':rows,'preserved_original_metadata_NOT_revalidated':preserved,'body_IO_started':False,'all_admission_flags':False},ensure_ascii=True,indent=2))
 save('FIRST-metadata-read-bindings.json',json.dumps(bindings,indent=2))
 summary={'phase':'FIRST_METADATA_MAPPING_COMPLETE_CONSUMED_BODY_UNREAD','directory':str(P),'source_run':42350609933,'mapped_body_count':len(rows),'declared_body_bytes':sum(r['original_saved_bytes'] for r in rows),'report_path':str(rp),'report_keys':list(report),'body_plan':'ALL160-exact-saved-body-range-plan.json','preserved_metadata_counts':{k:len(v) if isinstance(v,(list,dict)) else None for k,v in preserved.items()},'body_IO':False,'all_admission_flags':False}
 save('FIRST-metadata-summary.json',json.dumps(summary,indent=2));print(json.dumps(summary),flush=True);lease.verify_identity()
