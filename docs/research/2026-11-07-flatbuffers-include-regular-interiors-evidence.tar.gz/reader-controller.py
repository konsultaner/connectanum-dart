import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,re,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-regular-interiors-v1';Q=P/'FIRST-physical-directive-reader-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={
  'question':'FIRST bounded physical-byte directive/operand candidate interpretation of ALL160 NEW saved header body streams; no actual preprocessing or conditional evaluation',
  'exact_plan_source':str(P/'ALL160-exact-saved-body-range-plan.json'),
  'body_ranges':'ALL160 exact paths and [0,original_saved_bytes) ranges in saved plan, copied in full into before-body-IO declaration',
  'grammar':{
   'physical_lines':'Split at literal LF including LF in physical record; do not splice, decode, remove CR/comments, expand macros, resolve includes, or normalize bytes',
   'candidate_pattern_hex_ascii':'^[\\x20\\x09\\x0b\\x0c\\x0d]*#[\\x20\\x09\\x0b\\x0c\\x0d]*([A-Za-z_][A-Za-z_0-9]*)?',
   'all_candidates':'Keep EVERY matching physical line in original order with byte range/full raw hex, lexical keyword, full raw operand hex, prior-current physical backslash-newline flags',
   'include_operands':'For literal keyword include/include_next/import only: strip literal horizontal-space bytes; first raw byte quote or angle opens a lexical candidate, first raw closing delimiter ends it; preserve raw suffix and all no-close/macro-empty forms, no C tokenization/unescaping/effective-directive claim',
   'prefix_suffix':'Retain first and last min(64,size) byte hex for each file as bounded literal observations',
   'encoding':'Report UTF8 strict success/failure and NUL count; no decode fallback/line normalization',
   'remaining_semantics':'All comments/conditional states/tokenization/include resolution/compile/default language-ABI/sysroot/effective compiler/runtime semantics UNINTERPRETED'
  },
  'preserve_all210_original_and_new_lexical_epochs':True,'dirs49_deferred_no_IO':True,
  'ncurses_h_curses_h':'UNEXPANDED_UNFOLLOWED_original_raw_readlink_bytehex_NOT_SAVED_NULL',
  'prior_ledgers':'All original prior records remain protected at original metadata epochs; no new SDK/hash/query/source read or old stream-journal comparison',
  'all_admission_flags':False,'ownership':None,
  'separate_outer_launcher_PID_pipe_EOF':None,
  'no_source_runtime_SDK_Actions_build_numerical_cleanup':True
 }
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-metadata-root-context.json',json.dumps(v,ensure_ascii=True,indent=2))
 bindings=[];operation=None
 def state(fd):
  s=os.fstat(fd);return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']}
 def bound(path,role,expected=None):
  row={'path':str(path),'role':role,'before_open_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};bindings.append(row);fd=None;primary=None;raw=None
  try:
   fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);row['open_return_fd']=fd
   before=state(fd);row['before']=before;assert stat.S_ISREG(before['st_mode'])
   if expected:assert before['st_size']==expected['original_saved_bytes']
   h=hashlib.sha256();pieces=[];done=0
   while done<before['st_size']:
    chunk=os.pread(fd,min(65536,before['st_size']-done),done)
    if not chunk:raise RuntimeError('Unexpected saved-FD EOF; partial semantics quarantined')
    pieces.append(chunk);done+=len(chunk);h.update(chunk)
   assert os.pread(fd,1,done)==b''
   row.update(bounded_range=[0,done],bytes=done,sha256=h.hexdigest(),read_EOF=True)
   if expected:assert h.hexdigest()==expected['original_saved_sha256']
   after=state(fd);row['after']=after;assert before==after
   raw=b''.join(pieces)
  except BaseException as e:primary=e;row['primary_error']={'kind':type(e).__name__,'text':str(e)}
  if fd is not None:
   try:os.close(fd);row['close_return_fd']=fd
   except BaseException as e:
    row['close_error']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
  if primary is not None:raise primary
  return raw
 try:
  plan=json.loads(bound(P/'ALL160-exact-saved-body-range-plan.json','exact_new_body_plan'))
  rows=plan['ALL160_exact_body_sources_and_ranges'];assert len(rows)==160 and sum(r['original_saved_bytes'] for r in rows)==3387853 and plan['body_IO_started'] is False
  save('ALL160-exact-body-declaration-BEFORE-body-IO.json',json.dumps({'declaration':declaration,'ALL160_sources_and_ranges':rows,'preserved_original_metadata_NOT_revalidated':plan['preserved_original_metadata_NOT_revalidated'],'body_IO_started':False},ensure_ascii=True,indent=2))
  pattern=re.compile(rb'^[ \t\v\f\r]*#[ \t\v\f\r]*([A-Za-z_][A-Za-z_0-9]*)?')
  whitespace=b' \t\v\f\r';allresults=[];totals={};literal_requests=[];all_summary=[]
  for r in rows:
   raw=bound(pathlib.Path(r['saved_path']),'FIRST_new_header_physical_semantics',r)
   result={**r,'physical_line_count':0,'LF_count':raw.count(b'\n'),'NUL_count':raw.count(b'\0'),'prefix64_hex':raw[:64].hex(),'suffix64_hex':raw[-64:].hex(),'ALL_ordered_physical_hash_candidates':[]}
   try:raw.decode('utf-8');result['strict_UTF8']='success'
   except UnicodeDecodeError as e:result['strict_UTF8']={'first_failure_start':e.start,'first_failure_end':e.end,'reason':e.reason}
   offset=0;prior=False;keywords={};includes=[];continued=0
   # split only literal LF; no synthetic zero-length final physical line
   physical=raw.splitlines(keepends=True) if False else raw.split(b'\n')
   if raw.endswith(b'\n'):physical.pop()
   for i,part in enumerate(physical):
    line=part+(b'\n' if offset+len(part)<len(raw) else b'')
    current=line.endswith(b'\\\n') or line.endswith(b'\\\r\n')
    result['physical_line_count']+=1;continued+=int(current);match=pattern.match(line)
    if match:
     keyword=(match.group(1) or b'').decode('ascii');keywords[keyword]=keywords.get(keyword,0)+1;totals[keyword]=totals.get(keyword,0)+1
     operand=line[match.end():];item={'physical_line_1based':i+1,'offset':offset,'bytes':len(line),'raw_hex':line.hex(),'keyword_literal':keyword,'raw_after_keyword_hex':operand.hex(),'previous_physical_line_has_backslash_newline':prior,'this_physical_line_has_backslash_newline':current,'effective_preprocessor_directive':None}
     if keyword in ['include','include_next','import']:
      candidate=operand.lstrip(whitespace);opening=candidate[:1]
      inc={'source_reference':r['source_reference'],'physical_line_1based':i+1,'offset':offset,'keyword_literal':keyword,'raw_candidate_operand_hex':candidate.hex(),'effective_include_request':None}
      if opening in [b'<',b'"']:
       closing=b'>' if opening==b'<' else b'"';end=candidate.find(closing,1)
       inc.update(raw_opening=opening.decode('ascii'),raw_first_closing_offset=end if end>=0 else None,lexical_form='raw_delimited_candidate' if end>=0 else 'raw_delimiter_unclosed_on_this_physical_line')
       if end>=0:
        inc['raw_name_hex']=candidate[1:end].hex();inc['raw_name_UTF8_surrogateescape']=candidate[1:end].decode('utf-8','surrogateescape');inc['raw_suffix_hex']=candidate[end+1:].hex()
      else:inc['lexical_form']='empty_or_macro_or_other_raw_form'
      includes.append(inc);literal_requests.append(inc);item['include_operand_candidate']=inc
     result['ALL_ordered_physical_hash_candidates'].append(item)
    offset+=len(line);prior=current
   assert offset==len(raw)
   result.update(keyword_literal_counts=keywords,physical_backslash_newline_count=continued,include_operand_candidate_count=len(includes));allresults.append(result)
   all_summary.append({'source_reference':r['source_reference'],'saved_member':r['saved_member'],'bytes':r['original_saved_bytes'],'physical_line_count':result['physical_line_count'],'strict_UTF8':result['strict_UTF8'],'NUL_count':result['NUL_count'],'hash_candidate_count':len(result['ALL_ordered_physical_hash_candidates']),'keyword_literal_counts':keywords,'include_operand_candidate_count':len(includes),'physical_backslash_newline_count':continued})
  counts={}
  for inc in literal_requests:counts[inc['lexical_form']]=counts.get(inc['lexical_form'],0)+1
  qualification='FIRST ALL160 saved-body literal physical-byte scan only. Every first-non-horizontal-space # physical candidate retained, including any in comments/continued macros/conditional regions; no preprocessing/splicing/comment stripping/tokenization/condition evaluation/default-language/include resolution. Delimited names are raw candidate bytes, not established effective dependencies, paths, aliases, installed access or request permission. Full new bytes scanned for declared pattern, remaining program/body semantics UNINTERPRETED. Actualreport/index onlylocated savedmembers; no original SDK/currentheader hash refresh or old stream-journal comparison. Original ALL210 names-namehex-modes-types-UIDGID-links/separate-parent-name flags/newlexicalepochs/49dirsdeferred/ncurses.h-curses.h unexpanded-unfollowed/readlinkhexNULL/allpriorledgers preserved, not revalidated. Point sameFD/countSHA/stat/close not atomicABA-origin/auth/pathchain/globalactorFD/continuousphysicalEX-crash closure. No import/compile/nativequery/SDK/ACTIONS/bootstrap/build/driver/perf/numerical/Source20-runtime adoption. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI incomplete.'
  summary={'phase':'FIRST_ALL160_PHYSICAL_DIRECTIVE_CANDIDATES_COMPLETE_CONSUMED_NOT_admitted','source_run':42350609933,'source_commit':plan['source_commit'],'body_count':len(allresults),'new_bounded_body_bytes':sum(r['original_saved_bytes'] for r in rows),'physical_lines':sum(r['physical_line_count'] for r in allresults),'hash_candidate_count':sum(len(r['ALL_ordered_physical_hash_candidates']) for r in allresults),'keyword_literal_counts':totals,'include_operand_candidate_count':len(literal_requests),'include_lexical_form_counts':counts,'physical_backslash_newline_count':sum(r['physical_backslash_newline_count'] for r in allresults),'non_UTF8_body_count':sum(r['strict_UTF8']!='success' for r in allresults),'NUL_body_count':sum(r['NUL_count']>0 for r in allresults),'read_binding_count':len(bindings),'qualification':qualification,'all_admission_flags':False,'ownership':None,'reader_outer_launcher_PID_pipe_EOF':None}
  save('ALL160-physical-directive-candidates-PRIVATE.json',json.dumps({'summary':summary,'ALL160':allresults,'ALL_ordered_include_operand_candidates':literal_requests},ensure_ascii=True,indent=2)+'\n')
  save('ALL160-new-physical-scan-summary.json',json.dumps({**summary,'ALL160_file_summaries':all_summary},ensure_ascii=True,indent=2)+'\n')
  save('FIRST-new-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2))
  save('completion.json',json.dumps(summary,indent=2))
  cp=B/'current-task-checkpoint.json';cpraw=cp.read_bytes();save('checkpoint-before-reader-update.json',cpraw);d=json.loads(cpraw)
  d['actions_include_regular_interiors_v1']={'directory':str(P),'reader_directory':str(Q),**summary,'full_assessment':str(Q/'ALL160-physical-directive-candidates-PRIVATE.json'),'public_documentation_pending':True}
  d['actions_include_regular_inputs_v1']['all_new_saved_body_interiors_UNINSPECTED']=False
  d['active_turn_status']['next']='FIRST ALL160 savedheader physical directive/operand candidates COMPLETE_CONSUMED; summarize NEW results/publish metadata. All remaining program semantics/comment-preprocessing-conditions/includes UNINTERPRETED; no native SDK/candidatequery/import/compile/Actions/build/numerical/Source20-runtime adoption or old read-parser-model/acquisition replay. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-FINALstrict48/50-cleanCI incomplete.'
  d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps(summary),flush=True);lease.verify_identity()
 except BaseException as e:
  save('failure-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('failure.json',json.dumps({'kind':type(e).__name__,'text':str(e),'partial_unknowns_permanent_quarantine':True,'all_admission_flags':False},indent=2));raise
