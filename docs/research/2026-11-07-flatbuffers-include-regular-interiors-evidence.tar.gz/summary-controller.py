import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import subprocess
P=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132/2026-11-07-actions-include-regular-interiors-v1');R=P/'FIRST-physical-directive-reader-v1';Q=P/'summary-v1'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps({'scope':'FIRST advisory summary of genuinely NEW ALL160 physical-header candidate scan only; not an old source/parser/review/model rerun, not SDK query or compile. Narrow derived ALL160 counts and actual aggregate only; no raw header reopen, directive preprocessing/condition evaluation or include resolution. Advisory ROOT verifies, no approval/unavailability inference or advice-derived extra read/test/query.', 'all_admission_flags':False},indent=2));save('controller.py',sys.argv[1])
 d=json.loads((R/'ALL160-new-physical-scan-summary.json').read_bytes())
 rows=[{'source_reference':r['source_reference'],'bytes':r['bytes'],'physical_lines':r['physical_line_count'],'hash_candidates':r['hash_candidate_count'],'include_candidates':r['include_operand_candidate_count'],'backslash_newlines':r['physical_backslash_newline_count'],'UTF8':r['strict_UTF8'],'NUL_count':r['NUL_count']} for r in d['ALL160_file_summaries']]
 selection=json.dumps({'actual_aggregate':{k:v for k,v in d.items() if k!='ALL160_file_summaries'},'ALL160_derived_count_rows':rows},ensure_ascii=True,indent=2);save('NEW-ALL160-derived-summary-selection.json',selection)
 prompt='Summarize the NEW literal physical-header scan in <=130words. Mention all160/3387853bytes/84569physical lines/15313 first-nonspace# candidates,576include-operand candidates (575 raw-delimited and1macro/empty/other),2129backslash-newlines. Counts include comments/examples/continued macros; actual keywords include included and Z3_mk_* proving these are physical text candidates, NOT established effective preprocessing directives/dependencies. All160UTF8/noNUL is literal byte observation, NOTABI/defaultcompiler/sysroot/semantic/effectivecondition/access/cohort/ownership proof. No automatic joining/resolution/following of any include string or candidateexecution. All210original metadata and epochs/49dirsdeferred/ncurses.h-curses.h unexpanded-unfollowed/originalreadlinkhexNULL preserved. Suggest at most ONE bounded next saved-data question; no oldread-parser-model-SDK-query-build-compile-archive/campaign retry or cleanup advice. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair/FINALstrict48/50-cleanCI incomplete.'
 args=[sys.executable,str(H),'summarize','--repo',str(Q),'--file',str(Q/'NEW-ALL160-derived-summary-selection.json'),'--prompt',prompt,'--num-predict','900','--max-response-chars','5000','--timeout','180','--no-think']
 save('request.json',json.dumps({'argv':args},indent=2))
 p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);known=p;save('creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_IO':True},indent=2));print(json.dumps({'new_summary_pid':p.pid}),flush=True)
 o,e=p.communicate();status=p.wait();save('stdout',o);save('stderr',e)
 r={'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(o),'stderr_bytes':len(e),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_sha256':hashlib.sha256(e).hexdigest(),'advisory_not_approval':True}
 save('completion.json',json.dumps(r,indent=2));print(json.dumps(r));print(o.decode());print('HELPER_STDERR\n'+e.decode());lease.verify_identity()
