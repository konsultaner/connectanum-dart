import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-snapshot-enclosing-audit-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-snapshot-enclosing-audit'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601b96f77ca1323e846cc89746e5dc779e0ecf59'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Map snapshot constructor containment before further changes\n\nA cached-source audit identifies three nominal snapshot routes: auxiliary finalization, archive revalidation and command-log finalization. The helper constructs its snapshot attempt before registering it. Auxiliary finalization records an unknown return as None; command-log finalization starts with False. The archive revalidation call has no immediate callback record, and an exception stops its later statements.\n\nThese findings describe source order. Auxiliary first-error metadata accesses remain fallible, and higher failure handling, runtime bindings and transitive actors still need targeted evidence. No new failing regression was executed, so this audit makes no Source change. Five exact-identifier references, three separate Git attribute references and four higher attribute references are retained with their selected context. An empty literal-rebinding query establishes no runtime identity or global absence.\n\nBoth companion reviews reached token limits without a final answer; their full partial finals remain absent. ROOT independently qualifies the selected source and its limits. Producer c4199a and test0e4e94 remain the latest verified factory epoch. This phase performs no Source or HEAD recensus, tests, build or capture. The previous49 scoped tests remain historical and separate. Runtime admission, RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-snapshot-enclosing-audit'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: map snapshot constructor containment'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_enclosing_audit'].update(publication=receipt,docs_pending=False)
 n['current_free_bytes_about']=assessment['storage']['free_bytes'] # artifact-storage DATA; previous verified Source hashes remain unchanged
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="NEWpredeclared regression candidates: Auxiliary snapshotConstructorFirst plusfirst-error metadata getter/setter failure; _git archive snapshotConstructorFirst throughhigherinitialization/defer/preserve handling. UNEXECUTEDhypotheses/SOURCEINFERENCE, notruntimecounterexamples orSourcebug/RAMcause. RetainconfirmedOWNhandlesBEFOREhooks/fullofficialEX-scopedunits/fresh1GiBfloor/boundedSAMEactors-naturalwaits/no partialPopenmethods-retry-reset-replay-fieldderivedsettlement. Cachedc4199a enclosingaudit has5exactidentifierrefs/3nominalsnapshotroutes+3_gitattrs+4higherrefs/12literalbindingtargets0matches; notruntimebinding-allalias-opaque-transitiveactorclosure. _file_snapshot ctorBEFORElocalregistryappend/no Source-knownattemptafterunknownCtor. Auxsnapshotrow returnedNone/raw_returnNone/result_validNone; Endsnapshotrow returnedFalse/rawNone. Auxretain_first beginsfalliblegetsetmetadata, _completecatchcallsagain, potentialFirstmaskingUNPROVED; Endgroupprivateprimary beforemetadata/finallyraise Sourcefacts notsemanticownership. _git directarchivecall noimmediateprivatefirstrecord butexceptionabortslaterevent/body soabsenceguardaloneNOTcontinuationproof; _make_archivelaterlink/hash/ls-tree/higherinitpending-defer-preserve/receiptcustomobserve knownnominalcontexts notfinalruntimecallableauthority. NoSourceeditwithoutmeaningfulNEWactualBEFOREfailingregression; earlierconstructor-registration/metadata-globalbindings-otherfactoryshapes-getterinternals-calleeinterior-statcontents-ABA/historical-transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission remainincomplete. Producer/testUNCHANGEDsincefactoryc4199a/0e4e94, cachedSourceartifactSHAonly/liveSource-HEAD-current20canonicalnotverified; prior49historicalnotreplayed-oraggregated/currentadmission. Qwen85920tokenlimit1/0out611err;GLM86684tokenlimit1/0out978err/BOTH EOF-reaped/fullpartialfinalBOTH_ABSENT-notreconstructed/reachableNOTunavailability-approval/no unchangedreviewrepeat; ROOTindependentSourcequalification NOTmodelwholecurrentapproval. GLMv1input33657>31000 beforeqmkdir-command-inputfiles-Popen/sourcebindings/tailsfileskept; oldcontextUNSERIALIZEDnotreconstructed, freshv2selectedDATA/35000budgetBEFOREfirstGLMcall/notmodelretry-numericSourcefailure. ZEROnewtests-SourceGitprep-HEADrecensus-SDK-nativebuild-kernel-broker-benchmarkcapture-adoption-strictdispatch. Retentionmachinery-processlife rawchunksUNCHANGED/NOTfixedmemory/heapRSS-magnitude-growth-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-reset-evict-deleteauthority. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; fieldfacts DATAneverownership_complete-go_close_confirmed-EXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_snapshot_enclosing_cachedAST_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
