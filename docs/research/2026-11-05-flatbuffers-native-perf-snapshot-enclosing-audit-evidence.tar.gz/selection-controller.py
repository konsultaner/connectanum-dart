import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-enclosing-audit-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();s=(P/'cached-source.py').read_text();tree=ast.parse(s);parents={ch:n for n in ast.walk(tree) for ch in ast.iter_child_nodes(n)}
 def chain(n):
  out=[]
  while n in parents:n=parents[n];out.append(n)
  return out
 def fullname(n):return '.'.join([x.name for x in reversed(chain(n)) if isinstance(x,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))]+[n.name])
 selected=[];names=[]
 wanted={'AuxiliaryCommand._complete','AuxiliaryCommand._finalization_step','AuxiliaryCommand._retain_finalization_error','CommandProducer._git','CommandProducer._end_command','_file_snapshot'}
 for n in ast.walk(tree):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   full=fullname(n)
   if ('finalization' in n.name or 'end_command' in n.name or n.name=='_git'):names.append(dict(symbol=full,line=n.lineno,chars=len(ast.get_source_segment(s,n))))
   if full in wanted:selected.append(dict(symbol=full,line=n.lineno,source=ast.get_source_segment(s,n)))
 refs=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Attribute) and isinstance(n.ctx,ast.Load) and n.attr=='_git':
   stack=chain(n);statement=next(x for x in stack if isinstance(x,ast.stmt));scope=next(x for x in stack if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)))
   refs.append(dict(line=n.lineno,container=fullname(scope),statement=ast.get_source_segment(s,statement)))
 (P/'enclosing-methods-selected.json').open('x').write(json.dumps(selected,indent=2));(P/'git-attribute-references.json').open('x').write(json.dumps(refs,indent=2));(P/'related-symbol-index.json').open('x').write(json.dumps(names,indent=2))
 l.verify_identity();print(json.dumps(dict(selected=[dict(symbol=x['symbol'],line=x['line'],chars=len(x['source'])) for x in selected],git_references=refs,related_names=names),indent=2));print(json.dumps([x for x in selected if x['symbol'] in ('CommandProducer._git','CommandProducer._end_command')],indent=2))
