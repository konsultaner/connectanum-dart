import sys,pathlib,json,hashlib,ast,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-enclosing-audit-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();s=(P/'cached-source.py').read_text();tree=ast.parse(s);parents={ch:n for n in ast.walk(tree) for ch in ast.iter_child_nodes(n)}
 def chain(n):
  out=[]
  while n in parents:n=parents[n];out.append(n)
  return out
 def fullname(n):return '.'.join([x.name for x in reversed(chain(n)) if isinstance(x,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))]+[n.name])
 wanted={'_end_command_group','_end_command_guard','_failure_preservation_guard','AuxiliaryCommand._finalization_error','AuxiliaryCommand._finalization_guard','CommandProducer._source_guard','CommandProducer._make_archive'}
 selected=[dict(symbol=fullname(n),line=n.lineno,source=ast.get_source_segment(s,n)) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and fullname(n) in wanted]
 assert {x['symbol'] for x in selected}==wanted
 (P/'enclosing-guards-selected.json').open('x').write(json.dumps(selected,indent=2))
 refs=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Attribute) and isinstance(n.ctx,ast.Load) and n.attr in ('_source_guard','_make_archive'):
   stack=chain(n);statement=next(x for x in stack if isinstance(x,ast.stmt));scope=next(x for x in stack if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)))
   refs.append(dict(name=n.attr,line=n.lineno,container=fullname(scope),statement=ast.get_source_segment(s,statement)))
 (P/'higher-attribute-references.json').open('x').write(json.dumps(refs,indent=2))
 context="Review <=180words/max3 concrete Sourcefacts/gaps forNEWstaticenclosing audit, NOTpatchapproval. Cachedproducer c4199a/current20UNCANONICAL; no newSourceHEAD/hashcensus/tests/build/workload/nativecapture. All5 Name-loadrefs exact_file_snapshot/_FileSnapshotAttempt/_FILE_SNAPSHOT_ATTEMPTS inTHISmodule: wrapperctor+registry2, Aux._complete lambda1, _git directarchive-revalidation1, _end_command capturesnapshot1. Theseare3 nominal_file_snapshot routes, NOTallruntimealiases/bindings/opaque/transitiveactorclosure. Constructor executes BEFOREregistryappend; unknownactualctor meansSourcehas no returnedattempt/registration andROOTmustnotadopt object. Parent_aux/_end steps mayretainfirstbeforelaterreporting; _git directedgehasno immediateprivatefirst guard, but directexception alone isNOTevidenceofcontinuation/unsafeownership. Inspectexactselectedmethods; trace _source_guard/_make_archivehighernominalrefs only, declareuninspectededges notglobalabsence. Sourceconstructorbaseinit hasguardclosure/fieldassignments, no explicit nativeopen inselectedctor, NOTglobalnoactor proof againstsetter/interpreter/delegate/globalbinding. UnknownPopenCtorPERMANENTrefusal/no partialmethods; Sourcefields/EOF-status-FDclosed-finished NOTownership-EXrelease/immutableadmission. Existingfrozenpredicates/owner_emit_attempted unchanged. Need meaningful NEW actualBEFOREfailingregression beforeSourcechange; thisauditcanjustifyNOedit ifonlyunprovedpolicygap. Do notrecommendreplayoldtests/models/campaign/archive, globalPIDscan/kill/cleanup-reset/pop or field-derivedsettlement. CurrentDarwinSH/filebytes onlyNOToriginalLinux/fullindependentEX/SDK-current20canonical/brokers/RAMrepair/strictacceptance."
 for name in ('declaration.json','nominal-references.json','constructor-guard-selected.json','enclosing-methods-selected.json','enclosing-guards-selected.json','git-attribute-references.json','higher-attribute-references.json'):
  context+='\n'+name+'\n'+(P/name).read_text()
 assert len(context)<=31000,len(context)
 q=P/'qwen-review';q.mkdir();(q/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','ollama','--model','qwen3.8:27b','--num-predict','1400','--max-input-chars','31000','--max-response-chars','12000','--timeout','180','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').write_text(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(q/'start.json').write_text(json.dumps(dict(pid=child.pid)))
 out,err=child.communicate();status=child.wait();inp.close();(q/'stdout.bin').write_bytes(out);(q/'stderr.bin').write_bytes(err);result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);(q/'result.json').write_text(json.dumps(result,indent=2));l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-500:])
