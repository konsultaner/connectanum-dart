import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_FIRST_NEW71_directoryscope_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)






import os,stat,collections,datetime,contextlib,gzip,codecs,types,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-scope-v1';v=json.loads(sys.argv[1]);declaration=v['declaration']
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 free=shutil.disk_usage(B).free;assert free>=1073741824,'pretarget_storage_floor_NOtarget_contentIO'
 save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));save('fresh-storage-POINT-NOTbuild-authority.json',json.dumps({'free_bytes':free,'whole_plaintext_NEW_result_never_materialized':True,'all_existing_raw_evidence_unchanged_no_deletion':True}));bindings=[];outputs=[]

 aux_bindings=[]
 helper=pathlib.Path(declaration['auxiliary_OWNartifact_parser']['path']);ab={'role':'auxiliary_OWNartifact_parser_ONLY','path':str(helper),'range':[0,7283],'expected_sha256':'631f2976b157f1c5d42437f9ca8d1ef8fa3cd99c9535b4bdc7b2aaf3b00b6cae','open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};aux_bindings.append(ab);afd=os.open(helper,os.O_RDONLY|os.O_NOFOLLOW);ab['open_return_fd']=afd;primary=None
 try:
  s=os.fstat(afd);ak=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];ab['before']={k:getattr(s,k) for k in ak};ab['before_atime_ns_POINT_ONLY']=s.st_atime_ns;assert stat.S_ISREG(s.st_mode) and s.st_size==7283;hb=b''
  while len(hb)<7283:
   x=os.read(afd,7283-len(hb));assert x;hb+=x
  t=os.fstat(afd);ab['after']={k:getattr(t,k) for k in ak};ab['after_atime_ns_POINT_ONLY']=t.st_atime_ns;assert ab['before']==ab['after'] and hashlib.sha256(hb).hexdigest()==ab['expected_sha256'];ab.update(bytes=len(hb),sha256=hashlib.sha256(hb).hexdigest())
 except BaseException as e:primary=e;ab['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(afd);ab['close_return_fd']=afd
 except BaseException as e:
  ab['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('auxiliary_OWNartifact_parser-binding-PRIVATE.json',json.dumps(ab,indent=2))
 if primary is not None:raise primary
 bj=types.ModuleType('pr132_NEW71_OWNartifact_metadata_parser');bj.__file__=str(helper);bj.__package__='';sys.modules[bj.__name__]=bj;exec(compile(hb,str(helper),'exec'),bj.__dict__)
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def snap(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns

 owners=[];embedding_bindings=[]
 class NewOutput:
  def __init__(self,path,role):
   owners.append(self);self.fd=None;self.path=path;self.binding={'role':role,'path':str(path),'encoding':'concatenated_gzip_members_one_complete_UTF8_JSON_string','open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(self.binding);self.count=0;self.h=hashlib.sha256();self.compressed_count=0;self.compressed_h=hashlib.sha256();self.members=0;self.characters=0;self.decoder=codecs.getincrementaldecoder('utf-8')('strict');self.fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);self.binding['open_return_fd']=self.fd;self.binding['before'],self.binding['before_atime_ns_POINT_ONLY']=snap(self.fd)
  def emit(self,raw):
   if isinstance(raw,str):raw=raw.encode()
   for start in range(0,len(raw),65536):
    block=raw[start:start+65536];member=gzip.compress(block,mtime=0);sent=0
    while sent<len(member):
     n=os.write(self.fd,member[sent:]);assert n>0;sent+=n
    os.lseek(self.fd,self.compressed_count,os.SEEK_SET);parts=[];count=0
    while count<len(member):
     x=os.read(self.fd,len(member)-count);assert x;parts.append(x);count+=len(x)
    checked=b''.join(parts);assert checked==member and gzip.decompress(checked)==block
    self.compressed_h.update(member);self.compressed_count+=len(member);self.h.update(block);self.count+=len(block);self.members+=1;self.characters+=len(self.decoder.decode(block,final=False))
  def close(self):
   primary=None
   try:
    self.characters+=len(self.decoder.decode(b'',final=True));self.binding['after'],self.binding['after_atime_ns_POINT_ONLY']=snap(self.fd);assert self.binding['after']['st_size']==self.compressed_count
    self.binding.update(bytes=self.compressed_count,sha256=self.compressed_h.hexdigest(),decoded_JSON_bytes=self.count,decoded_JSON_sha256=self.h.hexdigest(),decoded_UTF8_characters=self.characters,gzip_members=self.members,SAMEOUTPUTFD_ALLcompressed_bytes_BYTEWISE_readback=True,EVERY_member_decoded_BYTEWISE_equal_to_original_NEW_JSON_stream_chunk=True,whole_original_NEW_JSON_stream_losslessly_retained=True)
   except BaseException as e:primary=e;self.binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
   try:os.close(self.fd);self.binding['close_return_fd']=self.fd
   except BaseException as e:
    self.binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
   save(self.binding['role']+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(self.binding,indent=2))
   if primary is not None:raise primary

 def extract(source,targetkey):
  role=source['role'];size=source['range'][1];expected=source['sha256'];b={'role':role,'path':source['path'],'range':source['range'],'expected_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(source['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;selected=[];occurrences0=0
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==size;rr=bj.BoundedJSON(lambda n:os.read(fd,n),size)
   for key in rr.object_keys():
    if key==targetkey:
     occurrences0+=1
     if role=='original_new_physical_result':
      for op in rr.array_values():selected.append(op)
     else:
      for row in rr.array_values():selected.append(row['original_separate_parent_child_metadata'])
    else:rr.skip_value()
   rr.finish();b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);b.update(bytes=rr.bytes_read,sha256=rr.digest.hexdigest());assert b['before']==b['after'] and rr.bytes_read==size and rr.digest.hexdigest()==expected and occurrences0==1
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return selected

 entries=extract(declaration['exact_saved_inputs'][0],'ALL446_original_child_relationships_with_NEW_counts')
 assert len(entries)==446 and len(bindings)==1
 typecounts=collections.Counter(row['saved_type_derived_from_original_mode'] for row in entries)
 assert typecounts['regular']==375 and typecounts['directory']==71 and typecounts['symlink']==typecounts['other']==typecounts['unknown']==0
 candidates=[];safe=[]
 for ordinal,row in enumerate(entries):
  if row['saved_type_derived_from_original_mode']!='directory':continue
  mode=row['original_separate_lstat_full_stat_times_PRIVATE']['st_mode'];assert stat.S_ISDIR(mode)
  parent=row['literal_parent_reference_SEPARATE'];child=row['literal_child_name_SEPARATE'];assert isinstance(parent,str) and isinstance(child,str) and child and '/' not in child and '\0' not in child
  literal=parent+'/'+child
  original={'new_directory_ordinal_ZERO_based':len(candidates),'original_record_ordinal_ZERO_based':ordinal,'literal_parent_reference_SEPARATE_UNCHANGED':parent,'literal_child_name_SEPARATE_UNCHANGED':child,'NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child':literal,'construction':'literal TEXT concatenation ONLY; no filesystemjoin-normalize-resolve-follow-pathsplit-basename-extraction-or-SDKquery','ALL_original_separate_parent_child_metadata_PRIVATE':row,'query_permission':None,'alias_identity':None}
  candidates.append(original)
  safe.append({k:original[k] for k in ['new_directory_ordinal_ZERO_based','original_record_ordinal_ZERO_based','literal_parent_reference_SEPARATE_UNCHANGED','literal_child_name_SEPARATE_UNCHANGED','NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child','construction','query_permission','alias_identity']})
  safe[-1].update(source_originalActions_run_id=row['source_originalActions_run_id'],source_originalActions_revision=row['source_originalActions_revision'],parent_query_ordinal_ZERO_based=row['parent_query_ordinal_ZERO_based'],child_entry_ordinal_ZERO_based=row['child_entry_ordinal_ZERO_based'],original_name_bytes_hex=row['original_name_bytes_hex'],original_saved_mode=mode,original_mode_directory=True,readlink_literal_comparison_count_UNPERFORMED=None,readlink_literal_matchlists_UNPERFORMED=None,readlink_literal_nonmatchlists_UNPERFORMED=None,readlink_rawhex_comparison_count_UNPERFORMED=None,readlink_rawhex_matchlists_UNPERFORMED=None,readlink_rawhex_nonmatchlists_UNPERFORMED=None)
 assert len(candidates)==len(safe)==71
 private_scope={'scope_declaration_UNCHANGED':declaration,'ALL71_NEW_lexicaldirectory_TEXT_candidates_PRIVATE':candidates,'ALL446_original_separate_parent_child_metadata_PRIVATE_UNCHANGED':entries,'all71_directories_DEFERRED':True,'NEW_fullreference_CP_comparison_performed':False,'all_admission_flags':False,'ownership':None}
 private_raw=json.dumps(private_scope,ensure_ascii=True,indent=2).encode();save('FIRST-ALL71-exact-PRIVATE-lexical-scope-BEFORE-CPcomparison.json',private_raw)
 safe_scope={'scope':'EXPLICITLY_DERIVED_SOURCE_new71_literal_directory_INPUT_TEXT_noSDKquery_authority_BEFOREcomparison','source_originalActions_run_id':42421987883,'source_originalActions_revision':'15c9dfa154d0985fcf75b7ebc6d2b02808cfbe9b','ALL71_NEW_lexicaldirectory_TEXT_candidates':safe,'all446_records_preserved_private_nativeorder_duplicates':True,'all71_directories_DEFERRED':True,'all_admission_flags':False,'ownership':None}
 safe_raw=json.dumps(safe_scope,ensure_ascii=True,indent=2).encode();save('FIRST-ALL71-explicitly-derived-public-safe-SOURCE-scope-BEFORE-CPcomparison.json',safe_raw)
 scope_descriptor={'both_NEW_scopes_saved_BEFORE_CP_input_contentIO_and_BEFORE_CPcomparison_and_futureSDKINPUTIO':True,'private_exact_scope_bytes':len(private_raw),'private_exact_scope_sha256':hashlib.sha256(private_raw).hexdigest(),'public_safe_SOURCE_scope_bytes':len(safe_raw),'public_safe_SOURCE_scope_sha256':hashlib.sha256(safe_raw).hexdigest(),'original_entry_records':446,'new_directory_candidates':71,'all71_directories_DEFERRED':True,'all_admission_flags':False}
 save('FIRST-scopes-saved-BEFORE-CP-contentIO-and-comparison.json',json.dumps(scope_descriptor,indent=2))
 cp_path=B/'current-task-checkpoint.json';fd=os.open(cp_path,os.O_RDONLY|os.O_NOFOLLOW);cb={'role':'ENTIRE_prior_OWNtaskcheckpoint_ALLstring_SCALARVALUES_NOT_dictionaryKEYstrings','path':str(cp_path),'open_return_fd':fd,'close_return_fd':None,'file_EOF_probe':None};bindings.append(cb);primary=None
 try:
  cb['before'],cb['before_atime_ns_POINT_ONLY']=snap(fd);size=cb['before']['st_size'];cb['range']=[0,size];save('PRIOR_ENTIRE_CP-pointFD-stat-size-range-BEFORE-contentIO.json',json.dumps(cb,indent=2));parts=[];count=0;h=hashlib.sha256()
  while count<size:
   x=os.read(fd,min(65536,size-count));assert x;parts.append(x);h.update(x);count+=len(x)
  cpraw=b''.join(parts);cb['after'],cb['after_atime_ns_POINT_ONLY']=snap(fd);assert cb['before']==cb['after'] and count==size;cb.update(bytes=count,sha256=h.hexdigest());cp=json.loads(cpraw.decode('utf-8'))
 except BaseException as e:primary=e;cb['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(fd);cb['close_return_fd']=fd
 except BaseException as e:
  cb['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('ENTIRE-prior-OWNtaskcheckpoint-INPUTFD-binding-PRIVATE.json',json.dumps(cb,indent=2))
 if primary is not None:raise primary
 cp_copy=P/'ENTIRE-prior-OWNtaskcheckpoint-BYTEEXACT-PRIVATE.json';cfd=os.open(cp_copy,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);sent=0
 while sent<len(cpraw):
  n=os.write(cfd,cpraw[sent:]);assert n>0;sent+=n
 os.lseek(cfd,0,os.SEEK_SET);got=b''
 while len(got)<len(cpraw):
  x=os.read(cfd,min(65536,len(cpraw)-len(got)));assert x;got+=x
 assert got==cpraw;cs=os.fstat(cfd);assert cs.st_size==len(cpraw);os.close(cfd);save('CP-original-SAMEOUTPUTFD-bytewise-copy-readback.json',json.dumps({'bytes':len(cpraw),'sha256':hashlib.sha256(cpraw).hexdigest(),'all_bytes_equal':True,'output_fd':cfd,'known_close_return_fd':cfd,'no_EOFprobe':True}))
 scalars=[]
 def walk(x,path):
  if isinstance(x,str):scalars.append({'ordinal_ZERO_based':len(scalars),'location':path,'original_scalar_value_UNCHANGED':x})
  elif isinstance(x,dict):
   for k,y in x.items():walk(y,path+[k])
  elif isinstance(x,list):
   for i,y in enumerate(x):walk(y,path+[i])
 walk(cp,[])
 def occurrences(hay,needle):
  out=[];start=0
  while True:
   pos=hay.find(needle,start)
   if pos<0:return out
   out.append(pos);start=pos+1
 def complement_runs(matched):
  runs=[];start=None
  for ordinal in range(len(scalars)):
   if ordinal not in matched:
    if start is None:start=ordinal
   elif start is not None:runs.append([start,ordinal]);start=None
  if start is not None:runs.append([start,len(scalars)])
  return runs
 comparisons=[];matched_candidates=0;exact_candidates=0;relations=0;overlaps=0
 for candidate in candidates:
  literal=candidate['NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child'];matches=[];matched=[];exact=False
  for row in scalars:
   value=row['original_scalar_value_UNCHANGED'];positions=occurrences(value,literal)
   if not positions:continue
   matched.append(row['ordinal_ZERO_based']);eq=value==literal;exact=exact or eq;overlaps+=len(positions)
   matches.append({'original_CP_scalar_ordinal_ZERO_based':row['ordinal_ZERO_based'],'original_CP_scalar_location_UNCHANGED':row['location'],'original_CP_scalar_value_UNCHANGED':value,'exact_scalar_equality':eq,'ALL_overlapping_character_offsets_ZERO_based':positions,'ALL_UTF8_surrogatepass_SCALAR_byte_offsets_ZERO_based':[len(value[:p].encode('utf-8','surrogatepass')) for p in positions],'offsets_NOT_JSONwire_or_SDKbytealias':True})
  matched_candidates+=bool(matches);exact_candidates+=exact;relations+=len(matches)
  comparisons.append({'original_NEW_candidate_ALLfields_PRIVATE_UNCHANGED':candidate,'NEW_fullreference_comparison_performed':True,'exact_scalar_equality_any':exact,'substring_comparison_ANYmatch':bool(matches),'matching_scalar_count':len(matches),'matching_scalar_positions_ZERO_based':matched,'ALL_matching_scalar_locations_flags_overlaps_PRIVATE':matches,'nonmatching_scalar_count':len(scalars)-len(matches),'ALL_nonmatching_scalar_positions_EXPLICITLY_DERIVED_ZERO_based_HALFOPEN_ordinal_runs':complement_runs(set(matched)),'nonmatching_runs_over_ALL_original_scalar_array_without_discard':True,'readlink_literal_comparison_performed':False,'readlink_literal_comparison_count_UNPERFORMED':None,'readlink_literal_matchlists_UNPERFORMED':None,'readlink_literal_nonmatchlists_UNPERFORMED':None,'readlink_rawhex_comparison_performed':False,'readlink_rawhex_comparison_count_UNPERFORMED':None,'readlink_rawhex_matchlists_UNPERFORMED':None,'readlink_rawhex_nonmatchlists_UNPERFORMED':None,'alias_identity':None,'query_permission':None})
 summary={'ALL_original_entry_records':446,'original_mode_type_counts':dict(typecounts),'FIRST_NEW_directory_lexical_candidates':71,'ENTIRE_prior_OWN_taskCP_top_level_nodes':len(cp),'prior_CP_actions_top_level_nodes_count_ONLY_NOT_comparison_filter':sum(k.startswith('actions_') for k in cp),'ALL_prior_CP_string_SCALARVALUES':len(scalars),'dictionary_KEY_strings_excluded_ONLY_comparison_corpus':True,'fullreference_candidates_exact_scalar_matched':exact_candidates,'fullreference_candidates_substring_matched':matched_candidates,'fullreference_candidates_substring_nonmatched':71-matched_candidates,'matching_candidate_scalar_relations':relations,'ALL_overlapping_occurrences':overlaps,'saved_metadata_input_bindings':len(bindings),'auxiliary_OWNartifact_parser_bindings':len(aux_bindings),'eligible_saved_link_records_THISdataset':sum(row['saved_type_derived_from_original_mode']=='symlink' for row in entries),'ALL71_readlink_comparison_counts_matchlists_nonmatchlists_UNPERFORMED_NULL':True,'all71_directories_DEFERRED':True,'new_SDK_queries':0,'new_Actions_queries':0,'new_SDK_body_reads':0,'new_directory_queries':0,'new_recursive_directory_queries':0,'candidate_executions':0,'alias_identity':None,'query_permission':None,'all_admission_flags':False,'ownership':None,'outer_launcher_PID_pipeEOF':None}
 resultname='ROOT-FIRST-ALL71-great-great-great-grandchild-directory-scope-PRIVATE.json.gz';out=NewOutput(P/resultname,'FIRST_new71_result');out.emit('{"execution_declaration":');out.emit(json.dumps(declaration,ensure_ascii=True));out.emit(',"FIRST_scopes_saved_BEFORE_CP_contentIO_descriptor":');out.emit(json.dumps(scope_descriptor,ensure_ascii=True));out.emit(',"ALL71_NEW_fullreference_CP_relationships_PRIVATE":');out.emit(json.dumps(comparisons,ensure_ascii=True,separators=(',',':')));out.emit(',"ALL_prior_ENTIRE_OWNtaskcheckpoint_string_SCALARVALUES_PRIVATE":');out.emit(json.dumps(scalars,ensure_ascii=True,separators=(',',':')));out.emit(',"ALL446_original_separate_parent_child_metadata_PRIVATE_UNCHANGED":');out.emit(json.dumps(entries,ensure_ascii=True,separators=(',',':')));out.emit(',"ALL_original_prior_checkpoint_JSON_value_PRIVATE_UNCHANGED":');out.emit(cpraw);out.emit(',"both_NEW_scopes_PRIVATE_all_original_fields_unchanged":');out.emit(private_raw);out.emit(',"NEW_public_safe_SOURCE_scope_all_fields_unchanged":');out.emit(safe_raw);out.emit(',"summary":');out.emit(json.dumps(summary,ensure_ascii=True))
 def embed(source,key):
  path=pathlib.Path(source['path']);size=source['range'][1];b={'role':source['role']+'_FIRST_whole_RAW_JSON_value_embedding','path':str(path),'range':[0,size],'expected_sha256':source['sha256'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};embedding_bindings.append(b);out.emit(','+json.dumps(key)+':');fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==size;count=0;h=hashlib.sha256()
   while count<size:
    raw=os.read(fd,min(65536,size-count));assert raw;out.emit(raw);h.update(raw);count+=len(raw)
   b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);b.update(bytes=count,sha256=h.hexdigest(),ALL_original_raw_JSON_bytes_fields_PRIVATE_unchanged_no_normalization=True);assert b['before']==b['after'] and count==size and h.hexdigest()==source['sha256']
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(source['role']+'-WHOLE-raw-JSON-value-embedding-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary

 embed(declaration['exact_saved_inputs'][0],'ALL_original446_metadata_intake_JSON_value_PRIVATE_UNCHANGED')
 out.emit(',"ALL_new_savedmetadata_input_bindings_PRIVATE":');out.emit(json.dumps(bindings,ensure_ascii=True));out.emit(',"ALL_RAW_JSON_value_embedding_bindings_PRIVATE":');out.emit(json.dumps(embedding_bindings,ensure_ascii=True));out.emit(',"qualification":');out.emit(json.dumps(declaration['scope'],ensure_ascii=True));out.emit('}\n');out.close()
 descriptor={'result_saved':resultname,'result_encoding':'concatenated-gzip-members-of-one-complete-UTF8-JSON-string','result_bytes':out.compressed_count,'result_sha256':out.compressed_h.hexdigest(),'decoded_JSON_bytes':out.count,'decoded_JSON_sha256':out.h.hexdigest(),'decoded_UTF8_characters':out.characters,'gzip_members':out.members,'summary':summary,'scopes_saved_BEFORE_CPcontentIO':scope_descriptor,'raw_JSON_embedding_input_bindings':len(embedding_bindings),'auxiliary_OWNartifact_parser_bindings':len(aux_bindings),'whole_NEW_JSON_stream_losslessly_retained':True};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 CP=B/'current-task-checkpoint.json';before=CP.read_bytes();save('checkpoint-before-intake-result.json',before);d=json.loads(before);d['actions_include_great_great_great_grandchild_directory_scope_v1']={'phase':'COMPLETE_CONSUMED_FIRST_ALL71_directory_lexicalscope_fullreferenceCP_NOT_admitted','directory':str(P),'original_saved_result':str(P/resultname),'original_saved_result_bytes':out.compressed_count,'original_saved_result_sha256':out.compressed_h.hexdigest(),'original_saved_result_encoding':descriptor['result_encoding'],'decoded_JSON_bytes':out.count,'decoded_JSON_sha256':out.h.hexdigest(),'summary':summary,'scope_descriptor':scope_descriptor,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_great_grandchild_directory_scope='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST boundedsummary-publication originalNEW71directorylexicalscope fullreferenceCP result ONLY/no oldsource-body-reader-parser-model-SDKquery-imagehash-Actionsacquisition-archive-numerical/schemaaudit replay/allprivatefields-stat-times-epochs-71currentdirsDEFERRED-older29and199DEFERRED-6and18links-oldncursesrawhexNULL unchanged/allsetupUNADMITTED/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
