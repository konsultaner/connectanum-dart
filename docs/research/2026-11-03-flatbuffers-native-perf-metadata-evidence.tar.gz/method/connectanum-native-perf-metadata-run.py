from pathlib import Path
import sys,subprocess,json,hashlib,shutil,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');phase=sys.argv[1];assert phase.replace('-','').isalnum();base=Path('/tmp/connectanum-native-perf-metadata-'+phase)
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 with local_resource_lease(exclusive=True) as lease:
  lease.verify_identity();assert shutil.disk_usage(root).free>=1024**3
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  assert not subprocess.check_output(['git','diff','HEAD','--','packages','native'],cwd=root)
  snap=Path(str(base)+'-source');snap.mkdir();files=sorted(root.glob('tool/*native_perf*.py'));hashes={}
  for p in files:b=p.read_bytes();(snap/p.name).write_bytes(b);hashes[str(p.relative_to(root))]=sha(b)
  receipt={'started':now(),'head':head,'source_sha256':hashes,'free_bytes':shutil.disk_usage(root).free,'official_exclusive_lease':True,'scope':'synthetic PERFILE2 files and OWN regular filesystem guards only; no Linux/perf/kernel/VM/benchmark/capture','command':[sys.executable,'-B','-m','unittest','discover','-s','tool','-p','test_native_perf_metadata.py','-v']}
  if len(sys.argv)>2:
   assert sys.argv[2].replace('_','').isalnum();receipt['command']+=['-k',sys.argv[2]]
  log=Path(str(base)+'-tests.log')
  with log.open('xb') as f:r=subprocess.run(receipt['command'],cwd=root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','CONNECTANUM_PERF_METADATA_FIXTURES':str(base)+'-fixtures'})
  lease.verify_identity();assert hashes=={str(p.relative_to(root)):sha(p.read_bytes()) for p in files}
  receipt.update(ended=now(),exit=r.returncode,log=str(log),log_sha256=sha(log.read_bytes()))
  with Path(str(base)+'-tests.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
  print(json.dumps({'exit':r.returncode,'log':str(log),'last':log.read_text()[-2500:]}))
except LocalResourceLeaseError as e:
 with Path(str(base)+'-lease-refusal.json').open('x') as f:json.dump({'utc':now(),'error':str(e),'before_snapshot_test':True},f)
 print(str(e));sys.exit(75)
