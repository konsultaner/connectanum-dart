"""Synthetic perf ABI fixtures; never kernel compatibility or capture acceptance."""
import hashlib
import json
import os
from pathlib import Path
import struct
import unittest
from unittest.mock import patch

from native_perf_metadata import MetadataError, PerfMetadataReader

IP, TID, TIME, ADDR, ID, CPU, PERIOD, STREAM, IDENT = 1, 2, 4, 8, 64, 128, 256, 512, 65536
MASK = IP | TID | TIME | ID | CPU | PERIOD | STREAM | IDENT
ROOT = Path(os.environ['CONNECTANUM_PERF_METADATA_FIXTURES']).resolve()


def record(kind, body, misc=0):
    return struct.pack('<IHH', kind, misc, 8 + len(body)) + body


def sid(pid=77, tid=78, time=2**60+1, event_id=41, stream=9001, ident=41):
    return struct.pack('<IIQQQIIQ', pid, tid, time, event_id, stream, 3, 0, ident)


def image(data=b'', mask=MASK, flags=(1 << 18) | 2, attr_bytes=128, features=0, ids=(41,)):
    attr = bytearray(attr_bytes)
    struct.pack_into('<IIQQQQQ', attr, 0, 1, attr_bytes, 0, 999, mask, 0, flags)
    header_size = 104
    stride = attr_bytes + 16
    ids_offset = header_size + stride
    ids_raw = b''.join(struct.pack('<Q', x) for x in ids)
    data_offset = ids_offset + len(ids_raw)
    header = struct.pack('<8sQQQQQQQQ', b'PERFILE2', header_size, stride,
                         header_size, stride, data_offset, len(data), 0, 0)
    return header + features.to_bytes(32, 'little') + bytes(attr) + struct.pack('<QQ', ids_offset, len(ids_raw)) + ids_raw + data


class MetadataTests(unittest.TestCase):
    def setUp(self):
        self.root = ROOT / self._testMethodName
        self.root.mkdir(parents=True)
        self.path = self.root / 'perf.data'

    def put(self, raw):
        self.path.write_bytes(raw)
        self.path.chmod(0o600)
        return self.path

    def decode(self, raw, **kwargs):
        with PerfMetadataReader(self.put(raw), **kwargs) as reader:
            rows = list(reader.records())
            summary = reader.summary()
        return rows, summary

    def test_sample_identifier_first_and_u64_strings(self):
        body = struct.pack('<QQIIQQQIIQ', 41, 2**63+9, 77, 78, 2**60+1, 41, 9001, 3, 0, 1000)
        rows, summary = self.decode(image(record(9, body)))
        self.assertEqual(rows[0]['decoded']['ip'], str(2**63+9))
        self.assertEqual(rows[0]['decoded']['identifier'], '41')
        self.assertEqual(rows[0]['decoded']['stream_id'], '9001')
        self.assertEqual(rows[0]['issues'], [])
        self.assertTrue(summary['raw_data_accounting_complete'])
        self.assertFalse(summary['capture_ready'])
        self.assertEqual(summary['scope'], 'metadata_decode_only')
        json.dumps(rows)

    def test_fork_body_identity_separate_from_trailer(self):
        raw = record(7, struct.pack('<IIIIQ', 88, 77, 89, 78, 12) + sid())
        rows, _ = self.decode(image(raw))
        self.assertEqual(rows[0]['decoded']['pid'], 88)
        self.assertEqual(rows[0]['sample_id']['pid'], 77)
        self.assertEqual(rows[0]['decoded']['time'], '12')
        self.assertEqual(rows[0]['sample_id']['time'], str(2**60+1))
        self.assertEqual(rows[0]['issues'], [])

    def test_comm_invalid_utf8_and_padding_retained(self):
        raw = record(3, struct.pack('<II', 77, 78) + b'bad\xff\0\xa5\x00' + sid(), 1 << 13)
        rows, _ = self.decode(image(raw))
        self.assertEqual(rows[0]['decoded']['comm_bytes_hex'], '626164ff')
        self.assertIsNone(rows[0]['decoded']['comm_utf8'])
        self.assertEqual(rows[0]['decoded']['padding_hex'], 'a500')
        self.assertTrue(rows[0]['decoded']['exec'])
        self.assertEqual(rows[0]['issues'], [])

    def test_mmap2_explicit_buildid_union(self):
        fixed = struct.pack('<IIQQQ', 77, 78, 4096, 8192, 0)
        union = struct.pack('<BBH20s', 3, 0, 0, b'abc' + bytes(17))
        rows, _ = self.decode(image(record(10, fixed + union + struct.pack('<II', 5, 2) + b'/x\0' + sid(), 1 << 14)))
        self.assertEqual(rows[0]['decoded']['build_id_hex'], '616263')
        self.assertNotIn('inode', rows[0]['decoded'])
        self.assertEqual(rows[0]['issues'], [])

    def test_mmap2_inode_union_without_flag(self):
        fixed = struct.pack('<IIQQQIIQQII', 77, 78, 4096, 4096, 0, 8, 1, 2**63+1, 0, 5, 2)
        rows, _ = self.decode(image(record(10, fixed + b'/x\0' + sid())))
        self.assertEqual(rows[0]['decoded']['inode'], str(2**63+1))
        self.assertNotIn('build_id_hex', rows[0]['decoded'])

    def test_lost_unknown_and_nonmonotonic_order(self):
        raws = [record(2, struct.pack('<QQ', 41, 8) + sid(time=9)),
                record(0xf123, b'opaque'), record(13, struct.pack('<Q', 2) + sid(time=1))]
        rows, summary = self.decode(image(b''.join(raws)))
        self.assertEqual([r['type'] for r in rows], [2, 0xf123, 13])
        self.assertEqual(rows[0]['decoded']['lost'], '8')
        self.assertEqual(rows[2]['decoded']['lost'], '2')
        self.assertIn('unknown_record_type', rows[1]['issues'])
        self.assertEqual(summary['data_accounted_bytes'], sum(map(len, raws)))
        offset = summary['data_section']['offset']
        for row, raw in zip(rows, raws):
            self.assertEqual(row['raw'], {'offset': offset, 'length': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
            offset += len(raw)

    def test_unsupported_sample_mask_keeps_opaque(self):
        rows, summary = self.decode(image(record(9, b'arbitrary'), mask=MASK|16))
        self.assertIsNone(rows[0]['decoded'])
        self.assertFalse(summary['layout_supported'])
        self.assertEqual(rows[0]['raw']['length'], 17)

    def test_missing_sample_id_all_retains_records(self):
        rows, summary = self.decode(image(record(3, b'12345678'), flags=2))
        self.assertFalse(summary['layout_supported'])
        self.assertIsNone(rows[0]['decoded'])

    def test_compression_never_guesses_framing(self):
        rows, summary = self.decode(image(b'compressed garbage', features=1 << 27))
        self.assertFalse(summary['layout_supported'])
        self.assertIsNone(rows[0]['type'])
        self.assertIn('compressed_data_unsupported', rows[0]['issues'])
        self.assertTrue(summary['raw_data_accounting_complete'])

    def test_truncated_header_and_body_retained(self):
        for name, raw in [('header', b'abcd'), ('body', struct.pack('<IHH', 9, 0, 40) + b'x')]:
            p = self.root / (name + '.data'); p.write_bytes(image(raw)); p.chmod(0o600)
            with PerfMetadataReader(p) as r:
                rows = list(r.records()); summary = r.summary()
            self.assertEqual(rows[0]['raw']['length'], len(raw))
            self.assertTrue(any('truncated' in v for v in rows[0]['issues']))
            self.assertTrue(summary['raw_data_accounting_complete'])

    def test_declared_data_tail_beyond_eof_not_invented(self):
        raw = bytearray(image(b'abc')); struct.pack_into('<Q', raw, 48, 100)
        rows, summary = self.decode(bytes(raw))
        self.assertEqual(summary['missing_data_bytes'], 97)
        self.assertEqual(sum(r['raw']['length'] for r in rows), 3)
        self.assertFalse(summary['declared_data_complete'])

    def test_zero_record_size_retains_remainder_once(self):
        raw = struct.pack('<IHH', 9, 0, 0) + b'remainder'
        rows, _ = self.decode(image(raw))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['raw']['length'], len(raw))
        self.assertIn('invalid_record_size', rows[0]['issues'])

    def test_record_budget_retains_unframed_tail(self):
        raw = record(99, b'x') * 3
        rows, summary = self.decode(image(raw), max_records=1)
        self.assertEqual(len(rows), 2)
        self.assertIsNone(rows[1]['type'])
        self.assertEqual(rows[1]['raw']['length'], 18)
        self.assertTrue(summary['raw_data_accounting_complete'])
        self.assertFalse(summary['record_framing_complete'])

    def test_invalid_sections_and_stride_refused(self):
        for name, offset, value in [('stride',16,81),('overlap',40,104),('idsalign',240,7)]:
            raw = bytearray(image()); struct.pack_into('<Q',raw,offset,value)
            p=self.root/(name+'.data');p.write_bytes(raw);p.chmod(0o600)
            with self.assertRaises(MetadataError):
                with PerfMetadataReader(p): pass

    def test_bad_magic_and_attr_size_refused(self):
        for name, offset, value in [('magic',0,b'notperf!'),('attr',108,struct.pack('<I',65))]:
            raw=bytearray(image());raw[offset:offset+len(value)]=value
            p=self.root/(name+'.data');p.write_bytes(raw);p.chmod(0o600)
            with self.assertRaises(MetadataError):
                with PerfMetadataReader(p):pass

    def test_fd_identity_and_fullhash_stability(self):
        self.put(image(record(99,b'abcd')))
        with PerfMetadataReader(self.path) as r:
            rows=list(r.records())
            with self.path.open('r+b') as f:f.seek(-1,2);f.write(b'z')
            with self.assertRaises(MetadataError):r.summary()
        self.assertEqual(len(rows),1)

    def test_partial_consumption_cannot_claim_summary(self):
        self.put(image(record(99,b'x')*2))
        with PerfMetadataReader(self.path) as r:
            it=r.records();next(it)
            with self.assertRaises(MetadataError):r.summary()
            it.close()
            with self.assertRaises(MetadataError):list(r.records())

    def test_nonregular_symlink_and_writable_mode_refused(self):
        self.put(image()); link=self.root/'link';link.symlink_to(self.path)
        fifo=self.root/'fifo';os.mkfifo(fifo,0o600)
        for p in [link,fifo]:
            with self.assertRaises(MetadataError):
                with PerfMetadataReader(p):pass
        self.path.chmod(0o666)
        with self.assertRaises(MetadataError):
            with PerfMetadataReader(self.path):pass

    def test_short_pread_chunks_accumulated(self):
        real=os.pread
        with patch('native_perf_metadata.os.pread',side_effect=lambda fd,n,pos:real(fd,min(n,3),pos)):
            rows,summary=self.decode(image(record(99,b'abcd')))
        self.assertEqual(rows[0]['raw']['length'],12)
        self.assertTrue(summary['raw_data_accounting_complete'])

    def test_identifier_mismatch_and_no_nul_kept(self):
        raw=record(3,struct.pack('<II',77,78)+b'nonul'+sid(ident=42))
        rows,_=self.decode(image(raw))
        self.assertIn('identifier_id_mismatch',rows[0]['issues'])
        self.assertIn('missing_name_nul',rows[0]['issues'])
        self.assertEqual(rows[0]['raw']['length'],len(raw))

    def test_multiple_attrs_never_select_favorable_layout(self):
        first=bytearray(image())
        attr=first[104:248]; ids=struct.pack('<Q',41)
        data=record(99,b'x')
        h=struct.pack('<8sQQQQQQQQ',b'PERFILE2',104,144,104,288,408,len(data),0,0)+bytes(32)
        a=bytearray(attr);struct.pack_into('<QQ',a,128,392,8)
        b=bytearray(attr);struct.pack_into('<QQ',b,128,400,8)
        rows,summary=self.decode(h+bytes(a)+bytes(b)+ids+ids+data)
        self.assertFalse(summary['layout_supported'])
        self.assertIsNone(rows[0]['decoded'])

    def test_close_failure_relinquishes_numeric_ownership(self):
        self.put(image())
        r=PerfMetadataReader(self.path);r.__enter__();fd=r._fd;real=os.close
        def uncertain(n):real(n);raise OSError(5,'synthetic close ambiguity')
        with patch('native_perf_metadata.os.close',side_effect=uncertain) as closer:
            with self.assertRaises(OSError):r.close()
            r.close()
            self.assertEqual(closer.call_count,1)
        with self.assertRaises(OSError):os.fstat(fd)


if __name__=='__main__':unittest.main()
