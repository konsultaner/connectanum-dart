"""Bounded read-only PERFILE2 metadata framing, not live provenance or admission.

ABI facts checked against Linux v6.8 UAPI perf_event.h and perf util/header.*.
Every data byte is referenced in original order, including undecodable tails.
The caller retains the original file; these hashes do not recreate its bytes.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import stat
import struct


class MetadataError(ValueError):
    """Unsupported structure or a failed bounded file observation."""


_ATTR_SIZES = {64, 72, 80, 96, 104, 112, 120, 128, 136}
_FLAT_MASK = 1 | 2 | 4 | 8 | 64 | 128 | 256 | 512 | 65536
_TYPES = {1: 'MMAP', 2: 'LOST', 3: 'COMM', 4: 'EXIT', 7: 'FORK',
          9: 'SAMPLE', 10: 'MMAP2', 13: 'LOST_SAMPLES'}
_CHUNK = 1024 * 1024


def _identity(st):
    return (st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_gid,
            st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def _uint(value, label, maximum):
    if type(value) is not int or not 1 <= value <= maximum:
        raise MetadataError('invalid ' + label)
    return value


class PerfMetadataReader:
    """One-shot stream of raw references and selected metadata fields.

    Structural header/section failures refuse entry. Per-record malformed,
    unknown, unsupported and partial bytes remain in the yielded raw references.
    summary() requires exhaustion and a second full hash/stat observation.
    """

    def __init__(self, path, *, max_file_bytes=1024**3, max_records=5_000_000):
        self.path = Path(path)
        self.max_file_bytes = _uint(max_file_bytes, 'file bound', 2**40)
        self.max_records = _uint(max_records, 'record bound', 50_000_000)
        self._fd = None
        self._entered = self._started = self._complete = False
        self._framed = True
        self._count = self._accounted = 0
        self._issues = []

    def __enter__(self):
        if self._entered:
            raise MetadataError('reader cannot be reopened')
        self._entered = True
        try:
            if not self.path.is_absolute() or self.path != self.path.resolve(strict=True):
                raise MetadataError('file path must be absolute and canonical')
            before = self.path.lstat()
            if (not stat.S_ISREG(before.st_mode) or before.st_mode & 0o6022
                    or before.st_uid not in {0, os.getuid()}
                    or not 104 <= before.st_size <= self.max_file_bytes):
                raise MetadataError('unsafe type, ownership, mode or file size')
            self._fd = os.open(self.path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
            opened = os.fstat(self._fd)
            self._initial = _identity(opened)
            if self._initial != _identity(before):
                raise MetadataError('path changed during open')
            self._size = opened.st_size
            self._sha = self._hash_range(0, self._size)
            self._header()
            self._stable()
            return self
        except BaseException as primary:
            try:
                self.close()
            except BaseException as secondary:
                primary.add_note('metadata close failed: ' + repr(secondary))
            raise

    def __exit__(self, exc_type, exc, tb):
        try:
            self.close()
        except BaseException as secondary:
            if exc is None:
                raise
            exc.add_note('metadata close failed: ' + repr(secondary))
        return False

    def close(self):
        fd, self._fd = self._fd, None
        if fd is not None:
            os.close(fd)

    def _read_at(self, offset, length):
        if self._fd is None or offset < 0 or length < 0 or offset + length > self._size:
            raise MetadataError('read outside retained file')
        result = bytearray()
        while len(result) < length:
            chunk = os.pread(self._fd, min(_CHUNK, length-len(result)), offset+len(result))
            if not chunk:
                raise MetadataError('unexpected EOF during file observation')
            result.extend(chunk)
        return bytes(result)

    def _hash_range(self, offset, length):
        digest = hashlib.sha256()
        for pos in range(offset, offset+length, _CHUNK):
            digest.update(self._read_at(pos, min(_CHUNK, offset+length-pos)))
        return digest.hexdigest()

    def _raw(self, offset, length):
        return {'offset': offset, 'length': length, 'sha256': self._hash_range(offset, length)}

    def _stable(self):
        if self._fd is None:
            raise MetadataError('reader is closed')
        if (_identity(os.fstat(self._fd)) != self._initial
                or _identity(self.path.lstat()) != self._initial):
            raise MetadataError('source identity changed')

    def _header(self):
        raw = self._read_at(0, 104)
        magic, header_size, stride, ao, az, do, dz, eo, ez = struct.unpack_from('<8sQQQQQQQQ', raw)
        if magic != b'PERFILE2':
            raise MetadataError('only little-endian regular PERFILE2 is supported')
        if not 104 <= header_size <= self._size or stride-16 not in _ATTR_SIZES:
            raise MetadataError('unsupported header or attribute stride')
        if not az or az % stride or az // stride > 64:
            raise MetadataError('invalid attribute count/section stride')
        self.features = int.from_bytes(raw[72:104], 'little')
        self.data_offset, self.data_size = do, dz
        if do > self._size:
            raise MetadataError('data section starts beyond retained file')
        self._available = min(dz, self._size-do)
        sections = [(0, header_size, 'header')]

        def section(offset, size, label, truncated=False):
            if not size:
                return
            if offset < header_size or (not truncated and offset+size > self._size):
                raise MetadataError('out-of-bounds ' + label)
            for other, count, name in sections:
                if offset < other+count and other < offset+size:
                    raise MetadataError('overlapping sections: ' + name + '/' + label)
            sections.append((offset, size, label))

        section(ao, az, 'attributes')
        section(do, dz, 'data', truncated=True)
        section(eo, ez, 'event_types')
        self.attributes = []
        for index in range(az // stride):
            offset = ao+index*stride
            attr = self._read_at(offset, stride)
            kind, size, config, period, mask, read_format, flags = struct.unpack_from('<IIQQQQQ', attr)
            if size != stride-16:
                raise MetadataError('attribute size/stride mismatch')
            ids_offset, ids_size = struct.unpack_from('<QQ', attr, stride-16)
            if ids_size % 8 or ids_size // 8 > 8192:
                raise MetadataError('invalid bounded attribute ID section')
            section(ids_offset, ids_size, 'attribute_ids_' + str(index))
            ids = struct.unpack('<' + 'Q'*(ids_size//8), self._read_at(ids_offset, ids_size)) if ids_size else ()
            self.attributes.append({'type': kind, 'size': size, 'config': str(config),
                'sample_period_or_freq': str(period), 'sample_type': str(mask),
                'read_format': str(read_format), 'flags': str(flags),
                'ids': [str(v) for v in ids], 'raw': self._raw(offset, stride)})
        self._layout = False
        self._compressed = bool(self.features & (1 << 27))
        if len(self.attributes) != 1:
            self._issues.append('multiple_attributes_unsupported')
        else:
            a = self.attributes[0]
            self._mask = int(a['sample_type'])
            flags = int(a['flags'])
            if a['type'] != 1 or a['config'] != '0':
                self._issues.append('not_software_cpu_clock')
            if self._mask & ~_FLAT_MASK:
                self._issues.append('nonflat_sample_layout_unsupported')
            if self._mask & 7 != 7:
                self._issues.append('missing_ip_tid_time')
            if not flags & (1 << 18):
                self._issues.append('missing_sample_id_all')
            self._layout = not self._issues
        if self._compressed:
            self._issues.append('compressed_data_unsupported')
            self._layout = False
        self._sections = sections

    def _sample_fields(self, raw, *, trailer):
        fields, offset = {}, 0
        order = [(65536, 'identifier', 'Q'), (1, 'ip', 'Q'), (2, 'tid_pair', 'II'),
                 (4, 'time', 'Q'), (8, 'addr', 'Q'), (64, 'id', 'Q'),
                 (512, 'stream_id', 'Q'), (128, 'cpu_pair', 'II'), (256, 'period', 'Q')]
        if trailer:
            order = [order[i] for i in (2, 3, 5, 6, 7, 0)]
        for bit, name, fmt in order:
            if not self._mask & bit:
                continue
            size = struct.calcsize('<'+fmt)
            if offset+size > len(raw):
                raise MetadataError('short sample fields')
            values = struct.unpack_from('<'+fmt, raw, offset)
            offset += size
            if name == 'tid_pair':
                fields.update(pid=values[0], tid=values[1])
            elif name == 'cpu_pair':
                fields.update(cpu=values[0], cpu_reserved=values[1])
            else:
                fields[name] = str(values[0])
        if offset != len(raw):
            raise MetadataError('extra sample field bytes')
        return fields

    def _id_issues(self, fields, issues):
        if 'id' in fields and 'identifier' in fields and fields['id'] != fields['identifier']:
            issues.append('identifier_id_mismatch')
        for key in ('id', 'identifier'):
            if key in fields and fields[key] not in self.attributes[0]['ids']:
                issues.append('unknown_attribute_' + key)
        # STREAM_ID may identify an inherited event; it need not equal its parent ID.

    @staticmethod
    def _name(raw, label):
        if b'\0' not in raw:
            raise MetadataError('missing_name_nul')
        name, padding = raw.split(b'\0', 1)
        try:
            text = name.decode('utf-8', errors='strict')
        except UnicodeDecodeError:
            text = None
        return {label+'_bytes_hex': name.hex(), label+'_utf8': text, 'padding_hex': padding.hex()}

    def _decode(self, kind, misc, body, issues):
        if kind not in _TYPES:
            issues.append('unknown_record_type')
            return None, None
        if not self._layout:
            issues.append('unsupported_attribute_layout')
            return None, None
        if kind == 9:
            fields = self._sample_fields(body, trailer=False)
            self._id_issues(fields, issues)
            return fields, None
        footer_size = sum(8 for bit in (2, 4, 64, 512, 128, 65536) if self._mask & bit)
        if len(body) < footer_size:
            raise MetadataError('short_sample_id_trailer')
        payload = body[:-footer_size] if footer_size else body
        sample_id = self._sample_fields(body[-footer_size:] if footer_size else b'', trailer=True)
        self._id_issues(sample_id, issues)
        if kind in (4, 7):
            if len(payload) != 24:
                raise MetadataError('bad_fork_exit_size')
            pid, ppid, tid, ptid, time = struct.unpack('<IIIIQ', payload)
            fields = {'pid': pid, 'ppid': ppid, 'tid': tid, 'ptid': ptid, 'time': str(time)}
        elif kind in (2, 13):
            if len(payload) != (16 if kind == 2 else 8):
                raise MetadataError('bad_lost_size')
            values = struct.unpack('<QQ' if kind == 2 else '<Q', payload)
            fields = {'lost': str(values[-1])}
            if kind == 2:
                fields['id'] = str(values[0])
            if values[-1]:
                issues.append('lost_samples')
        elif kind == 3:
            if len(payload) < 9:
                raise MetadataError('short_comm')
            pid, tid = struct.unpack_from('<II', payload)
            fields = {'pid': pid, 'tid': tid, 'exec': bool(misc & (1 << 13)), **self._name(payload[8:], 'comm')}
        else:
            fixed_size = 64 if kind == 10 else 32
            if len(payload) <= fixed_size:
                raise MetadataError('short_mmap')
            pid, tid, addr, length, pgoff = struct.unpack_from('<IIQQQ', payload)
            fields = {'pid': pid, 'tid': tid, 'addr': str(addr), 'length': str(length), 'pgoff': str(pgoff)}
            if not length or addr+length > 2**64:
                issues.append('invalid_mmap_range')
            if kind == 10:
                if misc & (1 << 14):
                    length_id, reserved1, reserved2, build_id = struct.unpack_from('<BBH20s', payload, 32)
                    fields.update(build_id_size=length_id, build_id_union_hex=payload[32:56].hex(),
                                  build_id_hex=build_id[:length_id].hex())
                    if length_id > 20 or reserved1 or reserved2:
                        issues.append('invalid_build_id_union')
                else:
                    major, minor, inode, generation = struct.unpack_from('<IIQQ', payload, 32)
                    fields.update(device_major=major, device_minor=minor, inode=str(inode), inode_generation=str(generation))
                prot, flags = struct.unpack_from('<II', payload, 56)
                fields.update(prot=prot, flags=flags)
            fields.update(self._name(payload[fixed_size:], 'filename'))
        return fields, sample_id

    def records(self):
        if self._started or self._fd is None:
            raise MetadataError('record stream is one-shot and requires an open reader')
        self._started = True
        pos, end = self.data_offset, self.data_offset+self._available
        while pos < end:
            issue = None
            if self._compressed:
                issue = 'compressed_data_unsupported'
            elif self._count >= self.max_records:
                issue = 'record_budget_remainder'
            elif end-pos < 8:
                issue = 'truncated_record_header'
            if issue:
                self._framed = False
                raw = self._raw(pos, end-pos)
                self._accounted += raw['length']
                yield {'type': None, 'name': None, 'misc': None, 'decoded': None,
                       'sample_id': None, 'issues': [issue], 'raw': raw}
                pos = end
                break
            kind, misc, size = struct.unpack('<IHH', self._read_at(pos, 8))
            issues = []
            if size < 8 or size > end-pos:
                issues.append('invalid_record_size' if size < 8 else 'truncated_record_body')
                size = end-pos
                self._framed = False
                fields, sample_id = None, None
            else:
                try:
                    fields, sample_id = self._decode(kind, misc, self._read_at(pos+8, size-8), issues)
                except MetadataError as exc:
                    fields, sample_id = None, None
                    issues.append(str(exc))
            raw = self._raw(pos, size)
            self._count += 1
            self._accounted += size
            yield {'type': kind, 'name': _TYPES.get(kind), 'misc': misc,
                   'cpu_mode': misc & 7, 'decoded': fields, 'sample_id': sample_id,
                   'issues': issues, 'raw': raw}
            pos += size
        self._stable()
        self._complete = True

    def summary(self):
        if not self._complete:
            raise MetadataError('summary requires exhausted record stream')
        self._stable()
        if self._hash_range(0, self._size) != self._sha:
            raise MetadataError('retained file bytes changed')
        self._stable()
        return {'scope': 'metadata_decode_only', 'capture_ready': False,
                'source': {'path': str(self.path), 'size': self._size, 'sha256': self._sha},
                'data_section': {'offset': self.data_offset, 'declared_length': self.data_size,
                                 'available_length': self._available},
                'attributes': self.attributes, 'feature_bitmap': str(self.features),
                'layout_supported': self._layout, 'format_issues': list(self._issues),
                'record_count': self._count, 'record_framing_complete': self._framed,
                'data_accounted_bytes': self._accounted,
                'raw_data_accounting_complete': self._accounted == self._available,
                'missing_data_bytes': self.data_size-self._available,
                'declared_data_complete': self.data_size == self._available,
                'limitations': ['synthetic-tested format only; actual kernel/tool compatibility unproved',
                    'metadata identity and paths do not prove role instance or loaded image bytes',
                    'no time sorting, sample selection, symbol attribution, admission or acceptance']}
