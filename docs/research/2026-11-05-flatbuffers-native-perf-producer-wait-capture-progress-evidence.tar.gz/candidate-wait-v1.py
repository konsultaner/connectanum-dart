def wait(self,timeout):
        _wait_entry_guard(self)
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        private_first=[None]
        record={'owner':self,'process':None,'log':None,'events':None,
                'command_records':None,'command_record':None,'command_attempt':None,
                'reader_fd':None,'output_buffer':None,'records':None,'output_log':None,
                'primary_error':None,'steps':[],'completed':False}

        def guard():
            if private_first[0] is not None:raise private_first[0]

        def refuse(error,row):
            if private_first[0] is None:private_first[0]=error
            primary=private_first[0] # Private refusal BEFORE secondary metadata.
            try:
                record['primary_error']=primary
                row['error']=error
            finally:
                raise primary

        def step(stage,callback):
            guard()
            row={'stage':stage,'returned':False,'raw':None,'error':None}
            record['steps'].append(row) # Intent BEFORE lookup/call.
            try:
                raw=callback()
                row['raw']=raw;row['returned']=True
                return raw,row
            except BaseException as error:
                refuse(error,row)

        def context(row):
            guard()
            try:
                if (self.process is not original_process or self.log is not original_log
                    or self.events is not original_events or self.records is not original_records
                    or original_records[-1] is not original_command or self._command_attempt is not original_attempt
                    or self.output_fd is not original_reader or self.output_buffer is not original_buffer
                    or self.output_log is not original_output_log):
                    raise ProducerError('wait entry context changed')
            except BaseException as error:
                refuse(error,row)

        _WAIT_ENTRIES[id(self)]=(self,guard,refuse)
        _WAIT_ENTRY_RECORDS.append(record) # Strong owner/first BEFORE context getters.

        def capture(stage,field,callback):
            raw,_=step(stage,callback)
            record[field]=raw
            return raw

        original_process=capture('capture_process','process',lambda:self.process)
        original_log=capture('capture_log','log',lambda:self.log)
        original_events=capture('capture_events','events',lambda:self.events)
        command_records=capture('capture_records','command_records',lambda:self.records)
        original_command=capture('capture_command_record','command_record',lambda:command_records[-1])
        original_attempt=capture('capture_command_attempt','command_attempt',lambda:self._command_attempt)
        original_reader=capture('capture_reader_fd','reader_fd',lambda:self.output_fd)
        original_buffer=capture('capture_output_buffer','output_buffer',lambda:self.output_buffer)
        original_records=capture('capture_records_again','records',lambda:self.records)
        original_output_log=capture('capture_output_log','output_log',lambda:self.output_log)
        lease,row=step('lease_lookup',lambda:self.lease_check)
        context(row)
        _,row=step('lease_call',lease) # Legacy callback return, including None/False, is ignored.
        context(row)
        clock,row=step('deadline_clock',lambda:time.monotonic())
        context(row)
        if type(clock) is not float or not -float('inf')<clock<float('inf'):
            refuse(ProducerError('invalid native wait deadline clock'),row)
        deadline=clock+timeout
        record['completed']=True # Entry setup only; not wait/actor completion or lease release.
        try:
            while True:
                if not self._drain_output(deadline):return None
                try:status=self._wait_command_natural(max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._version_guard();self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:
                    self._command_history_error(self._command_attempt,'postcommand_guards',e)
                    return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            _end_command_guard(self)
            _finish_publication_guard(self)
            self._command_history_error(self._command_attempt,'command_wait_body',e)
            if self.pending:
                self._defer_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise