import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-wait-capture-progress-v2');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-wait-capture-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='11a5a9ff4447e5ffa484da959d745368852d7044'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Retain wait-entry attempts before context getters\n\nThe wait-entry record was registered after its context attributes were read. Three controlled native attribute returns followed by a ROOT error therefore escaped before a record or permanent first-error guard existed. The helper now registers the owner and guard first, then records each attempted capture and raw return. Unknown process, journal or command-attempt returns remain unknown despite ROOT knowing the native objects. The original getter order and counts, including both records lookups, and the inner wait body are preserved.\n\nNEW4 privatev1 before986f7d/d9baa1 yields3FAIL/1normalPASS/0ERROR: stronger first-retention/witness policies, not three spontaneous kernel bugs or a RAM cause. Finalae71b6/0226dc passes23selected=4matchingNEW+19affected(4context5entry10actualwaitcallers). Two existing metadata stage-prefix assertions change; behavior assertions remain exact, and reversing those edits plus the append restores all previous test bytes. Privatev2 adds normal capture-reference/ten-stage assertions after model review and the original BEFORE controls, before edit/first AFTER; no completed BEFORE control is replayed. Eight new views plus9affected views/8BEFORE46AFTER DarwinEX observations and original-bound ROOT waits are UNIT facts, not full independent EX/originalLinuxcredentials/allactorclosure. Qwen60265 and GLM60963 complete0/fullanswers/reaped, ROOTqualified; corrections and limits are in the assessment.\n\nA preparation script failed before the new declaration/tests/models/source edit after its Source census and first checkpoint write. That namespace remains terminal and protected. A fresh namespace used retained snapshots without repeating the Source census. Source remains uncommitted, uncanonical and unadmitted; runtime admission, RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-wait-capture-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: retain producer wait attempts before context capture'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_wait_capture_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Earlierfinished-validation/bare-recordallocation-registration-secondarymetadata/globalbindings-capture-timegetterinternals-contents-shapes-concurrentABA; otherglob-end/enclosing-publicunknownCtor; writer-hash-init-nativeFD seams; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Currentae71b6/0226dc ONLYearlywaitcapture/barestrongowner-privatefirst-recordregisteredBEFOREgetters/10captureintentraw. Unknownnativeprocess-events-commandattempt SourceNone/rawNone-returnedFalse neverROOTknownPopen-FileIO-dict adopted; priorcompletedcapturesretained/nofieldderivedsettlement/partialPopenmethods. Sourcefirstpreserved/pureguardonly/no Sourcelease-clock-drain-read-select-wait-preserve-repr-note-close/retry-replay-restore afterunknown. NEW4privatev1before986f7d/d9baa1=3FAIL1normalPASS0ERROR/3first-retention-witnesspolicies NOT3nativekernelbugs-RAMcause; final23PASS=4NEW19affected(4context5entry10actualwaitcallers)/no old4-5BEFORE/model-numericalreplay-aggregate-current20canonical-admission. Originalgetterorder/counts inclbothrecordslookups/innerwaitbody/allothermethodshelpersfactoriesfrozenpredicates exact. OldtestPREFIXNOTexact/reverse2affectedmetadataassertions+append wholeoldtestBYTEexact/behaviorassertionsexact. Privatev2normalallrefs/10stageoracle AFTERmodels-v1BEFORE BEFOREedit-firstAFTER/no oldcontrolreplay/modelv1privatev1/ROOTwholefinalv2qualified.8new+9affectedviews/EX8before46after/4+4newRootsameoriginalboundwait10zeroCached/9affectedseparate0/knownFDpathdevino cleanupAFTERevidence UNITnotSourcecleanup-liveownership-fullEX-originalLinux/allFD-delegate-descendantclosure. Qwen60265=0/2070out486err-GLM60963=0/5658out1037err/fullanswers-reaped-ROOTqualified/rejectno-registry-guardinloop-proxyPIDadoption/guardrepralreadyasserted/contextlastcommandalreadychecks/metadata-priorityrethrow/registry-pop-leakcause/patchunwind-closedobject=>liveFD. Preparationv1 badsectionmarker(-1)/printNonecalled TypeError AFTERSourcecensus-oldorientation-firstcheckpoint BEFOREnewdeclaration-tests-models-Sourceedit; oldnamespaceTERMINAL/newv2readonlysnapshots/no Sourcecensusrepeat/rawlimitsno reconstruction.23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. Strongrefs-groups-rows-closures-tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_wait_capture_selected23PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
