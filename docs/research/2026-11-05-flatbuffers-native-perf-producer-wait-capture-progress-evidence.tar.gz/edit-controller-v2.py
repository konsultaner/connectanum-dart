import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-wait-capture-progress-v2");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in oldh.items())
 projection=json.loads((P/'candidate-ROOT-projection.json').read_text());assert projection['wholeSource_BYTE_projectsback'] and projection['whole_existing_tests_BYTE_projectsback']
 source=(P/'candidate-producer-v1.py').read_bytes();updated=(P/'affected-tests-updated-v1.py').read_bytes();private=(P/'wait_capture_regressions-v2.py').read_bytes();tests=updated+b'\n\n'+private;ast.parse(source);ast.parse(tests)
 reverse=updated.decode()
 for change in reversed(json.loads((P/'affected-test-metadata-changes.json').read_text())):reverse=reverse.replace(change['after'],change['before'],1)
 assert reverse==(P/'before-tests.py').read_text()
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(tests)
 h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').open('xb').write(source);(P/'after-tests.py').open('xb').write(tests);(P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2))
 value=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],wholeSource_BYTE_projectsback=True,inner_wait_body_AST_exact=True,originalgetter_order_counts_preserved=True,whole_existing_tests_BYTE_projectsback=True,oldtests_PREFIX_exact=False,only_two_affected_metadata_assertions_changed=True,behaviorassertions_exact=True,other18helpers3bins_unchanged=True,only_wait_capture_Sourcechanged=True,no_historical_artifact_rewrite=True,no_ownership_fullEX_admission_authority=True)
 (P/'edit-result.json').open('x').write(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());n=state['native_perf_only_diagnostic_design'];n['producer_wait_capture_progress'].update(Source_UNCHANGED=False,edit=value,model_pending=False,after_pending=True);n['current_source_sha256']=h;state['active_turn_status']='Producer_wait_capture_NEW4_before3FAIL1PASS_Sourceedited_AFTERpending';cp.write_text(json.dumps(state,indent=2)+'\n')
 l.verify_identity();print(json.dumps(value))
