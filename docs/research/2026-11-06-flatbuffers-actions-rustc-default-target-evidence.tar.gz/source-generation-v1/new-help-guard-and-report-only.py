try:
    help_raw = query("rustc-help", ["rustc", "--help"])
    try:
        help_text = help_raw.decode("utf-8")
        help_decode_error = None
    except UnicodeDecodeError as error:
        help_text = None
        help_decode_error = str(error)
    paragraphs = []
    if help_text is not None:
        lines = help_text.splitlines()
        starts = [i for i, line in enumerate(lines) if re.match(r"^\s*--print(?:\s|=|$)", line)]
        for start in starts:
            paragraph = [lines[start]]
            for line in lines[start + 1:]:
                if not line.strip() or re.match(r"^\s*(?:--[A-Za-z]|-[A-Za-z](?:\s|,|$))", line):
                    break
                paragraph.append(line)
            paragraphs.append("\n".join(paragraph))
    observed_print_section = paragraphs[0] if len(paragraphs) == 1 else None
    observations = {}
    for kind in ["cfg", "host-tuple"]:
        supported = observed_print_section is not None and re.search(
            r"(?<![A-Za-z0-9_-])" + re.escape(kind) + r"(?![A-Za-z0-9_-])",
            observed_print_section,
        ) is not None
        if not supported:
            observations[kind] = {
                "query_executed": False,
                "reason": "Exact token not explicitly listed in one unambiguous actual --print help paragraph",
                "reported_utf8": None,
            }
            continue
        raw = query("rustc-print-" + kind, ["rustc", "--print", kind])
        try:
            text = raw.decode("utf-8")
            error_text = None
        except UnicodeDecodeError as error:
            text = None
            error_text = str(error)
        observations[kind] = {
            "query_executed": True, "stdout_bytes": len(raw),
            "stdout_sha256": hashlib.sha256(raw).hexdigest(),
            "reported_utf8": text, "decode_error": error_text,
        }
    report = {
        "purpose": "NEW original Actions compiler-reported default cfg/host-tuple, no compilation",
        "workflow_revision": os.environ["GITHUB_SHA"],
        "run_id": os.environ["GITHUB_RUN_ID"],
        "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"],
        "uid": os.getuid(), "gid": os.getgid(), "cwd": str(root),
        "selected_environment": {key: os.environ.get(key) for key in [
            "PATH", "RUSTUP_TOOLCHAIN", "RUSTUP_HOME", "CARGO_HOME",
            "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_BUILD_TARGET",
            "ImageOS", "ImageVersion", "RUNNER_OS", "RUNNER_ARCH"]},
        "help_stdout_bytes": len(help_raw),
        "help_stdout_sha256": hashlib.sha256(help_raw).hexdigest(),
        "help_utf8_decode_error": help_decode_error,
        "print_paragraph_count": len(paragraphs),
        "actual_print_help_paragraph": observed_print_section,
        "observations": observations,
        "qualification": [
            "Actual help is only an operational guard for already-declared information queries, never tool/image/ABI/cohort/actor/physicalEX authority",
            "Host-tuple reports compiler host, not necessarily Cargo selected target; default cfg does not prove Cargo flags or the captured conditional ARM configuration match/inactivity",
            "Complete raw help/cfg/host streams and native statuses are retained, including opaque bytes and refusals; no guessed or normalized report values",
            "No target/SDK/worker/GC/allocator/workload setting changed, no unstable flag, source input, emit, link-args or native-static-libs request",
            "No old version/sysroot/query/component/config intake replay, C-tool guess, bootstrap/dependency/native build, driver/broker/perf/benchmark or Source20/runtime adoption",
            "Original Actions setup is unchanged and separate; complete effective linker/C headers/config-env/generated-input/native actor-FD/crash/officialEX admission remains unbound",
        ],
        "source_admitted": False, "live_admission": False,
        "capture_ready": False, "evidence_complete": False,
    }
    with (out / "rustc-default-target-observations.json").open("x") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
finally:
    journal.close()
