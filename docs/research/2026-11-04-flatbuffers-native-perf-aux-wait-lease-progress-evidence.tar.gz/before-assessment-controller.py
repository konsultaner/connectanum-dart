import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-lease-progress-v1');result=json.loads((p/'before/result.json').read_text());extra=json.loads((p/'before-buffered/result.json').read_text())
 assert (result['tests'],result['failures'],result['errors'])==(7,4,0) and (extra['tests'],extra['failures'],extra['errors'])==(1,0,0)
 reports=[];journals=[]
 for stage in ('before','before-buffered'):
  for path in sorted((p/stage/'fixtures').rglob('lease-before-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(p)),sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),data=d))
   assert d['original_callback_retained'] is True and d['original_process_retained'] is True and d['foreign_callback_calls']==0
   assert all(item['actual_official_verify_returned'] and item['raw_is_None'] for item in d['calls'])
   if d['mode']=='buffer-drift':assert d['finished'] is True and d['stdout_hex']==(b'ROOT-callback-buffer'+b'OWN-wait-lease-output').hex() and d['after_fault_source_attempts']
   if d['mode'] in ('alias-drift','process-drift','unknown-return'):assert d['private_first_is_received'] is True and d['guard_raises_received_first'] is True and d['row_present'] is False
   if d['mode']=='pre-alias':assert len(d['calls'])==2 and d['raised_is_ProducerError'] is True
  for path in sorted((p/stage/'fixtures').rglob('lease-unit-cleanup.json')):
   raw=path.read_bytes();journals.append(dict(stage=stage,path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(reports)==8 and len(journals)==8 and len(waits)==16 and all(type(row['status']) is int and row['status']==0 for row in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),NEWbefore7='4FAIL3PASS0APIerrors',separate_NEW_buffered1='1PASS0APIerrors original7 NOTreplayed',source_epoch='f39da0/299139',
 actual_current_officialEX_verify_delegate_returnedNone_BEFORE_ROOTfaults=True,scope_CURRENTDarwinfilelock_verification_ONLY_NOToriginalLinuxcredentials_fullactorEX_or_admission=True,
 buffer_injection_actual_written_to_log_plus_originalpayload_and_completion=True,
 alias_process_unknown_first_ALREADYretained_later_NEWstronger_percallback_intent_rawreturn_policy_NOTfour_native_kernelbugs=True,
 prealias_existing_guard_and_normalNone_ignoredFalse_PASS=True,nonempty_buffer_before_second_wait_normalPASS=True,
 reports=reports,journals=journals,new_known_boundwait_rows16_signed0=True,cached_possible=True,no_release_lock_credential_host_mutation_or_forged_live_receipt=True,
 ROOT_unit_knownFDcleanup_NOTphysicalEX=True,prior_legacy_rawlimits_preserved_no_reconstruction=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(cp.read_text());v=d['native_perf_only_diagnostic_design']['auxiliary_wait_lease_progress'];v.update(planning_pending=False,planning_status=0,NEW_tests_UNEXECUTED=False,NEWbefore7='4FAIL3PASS0APIerrors',separate_NEW_buffered1='1PASS0APIerrors',ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),candidate_UNIMPLEMENTED=True,review_pending=True);d['active_turn_status']='Aux_wait_lease_NEWbefore7_4FAIL3PASS_separatebuffered1PASS_candidateUNIMPLEMENTED_sourcef39da0_unchanged';cp.write_text(json.dumps(d,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(NEWbefore7='4FAIL3PASS0APIerrors',separate_buffered1='PASS',actual_buffer_injection_written=True,actual_current_officialEXdelegate=True,new_boundwaits16_signed0=True)))
