class AuxiliaryWaitLeaseProgressTests(unittest.TestCase):
    """NEW wait callback progress with actual CURRENT official EX verification."""
    def _lease_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-wait-lease-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        verify=official_ex_verify;actors=[];logs={};pipes=[];closed=[];cleanup=[];calls=[];foreign_calls=[];after_ops=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_read=os.read
        real_allocate=producer.AuxiliaryCommand._allocate_process;a=None;b=None;fault=False;raised=None;guard_error=None
        first=OSError(5,'OWN official verify return hidden by ROOT wait-callback fault');payload=b'OWN-wait-lease-output'
        def allocate(current,record):
            value=real_allocate(current,record);actors.append(dict(name=current.name,process=value,bound_wait=value.wait,bound_poll=value.poll));return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for name in ('lease-source','lease-foreign'):
                for role in ('stdout','stderr'):
                    if path==base/(name+'.'+role):logs[name+'.'+role]=value
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            st=os.fstat(fd);value=native_close(fd);closed.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None));return value
        def rows():
            journal=getattr(a,'_wait_lease_journal',None) if a is not None else None
            return journal if type(journal) is list else []
        def foreign_callback():foreign_calls.append(True);return None
        def callback():
            nonlocal fault
            ordinal=len(calls)+1;row=rows()[-1] if rows() else {}
            intent=(ordinal!=3 or (row.get('callback') is callback and row.get('callback_attempted') is True and row.get('returned') is None))
            value=verify()
            calls.append(dict(ordinal=ordinal,actual_official_verify_returned=True,raw_is_None=value is None,
                raw_is_False=value is False,wait_intent_before_delegate=intent))
            if ordinal==3:
                if mode in ('alias-drift','process-drift','buffer-drift','unknown-return'):
                    fault=True
                    if mode=='alias-drift':a.lease_check=foreign_callback
                    if mode=='process-drift':a.process=b.process
                    if mode=='buffer-drift':a.streams['stdout']['buffer']=b'ROOT-callback-buffer'
                    if mode=='unknown-return':raise first
                if mode=='false':return False
            return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                a=producer.AuxiliaryCommand(directory=base,name='lease-source',argv=[sys.executable,'-c',"import os;os.write(1,"+repr(payload)+")"],
                    cwd=base,environment=dict(os.environ),lease_check=callback);a.start()
                b=producer.AuxiliaryCommand(directory=base,name='lease-foreign',argv=[sys.executable,'-c','pass'],
                    cwd=base,environment=dict(os.environ),lease_check=verify);b.start()
                source=next(x for x in actors if x['name']=='lease-source');foreign=next(x for x in actors if x['name']=='lease-foreign')
                self.assertEqual(0,source['bound_wait'](10));self.assertEqual(0,foreign['bound_wait'](10))
                known={}
                for command in (a,b):
                    for role in ('stdout','stderr'):
                        fd=command.streams[role]['fd'];st=os.fstat(fd);known[fd]=(st.st_dev,st.st_ino)
                def polling():
                    if fault:after_ops.append(dict(kind='source_bound_poll_attempt'))
                    return source['bound_poll']()
                def reading(fd,count):
                    if fault:
                        st=os.fstat(fd)
                        if known.get(fd)==(st.st_dev,st.st_ino):after_ops.append(dict(kind='source_native_read_attempt',fd=fd,count=count))
                    return native_read(fd,count)
                source['process'].poll=polling
                if mode=='pre-alias':a.lease_check=foreign_callback;fault=True
                with mock.patch.object(os,'read',reading):
                    try:a.wait(timeout=10)
                    except BaseException as error:raised=error
                    if mode in ('alias-drift','process-drift','buffer-drift','unknown-return'):
                        # Pure guard only; never a second source wait/callback after error.
                        try:a._constructor_guard()
                        except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            row=rows()[0] if rows() else {};raw=row.get('raw_return')
            data=(base/'lease-source.stdout').read_bytes()
            report=dict(mode=mode,calls=calls,foreign_callback_calls=len(foreign_calls),after_fault_source_attempts=after_ops,
                actual_delegate_is_original_controller_bound_verify=True,scope_current_official_Darwin_EX_ONLY_not_originalLinux_credentials_fullactor_EX_or_admission=True,
                raised_is_injected=raised is first,raised_is_ProducerError=type(raised) is producer.ProducerError,
                guard_raises_received_first=raised is not None and guard_error is raised,
                private_first_is_received=raised is not None and getattr(a,'_deferred_primary_error',None) is raised,
                original_callback_retained=a._constructor_quarantine_binding[5] is callback,
                original_process_retained=a._constructor_quarantine.get('allocated_process') is source['process'],
                pending=a.pending,finished=a.finished,result_is_None=a.result is None,status=a.status,
                stdout_hex=data.hex(),stdout_size=len(data),source_buffer_hex=a.streams['stdout']['buffer'].hex(),
                row_present=bool(row),row_original_callback=row.get('callback') is callback,
                row_original_process=row.get('process') is source['process'],
                row_callback_attempted=row.get('callback_attempted'),row_returned=row.get('returned'),
                row_raw_is_None=raw is None,row_raw_is_False=raw is False,row_completed=row.get('completed'),
                row_error_is_received=raised is not None and row.get('error') is raised,
                known_ROOT_parent_pipes=pipes,known_ROOT_native_close_returns=closed)
            with (base/'lease-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_callback_retained']);self.assertTrue(report['original_process_retained'])
            self.assertTrue(all(item['actual_official_verify_returned'] and item['raw_is_None'] for item in calls))
            self.assertEqual(0,len(foreign_calls))
            if mode=='pre-alias':
                # Existing startup guard already refuses before the wait callback.
                self.assertIs(type(raised),producer.ProducerError);self.assertEqual(2,len(calls));self.assertEqual([],after_ops)
                self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
            elif mode in ('none','false'):
                self.assertIsNone(raised);self.assertEqual(3,len(calls));self.assertTrue(a.finished);self.assertFalse(a.pending)
                self.assertIsNotNone(a.result);self.assertIs(type(a.status),int);self.assertEqual(0,a.status);self.assertEqual(payload,data)
            else:
                self.assertEqual(3,len(calls));self.assertEqual([],after_ops)
                if mode=='unknown-return':self.assertIs(first,raised)
                else:self.assertIs(type(raised),producer.ProducerError)
                self.assertIs(raised,guard_error);self.assertTrue(report['private_first_is_received'])
                self.assertTrue(report['row_original_callback']);self.assertTrue(report['row_original_process']);self.assertTrue(report['row_error_is_received'])
                self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result);self.assertEqual(b'',data);self.assertFalse(report['row_completed'])
                self.assertTrue(calls[2]['wait_intent_before_delegate'])
                if mode=='unknown-return':self.assertIsNone(report['row_returned'])
                else:self.assertIs(report['row_returned'],True);self.assertTrue(report['row_raw_is_None'])
        finally:
            for actor in actors:
                value=actor['bound_wait'](10);cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=0,cached_possible=True));self.assertIs(type(value),int);self.assertEqual(0,value)
            identities={(item['fd'],item['dev'],item['ino']) for item in closed};seen=set()
            for item in pipes:
                key=(item['fd'],item['dev'],item['ino'])
                if key in seen or key in identities:continue
                seen.add(key);fd=item['fd']
                try:st=os.fstat(fd)
                except OSError as error:
                    cleanup.append(dict(kind='ROOT_known_FD_stat_error_NOTclosureproof',fd=fd,errno=error.errno));continue
                if (st.st_dev,st.st_ino)!=(item['dev'],item['ino']):
                    cleanup.append(dict(kind='ROOT_known_FD_identity_changed_NOTclosed',fd=fd));continue
                value=native_close(fd);cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
            for name,log in logs.items():
                if not log.closed:
                    fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                    log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',name=name,fd=fd,returned=True))
            with (base/'lease-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_existing_pre_alias_guard_refuses_without_foreign_callback(self):self._lease_case('pre-alias')
    def test_actual_verify_then_callback_alias_drift_retains_wait_boundary(self):self._lease_case('alias-drift')
    def test_actual_verify_then_process_drift_retains_wait_boundary(self):self._lease_case('process-drift')
    def test_actual_verify_then_buffer_injection_stops_before_log_write(self):self._lease_case('buffer-drift')
    def test_actual_verify_then_fault_retains_unknown_wait_intent(self):self._lease_case('unknown-return')
    def test_normal_actual_verify_None_preserves_bytes_and_completion(self):self._lease_case('none')
    def test_actual_verify_then_ignored_False_preserves_original_contract(self):self._lease_case('false')
