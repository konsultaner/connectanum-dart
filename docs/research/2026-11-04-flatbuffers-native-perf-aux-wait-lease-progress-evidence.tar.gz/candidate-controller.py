import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-lease-progress-v1');before=(p/'source-before.py').read_text();s=before
 methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema.py.txt').read_text();full=(p/'candidate-complete-guard.txt').read_text()
 needle='    def _wait_natural_status(self,timeout):';assert s.count(needle)==1;s=s.replace(needle,methods+needle,1)
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='        self._select_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._select_guard()\n        self._wait_lease_guard()\n\n    def _constructor_record',1)
 cls=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_complete')
 body=ast.get_source_segment(s,node);needle='        self._constructor_guard()\n';assert body.count(needle)==1;s=s.replace(body,body.replace(needle,needle+full,1),1)
 cls=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='wait')
 body=ast.get_source_segment(s,node);needle='        try:self.lease_check()';replacement='        try:self._check_wait_lease()'
 assert body.count(needle)==1 and s.count(body)==1;s=s.replace(body,body.replace(needle,replacement,1),1)
 needle="            select_state=values.get('_select_state');select_journal=values.get('_select_journal')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 fields="                wait_lease_fields_valid=waitlease_ok,wait_lease_quarantined=waitlease_quarantined,\n                wait_lease_entries=len(waitlease_journal) if type(waitlease_journal) is list else None,\n                wait_lease_returned=waitlease_last.get('returned') if type(waitlease_last.get('returned')) is bool else None,\n                wait_lease_context_released=waitlease_last.get('context_released') if type(waitlease_last.get('context_released')) is bool else None,\n                wait_lease_completed=waitlease_last.get('completed') if type(waitlease_last.get('completed')) is bool else None,\n"
 needle='                select_fields_valid=select_ok,select_quarantined=select_quarantined,';assert s.count(needle)==1;s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer.py',s),('candidate-data-fields.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='f39da0-before',tofile='NEW-waitlease-candidate')))
 l.verify_identity();print('private wait-lease candidate UNEXECUTED; source unchanged')
