import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-wait-lease-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW Aux wait-site lease callback original binding/context/intent/raw return progress only; preserve ignored callback return semantics incl None/False; earlier init/start lease sites/generic paths remain separate; no SDK/nativebuild/HEAD/tests/capture/cleanup',source_expected='f39da042145a6abf045b21c7029ce1afc4a10a3836be251e6c9036fee6280af2',tests_expected='2991399b751218a8dba0310c4d988e0af600006e122aba2da975e2c98895a314',prior_components_consumed_no_unchanged_repeat=True,new_unit_cases_delegate_actual_current_official_EX_verify_identity_NOToriginalLinux_host_fullphysicalEX=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='f39da042145a6abf045b21c7029ce1afc4a10a3836be251e6c9036fee6280af2' and hashlib.sha256(tests).hexdigest()=='2991399b751218a8dba0310c4d988e0af600006e122aba2da975e2c98895a314'
 for name,body in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(body)
 s=source.decode();cls=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 selected={x.name:ast.get_source_segment(s,x) for x in cls.body if isinstance(x,ast.FunctionDef) and x.name in ('wait','_constructor_guard','_startup_guard','_constructor_record','_defer')}
 with (P/'selected-source.json').open('x') as f:json.dump(selected,f,indent=2)
 l.verify_identity();print('NEW wait-lease source snapshot exact f39da0/299139; no tests/HEAD/SDK/native')
