import sys,pathlib,json,hashlib,subprocess,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-lease-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];slot=len(calls);row=dict(argv=argv,Popen_attempted=True,pid=None,status=None,stdout_eof=None,stderr_eof=None);calls.append(row)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  row['parent_pipe_FDstats']={name:dict(fd=stream.fileno(),dev=os.fstat(stream.fileno()).st_dev,ino=os.fstat(stream.fileno()).st_ino) for name,stream in [('stdout',child.stdout),('stderr',child.stderr)]}
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  out,err=child.communicate();status=child.wait();row.update(status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   path=q/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   st=path.stat();assert st.st_size==len(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest();row[label+'_pathstat']=dict(dev=st.st_dev,ino=st.st_ino,size=st.st_size)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not production
 h=json.loads((P/'after-edit-hashes.json').read_text());prior=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-select-progress-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items()) and all(h[k]==v for k,v in prior.items() if 'build_producer.py' not in k)
 before=(P/'source-before.py').read_text();current=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert current==(P/'candidate-producer.py').read_text() and current==(P/'after-producer.py').read_text()
 old=ast.parse(before);new=ast.parse(current);oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_wait_lease_guard','_check_wait_lease'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','wait','_constructor_guard','_complete'})
 methods=(P/'candidate-methods.py.txt').read_text();init=(P/'candidate-init.py.txt').read_text();schema=(P/'candidate-schema.py.txt').read_text();fields=(P/'candidate-data-fields.txt').read_text();full=(P/'candidate-complete-guard.txt').read_text()
 projected=current.replace(methods,'',1).replace(init,'',1).replace('        self._wait_lease_guard()\n','',1).replace(full,'',1).replace(schema,'',1).replace(fields,'',1)
 projected=projected.replace('        try:self._check_wait_lease()','        try:self.lease_check()',1)
 assert projected==before and tests==(P/'tests-before.py').read_text()+'\n\n'+(P/'new-tests-v2.py').read_text()
 assert 'for index,' not in schema and 'for wlindex,wlsnapshot' in schema
 def output_literal(node):
  return next(x for x in ast.walk(node) if isinstance(x,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='whole_descendant_exit_proven' for k in x.keys))
 assert ast.dump(output_literal(om['_complete']))==ast.dump(output_literal(nm['_complete']))
 forbidden={'repr','str','add_note','_write_json','close','_close_slot','wait','kill','_complete','_observe_status','_read_stream','_select_readers'}
 calls=[x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id if isinstance(x.func,ast.Name) else '' for x in ast.walk(nm['_check_wait_lease']) if isinstance(x,ast.Call)]
 assert not set(calls)&forbidden
 body=ast.get_source_segment(current,nm['_check_wait_lease'])
 assert body.index("check();row['callback_attempted']=True;value=callback()")<body.index("row['raw_return']=value;row['returned']=True")<body.index("check();row['context_checked']=True")<body.index("row['streams_before']=tuple(")<body.index("row['context_released']=True;row['completed']=True")
 assert 'if value' not in body and 'type(value)' not in body and 'value is None' not in body and not any(isinstance(x,ast.Return) for x in ast.walk(nm['_check_wait_lease']))
 guard_calls=[]
 for name,node in nm.items():
  for call in ast.walk(node):
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='_wait_lease_guard':guard_calls.append(dict(caller=name,keywords=[ast.unparse(x) for x in call.keywords]))
 assert {x['caller'] for x in guard_calls}=={'_constructor_guard','_complete'}
 v1=(P/'new-tests.py').read_text();v2=(P/'new-tests-v2.py').read_text()
 projected_test=v2.replace("\n    def test_actual_buffered_wait_reverification_preserves_bytes(self):self._lease_case('buffered')\n",'',1)
 projected_test=projected_test.replace("                    mid=None\n                    try:\n                        if mode=='buffered':\n                            partial=a.wait(timeout=0)\n                            mid=dict(return_is_None=partial is None,buffer_hex=a.streams['stdout']['buffer'].hex())\n                        a.wait(timeout=10)","                    try:a.wait(timeout=10)",1)
 projected_test=projected_test.replace("row_error_is_received=raised is not None and row.get('error') is raised,mid=mid,\n                row_entries=len(rows()),last_context_released=rows()[-1].get('context_released') if rows() else None,","row_error_is_received=raised is not None and row.get('error') is raised,",1)
 projected_test=projected_test.replace("elif mode in ('none','false','buffered'):\n                self.assertIsNone(raised);self.assertEqual(4 if mode=='buffered' else 3,len(calls));","elif mode in ('none','false'):\n                self.assertIsNone(raised);self.assertEqual(3,len(calls));",1)
 projected_test=projected_test.replace("\n                if mode=='buffered':self.assertEqual(dict(return_is_None=True,buffer_hex=payload.hex()),mid)",'',1)
 assert projected_test==v1
 invariant=dict(ROOT_whole_final_affected_methods_new8_helper_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,original7_testpaths_projectback_BYTEexact_excluding_buffered_only_branches_and_pure_report_fields=True,
 other18helpers3bins_BYTEexact=True,old_init_start_sites_read_select_directwait_poll_defer_othermethods_factories_gates_emit_freeze_auxpredicates_exact=True,original_result_literal_ASTexact=True,
 wait_callback_order_normalNone_helper_ignored_rawreturn_None_or_False_contract_preserved=True,no_None_only_or_type_truth_admission_gate=True,
 original_Ctor_callback_process_streamFD_writerFD_log_buffer_EOF_before_callback=True,rawreturn_before_postchecks=True,
 normal_duplicate_bufferrefs_summarized_AFTERknown_unchanged_callback_NOTstream_consumption_lease_EX_or_actor_release=True,unknowns_keep_original_fullbuffer_context=True,
 first_error_permanent_no_report_cleanup_restore_retry_replay_pipelineadvance=True,ordinary_latestrow_full_pre_finalization_and_passive_history=True,guard_calls=guard_calls,
 passive_wlindex_preserves_original_outer_auxiliary_index=True,
 actual_current_officialEX_verify_delegate_currentDarwin_ONLY_NOToriginalLinuxcredentials_fullactor_EX_or_admission=True,
 fields_refidentity_and_None_return_DATA_NOTauth_EXrelease_admission_atomicity_ABA_or_foreignwrite_prevention=True,
 local_GLM_token_limit1_NOretained_final_NOTapproval_ORglobalunavailability=True,ROOT_independent_source_tests_AST_qualified_NOTmodel_fullcurrent_approval=True,
 earlier_init_start_callback_backingFD_generic_enclosing_historical_transitive_fullphysicalEX_originalruntimeadmission_INCOMPLETE=True)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 reports=[];journals=[]
 for stage in ('before','before-buffered','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('lease-before-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
   assert d['original_callback_retained'] is True and d['original_process_retained'] is True and d['foreign_callback_calls']==0
   assert all(item['actual_official_verify_returned'] is True and item['raw_is_None'] is True for item in d['calls'])
   if stage=='after-selected':
    if d['mode']=='pre-alias':
     assert len(d['calls'])==2 and d['raised_is_ProducerError'] is True and not d['after_fault_source_attempts'] and d['row_present'] is False
    else:
     assert d['row_present'] is True and d['row_original_callback'] is True and d['row_original_process'] is True
     if d['mode'] in ('alias-drift','process-drift','buffer-drift','unknown-return'):
      assert d['guard_raises_received_first'] is True and d['private_first_is_received'] is True and d['row_error_is_received'] is True
      assert d['pending'] is True and d['finished'] is False and d['result_is_None'] is True and d['row_completed'] is False and d['after_fault_source_attempts']==[] and d['stdout_size']==0
      assert len(d['calls'])==3 and d['calls'][2]['wait_intent_before_delegate'] is True
      if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['row_returned'] is None and d['row_raw_is_None'] is True
      else:assert d['row_returned'] is True and d['row_raw_is_None'] is True
     else:
      assert d['mode'] in ('none','false','buffered') and d['row_returned'] is True and d['row_completed'] is True and d['last_context_released'] is True
      assert d['finished'] is True and d['pending'] is False and type(d['status']) is int and d['status']==0 and d['stdout_hex']==b'OWN-wait-lease-output'.hex()
      if d['mode']=='false':assert d['row_raw_is_False'] is True
      elif d['mode']=='buffered':assert len(d['calls'])==4 and d['row_entries']==2 and d['mid']==dict(return_is_None=True,buffer_hex=b'OWN-wait-lease-output'.hex())
      else:assert d['row_raw_is_None'] is True
  for path in sorted((P/stage/'fixtures').rglob('lease-unit-cleanup.json')):
   raw=path.read_bytes();journals.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=json.loads(raw)))
 assert len(reports)==16 and len(journals)==16
 waits=[row for j in journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(waits)==32 and all(type(row['status']) is int and row['status']==0 for row in waits)
 delegate_rows=[item for report in reports for item in report['data']['calls']];assert len(delegate_rows)==48
 for name,data in [('new-precleanup-reports.json',reports),('new-unit-journals.json',journals)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 b=json.loads((P/'before/result.json').read_text());extra=json.loads((P/'before-buffered/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text())
 assert (b['tests'],b['failures'],b['errors'])==(7,4,0) and (extra['tests'],extra['failures'],extra['errors'])==(1,0,0) and (a['tests'],a['failures'],a['errors'])==(22,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 NEWbefore7=b,separate_NEW_buffered1=extra,AFTERselected22=a,not_aggregated_or_current20canonical_or_originalruntimeadmission=True,
 source_Git=dict(head=head,branch=branch,untracked20_exact=True,production_packages_native_diffempty=True,four_signed0_BOTHseparateEOF=True,DATA_only=True),
 planning=json.loads((P/'test-planning/finish.json').read_text()),review=json.loads((P/'review/finish.json').read_text()),ROOT_review_qualification=json.loads((P/'ROOT-review-assessment.json').read_text()),
 ROOT_independent_wholefinal_source_tests_AST_qualified_NOTmodel_fullapproval=True,candidate_UNEXECUTED_before_edit=True,
 new_finite_journals=16,new_known_boundwait_rows=32,new_signed0_rows=32,cached_possible_NOTfreshsyscall=True,
 actual_A_facade_official_verify_return_rows=48,actual_current_officialEX_verify_NONE_NOTauth_ORoriginalLinux_fullactor_EX=True,
 only_pureguardprobe_aftererror_NOsecond_source_wait_callback=True,afterfault_monitored_native_attempts_zero=True,
 two_actual_OWN_normal_SourceAux_commands_percase_not_other_task_actors=True,
 buffer_injection_old_log_contamination_FIXED=True,other3_old_later_first_refusal_ALREADYworks_NEWpercallback_witness_NOTfour_native_kernelbugs=True,
 prealias_existing_startup_refusal_preserved_no_waitcallback_or_newrow=True,callback_ignored_None_False_contract_preserved_notNone_only=True,
 nonempty_buffer_before_second_wait_preserved_known_normal_duplicate_ref_summary_NOTrelease_or_exactheapbound=True,
 ROOT_unit_cleanup_stat_errors=sum(row['kind']=='ROOT_known_FD_stat_error_NOTclosureproof' for j in journals for row in j['data']),
 ROOT_unit_cleanup_identity_drifts=sum(row['kind']=='ROOT_known_FD_identity_changed_NOTclosed' for j in journals for row in j['data']),
 ROOTknown_parentFD_rawlog_cleanup_afterevidence_UNITonly_NOTliveEX=True,logical_history_opaque_return_refs_NOTexactheapRSS_bound_leak_timing_or_cause=True,
 required_legacy_setup_actorFD_APIreturns_notallserialized_no_reconstruction=True,inlineartifact_APIreturns_notall_regularfiles=True,all_named_operational_controllers_BEFOREcalls=True,
 other18helpers3bins_BYTEexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,
 free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_old_cleanup_spacechange_cause_UNMEASURED=True,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,
 provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_OPEN_DRAFT_base130_issue103_milestoneOPEN=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_wait_lease_progress']
 v.update(new_epoch_UNTESTED=False,ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW waitlease postcomponent4Git0/BOTHseparateEOF/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Final37da16/98a5f0 selected22PASS=8matchingNEW+14affected; ROOTqualified NOmodelanswer/current20canonical/admission')
 c['active_turn_status']='Aux_wait_lease37da16_98a5f0_selected22PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],NEWbefore7='4FAIL3PASS0APIerrors',separate_buffered1='1PASS0APIerrors',AFTERselected22='PASS',new_unit_journals=16,new_boundwait_rows=32,actual_A_delegate_verify_return_rows=48,free_bytes=free)))
