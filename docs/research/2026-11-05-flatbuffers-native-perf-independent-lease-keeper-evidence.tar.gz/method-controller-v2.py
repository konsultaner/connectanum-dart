import sys,pathlib,json,hashlib,os,stat,shutil,errno,subprocess,datetime
P=pathlib.Path("/tmp/connectanum-native-perf-independent-lease-keeper-v1")
OFFICIAL=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rawsave(p,b):
 with p.open('xb') as f:f.write(b)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_official(q):
 before=OFFICIAL.lstat();assert stat.S_ISREG(before.st_mode) and (before.st_uid,before.st_gid,before.st_size)==(501,20,35983)
 raw=OFFICIAL.read_bytes();after=OFFICIAL.lstat();assert (before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 assert sha(raw)=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
 save(q/'official-input-before-import.json',dict(path=str(OFFICIAL),uid=before.st_uid,gid=before.st_gid,size=len(raw),sha256=sha(raw),body_LOCALONLY_not_copied_or_published=True,point_identity_only=True))
 sys.path.insert(0,str(OFFICIAL.parent));import ollama_companion as m
 return m
def floor(q):
 free=shutil.disk_usage(P).free;save(q/'test-floor-before-body.json',dict(free_bytes=free,minimum_bytes=1024**3,test_only_not_build_capture_cleanup_authority=True));assert free>=1024**3
def blocked(error):
 cause=error.__cause__
 return type(cause) is BlockingIOError and cause.errno in (errno.EAGAIN,errno.EACCES) and str(error)=='local resource lease unavailable: local companion request is active'


def main():
    q=P/'actual-method-v1'
    q.mkdir()
    actors=[]
    def spawn(label,argv,stdin=None):
        i=len(actors)
        save(q/f'{i}-{label}-attempt-before.json',dict(label=label,argv=argv,Popen_attempted=True,pid=None))
        p=subprocess.Popen(argv,stdin=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        entry=dict(label=label,process=p,wait=p.wait,stdout=p.stdout,stderr=p.stderr,pid=p.pid)
        actors.append(entry)
        save(q/f'{i}-{label}-start-before-IO.json',dict(label=label,pid=p.pid,original_bound_wait_and_streams_retained_before_IO=True))
        return entry
    def finish(entry,out,err):
        status=entry['wait'](10)
        label=entry['label']
        rawsave(q/(label+'-stdout.bin'),out)
        rawsave(q/(label+'-stderr.bin'),err)
        row=dict(label=label,pid=entry['pid'],status=status,signed_native_int=type(status) is int,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err))
        save(q/(label+'-result.json'),row)
        return row
    keeper=spawn('keeper',[sys.executable,str(P/'keeper-fixture.py'),str(q/'keeper')],subprocess.PIPE)
    ready_raw=keeper['stdout'].readline()
    rawsave(q/'keeper-first-line.bin',ready_raw)
    if_ready=False
    if ready_raw:
        ready=json.loads(ready_raw)
        if_ready=ready.get('event')=='READY' and ready.get('official_EX_entered_verified') is True and ready.get('keeper_pid')==keeper['pid']
    if not if_ready:
        out,err=keeper['process'].communicate()
        row=finish(keeper,ready_raw+out,err)
        save(q/'refused-before-fixture.json',dict(keeper=row,no_client_or_probe_launched=True,namespace_terminal=True))
        print(json.dumps(dict(refused_before_fixture=True,keeper=row)))
        raise SystemExit(78)
    client=spawn('client',[sys.executable,'-c',"import sys;sys.stdin.buffer.readline();raise RuntimeError('independent-client-First')"],subprocess.PIPE)
    out,err=client['process'].communicate(input=b'client-start\n')
    client_result=finish(client,out,err)
    negative=spawn('negative-contender',[sys.executable,str(P/'probe-fixture.py'),str(q/'negative-probe')])
    out,err=negative['process'].communicate()
    negative_result=finish(negative,out,err)
    keeper['process'].stdin.write(b'observe\n')
    keeper['process'].stdin.flush()
    witness_raw=keeper['stdout'].readline()
    rawsave(q/'keeper-witness-line.bin',witness_raw)
    out,err=keeper['process'].communicate(input=b'finish\n')
    keeper_result=finish(keeper,ready_raw+witness_raw+out,err)
    positive=spawn('positive-contender',[sys.executable,str(P/'probe-fixture.py'),str(q/'positive-probe')])
    out,err=positive['process'].communicate()
    positive_result=finish(positive,out,err)
    child_result=json.loads((q/'keeper/result-before-release.json').read_text())
    rows=[keeper_result,client_result,negative_result,positive_result]
    save(q/'ALL-known-outcomes-BEFORE-assertions.json',dict(parent_four_rows=rows,keeper_owned_child=child_result,all_known_waits_collected=True,unknown_status_not_filled=True))
    witness=json.loads(witness_raw)
    neg=json.loads((q/'negative-probe/refused.json').read_text())
    assert all(x['signed_native_int'] and x['both_separate_EOF'] for x in rows)
    assert [x['status'] for x in rows]==[0,1,78,0]
    assert b'independent-client-First' in (q/'client-stderr.bin').read_bytes()
    assert witness['event']=='WITNESS' and witness['keeper_pid']==keeper['pid'] and witness['child_pid']==child_result['child_pid'] and witness['actual_native_poll'] is None
    assert neg['matched_exact_native_conflict'] and neg['native_errno'] in (errno.EAGAIN,errno.EACCES)
    assert child_result['child_signed_native_int'] and child_result['child_status']==0 and child_result['child_BOTH_EOF']
    assert (q/'keeper/official-context-exited.json').is_file() and (q/'positive-probe/acquired.json').is_file()
    result=dict(kind='NEW_PRIVATE_DARWIN_KNOWN_CONSTRUCTOR_CLIENT_FAILURE_FIXTURE_ONLY',cases=1,passes=1,failures=0,errors=0,parent_four_native_rows=rows,keeper_owned_child=child_result,distinct_actor_count=5,actual_independent_negative_EX_native_conflict=True,positive_after_keeper_natural_exit=True,caller_exit1_before_native_poll_None_observation=True,official_EX_held_by_independent_keeper_not_parent_callback_or_owner_field=True,Source_test_edits=False,SDK_or_original_runtime_invocations=False,originalLinux_credentials_physicalEX_fullFD_actor_closure=False,unknown_ctor_crash_general_error_cleanup_proved=False,atomic_ABA_or_origin_auth=False,capture_ready=False,evidence_complete=False,readiness=False,admission=False)
    save(q/'result.json',result)
    print(json.dumps(dict(cases=1,passes=1,actors=5,parent_statuses=[x['status'] for x in rows],child_status=child_result['child_status'],native_poll_None=True,admission=False)))

if __name__=="__main__":main()
