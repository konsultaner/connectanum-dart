import sys,pathlib,json,hashlib,os,stat,shutil,errno,subprocess,datetime
P=pathlib.Path("/tmp/connectanum-native-perf-independent-lease-keeper-v1")
OFFICIAL=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rawsave(p,b):
 with p.open('xb') as f:f.write(b)
def sha(b):return hashlib.sha256(b).hexdigest()
def load_official(q):
 before=OFFICIAL.lstat();assert stat.S_ISREG(before.st_mode) and (before.st_uid,before.st_gid,before.st_size)==(501,20,35983)
 raw=OFFICIAL.read_bytes();after=OFFICIAL.lstat();assert (before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 assert sha(raw)=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
 save(q/'official-input-before-import.json',dict(path=str(OFFICIAL),uid=before.st_uid,gid=before.st_gid,size=len(raw),sha256=sha(raw),body_LOCALONLY_not_copied_or_published=True,point_identity_only=True))
 sys.path.insert(0,str(OFFICIAL.parent));import ollama_companion as m
 return m
def floor(q):
 free=shutil.disk_usage(P).free;save(q/'test-floor-before-body.json',dict(free_bytes=free,minimum_bytes=1024**3,test_only_not_build_capture_cleanup_authority=True));assert free>=1024**3
def blocked(error):
 cause=error.__cause__
 return type(cause) is BlockingIOError and cause.errno in (errno.EAGAIN,errno.EACCES) and str(error)=='local resource lease unavailable: local companion request is active'

q=pathlib.Path(sys.argv[1]);q.mkdir();m=load_official(q)
try:
 with m.local_resource_lease(exclusive=True) as lease:
  lease.verify_identity();floor(q);save(q/'acquired.json',dict(pid=os.getpid(),official_EX_acquired=True,verify_identity_succeeded=True,fixture_only=True));print(json.dumps(dict(event='EX_ACQUIRED',pid=os.getpid())),flush=True)
except m.LocalResourceLeaseError as error:
 cause=error.__cause__;r=dict(pid=os.getpid(),event='EX_REFUSED',type=type(error).__name__,text=str(error),native_cause_type=type(cause).__name__,native_errno=getattr(cause,'errno',None),matched_exact_native_conflict=blocked(error),fixture_body_entered=False)
 save(q/'refused.json',r);print(json.dumps(r),flush=True);raise SystemExit(78 if blocked(error) else 1)
