import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-wait-context-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-wait-context-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='6626e1262da2e9f7a22693ae54fd49a9099363b6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Refuse changed wait-entry context before draining\n\nA lease or native-clock callback could return normally after changing the producer's journal, process or reader reference. The wait body then continued with changed context: one case reached natural status and later failed reporting, another returned None after a foreign-process lookup, and a False reader reached a ROOT barrier before native FD0. The wait prefix now checks private original references after each returned entry sub-operation and before the next operation. Known callback returns remain known; changed caller fields remain changed, without restoration or copying away.\n\nNEW4 at31cd79/326aed yields3FAIL/1normalPASS/0ERROR under controlled callbacks, not three spontaneous kernel bugs or a RAM cause. Final986f7d/d9baa1 passes19selected=4matchingNEW+15affected(5previous entry controls and10actual wait callers). The original inner wait body and all other methods/helpers/factories/frozen predicates remain exact; old test prefix is exact. Eight new views plus5affected views/8BEFORE38AFTER currentDarwinEX observations and original-bound ROOT waits remain UNIT facts, not full independent EX/originalLinuxcredentials/all actor closure. Normal leaseFalse/fullCTX-outCTX-err and earlier unknown-first contracts are preserved. Qwen57192 and GLM57649 complete0/fullanswers/reaped, ROOTqualified; later-loop scope, registry-pop/retry, return-witness, ABA and cleanup claims are corrected in the assessment. Source remains uncommitted/uncanonical/unadmitted; runtime admission, RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-wait-context-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: refuse changed producer wait entry context'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_wait_context_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Earlierwait-entryattributecapture-metadata-contents-shapes-globalbindings/laterclockcalleeinterior-concurrentABA; otherglob-end/enclosing-publicunknownCtor; writer-hash-init-nativeFD seams; independent frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Current986f7d/d9baa1 ONLYwaitentry checks privatelyretainedoriginalprocess-log-journal-records-command-attempt-reader-buffer-outputlog refs AFTEReachreturnedlookup-call-clock BEFOREnextoperation. KnownNone-float rowsreturnedTrue evencontextrefuses; changedfieldsstayforeign/no restore-copyfreeze-adopt; identityDATA notauth-ABA-ownership-EXrelease. NEW4before31cd79/326aed=3FAIL1normalPASS0ERROR:actualhealthycallbackcontext drift continuesdrain/reporting/foreignprocess/ROOTFalseFDbarrier(notnativeFD0), NOT3nativekernelbugs-RAMcause. Final19PASS=4NEW15affected(5priorentry10actualwaitcallers)/no prior5BEFORE-model-numericalreplay-aggregate-current20canonical-admission. Originalinnerwaitbody-allothermethodshelpersfactoriesfrozenpredicates exact/wholeSourceBYTEprojectback-oldtestPREFIX/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA.8newviews+5affected/EX8before38after/4+4newRootsameboundwait10zeroCached/5affectedseparate0/FDpathdevinocleanupAFTERevidence UNITnotSourcecleanup-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. Qwen57192=0/3018out486err-GLM57649=0/2280out685err/fullanswers-reaped-ROOTqualified/rejectreturnedFalseafterknownNone/laterloopdriftsubstitution/pop-retry-quarantine-reset/ABAequalnew-undetected/partialevidenceFDclose claims. Candidatev1-privatev1UNEXECUTEDbeforeedit-firstBEFORE/controllersBEFOREcalls; no modelwholecurrentapproval. PendingTrue-finishedFalse-statusNone/openFD DATA notliveness; negativepureguardonly/no Sourcepreserve-repr-note-drain-read-Popenwait-close/retry-replay-reset. Strongrefs-groups-rows-closures-tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. UnknownPopenCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_wait_context_selected19PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
