import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-wait-context-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1024**3
 q=P/'before-units';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 originaltests=(R/'tool/test_native_perf_build_producer.py').read_bytes();full=types.ModuleType('preserve_original_tests');full.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[full.__name__]=full;exec(compile(originaltests,full.__file__,'exec'),full.__dict__)
 tests=(P/'wait_context_regressions-v1.py').read_bytes();tm=types.ModuleType('wait_context_regressions');tm.__file__=str(P/'wait_context_regressions-v1.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;tm.__dict__['ProducerTests']=full.ProducerTests;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 cls=tm.ProducerWaitContextTests;names=unittest.defaultTestLoader.getTestCaseNames(cls);assert len(names)==4
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),candidate_tests_sha256=hashlib.sha256(tests).hexdigest(),selection=names,expected4=True,original_producer_UNCHANGED=True,no_unchanged_controls_replay=True),f,indent=2)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 out=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromTestCase(cls);result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(suite)
 (q/'tests.log').write_text(out.getvalue());value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),selection=names,leases=leases,source_UNCHANGED=True,not_canonical_runtime_admission=True,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['producer_wait_context_progress'];n.update(before_pending=False,before_result=value);c['active_turn_status']='Producer_wait_context_NEW4_BEFORE_'+str(value['failures'])+'FAIL_'+str(value['errors'])+'ERROR_Sourceunchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:value[k] for k in ('tests','failures','errors','passes')}));print(out.getvalue()[-1200:])
 # Expected BEFORE assertion failures are retained as unitdata; outercontroller0 is not numericalsuccess.

