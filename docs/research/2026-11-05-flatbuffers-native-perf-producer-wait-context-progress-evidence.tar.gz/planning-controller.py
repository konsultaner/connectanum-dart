import sys,pathlib,json,subprocess,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path("/tmp/connectanum-native-perf-producer-wait-context-progress-v1");q=p/'test-planning';q.mkdir()
 context="Plan <=180words/max3 concrete harness pitfalls for NEW4 healthy-returning waitentrycontextdrift ONLY. FullyreturnedactualOWNfixture/confirmedPopen, originalboundwait retained BEFOREcallbacks. LeaseafterofficialDarwinEXverifyNone replacesevents orprocess withOWNsentinel thenNone; modulelocal producer.time facadenativeclockfloat thenoutput_fdFalse. Rootos.read barrier catchesFalse BEFOREnativeFD0. RequireSourcecontextrefusal BEFOREdrain-poll-read/reporting, preserveforeignfields/norestore-copyfreeze. NormaldistinctCTX-outCTX-err/leaseFalselegacyignored. PriorNEW5 neverBEFOREreplayed; Rootsameactualboundwait10/devinoFDcleanupAFTERevidence UNITnotownership-release/physicalEX-originalLinuxcredentials-admission. IdentitychecksnotauthatomicABA, pendingfieldsnotliveness/stronggrowthunmeasured/no resettrim-delete. Suggestdeterministichooks+missingsemantics, no partialPopenmethods/Sourcecleanup/retry."
 selected=json.loads((p/'selected-source.json').read_text());context+='\nDECLARATION\n'+(p/'declaration.json').read_text()+'\nWAIT\n'+selected['wait']+'\nDRAIN\n'+selected['_drain_output']

 (q/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--num-predict','950','--max-input-chars','23000','--max-response-chars','8000','--timeout','180','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').write_text(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(q/'start.json').write_text(json.dumps(dict(pid=child.pid)))
 out,err=child.communicate();status=child.wait();inp.close();(q/'stdout.bin').write_bytes(out);(q/'stderr.bin').write_bytes(err)
 value=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True)
 (q/'result.json').write_text(json.dumps(value,indent=2));l.verify_identity();print(json.dumps(value));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-800:])
