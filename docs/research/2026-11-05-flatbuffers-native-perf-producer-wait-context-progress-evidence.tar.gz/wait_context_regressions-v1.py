"""NEW wait-entry context-drift controls; original fields are never restored."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class ProducerWaitContextTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)



    def _context_case(self,mode):
        calls=[];actors=[];seen={};leases=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT prevents native read on False FD')
        foreign=object()
        native_allocate=producer.CommandProducer._allocate_command_process
        native_drain=producer.CommandProducer._drain_output;native_wait=producer.CommandProducer._wait_command_natural
        native_time=producer.time;native_os=producer.os
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def checking():
            calls.append(dict(kind='wait_lease_attempt'));raw=verifying();calls.append(dict(kind='wait_lease_actual_return',raw_None=raw is None))
            if mode=='journal_drift':seen['producer'].events=foreign
            if mode=='process_drift':seen['producer'].process=foreign
            return False if mode=='normal' else raw
        class TimeFacade:
            def __getattr__(self,name):return getattr(native_time,name)
            def monotonic(self):
                raw=native_time.monotonic();calls.append(dict(kind='monotonic_actual_return',raw=raw))
                if mode=='reader_drift' and not seen.get('clock_drift_done'):
                    seen['clock_drift_done']=True;seen['producer'].output_fd=False
                return raw
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def read(self,fd,size):
                calls.append(dict(kind='Source_read_attempt',fd_False=fd is False,fd_original=fd is seen['reader']['fd']))
                if fd is False:raise first # Never delegate native FD0.
                return native_os.read(fd,size)
        def draining(p,deadline):
            calls.append(dict(kind='Source_drain_attempt'));return native_drain(p,deadline)
        def waiting(p,timeout):
            calls.append(dict(kind='Source_Popenwait_attempt'));return native_wait(p,timeout)
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating):
                code="import os,time;os.write(1,b'CTX-out');os.write(2,b'CTX-err');time.sleep(0.12)"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],lease_check=verifying);seen['producer']=p;p.lease_check=checking
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(producer,'time',TimeFacade()),mock.patch.object(producer,'os',OSFacade()),mock.patch.object(producer.CommandProducer,'_drain_output',draining),mock.patch.object(producer.CommandProducer,'_wait_command_natural',waiting):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                if mode!='normal':
                    try:producer._wait_entry_guard(p)
                    except BaseException as error:guard_error=error
            record=[r for r in producer._WAIT_ENTRY_RECORDS if r['owner'] is p][-1];rows=record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,result_None=result is None,result_status=None if result is None else result['status'],
                received_type=None if received is None else type(received).__name__,received_ROOTreadfirst=received is first,pure_guard_same_received=received is not None and guard_error is received,
                Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],Source_evidence_complete=p.evidence_complete,
                Source_events_foreign=p.events is foreign,Source_process_foreign=p.process is foreign,Source_reader_False=p.output_fd is False,
                original_log_closed=seen['log']['obj'].closed,original_journal_closed=seen['journal']['obj'].closed,record_process_original=record['process'] is actors[0]['process'],
                record_log_original=record['log'] is seen['log']['obj'],record_events_original=record['events'] is seen['journal']['obj'],record_reader_original=record['reader_fd'] is seen['reader']['fd'],
                record_primary_received=record['primary_error'] is received,record_completed=record['completed'],
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,raw_nativefloat=type(r['raw']) is float,error_ROOTfirst=r.get('error') is first) for r in rows],
                calls=list(calls),leases=leases,limits='Healthyreturningcontrolledcallbackdrift afteractualofficialDarwinEXverify/nativeclock. MODULELOCALos/time facades; ROOTFalseFDbarrier BEFOREnativeFD0. ForeignOWNsentinelnotPopen/actor; originalconfirmedPopen+boundwaitretained BEFOREhooks. Sourcefieldsstayforeign/no restoration. ContextidentityDATA notauth-atomicABA-liveness-ownership-EXrelease-originalLinux-fullFDclosure-admission. Negativepureguardonly/Rootsameboundwait10/knownFDdevino cleanupAFTERevidence UNITonly.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases))
            self.assertTrue(record['process'] is actors[0]['process']);self.assertTrue(record['log'] is seen['log']['obj']);self.assertTrue(record['events'] is seen['journal']['obj']);self.assertTrue(record['reader_fd'] is seen['reader']['fd'])
            if mode=='normal':
                self.assertTrue(returned);self.assertEqual('success',result['status']);self.assertIsNone(received);self.assertTrue(record['completed']);self.assertTrue(p.evidence_complete)
                self.assertEqual(b'CTX-outCTX-err',(p.directory/'command-000.log').read_bytes())
                self.assertTrue(any(r['stage']=='lease_call' and r['returned'] and r['raw'] is False for r in rows))
            else:
                self.assertFalse(returned);self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(guard_error is received);self.assertTrue(record['primary_error'] is received);self.assertFalse(record['completed'])
                self.assertTrue(p.pending);self.assertFalse(p.finished);self.assertIsNone(p.records[-1]['returncode']);self.assertFalse(p.evidence_complete)
                self.assertFalse(seen['log']['obj'].closed);self.assertFalse(seen['journal']['obj'].closed)
                self.assertFalse(any(x['kind'] in ('Source_drain_attempt','Source_read_attempt','Source_Popenwait_attempt','repr_first','note_first') for x in calls))
                self.assertEqual(['lease_lookup','lease_call']+(['deadline_clock'] if mode=='reader_drift' else []),[r['stage'] for r in rows])
                self.assertTrue(rows[-1]['returned'])
                if mode=='reader_drift':self.assertTrue(p.output_fd is False);self.assertTrue(type(rows[-1]['raw']) is float)
                else:
                    self.assertIsNone(rows[-1]['raw'])
                    if mode=='journal_drift':self.assertTrue(p.events is foreign)
                    if mode=='process_drift':self.assertTrue(p.process is foreign)
                count=len(calls)
                try:producer._wait_entry_guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('wait entry context pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed and item['obj'] is not raw:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_wait_lease_journal_drift_stops_before_drain(self):self._context_case('journal_drift')
    def test_actual_wait_lease_process_drift_stops_before_foreign_lookup(self):self._context_case('process_drift')
    def test_actual_native_clock_readerFalse_drift_stops_before_nativeFD0(self):self._context_case('reader_drift')
    def test_new_normal_wait_leaseFalse_preserves_fullbytes_result(self):self._context_case('normal')
