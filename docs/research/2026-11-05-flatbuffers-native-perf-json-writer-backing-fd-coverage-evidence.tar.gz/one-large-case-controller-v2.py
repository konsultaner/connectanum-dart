import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-json-writer-backing-fd-coverage-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1024**3
 q=P/'one-large-case-v2';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_WRITER_BACKING_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tests=(P/'backing_fd_coverage-v4.py').read_bytes();tm=types.ModuleType('backing_fd_coverage');tm.__file__=str(P/'backing_fd_coverage-v4.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 cls=tm.JSONWriterBackingFDTests;names=['test_actual_FileIO_prefix3_then_buffered_write_error_stops_before_flush'];assert len(names)==1
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),candidate_tests_sha256=hashlib.sha256(tests).hexdigest(),selection=names,expected1_NEW_larger_payload=True,original_producer_UNCHANGED=True,no_unchanged_controls_replay=True),f,indent=2)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 out=io.StringIO();suite=unittest.TestSuite([cls(names[0])]);result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(suite)
 (q/'tests.log').write_text(out.getvalue());value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),selection=names,leases=leases,source_UNCHANGED=True,not_canonical_runtime_admission=True,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['json_writer_backing_fd_coverage'];n.update(before_pending=False,large_case_result=value);c['active_turn_status']='JSONwriter_backingFD_separateNEWlarger_case_'+str(value['failures'])+'FAIL_'+str(value['errors'])+'ERROR_Sourceunchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:value[k] for k in ('tests','failures','errors','passes')}));print(out.getvalue()[-800:])
 if not result.wasSuccessful():sys.exit(1)

