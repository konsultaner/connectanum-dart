"""NEW actual FileIO backing-call coverage; unchanged producer and no Source recovery."""
import os
import io
import sys
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer


class JSONWriterBackingFDTests(TestCase):
    def _backing_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='writer-backing-'+mode+'-',dir=os.environ.get('CONNECTANUM_WRITER_BACKING_FIXTURES',tempfile.gettempdir()))).resolve()
        path=base/'output.json'
        value={'a':'é','body':'L'*20000 if mode=='write_prefix' else 'small','z':mode}
        payload=(json.dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode()
        seen={};events=[];renders=[];cleanup=[];phase=['Source'];evidence_ready=False
        class First(OSError):
            def __repr__(self):renders.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):renders.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):renders.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after actual FileIO delegate')
        original_open=producer.Path.open
        def opening(p,*args,**kwargs):
            if p!=path or args!=('xb',) or kwargs:return original_open(p,*args,**kwargs)
            event=dict(stage='original_Path_open',attempted=True,returned=False);events.append(event)
            f=original_open(p,*args,**kwargs);seen['manager']=f;seen['buffered_close']=f.close;event['returned']=True
            raw=f.raw;seen['raw']=raw
            seen['raw_write']=raw.write;seen['raw_close']=raw.close;seen['raw_fileno']=raw.fileno
            self.assertIs(type(f),io.BufferedWriter);self.assertIs(type(raw),io.FileIO)
            fd=seen['raw_fileno']();seen['fd']=fd;info=os.fstat(fd);seen['identity']=(info.st_dev,info.st_ino)
            def writing(packet):
                row=dict(stage='FileIO_write',phase=phase[0],attempted=True,returned=False,raw_int=None,requested_size=len(packet),delegated_size=None,error_type=None);events.append(row)
                delegated=packet[:3] if mode in ('flush_prefix','write_prefix') else packet;row['delegated_size']=len(delegated)
                try:
                    result=seen['raw_write'](delegated);row['raw_int']=result;row['returned']=True
                except BaseException as error:row['error_type']=type(error).__name__;raise
                if phase[0]=='Source' and mode in ('flush_prefix','flush_full','write_prefix'):raise first
                return result
            def closing():
                row=dict(stage='FileIO_close',phase=phase[0],attempted=True,returned=False,raw_None=None);events.append(row)
                result=seen['raw_close']();row['raw_None']=result is None;row['returned']=True
                if phase[0]=='Source' and mode=='close_fault':raise first
                return result
            raw.write=writing;raw.close=closing
            return f
        received=None;returned=False;result=object();guard_error=None
        try:
            with mock.patch.object(producer.Path,'open',opening):
                try:result=producer._write_json(path,value);returned=True
                except BaseException as error:received=error
            attempt=producer._JSON_WRITE_ATTEMPTS[-1]
            if received is not None:
                try:attempt.guard()
                except BaseException as error:guard_error=error
            f=seen['manager'];raw=seen['raw'];data=path.read_bytes()
            rows=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_int=r['raw'] if type(r['raw']) is int else None,error_is_received=received is not None and r['error'] is received) for r in attempt.steps]
            view=dict(mode=mode,Source_public_returned=returned,Source_public_result_None=result is None,
                received_original=received is first,Source_first_original=attempt.first_error is first,pure_guard_original=guard_error is first,
                Source_completed=attempt.completed,Source_manager_original=attempt.manager is f,Source_writer_original=attempt.writer is f,
                Source_writer_raw_original=attempt.writer is not None and attempt.writer.raw is raw,
                Source_render_before_asserts=list(renders),Source_rows=rows,ROOT_internal_events=list(events),
                ROOT_file_size=len(data),ROOT_file_sha256=hashlib.sha256(data).hexdigest(),ROOT_file_prefix_hex=data[:12].hex(),
                expected_payload_size=len(payload),expected_payload_sha256=hashlib.sha256(payload).hexdigest(),
                native_raw_closed=raw.closed,native_buffer_closed=f.closed,native_fd=seen['fd'],native_fd_identity=seen['identity'],
                limits='ROOTknowninternal FileIO return/bytes/closed DATA, never Source outerknownreturn/publication/durability/fullFD-instruction-actorEX/admission. Controlledprefix3/nativeNone-thenROOTfault NOTspontaneouskernelshortwrite.')
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual([],renders);self.assertIs(attempt.manager,f);self.assertIs(attempt.writer,f);self.assertIs(f.raw,raw)
            source_writes=[e for e in events if e['stage']=='FileIO_write' and e['phase']=='Source'];self.assertEqual(1,len(source_writes));self.assertTrue(source_writes[0]['returned'])
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(result);self.assertIsNone(received);self.assertTrue(attempt.completed);self.assertEqual(payload,data)
                self.assertEqual(['path','open','enter_lookup','exit_lookup','enter','json','encode','write','flush','fileno','fsync','exit'],[r['stage'] for r in rows])
                self.assertTrue(all(r['returned'] for r in rows));self.assertTrue(raw.closed);self.assertTrue(f.closed)
                self.assertEqual(1,len([e for e in events if e['stage']=='FileIO_close']))
            else:
                self.assertFalse(returned);self.assertTrue(received is first);self.assertTrue(attempt.first_error is first);self.assertTrue(guard_error is first);self.assertFalse(attempt.completed)
                stage='write' if mode=='write_prefix' else 'exit' if mode=='close_fault' else 'flush'
                self.assertEqual(stage,rows[-1]['stage']);self.assertFalse(rows[-1]['returned']);self.assertTrue(rows[-1]['raw_None']);self.assertTrue(rows[-1]['error_is_received'])
                self.assertEqual(payload[:3] if mode in ('flush_prefix','write_prefix') else payload,data)
                if mode in ('flush_prefix','flush_full'):
                    write=next(r for r in rows if r['stage']=='write');self.assertTrue(write['returned']);self.assertEqual(len(payload),write['raw_int'])
                if mode=='close_fault':
                    self.assertTrue(raw.closed);self.assertEqual(1,len([e for e in events if e['stage']=='FileIO_close']));self.assertTrue(events[-1]['raw_None'])
                else:self.assertFalse(raw.closed);self.assertFalse(any(e['stage']=='FileIO_close' for e in events))
                count=len(events)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is first)
                else:self.fail('permanent pure guard returned')
                self.assertEqual(count,len(events));self.assertEqual([],renders)
        finally:
            phase[0]='ROOT_cleanup_after_evidence'
            if evidence_ready and 'raw' in seen:
                raw=seen['raw'];row=dict(raw_already_closed=raw.closed,original_raw_close_attempted=False,original_raw_close_None=None,buffered_close_attempted=False,buffered_close_return_None=None)
                if not raw.closed:
                    fd=seen['raw_fileno']();a=os.fstat(fd);b=path.stat();same=(a.st_dev,a.st_ino)==tuple(seen['identity'])==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                    if same:
                        row['original_raw_close_attempted']=True;closed=seen['raw_close']();row['original_raw_close_None']=closed is None
                if raw.closed:
                    row['buffered_close_attempted']=True
                    try:closed=seen['buffered_close']();row['buffered_close_return_None']=closed is None
                    except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                after=path.read_bytes();row.update(after_size=len(after),after_sha256=hashlib.sha256(after).hexdigest(),after_equals_view=after==data,raw_closed_after=raw.closed,buffer_closed_after=seen['manager'].closed)
                cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True,known_manager='manager' in seen,known_raw='raw' in seen))
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(dict(rows=cleanup,events_after_evidence=events[len(view['ROOT_internal_events']):] if evidence_ready else [],limits='ROOTknownnativeRawclose BEFOREBufferedclose UNITonly/no Source recovery/EXrelease/borrowedFDdoubleclose; omitted setup/internalFD-delegate facts notreconstructed'),indent=2)+'\n')

    def test_actual_FileIO_prefix3_then_flush_error_retains_unknown_outer(self):self._backing_case('flush_prefix')
    def test_actual_FileIO_fullwrite_then_flush_error_is_not_publication(self):self._backing_case('flush_full')
    def test_actual_FileIO_prefix3_then_buffered_write_error_stops_before_flush(self):self._backing_case('write_prefix')
    def test_actual_FileIO_close_then_error_keeps_unknown_exit(self):self._backing_case('close_fault')
    def test_new_normal_actual_FileIO_write_close_preserves_full_JSON(self):self._backing_case('normal')
