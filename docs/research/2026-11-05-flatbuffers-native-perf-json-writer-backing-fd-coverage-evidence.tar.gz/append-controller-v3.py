import sys,pathlib,json,ast,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-backing-fd-coverage-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();u=json.loads((P/'units/result.json').read_text());assert(u['tests'],u['passes'],u['failures'],u['errors'])==(5,4,1,0)
 one=json.loads((P/'one-large-case-v2/result.json').read_text());assert(one['tests'],one['passes'],one['failures'],one['errors'])==(1,1,0,0)
 prior=(P/'backing_fd_coverage-v3.py').read_text();current=(P/'backing_fd_coverage-v4.py').read_text();assert current.replace("'L'*(io.DEFAULT_BUFFER_SIZE*4+1) if mode=='write_prefix'","'L'*20000 if mode=='write_prefix'",1)==prior
 original_source=(P/'before-producer.py').read_bytes();original_tests=(P/'before-tests.py').read_bytes()
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==original_source and (R/'tool/test_native_perf_build_producer.py').read_bytes()==original_tests
 extra=(P/'backing_fd_coverage-v4.py').read_bytes();new=original_tests+b'\n\n'+extra;tree=ast.parse(new);private=ast.parse(extra)
 node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='JSONWriterBackingFDTests');pnode=next(n for n in private.body if isinstance(n,ast.ClassDef) and n.name=='JSONWriterBackingFDTests')
 assert ast.dump(node,include_attributes=False)==ast.dump(pnode,include_attributes=False)
 (R/'tool/test_native_perf_build_producer.py').write_bytes(new)
 before=json.loads((P/'before-hashes.json').read_text());h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in before}
 assert [k for k in h if h[k]!=before[k]]==['tool/test_native_perf_build_producer.py']
 (P/'after-tests.py').open('xb').write(new);(P/'after-append-hashes.json').open('x').write(json.dumps(h,indent=2))
 v=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],producer_UNCHANGED=True,only_test_changed=True,other19helpers3bins_unchanged=True,oldtests_BYTES_PREFIX_exact=True,appended_class_ASTequivalent_to_privatev4=True,coverage='4PASSv3+separate1PASSv4; initial20k1harnessFAILpreserved; no5-suite-currentPASS',only_exclusive_write_prefix_branch_changes=True,NOafterappend_replay=True,not_BEFOREfailing_Sourcefix_or_fullcurrentcanonical_admission=True)
 (P/'append-result.json').open('x').write(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['json_writer_backing_fd_coverage'].update(append=v,Source_UNCHANGED=True,model_pending=False,ROOT_pending=True);c['active_turn_status']='JSONwriter_FileIObacking_4PASS_plusseparate1PASS_ASTequivalent_testappend_ROOTpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
