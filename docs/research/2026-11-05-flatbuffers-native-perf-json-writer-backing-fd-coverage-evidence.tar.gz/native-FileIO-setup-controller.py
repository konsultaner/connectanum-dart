import sys,pathlib,json,os,io,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-json-writer-backing-fd-coverage-v1")
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'native-FileIO-setup';q.mkdir();path=q/'probe.bin';events=[]
 def call(stage,fn,args=()):
  row=dict(stage=stage,attempted=True,returned=False,raw=None);events.append(row)
  raw=fn(*args);row['raw']=raw if type(raw) in (int,bool,str) or raw is None else type(raw).__name__;row['returned']=True
  return raw
 f=call('native_Path_open',path.open,('xb',));assert type(f) is io.BufferedWriter
 raw=call('native_BufferedWriter_raw',lambda:f.raw);assert type(raw) is io.FileIO
 original_write=raw.write;original_close=raw.close;original_fileno=raw.fileno;buffered_close=f.close
 fd=call('raw_fileno',original_fileno);info=call('raw_fstat',os.fstat,(fd,));identity=(info.st_dev,info.st_ino)
 def writing(packet):
  row=dict(stage='actual_original_FileIO_write',attempted=True,returned=False,raw=None,requested_size=len(packet),requested_sha256=hashlib.sha256(packet).hexdigest());events.append(row)
  value=original_write(packet);row['raw']=value;row['returned']=True;return value
 def closing():
  row=dict(stage='actual_original_FileIO_close',attempted=True,returned=False,raw_UNKNOWN=True);events.append(row)
  value=original_close();row['raw_None']=value is None;row['returned']=True;row['raw_UNKNOWN']=False;return value
 raw.write=writing;raw.close=closing
 written=call('buffered_write',f.write,(b'probe',));flushed=call('buffered_flush',f.flush)
 observed_fd=call('buffered_fileno',f.fileno);assert observed_fd==fd
 synced=call('native_fsync',os.fsync,(fd,));closed=call('buffered_close',buffered_close)
 actual=call('ROOT_filebytes',path.read_bytes)
 assert written==5 and flushed is None and synced is None and closed is None and actual==b'probe'
 assert [x['stage'] for x in events].count('actual_original_FileIO_write')==1 and [x['stage'] for x in events].count('actual_original_FileIO_close')==1
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),preflight_only_Source_units_executed=0,not_Sourcehelper_SDK_canonical_admission=True,native_Path_xb_BufferedWriter_FileIO_originaldelegates_observed=True,fd=fd,fd_devino=identity,buffer_closed=f.closed,raw_closed=raw.closed,actual_size=len(actual),actual_sha256=hashlib.sha256(actual).hexdigest(),events=events)
 (q/'result.json').open('x').write(json.dumps(result,indent=2))
 l.verify_identity();print(json.dumps(dict(preflight_only_Sourceunits0=True,actual_FileIO_write_close_callbacks=1,actual_bytes=len(actual),raw_closed=raw.closed,admission=False)))
