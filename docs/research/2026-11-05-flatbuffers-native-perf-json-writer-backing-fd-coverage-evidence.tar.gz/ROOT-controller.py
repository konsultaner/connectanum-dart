import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-json-writer-backing-fd-coverage-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-append-hashes.json').read_text());before=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'before-producer.py').read_bytes()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'backing_fd_coverage-v4.py').read_bytes()
 assert [k for k in h if h[k]!=before[k]]==['tool/test_native_perf_build_producer.py']
 ast.parse(source);tree=ast.parse(tests);private=ast.parse((P/'backing_fd_coverage-v4.py').read_bytes())
 node=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='JSONWriterBackingFDTests');pnode=next(x for x in private.body if isinstance(x,ast.ClassDef) and x.name=='JSONWriterBackingFDTests')
 assert ast.dump(node,include_attributes=False)==ast.dump(pnode,include_attributes=False)
 assert (P/'backing_fd_coverage-v4.py').read_text().replace("'L'*(io.DEFAULT_BUFFER_SIZE*4+1) if mode=='write_prefix'","'L'*20000 if mode=='write_prefix'",1)==(P/'backing_fd_coverage-v3.py').read_text()
 initial=json.loads((P/'units/result.json').read_text());one=json.loads((P/'one-large-case-v2/result.json').read_text())
 assert(initial['tests'],initial['passes'],initial['failures'],initial['errors'])==(5,4,1,0) and(one['tests'],one['passes'],one['failures'],one['errors'])==(1,1,0,0)
 assert len(initial['leases'])==10 and len(one['leases'])==2 and all(r['raw_None'] for r in initial['leases']+one['leases'])
 def views(path):return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())]}
 first=views(P/'units/fixtures');later=views(P/'one-large-case-v2/fixtures');assert len(first)==5 and len(later)==1
 assert first['write_prefix'][0]['Source_rows'][-1]['stage']=='flush' and first['write_prefix'][0]['expected_payload_size']<131072
 assert later['write_prefix'][0]['Source_rows'][-1]['stage']=='write' and later['write_prefix'][0]['expected_payload_size']>131072
 cleanup=[]
 for phase,group in [('initial',first),('separate_larger',later)]:
  for mode,(v,d) in group.items():
   assert v['Source_render_before_asserts']==[] and v['Source_manager_original'] and v['Source_writer_original'] and v['Source_writer_raw_original']
   writes=[e for e in v['ROOT_internal_events'] if e['stage']=='FileIO_write'];assert len(writes)==1 and writes[0]['returned']
   rows=v['Source_rows']
   if mode=='normal':
    assert v['Source_public_returned'] and v['Source_public_result_None'] and v['Source_completed']
    assert v['ROOT_file_sha256']==v['expected_payload_sha256'] and v['native_raw_closed'] and v['native_buffer_closed']
   else:
    assert not v['Source_public_returned'] and not v['Source_completed'] and v['received_original'] and v['Source_first_original'] and v['pure_guard_original']
    assert not rows[-1]['returned'] and rows[-1]['raw_None'] and rows[-1]['error_is_received']
    if mode in ('flush_prefix','write_prefix'):assert writes[0]['raw_int']==3 and writes[0]['delegated_size']==3 and v['ROOT_file_size']==3
    else:assert writes[0]['raw_int']==v['expected_payload_size'] and v['ROOT_file_sha256']==v['expected_payload_sha256']
    if mode=='close_fault':
     closes=[e for e in v['ROOT_internal_events'] if e['stage']=='FileIO_close'];assert len(closes)==1 and closes[0]['returned'] and closes[0]['raw_None'] and v['native_raw_closed']
    else:assert not v['native_raw_closed'] and not any(e['stage']=='FileIO_close' for e in v['ROOT_internal_events'])
   c=json.loads((d/'ROOT-unit-cleanup.json').read_text());row=c['rows'][0];assert row['after_equals_view'] and row['raw_closed_after'] and row['buffer_closed_after']
   if row['original_raw_close_attempted']:assert row['FD_path_original_identity_match'] and row['original_raw_close_None']
   cleanup.append(dict(phase=phase,mode=mode,receipt=c))
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],producer_UNCHANGED=True,
 initial=dict(tests=5,passes=4,harness_failure=1,errors=0,reason='20k buffered byinstalledPython, FileIOprefixerror inflush notwrite;1rawcall, NOTmodeltwo-callpremise/Sourcebug'),
 separate_new_larger_case=one,coverage='4privatev3PASS plusseparateNEWlarger-v4case1PASS. No unchanged4/original5 replay. NOTcombinedcurrent5PASS/fullcurrent20canonical/Sourcefix/BEFOREfailingrepairregression.',
 ROOT=dict(final_Source_tests_AST_qualified=True,producer_BYTES_UNCHANGED=True,oldtests_BYTES_PREFIX_exact=True,appended_class_ASTequivalent_privatev4=True,exclusive_write_prefix_input_branch_changes_only=True,other19helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=6,initial_parent_EXverify_None=10,separate_case_parent_EXverify_None=2,unit_cleanup=cleanup,normal_original_publicwriter_methodorder_exact=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM=json.loads((P/'candidate-review/result.json').read_text()),ROOT_qualified_NOTwholecurrentapproval=True,review_before_v3_postguard_assert_and_v4_exclusive_payload_change=True),
 limits=['OnlyselectedFileIO-backing coverage, notSourcebehaviorfix/productiondefect/RAMcause/aggregate/fullcurrentcanonical/admission. Initial4PASS1harnessFAIL preserved plusseparatepredeclaredlargercase1PASS; unchanged4 notrerun/failure notrewritten. Installedio.DEFAULT_BUFFER_SIZE131072 isDATA notactualbuffer/heapRSSallocationproof.',
 'ActualFileIO prefix3 writes intentionallydelegateonly3bytes, thenROOTfault; notspontaneouskernelshortwrite. Fullwrite/close actualreturns ROOTknown whileSourceouterwrite-flush-exit rawUNKNOWN. Manager/writer actualraw relation retained; noSourceadopt-infer fromRootbytes/closedfields.',
 'KnownoriginalnativeRawclose BEFOREBufferedclose AFTERevidence/devino/assertions UNITonly; bytepre/postsame. No Sourcecleanup/restore-retry-replay/EXrelease/borrowedFDclose. Cclosedobject cleanupresults actualrecorded, notstrongerallinternalFD-instruction/delegate proof.',
 'Sixnewviews(initial5+separate1), parent10+2CURRENT officialDarwinEXverifyNone notindependentfullEX-originalLinuxcredentials/immutableCOMPLETEadmission. No Sourcechildlaunch intheseunits; namedmodels/Git separatelyrecorded/notglobalabsence-fullreap. Some setup/internalFD/APIreturns notallserialized/no reconstruction.',
 'Source-independent5B nativeFileIOhook probe isseparateDATA/Sourceunit0/notSDK-build-canonical-runtimeadmission. Currentproduction/path-open xb buffering/methodorder unchanged. Rootfixture callbacks interpose onlydeclarednativebackingmethods, notSourceproductionobservers.',
 'Qwenreset/namespace/intducktype/oldouter-controls advice rejected. GLMtwo-callcount, unsafeFDmismatchclose andsilentguarddivergence claims rejected; v3safeidentity/postguardrenderassert BEFOREfirst5. Initial20kbadpremise discoveredAFTERmodel, v4exclusivepayloadbranch AFTERmodel; ROOTfinalASTqualified notmodelwholecurrentapproval. Allprivatev1-v2UNEXECUTED; first5v3; onlynewlargercasev4.',
 'All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact/no Sourcecommit-push-adoption/actualSDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.',
 'Journals-refs-rawbuffers-closures-tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. OtherFileIOseams/EINTR/nativeinternalprogress/globalbuiltins/earlierAPI/enclosing-historical-transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission remainINCOMPLETE.'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['json_writer_backing_fd_coverage'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],one_larger_pending=False,ROOT_pending=False,docs_pending=True);c['active_turn_status']='JSONwriter_FileIObacking_4PASS_plusNEW1PASS_testappend_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],producer_UNCHANGED=True,coverage='initial4PASS1harnessFAIL+separateNEW1PASS/no4replay',views=6,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
