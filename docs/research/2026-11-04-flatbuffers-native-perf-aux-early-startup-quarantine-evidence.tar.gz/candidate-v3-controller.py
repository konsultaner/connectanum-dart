import sys,pathlib,json,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1');s=(p/'candidate-v2-producer.py').read_text()
 s=s.replace("or constructor[5] is not self.lease_check):","or constructor[5] is not self.lease_check or constructor[6] is not self._constructor_secondary_errors\n            or type(constructor[6]) is not list):")
 s=s.replace('    def _quarantine_startup(self,binding,error):','    def _quarantine_startup(self,binding,error,operation=None):')
 old="""            current=state.get('current')
            if type(current) is dict and all(type(key) is str for key in current):
                if current.get('error') is None:current['error']=self._startup_primary_error"""
 new="""            if type(operation) is dict and all(type(key) is str for key in operation):
                if operation.get('error') is None:operation['error']=self._startup_primary_error"""
 assert old in s;s=s.replace(old,new)
 marker='            self._quarantine_startup(binding,error)\n            raise self._startup_primary_error'
 assert s.count(marker)==1;s=s.replace(marker,'            self._quarantine_startup(binding,error,row)\n            raise self._startup_primary_error')
 ast.parse(s)
 with (p/'candidate-v3-producer.py').open('x') as f:f.write(s)
 notes=dict(candidate_UNIMPLEMENTED_static_corrections_only=True,GLM26781_review_complete0_not_approval=True,ROOT_accepted='constructor secondary error-list identity must be checked before further startupIO; add binding[6] check',ROOT_rejected=['started=True/pending=False/finished=False/resultNone is deliberate terminal uncertainty, not completion; add explicitpendingFalse test','future retry fragility is irrelevant; retry forbidden','native MRO descriptor bypasses hostile metaclass __getattribute__; slots/shadow claim unsupported; no replacement with attribute access','claimed comprehension typo FALSE: actualcandidate checks current keys correctly; earliestprivate object alreadyretained','claimed constructorerror precedence FALSE: existingctor first checks BEFORE appended startupguard'],ROOT_independent_correction='outer nonoperation failure must not overwrite completed prior I/O row error; optional exact operation argument marks only the actual step; preserve raw return separately before post-check failure',model_review_PRECEDES_v3_hunks_and_newcontrols=True,no_new_model_fullsource_approval=True,new_controls_needed=['lease-succeeds then actual allocation_record returns before root fault: priorlease returnedTrue errorNone','constructorsecondary-list drift during lease: retained callback actualreturnTrue, refuse beforelog-pipeIO'])
 with (p/'ROOT-review-assessment.json').open('x') as f:json.dump(notes,f,indent=2)
 l.verify_identity()
