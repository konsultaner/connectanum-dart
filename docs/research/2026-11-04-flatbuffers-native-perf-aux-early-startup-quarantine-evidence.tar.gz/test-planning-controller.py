import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'test-planning';q.mkdir();methods=json.loads((P/'source-context.json').read_text())['methods']
 context="""NEW early Auxiliary startup resource uncertainty question. Constructor-uncertainty quarantine is consumed/implemented; do NOT repeat those controls. Need NEW meaningful real BEFORE boundaries BEFORE _arm_constructor, not missingAPI failures. Existing old handler invokes repr/defer, closes creator FDs and completes after early log/pipe/flag/lease failure. No actual native SDK/build/workload.
Proposed finite cases: (1) stdout native log+pipe return then actual set_blocking returns before injected OSError; (2) actual pipe returns then wrapper raises before source receives pair (known ROOT-unit handles only, source must retain UNKNOWN attempted operation, never invent actual handles/noactor absence); (3) stderr native log.open returns then wrapper raises, stdout known handles retained; (4) startup lease callback raises hostile-repr originalerror before resource operations; (5) normal actual quiet finite Python child bothstreams + successful publicwait. Earliest raised boundaryerror before binding/report hooks. Each negative records old reporting/close/complete/Popen calls BEFORE assertions and ROOT identity-bound cleanup; no child expected only if actual constructor wrapper records0 calls, not globalabsence. Root closes exact already-known unit descriptors only if native identity matches, no live cleanup/release authority.
Candidate future repair (UNIMPLEMENTED): private startup operation journal/binding precedes each fallible startup IO; retain actual returned object/FDpair privately BEFORE laterIO; unknown returns stay unknown. On pre-constructor failure retain originalerror first, quarantine before oldrepr-defer-close-complete; reuse existing permanent constructor guard without granting waits/settlement. Preserve actual IO arguments/order, successful body, copies/None semantics, allold gates. Earlier __init__ intent writes/generic reader internals/post-constructor reporting and full independent physicalEX remain out of narrow scope.
Give <=180 words: identify key assertions or conceptual flaw. No code, long rationale, or broad restatement. Partial Popen methods/unguarded close/newstagingfile/SDKflags/retry/recovery forbidden.
SOURCE START:\n"""+methods['start']+'\nOLD DEFER:\n'+methods['_defer']
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','1400','--max-input-chars','8000','--max-response-chars','6500','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_sha256=hashlib.sha256(context.encode()).hexdigest(),context_chars=len(context),NEW_early_startup_not_constructor_control_replay=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-900:])
