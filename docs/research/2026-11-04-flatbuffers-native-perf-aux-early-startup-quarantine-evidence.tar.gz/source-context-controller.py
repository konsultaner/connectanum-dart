import sys,pathlib,json,ast,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();s=(R/'tool/native_perf_build_producer.py').read_text();t=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert hashlib.sha256(s.encode()).hexdigest()=='5ba379d7d012b50205f710d1b7f2f061c78bd23b36ad8c67cf4f1fcad270dd82' and hashlib.sha256(t.encode()).hexdigest()=='e05804055dfa799fc6259b76e5bc3b9bce9602e0a2a343b7e00720e08bd93c17'
 c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');lines=s.splitlines()
 wanted={'__init__','start','_close_slot','_defer','_complete','_constructor_guard','_constructor_record','_arm_constructor','_quarantine_constructor','_check','_lease'}
 selected={x.name:'\n'.join(lines[x.lineno-1:x.end_lineno]) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in wanted}
 out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),methods=selected,free_bytes=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize)
 for name,data in [('before-producer.py',s),('before-existing-tests.py',t)]:
  with (P/name).open('x') as f:f.write(data)
 with (P/'source-context.json').open('x') as f:json.dump(out,f,indent=2)
 l.verify_identity();print(json.dumps(out))
