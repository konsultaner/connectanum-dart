import sys,pathlib,json,hashlib,subprocess,datetime,os,ast,copy
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait();slot=len(calls);row=dict(argv=argv,pid=child.pid,status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   with (q/(str(slot)+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest()
  calls.append(row);(q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();prod=run(['diff','--exit-code','HEAD','--','packages','native'])
 expected=json.loads((P/'after-edit-hashes.json').read_text());before=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1/after-edit-hashes.json').read_text())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in expected.items())
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not prod
 assert all(expected[k]==v for k,v in before.items() if 'build_producer.py' not in k)
 old=ast.parse((P/'before-producer.py').read_text());new=ast.parse(source)
 oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 allowed={'__init__','start','_constructor_guard','_startup_guard','_startup_step','_quarantine_startup'}
 assert len(old.body)==len(new.body) and all(ast.dump(x)==ast.dump(y) for x,y in zip(old.body,new.body) if x is not oc)
 assert set(nm)-set(om)=={'_startup_guard','_startup_step','_quarantine_startup'} and all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in allowed)
 projection=copy.deepcopy(nm['__init__']);projection.body=[x for x in projection.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr.startswith('_startup_') for t in x.targets))]
 assert ast.dump(projection)==ast.dump(om['__init__'])
 projection=copy.deepcopy(nm['_constructor_guard']);assert isinstance(projection.body[-1],ast.Expr) and ast.unparse(projection.body[-1])=='self._startup_guard()';projection.body.pop();assert ast.dump(projection)==ast.dump(om['_constructor_guard'])
 class Unwrap(ast.NodeTransformer):
  def visit_Call(self,node):
   node=self.generic_visit(node)
   if isinstance(node.func,ast.Attribute) and node.func.attr=='_startup_step':
    assert len(node.args)==3 and isinstance(node.args[2],ast.Lambda);return node.args[2].body
   return node
 projected=Unwrap().visit(copy.deepcopy(nm['start']))
 beforetry=next(x for x in om['start'].body if isinstance(x,ast.Try));aftertry=next(x for x in projected.body if isinstance(x,ast.Try))
 loops=[x for x in aftertry.body if isinstance(x,ast.For)];assert len(loops)==1
 loops[0].target=ast.Name(id='stream',ctx=ast.Store());loops[0].iter=ast.parse('self.streams.values()',mode='eval').body
 assert ast.dump(ast.Module(body=beforetry.body,type_ignores=[]))==ast.dump(ast.Module(body=aftertry.body,type_ignores=[]))
 assert ast.dump(ast.Module(body=om['start'].body[om['start'].body.index(beforetry)+1:],type_ignores=[]))==ast.dump(ast.Module(body=projected.body[projected.body.index(aftertry)+1:],type_ignores=[]))
 assert tests==(P/'before-existing-tests.py').read_text()+'\n\n'+(P/'new-review-tests.py').read_text()
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(dict(whole_affected_source_test_class_review=True,normal_startup_native_IO_AST_projects_back=True,constructor_original_first_guard_AST_exact_after_new_tail_check=True,all_original_tests_bytes_unchanged=True,other18_helpers_3bins_byteexact=True,all_other_original_functions_factories_gates_publicemitters_ASTexact=True,only_declared_init_start_guard_plus3private_methods=True,model_full_current_approval=False),f,indent=2)
 observations=[];cleanups=[]
 for stage in ('before','before-new-review-controls','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('before-cleanup.json')):
   data=json.loads(path.read_text());observations.append(dict(stage=stage,path=str(path),data=data))
   if stage=='after-selected' and data['mode']!='normal':
    assert all(data['calls'][key]==0 for key in ('repr','defer','complete','close_slot','constructor'))
    assert data['finished'] is False and data['pending'] is False and data['result_is_None']
  for path in sorted((P/stage/'fixtures').rglob('unit-cleanup.json')):
   data=json.loads(path.read_text())
   assert all(type(row['status']) is int and row['status']==0 for row in data if row['kind']=='known_finite_child_method_wait')
   cleanups.append(dict(stage=stage,path=str(path),data=data))
 with (q/'new-precleanup-observations.json').open('x') as f:json.dump(observations,f,indent=2)
 with (q/'new-unit-cleanup-journals.json').open('x') as f:json.dump(cleanups,f,indent=2)
 a=json.loads((P/'before/result.json').read_text());b=json.loads((P/'before-new-review-controls/result.json').read_text());z=json.loads((P/'after-selected/result.json').read_text())
 assert (a['tests'],a['failures'],a['errors'])==(5,4,0) and (b['tests'],b['failures'],b['errors'])==(2,2,0) and (z['tests'],z['failures'],z['errors'])==(10,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=expected['tool/native_perf_build_producer.py'],test_sha256=expected['tool/test_native_perf_build_producer.py'],all23_hashes=expected,NEWbefore5=dict(source='5ba379/e05804',tests=5,failures=4,errors=0,normal_PASS=1),separate_NEWreview_before2=dict(source='5ba379/e05804',tests=2,failures=2,errors=0),AFTERselected10=dict(source='e69a9e/15ad48',tests=10,failures=0,errors=0,new=7,affected=3),not_aggregate_whole_current20canonical_or_runtime_admission=True,source_Git=dict(head=head,branch=branch,exact20_untracked=True,production_packages_native_diffempty=True,four_actual_signed0_BOTH_separate_EOF=True,DATA_only=True),model_planning=json.loads((P/'test-planning/finish.json').read_text()),model_review=json.loads((P/'review/finish.json').read_text()),ROOT_model_qualification=json.loads((P/'ROOT-review-assessment.json').read_text()),model_review_before_v3_hunks_and_two_new_controls_not_full_currentapproval=True,initial_v1v2v3_candidate_artifacts_not_executed_before_edit=True,negative_cases_preconstructor_call_wrapper0_not_global_noactors_proof=True,hidden_actual_pipe_log_returns_ROOTunit_only_source_return_unknown=True,normal_finite_child_methodwait_rows=sum(1 for v in cleanups for r in v['data'] if r['kind']=='known_finite_child_method_wait'),all_unit_cleanup_journal_files=len(cleanups),legacy_required_fixture_and_constructor_actor_FD_API_journals_notall_retained_no_reconstruction=True,one_reviewcontrols_EX_prebody_activecompanion_refusal_zero_actions_then_actualEX=True,before_reviewcontrols_traceback_compilation_label_older_new_tests_path=True,actual_compiled_reviewclass_bytes_be89e6_and_stagecopy_retained_not_traceback_snippet_reconstruction=True,all_named_source_model_test_edit_ROOT_controllers_before_calls=True,other18_helpers_and3bins_byteexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_old_lossless_cleanup_space_change_cause_UNMEASURED=True,no_SDK_native_build_canonical_kernel_broker_benchmark_capture_cleanup_adoption_or_strictacceptance=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_open_draft_base130_issue103_milestone_open=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_early_startup_resource_quarantine'].update(ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW early-startup postcomponent 4Git actual0/BOTHseparateEOF/branchcodex/flatbuffers-native-perf-guard/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Finale69a9e/15ad48 ten selected PASS=7matchingNEW+3affected; ROOTqualified NOTmodelfullcurrentapproval/current20canonical/admission')
 c['active_turn_status']='Aux_early_startup_e69a9e_15ad48_selected10PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],tests=assessment['test_sha256'],NEWbefore5='4FAIL1PASS0ERROR',separate_NEWbefore2='2FAIL0ERROR',AFTERselected10='PASS',unit_cleanup_journal_files=len(cleanups),normal_child_wait_rows=assessment['normal_finite_child_methodwait_rows'],free_bytes=free)))
