import sys,pathlib,json,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1');s=(p/'candidate-producer.py').read_text()
 s=s.replace('    def _constructor_guard(self):\n        self._startup_guard()\n','    def _constructor_guard(self):\n')
 marker="            raise ProducerError('auxiliary constructor outcome quarantined')\n"
 assert s.count(marker)==1;s=s.replace(marker,marker+'        self._startup_guard()\n')
 marker='        for row in journal:\n';assert s.count(marker)==1;s=s.replace(marker,"        if (type(constructor) is not tuple or len(constructor)!=7\n            or constructor[0] is not self._constructor_quarantine\n            or constructor[1] is not self._process_allocation_binding\n            or constructor[2] is not self.streams or type(self.streams) is not dict\n            or any(type(key) is not str for key in self.streams)\n            or self.streams.get('stdout') is not constructor[3] or self.streams.get('stderr') is not constructor[4]\n            or constructor[5] is not self.lease_check):\n            raise ProducerError('auxiliary startup original resources changed')\n"+marker)
 ast.parse(s)
 with (p/'candidate-v2-producer.py').open('x') as f:f.write(s)
 with (p/'ROOT-candidate-static-corrections.json').open('x') as f:json.dump(dict(unexecuted_artifact_only=True,corrections=['place startup guard AFTER existing constructor first-error recovery, preserving earliest constructor error before later startup binding validation','validate original constructor/stream/slot/callback references at every startup step before nativeIO and after return retention'],no_new_failures_or_source_change_claim=True),f,indent=2)
 l.verify_identity()
