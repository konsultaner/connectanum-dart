import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();before=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-type-identity-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in before.items())
 for path,count,fail in [('before/result.json',5,4),('before-new-review-controls/result.json',2,2)]:
  row=json.loads((P/path).read_text());assert (row['tests'],row['failures'],row['errors'])==(count,fail,0)
 old=(R/'tool/native_perf_build_producer.py').read_text();oldtests=(R/'tool/test_native_perf_build_producer.py').read_text();candidate=(P/'candidate-v3-producer.py').read_text();new=(P/'new-review-tests.py').read_text();tests=oldtests+'\n\n'+new
 ot=ast.parse(old);nt=ast.parse(candidate)
 oc=next(x for x in ot.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in nt.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 allowed={'__init__','start','_constructor_guard','_startup_guard','_startup_step','_quarantine_startup'}
 assert all(ast.dump(x)==ast.dump(y) for x,y in zip(ot.body,nt.body) if x is not oc)
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_startup_guard','_startup_step','_quarantine_startup'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in allowed)
 assert ast.dump(ast.parse(tests).body[-1])==ast.dump(ast.parse(new).body[0])
 with (P/'edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_hashes=before,new_behavior='early pre-constructor startup uncertainty permanent refusal; journal actual return separate from checked outcome; normal operations preserved',candidate_v3_unexecuted_BEFORE_edit=True,new_BEFORE5='4FAIL1PASS',separate_NEWreview2='2FAIL',model_review_before_v3_hunks_no_full_current_approval=True),f,indent=2)
 (R/'tool/native_perf_build_producer.py').write_text(candidate);(R/'tool/test_native_perf_build_producer.py').write_text(tests)
 final={name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in before}
 assert all(final[name]==sha for name,sha in before.items() if name not in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'))
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(final,f,indent=2)
 for name,data in [('after-producer.py',candidate),('after-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(data)
 l.verify_identity();print(json.dumps({name:sha for name,sha in final.items() if 'build_producer' in name}))
