class AuxiliaryStartupResourceQuarantineTests(unittest.TestCase):
    def _startup_case(self,mode):
        root=Path(os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])
        base=Path(tempfile.mkdtemp(prefix='aux-startup-',dir=root)).resolve()
        calls={'repr':0,'defer':0,'complete':0,'close_slot':0,'constructor':0}
        phase=['initialization'];known_logs=[];known_pipes=[];writes=[];cleanup=[];child=None
        hook=RuntimeError('foreign startup repr hook')
        class Fault(OSError):
            def __repr__(error):
                calls['repr']+=1
                if mode=='lease':raise hook
                return 'finite startup boundary error'
        error=Fault(5,'injected after original startup operation')
        def lease_check():
            if phase[0]=='start' and mode=='lease':raise error
        aux=producer.AuxiliaryCommand(directory=base,name='early-start',argv=[sys.executable,'-c',
            "import os;os.write(1,b'normal-out');os.write(2,b'normal-err')"],
            cwd=base,environment=dict(os.environ),lease_check=lease_check)
        original_streams=aux.streams;original_slots=tuple(original_streams.values())
        actual_open=Path.open;actual_pipe=os.pipe;actual_block=os.set_blocking;actual_write=producer._write_json
        original_defer=producer.AuxiliaryCommand._defer;original_complete=producer.AuxiliaryCommand._complete
        original_close=producer.AuxiliaryCommand._close_slot;original_allocate=producer.AuxiliaryCommand._allocate_process
        def identity(fd):
            st=os.fstat(fd);return (st.st_dev,st.st_ino,st.st_mode)
        def opening(path,*args,**kwargs):
            value=actual_open(path,*args,**kwargs)
            if path in (base/'early-start.stdout',base/'early-start.stderr'):
                known_logs.append(dict(object=value,fd=value.fileno(),identity=identity(value.fileno()),path=str(path),
                    hidden_from_source=mode=='stderr-open' and path==base/'early-start.stderr'))
                if mode=='stderr-open' and path==base/'early-start.stderr':raise error
            return value
        def piping():
            value=actual_pipe();known_pipes.append(dict(pair=value,identities=tuple(identity(fd) for fd in value),
                hidden_from_source=mode=='pipe' and len(known_pipes)==0))
            if mode=='pipe' and len(known_pipes)==1:raise error
            return value
        def blocking(fd,flag):
            result=actual_block(fd,flag)
            if mode=='blocking' and known_pipes and fd==known_pipes[0]['pair'][0]:raise error
            return result
        def writing(path,value):
            writes.append(Path(path).name);return actual_write(path,value)
        def defer(current,fault):
            calls['defer']+=1;return original_defer(current,fault)
        def complete(current):
            calls['complete']+=1;return original_complete(current)
        def closing(current,stream,slot):
            calls['close_slot']+=1;return original_close(current,stream,slot)
        def allocate(current,record):
            nonlocal child
            calls['constructor']+=1;value=original_allocate(current,record);child=value;return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),
            mock.patch.object(os,'set_blocking',blocking),mock.patch.object(producer,'_write_json',writing),
            mock.patch.object(producer.AuxiliaryCommand,'_defer',defer),
            mock.patch.object(producer.AuxiliaryCommand,'_complete',complete),
            mock.patch.object(producer.AuxiliaryCommand,'_close_slot',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        returned=None;raised=None
        try:
            phase[0]='start'
            for patch in patches:patch.start()
            try:
                try:returned=aux.start()
                except BaseException as caught:raised=caught
                if mode=='normal':
                    self.assertIsNone(raised);self.assertIs(aux,returned)
                    observed=aux.wait(3)
            finally:
                for patch in reversed(patches):patch.stop()
            journal=getattr(aux,'_startup_journal',None)
            data_journal=[] if type(journal) is not list else [dict(stage=row.get('stage'),
                attempted=row.get('attempted'),returned=row.get('returned'),error_is_original=row.get('error') is error,
                value_is_None=row.get('value') is None) for row in journal]
            report=dict(mode=mode,scope='actual native early I/O with ROOT-hidden returned handles in injected cases; no live authority',
                calls=dict(calls),writes=list(writes),raised_is_original=raised is error,raised_is_repr_hook=raised is hook,
                returned_is_self=returned is aux,returned_is_dict=type(returned) is dict,started=aux.started,
                pending=aux.pending,finished=aux.finished,result_is_None=aux.result is None,
                constructor_process_field_is_None=aux.process is None,log_closed=[row['object'].closed for row in known_logs],
                known_pipe_pairs=len(known_pipes),journal=data_journal,
                original_stream_dict_retained=aux.streams is original_streams,
                original_slots_retained=all(any(value is slot for value in aux.streams.values()) for slot in original_slots))
            with (base/'before-cleanup.json').open('x') as out:json.dump(report,out,indent=2)
            if mode=='normal':
                self.assertEqual(1,calls['constructor']);self.assertEqual('success',observed['status'])
                self.assertEqual(0,observed['returncode']);self.assertTrue(aux.finished)
            else:
                self.assertEqual(0,calls['defer']);self.assertEqual(0,calls['complete']);self.assertEqual(0,calls['close_slot'])
                self.assertEqual(0,calls['repr']);self.assertEqual(0,calls['constructor']);self.assertIs(error,raised)
                self.assertTrue(aux.started);self.assertFalse(aux.finished);self.assertIsNone(aux.result)
                self.assertIsNone(aux.error);self.assertIsNone(aux.spawn_error)
                self.assertFalse(any(name.endswith(('-failure.json','-result.json','-spawned.json')) for name in writes))
                self.assertTrue(all(not row['object'].closed for row in known_logs))
                self.assertTrue(report['original_stream_dict_retained']);self.assertTrue(report['original_slots_retained'])
                self.assertIs(type(journal),list);self.assertTrue(journal)
                self.assertIs(error,getattr(aux,'_startup_primary_error',None))
                stage={'blocking':'stdout:reader_nonblocking','pipe':'stdout:pipe','stderr-open':'stderr:log_open','lease':'lease_check'}[mode]
                terminal=next(row for row in journal if row['stage']==stage)
                self.assertIs(True,terminal['attempted']);self.assertIsNot(True,terminal['returned'])
                self.assertIs(error,terminal['error'])
                for row in known_logs:
                    if not row['hidden_from_source']:
                        self.assertTrue(any(item.get('value') is row['object'] for item in journal))
                for row in known_pipes:
                    if not row['hidden_from_source']:
                        self.assertTrue(any(item.get('value') is row['pair'] for item in journal))
        finally:
            # Finite-unit exact ROOT handles only; hidden native returns never source facts.
            if child is not None:
                status=child.wait(3)
                cleanup.append(dict(kind='known_finite_child_method_wait',pid=child.pid,status=status,cached_possible=True))
                self.assertIs(type(status),int);self.assertEqual(0,status)
            for row in known_pipes:
                for fd,wanted in zip(row['pair'],row['identities']):
                    try:actual=identity(fd)
                    except OSError as gone:
                        if gone.errno!=9:raise
                        cleanup.append(dict(kind='unit_pipe',fd=fd,already_invalid=True));continue
                    if actual!=wanted:
                        cleanup.append(dict(kind='unit_pipe',fd=fd,identity_changed_no_close=True));continue
                    os.close(fd);cleanup.append(dict(kind='unit_pipe',fd=fd,identity_matched_close_returned=True))
            for row in known_logs:
                value=row['object']
                if value.closed:cleanup.append(dict(kind='unit_log',fd=row['fd'],already_closed=True));continue
                self.assertEqual(row['identity'],identity(value.fileno()))
                value.close();cleanup.append(dict(kind='unit_log',fd=row['fd'],identity_matched_close_returned=True))
            with (base/'unit-cleanup.json').open('x') as out:json.dump(cleanup,out,indent=2)

    def test_actual_nonblocking_return_then_fault_refuses_cleanup(self):
        self._startup_case('blocking')

    def test_hidden_actual_pipe_return_remains_unknown_no_cleanup(self):
        self._startup_case('pipe')

    def test_hidden_stderr_log_return_preserves_prior_known_resources(self):
        self._startup_case('stderr-open')

    def test_startup_lease_error_never_invokes_repr_hook(self):
        self._startup_case('lease')

    def test_normal_actual_two_stream_startup_and_wait_remain_successful(self):
        self._startup_case('normal')
