import sys,pathlib,json,hashlib,subprocess,datetime,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'review';q.mkdir();before=(P/'before-producer.py').read_text();candidate=(P/'candidate-v2-producer.py').read_text()
 diff=''.join(difflib.unified_diff(before.splitlines(True),candidate.splitlines(True),fromfile='before5ba379',tofile='CANDIDATE_UNIMPLEMENTED'))
 context="""NEW architecture/patch review for early Auxiliary startup-resource uncertainty. Candidate is a private artifact, NOT worktree code/executed/adopted. Actual meaningful NEW5 BEFORE at5ba379/e05804=4FAIL1normalPASS0ERROR. Actual log.open/pipe/set_blocking RETURN in root faultwrapper before injectederror; hidden returned handles ROOTunitONLY, source journal must keep unknown return None and no noactor/globalabsence inference. Hostile startup lease error currently repr-replacesfirst. No old constructor controls replay.
Selected candidate: private journal/binding beforestartupIO; entries before each fallible operation; actual returned refs BEFORE later binding checks/IO. Unknown pre-arm path retainsfirst and permanently refuses oldrepr/defer/close/complete/report/Popen/reentry, reuses ctorquarantine. Guard follows EXISTING ctor first recovery (not before), preserving originalerror precedence. Original mapping/slot/callback refs validated eachstep. Normal IO ordering/args/None-copy semantics/gates/publicsuccess unchanged. Generic helper internals, __init__ intent I/O, post-constructor reporting/complete and full independent physicalEX remain OUTSIDE scope. No newfailure/stagingoutput, wait/recovery/settlement/retry/closedstatus authority. Retainedmetadata not authentication/ABA/physicalclosure or RAM bound.
Qwen25151 planning0 misread target: ROOT rejects olddefer/complete suggestions for pipe+lease errors, invented beforearmbinding, atomic transition claim. Nativepipe/logmayreallyexist even when source call raises; unknown is not empty/absent. Root unit closes only exact known identity handles AFTERprecleanup evidence, never source facts/liveworkaround.
Give <=220words of actual P0/P1/P2 findings or say no issue found WITH scoped limitations. Do not restate design, invent broad requirements, suggest native partial Popen methods or authority from fields. Partial thought/limit is not approval.
WHOLE CANDIDATE SOURCE DELTA:\n"""+diff+'\nWHOLE NEW PRIVATE REGRESSION CLASS (helpers included):\n'+(P/'new-tests.py').read_text()
 assert len(context)<25000
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--reasoning-budget','256','--num-predict','1800','--max-input-chars','26000','--max-response-chars','9000','--timeout','240','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),candidate_UNIMPLEMENTED_NOT_executed=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']
 n['auxiliary_early_startup_resource_quarantine']=dict(path=str(P),source_unchanged='5ba379/e05804',NEW_before5='4FAIL1normalPASS0ERROR',candidate_UNIMPLEMENTED=True,candidate_path=str(P/'candidate-v2-producer.py'),review_pid=child.pid,review_pending=True,fullphysicalEX_and_runtime_admission_INCOMPLETE=True)
 c['active_turn_status']='Aux_early_startup_NEWbefore4FAIL1PASS_source5ba379unchanged_candidateUNIMPLEMENTED_GLMreview';cp.write_text(json.dumps(c,indent=2)+'\n')
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-900:])
