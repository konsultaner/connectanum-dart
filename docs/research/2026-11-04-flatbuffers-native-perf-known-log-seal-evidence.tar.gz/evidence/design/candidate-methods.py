
    def _known_log_raw(self,resource):
        writer=resource['writer']
        if type(writer) is io.FileIO:raw=writer
        elif type(writer) is io.BufferedWriter:raw=writer.raw
        else:raise ProducerError('unknown frozen log writer')
        if type(raw) is not io.FileIO or raw.closefd is not True:
            raise ProducerError('borrowed or unknown frozen log FD')
        forbidden={'flush','close','fileno','write','read','readinto','seek','tell',
            'writable','readable','seekable','raw','closed','closefd','detach'}
        for item in ((writer,) if raw is writer else (writer,raw)):
            keys=tuple(item.__dict__)
            if any(type(k) is not str for k in keys) or any(k in forbidden for k in keys):
                raise ProducerError('frozen log has shadowed IO methods')
        if resource['raw'] is None:resource['raw']=raw
        if raw is not resource['raw']:raise ProducerError('frozen log raw object changed')
        expected=resource['closed_expected']
        if type(expected) is not bool or writer.closed is not expected or raw.closed is not expected:
            raise ProducerError('frozen log closed state changed')
        return raw

    def _known_log_validate(self,resource):
        raw=self._known_log_raw(resource)
        path_info=resource['path'].lstat()
        identity=lambda item:(item.st_dev,item.st_ino,item.st_mode,item.st_uid,item.st_gid,item.st_nlink)
        if resource['closed_expected']:
            if identity(path_info)!=resource['identity']:
                raise ProducerError('closed frozen log path changed')
            return
        import fcntl
        fd=io.FileIO.fileno(raw);info=os.fstat(fd);current=identity(info)
        if (type(fd) is not int or fd<0 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1
            or current!=identity(path_info) or os.get_inheritable(fd) is not False
            or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_WRONLY):
            raise ProducerError('frozen log FD/path/direction changed')
        if resource['fd'] is None:resource['fd']=fd;resource['identity']=current
        if fd!=resource['fd'] or current!=resource['identity']:
            raise ProducerError('frozen log identity changed')

    def _known_log_guard(self):
        if threading.current_thread() is not self._thread or self._known_log_quarantined:
            raise ProducerError('frozen log worker unavailable or quarantined')
        self._known_actor_lease_callback()
        self._check_known_wait_inventory()
        keys=(('recipe',0),)+tuple(('auxiliary',i) for i in range(len(self._known_actor_auxiliaries)))
        bindings=self._known_wait_bindings
        if (type(bindings) is not dict or any(type(k) is not tuple or len(k)!=2
            or type(k[0]) is not str or type(k[1]) is not int for k in bindings)
            or set(bindings)!=set(keys) or len(self._known_log_actor_records)!=len(keys)
            or any(bindings[k] is not row for k,row in zip(keys,self._known_log_actor_records))):
            raise ProducerError('frozen waited actor layout changed')
        for record in self._known_log_actor_records:
            data=record['data'];process=record['process']
            if (record['quarantined'] or record['primary_error'] is not None or record['wait_observed'] is not True
                or type(record['wait_status']) is not int or type(process) is not subprocess.Popen
                or type(process.__dict__.get('returncode')) is not int
                or process.__dict__['returncode']!=record['wait_status']
                or type(data) is not dict or any(type(k) is not str for k in data)
                or data.get('pending') is not True or data.get('finished') is not False or data.get('result') is not None):
                raise ProducerError('frozen actor lacks a checked terminal wait')
            if record['role']=='recipe':
                source=record['source_record'];errors=source.get('output_read_errors')
                if (any(type(k) is not str for k in source) or tuple(source)!=record['source_record_keys']
                    or data.get('log') is not data.get('output_log')
                    or source.get('parent_output_write_close_confirmed') is not True
                    or source.get('output_read_close_error') is not None
                    or (errors is not None and (type(errors) is not list or errors))):
                    raise ProducerError('frozen recipe stream metadata changed')
            for stream in record['streams']:
                if (stream['eof'] is not True or stream['expected_fd'] is not None
                    or type(stream['buffer']) is not bytes or stream['buffer']
                    or stream['close_confirmed'] is not True or stream['write_pending'] is not False):
                    raise ProducerError('frozen read stream closure unresolved')
            self._known_wait_guard(record,self._known_log_lookup)
        data=self._known_actor_producer.__dict__
        if data.get('events') is not self._known_log_writers[-1]['writer']:
            raise ProducerError('frozen journal object changed')
        for resource in self._known_log_writers:self._known_log_validate(resource)
        raws=[id(r['raw']) for r in self._known_log_writers]
        fds=[r['fd'] for r in self._known_log_writers]
        files=[r['identity'][:2] for r in self._known_log_writers]
        if len(set(raws))!=len(raws) or len(set(fds))!=len(fds) or len(set(files))!=len(files):
            raise ProducerError('frozen log writers alias')

    def _cache_known_logs(self,stage):
        rows=[]
        for resource in self._known_log_writers:
            error=resource['first_error']
            error_type=None if error is None else type.__getattribute__(type(error),'__name__')
            row=dict(scope='frozen_known_log_object_facts_only',role=resource['role'],
                index=resource['index'],stream=resource['stream'],stage=stage,
                namespace_reserved=self._known_log_namespace_reserved,
                flush_attempted=resource['flush_attempted'],flush_returned=resource['flush_returned'],
                fsync_attempted=resource['fsync_attempted'],fsync_returned=resource['fsync_returned'],
                close_attempted=resource['close_attempted'],close_returned=resource['close_returned'],
                closed_observed=resource['closed_observed'],quarantined=self._known_log_quarantined,
                error_type=error_type,actor_ownership_complete=None,
                capture_ready=False,source_admitted=False,live_admission=False)
            if any(not any(type(v) is kind for kind in (str,int,bool,type(None))) for v in row.values()):
                raise ProducerError('nonprimitive frozen log observation')
            rows.append(MappingProxyType(row))
        with self._lock:self._known_log_rows=tuple(rows)

    def _known_log_error(self,index,stage,error):
        self._known_log_errors.append((index,stage,error))
        if index is not None:
            resource=self._known_log_writers[index]
            if resource['first_error'] is None:resource['first_error']=error

    def _known_log_io(self,index,step):
        resource=self._known_log_writers[index];writer=resource['writer']
        if step=='flush':
            return io.FileIO.flush(writer) if type(writer) is io.FileIO else io.BufferedWriter.flush(writer)
        if step=='fsync':return os.fsync(resource['fd'])
        if step=='close':
            return io.FileIO.close(writer) if type(writer) is io.FileIO else io.BufferedWriter.close(writer)
        raise ProducerError('unknown frozen log step')

    def _seal_known_logs(self):
        index=None;stage='prepare'
        try:
            if threading.current_thread() is not self._thread:
                raise ProducerError('frozen log sealing requires retained worker')
            keys=(('recipe',0),)+tuple(('auxiliary',i) for i in range(len(self._known_actor_auxiliaries)))
            bindings=self._known_wait_bindings
            if (type(bindings) is not dict or any(type(k) is not tuple or len(k)!=2
                or type(k[0]) is not str or type(k[1]) is not int for k in bindings) or set(bindings)!=set(keys)):
                raise ProducerError('every frozen actor needs a retained selected wait')
            self._known_log_actor_records=tuple(bindings[k] for k in keys)
            resources=[]
            def retain(role,number,name,writer,path):
                resources.append(dict(role=role,index=number,stream=name,writer=writer,path=path,
                    raw=None,fd=None,identity=None,closed_expected=False,first_error=None,
                    flush_attempted=False,flush_returned=None,fsync_attempted=False,fsync_returned=None,
                    close_attempted=False,close_returned=None,closed_observed=None))
            for record in self._known_log_actor_records:
                for stream in record['streams']:
                    retain(record['role'],record['index'],stream['role'],stream['log'],stream['path'])
            op=self._known_actor_producer;data=op.__dict__;directory=data.get('directory')
            retain('producer',-1,'journal',data.get('events'),
                directory/'journal.jsonl' if type(directory) is type(Path()) else None)
            self._known_log_writers=tuple(resources) # ALL available writer handles BEFORE callback/fstat.
            self._known_log_lookup={id(r['writer']):r for r in resources}
            if len(self._known_log_lookup)!=len(resources):raise ProducerError('frozen writer objects alias')
            self._known_actor_lease_callback()
            declared=self._kwargs.get('run_dir')
            if type(declared) not in (str,type(Path())):raise ProducerError('unknown frozen log run directory')
            declared=Path(declared)
            if (type(directory) is not type(Path()) or declared!=directory
                or declared.resolve(strict=True)!=declared):
                raise ProducerError('frozen log run directory changed')
            (declared/'owned-known-logs').mkdir(mode=0o700)
            self._known_log_namespace_reserved=True
            self._cache_known_logs('reserved')
            self._known_log_guard() # Validate ALL writers before first explicit flush.
            self._cache_known_logs('validated')
            for index,resource in enumerate(self._known_log_writers):
                for step in ('flush','fsync','close'):
                    stage=step
                    self._known_log_guard()
                    resource[step+'_attempted']=True
                    self._cache_known_logs(step+'_before')
                    # Cache publication is fallible too; revalidate after it and before native IO.
                    self._known_log_guard()
                    failure=None
                    try:self._known_log_io(index,step)
                    except BaseException as error:
                        resource[step+'_returned']=False;failure=error
                        self._known_log_error(index,step,error)
                    else:resource[step+'_returned']=True
                    if step=='close':
                        closed=resource['writer'].closed;raw_closed=resource['raw'].closed
                        resource['closed_observed']=closed if type(closed) is bool else None
                        if failure is None:
                            if closed is not True or raw_closed is not True:
                                raise ProducerError('frozen log close did not close both exact objects')
                            resource['closed_expected']=True
                    if failure is not None and step!='fsync':raise failure
                    self._cache_known_logs(step+'_after')
                if self._known_log_errors:raise self._known_log_errors[0][2]
            self._known_log_guard()
            self._cache_known_logs('sealed')
            return self.known_log_observations()
        except BaseException as error:
            if not self._known_log_errors or self._known_log_errors[-1][2] is not error:
                self._known_log_error(index,stage,error)
            self._known_log_quarantined=True
            try:self._cache_known_logs('failed')
            except BaseException as secondary:self._known_log_error(None,'observation',secondary)
            raise self._known_log_errors[0][2]

    def seal_known_actor_logs(self):
        return self._schedule('known_log_seal')

    def known_log_observations(self):
        with self._lock:return self._known_log_rows

