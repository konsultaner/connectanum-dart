
    def test_callback_dropped_private_stream_group_cannot_hide_raw_buffer_drift(self):
        owner,op,writers,sentinel,fault=self.prepared()
        record=owner._known_wait_bindings[('recipe',0)]
        original=record['streams'];buffer=op.output_buffer
        def callback():
            if owner._known_log_writers:
                record['streams']=[]
                op.output_buffer=b'OWN-SYNTHETIC-unwritten-marker'
        self.actions['callback']=callback
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            observed=dict(writer_IO_attempts=[list(call.args) for call in calls.call_args_list],
                current_private_streams=len(record['streams']),synthetic_raw_buffer_size=len(op.output_buffer),
                writer_closed_before_fixture_cleanup=[writer.closed for writer in writers],
                negative_writer_IO_mocked=True,no_original_buffer_or_log_replay=True)
            with (self.base/'dropped-stream-control.json').open('x') as f:json.dump(observed,f,indent=2)
            calls.assert_not_called()
            self.assertTrue(all(not w.closed for w in writers));self.assertTrue(owner._known_log_quarantined)
        finally:
            self.actions.pop('callback',None);record['streams']=original;op.output_buffer=buffer

