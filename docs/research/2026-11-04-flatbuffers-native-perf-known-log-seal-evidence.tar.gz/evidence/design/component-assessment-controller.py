import sys,pathlib,json,hashlib,ast,subprocess,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 p=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal');d=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal-design')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 put(p/'assessment-attempt.json',dict(scope='NEW ROOT assessment, retained results/source plus current own Git metadata only',no_tests_models_or_archives_repeated=True,no_recipe_or_SDK=True))
 original=json.loads((p/'original-hashes.json').read_text());final=json.loads((p/'types-fixed-hashes.json').read_text())
 assert len(original)==len(final)==23
 for rel,digest in final.items():assert sha((r/rel).read_bytes())==digest
 changed=[rel for rel in final if final[rel]!=original[rel]]
 assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 def read(stage,rel):return (p/(stage+'-source')/rel).read_text()
 old=ast.parse(read('original','tool/native_perf_build_producer.py'))
 new=ast.parse(read('types-fixed','tool/native_perf_build_producer.py'))
 dump=lambda node:ast.dump(node,include_attributes=False)
 funcs=lambda tree:{n.name:dump(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 assert funcs(old)==funcs(new)
 classes=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
 before=classes(old);after=classes(new);assert before.keys()==after.keys()
 owner='_RetainedPreflightOwner'
 for name in before:
  if name!=owner:assert dump(before[name])==dump(after[name]),name
 methods=lambda cls:{n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)}
 oldmethods=methods(before[owner]);newmethods=methods(after[owner])
 modified=[name for name in oldmethods if dump(oldmethods[name])!=dump(newmethods[name])]
 assert set(modified)=={'__init__','_schedule','_work','_known_wait_guard'}
 added=sorted(set(newmethods)-set(oldmethods))
 assert added==sorted(['_known_log_raw','_known_log_validate','_known_log_guard','_cache_known_logs','_known_log_error','_known_log_io','_seal_known_logs','seal_known_actor_logs','known_log_observations'])
 source=read('types-fixed','tool/native_perf_build_producer.py');lines=source.splitlines()
 affected='\n\n'.join('\n'.join(lines[newmethods[name].lineno-1:newmethods[name].end_lineno]) for name in modified+added)
 with (d/'ROOT-final-affected-methods.txt').open('x') as f:f.write(affected)
 # Final optional closed-log branch is bounded to log FD checks; default callback and read branch stay.
 guard=newmethods['_known_wait_guard'];guard_source='\n'.join(lines[guard.lineno-1:guard.end_lineno])
 assert 'if not closed_log:' in guard_source and "reader=stream['expected_fd']" in guard_source
 assert guard_source.index('if not closed_log:')<guard_source.index("reader=stream['expected_fd']")
 sealer=newmethods['_seal_known_logs']
 forbidden={'_complete','_end_command','_finish','_source_guard','_input_guard','_event','emit_receipt','emit_fixture_receipt'}
 called={n.func.attr if isinstance(n.func,ast.Attribute) else n.func.id for n in ast.walk(sealer) if isinstance(n,ast.Call) and isinstance(n.func,(ast.Attribute,ast.Name))}
 assert not called&forbidden
 # Earlier funcs/classes/test classes remain exact; NEW test class only.
 ot=ast.parse(read('original','tool/test_native_perf_build_producer.py'));nt=ast.parse(read('types-fixed','tool/test_native_perf_build_producer.py'))
 assert funcs(ot)==funcs(nt)
 oc=classes(ot);nc=classes(nt)
 assert set(nc)-set(oc)=={'KnownLogSealTests'}
 for name in oc:assert dump(oc[name])==dump(nc[name]),name
 new_tests=sorted(n.name for n in nc['KnownLogSealTests'].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
 assert len(new_tests)==17
 stages={};controls={};api_reports={}
 for stage in ['before','implemented','test-corrected','newguard-before','final','types-before','types-fixed']:
  report=json.loads((p/(stage+'-tests.json')).read_text())
  actor_rows=[];stream_rows=[];count=0
  for fixture in sorted((p/(stage+'-fixtures')).rglob('fixture-known-actors.json')):
   value=json.loads(fixture.read_text())
   assert value['no_original_buffer_log_replay_or_live_workaround'] is True
   actor_rows.extend(value['actors']);stream_rows.extend(value['streams'])
   for actor in value['actors']:assert type(actor['fixture_actual_same_Popen_final_wait']) is int and actor['fixture_actual_same_Popen_final_wait']==0
   for row in value['streams']:
    raw=(fixture.parent/row['fixture_suffix_file']).read_bytes()
    assert row['fixture_only_independent_drain'] is True
    assert type(row['original_buffer_size']) is int
   count+=1
  stages[stage]=dict(tests=report['tests'],failures=report['failures'],errors=report['errors'],
   recorded_NEW_fixture_actor_rows=len(actor_rows),signed_teardown_statuses=[row['fixture_actual_same_Popen_final_wait'] for row in actor_rows],
   separate_suffix_stream_rows=len(stream_rows),scope='NEW fixture teardown only; not complete negative originalstream integrity or legacy setup/API serialization')
  controls[stage]=[]
  for pattern in ('dropped-stream-control.json','unknown-role-control.json','unknown-record-key-control.json'):
   for path in sorted((p/(stage+'-fixtures')).rglob(pattern)):
    raw=path.read_bytes();controls[stage].append(dict(path=path.relative_to(p).as_posix(),sha256=sha(raw),size=len(raw),observed=json.loads(raw)))
  api_reports[stage]=[]
  for path in sorted((p/(stage+'-fixtures')).rglob('seal-before-fixture-cleanup.json')):
   raw=path.read_bytes();value=json.loads(raw)
   assert value['producer_result_is_none'] is True
   for row in value['rows']:
    assert row['actor_ownership_complete'] is None
    assert all(row[flag] is False for flag in ('capture_ready','source_admitted','live_admission'))
   api_reports[stage].append(dict(path=path.relative_to(p).as_posix(),sha256=sha(raw),size=len(raw),
    rows=value['rows'],producer_pending=value['producer_pending'],producer_finished=value['producer_finished']))
 assert stages['before']['tests']==14 and stages['before']['errors']==14
 assert stages['implemented']['tests']==16 and stages['implemented']['failures']==1 and not stages['implemented']['errors']
 assert stages['test-corrected']['tests']==1 and not stages['test-corrected']['failures']
 assert stages['newguard-before']['failures']==1 and stages['final']['tests']==2 and not stages['final']['failures']
 assert stages['types-before']['failures']==2 and stages['types-fixed']['tests']==3 and not stages['types-fixed']['failures']
 commands=[]
 def git(*args):
  argv=['git','-C',str(r),*args];rec=dict(argv=argv,status=None);commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);rec['pid']=child.pid
  stdout,stderr=child.communicate();rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=p/('root-git-'+str(len(commands))+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_sha256']=sha(raw);rec[label+'_size']=len(raw)
  put(p/('root-git-'+str(len(commands))+'-return.json'),rec)
  assert rec['status']==0
  lease.verify_identity();return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 status=git('status','--porcelain')
 dirty=[line[3:] for line in status.splitlines()]
 expected_dirty={rel for rel in final if rel.startswith('tool/')}
 assert set(dirty)==expected_dirty and len(dirty)==20
 production_diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify')
 assert production_diff==''
 result=dict(kind='known_log_object_sealer_source_component_v1',APIs='seal_known_actor_logs()/known_log_observations()',
 semantics='One permanently terminal action after checked known inventory; privately observed signed waits, same cached Popen status, EOF/emptybuffers/readFDNone/EXACT read close_confirmedTrue for EVERY frozen recipe+retainedaux. Historical readcloseNone refuses; not reconstructed. Original writer objects/logs+journal retained before callbacks/fstat; not whole historical actor/writer inventory.',
 io='Exact owned FileIO/BufferedWriterraw, no shadows/borrowed/aliases; all heldFD-path-singlelink-noninherit-writeonly bindings checked before first and every nativeIO. One explicit flush perwriter; flushFAIL no fsync/close/replay. FsyncFAIL can allow same writer guarded close then stop. One close attempt/native return vs closed props distinct. Nativeclose may implicitlyflush; not kernel-call/durability/physicalEX-release proof.',
 state='Raw producer+aux pendingTrue/finishedFalse/resultNone/refs retained. No endfinish/_complete/audit/spawn/logcontentreadhash/receiptpublication/producerretag/oldauxpredicatewaiver. Existing wait/inventory cache rows historical. Ownerfirsterror exactprivate; selected firstsecondary exactprivate/TYPEONLY/no repr-str-add_note. New observations cache-only/immutable primitive scalars; attempt/privatequarantine, neverpubliccache, govern future refusal. OwnershipNone/all3flagsFalse.',
 fixes='Initial16=15PASS1NEWtest tuple-container-identity assertionFAIL; exact row objects remained unchanged, tuple factory returns newtuple. Corrected1PASS separately/implementation unchanged. NEW dropped-private-stream-group+synthetic rawbuffer1FAIL allowed mocked nativeIO attempts; retained exact stream containers+tuples/cardinality/roles now checked beforeprogress. Fixed2PASS separately. TWO NEWunknownrole/recordkey controls2FAIL actuallyinvoke customeq; typecheck role beforeequality and recipe keys before dictionarylookup, fixed3PASS separately. No actual wrongFD/native data-loss/RAM/canonical defect claimed.',
 scope='17new unittest cases exist, not combined fullfinal suite. Actual finiteOWNPython/FIXTURE/mockedsourcearchiveinput/privateDirsNOTGO/selfdeadlines. Originalfactoryfault after actualctorreturn/laterwaitfault after auxlaunch, not observed originalSDK/buildfailure. Positive sourceAPI nativecloses all actual knownwriterobjects BEFOREfixturecleanup; required legacy cases scopes remain separate. Negative IO seam mocks/syntheticmetadata restores/directdrainclose ONLY unitteardown NEVERliveworkaround. New row/lifecycle reports retained; legacy setup/APIreturns and ALL raw private FD scalarreturns not systematically serialized. No reconstruction.',
 models=dict(orientation=dict(pid=3908,direct_status=0,root_qualification='Gemma describes existingparentsealer, invents new-vs-old comparison/writercreation; objects alreadyexist'),
  judge=dict(pid=4035,direct_status=0,root_qualification='Useful closedlog-beforefileno/retainedidentity/bothclosed/readguard checks. Reject cross-role alias exemption: SAME means each originalwriter. Oneattempt already blocksreseal. Explicit READclosefield clarified. Advisory selectedplan/source only.'),
  tests=dict(pid=4259,direct_status=0,root_qualification='Use real finitepositive/nativeIO, private negativeIOseam; reject syntheticpositive/fake writer.fsync/instance-shadow flush patch/guessederrors/kernelcallcounts.'),
  review=dict(pid=4975,direct_status=1,reason='reachable Ollama tokenlimit; stderr reports9275visiblechars by120s, stdout0/fullpartialfinalassessmentABSENT',reviewed_source_sha256='0bc7aabf53d6e03c5a49914bf9679b8d6a3183cd8ac0e697f7099bbe4e7c1f92',reviewed_test_sha256='6e8012fa144433f6868c33b9baf2d63cde89f36002574b337f99291384da1607',reaped=True,no_unavailability_or_approval=True,no_unchanged_repeat=True),
  ROOT='Whole affected final methods/newtests and AST/file invariants inspected, including postmodel stream-group and typeguards. Not model fullcurrent-source approval.'),
 preserved=dict(original_modulefuncs_factories_emitters_gates=True,AuxiliaryCommand_and_CommandProducer_classes=True,otheroriginalownermethods_testclasses=True,other18tools_selected3bins=True),
 modified_original_owner_methods=modified,added_owner_methods=added,current_source_sha256=final['tool/native_perf_build_producer.py'],
 current_test_sha256=final['tool/test_native_perf_build_producer.py'],source_bundle_hashes=final,stage_results=stages,
 serialized_regression_controls=controls,serialized_NEW_seal_reports=api_reports,
 own_Git_posttest_commands=commands,own_HEAD=head,own_branch=branch,whole_helper_WT_dirty20=True,
 all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,production_native_outputs_or_instructionclosure_not_newly_proved=True,
 remaining='Independent physical officialEX controller/unknown starts/receipt-audit failures, current20 canonical/sourceepoch package/provenance, runtime PATH/SDK/bootstrap/first3locks/hiddenconfigs, OWN productionnative-driver-staticRLIB/compiler-tool-kernel and original-host credential/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage controls incomplete. Freeze owner_emit_attempted refusal remains. No complete immutable admission/provider/liveSession; gate always refuses. No actualSDK/build/native/canonical/kernel/broker/benchmark/capture/sourcecommitpushadoption/strictdispatch/RAMcause-repair-acceptance.',
 free_after=os.statvfs(r).f_bavail*os.statvfs(r).f_frsize,no_cleanup=True,space_change_cause_unmeasured=True)
 put(p/'assessment.json',result)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');x=json.loads(c.read_text());n=x['native_perf_only_diagnostic_design']
 n['known_log_seal_component'].update(assessment=str(p/'assessment.json'),review_pending=False,publication_pending=True,
  ROOT_final_methods_review_pending=False,all_own_model_test_sessions_terminal=True,counts_not_combined_canonical=True,
  before14missingAPIERROR=True,initial16='15PASS1NEWtestassertionFAIL',corrected1PASSseparate=True,
  newstreamdrop1FAIL_fixed2PASSseparate=True,newtypeguards2FAIL_fixed3PASSseparate=True,
  no_physicalbridge_or_admission=True,source_sha256=result['current_source_sha256'],test_sha256=result['current_test_sha256'])
 n['last_free_bytes']=result['free_after'];x['active_turn_status']='known_log_seal_ROOT_assessed_targeted_controls_publication_pending_fullphysicalbridge_incomplete'
 c.write_text(json.dumps(x,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=result['current_source_sha256'],test=result['current_test_sha256'],stages=stages,source_invariants=True,posttestGit_direct_statuses=[row['status'] for row in commands],free=result['free_after'])))
