import sys,pathlib,json,subprocess,hashlib,datetime,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal-design');cache=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal')
 h=json.loads((cache/'test-corrected-hashes.json').read_text())
 current=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 parts=[]
 for rel in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']:
  original=(cache/'original-source'/rel).read_text();final=(cache/'test-corrected-source'/rel).read_text()
  assert hashlib.sha256((current/rel).read_bytes()).hexdigest()==h[rel]
  parts.append(''.join(difflib.unified_diff(original.splitlines(True),final.splitlines(True),fromfile='before/'+rel,tofile='after/'+rel)))
 diff='\n'.join(parts)
 with (p/'final-selected-diff.txt').open('x') as f:f.write(diff)
 prompt='NEW log-object sealer review, max3 concrete correctness bugs with exact methods/trigger. Prior failed owner first error remains original; selected IO first/secondary errors exactPRIVATE. All later actions terminal after attempt. Native flush fail prohibits close; fsync error allows same writer close then stops; failed close never retried. ALL cross-role aliases refuse (SAME means each own original log). Optional _known_wait_guard table skips only previously normally-closed log FD IO, preserves read/progress checks; old default unchanged. Positive tests use actual finite Python and native IO; fixture teardown is not live workaround. No physical EX/descendant/globalatomicity/admission authority; do not invent such claims. Avoid unsupported hypothetical future retry advice; distinguish test/setup failure from implementation bug. ROOT verifies. Assess selected FULL diff; no source/SDK/build/capture execution.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','2600','--max-response-chars','14000','--max-input-chars','75000','--timeout','240','--save-output',str(p/'review.txt'),'--prompt',prompt]
 assert len(diff)<74000
 with (p/'review-command-before.json').open('x') as f:json.dump(dict(argv=argv,input_chars=len(diff),input_sha256=hashlib.sha256(diff.encode()).hexdigest(),source_sha256=h),f,indent=2)
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(diff.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (p/('review-'+label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_size=len(stdout),stderr_size=len(stderr),input_chars=len(diff),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h)
 with (p/'review-finish.json').open('x') as f:json.dump(result,f,indent=2)
 lease.verify_identity();print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}));print(stdout.decode(errors='replace')[-14000:])
