import sys,pathlib,json,subprocess,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal-design')
 source=(p/'plan-v1.json').read_bytes()
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--num-predict','1500','--max-response-chars','9000','--max-input-chars','40000','--timeout','180','--save-output',str(p/'tests.txt'),'--prompt','Give at most5 focused unittest regression scenarios for this NEW UNIMPLEMENTED known-log-object sealer. Prioritize actual finite Python recipe+aux actors and native IO positive proof before fixture teardown, first-error/cache-failure, callback mutation and no replay/reclose. No pytest, fake-process positive proof, canonical/RAM/physical-release claims. Max450words; advisory, ROOT chooses cases.']
 (p/'tests-command-before.json').write_text(json.dumps(dict(argv=argv,input_sha256=hashlib.sha256(source).hexdigest(),no_source_execution=True),indent=2)+'\n')
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(source);status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (p/('tests-'+label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_size=len(stdout),stderr_size=len(stderr),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (p/'tests-finish.json').write_text(json.dumps(result,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
