import sys,pathlib,json,subprocess,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-known-log-seal-design')
 source=(p/'selected-source.txt').read_bytes()
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--stdin','--num-predict','1600','--max-response-chars','9000','--max-input-chars','40000','--timeout','180','--save-output',str(p/'orientation.txt'),'--prompt','Summarize ONLY the selected current owner methods for a NEW independent log-sealing action after successful frozen known-actor wait. State exact writer objects, current bindings/checks that must survive closure, and differences from old parent sealer. Do not propose implementation or claim physical lease/descendant closure. Max450words; use actual field names.']
 (p/'orientation-command-before.json').write_text(json.dumps(dict(argv=argv,input_sha256=hashlib.sha256(source).hexdigest(),no_source_execution=True),indent=2)+'\n')
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(source);status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (p/('orientation-'+label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_size=len(stdout),stderr_size=len(stderr),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (p/'orientation-finish.json').write_text(json.dumps(result,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
