
class KnownLogSealTests(unittest.TestCase):
    """Finite original-object seals; never actor/physical EX/admission authority."""
    done=KnownStreamWaitTests.done
    release=KnownStreamWaitTests.release
    start_partial=KnownStreamWaitTests.start_partial
    initialized=KnownStreamWaitTests.initialized
    ready=KnownStreamWaitTests.ready
    setUp=KnownStreamWaitTests.setUp
    argv=KnownStreamWaitTests.argv
    new_aux=KnownStreamWaitTests.new_aux
    save=KnownStreamWaitTests.save
    freeze=KnownStreamWaitTests.freeze
    row=KnownStreamWaitTests.row
    advance=KnownStreamWaitTests.advance
    complete_actor=KnownStreamWaitTests.complete_actor
    release_all=KnownStreamWaitTests.release_all
    tearDown=KnownStreamWaitTests.tearDown

    def prepared(self,mixed=True,partial=False):
        if partial:
            owner,op,gate,sentinel,fault=self.start_partial()
        else:owner,op,sentinel,fault=self.initialized(mixed=mixed)
        self.freeze(owner);self.release_all();self.complete_actor(owner,'recipe')
        for index in range(len(op.auxiliary_operations)):self.complete_actor(owner,'auxiliary',index)
        writers=[op.output_log]
        for auxiliary in op.auxiliary_operations:
            writers.extend(auxiliary.streams[name]['log'] for name in ('stdout','stderr'))
        writers.append(op.events)
        self.assertTrue(all(not writer.closed for writer in writers))
        return owner,op,writers,sentinel,fault

    def seal(self,owner):
        self.assertIs(owner.seal_known_actor_logs(),owner);self.done(owner)
        rows=owner.known_log_observations();self.assertIs(type(rows),tuple)
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertTrue(any(type(value) is kind for kind in (str,int,bool,type(None))))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertIs(row[flag],False)
        with (self.base/'seal-before-fixture-cleanup.json').open('x') as f:
            json.dump(dict(rows=[dict(row) for row in rows],lifecycle=[dict(row) for row in owner.worker_lifecycle()],
                producer_pending=owner._operation.pending,producer_finished=owner._operation.finished,
                producer_result_is_none=owner._operation.result is None),f,indent=2)
        return rows

    def test_actual_initialized_recipe_aux_logs_and_journal_close_without_retag(self):
        owner,op,writers,sentinel,fault=self.prepared()
        frozen=owner.known_actor_observations();waited=owner.known_actor_wait_observations()
        with mock.patch.object(producer.CommandProducer,'_end_command',side_effect=AssertionError('end')),\
             mock.patch.object(producer.CommandProducer,'_finish',side_effect=AssertionError('finish')),\
             mock.patch.object(producer.AuxiliaryCommand,'_complete',side_effect=AssertionError('complete')):
            rows=self.seal(owner)
        self.assertEqual(4,len(rows));self.assertTrue(all(w.closed for w in writers))
        self.assertTrue(all(r['close_returned'] is True and r['closed_observed'] is True for r in rows))
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
        self.assertTrue(all(a.pending and not a.finished and a.result is None for a in self.aux))
        self.assertIs(owner._first_error_object,fault);self.assertFalse(sentinel.exists())
        self.assertIs(frozen,owner.known_actor_observations());self.assertIs(waited,owner.known_actor_wait_observations())
        self.assertIs(op.log,writers[0]);self.assertIs(op.events,writers[-1])

    def test_actual_uninitialized_recipe_and_journal_close(self):
        owner,op,writers,sentinel,fault=self.prepared(partial=True)
        rows=self.seal(owner);self.assertEqual(2,len(rows));self.assertTrue(all(w.closed for w in writers))
        self.assertFalse(owner.observe(0)['initialized']);self.assertIs(owner._first_error_object,fault)
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertFalse(sentinel.exists())

    def test_missing_selected_aux_wait_refuses_before_any_writer_IO(self):
        owner,op,sentinel,fault=self.initialized(mixed=True)
        self.freeze(owner);self.release_all();self.complete_actor(owner,'recipe')
        with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
        calls.assert_not_called();self.assertTrue(owner._known_log_quarantined)
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed)
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()

    def test_unknown_read_close_confirmation_is_never_reconstructed(self):
        owner,op,writers,sentinel,fault=self.prepared()
        record=owner._known_wait_bindings[('recipe',0)];stream=record['streams'][0]
        stream['close_confirmed']=None
        with mock.patch.object(type(owner),'_known_log_io') as calls:rows=self.seal(owner)
        calls.assert_not_called();self.assertIsNone(stream['close_confirmed'])
        self.assertTrue(owner._known_log_quarantined);self.assertTrue(all(not w.closed for w in writers))

    def test_flush_failure_never_fsyncs_or_closes(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN explicit flush failure');calls=[]
        def operation(current,index,step):
            calls.append((index,step))
            if step=='flush':raise failure
            return actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertEqual([(0,'flush')],calls);self.assertTrue(all(not w.closed for w in writers))
        self.assertIs(owner._known_log_errors[0][2],failure);self.assertTrue(rows[0]['quarantined'])
        self.assertFalse(rows[0]['close_attempted'])

    def test_fsync_failure_permits_one_actual_close_then_stops(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN fsync failure');calls=[]
        def operation(current,index,step):
            calls.append((index,step))
            if step=='fsync':raise failure
            return actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertEqual([(0,'flush'),(0,'fsync'),(0,'close')],calls)
        self.assertTrue(writers[0].closed);self.assertTrue(all(not w.closed for w in writers[1:]))
        self.assertIs(owner._known_log_errors[0][2],failure)
        self.assertIs(rows[0]['fsync_returned'],False);self.assertIs(rows[0]['close_returned'],True)

    def test_actual_close_then_error_never_recloses(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io;failure=OSError(5,'OWN after native close');calls=[]
        def operation(current,index,step):
            calls.append((index,step));result=actual(current,index,step)
            if step=='close':raise failure
            return result
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertTrue(writers[0].closed);self.assertEqual(1,calls.count((0,'close')))
        self.assertIs(rows[0]['close_returned'],False);self.assertIs(rows[0]['closed_observed'],True)
        index=owner._index
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertEqual(index,owner._index);self.assertIs(owner._known_log_errors[0][2],failure)

    def test_normal_close_return_with_open_objects_quarantines(self):
        owner,op,writers,sentinel,fault=self.prepared()
        actual=type(owner)._known_log_io
        def operation(current,index,step):
            return None if step=='close' else actual(current,index,step)
        with mock.patch.object(type(owner),'_known_log_io',operation):rows=self.seal(owner)
        self.assertFalse(writers[0].closed);self.assertIs(rows[0]['close_returned'],True)
        self.assertIs(rows[0]['closed_observed'],False);self.assertTrue(rows[0]['quarantined'])

    def test_callback_pending_drift_refuses_before_native_writer_IO(self):
        owner,op,writers,sentinel,fault=self.prepared()
        self.actions['callback']=lambda:setattr(op,'pending',False)
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            calls.assert_not_called();self.assertTrue(all(not w.closed for w in writers))
        finally:self.actions.pop('callback',None);op.pending=True

    def test_writer_alias_refuses_without_close(self):
        owner,op,writers,sentinel,fault=self.prepared()
        original=op.events;op.events=op.log
        try:
            with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
            calls.assert_not_called();self.assertFalse(op.log.closed)
        finally:op.events=original

    def test_namespace_collision_is_permanently_terminal(self):
        owner,op,writers,sentinel,fault=self.prepared()
        namespace=op.directory/'owned-known-logs';namespace.mkdir()
        with mock.patch.object(type(owner),'_known_log_io') as calls:self.seal(owner)
        calls.assert_not_called();self.assertTrue(namespace.is_dir())
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertTrue(all(not w.closed for w in writers))

    def test_flush_primary_cache_secondary_exact_private_no_exception_hooks(self):
        owner,op,writers,sentinel,fault=self.prepared()
        hooks=[]
        class HookError(OSError):
            def __repr__(self):hooks.append('repr');raise AssertionError('repr')
            def __str__(self):hooks.append('str');raise AssertionError('str')
            def add_note(self,note):hooks.append('note');raise AssertionError('note')
        primary=HookError(5,'OWN first flush');secondary=ValueError('OWN failed cache')
        actual=type(owner)._cache_known_logs
        def cache(current,stage):
            if stage=='failed':raise secondary
            return actual(current,stage)
        with mock.patch.object(type(owner),'_known_log_io',side_effect=primary),\
             mock.patch.object(type(owner),'_cache_known_logs',cache):
            self.seal(owner)
        self.assertIs(owner._known_log_errors[0][2],primary);self.assertIs(owner._known_log_errors[-1][2],secondary)
        self.assertIs(owner._workers[-1]['_call_error_object'],primary);self.assertEqual([],hooks)
        self.assertTrue(all(not w.closed for w in writers))
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()

    def test_busy_worker_observer_outside_IO_lock_and_terminal_refusal(self):
        owner,op,writers,sentinel,fault=self.prepared()
        entered=self.threading.Event();release=self.threading.Event();self.barriers.append(release)
        def callback():
            self.assertTrue(owner._lock.acquire(False));owner._lock.release()
            entered.set();release.wait(3)
        self.actions['callback']=callback
        owner.seal_known_actor_logs();self.assertTrue(entered.wait(2))
        owner.known_log_observations();index=owner._index
        with self.assertRaises(producer.ProducerError):owner.seal_known_actor_logs()
        self.assertEqual(index,owner._index);release.set();self.done(owner);self.actions.pop('callback',None)
        self.assertTrue(all(w.closed for w in writers))
        with self.assertRaises(producer.ProducerError):owner.continue_known_actor_wait('recipe',0,0)

    def test_success_keeps_exact_writer_refs_and_refuses_all_pipeline_actions(self):
        owner,op,writers,sentinel,fault=self.prepared()
        self.seal(owner);index=owner._index
        for action in (lambda:owner.seal_known_actor_logs(),lambda:owner.continue_wait(0),
            lambda:owner.continue_known_actor_wait('auxiliary',0,0),lambda:owner.freeze_known_actors()):
            with self.assertRaises(producer.ProducerError):action()
        self.assertEqual(index,owner._index);self.assertTrue(all(w.closed for w in writers))
        self.assertFalse(sentinel.exists());self.assertIs(op.output_log,writers[0]);self.assertIs(op.events,writers[-1])

