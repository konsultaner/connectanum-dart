import sys,pathlib,json,hashlib,shutil,unittest,importlib.util,io,datetime
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1')
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'before-NEW3';q.mkdir();free=shutil.disk_usage(R).free;assert free>=1024**3
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1/harness-cleanup-v1/after-edit-hashes.json').read_text())
 actual={rel:hashlib.sha256((R/rel).read_bytes()).hexdigest() for rel in expected};assert actual==expected
 (q/'current23hashes.json').write_text(json.dumps(actual,indent=2));(q/'floor.json').write_text(json.dumps({'free_bytes':free,'test_1GiB_open':True,'no_build_capture_authority':True}))
 (P/'before-producer.py').write_bytes((R/'tool/native_perf_build_producer.py').read_bytes());(P/'before-tests.py').write_bytes((R/'tool/test_native_perf_build_producer.py').read_bytes())
 import os
 os.environ['CONNECTANUM_ARCHIVE_CATCH_FIXTURES']=str(q/'fixtures')
 sys.path.insert(0,str(R/'tool'))
 spec=importlib.util.spec_from_file_location('archive_catch_regressions',P/'archive_constructor_catch_regressions-v1.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   leases.append({'test':str(test),'position':'before','raw_None':l.verify_identity() is None});super().startTest(test)
  def stopTest(self,test):
   leases.append({'test':str(test),'position':'after','raw_None':l.verify_identity() is None});super().stopTest(test)
 stream=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromTestCase(module.ArchiveConstructorCatchTests)
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(suite)
 (q/'stdout.txt').write_text(stream.getvalue())
 out={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passes':result.testsRun-len(result.failures)-len(result.errors),'leases':leases,'details':[{'test':str(t),'traceback':tb} for t,tb in result.failures+result.errors],'source_sha256':actual['tool/native_perf_build_producer.py'],'test_sha256':actual['tool/test_native_perf_build_producer.py'],'no_old_control_replay':True,'not_currentcanonical_admission':True}
 (q/'result.json').write_text(json.dumps(out,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['archive_constructor_catch_progress']={'directory':str(P),'declaration':str(P/'declaration.json'),'before':out,'Source_changed':False,'furtherwork_pending':True};c.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_turn_status='Archive_constructor_catch_NEW3_BEFORE_recorded_ROOTpending');cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:v for k,v in out.items() if k not in ('details','leases')}));print(stream.getvalue()[-9000:])
