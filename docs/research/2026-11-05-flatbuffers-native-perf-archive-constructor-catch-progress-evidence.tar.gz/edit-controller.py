import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();expected=json.loads((P/'before-NEW3'/'current23hashes.json').read_text());actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert actual==expected
 source=(P/'candidate-producer-v1.py').read_text();tests=(P/'candidate-tests-v1.py').read_text();parts=json.loads((P/'projection-parts-v1.json').read_text())
 old=(R/'tool/native_perf_build_producer.py').read_text();oldtests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert source.replace(parts['new_catch'],parts['old_catch'],1)==old
 assert tests==oldtests+'\n\n'+parts['append'];assert tests.startswith(oldtests)
 def methods(s):
  t=ast.parse(s);return {c.name+'.'+f.name:ast.get_source_segment(s,f) for c in t.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef)}
 before=methods(old);after=methods(source);changed=[k for k in before if before[k]!=after[k]];assert changed==['CommandProducer.__init__']
 (R/'tool/native_perf_build_producer.py').write_text(source);(R/'tool/test_native_perf_build_producer.py').write_text(tests)
 final={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected}
 assert all(v==expected[k] for k,v in final.items() if k not in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'))
 (P/'after-edit-hashes.json').write_text(json.dumps(final,indent=2));(P/'after-producer.py').write_text(source);(P/'after-tests.py').write_text(tests)
 receipt=dict(source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],only_existing_method_changed=changed,Source_whole_BYTEprojectback=True,oldtest_PREFIX_exact=True,other18helpers3bins_unchanged=True,no_build_capture_adoption=True)
 (P/'edit-result.json').write_text(json.dumps(receipt,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['archive_constructor_catch_progress'].update(edit=receipt,Source_changed=True,after_pending=True);n['current_source_sha256']=final;c['active_turn_status']='Archive_constructor_catch_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps(receipt))
