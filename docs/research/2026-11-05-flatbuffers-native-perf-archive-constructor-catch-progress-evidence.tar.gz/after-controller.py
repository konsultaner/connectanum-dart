import sys,pathlib,json,hashlib,shutil,unittest,importlib.util,io,datetime,os
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'after-selected6';q.mkdir();free=shutil.disk_usage(R).free;assert free>=1024**3
 hashes=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in hashes.items())
 (q/'floor.json').write_text(json.dumps(dict(free_bytes=free,test_1GiB_open=True,no_build_capture_authority=True)))
 os.environ['CONNECTANUM_ARCHIVE_CATCH_FIXTURES']=str(q/'new-fixtures');os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(q/'affected-fixtures')
 sys.path.insert(0,str(R/'tool'));import test_native_perf_build_producer as t
 b=t.producer;original=b.AuxiliaryCommand._allocate_process;actors=[]
 def allocated(owner,record):
  process=original(owner,record);actors.append(dict(process=process,bound_wait=process.wait,pid=process.pid,argv=list(owner.argv)));return process
 b.AuxiliaryCommand._allocate_process=allocated
 leases=[];root_waits=[];offset=[0]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   offset[0]=len(actors);leases.append(dict(test=str(test),position='before',raw_None=l.verify_identity() is None));super().startTest(test)
  def stopTest(self,test):
   before=[dict(pid=x['pid'],argv=x['argv']) for x in actors[offset[0]:]]
   idx=len(root_waits);(q/f'ROOT-known-actors-{idx}-before-wait.json').write_text(json.dumps(dict(test=str(test),actors=before,no_Source_method_or_field_cleanup=True),indent=2))
   rows=[]
   for a in actors[offset[0]:]:
    try:
     raw=a['bound_wait'](10);rows.append(dict(pid=a['pid'],status=raw,signed_native_int=type(raw) is int,wait='same_original_bound_10',unit_only=True))
    except BaseException as error:rows.append(dict(pid=a['pid'],status=None,error_type=type(error).__name__,no_retry=True))
   root_waits.append(dict(test=str(test),rows=rows))
   (q/'ROOT-original-waits.json').write_text(json.dumps(root_waits,indent=2))
   leases.append(dict(test=str(test),position='after',raw_None=l.verify_identity() is None));super().stopTest(test)
 selected=[t.ArchiveConstructorCatchTests(name) for name in unittest.defaultTestLoader.getTestCaseNames(t.ArchiveConstructorCatchTests)]
 selected += [t.ProducerTests(name) for name in ('test_dirty_source_refused_before_command','test_wrong_archive_refused_before_command','test_head_drift_refused_before_command')]
 stream=io.StringIO()
 try:result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(unittest.TestSuite(selected))
 finally:b.AuxiliaryCommand._allocate_process=original
 (q/'stdout.txt').write_text(stream.getvalue());out=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),leases=leases,root_original_waits=root_waits,source_sha256=hashes['tool/native_perf_build_producer.py'],test_sha256=hashes['tool/test_native_perf_build_producer.py'],details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],selected=[str(x) for x in selected],no_old27_replay_or_currentcanonical_admission=True)
 (q/'result.json').write_text(json.dumps(out,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['archive_constructor_catch_progress'].update(after=out,after_pending=False,ROOT_pending=True);c.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_turn_status='Archive_constructor_catch_AFTER6_recorded_ROOTpending');cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps({k:v for k,v in out.items() if k not in ('details','leases','root_original_waits','selected')}));print(stream.getvalue()[-7500:])
