import sys,pathlib,json,ast,hashlib,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();old=(P/'before-NEW3-v2'/'before-producer.py').read_text();tests=(P/'before-NEW3-v2'/'before-tests.py').read_text()
 block="""        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self._defer_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise"""
 assert old.count(block)==1
 replacement="""        except BaseException as error:
            group=_failure_preservation_group(self,error)
            try:
                if self.pending:
                    # Preserve the actual owned child and return its waitable handle.
                    self._defer_failure(error)
                else:
                    self.finished=True
                    self._preserve_failure(error)
                    raise
            except BaseException as secondary:
                if secondary is error:raise
                group[2](secondary)"""
 new=old.replace(block,replacement,1);assert new.replace(replacement,block,1)==old
 added=(P/'archive_constructor_catch_regressions-v2.py').read_text();newtests=tests+'\n\n'+added
 ast.parse(new);ast.parse(newtests)
 (P/'candidate-producer-v1.py').write_text(new);(P/'candidate-tests-v1.py').write_text(newtests)
 (P/'projection-parts-v1.json').write_text(json.dumps({'old_catch':block,'new_catch':replacement,'oldtests_PREFIX_exact':True,'append':added},indent=2))
 (P/'candidate.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before',tofile='candidate')))
 selected=[]
 for n in ast.parse(new).body:
  if isinstance(n,ast.FunctionDef) and n.name=='_failure_preservation_group':selected.append(ast.get_source_segment(new,n))
  if isinstance(n,ast.ClassDef) and n.name=='CommandProducer':
   selected += [ast.get_source_segment(new,f) for f in n.body if isinstance(f,ast.FunctionDef) and f.name in ('__init__','_git')]
 (P/'candidate-selected-v1.py').write_text('\n\n'.join(selected))
 setup=json.loads(next((P/'before-NEW3'/'fixtures').glob('*/setup-commands.json')).read_text())
 correction={'prior_v2_declaration_setup_count_correction':'seven setup Git commands per case, not eight; actual native records authoritative','v1_3setupERROR_Source0_target0':True,'old_v1_frozen':True,'v2_first_target_NEW3':'1FAIL2PASS0ERROR','v1_setup_commands_per_case':len(setup),'candidate_UNEXECUTED_before_Source_edit':True,'AFTER_proposed':['matchingNEW3','ProducerTests.test_dirty_source_refused_before_command','ProducerTests.test_wrong_archive_refused_before_command','ProducerTests.test_head_drift_refused_before_command'],'no_old25_old2_old7_replay':True}
 (P/'candidate-declaration.json').write_text(json.dumps(correction,indent=2));l.verify_identity();print(json.dumps(correction))
