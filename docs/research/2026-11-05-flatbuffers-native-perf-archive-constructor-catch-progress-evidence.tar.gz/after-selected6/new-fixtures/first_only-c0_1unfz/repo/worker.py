import os
os.write(1,b'ARCHIVE-CATCH-NEW-out')
os.write(2,b'ARCHIVE-CATCH-NEW-err')
