import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-archive-constructor-catch-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='455273e473c7656282c6ea28479f95088cf82a7b'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Retain archive constructor errors before the catch reads metadata\n\nA new controlled regression completes an actual fixture Git archive, then raises First after the snapshot constructor returns only to ROOT. A subsequent producer pending getter raises Secondary. The original constructor catch allowed Secondary to replace First. Three new cases before the fix produce 1FAIL/2PASS/0ERROR; the normal metadata and distinct finite recipe controls already pass.\n\nThe catch now obtains its existing private first-error group before reading pending. Its original body remains inside a try: the same escaping error is rethrown unchanged, while a distinct secondary failure uses the existing private refusal. All six selected after tests pass: the matching three new cases and three constructor-refusal callers. Earlier pendingTrue deferral, helper acquisition, bindings and transitive actors remain outside this executed scope. Other existing Source bytes and the old test prefix are exact.\n\nThe first harness attempt has three preserved setup errors before any producer constructor; a fresh corrected attempt executes the target for the first time. A separate collector count error is corrected from saved data without rerunning tests, models or Source census. Both advisory calls reach token limits with no final answer; ROOT independently qualifies the patch and evidence. Known finite waits, source order and FD checks remain unit data. Source is uncommitted, uncanonical and unadmitted. RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-archive-constructor-catch-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: retain archive errors before constructor metadata'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['archive_constructor_catch_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Continue with a meaningful NEW predeclared question about constructor pendingTrue deferral after earlier private-group acquisition, or earlier group/row/try/metadata bindings and higher archive failure handling; no edit without real BEFORE-failing regression. Current Sourceae1d1a/test0265f8 changes only CommandProducer.__init__ catch: private first group BEFOREpending metadata, original body wrapped, sameerror bare rethrow preserving normal quarantine state, differentSecondary existingrefuse raisesOriginalFirst. BEFORE NEW3 at350759/43e6e0=1FAIL2PASS0ERROR after actualfixtureGitarchive, unknownsnapshotRootobject neverSourceadopted; pending nativeFalse thenSecondary masksFirst. Finalselected6PASS=matchingNEW3+3constructorrefusal callers(dirty/wrongarchive/headdrift), once; old27/25/2oldbodies/old7suite NEVERreplayed/currentcanonicalinference. WholeSourceBYTEprojectback/oldtestPREFIXexact; helper-oldauxpredicates-owner_emit_attempted untouched. Privatev1three setupERROR moduleattribute beforeSource0/target0 after7Gitsetupcommands percase; terminal/raws; v2firsttarget capturesactualAuxmethod+recipePopen setterbeforeSourcepublication, metadatafieldsneverSourceauthority. RootprivateNEW17waitrows eachphase include recipe; parentAFTER23=16sameNEW3Aux+7affected (doNOTaddduplicates), allsigned0cachedpossible; sixviews/rootclose1before1after AFTERevidence, EX6before12afterNone UNITnotfullphysicalEX-originalLinux/FD-interpreter-delegate-descendantclosure/admission. Rootv1oracleexpected24 wrongactual23 failedbeforemodels-Git4-assessment; v2correctsavedDATA/no Sourcecensus-unit-model-replay/firstGit4. Setup7not8 correctedcandidate-declaration. Qwen98741limit1/0out443err/GLM99726limit1/0out983err/BOTH EOF-naturalreaped/fullpartialfinalBOTH_ABSENT/notreconstructed/reachableNOTunavailable-approval/no unchangedreviewretry; ROOT independently qualifies finalSource-tests-order. Source23hashes verifiedROOTv1, v2saveddata+4freshSourceGit0-BOTH/HEAD601branch20untracked-productiontrackedempty DATA/notcompiled-admission. All20uncommitteduncanonicalunadmitted/no Sourcecommit-push-adoption-SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-strictdispatch. PendingTrue and earlier acquisition/binding/interiors/concurrentABA-historicaltransitive/fulloriginalruntimeimmutableCOMPLETEadmission INCOMPLETE. Strongowners/groups/closures/rawchunksprocesslife NOTfixedmemory/heapRSSgrowth-allocvolume-timing-leakcauseUNMEASURED/no RAMrepair-memorybound-trim-pop-reset-evict-deleteauthority. UnknownPopenCtorPERMANENT/no partialmethods-fieldderivedsettlement; fields/status/EOF/FDclosed DATAneverEXrelease-ownership/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Archive_constructor_catch_selected6PASS_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
