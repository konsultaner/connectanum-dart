import sys,pathlib,json,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-archive-constructor-catch-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();parts=json.loads((P/'projection-parts-v1.json').read_text())
 assert source==(P/'candidate-producer-v1.py').read_text() and tests==(P/'candidate-tests-v1.py').read_text()
 assert source.replace(parts['new_catch'],parts['old_catch'],1)==(P/'before-NEW3-v2'/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'archive_constructor_catch_regressions-v2.py').read_text()
 bad=json.loads((P/'before-NEW3'/'result.json').read_text());before=json.loads((P/'before-NEW3-v2'/'result.json').read_text());after=json.loads((P/'after-selected6'/'result.json').read_text())
 assert (bad['tests'],bad['failures'],bad['errors'])==(3,0,3)
 assert all("has no attribute '_allocate_process'" in x['traceback'] for x in bad['details'])
 assert (before['tests'],before['failures'],before['errors'])==(3,1,0)
 assert (after['tests'],after['failures'],after['errors'])==(6,0,0)
 assert len(before['leases'])==6 and len(after['leases'])==12 and all(x['raw_None'] for x in before['leases']+after['leases'])
 controls={};viewdata={}
 for label,folder in [('BEFORE',P/'before-NEW3-v2'/'fixtures'),('AFTER',P/'after-selected6'/'new-fixtures')]:
  rows=[];waitcount=0;closed=0
  for d in sorted(folder.iterdir()):
   v=json.loads((d/'view-before-ROOT-cleanup.json').read_text());k=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text())
   assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup)
   for i,x in enumerate(setup):
    for channel in ('stdout','stderr'):
     raw=(d/f'setup-{i}-{channel}.bin').read_bytes();assert len(raw)==x[channel+'_size'] and hashlib.sha256(raw).hexdigest()==x[channel+'_sha256']
   assert not v['snapshot_root_object_registered']
   status=[x for x in k['rows'] if x['kind']=='original_bound_wait'];assert all(x['status']==0 and x['signed_native_int'] for x in status);waitcount+=len(status)
   closed+=sum(x.get('closed_by_ROOT',False) for x in k['rows'] if x['kind']=='file')
   mode=v['archive_constructor_catch']
   if mode=='pending':
    assert v['pending_native_false'] and v['pending_fault'] and v['Source_pending'] is False and v['Source_finished'] is False and not v['Source_returned_object'] and not v['source_tar_exists']
    if label=='BEFORE':assert v['received_Secondary'] and not v['received_First'] and not v['captured_groups']
    else:assert v['received_First'] and not v['received_Secondary'] and v['captured_private_guard_First']
   if mode=='first_only':assert v['received_First'] and not v['Source_returned_object'] and not v['source_tar_exists']
   if mode=='normal':assert v['normal_result_status']=='success' and v['Source_returned_object'] and v['source_tar_exists']
   rows.append(v)
  assert len(rows)==3 and waitcount==17 and closed==1
  controls[label]=dict(newviews=3,root_original_bound_wait_rows=waitcount,all_signed0=True,Root_file_closes_afterevidence=closed)
  viewdata[label]=rows
 parent=[r for row in after['root_original_waits'] for r in row['rows']];assert len(parent)==24 and all(r['status']==0 and r['signed_native_int'] for r in parent)
 models={}
 for name in ('planning','review'):
  result=json.loads((P/name/'result.json').read_text());assert result['status']==1 and result['both_separate_EOF'] and result['stdout_size']==0 and not (P/name/'answer.txt').exists();models[name]=result
 q=P/'ROOT-source-Git';q.mkdir();commands=[]
 def git(args):
  idx=len(commands);argv=['git',*args]
  (q/f'{idx}-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);bound=child.wait
  (q/f'{idx}-start.json').write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=bound(10);(q/f'{idx}-stdout.bin').write_bytes(out);(q/f'{idx}-stderr.bin').write_bytes(err)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/'commands.json').write_text(json.dumps(commands,indent=2));assert status==0 and not err;return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 status=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert len(status)==20 and all(s.startswith('?? tool/') for s in status) and {s[3:] for s in status}=={k for k in h if k.startswith('tool/')}
 assert git(['diff','601108ea6216464bd00ae29c16cfaf0a59c71db6','--stat','--','packages','native'])==b''
 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],v1_setupERROR_frozen=bad,before_NEW3=before,after_selected6=after,controls=controls,parent_after_original_bound_wait_rows24_includes_sameNEW17_and_affected7=True,selected_views=viewdata,models=models,wholeSource_BYTEprojectback=True,only_existing_method_changed='CommandProducer.__init__',oldtest_PREFIX_exact=True,other18helpers3bins_unchanged=True,current23hashes_sourceGit4_0_BOTH=True,SourceGit=commands,limits=json.loads("[\"Only pending-getter catch gap executed: BEFORE NEW3 1FAIL2PASS0ERROR at350759/43e6e0; actualGit archive SourceAux completes then actual_FileSnapshotAttempt returns ROOT-only object andRootFirst; pending nativeFalse thenSecondary masksFirst. NormalmetadataFirst and distinct normal finite recipe controls alreadyPASS. This is one controlledfirstreplacement, not nativekernelbug/RAMcause.\",\"Finalae1d1a/0265f8 AFTER6PASS=matchingNEW3+3constructorrefusal callers(dirty source/wrong archive/head drift), once. No old27-completed25-old2bodies-old7suite rerun; prior25PASS2ERROR staysfrozen/separate, futurefixtureNEW3 staysseparate. No aggregate current20canonical. PendingTrue deferral branch and earlier catchgroup acquisition/bindings/interiors/concurrentABA/higherhistoricaltransitive actors remain unexecuted/unproved.\",\"Minimal existingCommandProducer.__init__catch only: existingfailuregroup capturesFirst BEFOREpending metadata; originalcatchbody inside try; identicalerror bare rethrow preserves normal helper quarantine state; distinctSecondary ->existingprivate refuse raisesFirst. Originalhelper/othermethodsclassesfunctions-oldauxpredicates-owner_emit_attempted exact/wholeSourceBYTEprojectback/oldtestPREFIXexact+v2NEW3append. Source pendingFalse/finishedFalse aftergetterfault staysDATA/no Sourcefieldrestore. UnknownsnapshotRootobject neverregistered-adopted-run; no returnedProducerafternegative/no partialPopenmethods-fieldderivedsettlement.\",\"Privatev1 BEFORE3setupERROR atwrongmodule_allocate_process lookup AFTER7nativeGitsetupcommands percase BEFORESource constructor0-target0. ALLv1raws terminal/protected/no repeat. V2correct actualAuxiliaryCommand._allocate_process method and bounded recipeprocess setter retain confirmedoriginalPopen/boundwait BEFORESourceIO/publication; no Popenclass/globalmodulepatch/proxyPID/credentialsSDKchanges. V2firstactualNEW3 BEFORE. Declaration initially said8setupcommands; actual7 correctedinnewcandidate-declaration beforeSourceedit. Controllers defined beforecalls; initialplanningcontroller file savedAFTERactualplanning API, notfile-before-exec claim.\",\"6newviews3BEFORE3AFTER; nativeSourceactors/rootboundwaitrows17each(4Firstnormalmetadata+9normalrecipe+4pending), all signed0/cachedpossible; Rootknownfileclose1before1after pendingcase AFTERevidence only. ParentAFTER Root24sameoriginalboundwaitrows include17sameNEW3actors plus7affected SourceAux, not41distinctactors. ParentCURRENT officialDarwinEX6BEFORE12AFTERNone observations UNITnotfullphysicalEX-originalLinuxcredentials/fullFD-interpreter-delegate-descendantclosure-liveownership-admission. Setup/internalFD/affectedtestGitAPIreturns notallserialized/no reconstruction-globalPIDscan-kill-globalabsence-fullreap.\",\"NEWfixture Gitsetup7percase, rawstdout/stderr fullSHA-size/status0/BOTH EOF; each namespace new, SourceactualfixtureGitarchive/SHA/recipefullbytes notproductionSourceSDKcohort. NormalconstructorretainedrecipePopen beforeSourcepublication/classsetterdelegates; Aux originalmethodreturncapturedbeforeSourcepublication. RootknownFDdevino data notatomicABA-writer-closure-auth. No Sourcepostfaultmethods except capturedpureprivateguard fromactualfailuregroup BEFOREpendingSecondary; guard returnsOriginalFirst/no metadataIO.\",\"Qwen98741planning tokenlimit1/0stdout443stderr; GLM99726review tokenlimit1/0stdout983stderr; BOTH EOF/naturalhelperreaped/fullpartialfinalBOTH_ABSENT/no reconstruction/reachableNOTglobalunavailability-approval/no unchangedmodelretry. ROOTindependentfullcandidate-tests/order/projections/selectedresults qualification, no modelwholecurrentapproval.\",\"Current23hashes other18helpers3bins unchanged/SourceGit4fresh status0-BOTH/HEAD601-ownbranch20untracked-productiontrackedempty DATA; all20uncommitteduncanonicalunadmitted/no Sourcecommit-push-adoption-SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-strictdispatch. Strongowners/groups/closures/rawchunks processlife NOTfixedmemory/heapRSSgrowth-allocvolume-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-pop-reset-evict-deleteauthority.\",\"ProviderABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/fullindependentEX-originalruntimeimmutableCOMPLETEadmission/RAMrepair-finalstrict48/50-cleanfinalCI INCOMPLETE/PR132OPENdraft#130/issue103milestoneOPEN. StoragefloorsDATA-recheck/notbuild-capture-deletionauthority/outsidecleanupcauseUNMEASURED.\"]"),storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['archive_constructor_catch_progress'].update(ROOT_qualified=True,ROOT_pending=False,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],model_pending=False);c['active_turn_status']='Archive_constructor_catch_NEW3before1FAIL2PASS_AFTER6PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],before='1FAIL2PASS0ERROR',after='6PASS=3NEW3affected',models_both_limit_fullpartialfinal_ABSENT=True,current23hashes_Git4_0_BOTH=True,free_bytes=free,full_admission=False)))
