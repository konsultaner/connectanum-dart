import unittest,pathlib,tempfile,sys,os,hashlib,json,subprocess,stat
import native_perf_build_producer as b
Path=pathlib.Path
def sha(raw):return hashlib.sha256(raw).hexdigest()
class FirstArchiveError(RuntimeError):pass
class SecondaryPendingError(RuntimeError):pass
class ArchiveConstructorCatchTests(unittest.TestCase):
 def _case(self,mode):
  root=Path(os.environ['CONNECTANUM_ARCHIVE_CATCH_FIXTURES']);root.mkdir(exist_ok=True)
  base=Path(tempfile.mkdtemp(prefix=mode+'-',dir=root)).resolve();repo=base/'repo';repo.mkdir();run=base/'run'
  setup=[];actors=[];fds=[];files=[];seen={'archive_ready':False,'spent':False,'ctor':[],'groups':[]}
  first=FirstArchiveError('original archive constructor failure');secondary=SecondaryPendingError('pending getter secondary')
  def git(*args):
   index=len(setup);argv=['git','-C',str(repo),*args];entry={'argv':argv,'Popen_attempted':True,'pid':None};setup.append(entry)
   (base/f'setup-{index}-before.json').write_text(json.dumps(entry))
   child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   bound=child.wait;entry['pid']=child.pid
   (base/f'setup-{index}-start.json').write_text(json.dumps({'pid':child.pid}))
   out,err=child.communicate();status=bound(10)
   (base/f'setup-{index}-stdout.bin').write_bytes(out);(base/f'setup-{index}-stderr.bin').write_bytes(err)
   entry.update(status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err))
   (base/'setup-commands.json').write_text(json.dumps(setup,indent=2))
   if status!=0:raise RuntimeError('fixture Git setup failed')
   return out
  git('init','-q');git('config','user.email','archive-catch@example.invalid');git('config','user.name','Archive Catch Fixture')
  (repo/'.gitignore').write_text('inputs/\n')
  (repo/'worker.py').write_text("import os\nos.write(1,b'ARCHIVE-CATCH-NEW-out')\nos.write(2,b'ARCHIVE-CATCH-NEW-err')\n")
  git('add','.');git('commit','-qm','new archive constructor catch fixture')
  head=git('rev-parse','HEAD').decode().strip();expected=sha(git('archive','--format=tar',head))
  (repo/'inputs').mkdir();(repo/'inputs'/'context').write_bytes(b'archive-catch-input-v1')
  inputs={'inputs/context':sha((repo/'inputs'/'context').read_bytes())}
  native_os=b.os;native_open=Path.open;native_allocate=b.AuxiliaryCommand._allocate_process;native_observe=b._observe_auxiliary
  native_ctor=b._FileSnapshotAttempt;native_group=b._failure_preservation_group;native_get=b.CommandProducer.__getattribute__;native_set=b.CommandProducer.__setattr__
  def fd_record(fd):
   st=native_os.fstat(fd);fds.append({'fd':fd,'dev':st.st_dev,'ino':st.st_ino,'mode':st.st_mode,'inheritable':native_os.get_inheritable(fd),'source_returned':True})
  class OSFacade:
   def __getattr__(self,name):return getattr(native_os,name)
   def pipe(self):
    pair=native_os.pipe()
    for fd in pair:fd_record(fd)
    return pair
  def opened(path,*args,**kwargs):
   value=native_open(path,*args,**kwargs)
   if path.parent==run:
    raw=getattr(value,'raw',None)
    def keep(stream):
     fd=stream.fileno();st=native_os.fstat(fd)
     files.append({'path':str(path),'stream':stream,'close':stream.close,'fd':fd,'dev':st.st_dev,'ino':st.st_ino})
    if raw is not None and raw is not value:keep(raw)
    keep(value)
   return value
  def remember(value,argv):
   if not any(row['process'] is value for row in actors):
    actors.append({'process':value,'bound_wait':value.wait,'pid':value.pid,'argv':argv,'stdout':value.stdout,'stderr':value.stderr})
  def allocated(owner,record):
   value=native_allocate(owner,record)
   remember(value,list(owner.argv))
   return value
  def assigned(owner,name,value):
   if name=='process' and type(value) is b._COMMAND_POPEN_TYPE:
    remember(value,['ROOT-known-returned-recipe-Popen'])
   return native_set(owner,name,value)
  def observed(owner,name,argv,stdout_max=1024**3):
   value=native_observe(owner,name,argv,stdout_max)
   if 'archive' in argv:
    seen.update(archive_ready=True,owner=owner,archive_path=owner.directory/(name+'.stdout'),archive_result=value)
   return value
  def constructed(path,maximum=16*1024**3):
   value=native_ctor(path,maximum)
   if mode!='normal' and seen['archive_ready'] and Path(path)==seen['archive_path'] and not seen['spent']:
    seen['ctor'].append(value);seen['spent']=True;seen['first_raised']=True
    raise first
   return value
  def grouped(owner,error):
   value=native_group(owner,error)
   if seen.get('first_raised') and seen.get('owner') is owner:seen['groups'].append(value)
   return value
  def gotten(owner,name):
   value=native_get(owner,name)
   if mode=='pending' and seen.get('first_raised') and seen.get('owner') is owner and name=='pending' and not seen.get('pending_fault'):
    seen['pending_native']=value;seen['pending_fault']=True;raise secondary
   return value
  received=None;result=None;returned=None;registry_before=len(b._FILE_SNAPSHOT_ATTEMPTS)
  evidence_ready=False
  try:
   b.os=OSFacade();Path.open=opened;b.AuxiliaryCommand._allocate_process=allocated;b._observe_auxiliary=observed;b._FileSnapshotAttempt=constructed;b._failure_preservation_group=grouped;b.CommandProducer.__getattribute__=gotten;b.CommandProducer.__setattr__=assigned
   try:
    returned=b.CommandProducer(repo=repo,source_commit=head,runtime_commit=head,run_dir=run,expected_archive_sha256=expected,inputs=inputs,commands=[[sys.executable,str(repo/'worker.py')]],lease_check=lambda:None,provenance='fixture')
    if mode=='normal':result=returned.wait(10)
   except BaseException as error:received=error
   finally:
    b.CommandProducer.__getattribute__=native_get;b.CommandProducer.__setattr__=native_set;b._failure_preservation_group=native_group;b._FileSnapshotAttempt=native_ctor;b._observe_auxiliary=native_observe;b.AuxiliaryCommand._allocate_process=native_allocate;Path.open=native_open;b.os=native_os
   guard_error=None
   if mode=='pending' and seen['groups']:
    try:seen['groups'][0][1]()
    except BaseException as error:guard_error=error
   owner=seen.get('owner')
   view={'archive_constructor_catch':mode,'received_First':received is first,'received_Secondary':received is secondary,'received_type':None if received is None else type(received).__name__,'Source_returned_object':returned is not None,'snapshot_root_object_count':len(seen['ctor']),'snapshot_root_object_registered':any(any(item is value for item in b._FILE_SNAPSHOT_ATTEMPTS) for value in seen['ctor']),'pending_fault':seen.get('pending_fault',False),'pending_native_false':seen.get('pending_native','missing') is False,'captured_private_guard_First':guard_error is first,'captured_groups':len(seen['groups']),'Source_finished':None if owner is None else native_get(owner,'finished'),'Source_pending':None if owner is None else native_get(owner,'pending'),'source_tar_exists':(run/'source.tar').exists(),'actors':[{'pid':row['pid'],'argv':row['argv']} for row in actors],'normal_result_kind':None if result is None else result['kind'],'normal_result_status':None if result is None else result['status'],'expected_archive_sha256':expected,'registry_growth':len(b._FILE_SNAPSHOT_ATTEMPTS)-registry_before,'setup_statuses':[row['status'] for row in setup],'unit_only_no_runtime_admission':True}
   (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2));evidence_ready=True
   if mode=='normal':
    self.assertIsNone(received);self.assertEqual('success',result['status']);self.assertEqual(expected,result['source_archive_sha256'])
    raw=(run/'command-000.log').read_bytes();self.assertEqual(b'ARCHIVE-CATCH-NEW-outARCHIVE-CATCH-NEW-err',raw)
   else:
    self.assertTrue(received is first);self.assertIsNone(returned);self.assertEqual(1,len(seen['ctor']));self.assertFalse(view['snapshot_root_object_registered']);self.assertFalse(view['source_tar_exists'])
    if mode=='pending':self.assertTrue(view['pending_native_false']);self.assertTrue(view['pending_fault'])
  finally:
   b.CommandProducer.__getattribute__=native_get;b.CommandProducer.__setattr__=native_set;b._failure_preservation_group=native_group;b._FileSnapshotAttempt=native_ctor;b._observe_auxiliary=native_observe;b.AuxiliaryCommand._allocate_process=native_allocate;Path.open=native_open;b.os=native_os
   if not evidence_ready:raise RuntimeError('no evidence ready; ROOT cleanup refused')
   rows=[]
   for row in actors:
    status=row['bound_wait'](10);rows.append({'kind':'original_bound_wait','pid':row['pid'],'status':status,'signed_native_int':type(status) is int,'unit_only':True})
   for row in fds:
    try:st=native_os.fstat(row['fd'])
    except OSError as error:
     rows.append({'kind':'pipe_creator_end','fd':row['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(row['dev'],row['ino'])
    rows.append({'kind':'pipe_creator_end','fd':row['fd'],'same_devino':same,'closed_by_ROOT':same})
    if same:native_os.close(row['fd'])
   for row in files:
    stream=row['stream']
    if stream.closed:continue
    try:st=native_os.fstat(row['fd'])
    except OSError as error:
     rows.append({'kind':'file','path':row['path'],'fd':row['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(row['dev'],row['ino']);entry={'kind':'file','path':row['path'],'fd':row['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(entry)
    if same:
     try:row['close']();entry['closed_by_ROOT']=True
     except BaseException as error:entry['close_error_type']=type(error).__name__
   (base/'ROOT-unit-cleanup.json').write_text(json.dumps({'evidence_ready':evidence_ready,'rows':rows,'not_Source_cleanup_or_full_actor_closure':True},indent=2))
 def test_new_pending_getter_preserves_archive_constructor_First(self):self._case('pending')
 def test_new_archive_constructor_First_normal_metadata(self):self._case('first_only')
 def test_new_archive_constructor_normal_finite_recipe_full_bytes(self):self._case('normal')
