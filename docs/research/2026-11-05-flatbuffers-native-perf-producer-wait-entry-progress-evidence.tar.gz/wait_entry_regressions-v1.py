"""NEW pending-producer wait entry failure retention controls."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class ProducerWaitEntryTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)



    def _entry_case(self,mode):
        calls=[];actors=[];seen={};leases=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT wait entry first')
        native_allocate=producer.CommandProducer._allocate_command_process;native_drain=producer.CommandProducer._drain_output
        native_wait=producer.CommandProducer._wait_command_natural;native_time=producer.time
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def checking():
            calls.append(dict(kind='wait_lease_attempt'));raw=verifying();calls.append(dict(kind='wait_lease_actual_return',raw_None=raw is None))
            if mode=='lease_unknown':raise first
            if mode=='normal':return False
            return raw
        def attribute(owner,name):
            raw=object.__getattribute__(owner,name)
            if owner is seen.get('producer') and name=='lease_check':
                calls.append(dict(kind='lease_lookup_actual_return'));seen['native_lease_lookup']=raw
                if mode=='lookup_unknown':raise first
            return raw
        class TimeFacade:
            def __getattr__(self,name):return getattr(native_time,name)
            def monotonic(self):
                raw=native_time.monotonic();calls.append(dict(kind='monotonic_actual_return',raw=raw));n=sum(x['kind']=='monotonic_actual_return' for x in calls)
                if n==1:
                    if mode=='clock_unknown':raise first
                    if mode=='clock_False':return False
                return raw
        def draining(p,deadline):
            calls.append(dict(kind='Source_drain_attempt'));return native_drain(p,deadline)
        def waiting(p,timeout):
            calls.append(dict(kind='Source_Popenwait_attempt'));return native_wait(p,timeout)
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating):
                code="import os,time;os.write(1,b'ENTRY-out');os.write(2,b'ENTRY-err');time.sleep(0.12)"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],lease_check=verifying);seen['producer']=p;p.lease_check=checking
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=obj.close,fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(producer.CommandProducer,'__getattribute__',attribute),mock.patch.object(producer,'time',TimeFacade()),mock.patch.object(producer.CommandProducer,'_drain_output',draining),mock.patch.object(producer.CommandProducer,'_wait_command_natural',waiting):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                guard=getattr(producer,'_wait_entry_guard',None)
                if mode!='normal' and guard is not None:
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in getattr(producer,'_WAIT_ENTRY_RECORDS',[]) if r.get('owner') is p];record=records[-1] if records else None;rows=[] if record is None else record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,result_None=result is None,result_status=None if result is None else result['status'],
                received_type=None if received is None else type(received).__name__,received_first=received is first,
                pure_guard_same_received=received is not None and guard_error is received,Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],
                Source_evidence_complete=p.evidence_complete,original_log_closed=seen['log']['obj'].closed,original_journal_closed=seen['journal']['obj'].closed,
                record_present=record is not None,record_process_original=False if record is None else record.get('process') is actors[0]['process'],
                record_log_original=False if record is None else record.get('log') is seen['log']['obj'],record_events_original=False if record is None else record.get('events') is seen['journal']['obj'],
                record_primary_received=False if record is None else record.get('primary_error') is received,record_completed=None if record is None else record['completed'],
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,error_first=r.get('error') is first) for r in rows],
                calls=list(calls),leases=leases,limits='Controlledwait-entry callback/timefault afteractualofficialDarwinEXverify/nativeclock; RootparentEX retained/no reallease-release/originalLinux/fullindependentEX proof. Pendingfieldnotkernel-liveness. Negativeonlypureguard/Rootsameknownboundwait+FDdevino cleanup AFTERevidence UNITnotSourcecleanup-ownership-EXrelease/allactorclosure/admission. Sourceunknownlookup-call-clock neverROOTknownfunction-None-float adopted. No globaltimepatch; modulelocalfacade only.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases))
            if mode=='normal':
                self.assertTrue(returned);self.assertEqual('success',result['status']);self.assertIsNone(received)
                self.assertEqual(b'ENTRY-outENTRY-err',(p.directory/'command-000.log').read_bytes());self.assertTrue(p.evidence_complete)
                if record is not None:self.assertTrue(record['completed']);self.assertTrue(record['process'] is actors[0]['process'])
            else:
                self.assertFalse(returned)
                if mode=='clock_False':self.assertTrue(type(received) is producer.ProducerError)
                else:self.assertTrue(received is first)
                self.assertTrue(guard is not None);self.assertTrue(guard_error is received);self.assertTrue(record is not None)
                self.assertTrue(record['process'] is actors[0]['process']);self.assertTrue(record['log'] is seen['log']['obj']);self.assertTrue(record['events'] is seen['journal']['obj'])
                self.assertTrue(record['primary_error'] is received);self.assertFalse(record['completed'])
                self.assertTrue(p.pending);self.assertFalse(p.finished);self.assertIsNone(p.records[-1]['returncode']);self.assertFalse(p.evidence_complete)
                self.assertFalse(seen['log']['obj'].closed);self.assertFalse(seen['journal']['obj'].closed)
                self.assertFalse(any(x['kind'] in ('Source_drain_attempt','Source_Popenwait_attempt','repr_first','note_first') for x in calls))
                stop={'lookup_unknown':'lease_lookup','lease_unknown':'lease_call','clock_unknown':'deadline_clock','clock_False':'deadline_clock'}[mode]
                self.assertEqual(['lease_lookup','lease_call','deadline_clock'][:['lease_lookup','lease_call','deadline_clock'].index(stop)+1],[r['stage'] for r in rows])
                if mode=='clock_False':self.assertTrue(rows[-1]['returned']);self.assertTrue(rows[-1]['raw'] is False)
                else:self.assertFalse(rows[-1]['returned']);self.assertIsNone(rows[-1]['raw'])
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('wait entry pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed and item['obj'] is not raw:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')


    def test_actual_wait_lease_verify_then_error_retains_pending_first(self):self._entry_case('lease_unknown')
    def test_actual_wait_lease_lookup_then_error_keeps_unknown_function(self):self._entry_case('lookup_unknown')
    def test_actual_monotonic_then_error_keeps_unknown_deadline_clock(self):self._entry_case('clock_unknown')
    def test_actual_monotonic_then_False_refused_before_drain(self):self._entry_case('clock_False')
    def test_new_normal_wait_leaseFalse_preserves_fullbytes_result(self):self._entry_case('normal')
