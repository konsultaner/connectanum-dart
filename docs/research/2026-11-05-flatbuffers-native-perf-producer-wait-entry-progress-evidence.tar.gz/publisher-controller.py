import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-wait-entry-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-producer-wait-entry-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='2ea35551aba1230fcd347662df347b45d89047a1'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Retain pending producer failures at wait entry\n\nThe lease lookup/call and deadline clock ran before the protected wait body. Three controlled actual-completion-then-error cases escaped without retained entry references or a private first-error guard; a native clock wrapper returning False entered the drain path and silently timed out. The wait prefix now retains the original process, log, journal, command and reader references before those callbacks, records each intent and raw return, and permanently refuses an unknown or invalid entry. Pending/finished/status fields remain unchanged after refusal. Healthy ignored lease False and the original inner wait body remain intact.\n\nNEW5 beforebd0cfe/98a966 yields4FAIL/1normalPASS/0ERROR: three retention policies and one invalid-clock refusal, not four spontaneous native kernel bugs or a RAM cause. Final31cd79/326aed passes15selected=5matchingNEW+10affected actual wait callers, including bounded same-process continuation, multi-command budgets, failure/signal/deferral and fixture receipts. Ten new views/10BEFORE30AFTER currentDarwinEX observations and5+5same-bound ROOT waits are UNIT facts, not full independent EX/originalLinuxcredentials/actor closure. Qwen53885 and GLM55126 complete0/fullanswers/reaped, ROOTqualified; proposed id-reuse/cleanup/integer-clock/finally-masking claims are rejected against the retained strong owner, actual float clock, and private-first finally. Source/test projections, old test prefix, other18helpers3bins and4newGit0/BOTHstreams/601/20untracked/productionempty are verified DATA. Strong references/rows/tracebacks have unmeasured growth. Earlier metadata/bindings/callee interiors/concurrent ABA/transitive actors remain open. Source stays uncommitted and unadmitted; RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-producer-wait-entry-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: retain pending producer wait entry failures'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_wait_entry_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Earlierwait-entryattributes-bindings-metadata-clockcalleeinterior-returnshapes/globalconcurrentABA; otherglob/end-enclosing-publicunknownCtorretention; writer-hash-init/nativeFD seams; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Current31cd79/326aed ONLYwaitentry newprivateguard/retainedoriginalprocess-log-journal-command-readerrefs/percalllookup-call-clockintentraw/privatefirst BEFOREcallbacks; originalinnerwaitbody/allotherSource methodshelpersfactoriesfrozenpredicates exact. NEW5beforebd0cfe/98a966=4FAIL1normalPASS0ERROR:3first-retentionpolicies+actualnativefloatthenFalse entersdrainreturnsNone/NOT4nativekernelbugs-RAMcause. Final15PASS=5matchingNEW10affectedactualwaitcallers/no aggregate-current20canonical-admission. Unknownlookup-call-clock rawNone-returnedFalse neverROOTknownfunction-None-float adopted; knownFalse clock refusedBEFOREarithmetic-drain; normalleaseFalse ignored/fullENTRY-outENTRY-err preserved. NegativependingTrue-finishedFalse-statusNone/opennativelog-journal DATA notliveness-release; pureguardonly/no Sourcepreserve-repr-note-wait-drain-read-Popenwait-close-retry-replay.10views/EX10before30after/5+5ROOTsameoriginalboundwait10 signed0cached/knownFDpathdevino cleanup AFTERevidence UNITnotSourcecleanup-fullEX-originalLinux/allFD-delegate-descendantclosure. Qwen53885=0/1991out399err-GLM55126=0/3139out770err/fullanswers-reaped-ROOTqualified/rejectidreuse-pop-cleanup-intclock-finallymasksprimary/pendingboolownershipclaims/no wholecurrentapproval. Candidatev1/privatev1UNEXECUTEDbeforeedit-firstBEFORE/controllersBEFOREcalls/wholeSourceBYTEprojectback-oldtestPREFIX-23hashes-other18helpers3bins4NEWGit0BOTH/601ownbranch20untrackedproductionempty DATA. Stronggroups-refs-rows-closures-tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. UnknownPopenCtorpermanentrefusal/no partialPopenmethods-fieldderivedownerclose; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_wait_entry_selected15PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
