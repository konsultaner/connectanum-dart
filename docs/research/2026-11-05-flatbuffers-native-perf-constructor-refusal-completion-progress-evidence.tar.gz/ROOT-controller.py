import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-refusal-completion-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();parts=json.loads((P/'projection-parts.json').read_text())
 assert source==(P/'candidate-producer-v1.py').read_text() and tests==(P/'candidate-tests-v1.py').read_text()
 assert source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'refusal_completion_regressions-v1.py').read_text()
 before=json.loads((P/'before-NEW4/result.json').read_text());after=json.loads((P/'after-NEW4/result.json').read_text())
 assert (before['tests'],before['failures'],before['errors'],before['passes'])==(4,2,0,2) and (after['tests'],after['failures'],after['errors'],after['passes'])==(4,0,0,4)
 assert len(before['leases'])==len(after['leases'])==8 and all(x['raw_None'] for x in before['leases']+after['leases'])
 controls={}
 for label,folder in [('BEFORE',P/'before-NEW4/fixtures'),('AFTER',P/'after-NEW4/new-fixtures')]:
  views=[];waits=[];pipes=files=setup_count=0
  for d in sorted(folder.iterdir()):
   v=json.loads((d/'view-before-ROOT-wait.json').read_text());c=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text());assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup);setup_count+=len(setup)
   for i,x in enumerate(setup):
    for channel in ('stdout','stderr'):
     raw=(d/f'setup-{i}-{channel}.bin').read_bytes();assert len(raw)==x[channel+'_size'] and hashlib.sha256(raw).hexdigest()==x[channel+'_sha256']
   w=[row for row in c['rows'] if row['kind']=='same_original_bound_wait'];assert all(x['status']==0 and x['signed_native_int'] for x in w);waits+=w
   saved_waits=json.loads((d/'ROOT-all-known-waits-before-assert.json').read_text());assert saved_waits['all_statuses_known'] and saved_waits['rows']==w
   pipes+=sum(row.get('closed_by_ROOT',False) for row in c['rows'] if row['kind']=='creatorFD');files+=sum(row.get('closed_by_ROOT',False) for row in c['rows'] if row['kind']=='file')
   mode=v['refusal_completion_contract'];assert v['ROOT_native_tuple_NOT_filled_called_adopted'] and v['ROOT_never_Source_wait_or_returned_owner_adopted']
   assert v['group_calls']==1 and v['after_group_gets']==['pending'] and v['pending_Secondary_injected'] and v['pending_exact_bool']
   assert not v['Source_finished_DATA'] and not v['Source_failure_attempted_DATA']
   if mode=='native_false':
    assert len(w)==5 and all(x['actor_kind']=='Auxiliary' for x in w) and v['archive_native_returned_None'] and not v['spawn_returned_inside_ROOT'] and v['actual_pending_return_inside_ROOT'] is False
   else:
    assert len(w)==6 and v['spawn_raw_None'] and v['spawn_stage']=='spawned' and v['actual_pending_return_inside_ROOT'] is True
    assert (d/'ROOT-recipe-pipe.bin').read_bytes()==b'RF-v1-outRF-v1-err' and (d/'ROOT-recipe-pipe-tail.bin').read_bytes()==b''
   if mode.startswith('native'):
    assert v['received_First'] and not v['Source_returned_owner'] and v['native_secondary_list_contains_Second'] and v['native_secondary_list_size']==1 and v['First_context_Second']
   else:
    assert v['callback_attempted'] and v['callback_received_Second'] and v['native_secondary_list_size']==0
    if mode=='return_false':assert v['callback_returned'] and v['callback_raw_is_False']
    else:assert mode=='raise_third' and v['callback_Third_attempted'] and not v['callback_returned']
    if label=='BEFORE':
     if mode=='return_false':assert v['Source_returned_owner'] and v['received_type'] is None and not v['received_First']
     else:assert not v['Source_returned_owner'] and v['received_Third'] and not v['received_First']
    else:
     assert v['received_First'] and not v['Source_returned_owner']
     assert v['First_context_Second'] if mode=='return_false' else v['First_context_Third']
   views.append(v)
  assert len(views)==4 and len(waits)==23 and setup_count==28 and pipes==3 and files==7
  controls[label]=dict(views=views,wait_rows=waits,Root_pipe_closes_AFTERevidence=pipes,Root_file_closes_AFTERevidence=files,separate_setupGit_rows=setup_count)
 parent=[r for rows in after['root_original_waits'] for r in rows['rows']];assert len(parent)==23 and all(r['status']==0 and r['signed_native_int'] for r in parent)
 models={}
 for name in ('planning','review'):
  r=json.loads((P/name/'result.json').read_text());assert r['status']==0 and r['both_separate_EOF'] and (P/name/'answer.txt').is_file()
  for stream in ('stdout','stderr'):
   raw=(P/name/(stream+'.bin')).read_bytes();assert len(raw)==r[stream+'_size'] and hashlib.sha256(raw).hexdigest()==r[stream+'_sha256']
  models[name]=r
 q=P/'ROOT-source-Git';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait(10);(q/f'{i}-stdout.bin').write_bytes(out);(q/f'{i}-stderr.bin').write_bytes(err)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/'commands.json').write_text(json.dumps(commands,indent=2));assert status==0 and not err;return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 status=git(['status','--porcelain','--untracked-files=all']).decode().splitlines();assert len(status)==20 and all(x.startswith('?? tool/') for x in status) and {x[3:] for x in status}=={k for k in h if k.startswith('tool/')}
 assert git(['diff','601108ea6216464bd00ae29c16cfaf0a59c71db6','--stat','--','packages','native'])==b''
 free=shutil.disk_usage(R).free
 ass=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],BEFORE4=before,AFTER4=after,matching_NEW2_negatives_plus2_nativeRefuse_affected_caller_controls=True,controls=controls,parent_after23_OVERLAPS_same_new23_NOTadditional_actors=True,models=models,model_ROOT_qualification=json.loads((P/'review-ROOT-qualification.json').read_text()),Source_whole_BYTEprojectback=True,oldtest_PREFIX_exact=True,only_existing_constructor_refusal_callback_finally_backstop_changed=True,native_callback_private_quarantine_helper_and_secondary_list_unchanged=True,First_priority_after_callback_attempt_deliberate_BaseException_policy=True,native_control_context_Second_preserved_negative_Third_context_preserved=True,earlier_primary_multiowner_history_bindings_callee_interiors_concurrentABA_transitive_unproved=True,Source_fields_status_EOF_closedFD_NOTliveness_ownership_EXrelease_admission=True,Root_collect_all_known_wait_outcomes_before_wait_assertions=True,unknown_beforeview_waitread_cleanup_incomplete=True,unit_NOTfull_physicalEX_originalLinux_fullFD_interpreter_delegate_descendant_closure=True,no_prior7_6_5_27_completed25_old2bodies_old7suite_private2_or_model_campaign_replay=True,current23hashes_other18helpers3bins_SourceGit4_0_BOTH=True,SourceGit=commands,all20_uncommitted_uncanonical_unadmitted=True,stronggroups_closures_rawchunks_processlife_NOTfixedmemory_RSSgrowth_allocvolume_timing_cause_UNMEASURED=True,no_Sourcecommit_push_adoption_SDKbuild_kernel_broker_benchmarkcapture_strictdispatch_RAMrepair_acceptance=True,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,outside_oldcleanup_cause='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(ass,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_refusal_completion_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256']);c.update(updated_utc=ass['utc'],active_turn_status='Constructor_refusal_completion_BEFORE4_2FAIL2PASS_AFTER4PASS_ROOTqualified_DOCSpending');cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps(dict(source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256'],BEFORE4='2FAIL2PASS0ERROR',AFTER4='4PASS0FAIL0ERROR',wait_rows_per_phase=23,parent_after_same23=True,Root_pipe_file_closes_per_phase=[3,7],current23hashes_SourceGit4zeroBOTH=True,free_bytes=free,full_admission=False)))
