import unittest,pathlib,tempfile,sys,os,hashlib,json,subprocess
import native_perf_build_producer as b
Path=pathlib.Path
def refusal_completion_sha(raw):return hashlib.sha256(raw).hexdigest()
class RefusalCompletionFirst(RuntimeError):pass
class RefusalCompletionSecond(RuntimeError):pass
class RefusalCompletionThird(RuntimeError):pass
_ROOT_REFUSAL_COMPLETION_ATTEMPTS=[]
class RefusalCompletionTests(unittest.TestCase):
 def _case(self,mode):
  root=Path(os.environ['CONNECTANUM_REFUSAL_COMPLETION_FIXTURES']);root.mkdir(exist_ok=True)
  base=Path(tempfile.mkdtemp(prefix=mode+'-',dir=root)).resolve();repo=base/'repo';repo.mkdir();run=base/'run'
  setup=[];actors=[];pipes=[];files=[];groups=[];seen={'spawn_returned':False,'pending_native':[]}
  first=RefusalCompletionFirst('refusal-completion-original-First');second=RefusalCompletionSecond('refusal-completion-pending-Second');third=RefusalCompletionThird('refusal-completion-callback-Third')
  attempt=dict(base=base,actors=actors,pipes=pipes,files=files);_ROOT_REFUSAL_COMPLETION_ATTEMPTS.append(attempt)
  def git(*args):
   i=len(setup);argv=['git','-C',str(repo),*args];row={'argv':argv,'Popen_attempted':True,'pid':None};setup.append(row)
   (base/f'setup-{i}-before.json').write_text(json.dumps(row))
   process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=process.wait
   (base/f'setup-{i}-start.json').write_text(json.dumps({'pid':process.pid}))
   out,err=process.communicate();status=wait(10)
   (base/f'setup-{i}-stdout.bin').write_bytes(out);(base/f'setup-{i}-stderr.bin').write_bytes(err)
   row.update(pid=process.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=refusal_completion_sha(out),stderr_sha256=refusal_completion_sha(err))
   (base/'setup-commands.json').write_text(json.dumps(setup,indent=2))
   if status!=0:raise RuntimeError('new fixture setup refused')
   return out
  git('init','-q');git('config','user.email','refusal-completion@example.invalid');git('config','user.name','Refusal Completion Fixture')
  (repo/'.gitignore').write_text('inputs/\n')
  (repo/'worker.py').write_text("import os,time\ntime.sleep(0.08)\nos.write(1,b'RF-v1-out')\nos.write(2,b'RF-v1-err')\n")
  git('add','.');git('commit','-qm','new refusal completion contract fixture');head=git('rev-parse','HEAD').decode().strip()
  expected=refusal_completion_sha(git('archive','--format=tar',head));(repo/'inputs').mkdir();(repo/'inputs'/'context').write_bytes(b'group-acquisition-input-v1')
  inputs={'inputs/context':refusal_completion_sha((repo/'inputs'/'context').read_bytes())}
  native_os=b.os;native_open=Path.open;native_aux=b.AuxiliaryCommand._allocate_process;native_recipe=b.CommandProducer._allocate_command_process
  native_archive=b.CommandProducer._make_archive;native_spawn=b.CommandProducer._spawn;native_get=b.CommandProducer.__getattribute__;native_group=b._failure_preservation_group
  def remember(process,kind):
   actors.append({'process':process,'wait':process.wait,'pid':process.pid,'kind':kind})
  class OSFacade:
   def __getattr__(self,name):return getattr(native_os,name)
   def pipe(self):
    pair=native_os.pipe();info=[]
    for fd in pair:
     st=native_os.fstat(fd);info.append({'fd':fd,'dev':st.st_dev,'ino':st.st_ino,'inheritable':native_os.get_inheritable(fd)})
    pipes.append({'pair':pair,'info':info});return pair
  def opened(path,*args,**kwargs):
   value=native_open(path,*args,**kwargs)
   if path.parent==run:
    raw=getattr(value,'raw',None)
    for stream in ([raw,value] if raw is not None and raw is not value else [value]):
     st=native_os.fstat(stream.fileno());files.append({'path':str(path),'stream':stream,'close':stream.close,'fd':stream.fileno(),'dev':st.st_dev,'ino':st.st_ino})
   return value
  def auxiliary(owner,record):
   process=native_aux(owner,record);remember(process,'Auxiliary');return process
  def recipe(owner,attempt,argv,writer):
   process=native_recipe(owner,attempt,argv,writer);remember(process,'recipe')
   matches=[row for row in reversed(pipes) if row['pair'][1]==writer];assert matches
   seen['recipe_pipe']=matches[0];return process
  def spawned(owner):
   raw=native_spawn(owner);seen.update(owner=owner,spawn_returned=True,spawn_raw_None=raw is None,actual_spawn_stage=owner._command_attempt['stage']);raise first
  def archived(owner):
   raw=native_archive(owner);seen.update(owner=owner,archive_native_returned_None=raw is None);raise first
  def replacement(received):
   seen.update(callback_attempted=True,callback_received_Second=received is second)
   if mode=='return_false':
    seen.update(callback_returned=True,callback_raw=False);return False
   seen['callback_raise_Third_attempted']=True;raise third
  def grouped(owner,error):
   seen['owner']=owner;value=native_group(owner,error);groups.append(value);seen['group_delivered']=True
   if mode in ('return_false','raise_third'):
    returned=value[:2]+(replacement,)+value[3:];seen['Source_refusal_replaced']=True;return returned
   return value
  def gotten(owner,name):
   value=native_get(owner,name)
   if seen.get('group_delivered') and seen.get('owner') is owner:
    seen.setdefault('after_group_gets',[]).append(name)
    if name=='pending' and not seen.get('pending_injected'):
     seen.update(pending_injected=True,pending_native=value,pending_native_exact_bool=type(value) is bool);raise second
   return value
  received=None;returned=None;evidence_ready=False
  try:
   b.os=OSFacade();Path.open=opened;b.AuxiliaryCommand._allocate_process=auxiliary;b.CommandProducer._allocate_command_process=recipe
   b.CommandProducer._make_archive=archived if mode=='native_false' else native_archive;b.CommandProducer._spawn=native_spawn if mode=='native_false' else spawned
   b.CommandProducer.__getattribute__=gotten;b._failure_preservation_group=grouped
   try:
    returned=b.CommandProducer(repo=repo,source_commit=head,runtime_commit=head,run_dir=run,expected_archive_sha256=expected,inputs=inputs,commands=[[sys.executable,str(repo/'worker.py')]],lease_check=lambda:None,provenance='fixture')
   except BaseException as error:received=error
   finally:
    b.CommandProducer._make_archive=native_archive;b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
    b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   owner=seen.get('owner');native_secondary=groups[0][4] if groups else []
   view={'refusal_completion_contract':mode,'group_calls':len(groups),'Source_refusal_replaced':seen.get('Source_refusal_replaced',False),'actual_pending_return_inside_ROOT':seen.get('pending_native'),'pending_exact_bool':seen.get('pending_native_exact_bool',False),'pending_Secondary_injected':seen.get('pending_injected',False),'after_group_gets':seen.get('after_group_gets',[]),'callback_attempted':seen.get('callback_attempted',False),'callback_received_Second':seen.get('callback_received_Second',False),'callback_returned':seen.get('callback_returned',False),'callback_raw_is_False':seen.get('callback_returned',False) and seen.get('callback_raw') is False,'callback_Third_attempted':seen.get('callback_raise_Third_attempted',False),'received_First':received is first,'received_Third':received is third,'received_type':None if received is None else type(received).__name__,'First_context_Second':first.__context__ is second,'First_context_Third':first.__context__ is third,'Source_returned_owner':returned is not None,'Source_pending_DATA':None if owner is None else native_get(owner,'pending'),'Source_finished_DATA':None if owner is None else native_get(owner,'finished'),'Source_failure_attempted_DATA':None if owner is None else native_get(owner,'failure_attempted'),'native_secondary_list_contains_Second':any(x is second for x in native_secondary),'native_secondary_list_size':len(native_secondary),'spawn_returned_inside_ROOT':seen.get('spawn_returned',False),'spawn_raw_None':seen.get('spawn_raw_None'),'spawn_stage':seen.get('actual_spawn_stage'),'archive_native_returned_None':seen.get('archive_native_returned_None',False),'ROOT_native_tuple_NOT_filled_called_adopted':True,'ROOT_never_Source_wait_or_returned_owner_adopted':True,'actor_rows':[{'pid':row['pid'],'kind':row['kind']} for row in actors],'unit_only_not_liveness_ownership_admission':True}
   (base/'view-before-ROOT-wait.json').write_text(json.dumps(view,indent=2));evidence_ready=True
   self.assertTrue(received is first);self.assertIsNone(returned)
   self.assertEqual(1,view['group_calls']);self.assertTrue(view['pending_exact_bool']);self.assertTrue(view['pending_Secondary_injected']);self.assertEqual(['pending'],view['after_group_gets'])
   self.assertFalse(view['Source_finished_DATA']);self.assertFalse(view['Source_failure_attempted_DATA'])
   if mode=='native_false':
    self.assertFalse(view['actual_pending_return_inside_ROOT']);self.assertTrue(view['archive_native_returned_None']);self.assertFalse(view['spawn_returned_inside_ROOT']);self.assertEqual(5,len(actors));self.assertTrue(all(a['kind']=='Auxiliary' for a in actors))
   else:
    self.assertTrue(view['actual_pending_return_inside_ROOT']);self.assertTrue(view['spawn_raw_None']);self.assertEqual('spawned',view['spawn_stage']);self.assertEqual(6,len(actors))
   if mode.startswith('native'):
    self.assertFalse(view['Source_refusal_replaced']);self.assertTrue(view['native_secondary_list_contains_Second']);self.assertEqual(1,view['native_secondary_list_size'])
   else:
    self.assertTrue(view['Source_refusal_replaced']);self.assertTrue(view['callback_attempted']);self.assertTrue(view['callback_received_Second']);self.assertEqual(0,view['native_secondary_list_size'])
    if mode=='return_false':self.assertTrue(view['callback_returned']);self.assertTrue(view['callback_raw_is_False']);self.assertTrue(view['First_context_Second'])
    else:self.assertTrue(view['callback_Third_attempted']);self.assertFalse(view['callback_returned']);self.assertTrue(view['First_context_Third'])
  finally:
   b.CommandProducer._make_archive=native_archive;b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
   b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   if not evidence_ready:raise RuntimeError('ROOT evidence absent; original handles retained; no cleanup claim')
   rows=[]
   for item in actors:
    try:
     raw=item['wait'](10);rows.append({'kind':'same_original_bound_wait','actor_kind':item['kind'],'pid':item['pid'],'status':raw,'signed_native_int':type(raw) is int})
    except BaseException as error:rows.append({'kind':'same_original_bound_wait','actor_kind':item['kind'],'pid':item['pid'],'status':None,'error_type':type(error).__name__,'signed_native_int':False,'no_retry':True})
   all_known=all(row['signed_native_int'] for row in rows)
   (base/'ROOT-all-known-waits-before-assert.json').write_text(json.dumps({'rows':rows,'all_statuses_known':all_known},indent=2))
   if not all_known:
    attempt['unknown_wait_statuses_retained']=True;raise RuntimeError('ROOT unknown wait; no FD cleanup or settlement claim')
   if 'recipe_pipe' in seen:
    pipe=seen['recipe_pipe'];fd=pipe['pair'][0];identity=pipe['info'][0];st=native_os.fstat(fd);same=(st.st_dev,st.st_ino)==(identity['dev'],identity['ino']);assert same
    assert native_os.get_blocking(fd) is False
    data=native_os.read(fd,65536);end=native_os.read(fd,1);(base/'ROOT-recipe-pipe.bin').write_bytes(data);(base/'ROOT-recipe-pipe-tail.bin').write_bytes(end)
    record={'fd':fd,'same_devino':same,'existing_nonblocking':True,'size':len(data),'sha256':refusal_completion_sha(data),'tail_size':len(end),'EOF':end==b'','not_Source_log_reconstruction':True}
    (base/'ROOT-pipe-before-close.json').write_text(json.dumps(record,indent=2));rows.append({'kind':'recipe_raw_pipe','record':record})
    self.assertEqual(b'RF-v1-outRF-v1-err',data);self.assertEqual(b'',end)
   (base/'ROOT-before-FDclose.json').write_text(json.dumps({'evidence_ready':True,'rows':rows},indent=2))
   for pipe in pipes:
    for info in pipe['info']:
     try:st=native_os.fstat(info['fd'])
     except OSError as error:rows.append({'kind':'creatorFD','fd':info['fd'],'already_closed_errno':error.errno});continue
     same=(st.st_dev,st.st_ino)==(info['dev'],info['ino']);rows.append({'kind':'creatorFD','fd':info['fd'],'same_devino':same,'closed_by_ROOT':same})
     if same:native_os.close(info['fd'])
   for item in files:
    if item['stream'].closed:continue
    try:st=native_os.fstat(item['fd'])
    except OSError as error:rows.append({'kind':'file','path':item['path'],'fd':item['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(item['dev'],item['ino']);record={'kind':'file','path':item['path'],'fd':item['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(record)
    if same:
     try:item['close']();record['closed_by_ROOT']=True
     except BaseException as error:record['close_error_type']=type(error).__name__
   (base/'ROOT-unit-cleanup.json').write_text(json.dumps({'evidence_ready':True,'rows':rows,'unit_not_live_ownership_fullFD_descendant_closure':True},indent=2))
   self.assertTrue(all(r['status']==0 for r in rows if r['kind']=='same_original_bound_wait'))
 def test_new_refusal_return_False_cannot_finish_constructor(self):self._case('return_false')
 def test_new_refusal_Third_cannot_replace_First(self):self._case('raise_third')
 def test_new_native_refusal_pendingTrue_caller_control(self):self._case('native_true')
 def test_new_native_refusal_pendingFalse_caller_control(self):self._case('native_false')
