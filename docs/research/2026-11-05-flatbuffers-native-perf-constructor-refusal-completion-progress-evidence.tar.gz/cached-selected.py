def _failure_preservation_group(owner,error):
    key=id(owner)
    previous=_FAILURE_PRESERVATION_GROUPS.get(key)
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        previous[1]()
        return previous
    primary=error
    quarantined=[False]
    secondary=[]

    def guard():
        if quarantined[0]:raise primary

    def refuse(received,row=None):
        quarantined[0]=True # Private terminal first BEFORE secondary metadata.
        try:
            if received is not primary:secondary.append(received)
            if row is not None:row['error']=received
        finally:
            raise primary

    group=(owner,guard,refuse,primary,secondary)
    _FAILURE_PRESERVATION_GROUPS[key]=group # Strong owner/first, process lifetime.
    return group

        except BaseException as error:
            try:group=_failure_preservation_group(self,error)
            except BaseException:raise error
            if type(group) is not tuple or len(group)!=5:raise error
            try:
                if self.pending:
                    # Preserve the actual owned child and return its waitable handle.
                    self._defer_failure(error)
                else:
                    self.finished=True
                    self._preserve_failure(error)
                    raise
            except BaseException as secondary:
                if secondary is error:raise
                group[2](secondary)