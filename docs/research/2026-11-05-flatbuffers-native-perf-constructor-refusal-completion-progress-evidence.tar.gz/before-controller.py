import sys,pathlib,json,hashlib,shutil,unittest,importlib.util,io,datetime,os
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-refusal-completion-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'before-NEW4';q.mkdir();free=shutil.disk_usage(R).free;assert free>=1024**3
 expected={'tool/native_perf_build_producer.py':'6e04cefc79c8c4725d72a19a931903fb2d1eb5b382b2916960c75c603fbc1706','tool/test_native_perf_build_producer.py':'3661f72f372c91cd152c6808074e191dd5dbd66ece8198f8ea72cc915acbfffa'}
 before={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert before==expected
 (q/'fresh2-source-test.json').write_text(json.dumps(before,indent=2));(q/'floor.json').write_text(json.dumps(dict(free_bytes=free,fresh_1GiB_floor=True,no_build_capture_deletion_authority=True)))
 os.environ['CONNECTANUM_REFUSAL_COMPLETION_FIXTURES']=str(q/'fixtures');sys.path.insert(0,str(R/'tool'))
 spec=importlib.util.spec_from_file_location('refusal_completion_scope',P/'refusal_completion_regressions-v1.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   leases.append(dict(test=str(test),position='before',raw_None=l.verify_identity() is None));super().startTest(test)
  def stopTest(self,test):
   leases.append(dict(test=str(test),position='after',raw_None=l.verify_identity() is None));super().stopTest(test)
 names=unittest.defaultTestLoader.getTestCaseNames(module.RefusalCompletionTests);assert names==['test_new_native_refusal_pendingFalse_caller_control', 'test_new_native_refusal_pendingTrue_caller_control', 'test_new_refusal_Third_cannot_replace_First', 'test_new_refusal_return_False_cannot_finish_constructor'];suite=unittest.TestSuite(module.RefusalCompletionTests(name) for name in names);stream=io.StringIO()
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(suite)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in expected};assert after==before
 (q/'stdout.txt').write_text(stream.getvalue());out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),leases=leases,Source_test_fresh2_unchanged=after,Source_test_edits=False,new_BEFORE4_only=True,prior6_old27_completed25_old2bodies_old7suite_private2_replayed=False,SourceHEAD_current20recensus_or_compiledcanonical_admission=False,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(out,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_refusal_completion_progress']={'directory':str(P),'declaration':str(P/'declaration.json'),'before_result':out,'Source_test_edits':False,'ROOT_pending':True,'SourceHEAD_current20_not_refreshed':True};c.update(updated_utc=out['utc'],active_turn_status='Constructor_refusal_completion_NEW4_BEFORE_recorded_ROOTpending');cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps({k:v for k,v in out.items() if k not in ('leases','details')}));print(stream.getvalue()[-7000:])
