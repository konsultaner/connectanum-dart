#!/usr/bin/env python3
"""Direct endpoint handoff primitives; no privileged launcher/capture entrypoint.

Live Linux credentials belong to a connected UNIX stream, not anonymous pipes.
Fixtures exercise POSIX descriptor transfer with explicit synthetic peer claims.
Listener ownership, trusted helper source, same-PID fd-exec, independent actual
sampler image/access checks and Linux capability controls remain integration work.
"""
from __future__ import annotations

import array
import base64
import fcntl
import json
import math
import os
import re
import socket
import struct
import sys
import threading
from contextlib import contextmanager
from dataclasses import dataclass

from native_perf_guard import GuardError, PipeChannel, PipeIdentity, _digest, _integer


@dataclass(frozen=True)
class Peer:
    pid: int
    uid: int
    gid: int

    def __post_init__(self):
        if not (_integer(self.pid, 1) and _integer(self.uid, 0) and _integer(self.gid, 0)):
            raise GuardError("invalid handoff peer")


def decode_ucred(data):
    if len(data) != struct.calcsize("=iII"):
        raise GuardError("invalid kernel credential record")
    return Peer(*struct.unpack("=iII", data))


def _close(fds):
    errors = []
    while fds:
        try:
            os.close(fds.pop())
        except OSError as error:
            errors.append(error)
    if errors:
        raise errors[0]


def _channel_json(channel):
    return {name: {"device": value.device, "inode": value.inode}
            for name, value in (("read_end", channel.read_end), ("write_end", channel.write_end))}


def _channel(value):
    if type(value) is not dict or set(value) != {"read_end", "write_end"}:
        raise GuardError("invalid handoff channel schema")
    ends = []
    for name in ("read_end", "write_end"):
        item = value[name]
        if type(item) is not dict or set(item) != {"device", "inode"}:
            raise GuardError("invalid handoff endpoint schema")
        ends.append(PipeIdentity(item["device"], item["inode"]))
    return PipeChannel(*ends)


def _context(declaration, nonce):
    if not _digest(declaration) or not isinstance(nonce, str) or not re.fullmatch("[0-9a-f]{32}", nonce):
        raise GuardError("invalid handoff declaration")


def _no_duplicate_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise GuardError("duplicate handoff JSON field")
        result[key] = value
    return result


class HandoffWire:
    MAX_FRAME = 8192
    MAX_RIGHTS = 256

    def __init__(self, sock, peer, *, fixture_only, timeout=10.0):
        if (sock.family != socket.AF_UNIX or sock.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE) != socket.SOCK_STREAM
                or not isinstance(peer, Peer) or type(fixture_only) is not bool
                or type(timeout) not in (float, int) or not math.isfinite(timeout) or not 0 < timeout <= 60):
            raise GuardError("invalid handoff wire")
        self.socket, self.peer, self.fixture_only = sock, peer, fixture_only
        self.state = "new"
        self.received_fds = set()
        self.evidence = []
        self.socket.settimeout(timeout)

    @classmethod
    def live(cls, sock, *, expected_uid, expected_gid, expected_pid=None, timeout=10.0):
        required = ("SO_PEERCRED", "SO_PASSCRED", "SCM_CREDENTIALS", "MSG_CMSG_CLOEXEC")
        if sys.platform != "linux" or any(not hasattr(socket, name) for name in required):
            raise GuardError("Linux credential and CLOEXEC facilities required")
        if os.getuid() != os.geteuid() or os.getgid() != os.getegid():
            raise GuardError("handoff process credential identities differ")
        peer = decode_ucred(sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("=iII")))
        if ((peer.uid, peer.gid) != (expected_uid, expected_gid)
                or expected_pid is not None and peer.pid != expected_pid):
            raise GuardError("connected handoff peer differs")
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
        return cls(sock, peer, fixture_only=False, timeout=timeout)

    @classmethod
    def fixture(cls, sock, peer, *, timeout=10.0):
        return cls(sock, peer, fixture_only=True, timeout=timeout)

    @contextmanager
    def once(self):
        if self.state != "new":
            raise GuardError("handoff is terminal; do not retry")
        if threading.active_count() != 1:
            self.state = "failed"
            raise GuardError("handoff requires a single-threaded process")
        self.state = "active"
        try:
            yield
        except BaseException as error:
            self.state = "failed"
            try:
                _close(self.received_fds)
            except OSError as cleanup_error:
                self.evidence.append({"operation": "close_refused", "errno": cleanup_error.errno})
            self.socket.close()  # Terminal failure also discards queued in-flight rights.
            self.evidence.append({"operation": "refused", "type": type(error).__name__,
                                  "errno": getattr(error, "errno", None)})
            raise
        else:
            self.state = "complete"

    def send_frame(self, value):
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
        if not 0 < len(payload) <= self.MAX_FRAME:
            raise GuardError("handoff frame size limit")
        data = struct.pack("!I", len(payload)) + payload
        record = {"operation": "send_frame", "data_base64": base64.b64encode(data).decode(), "sent_bytes": 0}
        self.evidence.append(record)
        while record["sent_bytes"] < len(data):
            count = self.socket.send(data[record["sent_bytes"]:])
            if type(count) is not int or not 0 < count <= len(data) - record["sent_bytes"]:
                raise GuardError("invalid handoff write progress")
            record["sent_bytes"] += count

    def send_rights(self, fds):
        record = {"operation": "send_rights", "fds": list(fds), "sent_bytes": 0}
        self.evidence.append(record)
        count = self.socket.sendmsg([b"H"], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", fds))])
        record["sent_bytes"] = count
        if count != 1:
            raise GuardError("handoff rights send failed; do not resend")

    def _recv(self, maximum, *, rights_count=0):
        intsize = array.array("i").itemsize
        capacity = socket.CMSG_SPACE(self.MAX_RIGHTS * intsize) + socket.CMSG_SPACE(struct.calcsize("=iII"))
        flags = 0 if self.fixture_only else socket.MSG_CMSG_CLOEXEC
        data, ancillary, message_flags, _address = self.socket.recvmsg(maximum, capacity, flags)
        record = {"operation": "recvmsg", "data_base64": base64.b64encode(data).decode(),
                  "flags": message_flags, "fixture_only": self.fixture_only,
                  "ancillary": [{"level": level, "kind": kind, "data_base64": base64.b64encode(value).decode()}
                                for level, kind, value in ancillary]}
        self.evidence.append(record)
        fds, credentials, invalid = [], [], False
        for level, kind, value in ancillary:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                whole = len(value) - len(value) % intsize
                received = array.array("i")
                received.frombytes(value[:whole])
                for fd in received:
                    self.received_fds.add(fd)
                    fds.append(fd)
                    os.set_inheritable(fd, False)
                invalid |= whole != len(value)
            elif (not self.fixture_only and level == socket.SOL_SOCKET
                  and kind == socket.SCM_CREDENTIALS):
                credentials.append(decode_ucred(value))
            else:
                invalid = True
        if (message_flags & (socket.MSG_CTRUNC | socket.MSG_TRUNC) or invalid
                or len(fds) != rights_count or len(fds) != len(set(fds))):
            raise GuardError("unexpected or truncated handoff ancillary data")
        if not self.fixture_only and credentials != [self.peer]:
            raise GuardError("handoff current sender credentials differ")
        if not data:
            raise GuardError("partial handoff EOF")
        return data, fds

    def read_frame(self):
        def exact(length):
            data = bytearray()
            while len(data) < length:
                chunk, _fds = self._recv(length - len(data))
                data.extend(chunk)
            return bytes(data)
        length = struct.unpack("!I", exact(4))[0]
        if not 0 < length <= self.MAX_FRAME:
            raise GuardError("handoff frame size limit")
        payload = exact(length)
        try:
            value = json.loads(payload, object_pairs_hook=_no_duplicate_pairs,
                               parse_constant=lambda _value: (_ for _ in ()).throw(GuardError("nonfinite handoff JSON")))
        except (ValueError, UnicodeError) as error:
            raise GuardError("invalid handoff JSON") from error
        if type(value) is not dict:
            raise GuardError("invalid handoff frame schema")
        return value

    def read_rights(self):
        data, fds = self._recv(1, rights_count=2)
        if data != b"H":
            raise GuardError("invalid handoff rights tag")
        return fds


@dataclass
class Endpoints:
    control_fd: int
    ack_fd: int
    control: PipeChannel
    ack: PipeChannel
    helper: Peer
    fixture_only: bool

    def close(self):
        for name in ("control_fd", "ack_fd"):
            fd = getattr(self, name)
            if fd >= 0:
                os.close(fd)
                setattr(self, name, -1)


def offer_endpoints(wire, declaration, nonce):
    """Create pipes inside this helper; never return controller-end duplicates.

    This does not launch perf, exec any image or operate on benchmark markers.
    Live caller must already be the trusted root helper after sudo exec.
    """
    owned = set()
    try:
        with wire.once():
            _context(declaration, nonce)
            if not wire.fixture_only and (os.getuid(), os.geteuid(), os.getgid(), os.getegid()) != (0, 0, 0, 0):
                raise GuardError("live endpoint producer must have declared root identities")
            request = wire.read_frame()
            expected_request = {"event": "request", "declaration_sha256": declaration, "nonce": nonce,
                                "controller_pid": wire.peer.pid, "fixture_only": wire.fixture_only}
            if (set(request) != set(expected_request)
                    or any(type(request[k]) is not type(v) or request[k] != v for k, v in expected_request.items())):
                raise GuardError("invalid handoff request")
            cr, cw = os.pipe()
            owned.update((cr, cw))
            ar, aw = os.pipe()
            owned.update((ar, aw))
            if min(owned) <= 2:
                raise GuardError("private handoff endpoints overlap stdio")
            control, ack = PipeChannel.from_fds(cr, cw), PipeChannel.from_fds(ar, aw)
            if control.identities & ack.identities:
                raise GuardError("handoff channels alias")
            helper = Peer(os.getpid(), os.geteuid(), os.getegid())
            common = {"declaration_sha256": declaration, "nonce": nonce, "helper_pid": helper.pid,
                      "helper_uid": helper.uid, "helper_gid": helper.gid, "fixture_only": wire.fixture_only}
            wire.send_frame({"event": "offer", **common, "control": _channel_json(control), "ack": _channel_json(ack)})
            wire.send_rights((cw, ar))
            for fd in (cw, ar):
                os.close(fd)
                owned.remove(fd)
            wire.send_frame({"event": "copies_closed", **common})
            result = Endpoints(cr, aw, control, ack, helper, wire.fixture_only)
            owned.clear()
            return result
    finally:
        _close(owned)


def receive_endpoints(wire, declaration, nonce):
    with wire.once():
        _context(declaration, nonce)
        wire.send_frame({"event": "request", "declaration_sha256": declaration, "nonce": nonce,
                         "controller_pid": os.getpid(), "fixture_only": wire.fixture_only})
        offer = wire.read_frame()
        common = {"declaration_sha256": declaration, "nonce": nonce, "helper_pid": wire.peer.pid,
                  "helper_uid": wire.peer.uid, "helper_gid": wire.peer.gid, "fixture_only": wire.fixture_only}
        if set(offer) != set(common) | {"event", "control", "ack"} or offer.get("event") != "offer":
            raise GuardError("invalid handoff offer schema")
        for name, expected in common.items():
            if type(offer[name]) is not type(expected) or offer[name] != expected:
                raise GuardError("handoff peer or declaration context differs")
        control, ack = _channel(offer['control']), _channel(offer['ack'])
        if control.identities & ack.identities:
            raise GuardError("handoff channels alias")
        cw, ar = wire.read_rights()
        if (PipeIdentity.from_fd(cw) != control.write_end or PipeIdentity.from_fd(ar) != ack.read_end
                or fcntl.fcntl(cw, fcntl.F_GETFL) & os.O_ACCMODE != os.O_WRONLY
                or fcntl.fcntl(ar, fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY):
            raise GuardError("received handoff endpoints differ")
        completed = wire.read_frame()
        if completed != {"event": "copies_closed", **common}:
            raise GuardError("invalid handoff completion")
        # Ownership is transferred only after complete validation.
        wire.received_fds.difference_update((cw, ar))
        return Endpoints(cw, ar, control, ack, wire.peer, wire.fixture_only)


if __name__ == "__main__":
    raise SystemExit("Handoff component only; no privileged-launcher/capture entrypoint")
