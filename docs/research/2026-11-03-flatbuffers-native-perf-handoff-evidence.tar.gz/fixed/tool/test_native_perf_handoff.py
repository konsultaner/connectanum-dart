from __future__ import annotations

import array
import base64
import errno
import fcntl
import json
import os
import select
import signal
import socket
import stat
import struct
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import native_perf_handoff as handoff
from native_perf_blocked_exec import _open_fds
from native_perf_guard import GuardError, PipeIdentity
from native_perf_handoff import HandoffWire, Peer, offer_endpoints, receive_endpoints


class SocketProxy:
    def __init__(self, sock, *, chunk=None, mutate=None, zero_sendmsg=False):
        self.sock, self.chunk, self.mutate = sock, chunk, mutate
        self.zero_sendmsg = zero_sendmsg
        self.received = []

    def __getattr__(self, name):
        return getattr(self.sock, name)

    def send(self, data):
        return self.sock.send(data[:self.chunk] if self.chunk else data)

    def sendmsg(self, *args):
        return 0 if self.zero_sendmsg else self.sock.sendmsg(*args)

    def recvmsg(self, length, capacity, flags=0):
        data, anc, outflags, address = self.sock.recvmsg(min(length, self.chunk) if self.chunk else length, capacity, flags)
        for level, kind, value in anc:
            if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                values = array.array('i')
                values.frombytes(value[:len(value) - len(value) % values.itemsize])
                for fd in values:
                    info = os.fstat(fd)
                    self.received.append((fd, info.st_dev, info.st_ino, stat.S_IFMT(info.st_mode)))
        result = (data, anc, outflags, address)
        return self.mutate(result) if self.mutate else result


@unittest.skipUnless(os.name == 'posix' and hasattr(os, 'fork') and hasattr(socket, 'SCM_RIGHTS'), 'OWN POSIX IPC fixtures')
class HandoffTests(unittest.TestCase):
    """NO actual Linux/root credentials, perf, image exec or benchmark evidence."""
    DECLARATION = 'a' * 64
    NONCE = 'b' * 32

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.children = []
        self.addCleanup(self.reap)
        self.proxies = []
        self.addCleanup(self.cleanup_received)

    def cleanup_received(self):
        # Only exact OWN received-copy identities, never a recycled descriptor.
        for proxy in self.proxies:
            for fd, device, inode, kind in proxy.received:
                try:
                    info = os.fstat(fd)
                    if (info.st_dev, info.st_ino, stat.S_IFMT(info.st_mode)) == (device, inode, kind):
                        os.close(fd)
                except OSError as error:
                    if error.errno != errno.EBADF:
                        raise

    def assert_received_closed(self, proxy):
        self.assertTrue(proxy.received)
        for fd, _dev, _ino, _kind in proxy.received:
            with self.assertRaises(OSError) as caught:
                os.fstat(fd)
            self.assertEqual(caught.exception.errno, errno.EBADF)

    def reap(self):
        for pid, _result in self.children:
            deadline = time.monotonic() + 1
            while True:
                try:
                    found, _status = os.waitpid(pid, os.WNOHANG)
                except ChildProcessError:
                    break  # Never signal a reaped/recycled numeric PID.
                if found:
                    break
                if time.monotonic() >= deadline:
                    os.kill(pid, signal.SIGKILL)  # Only OWN unexecuted synthetic helper fixture.
                    os.waitpid(pid, 0)
                    break
                time.sleep(.005)

    def pair(self, **proxy_options):
        left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        self.addCleanup(left.close)
        self.addCleanup(right.close)
        proxy = SocketProxy(right, **proxy_options)
        self.proxies.append(proxy)
        wire = HandoffWire.fixture(proxy, Peer(os.getpid(), os.geteuid(), os.getegid()), timeout=1)
        return left, wire, proxy

    def pipes(self):
        values = os.pipe() + os.pipe()
        for fd in values:
            self.addCleanup(os.close, fd)
        return values

    def helper(self, *, mutate_frame=None, mutate_request=None, rights_mode=None, flow=False, chunk=None, zero_rights=False, fake_root_peer=False):
        parent, child = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        result = self.directory / f'helper-{len(self.children)}.json'
        parent_pid, uid, gid = os.getpid(), os.geteuid(), os.getegid()
        pid = os.fork()
        if pid == 0:
            parent.close()
            ends = None
            wire = HandoffWire.fixture(SocketProxy(child, chunk=chunk, zero_sendmsg=zero_rights), Peer(parent_pid, uid, gid), timeout=1)
            record = {'fixture_only': True, 'pid': os.getpid(), 'uid': os.geteuid(), 'gid': os.getegid(), 'pipe_creations': 0}
            try:
                if mutate_frame:
                    send_frame = wire.send_frame
                    def mutate(value):
                        send_frame(mutate_frame(dict(value)))
                    wire.send_frame = mutate
                if rights_mode:
                    send_rights = wire.send_rights
                    def wrong_rights(fds):
                        send_rights((fds[1], fds[0]) if rights_mode == 'swap' else (fds[0], fds[0]))
                    wire.send_rights = wrong_rights
                create_pipe = os.pipe
                def counted_pipe():
                    record['pipe_creations'] += 1
                    return create_pipe()
                with patch('native_perf_handoff.os.pipe', side_effect=counted_pipe):
                    ends = offer_endpoints(wire, self.DECLARATION, self.NONCE)
                private = ends.control.identities | ends.ack.identities
                observed = []
                for fd in _open_fds():
                    if stat.S_ISFIFO(os.fstat(fd).st_mode):
                        identity = PipeIdentity.from_fd(fd)
                        if identity in private:
                            observed.append((fd, identity.device, identity.inode))
                record['retained_private_endpoints'] = observed
                record['producer_ends'] = [ends.control_fd, ends.ack_fd]
                if flow:
                    if not select.select([ends.control_fd], [], [], 1)[0] or os.read(ends.control_fd, 5) != b'ping\n':
                        raise GuardError('fixture control flow failed')
                    os.write(ends.ack_fd, b'ack\n')
                record['result'] = 'offered'
            except BaseException as error:
                record.update(result='refused', error=type(error).__name__, reason=str(error))
            finally:
                if ends:
                    ends.close()
                child.close()
                record['wire_state'] = wire.state
                record['rights_send_attempts'] = sum(e['operation'] == 'send_rights' for e in wire.evidence)
                result.write_text(json.dumps(record))
                os._exit(0)
        child.close()
        self.children.append((pid, result))
        self.addCleanup(parent.close)
        proxy = SocketProxy(parent, chunk=chunk)
        self.proxies.append(proxy)
        peer = Peer(pid, 0 if fake_root_peer else uid, 0 if fake_root_peer else gid)
        wire = HandoffWire.fixture(proxy, peer, timeout=1)
        if mutate_request:
            send_frame = wire.send_frame
            wire.send_frame = lambda value: send_frame(mutate_request(dict(value)))
        return wire, proxy, result

    def child_result(self, path):
        deadline = time.monotonic() + 1
        while not path.exists():
            if time.monotonic() >= deadline:
                self.fail('OWN fixture result missing')
            time.sleep(.005)
        return json.loads(path.read_text())

    def test_full_transfer_is_bidirectional_and_only_producer_ends_remain(self):
        wire, _proxy, result = self.helper(flow=True)
        ends = receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.addCleanup(ends.close)
        self.assertTrue(ends.fixture_only)
        self.assertEqual(wire.state, 'complete')
        self.assertFalse(os.get_inheritable(ends.control_fd))
        self.assertFalse(os.get_inheritable(ends.ack_fd))
        self.assertEqual(fcntl.fcntl(ends.control_fd, fcntl.F_GETFL) & os.O_ACCMODE, os.O_WRONLY)
        os.write(ends.control_fd, b'ping\n')
        self.assertTrue(select.select([ends.ack_fd], [], [], 1)[0])
        self.assertEqual(os.read(ends.ack_fd, 4), b'ack\n')
        actual = self.child_result(result)
        self.assertEqual(actual['result'], 'offered')
        self.assertEqual(len(actual['retained_private_endpoints']), 2)
        self.assertEqual(sorted(v[0] for v in actual['retained_private_endpoints']), sorted(actual['producer_ends']))

    def test_fragmented_frames_survive_one_byte_stream_reads(self):
        wire, _proxy, _result = self.helper(chunk=1)
        ends = receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.addCleanup(ends.close)
        self.assertEqual(wire.state, 'complete')

    def test_offer_context_mismatches_are_terminal(self):
        for field, value in [('nonce', 'c' * 32), ('declaration_sha256', 'd' * 64), ('helper_pid', 1), ('fixture_only', False)]:
            def mutate(frame):
                if frame['event'] == 'offer':
                    frame[field] = value
                return frame
            wire, _proxy, result = self.helper(mutate_frame=mutate)
            with self.subTest(field=field), self.assertRaisesRegex(GuardError, 'context'):
                receive_endpoints(wire, self.DECLARATION, self.NONCE)
            self.assertEqual(wire.state, 'failed')
            with self.assertRaisesRegex(GuardError, 'terminal'):
                receive_endpoints(wire, self.DECLARATION, self.NONCE)
            self.child_result(result)

    def test_wrong_channel_identity_or_alias_refuses(self):
        for alias in (False, True):
            def mutate(frame):
                if frame['event'] == 'offer':
                    if alias:
                        frame['ack'] = frame['control']
                    else:
                        frame['control']['write_end']['inode'] += 1
                return frame
            wire, proxy, result = self.helper(mutate_frame=mutate)
            with self.subTest(alias=alias), self.assertRaisesRegex(GuardError, 'alias|endpoints differ'):
                receive_endpoints(wire, self.DECLARATION, self.NONCE)
            if not alias:
                self.assert_received_closed(proxy)
            self.child_result(result)

    def test_missing_or_malformed_completion_closes_received_copies(self):
        def mutate(frame):
            if frame['event'] == 'copies_closed':
                frame['nonce'] = 'f' * 32
            return frame
        wire, proxy, result = self.helper(mutate_frame=mutate)
        with self.assertRaisesRegex(GuardError, 'completion'):
            receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.assert_received_closed(proxy)
        self.child_result(result)

    def test_completion_boolean_does_not_alias_root_uid_integer(self):
        def mutate(frame):
            frame['helper_uid'] = 0 if frame['event'] == 'offer' else False
            frame['helper_gid'] = 0
            return frame
        wire, proxy, result = self.helper(mutate_frame=mutate, fake_root_peer=True)
        with self.assertRaisesRegex(GuardError, 'completion'):
            ends = receive_endpoints(wire, self.DECLARATION, self.NONCE)
            self.addCleanup(ends.close)
        self.assert_received_closed(proxy)
        self.child_result(result)

    def test_success_cannot_be_replayed_on_same_wire(self):
        wire, _proxy, result = self.helper()
        ends = receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.addCleanup(ends.close)
        with self.assertRaisesRegex(GuardError, 'terminal'):
            receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.assertEqual(wire.state, 'complete')
        self.child_result(result)

    def test_short_rights_send_refuses_without_resend(self):
        wire, _proxy, result = self.helper(zero_rights=True)
        with self.assertRaisesRegex(GuardError, 'EOF|ancillary'):
            receive_endpoints(wire, self.DECLARATION, self.NONCE)
        child = self.child_result(result)
        self.assertEqual(child['wire_state'], 'failed')
        self.assertIn('do not resend', child['reason'])
        self.assertEqual(child['rights_send_attempts'], 1)

    def test_metadata_rights_are_closed_on_refusal(self):
        left, wire, proxy = self.pair()
        fds = self.pipes()
        left.sendmsg([struct.pack('!I', 2) + b'{}'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:2]))])
        with self.assertRaisesRegex(GuardError, 'ancillary'):
            with wire.once():
                wire.read_frame()
        self.assert_received_closed(proxy)
        self.assertTrue(wire.evidence)
        self.assertEqual(wire.state, 'failed')

    def test_wrong_rights_count_is_closed(self):
        for count in (1, 3, 4):
            left, wire, proxy = self.pair()
            fds = self.pipes()
            left.sendmsg([b'H'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:count]))])
            with self.subTest(count=count), self.assertRaisesRegex(GuardError, 'ancillary'):
                with wire.once():
                    wire.read_rights()
            self.assert_received_closed(proxy)

    def test_truncated_or_misaligned_rights_close_every_delivered_fd(self):
        for kind in ('ctrunc', 'trunc', 'misaligned'):
            def mutate(result):
                data, anc, flags, address = result
                if kind == 'ctrunc':
                    flags |= socket.MSG_CTRUNC
                elif kind == 'trunc':
                    flags |= socket.MSG_TRUNC
                else:
                    anc = [(level, ctype, value + b'x') for level, ctype, value in anc]
                return data, anc, flags, address
            left, wire, proxy = self.pair(mutate=mutate)
            fds = self.pipes()
            left.sendmsg([b'H'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:2]))])
            with self.subTest(kind=kind), self.assertRaisesRegex(GuardError, 'ancillary'):
                with wire.once():
                    wire.read_rights()
            self.assert_received_closed(proxy)

    def test_bad_tag_closes_received_fds(self):
        left, wire, proxy = self.pair()
        fds = self.pipes()
        left.sendmsg([b'X'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:2]))])
        with self.assertRaisesRegex(GuardError, 'tag'):
            with wire.once():
                wire.read_rights()
        self.assert_received_closed(proxy)

    def test_missing_rights_refuses(self):
        left, wire, _proxy = self.pair()
        left.sendall(b'H')
        with self.assertRaisesRegex(GuardError, 'ancillary'):
            with wire.once():
                wire.read_rights()

    def test_malformed_credential_before_rights_closes_all_copies(self):
        # SYNTHETIC Linux-decoder branch only: fake credential kind/flag, real OWN rights.
        synthetic_kind = 0xF00D
        def mutate(result):
            data, anc, flags, address = result
            return data, [(socket.SOL_SOCKET, synthetic_kind, b'x')] + anc, flags, address
        left, wire, proxy = self.pair(mutate=mutate)
        fds = self.pipes()
        left.sendmsg([b'H'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:2]))])
        wire.fixture_only = False
        with patch.object(socket, 'SCM_CREDENTIALS', synthetic_kind, create=True), patch.object(socket, 'MSG_CMSG_CLOEXEC', 0, create=True):
            with self.assertRaisesRegex(GuardError, 'credential'):
                with wire.once():
                    wire.read_rights()
        self.assert_received_closed(proxy)

    def test_wrong_current_sender_credentials_close_received_copies(self):
        synthetic_kind = 0xF00D
        def mutate(result):
            data, anc, flags, address = result
            cred = struct.pack('=iII', os.getpid() + 1, os.geteuid(), os.getegid())
            return data, anc + [(socket.SOL_SOCKET, synthetic_kind, cred)], flags, address
        left, wire, proxy = self.pair(mutate=mutate)
        fds = self.pipes()
        left.sendmsg([b'H'], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds[:2]))])
        wire.fixture_only = False
        with patch.object(socket, 'SCM_CREDENTIALS', synthetic_kind, create=True), patch.object(socket, 'MSG_CMSG_CLOEXEC', 0, create=True):
            with self.assertRaisesRegex(GuardError, 'current sender'):
                with wire.once():
                    wire.read_rights()
        self.assert_received_closed(proxy)

    def test_partial_header_and_oversized_frame_are_retained(self):
        for payload in (b'\x00\x01', struct.pack('!I', 8193)):
            left, wire, _proxy = self.pair()
            left.sendall(payload)
            left.close()
            with self.subTest(payload=payload), self.assertRaisesRegex(GuardError, 'EOF|size limit'):
                with wire.once():
                    wire.read_frame()
            received = b''.join(base64.b64decode(e['data_base64']) for e in wire.evidence if e['operation'] == 'recvmsg')
            self.assertEqual(received, payload)

    def test_json_duplicates_invalid_encoding_and_nonfinite_values_refuse(self):
        for payload in (b'{"event":1,"event":2}', b'\xff', b'{"value":NaN}', b'[]'):
            left, wire, _proxy = self.pair()
            left.sendall(struct.pack('!I', len(payload)) + payload)
            with self.subTest(payload=payload), self.assertRaises(GuardError):
                with wire.once():
                    wire.read_frame()

    def test_invalid_nonce_refuses_before_request_or_pipe_creation(self):
        left, wire, _proxy = self.pair()
        with self.assertRaisesRegex(GuardError, 'declaration'):
            receive_endpoints(wire, self.DECLARATION, 'bad')
        self.assertFalse(any(e['operation'] == 'send_frame' for e in wire.evidence))

    def test_live_factory_has_no_darwin_fallback(self):
        left, _wire, _proxy = self.pair()
        with patch('native_perf_handoff.sys.platform', 'darwin'), self.assertRaisesRegex(GuardError, 'Linux'):
            HandoffWire.live(left, expected_uid=0, expected_gid=0)

    def test_peer_and_wire_types_or_timeout_are_guarded(self):
        for value in (Peer(os.getpid(), os.geteuid(), os.getegid()),):
            for timeout in (False, 0, 61, float('inf')):
                left, _wire, _proxy = self.pair()
                with self.subTest(timeout=timeout), self.assertRaisesRegex(GuardError, 'wire'):
                    HandoffWire.fixture(left, value, timeout=timeout)
        for args in ((True, 0, 0), (1, False, 0), (0, 0, 0)):
            with self.subTest(args=args), self.assertRaisesRegex(GuardError, 'peer'):
                Peer(*args)

    def test_multithreaded_handoff_is_terminal(self):
        left, wire, _proxy = self.pair()
        with patch('native_perf_handoff.threading.active_count', return_value=2):
            with self.assertRaisesRegex(GuardError, 'single-threaded'):
                receive_endpoints(wire, self.DECLARATION, self.NONCE)
        self.assertEqual(wire.state, 'failed')
        self.assertFalse(wire.evidence)

    def test_swapped_or_duplicated_transfer_ends_are_refused(self):
        for mode in ('swap', 'duplicate'):
            wire, proxy, result = self.helper(rights_mode=mode)
            with self.subTest(mode=mode), self.assertRaisesRegex(GuardError, 'endpoints differ'):
                receive_endpoints(wire, self.DECLARATION, self.NONCE)
            self.assert_received_closed(proxy)
            self.child_result(result)

    def test_wrong_request_refuses_before_producer_creates_pipes(self):
        def mutate(frame):
            frame['nonce'] = 'f' * 32
            return frame
        wire, _proxy, result = self.helper(mutate_request=mutate)
        with self.assertRaisesRegex(GuardError, 'EOF'):
            receive_endpoints(wire, self.DECLARATION, self.NONCE)
        child = self.child_result(result)
        self.assertEqual(child['pipe_creations'], 0)
        self.assertEqual(child['rights_send_attempts'], 0)
        self.assertEqual(child['wire_state'], 'failed')
        self.assertIn('invalid handoff request', child['reason'])
