"""NEW snapshot open/stat return-shape and empty-file controls."""
import os
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class SnapshotOpenStatTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_OPEN_FIXTURES'])
        self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root));self.path=self.base/'empty.bin'
        with self.path.open('xb'):pass

    def _case(self,mode):
        calls=[];fds=[];seen={};evidence_ready=False;native_os=producer.os
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT open-stat first/FalseFD barrier')
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs);info=native_os.fstat(raw)
                fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)))
                calls.append(dict(kind='native_open_return',fd=raw,flags=flags))
                if mode=='open_False':return False
                if mode=='open_unknown':raise first
                return raw
            def fstat(self,fd):
                calls.append(dict(kind='Source_fstat_attempt',fd_False=fd is False))
                if fd is False:raise first # Never delegate native FD0.
                raw=native_os.fstat(fd);seen['ROOT_native_stat']=raw;calls.append(dict(kind='native_fstat_return',dev=raw.st_dev,ino=raw.st_ino,size=raw.st_size))
                if mode=='stat_None':return None
                if mode=='stat_unknown':raise first
                return raw
            def getuid(self):
                calls.append(dict(kind='Source_getuid_attempt'));return native_os.getuid()
            def read(self,fd,size):
                calls.append(dict(kind='Source_read_attempt'));raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw)));return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt'));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None));return raw
        returned=False;result=None;received=None;guard_error=None;attempt=None
        try:
            before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            with mock.patch.object(producer,'os',OSFacade()):
                try:result=producer._file_snapshot(self.path);returned=True
                except BaseException as error:received=error
            attempts=producer._FILE_SNAPSHOT_ATTEMPTS[before:];attempt=attempts[-1] if attempts else None
            if mode!='normal' and attempt is not None:
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=[] if attempt is None else attempt.steps
            view=dict(mode=mode,snapshot_open_stat_control=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,pure_guard_same_received=received is not None and guard_error is received,
                Source_attempt_present=attempt is not None,Source_first_received=False if attempt is None else attempt.first_error is received,Source_completed=None if attempt is None else attempt.completed,
                Source_fd_None=None if attempt is None else attempt.fd is None,Source_fd_False=None if attempt is None else attempt.fd is False,Source_fd_original=False if attempt is None or not fds else attempt.fd is fds[0]['fd'],
                Source_close_returned=None if attempt is None else attempt.close_returned,ROOT_native_stat_known='ROOT_native_stat' in seen,
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,raw_original_FD=bool(fds) and r['raw'] is fds[0]['fd'],raw_original_stat=r['raw'] is seen.get('ROOT_native_stat'),error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='MODULELOCALosfacade/nativeopen-fstat ofOWNemptyfile; ROOTactualFD/devino registeredBEFOREfault. Falsefstat barrier BEFOREnativeFD0/NEVERdelegateFalse. UnknownSourceopen/statNoneFalse neverRootnativeFD-statfilled. Negativepureguard/no SourceIO-close-repr-note-retry-replay-restore; ROOTknownsameopenFDdevino closeAFTERevidence UNITnotSourcecleanup-fullindependentEX-originalLinux-allFD-delegate-descendantclosure-ownership/admission. ZEROnewchild/emptybodyunitnotbenchmark/memoryRSSbound/cause.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable']);self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags'])
            self.assertTrue(attempt is not None)
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertEqual(dict(size=0,sha256=hashlib.sha256(b'').hexdigest()),result);self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned)
                self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls));self.assertEqual([0],[x['size'] for x in calls if x['kind']=='native_read_return'])
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed);self.assertFalse(attempt.close_returned)
                self.assertFalse(any(x['kind'] in ('Source_getuid_attempt','Source_read_attempt','Source_close_attempt','repr_first','note_first') for x in calls))
                last=rows[-1]
                if mode in ('open_False','stat_None'):
                    self.assertTrue(type(received) is producer.ProducerError)
                    if mode=='open_False':
                        self.assertIsNone(attempt.fd);self.assertEqual('open',last['stage']);self.assertTrue(last['returned']);self.assertTrue(last['raw'] is False);self.assertFalse(any(x['kind']=='Source_fstat_attempt' for x in calls))
                    else:
                        self.assertTrue(attempt.fd is fds[0]['fd']);self.assertEqual('fstat_before',last['stage']);self.assertTrue(last['returned']);self.assertIsNone(last['raw']);self.assertTrue('ROOT_native_stat' in seen)
                else:
                    self.assertTrue(received is first);self.assertFalse(last['returned']);self.assertIsNone(last['raw']);self.assertTrue(last['error'] is first)
                    if mode=='open_unknown':self.assertIsNone(attempt.fd);self.assertEqual('open',last['stage']);self.assertFalse(any(x['kind']=='Source_fstat_attempt' for x in calls))
                    else:self.assertTrue(attempt.fd is fds[0]['fd']);self.assertEqual('fstat_before',last['stage']);self.assertTrue('ROOT_native_stat' in seen)
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('snapshot open-stat pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);path=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(path.st_dev,path.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_open_then_False_refuses_before_fstat_nativeFD0(self):self._case('open_False')
    def test_actual_fstat_then_None_refuses_known_invalid_stat(self):self._case('stat_None')
    def test_actual_open_then_first_keeps_unknown_nativeFD(self):self._case('open_unknown')
    def test_actual_fstat_then_first_keeps_unknown_native_stat(self):self._case('stat_unknown')
    def test_new_normal_emptyfile_preserves_size_emptysha_flags_EOF_close(self):self._case('normal')
