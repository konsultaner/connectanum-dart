import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-snapshot-open-stat-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-snapshot-open-stat-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='e93fff4c9cc2714eeda586d94bee7ed570929b06'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Reject invalid snapshot open and stat returns before use\n\nThe snapshot helper accepted an interposed False open return as an FD and attempted fstat(False). A ROOT barrier prevented native FD0 access. A known None fstat return reached attribute access and produced AttributeError. Two checks now reject non-native/negative FD returns before storing or using them, and non-native stat returns before interpreting fields. Known invalid returns remain known in the attempt rows; ROOT-known native FD/stat values are never substituted.\n\nNEW5 befored42980/0c3ddf yields2FAIL/3PASS/0ERROR: two classification/refusal policies, not two spontaneous kernel bugs or a RAM cause. Distinct unknown-open/unknown-stat controls and a new normal empty-file control already passed. Finalb2488d/f12e8f passes28selected=5matchingNEW+23affected(5previoussnapshot8end10actualwaitcallers). Empty snapshots still return size0 and the native empty SHA, with original flags, EOF, digest and close order. All other Source bytes remain exact; old test prefix is exact. Ten new direct views plus5affected direct/8end-command views and currentDarwinEX observations are UNIT facts, not full independent EX/originalLinuxcredentials/actor closure. Qwen69209/GLM69539 complete0/fullanswers/reaped are ROOTqualified; flag-fallback, import-time, base-path and cleanup claims are corrected in the assessment.\n\nRaw chunk retention remains unchanged and does not establish fixed-memory streaming or a RAM repair. Source remains uncommitted, uncanonical and unadmitted; runtime admission and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-snapshot-open-stat-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: refuse invalid snapshot open and stat returns'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_open_stat_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Snapshot earlierconstructor-registration/metadata-globalbindings-open/postreadfstat-pathstat-returnshapes-calleeinterior-ABA; otherAPIs/enclosing-publicunknownCtor; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Currentb2488d/f12e8f ONLY2earlySnapshotchecks: exactintFD>=0 BEFOREself.fd/fstat, exactos.stat_result BEFOREfields-uid-hash-read; knownFalseopen returnedTrue leavesfdNone/no SourcefstatFalse/nativeFD0/RootactualFDneveradopted; knownNonefstat returnedTrue stopsbeforeAttributeError. Unknownopen/statNoneFalse unchanged/no ROOTfill. NEW5befored42980/0c3ddf=2FAIL3PASS0ERROR/knownshapepolicies NOT2nativekernelbugs-RAMcause; two unknowncontrols+normalEMPTYalreadyPASS. Final28PASS=5NEW23affected(5snapshot8end10actualwaitcallers)/no old5BEFORE/model-numericalreplay-aggregate-current20canonical-admission. Nativeempty0bytes-emptySHA/EOF/digest-close/flags/order/oldguard-privatefirst-capture andallothermethodshelpersfactoriesfrozenpredicates exact/wholeSourceBYTEprojectback/oldtestPREFIXexact.10newdirectviews+5priordirect8end/EX10before56after/ZEROnewchild/RootknownFDdevino close4negatives before4-after4/5priorSource3Rootcloses-separate/8endRootsameboundwait10 signed7zero1threeCached UNITnotSourcecleanup-liveownership-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. Negativepureguardonly/no Sourceuid-read-close-repr-note-retry-replay-restore/reset; actualnativeFD/stat neverROOTadopted.Sourcefd0wouldbevalidonlyactualnativeint0notFalse. Qwen69209=0/1636out398err-GLM69539=0/2277out684err/fullanswers-reaped-ROOTqualified/rejectfakeFD1-FD0devnull/syscalltrace/flagsimporttime-getattr0weakening/basepathunset/BaseExceptionswallow/statidentityrelaxation-pop-reset. Candidatev1-privatev1UNEXECUTEDbeforeedit-firstBEFORE/controllersBEFOREcalls/ROOTwholefinalAST/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. Rawchunkrefs unchanged NOTfixedmemory/default16GiBlogicalfilelimitNOTheapbound/growth-heapRSS-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-reset-evict-deleteauthority. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_snapshot_open_stat_selected28PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
