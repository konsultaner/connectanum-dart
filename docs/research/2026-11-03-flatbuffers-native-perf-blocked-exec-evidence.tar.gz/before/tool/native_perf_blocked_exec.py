#!/usr/bin/env python3
"""Owned blocked-exec component; no perf/benchmark capture entrypoint.

Darwin tests use an explicit exec callback. Such fixtures establish POSIX IPC
behavior only, not Linux fd-exec, sampler identity, inheritance or readiness.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import selectors
import signal
import stat
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from native_perf_guard import (
    FrozenLaunch, GuardError, PipeChannel, PipeIdentity, _digest, _write_all, parse_process_stat,
)


def environment_hash(environment) -> str:
    data = json.dumps(sorted(environment.items()), ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("ascii")).hexdigest()


def _file_identity(fd: int) -> tuple[int, ...]:
    info = os.fstat(fd)
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns, info.st_mode


def _file_hash(fd: int) -> str:
    digest = hashlib.sha256()
    offset = 0
    while data := os.pread(fd, 1024 * 1024, offset):
        digest.update(data)
        offset += len(data)
    return digest.hexdigest()


def _open_fds() -> list[int]:
    directory = Path("/proc/self/fd") if sys.platform.startswith("linux") else Path("/dev/fd")
    result = []
    for name in os.listdir(directory):
        if name.isdecimal():
            fd = int(name)
            try:
                os.fstat(fd)
            except OSError:
                continue  # Directory enumeration may have closed its own fd.
            result.append(fd)
    return sorted(result)


def _read_message(fd: int, maximum: int, timeout: float, *, require_eof: bool,
                  received: bytearray | None = None) -> bytes:
    deadline = time.monotonic() + timeout
    data = received if received is not None else bytearray()
    with selectors.DefaultSelector() as selector:
        selector.register(fd, selectors.EVENT_READ)
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not selector.select(remaining):
                raise GuardError("blocked-exec protocol timeout")
            chunk = os.read(fd, maximum + 1 - len(data))
            if not chunk:
                return bytes(data)
            data.extend(chunk)
            if len(data) > maximum:
                raise GuardError("blocked-exec message too long")
            if not require_eof and b"\n" in data:
                if data.count(b"\n") != 1 or not data.endswith(b"\n"):
                    raise GuardError("invalid blocked-exec ready framing")
                return bytes(data)


@dataclass(frozen=True)
class BlockedSpec:
    policy: FrozenLaunch
    driver_sha256: str
    declaration_sha256: str
    nonce: str
    marker_directory: Path
    cwd: Path
    timeout_seconds: float = 10.0

    def __post_init__(self):
        import re

        if (not _digest(self.driver_sha256) or not _digest(self.declaration_sha256)
                or not isinstance(self.nonce, str)
                or re.fullmatch(r"[0-9a-f]{32}", self.nonce) is None
                or type(self.timeout_seconds) not in (float, int)
                or not math.isfinite(self.timeout_seconds) or not 0 < self.timeout_seconds <= 60):
            raise GuardError("invalid blocked-exec specification")


@dataclass
class BlockedChild:
    pid: int
    go_fd: int
    ready_fd: int
    go_channel: PipeChannel
    ready_channel: PipeChannel
    ready_bytes: bytes = b""

    def read_ready(self, timeout: float = 10.0) -> dict:
        received = bytearray()
        try:
            data = _read_message(self.ready_fd, 8192, timeout, require_eof=False, received=received)
        finally:
            self.ready_bytes = bytes(received)  # Preserve even malformed/partial framing.
        try:
            ready = json.loads(data)
        except (ValueError, UnicodeError) as error:
            raise GuardError("invalid blocked-exec ready record") from error
        if (not data.endswith(b"\n") or not isinstance(ready, dict)
                or ready.get("event") != "blocked" or ready.get("pid") != self.pid):
            raise GuardError("blocked-exec child refused or changed identity")
        return ready

    def close_go(self) -> None:
        if self.go_fd >= 0:
            os.close(self.go_fd)
            self.go_fd = -1

    def wait(self, timeout: float = 10.0) -> int:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            pid, status = os.waitpid(self.pid, os.WNOHANG)
            if pid:
                return os.waitstatus_to_exitcode(status)
            time.sleep(0.005)
        raise GuardError("owned blocked-exec child did not exit")


def start_blocked(spec: BlockedSpec, log_fd: int, *,
                  test_exec: Callable | None = None) -> BlockedChild:
    """Fork a blocked original-credential child; real exec requires Linux FD exec.

    The caller owns reaping and all evidence. No automatic benchmark retry,
    cancellation, sampler operation or capture orchestration happens here.
    """
    if threading.active_count() != 1:
        raise GuardError("blocked executor requires a single-threaded controller")
    if test_exec is None and (not sys.platform.startswith("linux") or os.execve not in os.supports_fd):
        raise GuardError("Linux fd-exec capability is required; no path fallback")
    import fcntl

    log_info = os.fstat(log_fd)
    if (not stat.S_ISREG(log_info.st_mode)
            or fcntl.fcntl(log_fd, fcntl.F_GETFL) & os.O_ACCMODE not in (os.O_WRONLY, os.O_RDWR)):
        raise GuardError("driver log must be a writable regular file")
    if not Path(spec.policy.argv[0]).is_absolute():
        raise GuardError("declared driver path must be absolute")
    marker_path = spec.marker_directory.resolve(strict=True)
    cwd = spec.cwd.resolve(strict=True)
    executable = Path(spec.policy.argv[0]).resolve(strict=True)
    driver_fd = os.open(executable, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    directory_fd = None
    pipes = []
    try:
        info = os.fstat(driver_fd)
        image_identity = _file_identity(driver_fd)
        if (not stat.S_ISREG(info.st_mode) or not info.st_mode & 0o111
                or _file_hash(driver_fd) != spec.driver_sha256
                or _file_identity(driver_fd) != image_identity):
            raise GuardError("declared driver image mismatch")
        if test_exec is None and os.pread(driver_fd, 4, 0) != b"\x7fELF":
            raise GuardError("real fd-exec requires the declared ELF image")
        directory_fd = os.open(marker_path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | os.O_NOFOLLOW)
        if os.path.lexists(marker_path / "capture-consumed.json"):
            raise GuardError("existing consumed marker is terminal")
        directory_identity = os.fstat(directory_fd).st_dev, os.fstat(directory_fd).st_ino
        go_read, go_write = os.pipe()
        ready_read, ready_write = os.pipe()
        pipes = [go_read, go_write, ready_read, ready_write]
        if min(pipes) <= 2:
            raise GuardError("private protocol fd overlaps stdio")
        go_channel = PipeChannel.from_fds(go_read, go_write)
        ready_channel = PipeChannel.from_fds(ready_read, ready_write)
        parent_pid = os.getpid()
        expected_mask = signal.pthread_sigmask(signal.SIG_BLOCK, [])
        pid = os.fork()
        if pid == 0:
            try:
                os.setsid()
                os.chdir(cwd)
                null_fd = os.open(os.devnull, os.O_RDONLY | os.O_CLOEXEC)
                os.dup2(null_fd, 0)
                os.dup2(log_fd, 1)
                os.dup2(log_fd, 2)
                keep = {0, 1, 2, go_read, ready_write, driver_fd, directory_fd}
                for fd in _open_fds():
                    if fd not in keep:
                        os.close(fd)
                _child(spec, executable, image_identity, marker_path, directory_identity,
                       cwd, parent_pid, expected_mask, go_read, ready_write, driver_fd,
                       directory_fd, test_exec)
            except BaseException as error:
                record = {"event": "refused", "type": type(error).__name__,
                          "errno": getattr(error, "errno", None)}
                if isinstance(error, GuardError):
                    record["reason"] = str(error)  # All consumer GuardError reasons are static.
                try:
                    _write_all(ready_write, json.dumps(record).encode() + b"\n", os.write)
                except BaseException:
                    pass
                os._exit(78)
        os.close(go_read)
        os.close(ready_write)
        pipes = []
        return BlockedChild(pid, go_write, ready_read, go_channel, ready_channel)
    finally:
        os.close(driver_fd)
        if directory_fd is not None:
            os.close(directory_fd)
        for fd in pipes:
            os.close(fd)


def _child(spec, executable, image_identity, marker_path, directory_identity,
           cwd, parent_pid, expected_mask, go_fd, ready_fd, driver_fd, directory_fd, test_exec):
    expected_environment = environment_hash(dict(spec.policy.environment))

    def validate():
        if (os.getppid() != parent_pid or os.geteuid() != spec.policy.effective_uid
                or os.getegid() != spec.policy.effective_gid or Path.cwd() != cwd
                or environment_hash(os.environ) != expected_environment
                or signal.pthread_sigmask(signal.SIG_BLOCK, []) != expected_mask):
            raise GuardError("blocked-exec process policy changed")
        current = os.stat(executable, follow_symlinks=False)
        if ((_file_identity(driver_fd) != image_identity)
                or (current.st_dev, current.st_ino) != image_identity[:2]
                or _file_hash(driver_fd) != spec.driver_sha256
                or _file_identity(driver_fd) != image_identity):
            raise GuardError("blocked-exec driver image changed")
        current_directory = os.stat(marker_path, follow_symlinks=False)
        if (current_directory.st_dev, current_directory.st_ino) != directory_identity:
            raise GuardError("blocked-exec marker directory changed")

    validate()
    start_ticks = None
    if sys.platform.startswith("linux"):
        witness = parse_process_stat(Path("/proc/self/stat").read_text())
        if witness.pid != os.getpid():
            raise GuardError("blocked-exec stat identity mismatch")
        start_ticks = witness.start_ticks
    open_fds = _open_fds()
    open_pipes = []
    for fd in open_fds:
        if stat.S_ISFIFO(os.fstat(fd).st_mode):
            pipe = PipeIdentity.from_fd(fd)
            open_pipes.append({"fd": fd, "device": pipe.device, "inode": pipe.inode})
    ready = {"event": "blocked", "pid": os.getpid(), "parent_pid": parent_pid,
             "session_id": os.getsid(0), "effective_uid": os.geteuid(), "effective_gid": os.getegid(),
             "start_ticks": start_ticks, "environment_sha256": expected_environment,
             "driver_sha256": spec.driver_sha256, "open_fds": open_fds, "open_pipes": open_pipes,
             "test_exec_callback": test_exec is not None}
    _write_all(ready_fd, json.dumps(ready, sort_keys=True).encode() + b"\n", os.write)
    expected_token = f"{spec.declaration_sha256}:{spec.nonce}\n".encode("ascii")
    token = _read_message(go_fd, len(expected_token), spec.timeout_seconds, require_eof=True)
    if token != expected_token:
        raise GuardError("invalid blocked-exec token")
    marker_fd = os.open("capture-consumed.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                        dir_fd=directory_fd)
    try:
        info = os.fstat(marker_fd)
        expected_marker = json.dumps({"declaration_sha256": spec.declaration_sha256,
                                      "nonce": spec.nonce}, sort_keys=True).encode() + b"\n"
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != spec.policy.effective_uid
                or os.read(marker_fd, len(expected_marker) + 1) != expected_marker):
            raise GuardError("invalid consumed marker")
    finally:
        os.close(marker_fd)
    validate()
    os.close(go_fd)
    os.close(directory_fd)
    for name in ("SIGPIPE", "SIGXFZ", "SIGXFSZ"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), signal.SIG_DFL)
    os.set_inheritable(driver_fd, False)
    os.set_inheritable(ready_fd, False)
    if test_exec is not None:
        os.close(ready_fd)  # Explicit fixture simulates CLOEXEC, never claims real fd-exec.
        test_exec(driver_fd, spec.policy.argv, dict(spec.policy.environment))
        os._exit(0)
    os.execve(driver_fd, spec.policy.argv, dict(spec.policy.environment))


if __name__ == "__main__":
    raise SystemExit("Blocked-exec component only: no benchmark/capture entrypoint")
