from __future__ import annotations

import hashlib
import json
import os
import signal
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

import native_perf_blocked_exec as blocked
from native_perf_guard import ArmingGate, FrozenLaunch, GuardError, PipeChannel, PipeIdentity, ProcessInstance


@unittest.skipUnless(os.name == "posix" and hasattr(os, "fork"), "owned POSIX IPC fixtures")
class BlockedExecTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.marker = self.directory / "marker"
        self.marker.mkdir()
        self.driver = self.directory / "fixture-image"
        self.driver.write_bytes(b"owned nonbenchmark fixture image\n")
        self.driver.chmod(0o700)
        self.log = (self.directory / "driver.log").open("wb")
        self.addCleanup(self.log.close)
        self.witness = self.directory / "fixture-exec.json"
        self.children = []
        self.addCleanup(self.reap_children)
        policy = FrozenLaunch.freeze((str(self.driver), "fixture-argument"), os.environ.copy(),
                                     os.geteuid(), os.getegid())
        self.spec = blocked.BlockedSpec(policy, hashlib.sha256(self.driver.read_bytes()).hexdigest(),
                                        "c" * 64, "d" * 32, self.marker, Path.cwd(), 1.5)

    def reap_children(self):
        for child in self.children:
            child.close_go()
            try:
                child.wait(0.5)
            except ChildProcessError:
                pass  # Already reaped: never signal a recycled numeric PID.
            except GuardError:
                os.kill(child.pid, signal.SIGKILL)  # Only this owned test callback fixture.
                os.waitpid(child.pid, 0)
            os.close(child.ready_fd)

    def spawn(self, spec=None, exec_callback=None):
        witness = self.witness

        def fixture_exec(fd, argv, environment):
            open_fds = blocked._open_fds()
            null = os.stat(os.devnull)
            stdin = os.fstat(0)
            out, err = os.fstat(1), os.fstat(2)
            witness.write_text(json.dumps({
                "fixture_only": True, "pid": os.getpid(), "sid": os.getsid(0),
                "uid": os.geteuid(), "gid": os.getegid(), "argv": list(argv),
                "environment_sha256": blocked.environment_hash(environment),
                "driver_fd": fd, "open_fds": open_fds,
                "driver_fd_cloexec": not os.get_inheritable(fd),
                "stdin_is_devnull": (stdin.st_dev, stdin.st_ino) == (null.st_dev, null.st_ino),
                "stdout_stderr_same_log": (out.st_dev, out.st_ino) == (err.st_dev, err.st_ino),
                "sigpipe_default": signal.getsignal(signal.SIGPIPE) == signal.SIG_DFL,
                "signal_mask": sorted(int(s) for s in signal.pthread_sigmask(signal.SIG_BLOCK, [])),
            }))

        child = blocked.start_blocked(spec or self.spec, self.log.fileno(),
                                      test_exec=exec_callback or fixture_exec)
        self.children.append(child)
        return child

    def token(self):
        return ("c" * 64 + ":" + "d" * 32 + "\n").encode()

    def write_marker(self, data=None):
        if data is None:
            data = json.dumps({"declaration_sha256": "c" * 64, "nonce": "d" * 32},
                              sort_keys=True).encode() + b"\n"
        (self.marker / "capture-consumed.json").write_bytes(data)

    def send(self, child, token=None):
        os.write(child.go_fd, self.token() if token is None else token)
        child.close_go()  # AFTER complete GO; child must never own the write end.

    def assert_refused(self, child):
        self.assertEqual(child.wait(5), 78)
        self.assertFalse(self.witness.exists())

    def test_valid_token_marker_and_eof_reach_only_fixture_callback(self):
        child = self.spawn()
        ready = child.read_ready()
        self.assertTrue(ready["test_exec_callback"])
        self.assertEqual(ready["session_id"], child.pid)
        self.assertFalse(self.witness.exists())
        self.write_marker()
        self.send(child)
        self.assertEqual(child.wait(5), 0)
        observed = json.loads(self.witness.read_text())
        self.assertTrue(observed["fixture_only"])
        self.assertEqual(observed["pid"], child.pid)
        self.assertEqual(observed["uid"], os.geteuid())
        self.assertEqual(observed["gid"], os.getegid())
        self.assertEqual(observed["sid"], child.pid)
        self.assertEqual(observed["argv"], list(self.spec.policy.argv))
        self.assertEqual(observed["environment_sha256"], blocked.environment_hash(os.environ))
        self.assertEqual(set(observed["open_fds"]), {0, 1, 2, observed["driver_fd"]})
        for field in ("driver_fd_cloexec", "stdin_is_devnull", "stdout_stderr_same_log", "sigpipe_default"):
            self.assertTrue(observed[field], field)

    def test_eof_without_go_never_executes(self):
        child = self.spawn()
        child.read_ready()
        child.close_go()
        self.assert_refused(child)

    def test_arming_gate_and_real_child_consumer_integrate_with_fixture_sampler(self):
        child = self.spawn()
        ready = child.read_ready()
        # Actual kernel start-time/image provenance is deliberately NOT claimed
        # for this fixture sampler or Darwin's synthetic start_ticks value.
        wrapper = ProcessInstance(child.pid, ready["start_ticks"] or 1, "b" * 64,
                                  ready["effective_uid"], ready["effective_gid"])
        sampler = ProcessInstance(os.getpid(), 1, "a" * 64, os.geteuid(), os.getegid())
        control = os.pipe()
        ack = os.pipe()  # Created AFTER the blocked child: cannot be inherited.
        try:
            gate = ArmingGate(sampler, wrapper, PipeChannel.from_fds(*control),
                              PipeChannel.from_fds(*ack), child.go_channel,
                              self.spec.policy, self.spec.declaration_sha256, self.spec.nonce)
            gate.blocked(wrapper, frozenset(PipeIdentity(p["device"], p["inode"])
                                           for p in ready["open_pipes"]))
            self.assertEqual(gate.request_enable(sampler), b"enable\n")
            os.write(ack[1], b"ack\n")  # Fake perf acknowledgement, not a real sampler.
            gate.acknowledge(PipeIdentity.from_fd(ack[0]), os.read(ack[0], 4), sampler)
            gate.consume(self.marker)
            gate.release(child.go_fd, sampler, wrapper, self.spec.policy.argv,
                         dict(self.spec.policy.environment))
            child.close_go()
            self.assertEqual(child.wait(5), 0)
            self.assertTrue(json.loads(self.witness.read_text())["fixture_only"])
        finally:
            for fd in (*control, *ack):
                os.close(fd)

    def test_missing_marker_never_executes(self):
        child = self.spawn()
        child.read_ready()
        self.send(child)
        self.assert_refused(child)

    def test_partial_token_never_executes(self):
        child = self.spawn()
        child.read_ready()
        self.write_marker()
        self.send(child, self.token()[:40])
        self.assert_refused(child)

    def test_wrong_nonce_never_executes(self):
        child = self.spawn()
        child.read_ready()
        self.write_marker()
        self.send(child, self.token().replace(b"d", b"e"))
        self.assert_refused(child)

    def test_repeated_token_never_executes(self):
        child = self.spawn()
        child.read_ready()
        self.write_marker()
        self.send(child, self.token() * 2)
        self.assert_refused(child)

    def test_full_token_without_eof_times_out_without_exec(self):
        child = self.spawn(replace(self.spec, timeout_seconds=0.08))
        child.read_ready()
        self.write_marker()
        os.write(child.go_fd, self.token())
        self.assert_refused(child)

    def test_corrupt_marker_never_executes(self):
        child = self.spawn()
        child.read_ready()
        self.write_marker(b"{partial")
        self.send(child)
        self.assert_refused(child)

    def test_marker_symlink_never_executes(self):
        child = self.spawn()
        child.read_ready()
        protected = self.directory / "protected-marker"
        protected.write_bytes(b"unchanged")
        (self.marker / "capture-consumed.json").symlink_to(protected)
        self.send(child)
        self.assert_refused(child)
        self.assertEqual(protected.read_bytes(), b"unchanged")

    def test_replaced_marker_directory_does_not_retarget_pinned_fd(self):
        child = self.spawn()
        child.read_ready()
        self.write_marker()
        self.marker.rename(self.directory / "old-marker")
        self.marker.mkdir()
        self.write_marker()
        self.send(child)
        self.assert_refused(child)

    def test_driver_bytes_change_is_refused(self):
        child = self.spawn()
        child.read_ready()
        self.driver.write_bytes(b"changed fixture\n")
        self.write_marker()
        self.send(child)
        self.assert_refused(child)

    def test_driver_path_replacement_is_refused(self):
        child = self.spawn()
        child.read_ready()
        self.driver.rename(self.directory / "old-driver")
        self.driver.write_bytes(b"replacement\n")
        self.driver.chmod(0o700)
        self.write_marker()
        self.send(child)
        self.assert_refused(child)

    def test_environment_mismatch_refuses_before_ready(self):
        environment = {**os.environ, "NATIVE_PERF_FAKE_POLICY_KEY": "not-in-child"}
        policy = blocked.FrozenLaunch.freeze(self.spec.policy.argv, environment, os.geteuid(), os.getegid())
        child = self.spawn(replace(self.spec, policy=policy))
        with self.assertRaises(GuardError):
            child.read_ready()
        self.assertIn(b"refused", child.ready_bytes)
        self.assert_refused(child)

    def test_wrong_credentials_refuse_before_ready(self):
        policy = blocked.FrozenLaunch.freeze(self.spec.policy.argv, os.environ, os.geteuid() + 1, os.getegid())
        child = self.spawn(replace(self.spec, policy=policy))
        with self.assertRaises(GuardError):
            child.read_ready()
        self.assert_refused(child)

    def test_existing_marker_refuses_before_fork(self):
        self.write_marker(b"retained partial")
        with self.assertRaisesRegex(GuardError, "existing consumed"):
            self.spawn()
        self.assertEqual((self.marker / "capture-consumed.json").read_bytes(), b"retained partial")
        self.assertEqual(self.children, [])

    def test_unrelated_inheritable_fd_is_closed_before_ready(self):
        with (self.directory / "unrelated").open("wb") as extra:
            os.set_inheritable(extra.fileno(), True)
            child = self.spawn()
            ready = child.read_ready()
            self.assertNotIn(extra.fileno(), ready["open_fds"])
            child.close_go()
            self.assert_refused(child)

    def test_real_fd_exec_has_no_nonlinux_path_fallback(self):
        with patch.object(blocked.sys, "platform", "darwin"):
            with self.assertRaisesRegex(GuardError, "Linux fd-exec"):
                blocked.start_blocked(self.spec, self.log.fileno())
        self.assertEqual(self.children, [])

    def test_multithreaded_controller_is_refused(self):
        with patch.object(blocked.threading, "active_count", return_value=2):
            with self.assertRaisesRegex(GuardError, "single-threaded"):
                self.spawn()
        self.assertEqual(self.children, [])

    def test_wrong_image_hash_refuses_before_fork(self):
        with self.assertRaisesRegex(GuardError, "driver image"):
            self.spawn(replace(self.spec, driver_sha256="e" * 64))
        self.assertEqual(self.children, [])

    def test_review_driver_symlink_retarget_is_refused(self):
        alias = self.directory / "driver-alias"
        alias.symlink_to(self.driver)
        policy = FrozenLaunch.freeze((str(alias), *self.spec.policy.argv[1:]), os.environ,
                                     os.geteuid(), os.getegid())
        child = self.spawn(replace(self.spec, policy=policy))
        child.read_ready()
        replacement = self.directory / "replacement"
        replacement.write_bytes(b"another nonbenchmark fixture image\n")
        replacement.chmod(0o700)
        alias.unlink()
        alias.symlink_to(replacement)
        self.write_marker()
        self.send(child)
        self.assert_refused(child)

    def test_review_setid_fixture_mode_refuses_before_fork(self):
        # An owned non-ELF fixture only: no privileged executable or UID change.
        self.driver.chmod(0o4700)
        with self.assertRaisesRegex(GuardError, "driver image"):
            self.spawn()
        self.assertEqual(self.children, [])

    def test_review_fifo_marker_refuses_without_unbounded_open(self):
        child = self.spawn()
        child.read_ready()
        os.mkfifo(self.marker / "capture-consumed.json", 0o600)
        self.send(child)
        self.assert_refused(child)

    def test_review_callback_failure_preserves_primary_reason_in_log(self):
        def refused_callback(fd, argv, environment):
            raise GuardError("fixture callback refused")

        child = self.spawn(exec_callback=refused_callback)
        child.read_ready()
        self.write_marker()
        self.send(child)
        self.assert_refused(child)
        self.assertIn(b"fixture callback refused", (self.directory / "driver.log").read_bytes())


if __name__ == "__main__":
    unittest.main()
