import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 import ast,hashlib,io,json,os,pathlib,subprocess,sys,time,types,unittest
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-owned-emission-dispatch')
 C=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def writej(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 def snapshot(epoch):
  target=P/(epoch+'-source');target.mkdir()
  result={}
  for name in expected:
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  for name in ('bin/common.sh','bin/verify','bin/test-all'):
   data=(R/name).read_bytes();p=target/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);result[name]=sha(data)
  writej(P/(epoch+'-hashes.json'),result)
  return result
 def runtests(epoch,names):
  h=snapshot(epoch); fixture=P/(epoch+'-fixtures');fixture.mkdir()
  os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixture)
  sys.dont_write_bytecode=True
  modules=[]
  for name,rel in [('native_perf_build_producer','tool/native_perf_build_producer.py'),('canonical_output_selected_tests','tool/test_native_perf_build_producer.py')]:
   data=(P/(epoch+'-source')/rel).read_bytes();assert sha(data)==h[rel]
   mod=types.ModuleType(name);mod.__file__=str(R/rel)
   assert name not in sys.modules;sys.modules[name]=mod;modules.append(name)
   exec(compile(data,str(R/rel),'exec'),mod.__dict__)
  suite=unittest.TestSuite()
  for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,mod))
  out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
  (P/(epoch+'-tests.log')).write_text(out.getvalue())
  summary=dict(scope='OWN selected unit/path fixtures only; no canonical/build/receipt/admission',
   tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
   successful=result.wasSuccessful(),source_sha256=h,
   failures_detail=[dict(test=str(t),traceback=s) for t,s in result.failures],
   errors_detail=[dict(test=str(t),traceback=s) for t,s in result.errors])
  writej(P/(epoch+'-tests.json'),summary)
  for name in reversed(modules):sys.modules.pop(name)
  return summary
 expected=json.loads(C.read_text())['native_perf_only_diagnostic_design']['current_source_sha256']
 for name,digest in expected.items():assert sha((R/name).read_bytes())==digest,name
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;assert free>=1024**3,free
 P.mkdir();writej(P/'declaration.json',dict(scope='NEW owned emitter interface dispatch only; no actual canonical/production factory or live emission',source_sha256=expected,free_before=free,build_floor=12*1024**3,scoped_floor=1024**3,all_actual_producer_provenance_fixture=True,no_provenance_retagging_or_live_receipt=True))
 snapshot('original')
 path=R/'tool/test_native_perf_build_producer.py';source=path.read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.If) and "__name__" in ast.unparse(n.test))
 at=sum(len(x) for x in source.splitlines(keepends=True)[:node.lineno-1]);source=source[:at]+"\n\nclass PreflightEmissionDispatchTests(unittest.TestCase):\n    \"\"\"Mocked factory/emitter interfaces; actual producer provenance stays fixture.\"\"\"\n    git=ProducerTests.git\n    setUp=OwnedPreflightTests.setUp\n    tearDown=OwnedPreflightTests.tearDown\n    arguments=OwnedPreflightTests.arguments\n    drive=OwnedPreflightTests.drive\n\n    def constructed(self,kind):\n        self.sequence+=1\n        nonce=digest((str(self.base)+kind+str(self.sequence)).encode())[:32]\n        # Only the selected factory interface is replaced. Never retag the\n        # actual fixture producer or publish an own-canonical/production receipt.\n        def fixture_factory(**kwargs):return producer.start_fixture(**kwargs)\n        factory='start_canonical' if kind=='canonical' else 'start_production'\n        if kind=='fixture':\n            owner=producer.start_owned_preflight(kind,owner_id=nonce,**self.arguments())\n            self.owners.append(owner);self.drive(owner)\n        else:\n            with mock.patch.object(producer,factory,fixture_factory):\n                owner=producer.start_owned_preflight(kind,owner_id=nonce,**self.arguments())\n                self.owners.append(owner);self.drive(owner)\n        self.assertEqual('fixture',owner._operation.provenance)\n        return owner\n\n    def one_argument_boundary(self,kind,phase):\n        owner=self.constructed(kind);calls=[]\n        def emit(run):\n            calls.append(run)\n            return {'kind':'fixture-interface-only','capture_ready':False}\n        with mock.patch.object(producer,'emit_receipt',emit):\n            owner.emit(phase);view=owner.observe(2)\n        if view['failed']:\n            (self.base/'dispatch-error.json').write_text(json.dumps({\n                'type':type(owner._first_error_object).__name__,\n                'message':str(owner._first_error_object),\n                'scope':'MOCKED factory/emitter call boundary only'}))\n        self.assertTrue(view['call_done']);self.assertFalse(view['failed'],view)\n        self.assertEqual([owner._operation],calls)\n        self.assertEqual('fixture-interface-only',owner._last_result['kind'])\n        self.assertFalse(view['capture_ready']);self.assertFalse(view['source_admitted'])\n        self.assertFalse((self.base/'run-1/input-receipt.json').exists())\n\n    def mismatch(self,kind,phase):\n        owner=self.constructed(kind);before=dict(owner.observe(0));calls=[]\n        def emit(run):\n            calls.append(run)\n            return {'kind':'fixture-interface-only','capture_ready':False}\n        with mock.patch.object(producer,'emit_receipt',emit):\n            try:\n                with self.assertRaises(producer.ProducerError):owner.emit(phase)\n            finally:owner.observe(2)\n        after=dict(owner.observe(0))\n        self.assertEqual(before,after);self.assertFalse(after['owner_emit_attempted'])\n        self.assertEqual([],calls)\n        self.assertFalse((self.base/'run-1/input-receipt.json').exists())\n\n    def test_canonical_owned_branch_calls_one_argument_emitter(self):\n        self.one_argument_boundary('canonical','canonical')\n\n    def test_production_owned_branch_calls_one_argument_emitter(self):\n        self.one_argument_boundary('production','execution')\n\n    def test_canonical_wrong_phase_refused_before_owner_attempt(self):\n        self.mismatch('canonical','execution')\n\n    def test_production_wrong_phase_refused_before_owner_attempt(self):\n        self.mismatch('production','canonical')\n\n    def test_fixture_owned_branch_keeps_two_argument_emitter(self):\n        owner=self.constructed('fixture');calls=[]\n        def emit(run,phase):\n            calls.append((run,phase))\n            return {'kind':'fixture-interface-only','capture_ready':False}\n        with mock.patch.object(producer,'emit_fixture_receipt',emit):\n            owner.emit('canonical');view=owner.observe(2)\n        self.assertTrue(view['call_done']);self.assertFalse(view['failed'])\n        self.assertEqual([(owner._operation,'canonical')],calls)\n        self.assertEqual('fixture',owner._operation.provenance)\n        self.assertFalse(view['live_admission'])\n        self.assertFalse((self.base/'run-1/input-receipt.json').exists())\n"+'\n'+source[at:];ast.parse(source);path.write_text(source)
 summary=runtests('before',['PreflightEmissionDispatchTests'])
 writej(P/'tests-advice-root-assessment.json',dict(session76652_complete_reaped_exit0=True,advisory=True,
 accepted=['canonical+production one-arg boundary','phase mismatch beforeattempt','unchangedtwoargfixturebranch'],
 rejected=['Never retag actual fixture provenance tocanonical_recipe/production_recipe; actual object staysfixture','Owner kind is requestedcanonical/production to reach that interface; snapshotadmissionflagsFalse, not ownerkindfixture','Test PUBLICemit() mismatch validation, not direct private_work call','Stubreturnsfixture-interface-only; no real_emit or valid ownreceipt','pytestcommands were hypothetical; actualselectedunittest only'],
 no_actual_canonical_production_or_live_receipt_executed=True))
 lease.verify_identity();print(json.dumps({k:summary[k] for k in ('tests','failures','errors','skipped','successful')}))
