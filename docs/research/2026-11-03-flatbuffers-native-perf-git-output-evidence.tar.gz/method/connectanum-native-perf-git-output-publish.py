from pathlib import Path
import sys,os,stat,json,hashlib,tarfile,gzip,io,re,subprocess,datetime,copy,shutil,time
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
wt=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');docs=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart');base=Path('/tmp/connectanum-native-perf-git-output');name='2026-11-03-flatbuffers-native-perf-git-output';sha=lambda b:hashlib.sha256(b).hexdigest()
def publish(lease):
 lease.verify_identity();final=json.loads(Path(str(base)+'-consume-fixed-tests.json').read_text());assert final['exit']==0
 for rel,h in final['source_sha256'].items():assert sha((wt/rel).read_bytes())==h
 previous=json.loads(Path('/tmp/connectanum-native-perf-command-output-partial-fixed-tests.json').read_text())
 changed=[k for k,h in previous['source_sha256'].items() if h!=final['source_sha256'][k]];assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 assert not subprocess.check_output(['git','diff','HEAD','--','packages','native'],cwd=wt)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert subprocess.check_output(['git','branch','--show-current'],cwd=docs,text=True).strip()=='codex/flatbuffers-acceptance-status'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=docs)
 control=Path('/tmp').resolve()/'connectanum-native-perf-git-output-source-control';summary=json.loads((control/'summary.json').read_text());decl=json.loads((control/'declaration.json').read_text())
 assert summary['source_admitted'] is False and summary['capture_ready'] is False and len(summary['actual_commands'])==2
 assert decl['source_sha256']==final['source_sha256'];assert len(summary['actual_untracked_paths_original_order'])==20
 assert all(c['returncode']==0 and all(v['eof'] for v in c['outputs'].values()) for c in summary['actual_commands'])
 files={};special={};phases={}
 def tree(path,label):
  for p in sorted(path.rglob('*')):
   info=p.lstat();key=label+'/'+str(p.relative_to(path))
   if stat.S_ISREG(info.st_mode):files[key]=p
   elif not stat.S_ISDIR(info.st_mode):special[key]={'mode':info.st_mode,'link_target':os.readlink(p) if stat.S_ISLNK(info.st_mode) else None}
 for phase in ['before','receipt-before','implemented','controls','integrated','consume-before-v2','consume-fixed']:
  prefix=Path(str(base)+'-'+phase);r=json.loads(Path(str(prefix)+'-tests.json').read_text());log=Path(str(prefix)+'-tests.log').read_bytes();assert sha(log)==r['log_sha256']
  phases[phase]={'tests':int(re.search(rb'Ran (\d+) tests?',log)[1]),'exit':r['exit'],'log_sha256':sha(log),'source_sha256':r['source_sha256']}
  for ending in ['-source','-fixtures']:tree(Path(str(prefix)+ending),phase+ending)
  for ending in ['-tests.json','-tests.log']:p=Path(str(prefix)+ending);files[phase+'/'+p.name]=p
  for rel,h in r['source_sha256'].items():assert sha((Path(str(prefix)+'-source')/Path(rel).name).read_bytes())==h
 assert phases['consume-fixed']['tests']==78
 tree(control,'actual-source-control')
 for rel,h in decl['source_sha256'].items():assert sha((control/'source'/rel).read_bytes())==h
 for rel,h in decl['selected_LOCAL_input_hashes'].items():assert sha((control/'selected-input-files'/rel).read_bytes())==h
 for p in sorted(base.parent.glob(base.name+'-*')):
  if p.is_file() and p.name.endswith(('.py','.log','.txt','.json')) and p not in files.values() and '-checkpoint-' not in p.name:
   files['method/'+p.name]=p
 # Exact control raw summaries/declarations are archived, not rewritten for publication.
 archive=docs/'docs/research'/f'{name}-evidence.tar.gz';members={}
 with archive.open('xb') as out:
  with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for member,p in sorted(files.items()):
     data=p.read_bytes();info=tarfile.TarInfo(member);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data));members[member]={'size':len(data),'sha256':sha(data)}
    data=(json.dumps(special,indent=2)+'\n').encode();info=tarfile.TarInfo('original-special-node-metadata.json');info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data));members[info.name]={'size':len(data),'sha256':sha(data)}
 with tarfile.open(archive,'r:gz') as tar:
  assert len(tar.getmembers())==len(members)
  for member in tar:assert members[member.name]=={'size':member.size,'sha256':sha(tar.extractfile(member).read())}
 free=shutil.disk_usage(wt).free
 audit={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'NEW owned auxiliary Git command dual-output lifecycle and exact consumed metadata binding; source intake refusal, NOT complete live preflight','runtime_head':'601108ea6216464bd00ae29c16cfaf0a59c71db6','production_source_unchanged':True,'uncommitted_python_tools':20,'helper_bundle_files':20,'source_sha256':final['source_sha256'],'changed_files':changed,'other18_files_byteidentical':True,
 'changed_module_integration_PASS':78,'new_focused':13,'existing_module_callers':65,'phases':phases,
 'actual_before_failures':['Initial2 cases:1 actualFAIL initial Git observer returned before separately main-owned real output writer EOF;1 fixtureERROR unpacking the existing four-value receipt_fixture result into two variables. Fixture-only correction followed by separate1 actualFAIL receipt source audit also completed before writer EOF. No initial module absence or invented production defect count.','Initial repair2PASS;9more OWN lifecycle/schema/fault controls11PASS;changed76PASS. Root then found TWO actual consumed-byte continuity FAILs: same-size HEAD stdout replaced after snapshot was returned; dirty status stdout erased after snapshot yielded a valid FIXTURE canonical receipt despite dirty tiny source. Original stdout was copied BEFORE each OWN fixture mutation. No valid live receipt/GO/capture demonstrated.','Exact consumed metadata size/SHA and bounded FD/path/stat read binding fixed; archive handoff snapshot rechecked without loading full archive. Final changed78PASS.'],
 'implementation':{'ownership':'Prepared auxiliary object registered by parent before start, exclusive intent/start before Popen; actual direct handle retained before fallible output closure/observation publication. Two private noninherited nonblocking read FDs, separate stdout/stderr logs, incremental bounded writes and both EOFs plus signed natural status before completion. No writer authentication/whole-descendant claim.','errors':'First primary and secondary errors retained; failure/partial artifacts one terminal attempt. Numeric FD ownership consumed before close, no ambiguous reclose. Unknown output write/bound faults quarantine retained original FD and bounded raw pending bytes, no replay/cancel/relaunch/recovery. OWN finite quarantine fixtures explicitly close only their known FDs after known natural child exit; no live workaround.','consumed_bytes':'Source and receipt guards now consume exactly the observed stdout size/SHA via bounded nofollow regular FD read and before/after file/path checks. Whole metadata at most32MiB; archives remain streamed with snapshot handoff. Bounded observations, no atomic/global ABA/write-prevention or host execution authenticity.','bridges':'Both _git source intake and separate receipt-source audit use the new owner. Actual argv/env/output filenames preserved; only preflight Git stdin is DEVNULL, no original benchmark/driver channel altered. All positive build-receipt callers remain fixture-kind; capture_ready always false.'},
 'actual_source_control':{'declaration_sha256':sha((control/'declaration.json').read_bytes()),'summary_sha256':sha((control/'summary.json').read_bytes()),'actual_git_commands':2,'signed_statuses':[c['returncode'] for c in summary['actual_commands']],'source_admitted':False,'reason':'all20tool files remain uncommitted','selected_LOCAL_input_hashes':decl['selected_LOCAL_input_hashes'],'selected_config_file_generator_version':'3.13.1','source_and_selected_inputs_unchanged_after_each':True,'scope':'exact compiled current helper bytes, actual own HEAD/status output and selected workspace files ONLY; tool stamp is bounded read support, no new CLI version probe/SDK/loader/compiled closure/worker-role identity proof'},
 'models':{'tests97748':'Qwen COMPLETE/REAPED; declined test list because proposed new API implementation was absent in selected old-code snippets. Not backend unavailability or approval. Root chose actual regressions. First earlier wrapper refused resource lease BEFORE backend request; later admitted request retained separately.','review92762':'Reachable GLM TOKENLIMIT exit1/COMPLETE REAPED, no saved final assessment/approval. Selected windows cover auxiliary helper and partial tests; bridge windows were offset, so root independently read both complete actual bridges. No unchanged retry.','consumer_review55220':'NEW changed consumed-byte helper plus two actual bridges only; GLM COMPLETE/REAPED advisory. Alleged in-place/size concerns self-retracted as no concrete actionable issue. Reject global impossibility/atomicity inference from ctime; checks are bounded and exact consumed SHA is the useful guarantee. st_blocks/rdev are not physical memory/execution witnesses; xb fails preexisting symlinks, namespace trust remains separate. Audit write failure is terminal with per-command raw observations retained, not a success/admission claim.'},
 'preparation_failures':['Resource admissions refused before backend/source/test; wrappers and before-wait/phase-admission receipts kept. Only unstarted NONNUMERICAL admission was continued in fresh preparation labels, same host/guards/source; no executed test or numerical command retried for a favorable result.','External coordinator v2 missed runpy import before installer invocation/source mutation/snapshot/test; exact script and failure receipt retained, explicit import correction in v3. Not automatic approval rejection or production defect.'],
 'limits':['Actual independent live preflight provider remains unresolved; require_live_admission ALWAYS raises and live SessionController stays CLOSED. No JSON/command record/caller bool can mint permission.','No actual own20tool fullcanonical/committed whole-source archive/production recipe/native/driver/RLIB/compiler/loadedSDK/Linux/root/procfs/pidfd/FDexec/perf/kernel/VM/WAMP/nativebenchmark/capture/strict/numerical result. Actual source intake rejected dirty state, never produced an archive/build/receipt.','Actual selected config/three LOCAL lock bytes stay separate from HOSTED cohort; selected config generatorVersion is file data, not a new SDK or original worker-isolate observation. No helper-to-worker/source-closure/role/clock/COW-page inference. No old omission filled or old actual SDK CLI/package controls rerun.','Both EOFs only establish this stream has no current writers; no writer identity or all descendants exiting. FD/path/stat/hash are supporting bounded observations, not atomic/global ABA or host authenticity. Full source/SDK/compiler/config/native/descendant/kernel evidence remains required.','78 is changed module integration (13new+65existing callers), not canonical, strict48/50, RAM/heap/RSS/cause/acceptance. Other18 sources unchanged; distinct Session/admission/proc/metadata/etc proofs not rerun unchanged. All original workloads/controls/flags/SDK/GC/worker/body/window/sample rules unchanged.','Raw output retained without universal secret-free promise. All known OWN finite observation actors naturally waited; explicit quarantine fixture cleanup remains fixture-only.'],
 'archive':str(archive.relative_to(docs)),'archive_sha256':sha(archive.read_bytes()),'archive_members':members,'special_node_metadata':special,'free_bytes':free,'build_floor_bytes':12*1024**3,'build_disk_admission_open':free>=12*1024**3,'disk_drop_cause_measured':False,'no_cleanup':True,'capture_ready':False,'live_provider_implemented':False,'live_SessionController_closed':True,
 'next':'Integrate actual independently owned preflight/source/config/SDK/compiler/native receipts and nonbenchmark Linux controls; live gate stays CLOSED. Actual current source intake is dirty/unadmitted. Full own20tool canonical/archive/native/driver/RLIB/config/3locks/kernel provenance still pending. Disk below unchanged12GiB floor forbids builds until safely available; no cleanup of protected or other-task data. Source/guard work can continue within its separate resource admission. Preserve preGO expectations versus postGO actual role/timing/metadata outcomes.'}
 with Path(str(base)+'-root-readback.json').open('x') as f:json.dump(audit,f,indent=2);f.write('\n')
 public=copy.deepcopy(audit)
 for v in public['special_node_metadata'].values():
  if v['link_target'] is not None and Path(v['link_target']).is_absolute():v['link_target']={'transient_target_sha256':sha(v['link_target'].encode()),'original':'original-special-node-metadata.json in archive'}
 assert '/tmp/' not in json.dumps(public) and '/Users/' not in json.dumps(public)
 (docs/'docs/research'/f'{name}-assessment.json').write_text(json.dumps(public,indent=2)+'\n')
 note=f'''# Git auxiliary command and consumed-byte guards (2026-11-03)

Changed producer integration passes78 cases:13new Git auxiliary/consumer guards
plus65existing module callers. Both source intake and receipt-source audit now
retain an owned operation before launch and wait for signed natural direct exit
AND separate stdout/stderr EOF. Late bytes remain in the original streams.
Twenty tools stay uncommitted; helper20 and production601 remain unchanged.
Actual independent live preflight is unresolved; live SessionController is closed.

Two actual before failures show early initial/receipt Git completion while an
OWN separately main-parented finite writer still holds output. The first receipt
case initially had a fixture-only unpack error (existing helper returns four
values), then exposes its actual failure. The repair passes2, then11controls /
76changed integration. Root next finds two actual consumed-byte failures: a
same-size HEAD stdout substitution was consumed after its earlier hash, and
replacing dirty status stdout with empty bytes produced a valid FIXTURE canonical
receipt. Original command bytes were copied BEFORE each OWN mutation. No live
receipt, GO or capture was forged. Exact bounded consumed-byte size/SHA checks
fix both, yielding78PASS. [Every phase and qualified assessment]({name}-assessment.json),
[all source/log/regular fixtures and actual control]({name}-evidence.tar.gz).

Failure evidence is one terminal attempt; primary and secondary errors remain.
Unknown writes quarantine original FDs/raw bounded buffers without replay, cancel,
relaunch or recovery. The finite fault fixture closes only known OWN descriptors
AFTER known natural child exit, with a labelled receipt; never a live workaround.
EOF does not authenticate a writer or prove all descendants exited. Stat/hash/FD
checks are bounded observations, not atomicity, global ABA or write prevention.

A NEW predeclared actual local source-intake control compiles exact current helper
bytes and runs two actual Git commands (HEAD/status), both naturally exit0 with
both streams retained. It rejects the real owned worktree's20uncommitted tools:
source_admitted=false/capture_ready=false. All20source files, selected actual
three LOCAL locks and selected workspace package-config bytes remain unchanged
after each command. The selected file says generatorVersion3.13.1; that is not a
new SDK/worker/compiled-closure observation. No installed-version CLI control is
repeated, no actual whole-source archive/build/production receipt is manufactured.

Qwen completed but declined test ideas without the proposed API source; root
chose regressions. The first resource refusal was before backend inference.
GLM's auxiliary review token-limited without a saved final assessment; selected
bridge windows were offset, so root inspected both actual bridges. A distinct
review of the NEW consumed-byte binding completed: its alleged mutation/size
issues self-retract. Root rejects any global impossibility/atomicity inference
from ctime and treats audit-write failure as terminal, never source admission.
All advice is qualified, not approval; all own model/command sessions reaped.
External coordinator runpy NameError preceded source editing/tests and is retained.

No own fullcanonical/production/native/RLIB/loadedSDK/compiler/Linux/root/pidfd/
FDexec/perf/kernel/VM/benchmark/capture/strict result. Other18sources byte-identical;
old distinct proofs/actual CLI/helper controls/original strict data not rerun.
Both strict campaigns remain failed; no production RAM cause/repair/acceptance.
Last free{free/10**9:.2f}GB is BELOW unchanged12GiB build floor; cause unmeasured.
No build starts and no cleanup/protected-data deletion. Actual independent
preflight/kernel controls and full source/config/SDK/compiler/native provenance
remain next, preserving preGO expectations versus postGO role/metadata outcomes.
'''
 (docs/'docs/research'/f'{name}-preparation.md').write_text(note)
 state=docs/'docs/project_state.md';s=state.read_text();at=s.index('## ');s=s[:at]+f'''## Git source-command guards verified; actual source intake refused (2026-11-03)

Changed producer integration passes78cases (13new/65existing callers). Before
failures exposed early dual-output completion and consumed metadata differing
from its earlier snapshot; both are fixed with every original OWN byte retained.
A NEW actual HEAD/status control exits0 but rejects the real20uncommitted tools;
source_admitted=false. [Scope, failures and actual control](research/{name}-preparation.md).

Helper20/production601 unchanged; no actual canonical/native/Linux/perf/kernel/
VM/benchmark/capture or strict dispatch. Independent live preflight remains
unresolved; live SessionController stays closed. All own actors/sessions reaped.
Free{free/10**9:.2f}GB is below unchanged12GiB build floor, cause unmeasured; no build
or cleanup starts. Source/guard work still needs its own resource admission.
Both strict campaigns remain failed; no production RAM repair/acceptance.

'''+s[at:];state.write_text(s)
 plan=docs/'docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md';s=plan.read_text();at=s.index('## ');s=s[:at]+f'''Git auxiliary dual-output/consumed-byte guards now pass78changed module cases
(13new+65existing callers). Actual owned HEAD/status control rejects current
uncommitted20tool source; no archive/build/production receipt or live permission.
[All new evidence and limits](../research/{name}-preparation.md).
Independent live preflight, own fullcanonical/source/SDK/compiler/config/native
receipts and actual bounded Linux controls remain pending; controller CLOSED.
Free{free/10**9:.2f}GB is below unchanged12GiB build floor (cause unmeasured), so no
build starts or protected/other-task cleanup. Production601/helper20 unchanged.

'''+s[at:];plan.write_text(s)
 lease.verify_identity();print(json.dumps({'archive_members':len(members),'archive_sha256':audit['archive_sha256'],'producer':final['source_sha256']['tool/native_perf_build_producer.py'],'test':final['source_sha256']['tool/test_native_perf_build_producer.py'],'free_bytes':free}))

end=time.monotonic()+45;errors=[]
while True:
 admitted=False
 try:
  with local_resource_lease(exclusive=True) as lease:admitted=True;publish(lease)
 except LocalResourceLeaseError as error:
  if admitted:raise
  errors.append(str(error))
  if time.monotonic()>=end:
   with Path(str(base)+'-publish-admission-refusal.json').open('x') as f:json.dump({'errors':errors,'before_archive_docs_mutation':True},f,indent=2)
   print('Publication resource admission unavailable.');break
  time.sleep(min(.5,max(0,end-time.monotonic())))
 else:break
