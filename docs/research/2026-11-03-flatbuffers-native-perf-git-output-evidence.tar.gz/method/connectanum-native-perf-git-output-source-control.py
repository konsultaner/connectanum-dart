from pathlib import Path
import os,sys,hashlib,json,subprocess,types,shutil,datetime,time
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
base=Path('/tmp').resolve()/'connectanum-native-perf-git-output-source-control'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
expected=json.loads(Path('/tmp/connectanum-native-perf-git-output-consume-fixed-tests.json').read_text())
assert expected['exit']==0
locks={'pubspec.lock':'4c719ebf08ce4d65571d5c4b25f9ec16567405ab99c8ee298143acadfa2691b8',
'native/transport/Cargo.lock':'0cb8ef90485ccae06b2981d023ea44d46c6309ba46a1186dffab581169f9f0c3',
'native/bench/Cargo.lock':'ea60fd1c65bd64f04a65ff9c1410348ef2d22450c7d63e4556149f7b6f1c0189',
'.dart_tool/package_config.json':'2aed9f0d2f00893473082f40d28eda195660feeaa3f5799b407b793f33d54b1e'}

def run(lease):
 lease.verify_identity();assert root==root.resolve(strict=True);assert shutil.disk_usage(root).free>=1024**3
 files={rel:(root/rel).read_bytes() for rel in expected['source_sha256']}
 assert {k:sha(v) for k,v in files.items()}==expected['source_sha256']
 actual_inputs={rel:(root/rel).read_bytes() for rel in locks};assert {k:sha(v) for k,v in actual_inputs.items()}==locks
 config=json.loads(actual_inputs['.dart_tool/package_config.json']);assert config['generatorVersion']=='3.13.1'
 source=root/'tool/native_perf_build_producer.py';module=types.ModuleType('owned_git_source_control');module.__file__=str(source)
 exec(compile(files['tool/native_perf_build_producer.py'],str(source),'exec'),module.__dict__)
 environment=dict(os.environ);env_hash=sha(json.dumps(environment,sort_keys=True,ensure_ascii=True).encode())
 tool=module.describe_tool('git','READ_STAMP_ONLY_NO_VERSION_PROBE')
 # Read-only file/entry stamp ONLY. No new installed-version or loaded-image claim.
 tool_stamp={k:v for k,v in tool.items() if k!='version_prefix'}
 commands=[[tool['entry'],'-C',str(root),'rev-parse','HEAD'],[tool['entry'],'-C',str(root),'status','--porcelain','--untracked-files=normal']]
 base.mkdir(mode=0o700)
 for label,blobs in [('source',files),('selected-input-files',actual_inputs)]:
  for rel,data in blobs.items():
   path=base/label/rel;path.parent.mkdir(parents=True,exist_ok=True)
   with path.open('xb') as f:f.write(data)
 declaration={'kind':'own-nonbenchmark-source-intake-control-v1','scope':'actual own dirty source refusal only, no build/capture admission',
 'capture_ready':False,'commands':commands,'expected_head':'601108ea6216464bd00ae29c16cfaf0a59c71db6',
 'expected_untracked_paths':list(files),'source_sha256':expected['source_sha256'],'selected_LOCAL_input_hashes':locks,
 'selected_config_file_generator_version':'3.13.1','config_is_not_worker_or_compiled_closure_proof':True,
 'git_supporting_read_stamp':tool_stamp,'environment_sha256':env_hash,'controller_uid':os.getuid(),'controller_gid':os.getgid(),
 'new_installed_version_probe':False,'canonical_or_production_recipe':False,'actual_sdk_image_or_kernel_evidence':False,'declared':now()}
 module._write_json(base/'declaration.json',declaration)
 declaration_sha=module._regular_hash(base/'declaration.json');operations=[];observations=[];raw=[]
 def stable():
  lease.verify_identity();assert module._regular_hash(base/'declaration.json')==declaration_sha
  assert {rel:sha((root/rel).read_bytes()) for rel in files}==expected['source_sha256']
  assert {rel:sha((root/rel).read_bytes()) for rel in locks}==locks
  assert module.describe_tool('git','READ_STAMP_ONLY_NO_VERSION_PROBE')==tool
 for index,command in enumerate(commands):
  stable();operation=module.AuxiliaryCommand(directory=base,name=f'actual-git-{index:03}',argv=command,cwd=root,
      environment=environment,lease_check=lease.verify_identity)
  operations.append(operation) # register actual owned object BEFORE start
  operation.start();result=operation.result
  while result is None:result=operation.wait(5)
  assert result['status']=='success' and result['returncode']==0
  data=module._read_bound_metadata(base/f'actual-git-{index:03}.stdout',result['outputs']['stdout']['snapshot'])
  observations.append(result);raw.append(data);stable()
 assert raw[0].decode().strip()==declaration['expected_head']
 lines=raw[1].splitlines();assert lines and all(line.startswith(b'?? ') for line in lines)
 untracked=[line[3:].decode('utf-8') for line in lines];assert set(untracked)==set(files) and len(untracked)==len(files)
 summary={'kind':'own-nonbenchmark-source-intake-refusal-v1','scope':'actual Git metadata/stream and selected current file observation only',
 'capture_ready':False,'source_admitted':False,'reason':'actual source worktree has all20 uncommitted tool files',
 'declaration_sha256':declaration_sha,'actual_commands':observations,'actual_untracked_paths_original_order':untracked,
 'source_and_selected_LOCAL_files_unchanged_after_each':True,'installed_version_or_loaded_image_proof':False,
 'own_canonical_production_archive_native_or_RLIB_receipt':False,'complete_independent_live_preflight':False,
 'Linux_perf_kernel_VM_benchmark_capture_or_numerical_data':False,'all_known_direct_command_children_naturally_waited':True,
 'whole_descendant_exit_proven':False,'finished':now(),'free_bytes':shutil.disk_usage(root).free}
 stable();module._write_json(base/'summary.json',summary);lease.verify_identity()
 print(json.dumps({'control':str(base),'source_admitted':False,'actual_git_commands':len(observations),'untracked_tools':len(untracked),'free_bytes':summary['free_bytes']}))

end=time.monotonic()+45;errors=[]
while True:
 admitted=False
 try:
  with local_resource_lease(exclusive=True) as lease:admitted=True;run(lease)
 except LocalResourceLeaseError as error:
  if admitted:raise
  errors.append(str(error))
  if time.monotonic()>=end:
   with Path('/tmp/connectanum-native-perf-git-output-source-control-admission-refusal.json').open('x') as f:json.dump({'utc':now(),'errors':errors,'before_control_directory_declaration_or_child':True},f,indent=2)
   print('Resource reservation remains; actual source control did not start.');break
  time.sleep(min(.5,max(0,end-time.monotonic())))
 else:break
