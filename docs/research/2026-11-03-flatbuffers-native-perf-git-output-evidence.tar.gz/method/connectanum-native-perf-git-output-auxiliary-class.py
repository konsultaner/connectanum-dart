class AuxiliaryCommand:
    """Waitable direct child + two output pipes; never live admission.

    The owner registers this prepared object BEFORE start(). All actor handles
    stay here while pending. EOF proves no writer identity or descendant exit.
    """
    def __init__(self,*,directory,name,argv,cwd,environment,lease_check,stdout_max=1024**3,stderr_max=32*1024**2):
        if (type(name) is not str or not re.fullmatch('[a-z][a-z0-9-]{0,48}',name)
            or type(argv) is not list or not argv or any(type(x) is not str or not x or '\0' in x for x in argv)
            or type(environment) is not dict or any(type(k) is not str or type(v) is not str or '\0' in k+v for k,v in environment.items())
            or any(type(x) is not int or not 0<x<=16*1024**3 for x in (stdout_max,stderr_max))):
            raise ProducerError('invalid auxiliary command declaration')
        self.directory=Path(directory);self.cwd=Path(cwd)
        if self.directory.resolve(strict=True)!=self.directory or self.cwd.resolve(strict=True)!=self.cwd:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        self.name=name;self.argv=tuple(argv);self.environment=MappingProxyType(dict(environment));self.lease_check=lease_check
        self.started=False;self.pending=False;self.finished=False;self.process=None;self.result=None
        self.error=None;self.secondary_errors=[];self.failure_attempted=False;self.publication_attempted=False
        self.status=None;self.spawn_error=None;self.streams={}
        for role,maximum in [('stdout',stdout_max),('stderr',stderr_max)]:
            self.streams[role]={'path':self.directory/(name+'.'+role),'maximum':maximum,'log':None,'fd':None,'writer':None,
                'buffer':b'','hash':hashlib.sha256(),'bytes':0,'eof':False,'quarantined':False,'write_close_confirmed':False}
        self.intent={'scope':'auxiliary_command_intent_only','capture_ready':False,'argv':list(self.argv),'cwd':str(self.cwd),
            'environment_sha256':_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode()),
            'output_bounds':{'stdout':stdout_max,'stderr':stderr_max},'producer_sha256':_regular_hash(Path(__file__).resolve())}
        lease_check();_write_json(self.directory/(name+'-intent.json'),self.intent)
        self.intent_sha256=_regular_hash(self.directory/(name+'-intent.json'))

    def _defer(self,error):
        if self.error is None:self.error=repr(error)
        else:self.secondary_errors.append(repr(error))
        if not self.failure_attempted:
            self.failure_attempted=True
            try:_write_json(self.directory/(self.name+'-failure.json'),{'primary_error':self.error,'secondary_errors':self.secondary_errors,
                'returncode':self.status,'pending':self.pending,'capture_ready':False,
                'unwritten_base64':{k:base64.b64encode(s['buffer']).decode('ascii') for k,s in self.streams.items()}})
            except BaseException as secondary:error.add_note('auxiliary failure publication failed: '+repr(secondary))

    def _close_slot(self,stream,slot):
        fd=stream[slot];stream[slot]=None
        if fd is not None:
            try:os.close(fd)
            except BaseException as error:self._defer(error)
            else:return True
        return False

    def start(self):
        if self.started or self.finished:raise ProducerError('auxiliary start attempt is permanently terminal')
        self.started=True
        try:
            self.lease_check()
            sealed=_read_json(self.directory/(self.name+'-intent.json'),self.intent_sha256)
            if (sealed['argv']!=list(self.argv) or sealed['cwd']!=str(self.cwd)
                or sealed['environment_sha256']!=_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode())
                or sealed['output_bounds']!={k:v['maximum'] for k,v in self.streams.items()}
                or sealed['producer_sha256']!=_regular_hash(Path(__file__).resolve())):
                raise ProducerError('auxiliary declared plan changed')
            _write_json(self.directory/(self.name+'-started.json'),{'intent_sha256':self.intent_sha256,'terminal':True})
            for stream in self.streams.values():
                stream['log']=stream['path'].open('xb',buffering=0)
                stream['fd'],stream['writer']=os.pipe()
                os.set_inheritable(stream['fd'],False);os.set_inheritable(stream['writer'],False)
                os.set_blocking(stream['fd'],False)
            self.process=subprocess.Popen(list(self.argv),cwd=self.cwd,env=dict(self.environment),stdin=subprocess.DEVNULL,
                stdout=self.streams['stdout']['writer'],stderr=self.streams['stderr']['writer'],close_fds=True)
            # Retain the actual owned process BEFORE fallible closure/publication.
            self.pending=True
        except BaseException as error:
            self.spawn_error=repr(error);self._defer(error)
            for stream in self.streams.values():
                self._close_slot(stream,'writer');self._close_slot(stream,'fd')
            return self._complete()
        for stream in self.streams.values():stream['write_close_confirmed']=self._close_slot(stream,'writer')
        try:_write_json(self.directory/(self.name+'-spawned.json'),{'pid':self.process.pid,'intent_sha256':self.intent_sha256})
        except BaseException as error:self._defer(error)
        return self

    def _observe_status(self):
        value=self.process.poll()
        if value is not None:self.status=value

    def _complete(self):
        # Only used with no spawned child, or natural status AND both pipe EOFs.
        self.pending=False;self.finished=True;output={}
        for role,stream in self.streams.items():
            log=stream['log'];stream['log']=None
            if log is not None:
                try:log.flush();os.fsync(log.fileno())
                except BaseException as error:self._defer(error)
                finally:
                    try:log.close()
                    except BaseException as error:self._defer(error)
            item={'eof':stream['eof'],'stream_bytes':stream['bytes'],'stream_sha256':stream['hash'].hexdigest(),
                'parent_write_close_confirmed':stream['write_close_confirmed'],'quarantined':stream['quarantined']}
            try:
                item['snapshot']=_file_snapshot(stream['path'],stream['maximum'])
                item['snapshot_matches_stream']=item['snapshot']=={'size':stream['bytes'],'sha256':stream['hash'].hexdigest()}
                if not item['snapshot_matches_stream']:raise ProducerError('auxiliary log bytes changed: '+role)
            except BaseException as error:self._defer(error)
            output[role]=item
        okay=(self.error is None and self.spawn_error is None and self.status==0
              and all(s['eof'] and s['write_close_confirmed'] for s in self.streams.values()))
        self.result={'kind':'auxiliary-command-observation-v1','scope':'owned_direct_child_and_two_output_streams_only',
            'capture_ready':False,'whole_descendant_exit_proven':False,'intent_sha256':self.intent_sha256,
            'argv':list(self.argv),'cwd':str(self.cwd),'pid':None if self.process is None else self.process.pid,
            'returncode':self.status,'spawn_error':self.spawn_error,'status':'success' if okay else 'failed',
            'primary_error':self.error,'secondary_errors':self.secondary_errors,'outputs':output}
        if self.status is not None and self.status!=0 and self.result['primary_error'] is None:self.result['primary_error']='auxiliary command nonzero or signal'
        self.publication_attempted=True
        try:_write_json(self.directory/(self.name+'-result.json'),self.result)
        except BaseException as error:
            self._defer(error);self.result['status']='failed';self.result['primary_error']=self.error
        return self.result

    def wait(self,timeout):
        if self.finished:raise ProducerError('auxiliary completion is permanently terminal')
        if not self.started:raise ProducerError('auxiliary command has not started')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded auxiliary wait required')
        try:self.lease_check()
        except BaseException as error:self._defer(error)
        deadline=time.monotonic()+timeout
        while True:
            try:self._observe_status()
            except BaseException as error:self._defer(error);return None
            if any(s['quarantined'] for s in self.streams.values()):return None
            for stream in self.streams.values():
                if stream['eof']:continue
                if stream['buffer']:
                    if stream['bytes']+len(stream['buffer'])>stream['maximum']:
                        stream['quarantined']=True;self._defer(ProducerError('auxiliary stream exceeds declared output bound'));return None
                    try:count=stream['log'].write(stream['buffer'])
                    except BaseException as error:
                        stream['quarantined']=True;self._defer(error);return None
                    if type(count) is not int or not 0<count<=len(stream['buffer']):
                        stream['quarantined']=True;self._defer(ProducerError('auxiliary write count uncertain'));return None
                    stream['hash'].update(stream['buffer'][:count]);stream['bytes']+=count;stream['buffer']=stream['buffer'][count:]
                    continue
                try:part=os.read(stream['fd'],65536)
                except (BlockingIOError,InterruptedError):continue
                except BaseException as error:self._defer(error);return None
                if part:stream['buffer']=part
                else:
                    stream['eof']=True;self._close_slot(stream,'fd')
            if all(s['eof'] for s in self.streams.values()) and self.status is not None:
                self.status=self.process.wait(timeout=0)
                return self._complete()
            remaining=deadline-time.monotonic()
            if remaining<=0:return None
            # Buffered bytes must be written before waiting for further readability.
            if any(s['buffer'] for s in self.streams.values()):continue
            readers=[s['fd'] for s in self.streams.values() if s['fd'] is not None]
            try:
                if readers:select.select(readers,[],[],min(remaining,.05))
                else:
                    try:self.status=self.process.wait(timeout=remaining)
                    except subprocess.TimeoutExpired:return None
            except BaseException as error:self._defer(error);return None


def _observe_auxiliary(owner,name,argv,stdout_max=1024**3):
    operation=AuxiliaryCommand(directory=owner.directory,name=name,argv=argv,cwd=owner.repo,
        environment=owner.environment,lease_check=owner.lease_check,stdout_max=stdout_max)
    # Owner must retain every operation before ANY actual child launch.
    owner.auxiliary_operations.append(operation)
    operation.start()
    result=operation.result
    while result is None:result=operation.wait(60)
    if result['status']!='success':raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+str(result['primary_error']))
    return result

