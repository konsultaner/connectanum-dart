from pathlib import Path
import runpy,sys,time,json,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import LocalResourceLeaseError
end=time.monotonic()+45;attempts=0;first=datetime.datetime.now(datetime.timezone.utc).isoformat();errors=[]
while True:
 attempts+=1
 try:
  sys.argv=['/tmp/connectanum-native-perf-git-output-run.py','before']
  runpy.run_path(sys.argv[0],run_name='__main__')
 except LocalResourceLeaseError as error:
  # Only admission failures before ANY source snapshot/test/child may wait.
  if Path('/tmp/connectanum-native-perf-git-output-before-source').exists():raise
  errors.append(str(error))
  if time.monotonic()>=end:
   with Path('/tmp/connectanum-native-perf-git-output-before-wait-refusal.json').open('x') as f:json.dump({'started':first,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admission_attempts':attempts,'errors':errors,'no_source_snapshot_or_test_started':True},f,indent=2)
   print('Exclusive resource admission remains unavailable; no tests started.');break
  time.sleep(min(2,max(0,end-time.monotonic())))
 else:
  with Path('/tmp/connectanum-native-perf-git-output-before-wait-admission.json').open('x') as f:json.dump({'started':first,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'admission_attempts':attempts,'earlier_admission_errors':errors,'test_execution_once':True},f,indent=2)
  break
