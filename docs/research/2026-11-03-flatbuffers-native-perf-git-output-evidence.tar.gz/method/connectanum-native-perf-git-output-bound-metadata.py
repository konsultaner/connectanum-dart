def _read_bound_metadata(path,expected,maximum=32*1024**2):
    """Return only the bytes bound to this completed observation's snapshot."""
    if (type(expected) is not dict or set(expected)!={'size','sha256'}
        or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid auxiliary metadata bound before IO')
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_uid,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022
            or before.st_size!=expected['size']):raise ProducerError('auxiliary metadata file differs')
        chunks=[];h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(65536,maximum+1-count))
            if not part:break
            chunks.append(part);count+=len(part);h.update(part)
            if count>expected['size']:raise ProducerError('auxiliary metadata grew beyond observed bytes')
        if (count!=expected['size'] or h.hexdigest()!=expected['sha256']
            or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False))):
            raise ProducerError('auxiliary metadata consumed bytes differ from observation')
        return b''.join(chunks)
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as error:
            if primary is None:raise
            primary.add_note('auxiliary metadata close failed: '+repr(error))

