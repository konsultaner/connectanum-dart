from pathlib import Path
import sys,subprocess,json,hashlib,shutil,os,datetime,time,runpy
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');phase=sys.argv[1];assert phase.replace('-','').isalnum();base=Path('/tmp/connectanum-native-perf-git-output-'+phase)
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def under_lease(lease):
 lease.verify_identity();free=shutil.disk_usage(root).free;assert free>=1024**3
 if phase=='implemented':
  apply=runpy.run_path('/tmp/connectanum-native-perf-git-output-install.py')['apply'];apply(lease)
 if phase=='controls':
  apply=runpy.run_path('/tmp/connectanum-native-perf-git-output-contract-tests.py')['apply'];apply(lease)
 if phase=='consume-before-v2':
  apply=runpy.run_path('/tmp/connectanum-native-perf-git-output-consume-tests.py')['apply'];apply(lease)
 if phase=='receipt-before':
  test=root/'tool/test_native_perf_build_producer.py';source=test.read_text()
  assert source.count('run,_=self.f.receipt_fixture()')==1
  test.write_text(source.replace('run,_=self.f.receipt_fixture()','run=self.f.receipt_fixture()[0]',1))
  lease.verify_identity()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert not subprocess.check_output(['git','diff','HEAD','--','packages','native'],cwd=root)
 snap=Path(str(base)+'-source');snap.mkdir();files=sorted(root.glob('tool/*native_perf*.py'));hashes={}
 for p in files:b=p.read_bytes();(snap/p.name).write_bytes(b);hashes[str(p.relative_to(root))]=sha(b)
 selected=sys.argv[2] if len(sys.argv)>2 else 'test_native_perf_build_producer.GitOutputTests'
 command=[sys.executable,'-B','-m','unittest','-v',selected]+sys.argv[3:]
 receipt={'started':now(),'source_sha256':hashes,'official_exclusive_lease':True,'free_bytes':free,'scope':'NEW own Git auxiliary dual-output guards only; actual separately parented finite writers, no orphan descendants/kernel/capture/benchmark','command':command}
 with Path(str(base)+'-tests.log').open('xb') as f:r=subprocess.run(command,cwd=root/'tool',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','CONNECTANUM_PERF_PRODUCER_FIXTURES':str(base)+'-fixtures'})
 lease.verify_identity();assert hashes=={str(p.relative_to(root)):sha(p.read_bytes()) for p in files}
 log=Path(str(base)+'-tests.log');receipt.update(ended=now(),exit=r.returncode,log_sha256=sha(log.read_bytes()))
 with Path(str(base)+'-tests.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({'exit':r.returncode,'log':str(log),'last':log.read_text()[-4500:]}))

end=time.monotonic()+45;admission_errors=[];started_wait=now()
while True:
 admitted=False
 try:
  with local_resource_lease(exclusive=True) as lease:
   admitted=True
   under_lease(lease)
 except LocalResourceLeaseError as error:
  if admitted:raise
  admission_errors.append(str(error))
  if time.monotonic()>=end:
   with Path(str(base)+'-admission-refusal.json').open('x') as f:json.dump({'started':started_wait,'ended':now(),'errors':admission_errors,'before_any_source_fix_snapshot_or_test':True},f,indent=2)
   print('Exclusive lease remains reserved; no source fix/snapshot/test.');break
  time.sleep(min(.5,max(0,end-time.monotonic())))
 else:
  with Path(str(base)+'-admission.json').open('x') as f:json.dump({'started_wait':started_wait,'ended':now(),'earlier_admission_errors':admission_errors,'test_execution_once':True},f,indent=2)
  break
