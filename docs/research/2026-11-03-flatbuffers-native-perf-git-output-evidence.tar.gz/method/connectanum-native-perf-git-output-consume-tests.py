from pathlib import Path

def apply(lease):
 lease.verify_identity();p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/test_native_perf_build_producer.py');s=p.read_text()
 assert 'def test_git_consume_initial' not in s
 s+=r'''

    def test_git_consume_initial_rejects_changed_bytes_after_snapshot(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'consume';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb');original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            path=owner.directory/(name+'.stdout');raw=path.read_bytes()
            with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
            self.assertNotEqual(b'0'*40+b'\n',raw);path.write_bytes(b'0'*40+b'\n')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):run._git('rev-parse','HEAD')

    def test_git_consume_receipt_rejects_forged_empty_dirty_status(self):
        run=self.f.receipt_fixture()[0]
        (self.f.repo/'OWN-new-untracked-input').write_text('OWN synthetic dirty source control')
        original=producer._observe_auxiliary
        def observe(owner,name,argv,stdout_max=1024**3):
            result=original(owner,name,argv,stdout_max)
            if argv[-3:]==['status','--porcelain','--untracked-files=normal']:
                path=owner.directory/(name+'.stdout');raw=path.read_bytes();self.assertTrue(raw)
                with (owner.directory/(name+'-stdout-before-OWN-mutation.bin')).open('xb') as f:f.write(raw)
                path.write_bytes(b'')
            return result
        with mock.patch.object(producer,'_observe_auxiliary',observe):
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertFalse((run.directory/'input-receipt.json').exists())
'''
 p.write_text(s);lease.verify_identity()
