def _read_bound_metadata(path,expected,maximum=32*1024**2):
    """Return only the bytes bound to this completed observation's snapshot."""
    if (type(expected) is not dict or set(expected)!={'size','sha256'}
        or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid auxiliary metadata bound before IO')
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_uid,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022
            or before.st_size!=expected['size']):raise ProducerError('auxiliary metadata file differs')
        chunks=[];h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(65536,maximum+1-count))
            if not part:break
            chunks.append(part);count+=len(part);h.update(part)
            if count>expected['size']:raise ProducerError('auxiliary metadata grew beyond observed bytes')
        if (count!=expected['size'] or h.hexdigest()!=expected['sha256']
            or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False))):
            raise ProducerError('auxiliary metadata consumed bytes differ from observation')
        return b''.join(chunks)
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as error:
            if primary is None:raise
            primary.add_note('auxiliary metadata close failed: '+repr(error))

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        name=f'git-{index:03}';out=self.directory/(name+'.stdout')
        cmd=[self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv]
        result=_observe_auxiliary(self,name,cmd)
        stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
        if argv[0]=='archive':
            if _file_snapshot(out,1024**3)!=stdout:raise ProducerError('auxiliary archive output differs')
            data=None
        else:data=_read_bound_metadata(out,stdout)
        self._event('git_observation',argv=list(argv),returncode=result['returncode'],stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'],
            auxiliary_result_sha256=_regular_hash(self.directory/(name+'-result.json')))
        if argv[0]=='archive':return out
        return data

def _receipt_source_audit(run):
    path=run.directory/'receipt-source-audit.jsonl'
    audit=path.open('xb');index=0
    try:
        def observe(*argv):
            nonlocal index
            number=index;index+=1
            out=run.directory/f'receipt-git-{number:03}.stdout';err=run.directory/f'receipt-git-{number:03}.stderr'
            cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
            result=_observe_auxiliary(run,f'receipt-git-{number:03}',cmd,32*1024**2)
            stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
            data=_read_bound_metadata(out,stdout)
            record={'argv':cmd,'returncode':result['returncode'],'stdout':stdout,'stderr':stderr,
                'auxiliary_result_sha256':_regular_hash(run.directory/f'receipt-git-{number:03}-result.json')}
            audit.write((json.dumps(record,sort_keys=True)+'\n').encode());audit.flush();os.fsync(audit.fileno())
            return data
        run._source_guard(observe)
    finally:
        primary=sys.exception()
        try:audit.close()
        except OSError as e:
            if primary is None:raise
            primary.add_note('receipt source audit close failed: '+repr(e))
    return _regular_hash(path)
