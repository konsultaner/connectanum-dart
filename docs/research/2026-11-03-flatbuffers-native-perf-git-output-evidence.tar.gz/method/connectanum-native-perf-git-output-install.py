from pathlib import Path
import hashlib

def apply(lease):
    lease.verify_identity()
    p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
    assert hashlib.sha256(p.read_bytes()).hexdigest()=='676a4765942ebac243157cc371ee410de6f6d08a55346dc629b1ac756473b4b0'
    s=p.read_text();added=Path('/tmp/connectanum-native-perf-git-output-auxiliary-class.py').read_text()
    assert 'class AuxiliaryCommand' not in s;s=s.replace('class CommandProducer:',added+'\nclass CommandProducer:',1)
    needle="self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False;self.output_log=None;self.failure_attempted=False"
    assert needle in s;s=s.replace(needle,needle+';self.auxiliary_operations=[]',1)
    a=s.index('    def _git(self,*argv):');b=s.index('    def _source_guard(',a)
    s=s[:a]+'''    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        name=f'git-{index:03}';out=self.directory/(name+'.stdout')
        cmd=[self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv]
        result=_observe_auxiliary(self,name,cmd)
        stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
        self._event('git_observation',argv=list(argv),returncode=result['returncode'],stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'],
            auxiliary_result_sha256=_regular_hash(self.directory/(name+'-result.json')))
        if argv[0]=='archive':return out
        if stdout['size']>32*1024**2:raise ProducerError('git metadata exceeds declared bound')
        return out.read_bytes()

''' +s[b:]
    a=s.index('''            with out.open('xb') as o,err.open('xb') as e:''',s.index('def _receipt_source_audit'))
    b=s.index('''            return out.read_bytes()''',a)
    s=s[:a]+'''            cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
            result=_observe_auxiliary(run,f'receipt-git-{number:03}',cmd,32*1024**2)
            stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
            record={'argv':cmd,'returncode':result['returncode'],'stdout':stdout,'stderr':stderr,
                'auxiliary_result_sha256':_regular_hash(run.directory/f'receipt-git-{number:03}-result.json')}
            audit.write((json.dumps(record,sort_keys=True)+'\\n').encode());audit.flush();os.fsync(audit.fileno())
''' +s[b:]
    p.write_text(s);lease.verify_identity()
