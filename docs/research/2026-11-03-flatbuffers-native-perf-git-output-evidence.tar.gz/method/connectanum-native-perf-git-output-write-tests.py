from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/test_native_perf_build_producer.py')
s=r'''

class GitOutputTests(unittest.TestCase):
    """Actual OWN Git/extra finite writers, separate output endpoints, no orphan."""
    def setUp(self):
        self.f=ProducerTests('runTest');self.f.setUp();self.base=self.f.base
        self.actors=[];self.release=self.base/'release-git-writer';self.ready=self.base/'git-writer-ready'
        self.threads=[];self.parent=None

    def tearDown(self):
        self.release.touch(exist_ok=True)
        for thread in self.threads:
            thread.join(6)
            self.assertFalse(thread.is_alive(),'OWN finite observer thread must finish naturally')
        statuses=[{'pid':child.pid,'returncode':child.wait(5)} for child in self.actors]
        self.f.tearDown()
        if self.parent is not None and self.parent.events is not None:self.parent.events.close();self.parent.events=None
        (self.base/'owned-git-output-actors.json').write_text(json.dumps({'scope':'OWN main-parented finite Popen actors only; no descendants/kernel/capture','statuses':statuses}))

    def gate_observation(self,call,match):
        import threading,time
        real=producer.subprocess.Popen;selected=[];outcome={};done=threading.Event()
        code="""import os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:]);ready.write_text('ready')
end=time.monotonic()+4
while not release.exists() and time.monotonic()<end:time.sleep(.005)
os.write(1,b'late-owned-git-output\\n');os.write(2,b'late-owned-git-stderr\\n')
"""
        def popen(argv,*args,**kw):
            if not selected and match(list(argv)):
                writer=real([sys.executable,'-c',code,str(self.ready),str(self.release)],
                    stdout=kw['stdout'],stderr=kw['stderr'],stdin=subprocess.DEVNULL,close_fds=True)
                self.actors.append(writer)
                child=real(argv,*args,**kw);selected.append(child);self.actors.append(child)
                return child
            return real(argv,*args,**kw)
        def observe():
            try:outcome['value']=call()
            except BaseException as error:outcome['error']=error
            finally:done.set()
        with mock.patch.object(producer.subprocess,'Popen',popen):
            thread=threading.Thread(target=observe);self.threads.append(thread);thread.start()
            try:
                end=time.monotonic()+2
                while (not self.ready.exists() or not selected) and time.monotonic()<end:time.sleep(.005)
                self.assertTrue(selected);self.assertTrue(self.ready.exists())
                self.assertEqual(0,selected[0].wait(2))
                self.assertFalse(done.wait(.10),'Git observation completed before actual retained stdout/stderr writer EOF')
            finally:
                self.release.touch(exist_ok=True);thread.join(6)
        self.assertFalse(thread.is_alive())
        return outcome

    def test_git_initial_observer_waits_both_real_output_writers(self):
        run=object.__new__(producer.CommandProducer);self.parent=run
        run.directory=self.base/'direct';run.directory.mkdir();run.repo=self.f.repo
        run.environment=dict(os.environ);run.tools={};run.git_index=0;run.lease_check=lambda:None;run.auxiliary_operations=[]
        run.events=(run.directory/'journal.jsonl').open('xb')
        outcome=self.gate_observation(lambda:run._git('rev-parse','HEAD'),lambda argv:argv[-2:]==['rev-parse','HEAD'])
        if 'error' in outcome:raise outcome['error']
        self.assertIn(b'late-owned-git-output',outcome['value'])
        self.assertIn(b'late-owned-git-stderr',(run.directory/'git-000.stderr').read_bytes())

    def test_git_receipt_observer_refuses_late_dirty_status_bytes(self):
        run,_=self.f.receipt_fixture()
        outcome=self.gate_observation(lambda:producer.emit_fixture_receipt(run,'canonical'),
            lambda argv:argv[-3:]==['status','--porcelain','--untracked-files=normal'])
        self.assertIsInstance(outcome.get('error'),producer.ProducerError)
        self.assertIn('not clean',str(outcome['error']))
        self.assertFalse((run.directory/'input-receipt.json').exists())
        self.assertTrue((run.directory/'receipt-failure.json').exists())
'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();assert 'class GitOutputTests' not in p.read_text()
 with p.open('a') as f:f.write(s)
 lease.verify_identity()
