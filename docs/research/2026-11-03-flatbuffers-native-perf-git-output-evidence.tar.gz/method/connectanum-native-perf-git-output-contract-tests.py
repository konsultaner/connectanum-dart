from pathlib import Path

def apply(lease):
    lease.verify_identity()
    p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/test_native_perf_build_producer.py');s=p.read_text()
    assert 'def make_auxiliary' not in s
    s=s.replace("self.threads=[];self.parent=None","self.threads=[];self.parent=None;self.operations=[]",1)
    needle="        statuses=[{'pid':child.pid,'returncode':child.wait(5)} for child in self.actors]"
    replace="""        for operation in self.operations:
            if operation.pending:self.finish_auxiliary(operation)
            if operation.process is not None:self.actors.append(operation.process)
"""+needle
    assert needle in s;s=s.replace(needle,replace,1)
    extra=r'''

    def make_auxiliary(self,code,**kw):
        directory=self.base/'auxiliary';directory.mkdir(mode=0o700)
        op=producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c',code],
            cwd=self.f.repo,environment=dict(os.environ),lease_check=lambda:None,**kw)
        self.operations.append(op)
        return op

    def finish_auxiliary(self,op):
        import time
        end=time.monotonic()+6
        result=op.result
        while result is None and time.monotonic()<end:result=op.wait(2)
        self.assertIsNotNone(result,'OWN finite observation must complete naturally')
        return result

    def test_git_auxiliary_intent_and_owner_before_spawn(self):
        op=self.make_auxiliary("print('owned')");real=producer.subprocess.Popen;observed=[]
        def popen(*args,**kwargs):
            self.assertIn(op,self.operations)
            self.assertEqual(op.intent_sha256,digest((op.directory/'probe-intent.json').read_bytes()))
            self.assertTrue((op.directory/'probe-started.json').is_file());observed.append(True)
            return real(*args,**kwargs)
        with mock.patch.object(producer.subprocess,'Popen',popen):op.start()
        self.assertEqual([True],observed)
        self.assertFalse(os.get_inheritable(op.streams['stdout']['fd']))
        self.assertFalse(os.get_blocking(op.streams['stderr']['fd']))
        result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status']);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_git_auxiliary_declaration_drift_is_prechild_terminal(self):
        op=self.make_auxiliary("print('original')")
        op.argv=(sys.executable,'-c',"print('changed')");op.intent['argv']=list(op.argv)
        op.start()
        self.assertIsNone(op.process);self.assertEqual('failed',op.result['status'])
        self.assertIn('plan changed',op.result['primary_error'])
        with self.assertRaises(producer.ProducerError):op.start()

    def test_git_auxiliary_drains_two_capacity_streams(self):
        op=self.make_auxiliary("import os;[os.write(1,b'A'*65536) for _ in range(20)];[os.write(2,b'B'*65536) for _ in range(17)]")
        op.start();result=self.finish_auxiliary(op)
        self.assertEqual('success',result['status'])
        for role,raw in [('stdout',b'A'*(20*65536)),('stderr',b'B'*(17*65536))]:
            self.assertEqual(raw,(op.directory/('probe.'+role)).read_bytes())
            self.assertEqual(digest(raw),result['outputs'][role]['stream_sha256'])
            self.assertTrue(result['outputs'][role]['eof']);self.assertTrue(result['outputs'][role]['snapshot_matches_stream'])

    def test_git_auxiliary_postspawn_first_error_and_secondary_retained(self):
        op=self.make_auxiliary("print('finite-owned')");original=producer._write_json
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(28,'PRIMARY postspawn observation publication')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):op.start()
        self.assertTrue(op.pending);self.assertIsNotNone(op.process)
        real=producer.os.read;fd=op.streams['stdout']['fd']
        def read(target,count):
            if target==fd:raise OSError(5,'SECONDARY output read')
            return real(target,count)
        with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
        result=self.finish_auxiliary(op)
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIn('PRIMARY',result['primary_error']);self.assertTrue(any('SECONDARY' in x for x in result['secondary_errors']))

    def test_git_auxiliary_eof_close_ownership_consumed_once(self):
        op=self.make_auxiliary("print('finite')");op.start();fd=op.streams['stdout']['fd'];real=producer.os.close;calls=[]
        def close(target):
            if target==fd and not calls:
                calls.append(target);real(target);raise OSError(5,'ambiguous read-end close')
            return real(target)
        with mock.patch.object(producer.os,'close',close):result=self.finish_auxiliary(op)
        self.assertEqual([fd],calls);self.assertIsNone(op.streams['stdout']['fd'])
        self.assertEqual('failed',result['status']);self.assertEqual(0,result['returncode'])
        with self.assertRaises(producer.ProducerError):op.wait(0)

    def test_git_auxiliary_ambiguous_write_quarantines_without_replay(self):
        op=self.make_auxiliary("import os;os.write(1,b'tiny-raw')");op.start();original=op.streams['stdout']['log'];calls=[]
        class Fault:
            def write(self,data):calls.append(bytes(data));raise OSError(28,'injected auxiliary space fault')
        op.streams['stdout']['log']=Fault()
        try:
            self.assertIsNone(op.wait(2));self.assertTrue(op.streams['stdout']['quarantined'])
            self.assertIsNone(op.wait(0));self.assertEqual([b'tiny-raw'],calls)
            self.assertTrue(op.pending);self.assertIsNone(op.result)
            raw=json.loads((op.directory/'probe-failure.json').read_text())
            self.assertEqual(b'tiny-raw',base64.b64decode(raw['unwritten_base64']['stdout']))
        finally:
            status=op.process.wait(3)
            (self.base/'fixture-auxiliary-quarantine-cleanup.json').write_text(json.dumps({'scope':'OWN finite fixture-only FD cleanup AFTER known direct natural exit, NO producer recovery/admission',
                'pid':op.process.pid,'returncode':status,'unwritten_base64':base64.b64encode(op.streams['stdout']['buffer']).decode('ascii')}))
            self.actors.append(op.process);self.operations.remove(op)
            for stream in op.streams.values():
                for name in ('fd','writer'):
                    fd=stream[name];stream[name]=None
                    if fd is not None:os.close(fd)
                if stream['log'] is not None and stream['log'] is not op.streams['stdout']['log']:stream['log'].close()
                stream['log']=None
            original.close()

    def test_git_auxiliary_eof_before_child_exit_remains_pending(self):
        code="import os,time;from pathlib import Path;os.close(1);os.close(2);p=Path("+repr(str(self.ready))+");p.write_text('ready');r=Path("+repr(str(self.release))+");end=time.monotonic()+4\nwhile not r.exists() and time.monotonic()<end:time.sleep(.005)"
        op=self.make_auxiliary(code);op.start()
        import time
        end=time.monotonic()+2
        while not self.ready.exists() and time.monotonic()<end:time.sleep(.005)
        self.assertTrue(self.ready.exists());self.assertIsNone(op.wait(.03));self.assertIsNone(op.status)
        self.assertTrue(all(s['eof'] for s in op.streams.values()));self.release.touch()
        self.assertEqual('success',self.finish_auxiliary(op)['status'])

    def test_git_auxiliary_boolean_bounds_refuse_before_io(self):
        directory=self.base/'invalid';directory.mkdir()
        with self.assertRaises(producer.ProducerError):producer.AuxiliaryCommand(directory=directory,name='probe',argv=[sys.executable,'-c','pass'],cwd=self.f.repo,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=True)
        self.assertEqual([],list(directory.iterdir()))

    def test_git_auxiliary_partial_failure_evidence_has_one_attempt(self):
        op=self.make_auxiliary("print('finite')");original=producer._write_json;calls=[]
        def write(path,value):
            if Path(path).name=='probe-spawned.json':raise OSError(13,'PRIMARY postspawn')
            if Path(path).name=='probe-failure.json':
                calls.append(True)
                with Path(path).open('xb') as f:f.write(b'PARTIAL-OWN-FAILURE')
                raise OSError(28,'secondary publication space failure')
            return original(path,value)
        with mock.patch.object(producer,'_write_json',write):
            op.start();real=producer.os.read;fd=op.streams['stdout']['fd']
            def read(target,count):
                if target==fd:raise OSError(5,'SECONDARY read')
                return real(target,count)
            with mock.patch.object(producer.os,'read',read):self.assertIsNone(op.wait(2))
            result=self.finish_auxiliary(op)
        self.assertEqual([True],calls);self.assertIn('PRIMARY',result['primary_error'])
        self.assertEqual(b'PARTIAL-OWN-FAILURE',(op.directory/'probe-failure.json').read_bytes())
        self.assertEqual('failed',result['status'])
'''
    p.write_text(s+extra);lease.verify_identity()
