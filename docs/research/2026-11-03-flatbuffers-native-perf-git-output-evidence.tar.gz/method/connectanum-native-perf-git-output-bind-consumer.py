from pathlib import Path
import json,hashlib

def apply(lease):
    lease.verify_identity();p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py');s=p.read_text()
    expected=json.loads(Path('/tmp/connectanum-native-perf-git-output-consume-before-v2-tests.json').read_text())['source_sha256']['tool/native_perf_build_producer.py']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
    assert 'def _read_bound_metadata' not in s
    added=Path('/tmp/connectanum-native-perf-git-output-bound-metadata.py').read_text()
    s=s.replace('class AuxiliaryCommand:',added+'\nclass AuxiliaryCommand:',1)
    a=s.index('    def _git(self,*argv):');b=s.index('    def _source_guard(',a)
    part=s[a:b]
    needle="        self._event('git_observation'"
    at=part.index(needle)
    part=part[:at]+"""        if argv[0]=='archive':
            if _file_snapshot(out,1024**3)!=stdout:raise ProducerError('auxiliary archive output differs')
            data=None
        else:data=_read_bound_metadata(out,stdout)
"""+part[at:]
    part=part.replace("        if stdout['size']>32*1024**2:raise ProducerError('git metadata exceeds declared bound')\n        return out.read_bytes()","        return data",1)
    s=s[:a]+part+s[b:]
    a=s.index('def _receipt_source_audit(run):');b=s.index('def _emit(',a);part=s[a:b]
    part=part.replace("            record={'argv':cmd", "            data=_read_bound_metadata(out,stdout)\n            record={'argv':cmd",1).replace('            return out.read_bytes()','            return data',1)
    s=s[:a]+part+s[b:];p.write_text(s);lease.verify_identity()
