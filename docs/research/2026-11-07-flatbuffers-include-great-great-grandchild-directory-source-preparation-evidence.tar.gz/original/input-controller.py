import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat,contextlib,time,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-directory-inputs-v1';I=P/'source-preparation-inputs-v1';v=json.loads(sys.argv[1]);CP=B/'current-task-checkpoint.json'
inputs=[
('original190collector',B/'2026-11-07-actions-include-grandchild-directory-inputs-v1/FIRST-local-static-binding-v1/collector-bound-PRIVATE',1613289,'cab8351afb91aa946d151e472ee302d8800aa3f8351e1b51ae842138041d6fc2'),
('workflow35',B/'2026-11-07-actions-include-great-grandchild-regular-inputs-v1/FIRST-originalActions-v1/workflow-bound-PRIVATE',483481,'702d6f2436422a1d7c8357bea096bd4fa739df97e68ca675947a9dcf546a9362'),
('NEW199scope',B/'2026-11-07-actions-include-great-grandchild-directory-scope-v1/ALL199-new-exact-public-safe-directory-scope-BEFORE-INPUT-IO.json',5234963,'e1600b8bff415b6b7e531b66adeded088ac21362a4ce52c21946f347e60b5fd4'),
('actual4868BODYmetadata',B/'2026-11-07-actions-include-great-grandchild-regular-inputs-v1/FIRST-remaining-saved4868-verification-v1/ROOT-NEW-ALL4868-regular-great-grandchild-input-assessment-PRIVATE.json',63401479,'a49f18de7e725caedeebcae268c14669346acb1ea4de23f151f61c5d389854f0'),
('actual190DIRECTORYmetadata',B/'2026-11-07-actions-include-grandchild-directory-inputs-v1/FIRST-originalActions-v1/ROOT-NEW-ALL190-directory-input-assessment-PRIVATE.json',21618013,'7d1b45c39fc32fe52e446610d2aa022ea3489b795f75941dff9ead67d47a9082'),
('actual1229BODYmetadata',B/'2026-11-07-actions-include-grandchild-regular-inputs-v1/Actions-v1/ROOT-NEW-ALL1229-regular-grandchild-input-assessment-PRIVATE.json',14412328,'1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331')]
@contextlib.contextmanager
def first_body():
 for attempt in range(1,37):
  cm=m.local_resource_lease(exclusive=True)
  try:lease=cm.__enter__()
  except m.LocalResourceLeaseError as e:
   print(json.dumps({'official_EX_pretarget_refusal':attempt,'body_entered':False,'error':str(e)}),flush=True)
   if attempt==36:raise
   time.sleep(10);continue
  try:yield lease,attempt-1
  except BaseException:
   if not cm.__exit__(*sys.exc_info()):raise
  else:cm.__exit__(None,None,None)
  return
with first_body() as (lease,refusals):
 lease.verify_identity();P.mkdir();I.mkdir()
 def save(n,b):
  with (I/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':v['scope'],'exact_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':h} for r,p,n,h in inputs],'FIRST_selected_new_original190control_tail_range':[1595289,1613289],'root_literal_selection':'FIRST new199-target root selection ONLY source bytes that start OUT = at physical lineboundary; opaque originalprefix otherwise/no originalAST-parser-source-reverse-condition-replay','all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-input-context.json',json.dumps(v,indent=2));bindings=[];saved={}
 def read(path,size,sha,role):
  b={'role':role,'path':str(path),'range':[0,size],'expected_sha256':sha,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   a=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];b['before']={k:getattr(a,k) for k in keys};b['before_atime_ns_POINT_ONLY']=a.st_atime_ns;assert stat.S_ISREG(a.st_mode) and a.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    block=os.read(fd,min(65536,size-count));assert block,'earlyrangeend/FOREVERquarantine';parts.append(block);count+=len(block);h.update(block)
   z=os.fstat(fd);b.update(after={k:getattr(z,k) for k in keys},after_atime_ns_POINT_ONLY=z.st_atime_ns,bytes=count,sha256=h.hexdigest());assert b['before']==b['after'] and count==size and h.hexdigest()==sha;raw=b''.join(parts)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return raw
 for role,path,size,sha in inputs:
  raw=read(path,size,sha,role);saved[role]=raw;save(role+'-opaque-bound-PRIVATE',raw)
 source=saved['original190collector'];tail=source[1595289:1613289];save('FIRST-new199-selected-original190-tail-1595289-1613289.txt',tail)
 roots=[];offset=0
 for line in source.splitlines(keepends=True):
  if line.startswith(b'OUT = '):roots.append({'range':[offset,offset+len(line)],'raw_line':line.decode(),'sha256':hashlib.sha256(line).hexdigest()})
  offset+=len(line)
 scope=json.loads(saved['NEW199scope'])
 refs=scope['ALL199_new_literal_directory_references'];assert len(refs)==199
 obj={role:json.loads(saved[role]) for role in ['actual4868BODYmetadata','actual190DIRECTORYmetadata','actual1229BODYmetadata']}
 descriptor={'saved_metadata_bindings':len(bindings),'pret arget_EX_refusals':refusals,'original190collector_bytes':len(source),'original190collector_sha256':hashlib.sha256(source).hexdigest(),'FIRST_new199_root_candidates':roots,'FIRST_new199_control_tail_range':[1595289,1613289],'FIRST_new199_control_tail_sha256':hashlib.sha256(tail).hexdigest(),'NEW199scope_topkeys':list(scope),'NEW199_count':len(refs),'original_metadata_topkeys':{k:list(o) for k,o in obj.items()},'new_SDK_INPUT_queries':0,'new_Actions_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None}
 save('FIRST-input-bindings-and-selected-control-descriptor.json',json.dumps(descriptor,indent=2))
 before=CP.read_bytes();save('checkpoint-before-input-source-preparation.json',before);d=json.loads(before);d['actions_include_great_great_grandchild_directory_inputs_v1']={'directory':str(P),'phase':'FIRST_NEW199_six_input_bindings_controlselection_COMPLETE_CONSUMED_remaining_literal_qualification_AND_generation_PENDING_NOT_queried','source_control_and_ledger':descriptor,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_great_grandchild_directory_inputs='FIRSTsixbindings-controlselection_complete_remaining_new199referencequalification-generation_pending',next='FIRSTremaining savedboundmetadata NEW199 literalreference qualification and selectedcontrol interpretation BEFOREnewsourcegeneration. No sixinputreader-controlselection replay; no SDKINPUT-Actions-sourcecommit-dispatch. AllsetupUNADMITTED/flagsFALSE/ownershipNone.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(descriptor),flush=True);print(json.dumps({'FIRST_new199_selected_control_tail':tail.decode()},ensure_ascii=True),flush=True);lease.verify_identity()
