import sys,pathlib,json,hashlib,subprocess,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-shape-progress-v1');OLD=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-returns-progress-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();P.mkdir();q=P/'planning';q.mkdir()
 source=(OLD/'after-producer.py').read_text();tests=(OLD/'after-tests.py').read_text()
 assert hashlib.sha256(source.encode()).hexdigest()=='534c16bd6ba26f0b42d390341243204b1ac970004cb7c7ecaf65da7386bd1cd6'
 assert hashlib.sha256(tests.encode()).hexdigest()=='0bc3ab5ee15ef12475f1cb2209089a26a51877aac6420e4ab01ab811bd4af4d6'
 (P/'cached-before-producer.py').open('x').write(source);(P/'cached-before-tests.py').open('x').write(tests)
 tree=ast.parse(source);selected=[]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name=='_failure_preservation_group':selected.append(ast.get_source_segment(source,node))
  if isinstance(node,ast.ClassDef) and node.name=='CommandProducer':
   selected += [ast.get_source_segment(source,x) for x in node.body if isinstance(x,ast.FunctionDef) and x.name=='__init__']
 context='NEW bounded test planning <=160words. Exact native failure helper returns plain five-tuple (owner,guard,refuse,primary,secondary_list). Constructor currently refuses only known None/bool. Hypothesis: known first helper return empty tuple, four-tuple, six-tuple, or list(native5tuple) is accepted until later helper calls return native5tuple and constructor publishes deferred owner; no actual BEFORE run yet. Plan 4 invalid cases: native tuple fully created ONLY ROOT, then first callback returns one selected malformed shape, later callbacks delegate native unchanged; actual whole original _spawn completes inside ROOT then unique First; never adopt ROOT saved tuple or Source-returned unexpected owner, never Source.wait such owner. New positive: actual original _make_archive completes then unique First before input/recipe, helper returns native5tuple, failure JSON preservesFirst. Positive differs from consumed reserved-event/input-drift/whole_spawn controls. Existing fixture captures actual Aux+recipe Popen/original waits/creator pipes/FileIO before Source publication/I/O, finite child, ROOT originalwait10/full pipe bytes+EOF then closes only same known handles AFTER evidence. 1GiB floor/officialEX before unit runs. All prior tests/models/runs consumed; DO NOT suggest repeating them. Is new tuple kind/arity regression meaningful and is type(group)is tuple + len==5 before pending sufficient for THIS limited shape contract? NOT origin-auth/callable validation/ownership/ABA/fullEX/RAM repair. At most 2 concrete test pitfalls. No code edits from theory alone.\n'+'\n\n'.join(selected)
 assert len(context)<24000
 declaration=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW failure-group exact tuple kind and arity',cached_source_sha256=hashlib.sha256(source.encode()).hexdigest(),cached_test_sha256=hashlib.sha256(tests.encode()).hexdigest(),prospective_only=True,proposed_NEW5=['empty_tuple','short_tuple4','long_tuple6','list_of_native5','native5_after_archive_First'],Source_edit_only_after_actual_BEFORE_failure=True,prior_controls_models_campaigns_NOT_replayed=True,SourceHEAD_current20_compiled_runtime_NOT_refreshed=True,no_build_capture_adoption_or_deletion=True)
 (P/'declaration.json').open('x').write(json.dumps(declaration,indent=2));(q/'context.txt').open('x').write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--model','qwen3.8:27b','--num-predict','1600','--max-input-chars','24000','--max-response-chars','12000','--timeout','180','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').open('x').write(json.dumps(dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/'start.json').open('x').write(json.dumps(dict(pid=child.pid)))
 out,err=child.communicate();status=wait();inp.close()
 (q/'stdout.bin').open('xb').write(out);(q/'stderr.bin').open('xb').write(err)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True)
 (q/'result.json').open('x').write(json.dumps(result,indent=2));l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-500:])
