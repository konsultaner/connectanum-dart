import os,time
time.sleep(0.08)
os.write(1,b'GS-v1-out')
os.write(2,b'GS-v1-err')
