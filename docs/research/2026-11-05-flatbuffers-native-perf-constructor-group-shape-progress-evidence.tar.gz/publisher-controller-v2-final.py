import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-shape-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-constructor-group-shape-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication-v2';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='1d80b22bab573eee9d7b9335ea853742bb96b79b'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication-v2/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication-v2/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation-v2.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common='## 2026-11-05 — Validate failure-group tuple shape before deferral\n\nThe constructor now requires a plain five-element tuple from the failure-group helper before reading pending or entering deferral. Four new controlled cases returned an empty tuple, a four-element tuple, a six-element tuple or a list containing the native five elements. Before the change, all four continued through later native helper calls and returned an owner. After the change, each raises the original First before further metadata access. This validates kind and arity; it does not authenticate origins, callable fields or ownership.\n\nThe new before run is 4FAIL/1PASS/0ERROR. Its healthy control completes the actual archive operation, then raises First before input checking or recipe launch; the native group preserves First. Final after is 7PASS/0FAIL/0ERROR: the matching five new cases and two affected constructor callers covering a missing executable and a post-spawn journal error. These are controlled refusal regressions, not spontaneous kernel faults or evidence of the RAM cause.\n\nOnly the constructor condition changes. Whole Source reverse projection and the old test prefix are exact. Original native actors, waits and creator handles are retained before Source publication or I/O; raw pipe bytes and EOF precede scoped ROOT closes. These remain unit observations. The twenty helpers remain uncommitted, uncanonical and unadmitted. RAM repair, original-runtime admission, final strict 48/50 and clean final CI remain incomplete.\n\n'
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-constructor-group-shape-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: validate constructor failure group tuple shape'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_group_shape_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Next NEWpredeclared question: five-tuple field/callable contracts or binding/interior/concurrentABA/historical-transitive immutableoriginalruntimepreflight, onlyeditaftermeaningfulactualBEFOREfail. Current6e04ce/3661f7 selected7PASS=matchingNEW5+2affectedconstructorcallers(missingexecutable/postspawnjournalerror). BEFORE5=4FAIL1PASS0ERROR frozen. Actualnativefailuregroup5tuple completesONLYROOT; firstcallback knownreturns tuple0/4/6 orlist(native5), latercallsoriginalnative. Beforehelper3/getters59/ownerpublished; Rootneveradoptsreturnedowner orSource.waits. ConstructornowONLYexacttuple+arity5 BEFOREpending, raisesOriginalFirst; AFTERhelper1/getters0/noSourceownerpublication/defer-preserve-repr-close/ROOTtuplefill. Positiveactualwhole_make_archiveNone thenRootFirst/nativegroup/pendingFalse/5Aux0recipe/failureJSONFirst differsfromoldreserved-spawnedevent-inputdriftcontrols. KindarityNOTorigin-auth/callablefield-validity/ownership/allshapes. WholeSourceBYTEprojectback/oldtestPREFIXexact/other18helpers3bins-oldauxpredicates-owner_emit_attempted exact. NEW5onlyv1exactselection/no old6-5-27/25-2bodies-7suite-private2 replay/currentcanonicalaggregate. New10views5before5after/29ROOToriginalwaitrowsperphase signed0cachedpossible/Root4pipe8fileclosesperphase AFTERevidence; parentAFTERoverlapnotdistinct;35setupGitperphase separate0-BOTH. Actual18Brawpipe+EOF/logicalcountsNOTmemoryRSSbenchmarkpayload. ParentDarwinEX10before14afterNone UNITnotphysicalEX-originalLinux/fullFD-interpreter-delegate-descendantclosure/admission; beforeview/waitreadfailurecleanup incomplete/no missingAPI-PID-status-error-buffer reconstruction/PIDscan-kill-fullreap. All20uncommitteduncanonicalunadmitted/providerABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/noSourceadoption-SDKbuild-kernel-broker-benchmarkcapture-strictdispatch. GroupsclosuresrawchunksprocesslifeNOTfixedmemory/heapRSSgrowth-allocvolume-timing-leakcauseUNMEASURED/no RAMrepair-memorybound-trim-pop-reset-evict-deleteauthority. UnknownPopenCtorPERMANENT/frozenauxpredicates-owner_emit_attempted; Sourcefield-status-EOF-closedFD DATAneverownership-EXrelease/admission. Qwen25123=0/1711out398err;GLM26136=0/3888out1370err/BOTH EOF-naturalreaped-fullanswers-ROOTqualified NOTwholecurrentapproval. RejectGLMreset-pop-IDreuse-partialregistration-inventedgroup1call/archivefailure; callablefieldgap prospective/no furtherSourceedit. Free274039500800B/floorsDATA-recheck/no buildcapturecleanupauthority/outsidecleanupcauseUNMEASURED.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Constructor_group_shape_BEFORE5_4FAIL1PASS_AFTER7PASS_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
