import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 import pathlib,json,hashlib,urllib.request,urllib.parse
 p=pathlib.Path('/private/tmp/connectanum-native-perf-parent-writers-primary-v1');p.mkdir(mode=0o700)
 urls=[
  ('python314-io','https://docs.python.org/3.14/library/io.html'),
  ('cpython3144-bufferedio','https://raw.githubusercontent.com/python/cpython/v3.14.4/Modules/_io/bufferedio.c')]
 def put(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 put(p/'attempt.json',dict(terminal=True,scope='NEW primary-reference input for BufferedWriter implicit flush; no SDK change or execution attestation',
  inputs=urls,maximum_bytes_each=2*1024**2,full_bodies_LOCALONLY=True,no_model_endpoint_or_GitHub_token=True))
 local=p/'LOCAL-ONLY';local.mkdir(mode=0o700)
 receipts=[]
 for name,url in urls:
  request=urllib.request.Request(url,headers={'User-Agent':'Codex-source-reference/1.0'})
  with urllib.request.urlopen(request,timeout=45) as response:
   final=response.geturl();assert urllib.parse.urlparse(final).hostname in ('docs.python.org','raw.githubusercontent.com')
   data=response.read(2*1024**2+1)
   with (local/(name+'.body')).open('xb') as f:f.write(data)
   item=dict(url=url,final_url=final,status=response.status,size=len(data),sha256=hashlib.sha256(data).hexdigest(),
    content_type=response.headers.get('Content-Type'),date=response.headers.get('Date'),
    body_LOCALONLY=True,reference_only_not_installed_binary_or_loaded_instruction_proof=True)
   put(p/(name+'-receipt.json'),item);receipts.append(item)
   assert len(data)<=2*1024**2
 put(p/'receipts.json',receipts)
 print(json.dumps(receipts,indent=2))
 lease.verify_identity()
