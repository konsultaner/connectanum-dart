"""Own source-frozen command evidence, not capture or canonical admission.

Caller holds the official exclusive lease. Only fixed live factories may select
canonical/production recipes; fixture commands are labelled in every receipt.
A direct child status plus output-pipe EOF does not prove all descendants exited, SDK identity,
complete canonical validation, loader validity, or loaded role/native-image bytes.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import select
import stat
import subprocess
import sys
import tarfile
import time
import threading
from types import MappingProxyType


class ProducerError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise ProducerError('Python 3.11 or newer required before producer IO')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _regular_hash(path, maximum=1024**3, *, owners=None):
    owners={os.getuid()} if owners is None else owners
    path=Path(path)
    if not path.is_absolute() or path.resolve(strict=True)!=path:
        raise ProducerError('input path must be canonical without symlinks')
    before=path.stat(follow_symlinks=False)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
            raise ProducerError('input type/owner/mode/size differs')
        if identity(before)!=identity(info):raise ProducerError('input changed before read')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            h.update(part);count+=len(part)
            if count>maximum:raise ProducerError('input grew beyond bound')
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info):
            raise ProducerError('input changed during read')
        return h.hexdigest()
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('input close failed: '+repr(e))


def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))


def _write_json(path,value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode())
        f.flush();os.fsync(f.fileno())


VERSION_ARGS={'git':('--version',),'python3':('--version',),'bash':('--version',),
              'dart':('--version',),'cargo':('--version',),'rustc':('--version','--verbose')}
TOOL_FIELDS={'entry','target','sha256','version_prefix','entry_device','entry_inode','entry_mode',
             'entry_uid','entry_link','target_device','target_inode','target_mode','target_uid'}


def describe_tool(name,version_prefix,*,lookup_path=None):
    """Read-only intent preparation; executes no program and authenticates no image."""
    if name not in VERSION_ARGS or type(version_prefix) is not str or not 0<len(version_prefix)<=256 or '\0' in version_prefix or '\n' in version_prefix:
        raise ProducerError('invalid fixed tool/version declaration')
    entry=shutil.which(name,path=lookup_path)
    if entry is None or not Path(entry).is_absolute():raise ProducerError('tool PATH resolution missing or nonabsolute: '+name)
    entry=Path(entry);before=entry.lstat();target=entry.resolve(strict=True)
    if not (stat.S_ISREG(before.st_mode) or stat.S_ISLNK(before.st_mode)) or before.st_uid not in (0,os.getuid()):
        raise ProducerError('tool entry type/owner differs: '+name)
    info=target.stat()
    if not info.st_mode&0o111:raise ProducerError('tool target is not executable: '+name)
    digest=_regular_hash(target,maximum=512*1024**2,owners={0,os.getuid()})
    fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
    link=os.readlink(entry) if stat.S_ISLNK(before.st_mode) else None
    if fields(before)!=fields(entry.lstat()) or target!=entry.resolve(strict=True) or fields(info)!=fields(target.stat()):
        raise ProducerError('tool entry/target changed during observation: '+name)
    return {'entry':str(entry),'target':str(target),'sha256':digest,'version_prefix':version_prefix,
            'entry_device':before.st_dev,'entry_inode':before.st_ino,'entry_mode':before.st_mode,'entry_uid':before.st_uid,'entry_link':link,
            'target_device':info.st_dev,'target_inode':info.st_ino,'target_mode':info.st_mode,'target_uid':info.st_uid}


def _tool_table(value):
    if value is None:return MappingProxyType({})
    if type(value) is not dict or not 0<len(value)<=len(VERSION_ARGS):raise ProducerError('invalid tool table')
    result={}
    integers={'entry_device','entry_inode','entry_mode','entry_uid','target_device','target_inode','target_mode','target_uid'}
    for name,spec in value.items():
        if type(name) is not str or name not in VERSION_ARGS or type(spec) is not dict or set(spec)!=TOOL_FIELDS:
            raise ProducerError('invalid fixed tool snapshot schema')
        if any(type(spec[k]) is not int or spec[k]<0 for k in integers) or any(type(spec[k]) is not str or not spec[k] for k in ('entry','target','sha256','version_prefix')) or (spec['entry_link'] is not None and type(spec['entry_link']) is not str):
            raise ProducerError('invalid typed tool snapshot')
        if (not re.fullmatch('[0-9a-f]{64}',spec['sha256']) or not Path(spec['entry']).is_absolute() or not Path(spec['target']).is_absolute()
            or not 0<len(spec['version_prefix'])<=256 or '\0' in spec['version_prefix'] or '\n' in spec['version_prefix']):raise ProducerError('invalid tool digest/path/version declaration')
        result[name]=MappingProxyType(dict(spec))
    return MappingProxyType(result)


def _required_tools(value):
    if type(value) is not dict or set(value)!=set(VERSION_ARGS):
        raise ProducerError('live recipe requires all six declared tool snapshots')


LOCK_PATHS={'pub':'pubspec.lock','transport':'native/transport/Cargo.lock','bench':'native/bench/Cargo.lock'}
CANONICAL_RECIPES=[['bin/verify']]
PRODUCTION_RECIPES=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                    ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']]


def _required_context(kwargs):
    if (type(kwargs.get('census_id')) is not str or not re.fullmatch('[0-9a-f]{32}',kwargs['census_id'])
        or type(kwargs.get('expected_sdk')) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',kwargs['expected_sdk'])
        or type(kwargs.get('config_bindings')) is not dict or not {'server','client'}<=set(kwargs['config_bindings'])):
        raise ProducerError('live recipe needs pre-child census/SDK/config context')


def _read_json(path,expected):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NONBLOCK|os.O_NOFOLLOW)
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(2*1024**2+1)
        if len(data)>2*1024**2 or _sha(data)!=expected:raise ProducerError('sealed JSON size/digest differs')
        def pairs(values):
            out={}
            for key,value in values:
                if key in out:raise ProducerError('duplicate JSON key')
                out[key]=value
            return out
        def constant(value):raise ProducerError('nonfinite JSON constant')
        try:result=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('malformed sealed JSON') from e
        if type(result) is not dict:raise ProducerError('sealed JSON must be an object')
        return result
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('sealed JSON close failed: '+repr(e))


def _dart_sdk(line):
    match=re.match(r'^Dart SDK version: ([0-9]+\.[0-9]+\.[0-9]+) \(stable\)(?: |$)',line)
    if match is None:raise ProducerError('stable Dart SDK line required')
    return match[1]


def _read_bound_metadata(path,expected,maximum=32*1024**2):
    """Return only the bytes bound to this completed observation's snapshot."""
    if (type(expected) is not dict or set(expected)!={'size','sha256'}
        or type(expected['size']) is not int or not 0<=expected['size']<=maximum
        or type(expected['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',expected['sha256'])):
        raise ProducerError('invalid auxiliary metadata bound before IO')
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_uid,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022
            or before.st_size!=expected['size']):raise ProducerError('auxiliary metadata file differs')
        chunks=[];h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(65536,maximum+1-count))
            if not part:break
            chunks.append(part);count+=len(part);h.update(part)
            if count>expected['size']:raise ProducerError('auxiliary metadata grew beyond observed bytes')
        if (count!=expected['size'] or h.hexdigest()!=expected['sha256']
            or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False))):
            raise ProducerError('auxiliary metadata consumed bytes differ from observation')
        return b''.join(chunks)
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as error:
            if primary is None:raise
            primary.add_note('auxiliary metadata close failed: '+repr(error))


class AuxiliaryCommand:
    """Waitable direct child + two output pipes; never live admission.

    The owner registers this prepared object BEFORE start(). All actor handles
    stay here while pending. EOF proves no writer identity or descendant exit.
    """
    def __init__(self,*,directory,name,argv,cwd,environment,lease_check,stdout_max=1024**3,stderr_max=32*1024**2):
        if (type(name) is not str or not re.fullmatch('[a-z][a-z0-9-]{0,48}',name)
            or type(argv) is not list or not argv or any(type(x) is not str or not x or '\0' in x for x in argv)
            or type(environment) is not dict or any(type(k) is not str or type(v) is not str or '\0' in k+v for k,v in environment.items())
            or any(type(x) is not int or not 0<x<=16*1024**3 for x in (stdout_max,stderr_max))):
            raise ProducerError('invalid auxiliary command declaration')
        self.directory=Path(directory);self.cwd=Path(cwd)
        if self.directory.resolve(strict=True)!=self.directory or self.cwd.resolve(strict=True)!=self.cwd:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        self.name=name;self.argv=tuple(argv);self.environment=MappingProxyType(dict(environment));self.lease_check=lease_check
        self.started=False;self.pending=False;self.finished=False;self.process=None;self.result=None
        self.error=None;self.secondary_errors=[];self.failure_attempted=False;self.publication_attempted=False
        self.status=None;self.spawn_error=None;self.streams={}
        for role,maximum in [('stdout',stdout_max),('stderr',stderr_max)]:
            self.streams[role]={'path':self.directory/(name+'.'+role),'maximum':maximum,'log':None,'fd':None,'writer':None,
                'buffer':b'','hash':hashlib.sha256(),'bytes':0,'eof':False,'quarantined':False,'write_close_confirmed':False}
        self.intent={'scope':'auxiliary_command_intent_only','capture_ready':False,'argv':list(self.argv),'cwd':str(self.cwd),
            'environment_sha256':_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode()),
            'output_bounds':{'stdout':stdout_max,'stderr':stderr_max},'producer_sha256':_regular_hash(Path(__file__).resolve())}
        lease_check();_write_json(self.directory/(name+'-intent.json'),self.intent)
        self.intent_sha256=_regular_hash(self.directory/(name+'-intent.json'))

    def _defer(self,error):
        if self.error is None:self.error=repr(error)
        else:self.secondary_errors.append(repr(error))
        if not self.failure_attempted:
            self.failure_attempted=True
            try:_write_json(self.directory/(self.name+'-failure.json'),{'primary_error':self.error,'secondary_errors':self.secondary_errors,
                'returncode':self.status,'pending':self.pending,'capture_ready':False,
                'unwritten_base64':{k:base64.b64encode(s['buffer']).decode('ascii') for k,s in self.streams.items()}})
            except BaseException as secondary:error.add_note('auxiliary failure publication failed: '+repr(secondary))

    def _close_slot(self,stream,slot):
        fd=stream[slot];stream[slot]=None
        if fd is not None:
            try:os.close(fd)
            except BaseException as error:self._defer(error)
            else:return True
        return False

    def start(self):
        if self.started or self.finished:raise ProducerError('auxiliary start attempt is permanently terminal')
        self.started=True
        try:
            self.lease_check()
            sealed=_read_json(self.directory/(self.name+'-intent.json'),self.intent_sha256)
            if (sealed['argv']!=list(self.argv) or sealed['cwd']!=str(self.cwd)
                or sealed['environment_sha256']!=_sha(json.dumps(dict(self.environment),sort_keys=True,ensure_ascii=True).encode())
                or sealed['output_bounds']!={k:v['maximum'] for k,v in self.streams.items()}
                or sealed['producer_sha256']!=_regular_hash(Path(__file__).resolve())):
                raise ProducerError('auxiliary declared plan changed')
            _write_json(self.directory/(self.name+'-started.json'),{'intent_sha256':self.intent_sha256,'terminal':True})
            for stream in self.streams.values():
                stream['log']=stream['path'].open('xb',buffering=0)
                stream['fd'],stream['writer']=os.pipe()
                os.set_inheritable(stream['fd'],False);os.set_inheritable(stream['writer'],False)
                os.set_blocking(stream['fd'],False)
            self.process=subprocess.Popen(list(self.argv),cwd=self.cwd,env=dict(self.environment),stdin=subprocess.DEVNULL,
                stdout=self.streams['stdout']['writer'],stderr=self.streams['stderr']['writer'],close_fds=True)
            # Retain the actual owned process BEFORE fallible closure/publication.
            self.pending=True
        except BaseException as error:
            self.spawn_error=repr(error);self._defer(error)
            for stream in self.streams.values():
                self._close_slot(stream,'writer');self._close_slot(stream,'fd')
            return self._complete()
        for stream in self.streams.values():stream['write_close_confirmed']=self._close_slot(stream,'writer')
        try:_write_json(self.directory/(self.name+'-spawned.json'),{'pid':self.process.pid,'intent_sha256':self.intent_sha256})
        except BaseException as error:self._defer(error)
        return self

    def _observe_status(self):
        value=self.process.poll()
        if value is not None:self.status=value

    def _complete(self):
        # Only used with no spawned child, or natural status AND both pipe EOFs.
        self.pending=False;self.finished=True;output={}
        for role,stream in self.streams.items():
            log=stream['log'];stream['log']=None
            if log is not None:
                try:log.flush();os.fsync(log.fileno())
                except BaseException as error:self._defer(error)
                finally:
                    try:log.close()
                    except BaseException as error:self._defer(error)
            item={'eof':stream['eof'],'stream_bytes':stream['bytes'],'stream_sha256':stream['hash'].hexdigest(),
                'parent_write_close_confirmed':stream['write_close_confirmed'],'quarantined':stream['quarantined']}
            try:
                item['snapshot']=_file_snapshot(stream['path'],stream['maximum'])
                item['snapshot_matches_stream']=item['snapshot']=={'size':stream['bytes'],'sha256':stream['hash'].hexdigest()}
                if not item['snapshot_matches_stream']:raise ProducerError('auxiliary log bytes changed: '+role)
            except BaseException as error:self._defer(error)
            output[role]=item
        okay=(self.error is None and self.spawn_error is None and self.status==0
              and all(s['eof'] and s['write_close_confirmed'] for s in self.streams.values()))
        self.result={'kind':'auxiliary-command-observation-v1','scope':'owned_direct_child_and_two_output_streams_only',
            'capture_ready':False,'whole_descendant_exit_proven':False,'intent_sha256':self.intent_sha256,
            'argv':list(self.argv),'cwd':str(self.cwd),'pid':None if self.process is None else self.process.pid,
            'returncode':self.status,'spawn_error':self.spawn_error,'status':'success' if okay else 'failed',
            'primary_error':self.error,'secondary_errors':self.secondary_errors,'outputs':output}
        if self.status is not None and self.status!=0 and self.result['primary_error'] is None:self.result['primary_error']='auxiliary command nonzero or signal'
        self.publication_attempted=True
        try:_write_json(self.directory/(self.name+'-result.json'),self.result)
        except BaseException as error:
            self._defer(error);self.result['status']='failed';self.result['primary_error']=self.error
        return self.result

    def wait(self,timeout):
        if self.finished:raise ProducerError('auxiliary completion is permanently terminal')
        if not self.started:raise ProducerError('auxiliary command has not started')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded auxiliary wait required')
        try:self.lease_check()
        except BaseException as error:self._defer(error)
        deadline=time.monotonic()+timeout
        while True:
            try:self._observe_status()
            except BaseException as error:self._defer(error);return None
            if any(s['quarantined'] for s in self.streams.values()):return None
            for stream in self.streams.values():
                if stream['eof']:continue
                if stream['buffer']:
                    if stream['bytes']+len(stream['buffer'])>stream['maximum']:
                        stream['quarantined']=True;self._defer(ProducerError('auxiliary stream exceeds declared output bound'));return None
                    try:count=stream['log'].write(stream['buffer'])
                    except BaseException as error:
                        stream['quarantined']=True;self._defer(error);return None
                    if type(count) is not int or not 0<count<=len(stream['buffer']):
                        stream['quarantined']=True;self._defer(ProducerError('auxiliary write count uncertain'));return None
                    stream['hash'].update(stream['buffer'][:count]);stream['bytes']+=count;stream['buffer']=stream['buffer'][count:]
                    continue
                try:part=os.read(stream['fd'],65536)
                except (BlockingIOError,InterruptedError):continue
                except BaseException as error:self._defer(error);return None
                if part:stream['buffer']=part
                else:
                    stream['eof']=True;self._close_slot(stream,'fd')
            if all(s['eof'] for s in self.streams.values()) and self.status is not None:
                self.status=self.process.wait(timeout=0)
                return self._complete()
            remaining=deadline-time.monotonic()
            if remaining<=0:return None
            # Buffered bytes must be written before waiting for further readability.
            if any(s['buffer'] for s in self.streams.values()):continue
            readers=[s['fd'] for s in self.streams.values() if s['fd'] is not None]
            try:
                if readers:select.select(readers,[],[],min(remaining,.05))
                else:
                    try:self.status=self.process.wait(timeout=remaining)
                    except subprocess.TimeoutExpired:return None
            except BaseException as error:self._defer(error);return None


def _observe_auxiliary(owner,name,argv,stdout_max=1024**3):
    operation=AuxiliaryCommand(directory=owner.directory,name=name,argv=argv,cwd=owner.repo,
        environment=owner.environment,lease_check=owner.lease_check,stdout_max=stdout_max)
    # Owner must retain every operation before ANY actual child launch.
    owner.auxiliary_operations.append(operation)
    operation.start()
    result=operation.result
    while result is None:result=operation.wait(60)
    if result['status']!='success':raise ProducerError('auxiliary Git observation failed; owned status/raw streams retained: '+str(result['primary_error']))
    return result


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None,tools=None,census_id=None,expected_sdk=None,config_bindings=None,_preflight_owner=None):
        if _preflight_owner is not None:
            if type(_preflight_owner) is not _RetainedPreflightOwner:raise ProducerError('foreign preflight entry hook')
            _preflight_owner._register_producer(self)
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        if ((census_id is None)!=(expected_sdk is None) or (census_id is not None and
            (type(census_id) is not str or not re.fullmatch('[0-9a-f]{32}',census_id) or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)))):
            raise ProducerError('invalid pre-child census/SDK context')
        config_bindings={} if config_bindings is None else config_bindings
        if (type(config_bindings) is not dict or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}',k) or type(v) is not str or v not in inputs for k,v in config_bindings.items())
            or (config_bindings and (expected_sdk is None or not {'server','client'}<=set(config_bindings)))):
            raise ProducerError('unbound pre-child config context')
        self.census_id=census_id;self.expected_sdk=expected_sdk;self.config_bindings=MappingProxyType(dict(config_bindings))
        self.evidence_complete=False;self.receipt_attempted=False;self.intent_sha256=None;self.result_sha256=None;self.journal_sha256=None
        self.repo=Path(repo);self.directory=Path(run_dir)
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.tools=_tool_table(tools)
        self.task_kinds=tuple(('tool_version',name) for name in sorted(self.tools))+tuple(('recipe',None) for _ in commands)
        self.commands=tuple((self.tools[name]['entry'],*VERSION_ARGS[name]) for name in sorted(self.tools))+tuple(tuple(a) for a in commands)
        self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.environment={**os.environ,**self.env_delta};self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False;self.output_log=None;self.failure_attempted=False;self.auxiliary_operations=[]
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            _write_json(self.directory/'intent.json',{'kind':'build-preparation-intent-v1','source_commit':source_commit,'runtime_commit':runtime_commit,
                        'census_id':self.census_id,'expected_sdk':self.expected_sdk,'config_bindings':dict(self.config_bindings),
                        'expected_archive_sha256':expected_archive_sha256,'inputs':dict(self.inputs),'tools':{k:dict(v) for k,v in self.tools.items()},
                        'commands':[list(a) for a in self.commands],'task_kinds':self.task_kinds,'provenance':provenance,
                        'producer_file_sha256':_regular_hash(Path(__file__).resolve()),'environment_delta':self.env_delta})
            self.intent_sha256=_regular_hash(self.directory/'intent.json')
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self._defer_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        name=f'git-{index:03}';out=self.directory/(name+'.stdout')
        cmd=[self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv]
        result=_observe_auxiliary(self,name,cmd)
        stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
        if argv[0]=='archive':
            if _file_snapshot(out,1024**3)!=stdout:raise ProducerError('auxiliary archive output differs')
            data=None
        else:data=_read_bound_metadata(out,stdout)
        self._event('git_observation',argv=list(argv),returncode=result['returncode'],stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'],
            auxiliary_result_sha256=_regular_hash(self.directory/(name+'-result.json')))
        if argv[0]=='archive':return out
        return data

    def _source_guard(self,observe=None):
        observe=self._git if observe is None else observe
        self.lease_check()
        self._tool_guard()
        if observe('rev-parse','HEAD').decode().strip()!=self.source_commit:raise ProducerError('source HEAD differs')
        if observe('status','--porcelain','--untracked-files=normal'):raise ProducerError('source worktree is not clean')
        if observe('diff','--no-ext-diff','--no-textconv',self.runtime_commit,self.source_commit,'--','packages','native'):raise ProducerError('runtime source differs')

    def _make_archive(self):
        # git archive bytes are kept without extraction. Validate every blob and mode.
        raw_path=self._git('archive','--format=tar',self.source_commit)
        archive=self.directory/'source.tar'
        # Exclusive hard-link publication keeps original command bytes, no copy/overwrite.
        os.link(raw_path,archive,follow_symlinks=False)
        archive_hash=_regular_hash(archive)
        if archive_hash!=self.expected_archive_sha256:raise ProducerError('source archive differs from immutable expected digest')
        tree={}
        for entry in self._git('ls-tree','-rz',self.source_commit).split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,kind,object_id=meta.split(b' ')
            if kind!=b'blob':raise ProducerError('unsupported source tree entry')
            tree[os.fsdecode(name)]=(mode.decode(),object_id.decode())
        found=set()
        with tarfile.open(archive,'r:') as tar:
            for member in tar:
                if member.isdir():continue
                if member.name not in tree or member.name in found:raise ProducerError('archive has unknown or duplicate source entry')
                mode,object_id=tree[member.name]
                if member.issym() and mode=='120000':data=os.fsencode(member.linkname)
                elif member.isfile() and mode in ('100644','100755'):
                    if member.size>128*1024**2:raise ProducerError('source entry exceeds declared bound')
                    if bool(member.mode&0o111)!=(mode=='100755'):raise ProducerError('source archive executable mode differs')
                    data=tar.extractfile(member).read()
                else:raise ProducerError('source archive type differs')
                if hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=object_id:raise ProducerError('source archive blob differs')
                found.add(member.name)
        if found!=set(tree):raise ProducerError('source archive omits committed files')
        self.source_entries=len(found);self.source_archive_sha256=_regular_hash(archive)
        if self.source_archive_sha256!=archive_hash:raise ProducerError('archive changed during membership check')
        self._event('source_archive',sha256=self.source_archive_sha256,entries=self.source_entries)


    def _tool_guard(self):
        for name,expected in self.tools.items():
            observed=describe_tool(name,expected['version_prefix'],lookup_path=self.environment.get('PATH'))
            if observed!=dict(expected):raise ProducerError('tool entry/target identity differs: '+name)

    def _version_guard(self):
        record=self.records[-1]
        if record['kind']!='tool_version':return
        if record['log_bytes']>65536:raise ProducerError('tool version output exceeds declared bound')
        path=self.directory/f'command-{len(self.records)-1:03}.log'
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            with os.fdopen(fd,'rb',closefd=False) as reader:data=reader.read(65537)
            if len(data)!=record['log_bytes'] or _sha(data)!=record['log_sha256']:raise ProducerError('tool version bytes changed')
            text=data.decode('utf-8')
            prefix=self.tools[record['tool']]['version_prefix']
            line=text.splitlines()[0] if text else ''
            match=line.startswith(prefix)
            suffix=line[len(prefix):] if match else ''
            if not text or '\0' in text or not text.endswith('\n') or not match or (not prefix[-1].isspace() and suffix and not suffix[0].isspace()):
                raise ProducerError('tool version differs: '+record['tool'])
            record['version_line']=text.splitlines()[0]
            if record['tool']=='dart' and self.expected_sdk is not None and _dart_sdk(record['version_line'])!=self.expected_sdk:
                raise ProducerError('reported Dart SDK differs from pre-child context')
        finally:
            primary=sys.exception()
            try:os.close(fd)
            except OSError as error:
                if primary is None:raise
                primary.add_note('version descriptor close failed: '+repr(error))


    def _config_guard(self):
        for relative in set(self.config_bindings.values()):
            value=_read_json(self.repo/relative,self.inputs[relative])
            packages=value.get('packages')
            if (type(value.get('configVersion')) is not int or value['configVersion']!=2
                or value.get('generator')!='pub' or value.get('generatorVersion')!=self.expected_sdk
                or type(packages) is not list or not packages):raise ProducerError('config generator/SDK differs')
            names=set()
            for entry in packages:
                if (type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names
                    or type(entry.get('rootUri')) is not str or not entry['rootUri']
                    or type(entry.get('packageUri')) is not str):raise ProducerError('invalid generated package config entry')
                names.add(entry['name'])

    def _input_guard(self):
        self.lease_check()
        for relative,expected in self.inputs.items():
            if _regular_hash(self.repo/relative)!=expected:raise ProducerError('input identity/digest differs: '+relative)
        if self.config_bindings:self._config_guard()

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index])
        self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
        self.log=(self.directory/f'command-{index:03}.log').open('xb',buffering=0)
        self.output_log=self.log;self.output_fd=None;self.output_buffer=b'';self.output_write_uncertain=False
        self.output_hash=hashlib.sha256();self.output_bytes=0
        kind,tool=self.task_kinds[index]
        record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),
                'returncode':None,'spawn_error':None,'output_eof':False,'log_complete':False,
                'whole_descendant_exit_proven':False,'parent_output_write_close_confirmed':False}
        self.records.append(record)
        writer=None
        try:
            self.output_fd,writer=os.pipe()
            os.set_inheritable(self.output_fd,False);os.set_inheritable(writer,False)
            os.set_blocking(self.output_fd,False)
            self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=writer,
                stderr=subprocess.STDOUT,close_fds=True,env=self.environment)
        except OSError as error:
            record['spawn_error']=repr(error)
            for fd in (writer,self.output_fd):
                if fd is not None:
                    try:os.close(fd)
                    except OSError as secondary:error.add_note('unspawned output close failed: '+repr(secondary))
            self.output_fd=None;record['output_eof']=None
            self._end_command(None)
            self._finish('failed','command spawn failed: '+repr(error))
        else:
            # Own the actual child before any fallible close/journal operation.
            record['pid']=self.process.pid;self.pending=True
            try:
                fd=writer;writer=None
                os.close(fd)
            except OSError as error:
                record['parent_output_write_close_error']=repr(error)
                self._defer_failure(error)
            else:record['parent_output_write_close_confirmed']=True
            self._event('command_spawned',index=index,pid=self.process.pid)

    def _observe_direct_status(self):
        status=self.process.poll()
        if status is not None and self.records[-1]['returncode'] is None:
            self.records[-1]['returncode']=status
            self.records[-1]['direct_exit_observed_ns']=time.time_ns()
        return status

    def _drain_output(self,deadline):
        """Continue one pipe, bounded by the caller's remaining wait budget.

        EOF authenticates no writer or descendant identity. A read error fails the
        run even if later continuation reaches EOF. An ambiguous file-write error
        quarantines the original read FD and bounded unwritten bytes, without
        replaying bytes, closing a live writer channel, or launching another child.
        """
        record=self.records[-1]
        while True:
            self._observe_direct_status()
            if self.output_write_uncertain:return False
            if self.output_buffer:
                try:count=self.output_log.write(self.output_buffer)
                except BaseException:
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise
                if type(count) is not int or not 0<count<=len(self.output_buffer):
                    self.output_write_uncertain=True
                    record['output_write_uncertain']=True
                    raise ProducerError('output log write count is uncertain')
                self.output_hash.update(self.output_buffer[:count]);self.output_bytes+=count
                self.output_buffer=self.output_buffer[count:]
                if time.monotonic()>=deadline:return False
                continue
            if record['output_eof'] is True:return True
            try:part=os.read(self.output_fd,65536)
            except InterruptedError:
                if time.monotonic()>=deadline:return False
                continue
            except BlockingIOError:
                remaining=deadline-time.monotonic()
                if remaining<=0:return False
                select.select([self.output_fd],[],[],min(remaining,.05))
                continue
            except BaseException as error:
                record.setdefault('output_read_errors',[]).append(repr(error))
                raise
            if part:
                self.output_buffer=part
                continue
            record['output_eof']=True;record['output_eof_observed_ns']=time.time_ns()
            fd=self.output_fd;self.output_fd=None
            try:os.close(fd)
            except OSError as error:
                record['output_read_close_error']=repr(error)
                raise
            return True

    def _end_command(self,status):
        self.pending=False
        record=self.records[-1];record['returncode']=status;record['ended_ns']=time.time_ns()
        log=self.log;self.log=None;self.output_log=None
        log.flush();os.fsync(log.fileno());log.close()
        data=_file_snapshot(self.directory/f'command-{len(self.records)-1:03}.log')
        record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
        if record['spawn_error'] is None:
            if (record['output_eof'] is not True or self.output_fd is not None or self.output_buffer
                or data!={'size':self.output_bytes,'sha256':self.output_hash.hexdigest()}):
                raise ProducerError('output pipe bytes and final log snapshot differ')
            record['log_complete']=not self.output_write_uncertain and 'output_read_errors' not in record
        self._event('command_end',index=len(self.records)-1,**record)

    def _finish(self,status,error=None):
        self.finished=True
        output_hashes={}
        if status=='success':
            for role,path in self.outputs.items():
                if '*' in str(path):
                    matches=sorted(Path(path).parent.glob(Path(path).name))
                    if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                    path=matches[0]
                output_hashes[role]={'path':str(path),'sha256':_regular_hash(Path(path))}
        self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                     'scope':'owned_direct_child_wait_output_pipe_eof_and_file_snapshots_only','capture_ready':False,
                     'status':status,'error':error,'census_id':self.census_id,'expected_sdk':self.expected_sdk,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                     'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                     'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance,'tools':{k:dict(v) for k,v in self.tools.items()}}
        _write_json(self.directory/'result.json',self.result)
        self.result_sha256=_regular_hash(self.directory/'result.json')
        self._event('finished',status=status,error=error)
        events=self.events;self.events=None;events.close()
        self.journal_sha256=_regular_hash(self.directory/'journal.jsonl');self.evidence_complete=True
        return self.result

    def _defer_failure(self,error):
        if self.deferred_error is None:self.deferred_error=repr(error)
        else:self.records[-1].setdefault('secondary_errors',[]).append(repr(error))
        self._preserve_failure(error)

    def _preserve_failure(self,error):
        # One terminal publication attempt. Later errors remain in the owned
        # record/final failed result, never overwrite the first partial artifact.
        if not self.failure_attempted:
            self.failure_attempted=True
            try:_write_json(self.directory/'failure.json',{'error':self.deferred_error or repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
                 'output_write_uncertain':self.output_write_uncertain,
                 'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if self.output_write_uncertain else None})
            except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))
        if not self.pending and self.events is not None:
            events=self.events;self.events=None
            try:events.close()
            except BaseException as secondary:error.add_note('journal close failed: '+repr(secondary))

    def wait(self,timeout):
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        self.lease_check()
        deadline=time.monotonic()+timeout
        try:
            while True:
                if not self._drain_output(deadline):return None
                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._version_guard();self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            if self.pending:
                self._defer_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise


def start_fixture(**kwargs):
    return CommandProducer(**kwargs,provenance='fixture')


def _live_inputs(inputs):
    required={'pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'}
    if type(inputs) is not dict or not required<set(inputs) or any(k not in required and not k.endswith('/.dart_tool/package_config.json') and k!='.dart_tool/package_config.json' for k in inputs):
        raise ProducerError('actual three locks and generated package configs required')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR'):
        if os.environ.get(key):raise ProducerError('undeclared build environment: '+key)


def _canonical_native_path(repo):
    return Path(repo)/'native/transport/target/ffi-test/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')


def _validate_owned_output_path(run,phase,role,path):
    """Location predicate only; this does not validate bytes or admit a capture."""
    if phase=='canonical' and role=='canonical_native':
        if path!=_canonical_native_path(run.repo):raise ProducerError('canonical native outside own ffi-test output')
    elif phase=='execution' and role=='static_rlib':
        if path.parent!=run.directory/'target/release/deps' or not re.fullmatch('libct_core-[A-Za-z0-9_]+\\.rlib',path.name):raise ProducerError('RLIB outside own production target')
    elif phase=='execution' and role in ('native_elf','driver_elf'):
        if path!=run.directory/'target/release'/('libct_ffi.so' if role=='native_elf' else 'http_stream'):
            raise ProducerError('production artifact outside own target')
    else:raise ProducerError('own output phase/role differs')


def start_canonical(**kwargs):
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    if os.environ.get('CONNECTANUM_CI_NATIVE_DIR'):raise ProducerError('undeclared canonical CI artifact reuse')
    native=_canonical_native_path(kwargs['repo'])
    configured=os.environ.get('CONNECTANUM_NATIVE_LIB')
    if configured and Path(configured).resolve()!=native:raise ProducerError('canonical native path is outside own declared ffi-test output')
    return CommandProducer(**kwargs,commands=[['bin/verify']],provenance='canonical_recipe',outputs={'canonical_native':native})


def start_production(**kwargs):
    if sys.platform!='linux':raise ProducerError('production ELF recipe requires actual Linux')
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    target=Path(kwargs['run_dir'])/'target'
    return CommandProducer(**kwargs,provenance='production_recipe',env_delta={'CARGO_TARGET_DIR':str(target)},
        commands=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                  ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],
        outputs={'native_elf':target/'release/libct_ffi.so','driver_elf':target/'release/http_stream',
                 'static_rlib':target/'release/deps/libct_core-*.rlib'})



def _receipt_source_audit(run):
    path=run.directory/'receipt-source-audit.jsonl'
    audit=path.open('xb');index=0
    try:
        def observe(*argv):
            nonlocal index
            number=index;index+=1
            out=run.directory/f'receipt-git-{number:03}.stdout';err=run.directory/f'receipt-git-{number:03}.stderr'
            cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
            result=_observe_auxiliary(run,f'receipt-git-{number:03}',cmd,32*1024**2)
            stdout=result['outputs']['stdout']['snapshot'];stderr=result['outputs']['stderr']['snapshot']
            data=_read_bound_metadata(out,stdout)
            record={'argv':cmd,'returncode':result['returncode'],'stdout':stdout,'stderr':stderr,
                'auxiliary_result_sha256':_regular_hash(run.directory/f'receipt-git-{number:03}-result.json')}
            audit.write((json.dumps(record,sort_keys=True)+'\n').encode());audit.flush();os.fsync(audit.fileno())
            return data
        run._source_guard(observe)
    finally:
        primary=sys.exception()
        try:audit.close()
        except OSError as e:
            if primary is None:raise
            primary.add_note('receipt source audit close failed: '+repr(e))
    return _regular_hash(path)


def _emit(run,phase,fixture):
    if type(run) is not CommandProducer or phase not in ('canonical','execution'):
        raise ProducerError('owned producer and valid phase required')
    if run.pending or not run.finished or not run.evidence_complete or run.result['status']!='success':
        raise ProducerError('successful complete owned producer required')
    if fixture:
        if run.provenance!='fixture':raise ProducerError('fixture emitter only accepts fixture provenance')
    elif run.provenance!=('canonical_recipe' if phase=='canonical' else 'production_recipe'):
        raise ProducerError('live receipt cannot adopt fixture or foreign producer provenance')
    if run.receipt_attempted:raise ProducerError('receipt attempt is permanently terminal')
    run.receipt_attempted=True
    try:
        _write_json(run.directory/'receipt-attempt.json',{'census_id':run.census_id,'phase':phase,'fixture':fixture,'terminal':True})
        if run.census_id is None or run.expected_sdk is None or not {'server','client'}<=set(run.config_bindings):
            raise ProducerError('receipt context was not declared before child')
        intent=_read_json(run.directory/'intent.json',run.intent_sha256)
        sealed=_read_json(run.directory/'result.json',run.result_sha256)
        if (intent['census_id']!=run.census_id or intent['expected_sdk']!=run.expected_sdk
            or intent['config_bindings']!=dict(run.config_bindings) or intent['inputs']!=dict(run.inputs)
            or intent['source_commit']!=run.source_commit or intent['runtime_commit']!=run.runtime_commit
            or intent['expected_archive_sha256']!=run.source_archive_sha256 or sealed!=run.result
            or intent['provenance']!=run.provenance or sealed['provenance']!=run.provenance
            or sealed['kind']!=('fixture-command-evidence-v1' if fixture else 'own-command-evidence-v1')):
            raise ProducerError('pre-child receipt context changed')
        if _regular_hash(run.directory/'journal.jsonl')!=run.journal_sha256:raise ProducerError('sealed journal changed')
        source_audit_sha256=_receipt_source_audit(run);run._input_guard()
        if _regular_hash(run.directory/'source.tar')!=run.source_archive_sha256:raise ProducerError('sealed archive changed')
        if set(run.tools)!=set(VERSION_ARGS) or len(sealed['commands'])!=len(run.commands):raise ProducerError('six probes and all recipes required')
        recipes=[];dart=None
        for index,record in enumerate(sealed['commands']):
            if (record['argv']!=list(run.commands[index]) or (record['kind'],record['tool'])!=run.task_kinds[index]
                or record['returncode']!=0 or record['spawn_error'] is not None
                or record.get('output_eof') is not True or record.get('log_complete') is not True
                or record.get('parent_output_write_close_confirmed') is not True):raise ProducerError('command phase/argv/status/output completion differs')
            log=_file_snapshot(run.directory/f'command-{index:03}.log')
            if log!={'size':record['log_bytes'],'sha256':record['log_sha256']}:raise ProducerError('command log changed')
            if record['kind']=='recipe':recipes.append({'argv':record['argv'],'exit':record['returncode']})
            elif record['tool']=='dart':dart=_dart_sdk(record['version_line'])
        if dart!=run.expected_sdk:raise ProducerError('actual reported SDK differs')
        if not fixture and [r['argv'] for r in recipes]!=(CANONICAL_RECIPES if phase=='canonical' else PRODUCTION_RECIPES):
            raise ProducerError('live phase recipe differs')
        expected_roles={'canonical_native'} if phase=='canonical' else {'native_elf','driver_elf','static_rlib'}
        if set(sealed['outputs'])!=expected_roles:raise ProducerError('own output roles differ')
        for role,entry in sealed['outputs'].items():
            path=Path(entry['path'])
            if not fixture:_validate_owned_output_path(run,phase,role,path)
            if _regular_hash(path)!=entry['sha256']:raise ProducerError('own output bytes changed')
        complete=run.directory/'complete-command.log'
        with complete.open('xb') as out:
            for index,record in enumerate(sealed['commands']):
                fd=os.open(run.directory/f'command-{index:03}.log',os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
                try:
                    h=hashlib.sha256();count=0
                    while True:
                        part=os.read(fd,1024**2)
                        if not part:break
                        count+=len(part)
                        if count>record['log_bytes']:raise ProducerError('command log grew during copy')
                        h.update(part);out.write(part)
                    if count!=record['log_bytes'] or h.hexdigest()!=record['log_sha256']:raise ProducerError('command bytes changed during copy')
                finally:
                    primary=sys.exception()
                    try:os.close(fd)
                    except OSError as e:
                        if primary is None:raise
                        primary.add_note('command log close failed: '+repr(e))
            out.flush();os.fsync(out.fileno())
        common={'census_id':run.census_id,'source_commit':run.source_commit,'runtime_commit':run.runtime_commit,
                'source_archive_sha256':run.source_archive_sha256,'sdk':dart,'log_sha256':_regular_hash(complete,maximum=16*1024**3),
                'lock_hashes':{k:run.inputs[p] for k,p in LOCK_PATHS.items()},
                'package_configs':{k:run.inputs[p] for k,p in run.config_bindings.items()},'commands':recipes}
        receipt={'kind':('fixture-' if fixture else 'own-')+('canonical-v1' if phase=='canonical' else 'production-v1'),**common}
        if phase=='canonical':receipt['native_sha256']=sealed['outputs']['canonical_native']['sha256']
        else:receipt.update(outputs={k:v['sha256'] for k,v in sealed['outputs'].items()},features=[])
        _write_json(run.directory/'input-receipt.json',receipt)
        binding={'scope':'command-produced links only; independent canonical breadth/descendant/SDK-image/root admission still required',
                 'capture_ready':False,'fixture':fixture,'census_id':run.census_id,'intent_sha256':run.intent_sha256,
                 'result_sha256':run.result_sha256,'journal_sha256':run.journal_sha256,'source_audit_sha256':source_audit_sha256,'receipt_sha256':_regular_hash(run.directory/'input-receipt.json'),
                 'log_sha256':receipt['log_sha256']}
        _write_json(run.directory/'receipt-binding.json',binding)
        return receipt
    except BaseException as e:
        try:_write_json(run.directory/'receipt-failure.json',{'primary_error':repr(e),'terminal':True})
        except BaseException as secondary:e.add_note('receipt failure publication failed: '+repr(secondary))
        raise


def emit_receipt(run):
    if (type(run) is not CommandProducer or run.provenance not in ('canonical_recipe','production_recipe')
        or type(run.result) is not dict or run.result.get('kind')!='own-command-evidence-v1' or run.result.get('provenance')!=run.provenance):
        raise ProducerError('live receipt requires actual live-factory provenance')
    return _emit(run,'canonical' if run.provenance=='canonical_recipe' else 'execution',False)


def emit_fixture_receipt(run,phase):
    return _emit(run,phase,True)


# Separate SDK-method observer only. Never injected into WAMP/benchmark workers.
DART_PACKAGE_PROBE_SOURCE = r"""import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

Future<void> main(List<String> args) async {
  if (args.length != 1 || !RegExp(r'^[0-9a-f]{32}$').hasMatch(args.single)) {
    stderr.writeln('one declared nonce required');
    exitCode = 64;
    return;
  }
  final missingName = '__native_perf_absent_${args.single}';
  final active = await Isolate.packageConfig;
  String? bytesBase64;
  final mappings = <Map<String, Object?>>[];
  if (active != null) {
    if (active.scheme != 'file') throw StateError('non-file active config unsupported');
    final file = File.fromUri(active);
    if (file.lengthSync() > 2 * 1024 * 1024) throw StateError('active config too large');
    final bytes = file.readAsBytesSync();
    if (bytes.length > 2 * 1024 * 1024) throw StateError('active config grew');
    bytesBase64 = base64Encode(bytes);
    final config = jsonDecode(utf8.decode(bytes));
    if (config is! Map || config['packages'] is! List) throw StateError('config shape');
    final packages = config['packages'] as List;
    if (packages.length > 1024) throw StateError('too many packages');
    for (final entry in packages) {
      if (entry is! Map || entry['name'] is! String) throw StateError('package name');
      final name = entry['name'] as String;
      final resolved = await Isolate.resolvePackageUri(Uri.parse('package:$name/'));
      mappings.add({'name': name, 'uri': resolved?.toString()});
    }
  }
  final missing = await Isolate.resolvePackageUri(Uri.parse('package:$missingName/'));
  stdout.writeln(jsonEncode({
    'kind': 'dart-package-config-observation-v1',
    'script': Platform.script.toString(),
    'sdk': Platform.version,
    'config_uri': active?.toString(),
    'config_b64': bytesBase64,
    'mappings': mappings,
    'missing_name': missingName,
    'missing_uri': missing?.toString(),
  }));
}
"""


def validate_package_observation(value,*,expected_sdk,expected_script_uri,expected_config_uri,expected_config_bytes,nonce):
    """Validate helper-only observations, not compiled/loaded-role provenance."""
    import base64
    from urllib.parse import urlsplit
    keys={'kind','script','sdk','config_uri','config_b64','mappings','missing_name','missing_uri'}
    if (type(value) is not dict or set(value)!=keys or value['kind']!='dart-package-config-observation-v1'
        or type(nonce) is not str or not re.fullmatch('[0-9a-f]{32}',nonce)
        or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)
        or type(expected_script_uri) is not str or not expected_script_uri.startswith('file:')
        or type(value['sdk']) is not str or len(value['sdk'])>4096 or value['script']!=expected_script_uri
        or value['missing_name']!='__native_perf_absent_'+nonce or value['missing_uri'] is not None
        or type(value['mappings']) is not list or len(value['mappings'])>1024):
        raise ProducerError('invalid package observation schema/context')
    if _dart_sdk('Dart SDK version: '+value['sdk'])!=expected_sdk:raise ProducerError('package observer SDK differs')
    if expected_config_bytes is None:
        if expected_config_uri is not None or value['config_uri'] is not None or value['config_b64'] is not None or value['mappings']:
            raise ProducerError('null-config negative differs')
        raw=None;names=[]
    else:
        if (type(expected_config_bytes) is not bytes or not 0<len(expected_config_bytes)<=2*1024**2
            or type(expected_config_uri) is not str or not expected_config_uri.startswith('file:')
            or value['config_uri']!=expected_config_uri or type(value['config_b64']) is not str):raise ProducerError('package config context differs')
        if len(value['config_b64'])!=4*((len(expected_config_bytes)+2)//3):raise ProducerError('package encoding length differs before decoder')
        try:raw=base64.b64decode(value['config_b64'],validate=True)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config encoding') from e
        if raw!=expected_config_bytes:raise ProducerError('exact package config bytes differ')
        def pairs(values):
            out={}
            for key,entry in values:
                if key in out:raise ProducerError('duplicate package config JSON key')
                out[key]=entry
            return out
        def constant(entry):raise ProducerError('nonfinite package config JSON')
        try:config=json.loads(raw,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config JSON') from e
        if (type(config) is not dict or type(config.get('configVersion')) is not int or config['configVersion']!=2
            or config.get('generatorVersion')!=expected_sdk or type(config.get('packages')) is not list
            or not 0<len(config['packages'])<=1024):raise ProducerError('package config schema/SDK differs')
        names=[]
        for entry in config['packages']:
            if type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names:
                raise ProducerError('package config has duplicate/invalid names')
            names.append(entry['name'])
        if value['missing_name'] in names:raise ProducerError('absent query name is in declared config')
    if len(names)!=len(value['mappings']):raise ProducerError('package mapping inventory differs')
    mappings=[];other=0
    for name,entry in zip(names,value['mappings']):
        if type(entry) is not dict or set(entry)!= {'name','uri'} or entry['name']!=name:
            raise ProducerError('package mapping order/entry differs')
        uri=entry['uri']
        if uri is not None:
            if type(uri) is not str or not 0<len(uri)<=16384 or any(c in uri for c in '\0\r\n') or re.search(r'%(?![0-9a-fA-F]{2})',uri):
                raise ProducerError('invalid resolved package URI')
            try:scheme=urlsplit(uri).scheme
            except ValueError as e:raise ProducerError('malformed resolved URI') from e
            if not scheme or scheme=='package':raise ProducerError('package URI was not resolved')
        else:scheme=None
        if scheme!='file':other+=1
        mappings.append((name,uri))
    return {'scope':'helper_package_config_observation_only','capture_ready':False,'config_sha256':None if raw is None else _sha(raw),
            'package_count':len(names),'mappings':tuple(mappings),'other_or_null':other,'sdk':value['sdk'],'config_uri':value['config_uri']}


# These objects retain only this process's OWN preparation calls. They are not
# admission capabilities, descendant census, or physical lease retention.
_PREFLIGHT_OWNERS={}
_PREFLIGHT_OWNER_LIMIT=64
_PREFLIGHT_OWNERS_LOCK=threading.Lock()


def _preflight_timeout(value):
    if type(value) not in (int,float) or not 0<=value<=60:
        raise ProducerError('bounded preflight observation/wait required')
    return value


def _copy_preflight_kwargs(kwargs):
    if '_preflight_owner' in kwargs or not callable(kwargs.get('lease_check')):
        raise ProducerError('private owner hook or missing lease callback')
    budget=[4096]
    def copy(value,depth=0):
        budget[0]-=1
        if budget[0]<0 or depth>24:raise ProducerError('preflight declaration exceeds copy bound')
        if value is None or type(value) in (bool,int,float):return value
        if type(value) is str:
            if len(value)>1024**2:raise ProducerError('preflight string exceeds bound')
            return value
        if type(value) is type(Path()):return value
        if type(value) is dict:
            if any(type(k) is not str for k in value):raise ProducerError('preflight declaration keys must be strings')
            return {k:copy(v,depth+1) for k,v in value.items()}
        if type(value) in (list,tuple):
            items=[copy(v,depth+1) for v in value]
            return items if type(value) is list else tuple(items)
        raise ProducerError('unsupported preflight declaration value')
    return {k:(v if k=='lease_check' else copy(v)) for k,v in kwargs.items()}


class _RetainedPreflightOwner:
    """Serialized phase calls; caller keeps the official EX lease throughout."""

    def __init__(self,kind,owner_id,kwargs):
        self.kind=kind;self.owner_id=owner_id;self._kwargs=kwargs
        self._operation=None;self._initialized=False;self._pending=None;self._finished=None
        self._lock=threading.Lock();self._event=threading.Event();self._thread=None
        self._busy=False;self._call_done=False;self._action=None;self._index=0
        self._state='reserved';self._failed=False;self._first_error=None;self._first_error_object=None
        self._owner_emit_attempted=False;self._last_result=None
        self._workers=[];self._joined_workers=0
        self._partial_auxiliaries=None;self._auxiliary_views={};self._auxiliary_index=None
        self._auxiliary_quarantined=False;self._auxiliary_ledger_check_matched=None
        self._partial_command=None;self._command_quarantined=False;self._command_wait_status=None
        self._command_view=MappingProxyType(dict(scope='retained_command_observation_only',observed=False,
            quarantined=False,terminal_observed=False,direct_status=None,natural_wait_observed=False,pid=None))
        self._snapshot=self._snapshot_locked()

    def _snapshot_locked(self):
        return MappingProxyType(dict(scope='retained_preflight_call_only',
            owner_id=self.owner_id,call_index=self._index,action=self._action,
            call_state=self._state,call_done=self._call_done,failed=self._failed,
            first_error=self._first_error,retained_operation=self._operation is not None,
            initialized=self._initialized,producer_pending=self._pending,
            producer_finished=self._finished,owner_emit_attempted=self._owner_emit_attempted,
            worker_joined=None if not self._workers else self._workers[-1]['worker_joined'],
            worker_start_settled=None if not self._workers else self._workers[-1]['start_settled'],
            all_workers_joined=bool(self._workers) and self._joined_workers==len(self._workers),
            auxiliary_index=self._auxiliary_index,
            auxiliary_ledger_check_matched=self._auxiliary_ledger_check_matched,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))

    def _register_producer(self,operation):
        with self._lock:
            with _PREFLIGHT_OWNERS_LOCK:registered=_PREFLIGHT_OWNERS.get(self.owner_id) is self
            if (threading.current_thread() is not self._thread or self._action!='construct'
                or self._operation is not None or type(operation) is not CommandProducer or not registered):
                raise ProducerError('foreign or repeated preflight constructor registration')
            self._operation=operation
            self._snapshot=self._snapshot_locked()

    def _error_locked(self,error):
        self._failed=True
        if self._first_error is None:
            self._first_error=type(error).__name__;self._first_error_object=error

    def _schedule(self,action,value=None):
        with self._lock:
            if self._busy:raise ProducerError('preflight phase already running or quarantined')
            if self._workers and (not self._workers[-1]['worker_joined'] or not self._workers[-1]['start_settled']):
                raise ProducerError('previous exact preflight worker has not joined with settled start')
            if action=='construct':
                if self._index:raise ProducerError('constructor attempt is permanently terminal')
            elif action=='command_wait':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._command_quarantined
                    or self._command_view['terminal_observed']):
                    raise ProducerError('partial command continuation not eligible')
            elif action=='auxiliary_wait':
                if (self._initialized or not self._failed or self._operation is None
                    or self._owner_emit_attempted or self._auxiliary_quarantined):
                    raise ProducerError('partial auxiliary continuation not eligible')
                cached=self._auxiliary_views.get(value[0])
                if cached is not None and cached['terminal_result_observed']:
                    raise ProducerError('auxiliary wait is permanently terminal')
            elif (not self._initialized or self._owner_emit_attempted
                  or (action=='wait' and (self._finished or (self._failed and self._pending is not True)))
                  or (action=='emit' and self._failed)):
                raise ProducerError('preflight continuation not eligible; exact owner retained')
            if action=='emit':self._owner_emit_attempted=True
            self._index+=1;self._action=action;self._busy=True;self._call_done=False;self._state='running'
            self._event=threading.Event()
            record=dict(call_index=self._index,action=action,thread_created=False,
                start_attempted=False,start_returned=False,start_settled=False,
                worker_entered=False,call_done=False,worker_joined=False,join_error=None,call_error=None,
                auxiliary_observation_error=None,_thread=None,_join_error_object=None,_call_error_object=None,
                _auxiliary_observation_error_object=None)
            self._workers.append(record)
            try:thread=threading.Thread(target=self._work,args=(action,value,self._event,record),daemon=False)
            except BaseException as error:
                self._thread=None;self._state='start_uncertain';self._error_locked(error)
                record['start_settled']=True
                self._snapshot=self._snapshot_locked();return self
            self._thread=thread;record['_thread']=thread;record['thread_created']=True
            record['start_attempted']=True;self._snapshot=self._snapshot_locked()
        try:thread.start()
        except BaseException as error:
            with self._lock:
                record['start_settled']=True;self._error_locked(error)
                if not self._call_done:self._state='start_uncertain'
                self._snapshot=self._snapshot_locked()
                # Do not set completion or start again: the actual worker may exist.
        else:
            with self._lock:
                record['start_returned']=True;record['start_settled']=True
                self._snapshot=self._snapshot_locked()
        return self

    def _work(self,action,value,event,record):
        with self._lock:
            record['worker_entered']=True
            self._snapshot=self._snapshot_locked()
        error=None;result=None
        try:
            if action=='construct':
                factory={'fixture':start_fixture,'canonical':start_canonical,'production':start_production}[self.kind]
                result=factory(**self._kwargs,_preflight_owner=self)
                if result is not self._operation:raise ProducerError('factory did not return registered exact producer')
            elif action=='wait':result=self._operation.wait(value)
            elif action=='auxiliary_wait':result=self._wait_partial_auxiliary(*value)
            elif action=='command_wait':result=self._wait_partial_command(value)
            elif self.kind=='fixture':result=emit_fixture_receipt(self._operation,value)
            else:
                # The own emitter derives its phase from producer provenance.
                result=emit_receipt(self._operation)
        except BaseException as caught:error=caught
        with self._lock:
            if action=='construct' and error is None:self._initialized=True
            if self._initialized:
                # Only the serialized worker reads producer state after the call.
                self._pending=self._operation.pending;self._finished=self._operation.finished
            if error is not None:
                self._error_locked(error);record['call_error']=type(error).__name__;record['_call_error_object']=error
            self._last_result=result;self._call_done=True;self._busy=False;record['call_done']=True
            self._state='raised' if error is not None else 'returned'
            self._snapshot=self._snapshot_locked()
        event.set()

    def observe(self,timeout=0):
        timeout=_preflight_timeout(timeout);deadline=time.monotonic()+timeout
        with self._lock:
            event=self._event;record=self._workers[-1] if self._workers else None
            thread=None if record is None else record['_thread']
        event.wait(timeout)
        # Keep the exact handle until a real join succeeds. Call/event completion
        # alone cannot release a worker or authorize another producer phase.
        if thread is not None and thread is not threading.current_thread() and thread.ident is not None:
            try:
                thread.join(max(0,deadline-time.monotonic()))
                joined=not thread.is_alive()
            except BaseException as error:
                with self._lock:
                    if record['join_error'] is None:
                        record['join_error']=type(error).__name__;record['_join_error_object']=error
                    self._snapshot=self._snapshot_locked()
            else:
                with self._lock:
                    if joined and not record['worker_joined']:
                        record['worker_joined']=True;self._joined_workers+=1
                        record['_thread']=None
                    self._snapshot=self._snapshot_locked()
        with self._lock:return self._snapshot

    def worker_lifecycle(self):
        """Frozen call records, with no producer, Thread, FD or exception objects."""
        with self._lock:
            return tuple(MappingProxyType({key:value for key,value in record.items() if not key.startswith('_')})
                for record in self._workers)


    def _partial_auxiliary_ledger(self):
        if threading.current_thread() is not self._thread or type(self._operation) is not CommandProducer:
            raise ProducerError('partial auxiliary inspection requires the retained worker')
        data=self._operation.__dict__
        if (not {'pending','process','finished','auxiliary_operations'}<=data.keys()
            or data['pending'] is not False or data['process'] is not None or data['finished'] is not True):
            raise ProducerError('recipe actor or unknown partial producer remains unresolved')
        ledger=data['auxiliary_operations']
        if type(ledger) is not list or any(type(item) is not AuxiliaryCommand for item in ledger):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger is unknown')
        current=tuple(ledger)
        if len({id(item) for item in current})!=len(current):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger aliases an actor')
        with self._lock:
            if self._partial_auxiliaries is None:self._partial_auxiliaries=current
            frozen=self._partial_auxiliaries
        if len(current)!=len(frozen) or any(a is not b for a,b in zip(current,frozen)):
            self._quarantine_auxiliary_ledger()
            raise ProducerError('partial auxiliary ledger changed; exact handles retained')
        with self._lock:
            if self._auxiliary_quarantined:raise ProducerError('partial auxiliary ledger is quarantined')
            self._auxiliary_ledger_check_matched=True
            self._snapshot=self._snapshot_locked()
        return frozen

    def _quarantine_auxiliary_ledger(self):
        with self._lock:
            self._auxiliary_quarantined=True;self._auxiliary_ledger_check_matched=False
            self._auxiliary_views={index:MappingProxyType({**dict(row),'ledger_check_matched':False})
                for index,row in self._auxiliary_views.items()}
            self._snapshot=self._snapshot_locked()

    def _cache_auxiliary_observation(self,index,auxiliary,stage):
        # Only the serialized worker reads raw actor state. Cached rows are data,
        # never actor closure, authentication or physical lease-release authority.
        if threading.current_thread() is not self._thread:
            raise ProducerError('auxiliary observation requires the retained worker')
        data=auxiliary.__dict__
        required={'started','pending','finished','process','result','status','streams'}
        if not required<=data.keys() or data['started'] is not True:
            raise ProducerError('unknown auxiliary lifecycle')
        if type(data['pending']) is not bool or type(data['finished']) is not bool:
            raise ProducerError('invalid auxiliary state')
        process=data['process'];status=data['status'];result=data['result'];streams=data['streams']
        if (type(process) is not subprocess.Popen or type(process.pid) is not int or process.pid<=0
            or (status is not None and type(status) is not int)
            or (result is not None and type(result) is not dict)
            or type(streams) is not dict or set(streams)!= {'stdout','stderr'}
            or any(type(streams[key]) is not dict or type(streams[key].get('eof')) is not bool for key in streams)):
            raise ProducerError('unknown auxiliary handle or stream state')
        terminal=data['finished'] is True and data['pending'] is False and type(result) is dict
        if terminal:
            if result.get('returncode')!=status or type(result.get('returncode')) is not type(status):
                raise ProducerError('auxiliary terminal status differs')
        elif not (data['pending'] is True and data['finished'] is False and result is None):
            raise ProducerError('incomplete auxiliary terminal state')
        row=dict(index=index,pid=process.pid,direct_status=status,pending=data['pending'],
            finished=data['finished'],stdout_eof=streams['stdout']['eof'],stderr_eof=streams['stderr']['eof'],
            terminal_result_observed=terminal,stage=stage)
        with self._lock:
            row['ledger_check_matched']=self._auxiliary_ledger_check_matched
            value=MappingProxyType(row);self._auxiliary_views[index]=value;self._auxiliary_index=index
            self._snapshot=self._snapshot_locked()
        return value

    def _wait_partial_auxiliary(self,index,timeout):
        frozen=self._partial_auxiliary_ledger()
        # Freeze and retain before selecting; never reselect a different actor.
        if index>=len(frozen):raise ProducerError('partial auxiliary index is not retained')
        auxiliary=frozen[index]
        before=self._cache_auxiliary_observation(index,auxiliary,'before_wait')
        if before['terminal_result_observed']:raise ProducerError('auxiliary wait is permanently terminal')
        try:result=auxiliary.wait(timeout)
        except BaseException as error:
            try:
                self._cache_auxiliary_observation(index,auxiliary,'after_wait_error')
                self._partial_auxiliary_ledger()
            except BaseException as secondary:
                with self._lock:
                    record=self._workers[-1]
                    record['auxiliary_observation_error']=type(secondary).__name__
                    record['_auxiliary_observation_error_object']=secondary
            raise
        after=self._cache_auxiliary_observation(index,auxiliary,'after_wait')
        self._partial_auxiliary_ledger()
        if (result is None and after['terminal_result_observed']) or (result is not None and result is not auxiliary.result):
            raise ProducerError('auxiliary wait result differs from retained state')
        return after

    def auxiliary_observations(self):
        """Immutable selected-actor data; never a complete actor inventory."""
        with self._lock:return tuple(self._auxiliary_views[index] for index in sorted(self._auxiliary_views))


    def _quarantine_command(self):
        with self._lock:
            self._command_quarantined=True
            self._command_view=MappingProxyType(dict(self._command_view,quarantined=True))

    def _checked_partial_command(self):
        # Worker-only bounded identity observations, not atomic FD/writer authority.
        if threading.current_thread() is not self._thread or type(self._operation) is not CommandProducer:
            raise ProducerError('partial command inspection requires the retained worker')
        try:
            data=self._operation.__dict__
            required={'pending','finished','process','result','records','commands','log','output_log',
                      'output_fd','output_buffer','output_hash','output_bytes','output_write_uncertain',
                      'auxiliary_operations','lease_check'}
            if (not required<=data.keys() or data['pending'] is not True or data['finished'] is not False
                or data['result'] is not None):
                raise ProducerError('unknown or nonpending partial command')
            process=data['process'];records=data['records'];commands=data['commands'];log=data['output_log']
            pid=process.pid if type(process) is subprocess.Popen else None
            auxiliary=data['auxiliary_operations']
            if (type(process) is not subprocess.Popen or type(pid) is not int or pid<=0
                or type(records) is not list or not records or any(type(x) is not dict for x in records)
                or type(commands) is not tuple or not len(records)<=len(commands)
                or any(type(x) is not tuple or not x or any(type(a) is not str for a in x) for x in commands)
                or type(log) is not io.FileIO or data['log'] is not log or log.closed
                or type(data['output_buffer']) is not bytes or type(data['output_bytes']) is not int or data['output_bytes']<0
                or type(data['output_write_uncertain']) is not bool
                or type(data['output_hash']) is not type(hashlib.sha256()) or data['output_hash'].name!='sha256'
                or type(auxiliary) is not list or any(type(x) is not AuxiliaryCommand for x in auxiliary)
                or len({id(x) for x in auxiliary})!=len(auxiliary) or not callable(data['lease_check'])):
                raise ProducerError('unknown retained command handles or state')
            record=records[-1];index=len(records)-1;argv=record.get('argv');fd=data['output_fd']
            argv_values=tuple(argv) if type(argv) is list else None;kind=record.get('kind')
            if (type(argv) is not list or any(type(x) is not str for x in argv_values) or argv_values!=commands[index]
                or type(record.get('pid')) is not int or record['pid']!=pid
                or type(kind) is not str
                or kind not in ('recipe','tool_version')
                or type(record.get('output_eof')) is not bool
                or type(record.get('parent_output_write_close_confirmed')) is not bool
                or (record.get('returncode') is not None and type(record['returncode']) is not int)
                or (fd is None and record['output_eof'] is not True)
                or (fd is not None and (type(fd) is not int or fd<0 or record['output_eof'] is True))):
                raise ProducerError('unknown command record or output pipe')
            candidate=dict(process=process,records=records,record=record,argv=argv,commands=commands,log=log,
                output_hash=data['output_hash'],auxiliary=auxiliary,lease_check=data['lease_check'],
                record_ids=tuple(id(x) for x in records),auxiliary_ids=tuple(id(x) for x in auxiliary),
                argv_values=argv_values,index=index,pid=pid,kind=kind,output_fd=fd,
                log_fd=None,log_identity=None,pipe_identity=None)
            # Retain exact actor/log/ledger handles BEFORE fstat or callback I/O.
            with self._lock:
                if self._partial_command is None:self._partial_command=candidate
                frozen=self._partial_command
                if self._command_quarantined:raise ProducerError('partial command is quarantined')
            pointers=('process','records','record','argv','commands','log','output_hash','auxiliary','lease_check')
            values=('record_ids','auxiliary_ids','argv_values','index','pid','kind')
            if (any(candidate[x] is not frozen[x] for x in pointers)
                or any(candidate[x]!=frozen[x] for x in values)
                or (fd is not None and fd!=frozen['output_fd'])):
                raise ProducerError('partial command identity changed; exact handles retained')
            log_fd=log.fileno();info=os.fstat(log_fd)
            file_identity=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink)
            if not stat.S_ISREG(info.st_mode):raise ProducerError('command log is not regular')
            if frozen['log_fd'] is None:frozen['log_fd']=log_fd;frozen['log_identity']=file_identity
            if log_fd!=frozen['log_fd'] or file_identity!=frozen['log_identity']:
                raise ProducerError('command log identity changed')
            if fd is not None:
                info=os.fstat(fd)
                pipe_identity=(info.st_dev,info.st_ino,info.st_mode)
                if not stat.S_ISFIFO(info.st_mode):raise ProducerError('command output is not a pipe')
                if frozen['pipe_identity'] is None:frozen['pipe_identity']=pipe_identity
                if pipe_identity!=frozen['pipe_identity']:raise ProducerError('command output identity changed')
            return frozen
        except BaseException:
            self._quarantine_command()
            raise

    def _cache_command_observation(self,stage):
        frozen=self._checked_partial_command()
        data=self._operation.__dict__;record=frozen['record']
        # Copy primitive values before validation; never publish fresh raw reads
        # after checking mutable producer fields. This does not make a global snapshot atomic.
        eof=record.get('output_eof');buffered=data.get('output_buffer');size=data.get('output_bytes')
        uncertain=data.get('output_write_uncertain');writer_closed=record.get('parent_output_write_close_confirmed')
        pending=data.get('pending');log_open=not frozen['log'].closed
        if (type(eof) is not bool or type(buffered) is not bytes or type(size) is not int or size<0
            or type(uncertain) is not bool or type(writer_closed) is not bool or pending is not True
            or type(stage) is not str):
            self._quarantine_command()
            raise ProducerError('unknown command observation scalar')
        with self._lock:
            status=self._command_wait_status;waited=status is not None
            terminal=waited and eof and not buffered
            row=dict(scope='retained_command_observation_only',observed=True,index=frozen['index'],
                pid=frozen['pid'],kind=frozen['kind'],direct_status=status,
                natural_wait_observed=waited,output_eof=eof,
                output_buffer_bytes=len(buffered),output_bytes=size,
                output_write_uncertain=uncertain,parent_output_write_close_confirmed=writer_closed,
                log_open=log_open,producer_pending=pending,
                terminal_observed=terminal,quarantined=self._command_quarantined,stage=stage,
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False)
            self._command_view=MappingProxyType(row)
            return self._command_view

    def _wait_partial_command(self,timeout):
        frozen=self._checked_partial_command()
        before=self._cache_command_observation('before_wait')
        if before['terminal_observed']:raise ProducerError('partial command wait is permanently terminal')
        try:
            frozen['lease_check']()
            self._checked_partial_command() # Callback drift refuses before pipe I/O.
            deadline=time.monotonic()+timeout
            # No end_command/finish, audits, next spawn, log close or publication.
            self._operation._drain_output(deadline)
            if self._command_wait_status is None:
                try:status=frozen['process'].wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:pass
                else:
                    if type(status) is not int:raise ProducerError('unknown direct command status')
                    with self._lock:self._command_wait_status=status
        except BaseException:
            try:self._cache_command_observation('after_wait_error')
            except BaseException as secondary:
                with self._lock:
                    record=self._workers[-1]
                    record['command_observation_error']=type(secondary).__name__
                    record['_command_observation_error_object']=secondary
            raise
        return self._cache_command_observation('after_wait')

    def command_observation(self):
        """Immutable selected-command data, never actor/lease closure authority."""
        with self._lock:return self._command_view

    def continue_command_wait(self,timeout):
        return self._schedule('command_wait',_preflight_timeout(timeout))

    def continue_auxiliary_wait(self,index,timeout):
        if type(index) is not int or index<0:raise ProducerError('nonnegative auxiliary index required')
        return self._schedule('auxiliary_wait',(index,_preflight_timeout(timeout)))

    def continue_wait(self,timeout):
        return self._schedule('wait',_preflight_timeout(timeout))

    def emit(self,phase):
        if phase not in ('canonical','execution'):raise ProducerError('valid receipt phase required')
        if (self.kind=='canonical' and phase!='canonical') or (self.kind=='production' and phase!='execution'):
            raise ProducerError('receipt phase differs from fixed preflight factory')
        return self._schedule('emit',phase)


def start_owned_preflight(kind,*,owner_id,**kwargs):
    """Retain before launch; call completion never grants capture admission."""
    if type(kind) is not str or kind not in ('fixture','canonical','production'):
        raise ProducerError('fixed preflight factory required')
    if type(owner_id) is not str or not re.fullmatch('[0-9a-f]{32}',owner_id):
        raise ProducerError('preflight owner id required')
    with _PREFLIGHT_OWNERS_LOCK:
        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')
        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')
    frozen=_copy_preflight_kwargs(kwargs)
    owner=_RetainedPreflightOwner(kind,owner_id,frozen)
    with _PREFLIGHT_OWNERS_LOCK:
        if owner_id in _PREFLIGHT_OWNERS:raise ProducerError('owner id is permanently retained')
        if len(_PREFLIGHT_OWNERS)>=_PREFLIGHT_OWNER_LIMIT:raise ProducerError('preflight owner registration capacity reached')
        _PREFLIGHT_OWNERS[owner_id]=owner
    return owner._schedule('construct')
