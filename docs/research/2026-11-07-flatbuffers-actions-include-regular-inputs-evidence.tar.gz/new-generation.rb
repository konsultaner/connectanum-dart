require 'yaml'; require 'json'; require 'digest'
v=JSON.parse(File.read(ARGV[0])); base=File.binread(v.fetch('parent_path')); raise unless Digest::SHA256.hexdigest(base)==v.fetch('parent_sha256')
doc=YAML.load(base); jobs=doc.fetch('jobs'); raise unless jobs.size==28
oldkey='flatbuffers-gcc-math-regular-inputs';newkey='flatbuffers-include-regular-inputs';raise if jobs.key?(newkey)
job=jobs.fetch(oldkey);scripts=job.fetch('steps').select{|s|s['run'].is_a?(String)&&s['run'].include?(v.fetch('old_collector'))};raise unless scripts.size==1
scripts[0]['run']=scripts[0]['run'].sub(v.fetch('old_collector')){v.fetch('new_collector')}
def transform(x)
 case x
 when Hash;x.each_with_object({}){|(k,v),h|h[k]=transform(v)}
 when Array;x.map{|v|transform(v)}
 when String;x.gsub('flatbuffers_gcc_math_regular_inputs','flatbuffers_include_regular_inputs').gsub('flatbuffers-gcc-math-regular-inputs','flatbuffers-include-regular-inputs').gsub('native-perf-gcc-math-regular-inputs','native-perf-include-regular-inputs').gsub('FlatBuffers GCC math regular inputs (no execution)','FlatBuffers include regular inputs (no execution)')
 else;x
 end
end
job=transform(job);block=YAML.dump({newkey=>job}).sub(/\A---\s*\n/,'').lines.map{|l|'  '+l}.join
choice="          - flatbuffers_gcc_math_regular_inputs\n";raise unless base.scan(choice).size==1
addition="          - flatbuffers_include_regular_inputs\n";candidate=base.sub(choice){choice+addition};candidate+="\n"+block
File.open(v.fetch('candidate_path'),'wb'){|f|f.write(candidate)};File.open(v.fetch('job_block_path'),'wb'){|f|f.write(block)}
puts JSON.generate({'new_job_key'=>newkey,'parent_jobs'=>28,'new_job_count'=>29,'candidate_bytes'=>candidate.bytesize,'candidate_sha256'=>Digest::SHA256.hexdigest(candidate)})