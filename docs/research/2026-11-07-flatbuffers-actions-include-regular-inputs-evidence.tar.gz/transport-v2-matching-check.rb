require 'yaml';require 'json';require 'digest'
v=JSON.parse(File.read(ARGV[0]));before=File.binread(v.fetch('before_path'));old=YAML.load(before);fresh=YAML.load(before)
job=fresh.fetch('jobs').fetch('flatbuffers-include-regular-inputs');source=File.binread(v.fetch('collector_path'));steps=job.fetch('steps');matches=steps.select{|x|x['run'].is_a?(String)&&x['run'].include?(source)};raise unless matches.size==1
script=matches[0].fetch('run');needle="python3 - <<'PY'\n"+source+"\nPY\n";raise unless script.scan(needle).size==1
replacement="python3 - < "+v.fetch('repo_collector_path')+"\n"
matches[0]['run']=script.sub(needle){replacement}
oldblock=File.binread(v.fetch('old_job_block_path'));raise unless before.end_with?("\n"+oldblock)
key='flatbuffers-include-regular-inputs'
render=lambda{|obj|YAML.dump({key=>obj}).sub(/\A---\s*\n/,'').lines.map{|l|'  '+l}.join}
raise unless render.call(old.fetch('jobs').fetch(key))==oldblock
newblock=render.call(job);prefix=before[0...-oldblock.bytesize];candidate=prefix+newblock
raise unless candidate[0...-newblock.bytesize]+oldblock==before
File.open(v.fetch('after_path'),'wb'){|f|f.write(candidate)}
parsed=YAML.load(candidate);raise unless parsed==fresh
raise unless candidate.bytesize<500000&&candidate.bytesize<512000
raise unless old.fetch('jobs').size==29&&parsed.fetch('jobs').size==29
oldjobs=old.fetch('jobs');newjobs=parsed.fetch('jobs');raise unless oldjobs.reject{|k,_|k=='flatbuffers-include-regular-inputs'}==newjobs.reject{|k,_|k=='flatbuffers-include-regular-inputs'}
roundtrip=YAML.load(candidate);roundsteps=roundtrip.fetch('jobs').fetch('flatbuffers-include-regular-inputs').fetch('steps');restore=roundsteps.select{|x|x['run'].is_a?(String)&&x['run'].include?(replacement)};raise unless restore.size==1
restore[0]['run']=restore[0]['run'].sub(replacement){needle};raise unless roundtrip==old
puts JSON.generate({'before_workflow_bytes'=>before.bytesize,'after_workflow_bytes'=>candidate.bytesize,'after_workflow_sha256'=>Digest::SHA256.hexdigest(candidate),'collector_bytes'=>source.bytesize,'collector_sha256'=>Digest::SHA256.hexdigest(source),'all28oldjobs_unchanged'=>true,'all29job_and_top_fields_equal_after_reversing_ONLY_new_transport'=>true,'collector_byteexact'=>true,'interpreter_argv_python3_dash_preserved'=>true,'below_both_500000_and_512000_bytes'=>true,'originalworkflow_byteexact_after_reversing_ONLY_new_job_block'=>true,'YAML_pass'=>true,'no_runtime_candidate_executions'=>0,'all_admission_flags'=>false})