import sys,pathlib,json,hashlib,subprocess,shutil,datetime,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-acquisition-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();parts=json.loads((P/'projection-parts.json').read_text())
 assert source==(P/'candidate-producer-v1.py').read_text() and tests==(P/'candidate-tests-v1.py').read_text()
 assert source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'group_acquisition_regressions-v1.py').read_text()
 before=json.loads((P/'before-NEW3/result.json').read_text());after=json.loads((P/'after-selected5/result.json').read_text())
 assert (before['tests'],before['failures'],before['errors'])==(3,2,0)
 assert (after['tests'],after['failures'],after['errors'])==(5,0,0)
 assert len(before['leases'])==6 and len(after['leases'])==10 and all(x['raw_None'] for x in before['leases']+after['leases'])
 controls={}
 for label,folder in [('BEFORE',P/'before-NEW3/fixtures'),('AFTER',P/'after-selected5/new-fixtures')]:
  views=[];waits=[];pipecloses=0;filecloses=0
  for d in sorted(folder.iterdir()):
   v=json.loads((d/'view-before-ROOT-wait.json').read_text());c=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text())
   assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup)
   for i,x in enumerate(setup):
    for channel in ('stdout','stderr'):
     raw=(d/f'setup-{i}-{channel}.bin').read_bytes();assert len(raw)==x[channel+'_size'] and hashlib.sha256(raw).hexdigest()==x[channel+'_sha256']
   w=[r for r in c['rows'] if r['kind']=='same_original_bound_wait'];assert all(r['status']==0 and r['signed_native_int'] for r in w);waits+=w
   pipecloses+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='creatorFD');filecloses+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='file')
   assert v['ROOT_tuple_never_called_or_adopted'] and v['post_unknown_gets']==[] and not v['Source_returned_owner']
   if v['group_acquisition']=='input':
    assert not v['factory_unknown'] and v['group_calls']==2 and v['received_First'] and v['received_type']=='ProducerError' and not v['spawn_returned_inside_ROOT']
    assert len(w)==5 and not any(r['actor_kind']=='recipe' for r in w) and v['Source_finished_DATA'] and not v['Source_pending_DATA']
   else:
    assert v['factory_unknown'] and v['group_calls']==1 and v['spawn_raw_None'] and v['spawn_stage']=='spawned' and len(w)==6
    assert v['Source_pending_DATA'] and not v['Source_finished_DATA'] and not v['Source_failure_attempted_DATA']
    assert (d/'ROOT-recipe-pipe.bin').read_bytes()==b'GROUP-ACQUIRE-v1-outGROUP-ACQUIRE-v1-err' and (d/'ROOT-recipe-pipe-tail.bin').read_bytes()==b''
    if label=='BEFORE':assert v['received_Secondary'] and not v['received_First'] and not v['first_context_is_secondary']
    else:assert v['received_First'] and not v['received_Secondary'] and v['first_context_is_secondary']
   views.append(v)
  assert len(views)==3 and len(waits)==17 and pipecloses==2 and filecloses==4
  controls[label]=dict(views=views,original_bound_wait_rows=waits,Root_pipe_closes_afterevidence=pipecloses,Root_file_closes_afterevidence=filecloses,setup_Git_rows21_separate=True)
 parent=[r for row in after['root_original_waits'] for r in row['rows']];assert len(parent)==31 and all(r['status']==0 and r['signed_native_int'] for r in parent)
 models={}
 for name in ('planning','review'):
  r=json.loads((P/name/'result.json').read_text());assert r['status']==0 and r['both_separate_EOF'] and (P/name/'answer.txt').is_file();models[name]=r
 q=P/'ROOT-source-Git';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait(10);(q/f'{i}-stdout.bin').write_bytes(out);(q/f'{i}-stderr.bin').write_bytes(err)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/'commands.json').write_text(json.dumps(commands,indent=2));assert status==0 and not err;return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 status=git(['status','--porcelain','--untracked-files=all']).decode().splitlines();assert len(status)==20 and all(s.startswith('?? tool/') for s in status) and {s[3:] for s in status}=={k for k in h if k.startswith('tool/')}
 assert git(['diff','601108ea6216464bd00ae29c16cfaf0a59c71db6','--stat','--','packages','native'])==b''
 qualification=json.loads((P/'review-ROOT-qualification.json').read_text());qualification['actual_AFTER_primary_context_is_original_secondary_BOTH']=True;qualification['actual_input_recipe_rows0_Aux5_and_knowncleanup']=True
 (P/'review-ROOT-after-data.json').open('x').write(json.dumps(qualification,indent=2))
 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before_NEW3=before,after_selected5=after,controls=controls,parent_after31_rows_include_same_NEW17_plus14affected_do_not_add_duplicates=True,models=models,ROOT_model_qualification=qualification,wholeSource_BYTEprojectback=True,oldtest_PREFIX_exact=True,only_existing_method_changed='CommandProducer.__init__',other18helpers3bins_unchanged=True,current23hashes_SourceGit4_0_BOTH=True,SourceGit=commands,no_prior6_old27_old25_old2bodies_old7suite_private2_replay=True,Source_unknown_group_ROOTtuple_never_adopted_called=True,no_Source_pending_defer_preserve_repr_close_after_unknown=True,Source_fields_not_liveness_ownership_EXrelease=True,unit_not_fullphysicalEX_originalLinux_FD_interpreter_delegate_descendant_closure_or_runtime_admission=True,unexpected_beforeview_wait_read_cleanup_not_proved=True,stronggroups_rawchunks_processlife_NOTfixedmemory_RSSgrowth_timing_leakcause_UNMEASURED=True,no_Source_commit_push_adoption_SDKbuild_kernel_broker_benchmarkcapture_strictdispatch_RAMrepair_acceptance=True,before_builder_bad_marker_before_files_units_SourceIO_corrected_firstactual_run=True,available_API_only_no_omission_reconstruction=True,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_group_acquisition_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256']);c.update(updated_utc=assessment['utc'],active_turn_status='Constructor_group_acquisition_NEW3before2FAIL1PASS_AFTER5PASS_ROOTqualified_DOCSpending');cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],before='2FAIL1PASS0ERROR',after='5PASS=3NEW2affected',current23hashes_SourceGit4_0_BOTH=True,original_primary_secondary_context_retained=True,free_bytes=free,full_admission=False)))
