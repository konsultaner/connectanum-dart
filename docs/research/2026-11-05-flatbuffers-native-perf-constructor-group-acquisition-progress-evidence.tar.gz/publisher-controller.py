import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-acquisition-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-constructor-group-acquisition-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='14ad24722d889e2213e27572882be3e1a182c98d'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Preserve First when failure-group acquisition has an unknown return\n\nThree new regressions produce2FAIL/1PASS/0ERROR before the change. The actual whole spawn body returns inside ROOT and ROOT raises First; the native failure-group function then returns a tuple only inside ROOT, which raises a later RuntimeError or SystemExit before Source receives that tuple. Acquisition outside the inner catch allowed the later error to replace First. The separate actual pre-spawn input-digest refusal control already passes.\n\nThe constructor now catches acquisition failure and raises its already-known original error. It does not adopt the ROOT-only tuple, call its methods, read pending or enter defer/preserve/format/close work after that unknown return. Both after cases retain the later error in First's exception context. Five selected after tests pass: matchingNEW3 plus symlink-input refusal and caller-input-dictionary mutation controls. Source projection changes only this constructor acquisition boundary; the old test prefix and other18 helper/three bin hashes remain exact.\n\nThese are controlled error-priority regressions, not spontaneous kernel bugs or a RAM cause. Known finite actors/FD closes and current Darwin lease observations remain unit data. No earlier tests or reviews are replayed, no Source commit/build/capture/adoption occurs, and full original-runtime admission and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-constructor-group-acquisition-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: preserve First across unknown group acquisition'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_group_acquisition_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Next NEWpredeclared question may cover known-invalid failure-group return shapes (None/bool) before pending metadata/callable fields, or earlier binding/interior/concurrentABA/historical-transitive original-runtime preflight. Prospective/no Source edit withoutmeaningfulactualBEFOREfailure. Current711478/f094b9 selected5PASS=matchingNEW3+2callercontrols (inputsymlinkrefusal/callerinputdictmutation). BEFOREae1d1a/0265f8 NEW3=2FAIL1PASS0ERROR: actualwhole_spawn returnsNone insideROOT thenFirst, nativefailuregroup returnsTuple ONLYROOT thenRuntimeError/SystemExit beforeSourcegetsGroup; latererror replacedFirst. Onlyconstructoracquisition nowtry/exceptBaseException raisesalreadyknownFirst. ROOTtuple neveradopted/called; Sourcepostunknowngetcount0/no pending-defer-preserve-repr-close; pendingTrue-finishedFalse-failure_attemptedFalse DATAunchanged. AFTERbothFirstcontextIsOriginalSecondary true/standardchaining/no traceback suppression. Normalpre-spawn actualinputdigestmismatchSourceProducerError/nativeknownGroup alreadyPASS/no recipe. WholeSourceBYTEprojectback/oldtestPREFIXexact/helpercallee-oldauxpredicates-owner_emit_attempted unchanged; no prior6-old27-completed25-old2bodies-old7suite-privatependingTrue2 replay/currentcanonicalaggregate. 6views3BEFORE3AFTER/privateRoot17waitrows perphase(2neg6each+control5) all0cachedpossible/Root2pipe4filecloses perphase AFTERevidence; parentAFTER31=17sameNEW+14affected (neveraddduplicates). ParentDarwinEX6BEFORE10AFTERNone UNITnotphysicalEX-originalLinux/FD-interpreter-delegate-descendantclosure/ownershipadmission; unknownbeforeview-wait-read cleanup incomplete/no allreap/globalPIDscan-kill/APIreconstruction. Qwen12075=0/524out320err;GLM13388=0/4814out859err/BOTH EOF-naturalreaped-fullanswers-ROOTqualified notwholecurrentapproval. RejectstrongownerIDreuse/clearedentrycollision/ownerledgerwrite-afterunknown/traceback-lost/inputflagspawncoupling/inputcapturenotrun; Rootactualcontext/0inputrecipe5Aux validatesselectedfacts; Firstpriority overlaterBaseException deliberate no SystemExitprocessabort. 1GiBfree-diskfloor NOTmemoryfixture; original_spawnreturnsNone/nativePopenreturnsobject. BeforecontrollerbuildermarkerfailedBEFOREanyfiles-units-SourceIO/correctedfirstactualrun. Current23hashes-other18helpers3bins/4freshSourceGit0-BOTH/HEAD601ownbranch20untracked-productiontrackedempty DATA/notcompiledcanonical. Stronggroups-closures-rawchunksprocesslife NOTfixedmemory/heapRSSgrowth-allocvolume-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-pop-reset-evict-deleteauthority. All20uncommitteduncanonicalunadmitted/providerABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no Sourceadoption-SDKbuild-kernel-broker-benchmarkcapture-strictdispatch; UnknownPopenCtorPERMANENT/no partialmethods-fieldderivedsettlement.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Constructor_group_acquisition_selected5PASS_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
