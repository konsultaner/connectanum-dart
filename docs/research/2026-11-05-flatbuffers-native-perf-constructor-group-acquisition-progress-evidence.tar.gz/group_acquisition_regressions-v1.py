import unittest,pathlib,tempfile,sys,os,hashlib,json,subprocess
import native_perf_build_producer as b
Path=pathlib.Path
def group_acq_sha(raw):return hashlib.sha256(raw).hexdigest()
class GroupAcquisitionFirst(RuntimeError):pass
class GroupAcquisitionSecond(RuntimeError):pass
class GroupAcquisitionTests(unittest.TestCase):
 def _case(self,mode):
  root=Path(os.environ['CONNECTANUM_GROUP_ACQ_FIXTURES']);root.mkdir(exist_ok=True)
  base=Path(tempfile.mkdtemp(prefix=mode+'-',dir=root)).resolve();repo=base/'repo';repo.mkdir();run=base/'run'
  setup=[];actors=[];pipes=[];files=[];groups=[];seen={'spawn_returned':False,'pending_native':[]}
  first=GroupAcquisitionFirst('group-acquisition-original-first');second=(SystemExit('group-acquisition-SystemExit') if mode=='exit' else GroupAcquisitionSecond('group-acquisition-secondary'))
  def git(*args):
   i=len(setup);argv=['git','-C',str(repo),*args];row={'argv':argv,'Popen_attempted':True,'pid':None};setup.append(row)
   (base/f'setup-{i}-before.json').write_text(json.dumps(row))
   process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=process.wait
   (base/f'setup-{i}-start.json').write_text(json.dumps({'pid':process.pid}))
   out,err=process.communicate();status=wait(10)
   (base/f'setup-{i}-stdout.bin').write_bytes(out);(base/f'setup-{i}-stderr.bin').write_bytes(err)
   row.update(pid=process.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=group_acq_sha(out),stderr_sha256=group_acq_sha(err))
   (base/'setup-commands.json').write_text(json.dumps(setup,indent=2))
   if status!=0:raise RuntimeError('new fixture setup refused')
   return out
  git('init','-q');git('config','user.email','group-acquisition@example.invalid');git('config','user.name','Group Acquisition Fixture')
  (repo/'.gitignore').write_text('inputs/\n')
  (repo/'worker.py').write_text("import os,time\ntime.sleep(0.08)\nos.write(1,b'GROUP-ACQUIRE-v1-out')\nos.write(2,b'GROUP-ACQUIRE-v1-err')\n")
  git('add','.');git('commit','-qm','new group acquisition fixture');head=git('rev-parse','HEAD').decode().strip()
  expected=group_acq_sha(git('archive','--format=tar',head));(repo/'inputs').mkdir();(repo/'inputs'/'context').write_bytes(b'group-acquisition-input-v1')
  inputs={'inputs/context':group_acq_sha((repo/'inputs'/'context').read_bytes())}
  if mode=='input':inputs['inputs/context']='0'*64
  native_os=b.os;native_open=Path.open;native_aux=b.AuxiliaryCommand._allocate_process;native_recipe=b.CommandProducer._allocate_command_process
  native_spawn=b.CommandProducer._spawn;native_get=b.CommandProducer.__getattribute__;native_group=b._failure_preservation_group
  def remember(process,kind):
   actors.append({'process':process,'wait':process.wait,'pid':process.pid,'kind':kind})
  class OSFacade:
   def __getattr__(self,name):return getattr(native_os,name)
   def pipe(self):
    pair=native_os.pipe();info=[]
    for fd in pair:
     st=native_os.fstat(fd);info.append({'fd':fd,'dev':st.st_dev,'ino':st.st_ino,'inheritable':native_os.get_inheritable(fd)})
    pipes.append({'pair':pair,'info':info})
    return pair
  def opened(path,*args,**kwargs):
   value=native_open(path,*args,**kwargs)
   if path.parent==run:
    raw=getattr(value,'raw',None)
    for stream in ([raw,value] if raw is not None and raw is not value else [value]):
     st=native_os.fstat(stream.fileno());files.append({'path':str(path),'stream':stream,'close':stream.close,'fd':stream.fileno(),'dev':st.st_dev,'ino':st.st_ino})
   return value
  def auxiliary(owner,record):
   process=native_aux(owner,record);remember(process,'Auxiliary');return process
  def recipe(owner,attempt,argv,writer):
   process=native_recipe(owner,attempt,argv,writer);remember(process,'recipe')
   matches=[row for row in reversed(pipes) if row['pair'][1]==writer];assert matches
   seen['recipe_pipe']=matches[0];seen['recipe_process']=process;return process
  def spawned(owner):
   raw=native_spawn(owner)
   seen.update(owner=owner,spawn_returned=True,spawn_raw_None=raw is None,actual_spawn_stage=owner._command_attempt['stage'])
   raise first
  def grouped(owner,error):
   nonlocal first
   seen['owner']=owner
   if mode=='input':first=error
   value=native_group(owner,error);groups.append(value)
   if mode!='input' and not seen.get('factory_unknown'):
    seen['factory_unknown']=True
    raise second
   return value
  def gotten(owner,name):
   value=native_get(owner,name)
   if seen.get('factory_unknown') and seen.get('owner') is owner:seen.setdefault('post_unknown_gets',[]).append(name)
   return value
  received=None;returned=None;result=None;evidence_ready=False
  try:
   b.os=OSFacade();Path.open=opened;b.AuxiliaryCommand._allocate_process=auxiliary;b.CommandProducer._allocate_command_process=recipe
   b.CommandProducer._spawn=spawned if mode!='input' else native_spawn;b.CommandProducer.__getattribute__=gotten;b._failure_preservation_group=grouped
   try:
    returned=b.CommandProducer(repo=repo,source_commit=head,runtime_commit=head,run_dir=run,expected_archive_sha256=expected,inputs=inputs,commands=[[sys.executable,str(repo/'worker.py')]],lease_check=lambda:None,provenance='fixture')
    b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
    if returned is not None:raise AssertionError('constructor unexpectedly returned')
   except BaseException as error:received=error
   finally:
    b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
    b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   owner=seen.get('owner')
   view={'group_acquisition':mode,'spawn_returned_inside_ROOT':seen['spawn_returned'],'spawn_raw_None':seen.get('spawn_raw_None'),'spawn_stage':seen.get('actual_spawn_stage'),'group_calls':len(groups),'factory_unknown':seen.get('factory_unknown',False),'ROOT_tuple_never_called_or_adopted':True,'post_unknown_gets':seen.get('post_unknown_gets',[]),'Source_returned_owner':returned is not None,'received_First':received is first,'received_Secondary':received is second,'received_type':None if received is None else type(received).__name__,'first_context_is_secondary':first.__context__ is second,'Source_pending_DATA':None if owner is None else native_get(owner,'pending'),'Source_finished_DATA':None if owner is None else native_get(owner,'finished'),'Source_failure_attempted_DATA':None if owner is None else native_get(owner,'failure_attempted'),'actor_rows':[{'pid':row['pid'],'kind':row['kind']} for row in actors],'unit_only_not_ownership_admission':True}
   (base/'view-before-ROOT-wait.json').write_text(json.dumps(view,indent=2));evidence_ready=True
   self.assertTrue(received is first);self.assertIsNone(returned)
   if mode=='input':
    self.assertIs(type(first),b.ProducerError);self.assertEqual('input identity/digest differs: inputs/context',str(first));self.assertFalse(view['factory_unknown']);self.assertFalse(view['spawn_returned_inside_ROOT']);self.assertTrue(view['Source_finished_DATA'])
    saved=json.loads((run/'failure.json').read_text());self.assertIn('input identity/digest differs',saved['error'])
   else:
    self.assertTrue(view['factory_unknown']);self.assertEqual(1,view['group_calls']);self.assertEqual([],view['post_unknown_gets']);self.assertTrue(view['spawn_raw_None']);self.assertEqual('spawned',view['spawn_stage']);self.assertTrue(view['Source_pending_DATA']);self.assertFalse(view['Source_finished_DATA']);self.assertFalse(view['Source_failure_attempted_DATA'])
  finally:
   b.CommandProducer._spawn=native_spawn;b.CommandProducer.__getattribute__=native_get;b._failure_preservation_group=native_group
   b.CommandProducer._allocate_command_process=native_recipe;b.AuxiliaryCommand._allocate_process=native_aux;Path.open=native_open;b.os=native_os
   if not evidence_ready:raise RuntimeError('ROOT evidence absent; no cleanup claim')
   rows=[]
   for row in actors:
    raw=row['wait'](10);rows.append({'kind':'same_original_bound_wait','actor_kind':row['kind'],'pid':row['pid'],'status':raw,'signed_native_int':type(raw) is int})
   if mode!='input':
    pipe=seen['recipe_pipe'];fd=pipe['pair'][0];identity=pipe['info'][0];st=native_os.fstat(fd)
    same=(st.st_dev,st.st_ino)==(identity['dev'],identity['ino']);assert same
    assert native_os.get_blocking(fd) is False
    data=native_os.read(fd,65536);tail=native_os.read(fd,1);(base/'ROOT-recipe-pipe.bin').write_bytes(data);(base/'ROOT-recipe-pipe-tail.bin').write_bytes(tail)
    record={'fd':fd,'same_devino':same,'existing_nonblocking':True,'size':len(data),'sha256':group_acq_sha(data),'tail_size':len(tail),'EOF':tail==b'','not_Source_log_reconstruction':True}
    (base/'ROOT-pipe-before-close.json').write_text(json.dumps(record,indent=2));rows.append({'kind':'recipe_raw_pipe','record':record})
    self.assertEqual(b'GROUP-ACQUIRE-v1-outGROUP-ACQUIRE-v1-err',data);self.assertEqual(b'',tail)
   (base/'ROOT-before-FDclose.json').write_text(json.dumps({'evidence_ready':True,'rows':rows},indent=2))
   for pipe in pipes:
    for info in pipe['info']:
     try:st=native_os.fstat(info['fd'])
     except OSError as error:rows.append({'kind':'creatorFD','fd':info['fd'],'already_closed_errno':error.errno});continue
     same=(st.st_dev,st.st_ino)==(info['dev'],info['ino']);rows.append({'kind':'creatorFD','fd':info['fd'],'same_devino':same,'closed_by_ROOT':same})
     if same:native_os.close(info['fd'])
   for item in files:
    if item['stream'].closed:continue
    try:st=native_os.fstat(item['fd'])
    except OSError as error:rows.append({'kind':'file','path':item['path'],'fd':item['fd'],'already_closed_errno':error.errno});continue
    same=(st.st_dev,st.st_ino)==(item['dev'],item['ino']);record={'kind':'file','path':item['path'],'fd':item['fd'],'same_devino':same,'closed_by_ROOT':False};rows.append(record)
    if same:
     try:item['close']();record['closed_by_ROOT']=True
     except BaseException as error:record['close_error_type']=type(error).__name__
   (base/'ROOT-unit-cleanup.json').write_text(json.dumps({'evidence_ready':True,'rows':rows,'unit_not_live_ownership_fullFD_descendant_closure':True},indent=2))
 def test_new_unknown_group_RuntimeError_preserves_original_First(self):self._case('runtime')
 def test_new_unknown_group_SystemExit_preserves_original_First(self):self._case('exit')
 def test_new_native_group_known_input_digest_refusal_control(self):self._case('input')
