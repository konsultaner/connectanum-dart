import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0642_NEW71_SOURCEpublication_EX',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
import os,stat,base64,subprocess,datetime,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-originalActions-sourcepublication-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 def js(n,x):save(n,json.dumps(x,ensure_ascii=True,indent=2))
 save('controller.py',sys.argv[2]);js('execution-declaration.json',v)
 js('actual-publication-actor-environment-credentials-PRIVATE.json',{'argv':sys.argv,'cwd':os.getcwd(),'uid':os.getuid(),'euid':os.geteuid(),'gid':os.getgid(),'egid':os.getegid(),'groups':os.getgroups(),'environment':dict(os.environ),'not_original_Actions_driver_credentials_or_admission':True})
 free=shutil.disk_usage(B).free;js('fresh-storage-point-BEFORE-sourcebindings-NO-build.json',{'free_bytes':free,'floor_bytes':1073741824,'not_build_capture_or_deletion_authority':True});assert free>=1073741824
 CP=B/'current-task-checkpoint.json';old=CP.read_bytes();save('checkpoint-BEFORE-sourcepublication-PRIVATE.json',old);d=json.loads(old)
 node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 assert node['phase']=='COMPLETE_CONSUMED_FIRST_NEW71_localSTATIC_BINDINGS_public_DOCS_NOT_ActionsSourcePublished_Dispatched_Queried_NOTadmitted'
 node['FIRST_Actions_sourcepublication']={'phase':'FIRST_ENTERED_inputs_parent_reference_Gittransport_PENDING_NOdispatch','directory':str(P),'native_OWNmetadata_PID':os.getpid(),'outer_PID_pipeEOF':None,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_directory71_preparation='FIRST_Actions_sourcepublication_ENTERED_noSDKquery_dispatch',next='ONLYSAMEoriginal sourcepublication session polls/no relaunch/namespace reset/retry. No Source20-runtime-native-build-adoption-cleanup/SDK_INPUT_IO. BothfullGitblobJSONreadbacks requiredbeforeanyfuturedispatch.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 bindings=[];outputs=[];owners=[]
 def md(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
  return {k:getattr(s,k) for k in dir(s) if k.startswith('st_') and type(getattr(s,k)) in (int,float)}
 def read(row):
  fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);primary=None;b={'role':row['role'],'path':row['path'],'open_return_fd':fd,'close_return_fd':None,'expected_bytes':row['bytes'],'expected_sha256':row['sha256'],'file_EOF_probe':None}
  bindings.append(b)
  try:
   before=md(fd);nbytes=before['st_size'];assert row['bytes'] is None or nbytes==row['bytes'];b.update(before=before,range=[0,nbytes]);js(row['role']+'-point-BEFORE-contentIO-PRIVATE.json',b)
   n=0;parts=[];h=hashlib.sha256()
   while n<nbytes:
    x=os.read(fd,min(65536,nbytes-n));assert x;n+=len(x);parts.append(x);h.update(x)
   raw=b''.join(parts);after=md(fd);b['after']=after
   assert all(before[k]==after[k] for k in before if k not in ['st_atime','st_atime_ns']) and (row['sha256'] is None or h.hexdigest()==row['sha256'])
   b.update(bytes=n,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  js(row['role']+'-INPUTFD-binding-PRIVATE.json',b)
  if primary is not None:raise primary
  return raw
 def write(name,raw):
  fd=os.open(P/name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);primary=None;b={'name':name,'open_return_fd':fd,'close_return_fd':None,'file_EOF_probe':None};outputs.append(b)
  try:
   before=md(fd);b['before']=before;n=0
   while n<len(raw):
    z=os.write(fd,raw[n:n+65536]);assert z>0;n+=z
   os.fsync(fd);os.lseek(fd,0,os.SEEK_SET);n=0;h=hashlib.sha256()
   while n<len(raw):
    x=os.read(fd,min(65536,len(raw)-n));assert x and x==raw[n:n+len(x)];n+=len(x);h.update(x)
   after=md(fd);b['after']=after;assert n==len(raw)==after['st_size'] and h.hexdigest()==hashlib.sha256(raw).hexdigest() and (before['st_dev'],before['st_ino'])==(after['st_dev'],after['st_ino'])
   b.update(bytes=n,sha256=h.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  js(name+'-OUTPUTFD-binding-PRIVATE.json',b)
  if primary is not None:raise primary
  return {'path':str(P/name),'bytes':b['bytes'],'sha256':b['sha256']}
 def run(args,role,input_bytes=None):
  owner={'operation':role,'handle':None};owners.append(owner)
  js(role+'-request.json',{'argv':args,'cwd':str(P),'stdin_bytes':None if input_bytes is None else len(input_bytes),'stdin_sha256':None if input_bytes is None else hashlib.sha256(input_bytes).hexdigest(),'strong_original_owner_registered_BEFORE_constructor':True})
  p=subprocess.Popen(args,cwd=P,stdin=subprocess.PIPE if input_bytes is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);owner['handle']=p
  js(role+'-creator.json',{'pid':p.pid,'original_strong_handle_retained_BEFORE_fallible_IO':True})
  if role=='FIRST-NEW71-collector-Git-pack-push':print(json.dumps({'original_Gitpush_PID':p.pid,'no_dispatch_or_SDKquery':True}),flush=True)
  try:o,e=p.communicate(input=input_bytes);status=p.wait()
  except BaseException as ex:
   js(role+'-unknown-outcome-PRIVATE.json',{'kind':type(ex).__name__,'text':str(ex),'pid':p.pid,'signed_status':None,'stdout_EOF':None,'stderr_EOF':None,'no_relaunch_or_globalreap':True});raise
  save(role+'.stdout',o);save(role+'.stderr',e)
  completion={'pid':p.pid,'signed_status':status,'stdout_eof':True,'stderr_eof':True,'same_original_wait':True,'wait_may_be_cached':True,'stdout_bytes':len(o),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_bytes':len(e),'stderr_sha256':hashlib.sha256(e).hexdigest()}
  js(role+'-completion.json',completion)
  assert status==0,(role,completion)
  lease.verify_identity();return o
 def api(method,endpoint,role,body=None):
  args=['gh','api','--hostname','github.com','--method',method,endpoint]
  if body is not None:
   raw=json.dumps(body,ensure_ascii=True,separators=(',',':')).encode();row=write(role+'-body.json',raw)
   js(role+'-body-file-binding-NOT_HTTPwire.json',row);args+=['--input',row['path']]
  return run(args,role)
 raw_inputs={row['role']:read(row) for row in v['inputs']}
 for row in v['inputs']:write(row['role']+'-bound-original-PRIVATE',raw_inputs[row['role']])
 source=raw_inputs['NEW71_actual_collector_SOURCE'];workflow=raw_inputs['NEW40_actual_workflow_SOURCE'];scope=raw_inputs['RAW71_SOURCE_scope_UNCHANGED_NOcomparison_replay']
 static=json.loads(raw_inputs['consumed_STATIC_completion_METADATA_ONLY']);staticproof=json.loads(raw_inputs['consumed_STATIC_ALLfield_proof_METADATA_ONLY'])
 sourcevalidation=json.loads(raw_inputs['consumed_SOURCEvalidation_METADATA_ONLY']);codec=json.loads(raw_inputs['consumed_CODEC28883414event_proof_METADATA_ONLY'])
 parent=json.loads(raw_inputs['original5a187768_parent_commit_SAVED_RESPONSEmetadata'])
 assert parent['sha']==v['parent_source'] and parent['tree']['sha']==v['parent_tree']
 assert static['inputs']==9 and static['newcontrol_regions']==4 and static['new_refs']==71 and static['report_fields_NEW71']==11
 assert static['result']==staticproof['result'] and staticproof['total_ordered_events']==6240 and staticproof['EVERY_standardPython_field_exhaustive_ordered_structure_duplicatekeys_arraypositions_typedleaves_equal'] is True
 assert all(x is None for x in static['runtime_preproof_UNMEASURED_NULLs'].values()) and static['sourcecommit'] is None and static['run_id'] is None
 assert sourcevalidation['collector']['bytes']==len(source) and sourcevalidation['collector']['sha256']==hashlib.sha256(source).hexdigest()
 assert sourcevalidation['workflow']['bytes']==len(workflow) and sourcevalidation['workflow']['sha256']==hashlib.sha256(workflow).hexdigest()
 assert codec['total_ordered_events']==28883414 and len(codec['ALL291_original_groupcounts_preserved'])==291 and sum(codec['ALL291_original_groupcounts_preserved'])==28720117
 assert len(scope)==94092 and not scope.endswith(b'\n') and len(json.loads(scope)['ALL71_NEW_lexicaldirectory_TEXT_candidates'])==71
 assert len(workflow)<500000 and len(workflow)<512000
 js('ALL-nine-actual-publication-input-bindings-PRIVATE.json',bindings)
 parentref=json.loads(api('GET','repos/konsultaner/connectanum-dart/git/ref/heads/'+v['parent_branch'],'FIRST-current-original-parent-branch-reference-METADATA'))
 assert parentref['ref']=='refs/heads/'+v['parent_branch'] and parentref['object']['sha']==v['parent_source']

 bare=P/'NEW-private-collector-only-carrier.git';G=['git','--git-dir='+str(bare)]
 run(['git','init','--bare','--object-format=sha1',str(bare)],'FIRST-NEW71-private-bare-Git-init')
 expected_blob=hashlib.sha1(b'blob '+str(len(source)).encode()+b'\x00'+source).hexdigest()
 blob=run(G+['hash-object','-w','--stdin'],'FIRST-NEW71-bound-source-Gitblob',source).decode().strip();assert blob==expected_blob
 localreadback=run(G+['cat-file','blob',blob],'FIRST-NEW71-local-Gitblob-BYTEEXACT-readback');assert localreadback==source
 filename=v['collector_git_path'].split('/')[-1]
 collectors_tree=run(G+['mktree'],'FIRST-NEW71-carrier-collectors-tree',('100644 blob '+blob+'\t'+filename+'\n').encode()).decode().strip()
 github_tree=run(G+['mktree'],'FIRST-NEW71-carrier-github-tree',('040000 tree '+collectors_tree+'\tcollectors\n').encode()).decode().strip()
 carrier_tree=run(G+['mktree'],'FIRST-NEW71-carrier-root-tree',('040000 tree '+github_tree+'\t.github\n').encode()).decode().strip()
 carrier_commit=run(G+['commit-tree',carrier_tree,'-m','Carry exact NEW71 directory collector bytes through Git transport [skip ci]'],'FIRST-NEW71-carrier-orphan-commit').decode().strip()
 pushargs=G+['-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','--porcelain','--no-force','https://github.com/konsultaner/connectanum-dart.git',carrier_commit+':refs/heads/'+v['carrier_branch']]
 run(pushargs,'FIRST-NEW71-collector-Git-pack-push')
 carrierref=json.loads(api('GET','repos/konsultaner/connectanum-dart/git/ref/heads/'+v['carrier_branch'],'FIRST-NEW71-carrier-remote-reference-METADATA'))
 assert carrierref['object']['sha']==carrier_commit
 transport={'collector_git_blob_sha':blob,'collector_bytes':len(source),'collector_sha256':hashlib.sha256(source).hexdigest(),'local_Gitobject_full_BYTEEXACT_readback':True,
 'new_carrier_branch':v['carrier_branch'],'new_carrier_commit':carrier_commit,'new_carrier_tree':carrier_tree,'collector_ONLY_no_workflow_or_originalcohort_admission':True,
 'new_Gitpush_completed_once':True,'no_clone_fetch_oldsource_SDK_or_API_POST_retry':True,'original_workload_cohort_copy_GC_flags_gates_schema_unchanged':True,'all_admission_flags':False,'ownership':None}
 js('FIRST-NEW71-Gittransport-completion.json',transport)
 expected_workflow_blob=hashlib.sha1(b'blob '+str(len(workflow)).encode()+b'\x00'+workflow).hexdigest()
 workflow_blob=json.loads(api('POST','repos/konsultaner/connectanum-dart/git/blobs','FIRST-NEW71-workflow-blob-create',{'content':base64.b64encode(workflow).decode('ascii'),'encoding':'base64'}))
 assert workflow_blob['sha']==expected_workflow_blob
 tree=json.loads(api('POST','repos/konsultaner/connectanum-dart/git/trees','FIRST-NEW71-atomic-TWOfile-tree',
 {'base_tree':v['parent_tree'],'tree':[{'path':v['collector_git_path'],'mode':'100644','type':'blob','sha':blob},{'path':v['workflow_git_path'],'mode':'100644','type':'blob','sha':workflow_blob['sha']}]}))
 assert isinstance(tree['sha'],str) and len(tree['sha'])==40
 commit=json.loads(api('POST','repos/konsultaner/connectanum-dart/git/commits','FIRST-NEW71-original-parent-commit',
 {'message':'Prepare original Actions all71 saved directory inputs [skip ci]','tree':tree['sha'],'parents':[v['parent_source']]}))
 assert commit['tree']['sha']==tree['sha'] and [x['sha'] for x in commit['parents']]==[v['parent_source']]
 revision=commit['sha'];assert isinstance(revision,str) and len(revision)==40
 branch=json.loads(api('POST','repos/konsultaner/connectanum-dart/git/refs','FIRST-NEW71-original-Actions-source-branch',{'ref':'refs/heads/'+v['new_branch'],'sha':revision}))
 assert branch['ref']=='refs/heads/'+v['new_branch'] and branch['object']['sha']==revision
 # Contents records bind path/object locators only. BOTH full original Gitblob JSON bodies are acquired before any future dispatch.
 readbacks=[]
 for kind,path,sha,expected in [('collector',v['collector_git_path'],blob,source),('workflow',v['workflow_git_path'],workflow_blob['sha'],workflow)]:
  locator_raw=api('GET','repos/konsultaner/connectanum-dart/contents/'+path+'?ref='+revision,'FIRST-NEW71-'+kind+'-commit-path-METADATA-ONLYlocator')
  locator=json.loads(locator_raw);assert locator['sha']==sha and locator['size']==len(expected) and locator['path']==path and locator['type']=='file'
  fullraw=api('GET','repos/konsultaner/connectanum-dart/git/blobs/'+sha,'FIRST-NEW71-'+kind+'-FULL-Gitblob-JSON-readback')
  record=json.loads(fullraw.decode('utf-8','strict'))
  assert record['sha']==sha and record['size']==len(expected) and record['encoding']=='base64'
  decoded=base64.decodebytes(record['content'].encode('ascii'));assert decoded==expected
  decodedrow=write('FIRST-NEW71-'+kind+'-FULL-decoded-BYTEEXACT-readback',decoded)
  readbacks.append({'kind':kind,'commit_path':path,'git_blob_sha':sha,'FULL_original_Gitblob_JSON_bytes':len(fullraw),'FULL_original_Gitblob_JSON_sha256':hashlib.sha256(fullraw).hexdigest(),
  'decoded_FULL_bytes':len(decoded),'decoded_FULL_sha256':hashlib.sha256(decoded).hexdigest(),'decoded_saved_output':decodedrow,
  'whole_decoded_BYTES_equal_actual_bound_SOURCE':True,'Contents_metadata_used_ONLY_as_locator':True,'not_HTTPwire_bytes_atomicABA_originchain_admission':True})
 assert len(readbacks)==2 and all(x['close_return_fd']==x['open_return_fd'] for x in bindings+outputs)
 receipt={'phase':'FIRST_NEW71_originalActions_SOURCEPUBLICATION_BOTH_FULL_Gitblob_JSON_decodedBYTEEXACT_READBACKS_COMPLETE_NOdispatch_SDKquery_NOTadmitted',
 'directory':str(P),'source_commit':revision,'parent_source':v['parent_source'],'parent_tree':v['parent_tree'],'new_tree':tree['sha'],'branch':v['new_branch'],
 'collector_bytes':len(source),'collector_sha256':hashlib.sha256(source).hexdigest(),'workflow_bytes':len(workflow),'workflow_sha256':hashlib.sha256(workflow).hexdigest(),
 'new71_source_scope_bytes':len(scope),'new71_source_scope_sha256':hashlib.sha256(scope).hexdigest(),'source_scope_terminal_LF':False,
 'full_Gitblob_readbacks':readbacks,'source_commit_branch_created_ONCE':True,'carrier_transport':transport,
 'saved_input_bindings':len(bindings),'original_STATIC10runtimepreproof_NULLs_immutable':static['runtime_preproof_UNMEASURED_NULLs'],
 'source_conditions19420_64efe_BYTEEXACT_REUSED_NOTreevaluated':True,'old_AST_reverse_Ruby_conditions_codec_9GBproof_model_body_NOTreplayed':True,
 'all71_sdkdirectories_DEFERRED':True,'actual_Actions_run_id_UNPERFORMED':None,'newSDK_INPUT_queries':0,'workflow_dispatches':0,
 'new_actual_sourcepublication_facts_SEPARATE_not_retrofill_STATIC_Sourcevalidation_NULLs':True,
 'original_Linux_Dart_PATH_env_argv_credentials_recipes_preserved_NOTadmitted':True,
 'full_original_raw_requests_returns_GitblobJSON_sourcebytes_private_fields_stattimes_FDcredentials_preserved_PRIVATE':True,
 'pointFD_bytewise_countSHA_close_Gitpack_tree_readback_NOTatomicABA_globalactorFD_originaldrivercredentials_access_effectiveABI_physicalEX_crash_admission':True,
 'no_Source20_runtime_edit_import_test_build_native_numerical_adoption_or_cleanup':True,'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipeEOF':None}
 js('FIRST-NEW71-source-publication-completion-receipt.json',receipt)
 old=CP.read_bytes();save('checkpoint-BEFORE-sourcepublication-complete-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_Actions_sourcepublication']=receipt;node['source_commit']=revision;node['parent_source']=v['parent_source'];node['branch']=v['new_branch']
 node['phase']='FIRST_NEW71_Actions_SOURCEPUBLISHED_BOTH_FULL_Gitblob_READBACKS_COMPLETE_NOdispatch_SDKquery_NOTadmitted'
 d['active_turn_status'].update(new_directory71_preparation='FIRST_sourcepublication_COMPLETE_BOTH_FULL_GitblobJSON_readbacks_NOdispatch_SDKquery_NOTadmitted',
 next='FIRST expresslydeclared originalworkflow265291183 nonnumerical directory71 dispatch afterreuseactual sourcepublication readback receipts/preflight metadata only. New39SOURCEfalse/new40true isnotactualSKIPs/admission. OriginalSTATIC10runtimeNULLs immutable/newactualruntimefacts separate. No oldsource-bodyreader-parser-proof-AST-reverse-model-SDKquery-Actions-acquisition-archive-numerical/schemaaudit replay/REST422retry; noSource20-runtimeadoption-build-native-cleanup. All71SDKdirsDEFERRED untilFIRSTactualdeclaredquery.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 lease.verify_identity()
 preview={k:val for k,val in receipt.items() if k not in ['directory','carrier_transport','original_STATIC10runtimepreproof_NULLs_immutable']}
 js('compact-completion-PRIVATE.json',preview);out=json.dumps(preview,ensure_ascii=True);assert len(out)<18000;print(out,flush=True)
