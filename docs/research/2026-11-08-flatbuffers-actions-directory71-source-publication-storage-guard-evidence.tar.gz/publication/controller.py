import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0610_STATIC_publication_EX',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
import os,stat,io,tarfile,gzip,datetime,subprocess
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P0=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1'
P=P0/'FIRST-sourcepublication-storage-publication-v1'
ST=P0/'FIRST-sourcepublication-storage-publication-parts-v1'
D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
manifest=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir(mode=0o700)
 def save(n,b):
  fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('publication-controller.py',sys.argv[2]);save('exact-input-fragment-manifest.json',json.dumps(manifest,ensure_ascii=True,indent=2));bindings=[];outputs=[];owners=[]
 statkeys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def md(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in statkeys},s.st_atime_ns
 def read(path,role,expected_bytes=None,expected_sha=None):
  b={'role':role,'path':str(path),'expected_bytes':expected_bytes,'expected_sha256':expected_sha,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd);nbytes=b['before']['st_size'];assert expected_bytes is None or nbytes==expected_bytes;save(role+'-pointFD-range-BEFORE-contentIO.json',json.dumps({'path':str(path),'same_open_FD':fd,'range':[0,nbytes],'expected_sha256':expected_sha,'original_full_private_stat_fields_preserved':True},indent=2));parts=[];count=0;h=hashlib.sha256()
   while count<nbytes:
    x=os.read(fd,min(65536,nbytes-count));assert x;parts.append(x);count+=len(x);h.update(x)
   raw=b''.join(parts);b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert b['before']==b['after'] and count==nbytes and (expected_sha is None or h.hexdigest()==expected_sha);b.update(bytes=count,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return raw,b
 def run(args,role):
  owner={'operation':role,'handle':None};owners.append(owner);save(role+'-intent-BEFORE-constructor.json',json.dumps({'argv':args,'cwd':str(D),'original_owner_registered_BEFORE_constructor':True},indent=2));p=subprocess.Popen(args,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);owner['handle']=p;save(role+'-creator.json',json.dumps({'pid':p.pid,'original_strong_handle_before_fallible_IO':True},indent=2));o,e=p.communicate();status=p.wait();save(role+'-stdout',o);save(role+'-stderr',e);r={'pid':p.pid,'signed_status':status,'stdout_eof':True,'stderr_eof':True,'same_original_wait':True,'wait_may_be_cached':True,'stdout_bytes':len(o),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_bytes':len(e),'stderr_sha256':hashlib.sha256(e).hexdigest()};save(role+'-completion.json',json.dumps(r,indent=2));assert status==0,(role,r);return o
 def write(name,raw):
  b={'name':name,'path':str(P/name),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(b);fd=os.open(P/name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd);n=0
   while n<len(raw):
    sent=os.write(fd,raw[n:n+65536]);assert sent>0;n+=sent
   os.fsync(fd);os.lseek(fd,0,os.SEEK_SET);n=0;h=hashlib.sha256();readback_parts=[]
   while n<len(raw):
    block=os.read(fd,min(65536,len(raw)-n));assert block and block==raw[n:n+len(block)];readback_parts.append(block);n+=len(block);h.update(block)
   b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert n==len(raw)==b['after']['st_size'] and h.hexdigest()==hashlib.sha256(raw).hexdigest() and (b['before']['st_dev'],b['before']['st_ino'])==(b['after']['st_dev'],b['after']['st_ino']);b.update(bytes=n,sha256=h.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(name+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return {'path':str(P/name),'bytes':b['bytes'],'sha256':b['sha256']},b''.join(readback_parts)

 DOC="# PR #132: directory71 source publication and local dispatch guard\n\nThe prepared source was published once on a separate Actions preparation branch. Commit 32ab37e14b8ab6e8a908426ef2ad07c37f1f27db has original parent 5a187768a0cb8ec1caa325ecb62bba4e7996efed and atomic two-file tree 5a17f265f473a5899dc6d5d5bfeec3848b4be9d0. The PR remains open/draft and unchanged.\n\nNine actual saved inputs were bound before publication. An isolated, newly owned bare-Git carrier transported only the unchanged 79,775,955-byte collector (d960371450a3d235577b84de7777922b1bbf5d9c240297932deeab2ff216947c); it contained no workflow and establishes no runtime cohort/admission. Full local Git-object readback matched every source byte. The separate workflow remains 489,851 bytes (dcbcba1e7c5940a796c93cccc04ace777842ccf12832c74c2a2ab8ea5b6fe83f). No failed collector REST POST was retried.\n\nBoth complete Git-blob JSON bodies were saved and decoded before any prospective dispatch. Collector Git blob fbda02b68301bbfba5167e173f4e0c1736fcf631 returned 109,913,843 JSON bytes (e2632fa13de5fa695832b2fd239d819bcbc0634556aeac15a7796bd77b961e6e); all 79,775,955 decoded bytes matched. Workflow blob eb7ea8512ceb7a7b98370ae6f4fb6b6b617f8c4d returned 675,211 JSON bytes (ba0d2e343f07c1feee53cceb8cf582d689d5a6f4af70093dc81cffcb2fbe3282); all 489,851 decoded bytes matched. Contents responses served only as path/object locators. These are saved CLI response bytes, not HTTP-wire measurements or atomic ABA/origin-chain proof.\n\nThe first dispatch controller stopped at its local storage guard: the saved free-space point was 745,529,344 bytes, below its intact 1,073,741,824-byte floor. Native tool status was 1. This occurred before dispatch-input metadata I/O, checkpoint phase entry, any dispatch API call, run discovery or watch construction. No workflow was started and no new SDK directory query occurred. The entered failed namespace is permanently terminal; no reset, replay, relaunch, guard waiver, existing-artifact compression or cleanup followed. This local capacity observation does not establish application RAM peak, MemoryError, OOM, swapping, CI failure or a RAM repair.\n\nThe complete original parent-checkpoint snapshot and saved metadata remain private, unchanged and verbatim. A first inventory covered 162 entries in an owned saved-evidence directory, not an SDK directory. Nine prior Git receipt/request records and seven Actions request records were used only as metadata/templates; no old run, source body, SDK query, acquisition journal, proof or model was replayed. The initial parent locator's native body completed with status 0 and saved its full metadata result; its console exceeded the 6,000-token budget (reported 6,427). Full original stdout bytes/hash remain unretained/null. The complete saved result is not reconstructed stdout, and the reader was not repeated.\n\nGemma26868 delivered a new, distinct actual-count summary (signed 0, both EOF), not a retry or fallback for a consumed source review. ROOT corrects its wording: Git/source APIs did execute successfully; disk_usage successfully read and saved a capacity value, and the numeric guard then failed. This was not a storage read failure or an actual Actions pipeline failure. Generic framework/API/change-point prose is metadata-only advice and grants no edit, query, build, adoption, cleanup, retry or gate-waiver authority. All omitted counts/hashes and every original private field, stat time, FD/credential field, native order, duplicate, relationship and earlier null remain unchanged.\n\nBefore public projection, one new complete private metadata JSON stream, including all original input JSON values verbatim, passed whole compressed-copy/same-output-FD bytewise readback, whole decompressed strict-UTF-8 JSON-string equality and exhaustive ordered-structure/every-standard-Python-field equality, including duplicate keys, array positions and typed leaves. Raw gzip members are bounded chunks of one JSON document. The format was chosen prospectively for this new metadata artifact; no old artifact was compressed or deleted and no plaintext new result/copy was materialized. Encoding does not waive the failed dispatch guard or change SDK body transport, workload, GC, copies, cohort, schema or gates.\n\nOriginal workflow 265291183, Ubuntu24.04/Dart3.13.5/Rust1.99.0/PATH/env/argv/credentials/recipes and all 71 reference positions remain preserved, not admitted. The raw 94,092-byte SOURCE scope retains its original hash and no terminal LF. All 71 SDK directories remain deferred. Older links/epochs/ledgers and the ten original STATIC runtime preproof nulls remain immutable; future actual runtime facts must be separate. Point FD/stat/count/hash/close, Gitpack/tree and readback evidence do not establish global actor-FD ownership, original-driver credentials/access, effective ABI, continuous physical EX or crash admission.\n\nOnly the previously unentered dispatch/input/API/watch tail may progress later, after a fresh capacity point clears the unchanged floor and applicable preflight. A new namespace alone supplies no retry permission. No Source20/runtime edit/import/test/build/native/numerical/adoption work or cleanup occurred. All setup is unadmitted, flags false and ownership null; RAM repair, immutable runtime admission, own FINAL strict48/50 and clean final production CI remain incomplete. Preparation-only skip-ci never waives final CI.\n\nSee the [assessment](2026-11-08-flatbuffers-actions-directory71-source-publication-storage-guard-assessment.json) and [selected archive](2026-11-08-flatbuffers-actions-directory71-source-publication-storage-guard-evidence.tar.gz). The archive contains 27 regular members: 24 selected originals and three explicitly derived metadata files. It is not the full private directory, full raw Git responses, generated collector/runtime payload or an admitted Source20/runtime package.\n"
 SUMMARY="\n## 2026-11-08 — PR #132 source published; dispatch stopped before API\n\nOriginal Actions preparation source32ab37e14b8ab6e8a908426ef2ad07c37f1f27db was published once from parent5a187768a0cb8ec1caa325ecb62bba4e7996efed, with atomic two-file tree and BOTH full Git-blob JSON decoded-byte readbacks. Collector79,775,955 bytes and separate workflow489,851 bytes remain unchanged; Contents metadata was only a locator. No workflow was started: the first dispatch controller's saved745,529,344-byte local free-space point failed its intact1,073,741,824-byte guard before input metadata/CP phase entry/API/run/watch. That namespace is permanently terminal; no retry, reset, guard waiver or cleanup occurred. Only the unentered tail can later progress after fresh capacity clears the unchanged floor and applicable preflight. This is local storage data, not application RAM/OOM/CI-failure or repair evidence. All71 SDKdirs remain deferred; private fields/stat-times/FDcredentials/native order/duplicates/relationships and original STATIC10 preproof nulls remain unchanged, with future runtime facts separate. A first complete private metadata copy/UTF8 JSON-string/every-Python-field proof precedes public projection; no old source/proof/model/SDK/Actions acquisition was replayed. All setup remains unadmitted, flags false, ownership null; RAM repair, immutable admission, own FINAL strict48/50 and clean final CI remain incomplete. See [source publication and the saved guard failure](research/2026-11-08-flatbuffers-actions-directory71-source-publication-storage-guard.md).\n"

 payloadparts=[read(ST/('part-%04d.jsonpart'%row['part']),'payloadpart%04d'%row['part'],row['bytes'],row['sha256'])[0] for row in manifest]
 payloadraw=b''.join(payloadparts);assert len(payloadraw)==421261 and len(payloadraw.decode('utf-8','strict'))==421253
 v=json.loads(payloadraw);save('actual-available-whole-context-PRIVATE.json',payloadraw)
 pubdeclraw=json.dumps({'scope':v['scope'],'exact_metadata_inputs':v['inputs'],'selected_originals':v['selected_originals'],'new_result_format_chosen_BEFORE_FIRST_body_contentIO':'one complete JSON UTF8stream losslesslygzip rawmembers<=65536; alloldrawartifacts untouched/no plaintextNEWresult copies/deletion','no_failed_dispatch_retry_guardwaiver_or_cleanup':True,'all_admission_flags':False,'ownership':None},ensure_ascii=True,indent=2).encode();pubdeclrow,pubdeclback=write('publication-declaration.json',pubdeclraw)
 originals=[];cache={};allvalues=[]
 for row in v['inputs']:
  raw,binding=read(pathlib.Path(row['path']),row['role'],row['bytes'],row['sha256']);cache[row['path']]=(raw,binding);allvalues.append((row['role'],raw))
 values={role:json.loads(raw) for role,raw in allvalues}
 pub=values['NEW_sourcepublication_full_receipt'];failure=values['NEW_saved_local_storage_failure_assessment'];model=values['NEW_model_summary_completion']
 assert pub['source_commit']=='32ab37e14b8ab6e8a908426ef2ad07c37f1f27db' and len(pub['full_Gitblob_readbacks'])==2 and all(x['whole_decoded_BYTES_equal_actual_bound_SOURCE'] for x in pub['full_Gitblob_readbacks'])
 assert pub['workflow_dispatches']==0 and pub['actual_Actions_run_id_UNPERFORMED'] is None
 assert failure['actual_saved_space_record_ALLfields_UNCHANGED']['free_bytes']==745529344 and failure['actual_saved_space_record_ALLfields_UNCHANGED']['floor_bytes']==1073741824 and failure['original_native_tool_status']==1 and failure['actual_dispatches_in_failed_body']==0
 assert model==v['ROOT_qualification']['actual_child_completion'] and model['signed_status']==0
 for i,row in enumerate(v['selected_originals']):
  if row['path'] in cache:raw,binding=cache[row['path']]
  else:raw,binding=read(pathlib.Path(row['path']),'selectedoriginal%02d'%i,row['bytes'],row['sha256']);cache[row['path']]=(raw,binding)
  originals.append((row['member'],raw,binding))
 selected_by_name={name:raw for name,raw,_ in originals}
 gitpush=json.loads(selected_by_name['sourcepublication/Gitpush-completion.json']);assert gitpush['pid']==25693 and gitpush['signed_status']==0 and gitpush['stdout_eof'] is True and gitpush['stderr_eof'] is True
 metadata={'scope':'FIRST sourcepublication actual readbacks and saved storageguard failure combined metadata; no oldquery/proof/body replay','all8_original_JSON_values_embedded_VERBATIM':True,
 'all_private_original_fields_stat_times_FDcredentials_nativeorder_duplicates_relationships_NULLs_unchanged':True,
 'actual_input_bindings_PRIVATE':bindings,'original_Gitpush_completion_ALLfields':gitpush,'ROOT_model_qualification_ALLfields':v['ROOT_qualification'],
 'first_pub_locator_RAWlimit_original_UNCHANGED':v['original_locator_stdout_RAWlimit'],'all_admission_flags':False,'ownership':None}
 raw=(json.dumps(metadata,ensure_ascii=True,indent=2)[:-1]+',\n"actual_available_ROOT_context_JSON_value_VERBATIM":').encode()+payloadraw+b',\n"ALL_original_metadata_JSON_values_VERBATIM":['
 for i,(role,value) in enumerate(allvalues):
  if i:raw+=b','
  raw+=b'{"role":'+json.dumps(role).encode()+b',"original_JSON_value":'+value+b'}'
 raw+=b']\n}'
 members=[];encoded_blocks=[];offset=0
 for i in range(0,len(raw),65536):
  block=raw[i:i+65536];member=gzip.compress(block,mtime=0);assert gzip.decompress(member)==block
  encoded_blocks.append(member);members.append({'encoded_start':offset,'encoded_end':offset+len(member),'raw_start':i,'raw_end':i+len(block)});offset+=len(member)
 compressed=b''.join(encoded_blocks)
 result,resultback=write('FIRST-full-sourcepublication-storage-metadata-original-PRIVATE.json.gz',compressed)
 copy,copyback=write('FIRST-full-sourcepublication-storage-metadata-copy-PRIVATE.json.gz',resultback)
 assert compressed==resultback==copyback
 for row in members:
  assert resultback[row['encoded_start']:row['encoded_end']]==copyback[row['encoded_start']:row['encoded_end']]
  assert gzip.decompress(copyback[row['encoded_start']:row['encoded_end']])==raw[row['raw_start']:row['raw_end']]
 decoded=gzip.decompress(copyback);assert decoded==raw
 text0=raw.decode('utf-8','strict');text1=decoded.decode('utf-8','strict');assert text0==text1 and json.loads(text0)==json.loads(text1)
 class ObjectPairs(list):pass
 def events(x):
  if isinstance(x,ObjectPairs):
   yield ('object_start',None)
   for key,value in x:yield ('key',key);yield from events(value)
   yield ('object_end',None)
  elif type(x) is list:
   yield ('array_start',None)
   for value in x:yield from events(value)
   yield ('array_end',None)
  else:yield ('atom_'+type(x).__name__,x)
 from itertools import zip_longest
 missing=object();counts={};total=0
 for a,b in zip_longest(events(json.loads(text0,object_pairs_hook=ObjectPairs)),events(json.loads(text1,object_pairs_hook=ObjectPairs)),fillvalue=missing):
  assert a is not missing and b is not missing and a==b;counts[a[0]]=counts.get(a[0],0)+1;total+=1
 proof={'encoded_original':result,'encoded_copy':copy,'decoded_JSON_bytes':len(raw),'decoded_JSON_sha256':hashlib.sha256(raw).hexdigest(),'decoded_UTF8_JSONSTRING_characters':len(text0),'gzip_members':len(members),
 'ALLcompressed_bytes_SAMEOUTPUTFD_BYTEWISE_readback_and_whole_decoded_BYTEWISE_UTF8JSONSTRING_EVERYstandardPythonfield_equal':True,
 'exhaustive_ordered_structure_duplicatekeys_arraypositions_typedleaves_ALLfield_counts':counts,'total_ordered_events':total,
 'all_original_private_fields_stattimes_FDcredentials_relationships_NULLs_unchanged':True,'all_before_public_projection':True,
 'no_oldoracle180_or_static_AST_reverse_conditions_codec_9GB_original4_62GB_proof_replay':True,'not_RAMrepair_existingartifact_compression_SDKbodytransport_cleanup_retry_guardwaiver_schemawaiver':True,'all_admission_flags':False,'ownership':None}
 proofraw=json.dumps(proof,ensure_ascii=True,indent=2).encode();proofrow,proofback=write('FIRST-whole-metadata-ALLfield-equality-proof.json',proofraw)
 layout={k:value for k,value in pub.items() if k not in ['directory','full_Gitblob_readbacks','original_STATIC10runtimepreproof_NULLs_immutable']}
 layout['classification']='EXPLICITLY_DERIVED_PUBLIC_METADATA_originals_UNCHANGED'
 layout['full_Gitblob_readbacks']=[{k:value for k,value in x.items() if k!='decoded_saved_output'} for x in pub['full_Gitblob_readbacks']]
 layout['original_STATIC10runtimepreproof_NULLs_immutable']=pub['original_STATIC10runtimepreproof_NULLs_immutable']
 qualification={'classification':'EXPLICITLY_DERIVED_PUBLIC_METADATA_originals_UNCHANGED','actual_failure_assessment_ALLfields':failure,
 'actual_Gitpush_completion_ALLfields':gitpush,'ROOT_model_qualification':v['ROOT_qualification'],
 'initial_parentlocator_full_stdout_RAW_UNRETAINED_limit':v['original_locator_stdout_RAWlimit'],
 'OWN_saved_artifact_inventory_entries':162,'saved_parent_Gitmetadata_templates':9,'saved_Actions_request_templates':7,
 'all_original_CP_bytes_fields_private_verbatim_wholecopy_unchanged':True,'no_old_SDK_QUERY_Actions_acquisition_model_proof_replay':True,
 'all_admission_flags':False,'ownership':None}
 proofsafe={k:value for k,value in proof.items() if k not in ['encoded_original','encoded_copy']}
 pubcontrol,pubcontrolbinding=read(P/'publication-controller.py','PUB_controller_first_archive_binding',len(sys.argv[2].encode()),hashlib.sha256(sys.argv[2].encode()).hexdigest())
 originals.extend([('publication/controller.py',pubcontrol,pubcontrolbinding),('publication/declaration.json',pubdeclback,None),('publication/whole-ALLfield-equality-proof.json',proofback,None)])
 selected=list(originals)
 for name,value in [('derived/sourcepublication.json',layout),('derived/storage-and-ROOT-qualification.json',qualification),('derived/whole-metadata-proof.json',proofsafe)]:
  b=json.dumps(value,ensure_ascii=True,indent=2).encode();save(name.replace('/','-'),b);selected.append((name,b,None))
 stream=io.BytesIO()
 with tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.PAX_FORMAT) as tar:
  for name,b,binding in selected:
   entry=tarfile.TarInfo(name);entry.size=len(b);entry.mode=0o600
   if binding is not None:
    point=binding['before'];entry.mode=point['st_mode']&0o7777;entry.uid=point['st_uid'];entry.gid=point['st_gid'];entry.mtime=point['st_mtime_ns']//1000000000;entry.pax_headers={'mtime':str(point['st_mtime_ns']//1000000000)+'.'+str(point['st_mtime_ns']%1000000000).zfill(9)}
   tar.addfile(entry,io.BytesIO(b))
 archive=stream.getvalue();archiverow,archiveback=write('FIRST-selected-sourcepublication-storage-evidence.tar.gz',archive);assert archiveback==archive
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  entries=tar.getmembers();assert len(entries)==len(selected)
  for entry,(name,b,_) in zip(entries,selected):
   assert entry.isfile() and entry.name==name and entry.size==len(b);f=tar.extractfile(entry);assert f is not None;found=f.read();assert found==b and hashlib.sha256(found).hexdigest()==hashlib.sha256(b).hexdigest()
 assert len(selected)==27 and len(originals)==24
 base='2026-11-08-flatbuffers-actions-directory71-source-publication-storage-guard'
 refs=['docs/research/'+base+'.md','docs/research/'+base+'-assessment.json','docs/research/'+base+'-evidence.tar.gz','docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']
 assessment={'sourcepublication':layout,'failure_and_ROOT_qualification':qualification,'whole_original_metadata_proof':proofsafe,
 'private_result_encoded_bytes':result['bytes'],'private_result_encoded_sha256':result['sha256'],'copyproof_bytes':proofrow['bytes'],'copyproof_sha256':proofrow['sha256'],
 'archive':{'repository_ref':refs[2],'bytes':len(archive),'sha256':hashlib.sha256(archive).hexdigest(),'regular_selected':27,'original_selected':24,'EXPLICITLY_derived_metadata':3,
 'members':[{'position_ZERO_based':i,'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'kind':'EXPLICITLY_DERIVED_METADATA' if name.startswith('derived/') else 'selected_original_BYTEEXACT'} for i,(name,b,_) in enumerate(selected)],
 'not_full_raw_directory_generatedcollector_runtime_payload_or_Source20_runtime_package':True},
 'all_setup_UNADMITTED_RAMrepair_FINALstrict48_50_cleanfinalCI_INCOMPLETE':True,'all_admission_flags':False,'ownership':None}

 oldhead=run(['git','rev-parse','HEAD'],'Git01HEAD').decode().strip();branch=run(['git','branch','--show-current'],'Git02branch').decode().strip();status=run(['git','status','--porcelain=v1'],'Git03status')
 assert branch=='codex/flatbuffers-acceptance-status' and not status
 if oldhead!=v['expected_docs_HEAD']:
  run(['git','merge-base','--is-ancestor',v['expected_docs_HEAD'],oldhead],'Git04ancestor')
  changed=run(['git','diff','--name-only',v['expected_docs_HEAD']+'..'+oldhead],'Git05laterDOCSonly').decode().splitlines();assert changed and all(x.startswith('docs/') for x in changed)
 assert all(not (D/x).exists() for x in refs[:3])
 for path,b in [(refs[0],DOC.encode()),(refs[1],json.dumps(assessment,ensure_ascii=True,indent=2).encode()+b'\n'),(refs[2],archive)]:
  with (D/path).open('xb') as f:f.write(b)
 for i,path in enumerate(refs[3:]):
  before,binding=read(D/path,'DOCS_update%02d'%i);save('DOCS-before%02d-PRIVATE.md'%i,before)
  insert=SUMMARY if i==0 else SUMMARY.replace('(research/','(../research/')
  end=before.index(b'\n')+1
  with (D/path).open('wb') as f:f.write(before[:end]+insert.encode()+before[end:])
 run(['git','diff','--check'],'Git06diffcheck')
 status=run(['git','status','--porcelain=v1'],'Git07exact5').decode().splitlines();assert sorted(x[3:] for x in status)==sorted(refs)
 run(['git','add','--']+refs,'Git08add');assert sorted(run(['git','diff','--cached','--name-only'],'Git09staged').decode().splitlines())==sorted(refs)
 run(['git','diff','--cached','--check'],'Git10stagedcheck');run(['git','commit','-m','docs: record PR132 source publication and dispatch storage guard [skip ci]'],'Git11commit')
 head=run(['git','rev-parse','HEAD'],'Git12newHEAD').decode().strip();run(['git','push','github','codex/flatbuffers-acceptance-status'],'Git13push');assert not run(['git','status','--porcelain=v1'],'Git14clean')
 receipt={'docs_commit':head,'previous_docs_HEAD':oldhead,'DOCS_paths':refs,'archive_bytes':len(archive),'archive_sha256':hashlib.sha256(archive).hexdigest(),'regular_selected':27,'selected_originals':24,'EXPLICITLY_derived_metadata':3,
 'new_private_metadata_original':result,'new_private_metadata_decoded_bytes':len(raw),'new_private_metadata_decoded_sha256':hashlib.sha256(raw).hexdigest(),'new_private_metadata_UTF8_JSONSTRING_characters':len(text0),'gzip_members':len(members),
 'whole_ALLfield_proof':proofrow,'ordered_field_events':total,'sourcepublication_commit':pub['source_commit'],'Gitpush_original_completion':gitpush,
 'failed_dispatch_native_tool_status':1,'failed_dispatch_saved_free_bytes':745529344,'intact_storage_guard_bytes':1073741824,'workflow_dispatches':0,'run_id_UNPERFORMED':None,'new_SDKdirectory_queries':0,
 'all_original_private_fields_stattimes_FDcredentials_relationships_NULLs_UNCHANGED':True,'all_admission_flags':False,'ownership':None}
 save('FIRST-publication-completion-receipt.json',json.dumps(receipt,ensure_ascii=True,indent=2))
 CP=B/'current-task-checkpoint.json';old=CP.read_bytes();save('checkpoint-BEFORE-publication-facts-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_sourcepublication_storage_failure_publication']=receipt;node['FIRST_sourcepublication_storage_failure_model_ROOTqualification']=v['ROOT_qualification']
 node['phase']='COMPLETE_CONSUMED_NEW71_SOURCEPUBLICATION_BOTHfullreadbacks_FIRSTdispatch_STORAGEguard_failure_PUBLIC_DOCS_NOdispatch_SDKquery_NOTadmitted'
 d['docs_commit']=head;d['docs_status']={'worktree':str(D),'branch':'codex/flatbuffers-acceptance-status','head':head,'docs_only':True,'clean':True,'pushed_remote':'github'}
 d['active_turn_status'].update(new_directory71_preparation='SOURCEpublication_BOTHfullreadbacks_and_FIRSTdispatch_storageguard_failure_COMPLETE_CONSUMED_PUBLISHED_NOdispatch_SDKquery',
 next='FIRST remaining UNENTERED dispatch/input/API/watch tail ONLY afterfreshcapacity point clears unchanged1GiBguard/applicablepreflight. Failednamespace FOREVERterminal; no initialspacecheck/body/input-source-Gitreadback-proof-model-SDK-Actions-acquisition-archive replay, no guardwaiver/reset/redispatch/cleanup. All71SDKdirsDEFERRED/originalSTATICNULLs immutable/newfactsSEPARATE/allsetupUNADMITTED/noSource20-runtimeadoption-build-native-numerical. Freshcurrentstate maybe observed asnewpoint notcause-repair/authority. Keep samechat followup active/neverarchive.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(receipt,ensure_ascii=True),flush=True)
