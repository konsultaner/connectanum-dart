import pathlib,sys,json,hashlib,importlib.util,os,stat,datetime
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0642_FIRST_saved_dispatch_storage_failure_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-dispatch-storage-guard-failure-intake-v1'
F=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-originalActions71-dispatch-watch-v1/fresh-storage-point-BEFORE-nonnumerical-dispatch.json'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir(mode=0o700)
 def save(n,b):
  fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2])
 fd=os.open(F,os.O_RDONLY|os.O_NOFOLLOW);primary=None;binding={'path':str(F),'open_return_fd':fd,'close_return_fd':None,'file_EOF_probe':None}
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns']
 try:
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);binding['before']={k:getattr(s,k) for k in keys};nbytes=s.st_size;binding['range']=[0,nbytes]
  save('saved-space-record-point-BEFORE-IO-PRIVATE.json',json.dumps(binding,indent=2));count=0;parts=[];h=hashlib.sha256()
  while count<nbytes:
   b=os.read(fd,min(65536,nbytes-count));assert b;parts.append(b);count+=len(b);h.update(b)
  raw=b''.join(parts);s=os.fstat(fd);binding['after']={k:getattr(s,k) for k in keys}
  assert all(binding['before'][k]==binding['after'][k] for k in keys if k!='st_atime_ns');binding.update(bytes=count,sha256=h.hexdigest())
 except BaseException as e:primary=e;binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(fd);binding['close_return_fd']=fd
 except BaseException as e:
  binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('saved-space-record-binding-PRIVATE.json',json.dumps(binding,indent=2))
 if primary is not None:raise primary
 save('original-saved-free-space-record-BYTEEXACT.json',raw);space=json.loads(raw)
 assert space['floor_bytes']==1073741824 and space['free_bytes']<space['floor_bytes']
 result={'original_native_tool_status':v['actual_failed_native_tool_return']['exit_code'],'actual_saved_space_record_ALLfields_UNCHANGED':space,'source_record_bytes':len(raw),'source_record_sha256':hashlib.sha256(raw).hexdigest(),
 'source_publication_ALREADY_complete_commit':'32ab37e14b8ab6e8a908426ef2ad07c37f1f27db','BOTH_full_GitblobJSON_decodedBYTEEXACT_readbacks_ALREADY_complete':True,
 'dispatch_namespace_ENTERED_FOREVER_TERMINAL':True,'failure_BEFORE_CP_phase_entry_input_metadata_IO_or_ANY_API_dispatch':True,
 'actual_dispatches_in_failed_body':0,'run_id_UNPERFORMED':None,'watch_PID_UNPERFORMED':None,
 'no_guard_waiver_existingartifact_compression_deletion_cleanup_namespace_reset_or_relaunch':True,
 'source_body_static_codec_Actions_SDKquery_proofs_NOTreplayed':True,'local_storage_POINT_NOT_RAISE_MemoryError_OOM_swapping_CI_RAMcause_repair_or_ownership_admission':True,
 'all_original_private_fields_stat_times_FDcredentials_relationships_NULLs_unchanged':True,'all_admission_flags':False,'ownership':None}
 rawresult=json.dumps(result,ensure_ascii=True,indent=2).encode();save('FIRST-dispatch-storage-guard-failure-assessment-PRIVATE.json',rawresult)
 CP=B/'current-task-checkpoint.json';rawcp=CP.read_bytes();save('checkpoint-BEFORE-failure-facts-PRIVATE.json',rawcp);d=json.loads(rawcp);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_originalActions71_dispatch_failed_before_input_API']=result
 node['phase']='NEW71_SOURCEPUBLICATION_complete_BOTHreadbacks_DONE_FIRST_dispatch_STORAGEguard_failed_BEFORE_API_TERMINAL_noSDKquery'
 d['active_turn_status'].update(new_directory71_preparation='SOURCEpublished_BOTHreadbacks_DONE_FIRSTdispatch_local_storage_guard_failed_BEFOREinput_API_TERMINAL',
 next='Publish FIRSTnewsourcepublication and actualsaved localstorage-guard failure evidence. Failed dispatch namespace FOREVERterminal/no replay-reset-relaunch/guardwaiver/cleanup. Onlyunentered dispatch/input/API/watch tail maylaterproceed with intactfresh1GiB storage guard afteractualexternalcapacityclear andapplicablepreflight; no newnamespace-alone retry or Source20-runtimeadoption-build-native-numerical.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 lease.verify_identity();print(json.dumps({'assessment_bytes':len(rawresult),'assessment_sha256':hashlib.sha256(rawresult).hexdigest(),'result':result},ensure_ascii=True),flush=True)
