import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0642_FIRST_NEW71_originalActions_EX',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
import os,stat,subprocess,datetime,time,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-originalActions71-dispatch-watch-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir(mode=0o700)
 def save(n,b):
  fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 def js(n,x):save(n,json.dumps(x,ensure_ascii=True,indent=2))
 save('controller.py',sys.argv[2]);js('execution-declaration.json',v)
 js('original_actual_actor_environment_credentials-PRIVATE.json',{'uid':os.getuid(),'euid':os.geteuid(),'gid':os.getgid(),'egid':os.getegid(),'groups':os.getgroups(),'argv':sys.argv,'cwd':os.getcwd(),'environment':dict(os.environ),'not_original_remote_driver_or_globalownership_admission':True})
 free=shutil.disk_usage(B).free;js('fresh-storage-point-BEFORE-nonnumerical-dispatch.json',{'free_bytes':free,'floor_bytes':1073741824,'not_build_capture_deletion_authority':True});assert free>=1073741824
 CP=B/'current-task-checkpoint.json';old=CP.read_bytes();save('checkpoint-BEFORE-FIRST-dispatch-intake-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 assert node['phase']=='FIRST_NEW71_Actions_SOURCEPUBLISHED_BOTH_FULL_Gitblob_READBACKS_COMPLETE_NOdispatch_SDKquery_NOTadmitted'
 node['FIRST_originalActions71']={'phase':'FIRST_ENTERED_pre-dispatch_metadata_bindings_PENDING','directory':str(P),'native_OWNmetadata_PID':os.getpid(),'outer_PID_pipeEOF':None,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_directory71_preparation='FIRST_originalActions71_ENTERED_pre-dispatch_metadata_pending',next='ONLYSAMEoriginal NEW71 dispatch/watch session polls; no re-dispatch/relaunch/namespace reset/oldSDK-Actions-acquisition-model-proof replay. StaticNULLs immutable/newruntimefacts separate/allsetupUNADMITTED/noSource20-runtimeadoption-build-native-cleanup.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 bindings=[];outputs=[];owners=[]
 def md(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode)
  return {k:getattr(s,k) for k in dir(s) if k.startswith('st_') and type(getattr(s,k)) in (int,float)}
 def read(row):
  fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);primary=None;b={'role':row['role'],'path':row['path'],'open_return_fd':fd,'close_return_fd':None,'expected_bytes':row['bytes'],'expected_sha256':row['sha256'],'file_EOF_probe':None}
  bindings.append(b)
  try:
   before=md(fd);nbytes=before['st_size'];assert row['bytes'] is None or nbytes==row['bytes'];b.update(before=before,range=[0,nbytes]);js(row['role']+'-point-BEFORE-contentIO-PRIVATE.json',b)
   n=0;parts=[];h=hashlib.sha256()
   while n<nbytes:
    x=os.read(fd,min(65536,nbytes-n));assert x;n+=len(x);parts.append(x);h.update(x)
   raw=b''.join(parts);after=md(fd);b['after']=after
   assert all(before[k]==after[k] for k in before if k not in ['st_atime','st_atime_ns']) and (row['sha256'] is None or h.hexdigest()==row['sha256'])
   b.update(bytes=n,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  js(row['role']+'-INPUTFD-binding-PRIVATE.json',b)
  if primary is not None:raise primary
  return raw
 def write(name,raw):
  fd=os.open(P/name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);primary=None;b={'name':name,'open_return_fd':fd,'close_return_fd':None,'file_EOF_probe':None};outputs.append(b)
  try:
   before=md(fd);b['before']=before;n=0
   while n<len(raw):
    z=os.write(fd,raw[n:n+65536]);assert z>0;n+=z
   os.fsync(fd);os.lseek(fd,0,os.SEEK_SET);n=0;h=hashlib.sha256()
   while n<len(raw):
    x=os.read(fd,min(65536,len(raw)-n));assert x and x==raw[n:n+len(x)];n+=len(x);h.update(x)
   after=md(fd);b['after']=after;assert n==len(raw)==after['st_size'] and h.hexdigest()==hashlib.sha256(raw).hexdigest() and (before['st_dev'],before['st_ino'])==(after['st_dev'],after['st_ino'])
   b.update(bytes=n,sha256=h.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  js(name+'-OUTPUTFD-binding-PRIVATE.json',b)
  if primary is not None:raise primary
  return {'path':str(P/name),'bytes':b['bytes'],'sha256':b['sha256']}
 def run(args,role,input_bytes=None,require_zero=True):
  owner={'operation':role,'handle':None};owners.append(owner)
  js(role+'-request.json',{'argv':args,'cwd':str(P),'stdin_bytes':None if input_bytes is None else len(input_bytes),'stdin_sha256':None if input_bytes is None else hashlib.sha256(input_bytes).hexdigest(),'strong_original_owner_registered_BEFORE_constructor':True})
  p=subprocess.Popen(args,cwd=P,stdin=subprocess.PIPE if input_bytes is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);owner['handle']=p
  js(role+'-creator.json',{'pid':p.pid,'original_strong_handle_retained_BEFORE_fallible_IO':True})
  if role=='FIRST-watch-only-NEW71-originalActions-run':print(json.dumps({'original_watch_PID':p.pid}),flush=True)
  try:o,e=p.communicate(input=input_bytes);status=p.wait()
  except BaseException as ex:
   js(role+'-unknown-outcome-PRIVATE.json',{'kind':type(ex).__name__,'text':str(ex),'pid':p.pid,'signed_status':None,'stdout_EOF':None,'stderr_EOF':None,'no_relaunch_or_globalreap':True});raise
  save(role+'.stdout',o);save(role+'.stderr',e)
  completion={'pid':p.pid,'signed_status':status,'stdout_eof':True,'stderr_eof':True,'same_original_wait':True,'wait_may_be_cached':True,'stdout_bytes':len(o),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_bytes':len(e),'stderr_sha256':hashlib.sha256(e).hexdigest()}
  js(role+'-completion.json',completion)
  if require_zero:assert status==0,(role,completion)
  lease.verify_identity();return o,completion
 def api(method,endpoint,role,body=None):
  args=['gh','api','--hostname','github.com','--method',method,endpoint]
  if body is not None:
   raw=json.dumps(body,ensure_ascii=True,separators=(',',':')).encode();row=write(role+'-body.json',raw)
   js(role+'-body-file-binding-NOT_HTTPwire.json',row);args+=['--input',row['path']]
  return run(args,role)[0]

 raw_inputs={row['role']:read(row) for row in v['inputs']}
 for row in v['inputs']:write(row['role']+'-original-bound-PRIVATE.json',raw_inputs[row['role']])
 pub=json.loads(raw_inputs['new_sourcepublication_receipt_METADATA_only_NOTGitreadbackreplay'])
 scope=json.loads(raw_inputs['original_RAW71_SOURCE_fields_UNCHANGED'])
 templates=json.loads(raw_inputs['saved_old375_request_METADATA_TEMPLATES_ONLY_NOToldexecute'])
 assert pub['source_commit']==v['source_commit'] and pub['branch']==v['branch'] and pub['saved_input_bindings']==9
 assert pub['workflow_dispatches']==0 and pub['actual_Actions_run_id_UNPERFORMED'] is None
 assert len(pub['full_Gitblob_readbacks'])==2 and all(x['whole_decoded_BYTES_equal_actual_bound_SOURCE'] is True for x in pub['full_Gitblob_readbacks'])
 assert pub['collector_sha256']=='d960371450a3d235577b84de7777922b1bbf5d9c240297932deeab2ff216947c' and pub['workflow_sha256']=='dcbcba1e7c5940a796c93cccc04ace777842ccf12832c74c2a2ab8ea5b6fe83f'
 assert all(x is None for x in pub['original_STATIC10runtimepreproof_NULLs_immutable'].values())
 assert pub['all_admission_flags'] is False and pub['ownership'] is None
 rows=scope['ALL71_NEW_lexicaldirectory_TEXT_candidates'];assert len(rows)==71
 intended_refs=[x['NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child'] for x in rows]
 assert [x['new_directory_ordinal_ZERO_based'] for x in rows]==list(range(71)) and all(x['query_permission'] is None and x['alias_identity'] is None for x in rows)
 metadata={x['name']:x['original_JSON_all_fields_UNCHANGED'] for x in templates['all7_selected_original_metadata_bytes_fields_PRIVATEunchanged']}
 def oldargv(name):return list(metadata[name]['argv'])
 dispatch=oldargv('FIRST-dispatch-only-NEW375-great-great-great-grandchild-regular-inputs-request.json')
 assert dispatch[:7]==['gh','api','--hostname','github.com','--method','POST','repos/konsultaner/connectanum-dart/actions/workflows/265291183/dispatches'] and dispatch[-2]=='--input'
 body=write('FIRST-NEW71-original265291183-dispatch-body.json',json.dumps({'ref':v['branch'],'inputs':{'campaign':v['campaign']}},ensure_ascii=True,separators=(',',':')).encode())
 dispatch[-1]=body['path']
 before_dispatch=datetime.datetime.now(datetime.timezone.utc).isoformat();js('FIRST-original265291183-dispatch-intent.json',{'source_commit':v['source_commit'],'branch':v['branch'],'campaign':v['campaign'],'actual_time_before_dispatch':before_dispatch,'both_FULL_GitblobJSON_readbacks_complete_BEFORE_this_dispatch':True,'original_STATIC10preproof_NULLs_immutable_future_runtimefacts_SEPARATE':True,'all_admission_flags':False,'ownership':None})
 _,dispatch_completion=run(dispatch,'FIRST-single-NEW71-original265291183-dispatch')
 discovery_template=oldargv('FIRST-discover-NEW375-run-0-request.json')
 oldbranch='codex/pr132-actions-include-great-great-great-grandchild-regular-inputs-20261108'
 assert discovery_template[6].count(oldbranch)==1
 discovery_template[6]=discovery_template[6].replace(oldbranch,v['branch'],1)
 attempts=0;run_record=None
 while run_record is None:
  o,_=run(discovery_template,'FIRST-discover-NEW71-run-%d'%attempts);value=json.loads(o)
  matches=[x for x in value['workflow_runs'] if x['head_sha']==v['source_commit'] and x['event']=='workflow_dispatch' and x['head_branch']==v['branch'] and x['workflow_id']==265291183]
  assert len(matches)<=1
  if matches:run_record=matches[0];assert run_record['run_attempt']==1
  else:time.sleep(2)
  attempts+=1
 runid=run_record['id'];js('FIRST-actual-NEW71-run-identity-PRIVATE.json',run_record);print(json.dumps({'original_NEW71_run_id':runid,'source_commit':run_record['head_sha']}),flush=True)
 old=CP.read_bytes();save('checkpoint-BEFORE-watch-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_originalActions71']={'phase':'FIRST_DISPATCHED_ACTUAL_run_id_OBSERVED_ORIGINALwatch_PENDING','directory':str(P),'run_id':runid,'source_commit':v['source_commit'],'dispatch_completion':dispatch_completion,'new_runtime_fields_SEPARATE_from_immutable_STATIC_NULLs':True,'all_admission_flags':False,'ownership':None}
 node['run_id']=runid;d['active_turn_status']['next']='ONLYSAMEoriginal NEW71 watch session untilactualnaturalcompletion; no repoll-oldruns/redispatch/relaunch/namespace reset/SDKquery replay. OriginalSTATICNULLs immutable/notruntimeadmission.'
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 watch=oldargv('FIRST-watch-only-NEW375-run-request.json');assert watch[3]=='42434499630';watch[3]=str(runid)
 _,watch_completion=run(watch,'FIRST-watch-only-NEW71-originalActions-run',require_zero=False)
 def for_new_run(name):
  args=oldargv(name);assert args[6].count('42434499630')==1;args[6]=args[6].replace('42434499630',str(runid),1);return args
 jobs_raw,_=run(for_new_run('FIRST-new375-jobs-request.json'),'FIRST-NEW71-jobs-ONCE')
 jobs=json.loads(jobs_raw);matches=[x for x in jobs['jobs'] if x['name']==v['expected_job_name']];assert len(matches)==1
 job=matches[0];jobid=job['id'];assert job['run_id']==runid and job['head_sha']==v['source_commit']
 other=[x for x in jobs['jobs'] if x['id']!=jobid]
 counts={'actual_total_jobs':len(jobs['jobs']),'actual_old_jobs':len(other),'actual_old_skipped':sum(x['conclusion']=='skipped' for x in other),'new_job_conclusion':job['conclusion'],'new_job_status':job['status']}
 js('FIRST-actual-NEW71-job-counts-PRIVATE.json',counts)
 logs=oldargv('FIRST-new375-job-log-request.json');assert logs[6].count('128590360371')==1;logs[6]=logs[6].replace('128590360371',str(jobid),1)
 lograw,_=run(logs,'FIRST-NEW71-job-log-ONCE')
 artifacts_raw,_=run(for_new_run('FIRST-new375-artifact-list-request.json'),'FIRST-NEW71-artifact-metadata-list-ONCE')
 artifacts=json.loads(artifacts_raw)
 selected=[x for x in artifacts['artifacts'] if x['name']==v['expected_artifact_name']]
 # All artifact records remain in full original raw JSON. A selection is an expected output locator, not favorable SDK/cohort filtering.
 assert len(selected)<=1
 artifact=selected[0] if selected else None
 receipt={'phase':'FIRST_NEW71_originalActions_single_dispatch_watch_jobs_log_artifactMETADATA_COMPLETE_ARTIFACTZIP_UNQUERIED_NOTadmitted',
 'directory':str(P),'source_commit':v['source_commit'],'branch':v['branch'],'original_workflow_id':265291183,'run_id':runid,'job_id':jobid,'dispatch_count':1,'discovery_observations':attempts,
 'dispatch_actual_completion':dispatch_completion,'watch_actual_completion':watch_completion,'actual_job_counts':counts,
 'actual_ALL39_old_jobs_SKIPPED_40total':len(other)==39 and counts['actual_old_skipped']==39 and len(jobs['jobs'])==40,
 'actual_new_job_success':job['conclusion']=='success','artifact_original_all_fields_PRIVATE':artifact,
 'joblog_bytes':len(lograw),'joblog_sha256':hashlib.sha256(lograw).hexdigest(),
 'all_original_full_jobs_artifacts_log_request_return_fields_PRIVATE_unchanged':True,'all71_intended_scope_positions_nativeorder_duplicates_UNCHANGED':intended_refs,
 'actual_SDK_directory_observation_streams_counts_metadata_UNMEASURED_until_FIRSTartifactintake':None,
 'originalSOURCE_all71_DEFERRED_flags_UNCHANGED_historical_notretrofill':True,'STATIC10runtimepreproof_NULLs_immutable_newactualruntimefacts_SEPARATE':True,
 'original_oldreader_AST_reverse_conditions_codec_whole9GB_model_proofs_NOTreplayed':True,
 'artifactZIP_query_UNPERFORMED':None,'report_body_read_parse_UNPERFORMED':None,'new_candidate_compiler_or_headerbody_query':0,
 'no_Source20_runtime_edit_import_test_build_native_numerical_adoption_cleanup':True,
 'recipes_labels_toolversions_NOTeffectiveABI_originaldrivercredentials_access_ownership_physicalEX_crashadmission':True,
 'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipeEOF':None}
 js('FIRST-NEW71-dispatch-watch-completion-receipt-PRIVATE.json',receipt)
 old=CP.read_bytes();save('checkpoint-BEFORE-watch-completion-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_originalActions71']=receipt;node['job_id']=jobid;node['phase']='FIRST_NEW71_Actions_watch_COMPLETE_FIRSTartifactZIP_intake_PENDING_NOTadmitted'
 d['active_turn_status'].update(new_directory71_preparation='FIRST_originalActions71_watch_COMPLETE_ARTIFACTZIP_UNQUERIED_NOTadmitted',
 next='FIRST expresslydeclared acquisition of onlyNEW71 originalrun artifactZIP/report/journal/scope metadata. Reuse completed single265291183 dispatch/originalwatch/jobs/log/artifactlist and BOTHGitblobJSONreadbacks metadata ONLY/no repoll-redownload-redispatch-oldquery-proof-source-model replay. AlloriginalSTATICNULLs/sourceDEFERREDflags immutable/newactualruntimefacts SEPARATE; allsetupUNADMITTED/noSource20-runtime-build-native-numerical-adoption-cleanup.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 lease.verify_identity();print(json.dumps({k:value for k,value in receipt.items() if k not in ['all71_intended_scope_positions_nativeorder_duplicates_UNCHANGED','artifact_original_all_fields_PRIVATE','directory']}|{'artifact_locator':None if artifact is None else {k:artifact.get(k) for k in ['id','name','size_in_bytes','digest','expired','created_at','updated_at']}},ensure_ascii=True),flush=True)
