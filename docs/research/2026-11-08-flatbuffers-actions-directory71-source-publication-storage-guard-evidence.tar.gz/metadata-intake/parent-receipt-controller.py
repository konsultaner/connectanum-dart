import pathlib,sys,json,hashlib,importlib.util,os,stat
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0642_saved_parent_Gitmetadata_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-parent-source-receipt-metadata-v1'
A=B/'2026-11-08-actions-include-great-great-great-grandchild-regular-inputs-v1/FIRST-remaining-Git-transport-and-originalActions-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2]);bindings=[]
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns']
 def read(path,role,n,sha=None):
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);primary=None;b={'role':role,'path':str(path),'range':[0,n],'expected_sha256':sha,'open_return_fd':fd,'close_return_fd':None,'file_EOF_probe':None}
  try:
   s=os.fstat(fd);assert stat.S_ISREG(s.st_mode) and s.st_size==n;b['before']={k:getattr(s,k) for k in keys};save(role+'-point-BEFORE-contentIO.json',json.dumps(b,indent=2))
   count=0;parts=[];h=hashlib.sha256()
   while count<n:
    x=os.read(fd,min(65536,n-count));assert x;count+=len(x);h.update(x);parts.append(x)
   raw=b''.join(parts);s=os.fstat(fd);b['after']={k:getattr(s,k) for k in keys};assert all(b['before'][k]==b['after'][k] for k in keys if k!='st_atime_ns') and (sha is None or h.hexdigest()==sha);b.update(bytes=count,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-binding-PRIVATE.json',json.dumps(b,indent=2));bindings.append(b)
  if primary is not None:raise primary
  return raw
 inventory=json.loads(read(pathlib.Path(v['inventory']['path']),'OWN_inventory_METADATA',v['inventory']['bytes'],v['inventory']['sha256']))
 rows=inventory['ALL_original_native_order_names_namehex_statfields_UIDGID_retained'];declared=[]
 for name in v['selected_original_names']:
  matches=[row for row in rows if row['name']==name];assert len(matches)==1
  row=matches[0];assert stat.S_ISREG(row['lstat_no_follow']['st_mode'])
  declared.append({'name':name,'range':[0,row['lstat_no_follow']['st_size']],'original_inventory_record_UNCHANGED':row})
 save('exact-selected-metadata-ranges-BEFORE-contentIO-PRIVATE.json',json.dumps(declared,ensure_ascii=True,indent=2))
 out=[]
 for i,row in enumerate(declared):
  raw=read(A/row['name'],'saved_Gitmetadata%02d'%i,row['range'][1]);save('original%02d-%s'%(i,row['name']),raw)
  value=json.loads(raw);out.append({'name':row['name'],'original_JSON_all_fields_UNCHANGED':value,'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest()})
 result={'declaration':v,'all9_selected_original_metadata_bytes_fields_PRIVATEunchanged':out,'bindings':bindings,'not_old_source_reader_AST_condition_SDKquery_Actions_acquisition_streamhash_proof_replay':True,'all_admission_flags':False,'ownership':None}
 raw=json.dumps(result,ensure_ascii=True,indent=2).encode();save('FIRST-parent-publication-metadata-result-PRIVATE.json',raw)
 preview=[]
 for x in out:
  value=x['original_JSON_all_fields_UNCHANGED']
  if x['name']=='FIRST-new375-commit.stdout':
   assert value['sha']=='5a187768a0cb8ec1caa325ecb62bba4e7996efed'
   value={'sha':value['sha'],'tree':value['tree'],'parents':value['parents']}
  preview.append({'name':x['name'],'raw_bytes':x['raw_bytes'],'raw_sha256':x['raw_sha256'],'metadata':value})
 receipt={'result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'preview':preview,'all_admission_flags':False}
 save('completion-descriptor.json',json.dumps(receipt,ensure_ascii=True,indent=2));lease.verify_identity();text=json.dumps(receipt,ensure_ascii=True);assert len(text)<16000;print(text,flush=True)
