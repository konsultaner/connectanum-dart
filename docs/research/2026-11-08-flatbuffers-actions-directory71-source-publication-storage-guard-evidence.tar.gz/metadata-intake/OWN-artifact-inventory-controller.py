import pathlib,sys,json,hashlib,importlib.util,os,stat
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0642_parent_Gitreceipts_artifact_inventory_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-parent-source-receipt-inventory-v1'
source=B/'2026-11-08-actions-include-great-great-great-grandchild-regular-inputs-v1/FIRST-remaining-Git-transport-and-originalActions-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2])
 fd=os.open(source,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);primary=None;binding={'path':str(source),'open_return_fd':fd,'close_return_fd':None}
 def md(s):return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns']}
 try:
  before=os.fstat(fd);assert stat.S_ISDIR(before.st_mode);binding['before']=md(before);save('OWNartifact-directory-BEFORE-native-listdir-PRIVATE.json',json.dumps(binding,indent=2))
  names=os.listdir(fd);rows=[]
  for i,name in enumerate(names):
   s=os.stat(name,dir_fd=fd,follow_symlinks=False);rows.append({'position':i,'name':name,'name_hex':os.fsencode(name).hex(),'lstat_no_follow':md(s)})
  after=os.fstat(fd);binding['after']=md(after)
  assert (before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_nlink,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_nlink,after.st_mtime_ns,after.st_ctime_ns)
 except BaseException as e:primary=e;binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(fd);binding['close_return_fd']=fd
 except BaseException as e:
  binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('OWNartifact-directory-binding-PRIVATE.json',json.dumps(binding,indent=2))
 if primary is not None:raise primary
 result={'declaration':v,'ALL_original_native_order_names_namehex_statfields_UIDGID_retained':rows,'binding':binding,'no_SDK_INPUT_or_remoteGit_Actions_query':True,'all_admission_flags':False,'ownership':None}
 raw=json.dumps(result,ensure_ascii=True,indent=2).encode();save('FIRST-OWN-parent-source-receipt-inventory-PRIVATE.json',raw)
 receipt={'result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'entries':len(rows),'ALLnames_nativeorder':[x['name'] for x in rows],'not_SDKdirectory_query':True,'all_admission_flags':False}
 save('completion-descriptor.json',json.dumps(receipt,indent=2));lease.verify_identity();out=json.dumps(receipt,ensure_ascii=True);assert len(out)<18000;print(out,flush=True)
