require 'yaml'
require 'json'
require 'digest'
v=JSON.parse(File.binread(ARGV[0]))
base=File.binread(v.fetch('parent_path'))
candidate=File.binread(v.fetch('candidate_path'))
raise unless Digest::SHA256.hexdigest(base)==v.fetch('parent_sha256')
old=YAML.load(base);fresh=YAML.load(candidate)
oldjobs=old.fetch('jobs');newjobs=fresh.fetch('jobs')
raise unless oldjobs.size==39 && newjobs.size==40
newkey=v.fetch('new_job_key');oldkey=v.fetch('template_job_key')
raise if oldjobs.key?(newkey)
raise unless oldjobs.all?{|key,value|newjobs.fetch(key)==value}
rest=Marshal.load(Marshal.dump(fresh));rest.fetch('jobs').delete(newkey)
onkey=rest.key?('on') ? 'on' : true
opts=rest.fetch(onkey).fetch('workflow_dispatch').fetch('inputs').fetch('campaign').fetch('options')
raise unless opts.count(v.fetch('new_campaign'))==1
opts.delete(v.fetch('new_campaign'))
raise unless rest==old
raise unless candidate.delete_suffix(v.fetch('appended_block')).sub(v.fetch('new_choice_line'),'')==base
job=newjobs.fetch(newkey)
oldjob=oldjobs.fetch(oldkey)
raise unless job.fetch('runs-on')==oldjob.fetch('runs-on') && job.fetch('env')==oldjob.fetch('env') && job.fetch('timeout-minutes')==oldjob.fetch('timeout-minutes') && job.fetch('concurrency')==oldjob.fetch('concurrency')
raise unless job.fetch('steps').select{|s|s['uses']=='dart-lang/setup-dart@v1'}.map{|s|s.fetch('with')}==oldjob.fetch('steps').select{|s|s['uses']=='dart-lang/setup-dart@v1'}.map{|s|s.fetch('with')}
raise unless job.fetch('steps').select{|s|s['uses'].is_a?(String)&&s['uses'].start_with?('dtolnay/rust-toolchain@')}.map{|s|s.fetch('uses')}==oldjob.fetch('steps').select{|s|s['uses'].is_a?(String)&&s['uses'].start_with?('dtolnay/rust-toolchain@')}.map{|s|s.fetch('uses')}
scripts=job.fetch('steps').select{|s|s['run'].is_a?(String)&&s['run'].include?(v.fetch('new_collector_ref'))}
raise unless scripts.size==1
upload=job.fetch('steps').select{|s|s['uses'].is_a?(String)&&s['uses'].start_with?('actions/upload-artifact@')}
raise unless upload.size==1 && upload[0].fetch('with').fetch('path')==v.fetch('new_uploader_sink')
raise unless candidate.bytesize<500000 && candidate.bytesize<512000
puts JSON.generate({'NEW71_SOURCE_old39_new40_jobs_preserved'=>true,'ALL39_old_job_fields_UNCHANGED'=>true,'ALL_original_topfields_preserved_except_NEW71_campaign_option'=>true,'whole_original_workflow_BYTEEXACTreverse_for_NEW71candidate'=>true,'new_job_recipes_versions_env_argv_source_refs_uploader_MATCH'=>true,'workflow_bytes'=>candidate.bytesize,'workflow_sha256'=>Digest::SHA256.hexdigest(candidate),'NEW39_SOURCEconditions_not_yet_evaluated'=>true,'NEW40job_SOURCEguard_not_yet_evaluated'=>true,'original_parsed_jobs33_STALE_and_inherited_all199_label_UNMODIFIED'=>true,'ALL39_original_if_text_for_FIRST_NEW71_campaign_question'=>oldjobs.map{|key,j|{'job'=>key,'if'=>j['if']}},'NEW40_if_text'=>job['if'],'no_actual_Actions_runtime_admission'=>true})
