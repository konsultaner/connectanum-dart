import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0417_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,gzip,base64,ast,datetime,subprocess,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/source-generation-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v['declaration'],ensure_ascii=True,indent=2));save('controller.py',sys.argv[2]);save('actual-new-generation-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2))
 CP=B/'current-task-checkpoint.json';cpbefore=CP.read_bytes();save('checkpoint-before-sourcewriter.json',cpbefore);d=json.loads(cpbefore);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1'];node['FIRST_NEW71_sourcewriter']={'phase':'FIRST_ENTERED_newcandidate_proofs_PENDING_notadmitted','directory':str(P),'native_OWNmetadata_PID':os.getpid(),'separate_outer_PID_pipeEOF':None,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_directory71_preparation='FIRST_NEW71_SOURCEwriter_ENTERED_IN_PROGRESS_NOTadmitted',next='ONLYSAMEoriginal NEW71SOURCEwriter session waits/no relaunch-reset-originalnamespace/bodyreader-model-replays. No SDK_INPUT_IO-Source20-runtime-adoption-build-native-numerical-cleanup.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];bindings=[];outputs=[];owners=[]
 def md(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 def read(row):
  b={'role':row['role'],'path':row['path'],'range':[0,row['bytes']],'expected_sha256':row['sha256'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd);assert b['before']['st_size']==row['bytes'];parts=[];count=0;h=hashlib.sha256()
   while count<row['bytes']:
    block=os.read(fd,min(65536,row['bytes']-count));assert block;parts.append(block);count+=len(block);h.update(block)
   raw=b''.join(parts);b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert b['before']==b['after'] and h.hexdigest()==row['sha256'];b.update(bytes=count,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(row['role']+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  if row['decode_gzip']:
   decoded=gzip.decompress(raw);assert len(decoded)==row['decoded_bytes'] and hashlib.sha256(decoded).hexdigest()==row['decoded_sha256'] and len(decoded.decode('utf-8','strict'))==row['decoded_UTF8_characters'];return decoded
  return raw
 def write(name,raw):
  b={'name':name,'path':str(P/name),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(b);fd=os.open(P/name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd);n=0
   while n<len(raw):
    sent=os.write(fd,raw[n:n+65536]);assert sent>0;n+=sent
   os.fsync(fd);os.lseek(fd,0,os.SEEK_SET);n=0;h=hashlib.sha256()
   while n<len(raw):
    block=os.read(fd,min(65536,len(raw)-n));assert block and block==raw[n:n+len(block)];n+=len(block);h.update(block)
   b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert n==len(raw)==b['after']['st_size'] and h.hexdigest()==hashlib.sha256(raw).hexdigest() and (b['before']['st_dev'],b['before']['st_ino'])==(b['after']['st_dev'],b['after']['st_ino']);b.update(bytes=n,sha256=h.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(name+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return {'path':str(P/name),'bytes':b['bytes'],'sha256':b['sha256']}
 raw_inputs={row['role']:read(row) for row in v['declaration']['exact_saved_inputs']}
 source=raw_inputs['original29_directory_collector'];workflow=raw_inputs['current39job_workflow'];scope=raw_inputs['NEW71_publicsafe_SOURCE_scope'];packet=raw_inputs['NEW71_exact_wire_packet'];helper=raw_inputs['OWN_boundedJSON_CONTROL_source_copy_only_NOold180oracles'];old38raw=raw_inputs['original38PASSraw_BYTEEXACT_reuse_ONLY_NOreevaluation'];proof=json.loads(raw_inputs['NEW71_completed_codecproof_METADATA_only_NOTreexecute'])
 assert proof==v['original_completed_codecproof_ALLfields'] and proof['total_ordered_events']==28883414 and proof['ALL28720117_original_ordered_VALUES_retained']==28720117 and proof['ALL_original_runtime_bytes_equal_reconstructed_packet_wire'] is True and proof['exhaustive_ordered_structure_duplicatekeys_arraypositions_typedleaves_EVERYstandardPythonfield_equal'] is True
 assert v['original_runtime_final_tool_return_UNCHANGED']['exit_code']==0
 assert len(scope)==94092 and not scope.endswith(b'\n') and hashlib.sha256(scope).hexdigest()=='0556b6dd4da02409b69528e1647c93b8e80e9a01cad4d5ae7b078c98cb4fcf36'
 scope_object=json.loads(scope);scope_gz=gzip.compress(scope,mtime=0);assert gzip.decompress(scope_gz)==scope and gzip.decompress(scope_gz).decode('utf-8')==scope.decode('utf-8') and json.loads(gzip.decompress(scope_gz))==scope_object
 packet_b64=base64.b64encode(packet);assert base64.b64decode(packet_b64,validate=True)==packet
 source_text=source.decode('utf-8');oldfun=v['original_save_json_function_BYTES_UNCHANGED'].encode();assert source.count(oldfun)==1 and source.find(oldfun)==865348
 bounded_source=helper.decode('utf-8');assert 'class BoundedJSON' in bounded_source
 bounded_new=bounded_source.replace('BoundedJSON','NEW71_BoundedJSON')
 helpers='\n\n# FIRST NEW71 OWN metadata helpers; all original collector functions remain unchanged.\nimport gzip\nimport base64\nimport zlib\nimport codecs\n'+bounded_new+'\n'+v['new_exact_metadata_bytes_function']+'\n'+v['new_codec_classes']+'\n'+v['new_history_guard']+'\n'
 loader=v['new_loader_template']
 substitutions={'__NEW71_SCOPE_B64__':repr(base64.b64encode(scope_gz).decode('ascii')),'__NEW71_PACKET_B64__':repr(packet_b64.decode('ascii')),'__NEW71_PACKET_DESCRIPTOR__':repr(v['runtime_packet_descriptor']),'__NEW71_RUNTIME_DESCRIPTOR__':repr(v['runtime_original_descriptor']),'__NEW71_GROUPCOUNTS__':repr(v['all291groupcounts_UNCHANGED'])}
 for marker,replacement in substitutions.items():assert loader.count(marker)==1;loader=loader.replace(marker,replacement)
 assert '__NEW71_' not in loader
 oldroot=b'OUT = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-include-great-great-great-grandchild-directory-inputs"'
 newroot=b'OUT = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-include-great-great-great-grandchild-directory71-inputs"'
 assert source.count(oldroot)==1
 observations=v['saved_observations_line']['original_bytes'].encode();obspos=v['saved_observations_line']['absolute_source_offset'];assert source[obspos:obspos+len(observations)]==observations
 report_anchor=b'    written = save_json("include-great-great-great-grandchild-directory-inputs.json", report)\n';assert source.count(report_anchor)==1
 edits=[{'label':'NEW71_unique_OWN_output_namespace','start':source.index(oldroot),'old':oldroot,'new':newroot},{'label':'NEW71_helpers_AFTER_original_save_json_before_original_main','start':source.index(oldfun)+len(oldfun),'old':b'','new':helpers.encode()},{'label':'NEW71_loader_AFTER_all_old49_63_190_199_29guards_BEFORE_INPUTIO','start':obspos,'old':b'','new':loader.encode()},{'label':'NEW71_report_fields_separate_oldfields_unchanged','start':source.index(report_anchor),'old':b'','new':v['new_report_template'].encode()}]
 edits.sort(key=lambda x:x['start']);parts=[];cursor=0;length=0
 for edit in edits:
  assert cursor<=edit['start'] and source[edit['start']:edit['start']+len(edit['old'])]==edit['old'];prefix=source[cursor:edit['start']];parts.extend([prefix,edit['new']]);length+=len(prefix);edit['new_start']=length;length+=len(edit['new']);cursor=edit['start']+len(edit['old'])
 parts.append(source[cursor:]);candidate=b''.join(parts);reverse=candidate
 for edit in reversed(edits):
  start=edit['new_start'];assert reverse[start:start+len(edit['new'])]==edit['new'];reverse=reverse[:start]+edit['old']+reverse[start+len(edit['new']):]
 assert reverse==source and candidate.count(oldfun)==1 and candidate[candidate.index(oldfun):candidate.index(oldfun)+len(oldfun)]==oldfun
 plan=v['workflow_plan'];choice=plan['original_choice_line'].encode();addition=plan['additional_choice_line'].encode();assert workflow.count(choice)==1
 block=('\n'+plan['new_separate_jobblock']).encode();newworkflow=workflow.replace(choice,choice+addition,1)+block
 assert newworkflow[:-len(block)].replace(addition,b'',1)==workflow
 assert len(newworkflow)<500000 and len(newworkflow)<512000
 parentrow=write('parent39-workflow-PRIVATE.yml',workflow);collector=write('collector.py',candidate);workflowrow=write('candidate-wamp-profile-benchmarks.yml',newworkflow);blockrow=write('new-job-block.yml',block);sourcerow=write('NEW71-exact-public-safe-SOURCE-raw-noLF.json',scope);scopegzrow=write('NEW71-exact-public-safe-SOURCE-raw-noLF.json.gz',scope_gz);old38row=write('original38-SOURCEcondition-PASSraw-BYTEEXACT-reused-NOreevaluation.json',old38raw)
 maprows=[{'label':edit['label'],'original_range':[edit['start'],edit['start']+len(edit['old'])],'original_replaced_bytes_hex':edit['old'].hex(),'new_range':[edit['new_start'],edit['new_start']+len(edit['new'])],'new_inserted_bytes':len(edit['new']),'new_inserted_sha256':hashlib.sha256(edit['new']).hexdigest(),'all_full_original_and_NEW_source_bytes_private_retained':True} for edit in edits];save('FIRST-controlled-NEW71-patch-map-PRIVATE.json',json.dumps(maprows,indent=2))
 free=shutil.disk_usage(B).free;save('fresh-scoped-validation-floor-BEFORE_FIRST_newcandidate_AST.json',json.dumps({'free_bytes':free,'floor':1073741824,'not_build_or_capture_authority':True,'no_build_executed':True},indent=2));assert free>=1073741824
 tree=ast.parse(candidate.decode('utf-8'),filename=str(P/'collector.py'));definitions=[node.name for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))]
 assert all(definitions.count(name)==1 for name in ['save_json','NEW71_save_exact_metadata_bytes','NEW71_validate_owned_literal_history','NEW71_BoundedJSON','NEW71CompressedUTF8','NEW71PacketWire'])
 candidate_AST={'FIRST_NEW71_candidate_AST_syntax_PASS_NOTexec_eval_import_or_globals':True,'original_save_json_function_BYTEEXACT_UNCHANGED':True,'whole_original_collector_BYTEEXACTreverse_for_NEW71candidate':True,'old49_63_190_199_29scopes_separate_BEFORE_NEW71loader_BEFORE_INPUTIO':True,'new71_reference_count':len(scope_object['ALL71_NEW_lexicaldirectory_TEXT_candidates']),'exact_SOURCE_raw_bytes':len(scope),'exact_SOURCE_raw_sha256':hashlib.sha256(scope).hexdigest(),'SOURCE_terminal_LF':scope.endswith(b'\n'),'new_report71_fields':True,'all291groups_ALL28720117VALUES_from_completed_codecproof_NOTreexecuted':True,'new_imports_metadata_ONLY_not_effectiveABI_or_actorclosure':True};assert candidate_AST['new71_reference_count']==71;save('FIRST-NEW71-candidate-AST-source-preservation.json',json.dumps(candidate_AST,indent=2))
 rubyrow=write('NEW71-workflow-preservation-FIRST-new39-to40.rb',v['new_Ruby_validation_source'].encode())
 params={'parent_path':parentrow['path'],'parent_sha256':parentrow['sha256'],'candidate_path':workflowrow['path'],'new_job_key':'flatbuffers-include-great-great-great-grandchild-directory71-inputs','template_job_key':'flatbuffers-include-great-great-great-grandchild-directory-inputs','new_campaign':plan['new_campaign_value'],'appended_block':block.decode(),'new_choice_line':plan['additional_choice_line'],'new_collector_ref':'.github/collectors/pr132_include_great_great_great_grandchild_directory71_inputs.py','new_uploader_sink':'\x24{{ runner.temp }}/native-perf-include-great-great-great-grandchild-directory71-inputs'}
 save('NEW71-workflow-preservation-parameters.json',json.dumps(params,indent=2));args=['ruby',rubyrow['path'],str(P/'NEW71-workflow-preservation-parameters.json')];owner={'operation':'FIRST_NEW71_Ruby_workflow39to40_source_preservation','handle':None};owners.append(owner);save('generation-intent-BEFORE-constructor.json',json.dumps({'argv':args,'original_strong_owner_registered_BEFORE_Popen':True},indent=2));p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);owner['handle']=p;save('generation-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_fallible_IO':True},indent=2));print(json.dumps({'FIRST_NEW71_SOURCEwriter_Ruby_PID':p.pid}),flush=True)
 stdout,stderr=p.communicate();status=p.wait();save('generation.stdout',stdout);save('generation.stderr',stderr);completion={'pid':p.pid,'signed_status':status,'stdout_eof':True,'stderr_eof':True,'same_original_wait':True,'wait_may_be_cached':True,'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest()};save('generation-completion.json',json.dumps(completion,indent=2));assert status==0
 ruby=json.loads(stdout);assert ruby['NEW71_SOURCE_old39_new40_jobs_preserved'] is True and ruby['NEW39_SOURCEconditions_not_yet_evaluated'] is True
 validation={'phase':'FIRST_NEW71_COLLECTOR_WORKFLOW_SOURCEwriter_COMPLETE_AST_reverse_preservation_PASS_NEW39SOURCEconditions_PENDING_NOTadmitted','collector':collector,'workflow':workflowrow,'scope_raw':sourcerow,'scope_gzip':scopegzrow,'scope_gzip_base64_bytes':len(base64.b64encode(scope_gz)),'original38PASSraw_reused_BYTEEXACT_NOreevaluation':old38row,'codecproof_metadata_bytes':len(raw_inputs['NEW71_completed_codecproof_METADATA_only_NOTreexecute']),'codecproof_metadata_sha256':hashlib.sha256(raw_inputs['NEW71_completed_codecproof_METADATA_only_NOTreexecute']).hexdigest(),'completed28883414event_CODECproof_reused_NOTreexecuted':True,'packet_encoded_INPUT':v['runtime_packet_descriptor'],'runtime_original_binding':v['runtime_original_descriptor'],'ALL291original_groupcounts_UNCHANGED':v['all291groupcounts_UNCHANGED'],'ALL28720117ordered_VALUES_positions_duplicates_preserved':True,'original_PRIVATE9GBledger_fields_stat_times_FDcredentials_relationships_UNCHANGED':True,'source_AST':candidate_AST,'workflow_Ruby_preservation':ruby,'Ruby_actual_completion':completion,'source_INPUT_bindings':len(bindings),'new39SOURCEconditions_status_UNPERFORMED':None,'new40jobSOURCEguard_status_UNPERFORMED':None,'localSTATIC_runtime_preproof_status_UNPERFORMED':None,'source_commit':None,'run_id':None,'no_Source20_runtime_edit_import_test_build_native_adoption_SDKquery_Actions_numerical_cleanup':True,'all_admission_flags':False,'ownership':None}
 vr=json.dumps(validation,ensure_ascii=True,indent=2).encode();save('FIRST-NEW71-source-validation.json',vr);descriptor={'directory':str(P),'source_validation_bytes':len(vr),'source_validation_sha256':hashlib.sha256(vr).hexdigest(),'collector':collector,'workflow':workflowrow,'source_AST':candidate_AST,'Ruby_completion':completion,'NEW39_original_if_text_for_FIRST_NEW71_campaign_question':ruby['ALL39_original_if_text_for_FIRST_NEW71_campaign_question'],'NEW40_if_text':ruby['NEW40_if_text'],'new39SOURCEconditions_UNPERFORMED':None,'new40jobSOURCEguard_UNPERFORMED':None,'all_admission_flags':False,'ownership':None};save('FIRST-source-generation-descriptor.json',json.dumps(descriptor,indent=2))
 before=CP.read_bytes();save('checkpoint-before-source-validation-facts.json',before);d=json.loads(before);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1'];node['FIRST_NEW71_sourcewriter']=validation;node['phase']='FIRST_NEW71_SOURCEwriter_complete_AST_reverse_workflow_preservation_PASS_NEW39SOURCEconditions_PENDING_NOTadmitted';d['active_turn_status'].update(new_directory71_preparation='SOURCEwriter_complete_NEW39SOURCEfalse_and_new40guard_PENDING',next='FIRST NEW39SOURCEfalseconditions/new40SOURCEguard overactualNEW71workflow/source ONLY; old38PASSraw9102 BYTEEXACTreusedNOTreevaluated/originalRubyparsed33-inheritedall199labelUNCHANGED. ThenFIRSTnewsource-review/publication/localSTATICpreflight beforefutureGitBOTHreadbacks-dispatch; no originalreader-parser-wholecodec-proof-source_AST-reverse-model-SDKquery-Actions-acquisition-numerical/schemaaudit replays/allsetupUNADMITTED-noSource20runtimeadoption-native-cleanup.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 preview=json.dumps(descriptor,ensure_ascii=True);assert len(preview.encode())<40000;print(preview,flush=True);lease.verify_identity()
