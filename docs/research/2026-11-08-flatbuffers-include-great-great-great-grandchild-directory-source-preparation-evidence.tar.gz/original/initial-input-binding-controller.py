import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0311_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,codecs,gzip,shutil,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P0=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1';P=P0/'FIRST-exact-saved-preparation-input-bindings-v1';v=json.loads(sys.argv[1]);declaration=v['declaration']
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2))
 free=shutil.disk_usage(B).free;save('fresh-storage-POINT-NOTbuild-authority.json',json.dumps({'free_bytes':free,'declared_plain_input_bytes':sum(x['range'][1] for x in declaration['exact_saved_inputs']),'NEWcopies_losslessly_gzip_prospective_BEFOREinputIO':True,'existing_raw_evidence_UNCHANGED_NONDELETED':True}));assert free>=1073741824
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def snap(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 owners=[];outputs=[];bindings=[];copies=[];newscope=None;control=None
 class NewOutput:
  def __init__(self,path,role):
   owners.append(self);self.fd=None;self.path=path;self.binding={'role':role,'path':str(path),'encoding':'concatenated_gzip_members_ONE_complete_original_UTF8_BYTE_stream_NOT_claim_all_are_JSON','open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(self.binding);self.count=0;self.h=hashlib.sha256();self.compressed_count=0;self.compressed_h=hashlib.sha256();self.members=0;self.characters=0;self.decoder=codecs.getincrementaldecoder('utf-8')('strict');self.fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);self.binding['open_return_fd']=self.fd;self.binding['before'],self.binding['before_atime_ns_POINT_ONLY']=snap(self.fd)
  def emit(self,raw):
   if isinstance(raw,str):raw=raw.encode()
   for start in range(0,len(raw),65536):
    block=raw[start:start+65536];member=gzip.compress(block,mtime=0);sent=0
    while sent<len(member):
     n=os.write(self.fd,member[sent:]);assert n>0;sent+=n
    os.lseek(self.fd,self.compressed_count,os.SEEK_SET);parts=[];count=0
    while count<len(member):
     x=os.read(self.fd,len(member)-count);assert x;parts.append(x);count+=len(x)
    checked=b''.join(parts);assert checked==member and gzip.decompress(checked)==block
    self.compressed_h.update(member);self.compressed_count+=len(member);self.h.update(block);self.count+=len(block);self.members+=1;self.characters+=len(self.decoder.decode(block,final=False))
  def close(self):
   primary=None
   try:
    self.characters+=len(self.decoder.decode(b'',final=True));self.binding['after'],self.binding['after_atime_ns_POINT_ONLY']=snap(self.fd);assert self.binding['after']['st_size']==self.compressed_count
    self.binding.update(bytes=self.compressed_count,sha256=self.compressed_h.hexdigest(),decoded_original_bytes=self.count,decoded_original_sha256=self.h.hexdigest(),decoded_UTF8_characters=self.characters,gzip_members=self.members,SAMEOUTPUTFD_ALLcompressed_bytes_BYTEWISE_readback=True,EVERY_member_decoded_BYTEWISE_equal_to_original_input_raw_chunk=True,whole_original_input_UTF8_byte_stream_losslessly_retained=True)
   except BaseException as e:primary=e;self.binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
   try:os.close(self.fd);self.binding['close_return_fd']=self.fd
   except BaseException as e:
    self.binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
   save(self.binding['role']+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(self.binding,indent=2))
   if primary is not None:raise primary


 for source in declaration['exact_saved_inputs']:
  role=source['role'];size=source['range'][1];expected=source['sha256'];b={'role':role,'path':source['path'],'range':source['range'],'expected_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(source['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;count=0;h=hashlib.sha256();selected=[]
  out=NewOutput(P/(role+'-whole-original-PRIVATE.utf8.gz'),role+'-WHOLE_UTF8_COPY')
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==size
   while count<size:
    raw=os.read(fd,min(65536,size-count));assert raw;out.emit(raw);h.update(raw);count+=len(raw)
    if role in ['original29_directory_collector','NEW71_publicsafe_SOURCE_scope']:selected.append(raw)
   b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);assert b['before']==b['after'] and count==size and h.hexdigest()==expected;b.update(bytes=count,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  out.close();assert out.count==size and out.h.hexdigest()==expected;copies.append({'role':role,'original_path_UNCHANGED':source['path'],'original_range':source['range'],'original_sha256':expected,'NEW_whole_PRIVATE_copy_path':str(out.path),'encoded_bytes':out.compressed_count,'encoded_sha256':out.compressed_h.hexdigest(),'decoded_original_bytes':out.count,'decoded_original_sha256':out.h.hexdigest(),'decoded_UTF8_characters':out.characters,'gzip_members':out.members,'ALL_compressed_SAMEOUTPUTFD_BYTEWISE_readback_AND_decoded_BYTEWISE_equal_original_input_blocks':True,'no_existing_artifact_compression_or_deletion':True})
  if role=='original29_directory_collector':
   raw=b''.join(selected);assert len(raw)==34765001;head=raw[:2048];tail=raw[34745001:34765001];save('FIRST_NEW71_source-head-0-2048-PRIVATE.bytes',head);save('FIRST_NEW71_source-tail-34745001-34765001-PRIVATE.bytes',tail);hits=[];start=0
   while True:
    pos=raw.find(b'ROOT',start)
    if pos<0:break
    lo=max(0,pos-128);hi=min(size,pos+256);context=raw[lo:hi];hits.append({'literal_token_byte_offset_ZERO_based':pos,'exact_context_range':[lo,hi],'exact_context_bytes_hex':context.hex(),'context_count':len(context),'context_sha256':hashlib.sha256(context).hexdigest()});start=pos+1
   control={'source_bytes':size,'source_sha256':expected,'sourceprefix_opaque_except_NEW71_head_tail_ROOTcontexts':True,'head_range':[0,2048],'head_sha256':hashlib.sha256(head).hexdigest(),'tail_range':[34745001,34765001],'tail_sha256':hashlib.sha256(tail).hexdigest(),'ALL_literal_ROOT_token_occurrences_count':len(hits),'ALL_ROOT_token_positions_and_contexts_PRIVATE':hits,'old_AST_selector_parser_conditions_reverse_proofs_NOT_reexecuted':True};save('FIRST_NEW71_source-control-byte-selections-PRIVATE.json',json.dumps(control,indent=2))
  elif role=='NEW71_publicsafe_SOURCE_scope':
   raw=b''.join(selected);newscope=json.loads(raw);rows=newscope['ALL71_NEW_lexicaldirectory_TEXT_candidates'];assert len(rows)==71 and newscope['all71_directories_DEFERRED'] is True and newscope['all_admission_flags'] is False and newscope['ownership'] is None
   for i,row in enumerate(rows):
    assert row['new_directory_ordinal_ZERO_based']==i and row['original_mode_directory'] is True and row['NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child']==row['literal_parent_reference_SEPARATE_UNCHANGED']+'/'+row['literal_child_name_SEPARATE_UNCHANGED'] and row['query_permission'] is None and row['alias_identity'] is None
   save('FIRST_NEW71_literals_FROM_declared_SOURCE_unchanged.json',json.dumps({'all71_NEW_literal_TEXT_refs':[r['NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child'] for r in rows],'original_SOURCE_ALLfields_UNCHANGED':newscope,'qualification_against_actual_prior_consumption_ledgers_UNPERFORMED':None,'query_permission':None,'all_admission_flags':False,'ownership':None},ensure_ascii=True,indent=2))
 receipt={'phase':'FIRST_NEW71_11exact_savedinput_bindings_and_control_bytes_COMPLETE_CONSUMED_NOT_source_generation_or_admission','input_bindings':bindings,'NEWlossless_OWNartifact_wholecopy_descriptors':copies,'source_control_selection_PRIVATE':control,'NEW71_SOURCE_actual_candidates':len(newscope['ALL71_NEW_lexicaldirectory_TEXT_candidates']),'NEW71_SOURCE_bytes':94092,'NEW71_SOURCE_sha256':'0556b6dd4da02409b69528e1647c93b8e80e9a01cad4d5ae7b078c98cb4fcf36','old_metadata_topkeys_UNPERFORMED':None,'new71_prior_literal_qualification_UNPERFORMED':None,'original_source_AST_selector_syntax_conditions_reverse_proof_replays':0,'new_SDK_INPUT_queries':0,'source_commit':None,'run_id':None,'all_admission_flags':False,'ownership':None};save('FIRST-main-input-binding-completion-PRIVATE.json',json.dumps(receipt,ensure_ascii=True,indent=2))
 CP=B/'current-task-checkpoint.json';before=CP.read_bytes();save('checkpoint-before-input-binding-receipt.json',before);d=json.loads(before);d['actions_include_great_great_great_grandchild_directory71_preparation_v1']={'phase':'FIRST_11savedinputs_controlbytes_COMPLETE_CONSUMED_remaining_NEW71_qualification_sourcewriter_NOTentered','directory':str(P0),'input_binding_directory':str(P),'input_bindings':bindings,'whole_PRIVATE_copy_descriptors':copies,'NEW71_source_control_descriptor':control,'NEW71_SOURCE_candidates':71,'old_metadata_topkeys_UNPERFORMED':None,'new71_prior_literal_qualification_UNPERFORMED':None,'source_commit':None,'run_id':None,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_directory71_preparation='FIRST11savedinput_bindings_COMPLETE_CONSUMED_remaining_qualification_sourcewriter',next='FIRST remaining NEW71fullreference qualification against boundactualpriorconsumptionmetadata and NEWcollector-workflow generation ONLY; first11bindings/controlselection CONSUMED/notreexecute/no oldsource-AST-selector-parser-conditions-reverse proof replay/no SDK-Actions-bodyquery-bootstrap-dependency-build-native-numerical-Source20runtimeadoption-cleanup/allsetupUNADMITTED.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'input_bindings':len(bindings),'whole_original_raw_input_bytes':sum(x['range'][1] for x in declaration['exact_saved_inputs']),'NEWcopy_descriptors':copies,'NEW71_source_control_descriptor':control,'NEW71_SOURCE_candidates':71,'metadata_topkeys_and_prior_qualification_UNPERFORMED':None,'new_SDK_INPUT_queries':0,'all_admission_flags':False,'ownership':None},ensure_ascii=True),flush=True);lease.verify_identity()
