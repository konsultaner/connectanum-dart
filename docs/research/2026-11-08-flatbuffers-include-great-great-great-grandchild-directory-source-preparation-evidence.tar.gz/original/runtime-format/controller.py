import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0417_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,gzip,base64,codecs,types,contextlib,zlib,collections,itertools,datetime,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P0=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1';P=P0/'FIRST-NEW71-runtime-metadata-format-v1';v=json.loads(sys.argv[1]);declaration=v['declaration']
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(declaration,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));free=shutil.disk_usage(B).free;save('fresh-storage-POINT-NOTbuild-authority.json',json.dumps({'free_bytes':free,'NEWoutput_formats_prospective_before_original_ledger_IO':True,'no_existing_raw_evidence_compression_deletion':True}));assert free>=1073741824

 CP=B/'current-task-checkpoint.json';cpbefore=CP.read_bytes();save('checkpoint-before-FIRST-runtime-format.json',cpbefore);cp=json.loads(cpbefore);node=cp['actions_include_great_great_great_grandchild_directory71_preparation_v1'];node['FIRST_NEW71_runtime_metadata_exact_wire_format']={'phase':'FIRST_ENTERED_IN_PROGRESS_SOURCEwriter_NOTentered_finalstatus_UNMEASURED_NULL','directory':str(P),'native_OWNmetadata_controller_PID':os.getpid(),'separate_outer_launcher_PID_pipeEOF':None,'final_result':None,'original_PRIVATE_ledger_UNCHANGED':True,'all_admission_flags':False,'ownership':None};cp['active_turn_status'].update(new_directory71_preparation='FIRST_runtime_wire_format_IN_PROGRESS_SOURCEwriter_NOTentered',next='ONLY SAMEoriginal runtime-wire-format session polls; no relaunch-reset-namespace-alone-retry-globalPIDscan-kill-fullreap. Complete originalNEWruntime rawBYTEWISE/UTF8JSONSTRING/EVERYstandardPythonfield proof BEFOREFIRSTcollectorSOURCEwriter; oldqualification-wholeledgeridentity-CONSUMED. NoSDKquery-Source20runtimeadoption-build-native-numerical-cleanup/allsetupUNADMITTED.');cp['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cp['updated_at']=cp['updated_utc'];CP.write_text(json.dumps(cp,ensure_ascii=False,indent=2)+'\n')
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']
 def snap(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 bindings=[];owners=[];outputs=[];print(json.dumps({'FIRST_NEW71_runtime_metadata_format_PID':os.getpid(),'SOURCEwriter_NOTentered':True}),flush=True)
 def small_input(row,role):
  b={'role':role,**row,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;raw=b'';primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==row['range'][1]
   while len(raw)<row['range'][1]:
    x=os.read(fd,min(65536,row['range'][1]-len(raw)));assert x;raw+=x
   b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);b.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());assert b['before']==b['after'] and b['sha256']==row['sha256']
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return raw
 proof_raw=small_input(declaration['exact_completed_whole_ledger_proof'],'completed_wholeledger_proof_METADATA_ONLY_NOTreexecute');proof=json.loads(proof_raw);assert proof['total_ordered_events']==379622015 and proof['all_complete_BEFORE_publicprojection'] is True
 native=v['actual_original_wholeproof_tool_return_UNCHANGED'];assert native['exit_code']==0 and hashlib.sha256(native['output'].encode()).hexdigest()=='3043caf456cf371b0e3043b971fe09e7065fbb859f183e3e24e7cfe9200e20f6';original_rows=[json.loads(x) for x in native['output'].strip().split('\n') if x];assert original_rows[0]['FIRST_whole_original_DECODED_ALLfield_equality_PASS']==proof and original_rows[1]['FIRST_whole_ledger_identity_completion']['proof']==proof
 hb=small_input(declaration['auxiliary_OWNartifact_parser'],'auxiliary_OWNartifact_parser_ONLY');bj=types.ModuleType('pr132_FIRST_NEW71_runtime_metadata_format');bj.__file__=declaration['auxiliary_OWNartifact_parser']['path'];bj.__package__='';sys.modules[bj.__name__]=bj;exec(compile(hb,bj.__file__,'exec'),bj.__dict__)
 class NewOutput:
  def __init__(self,path,role):
   owners.append(self);self.fd=None;self.path=path;self.binding={'role':role,'path':str(path),'encoding':'concatenated_gzip_members_one_complete_UTF8_JSON_string','open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(self.binding);self.count=0;self.h=hashlib.sha256();self.compressed_count=0;self.compressed_h=hashlib.sha256();self.members=0;self.characters=0;self.decoder=codecs.getincrementaldecoder('utf-8')('strict');self.fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);self.binding['open_return_fd']=self.fd;self.binding['before'],self.binding['before_atime_ns_POINT_ONLY']=snap(self.fd)
  def emit(self,raw):
   if isinstance(raw,str):raw=raw.encode()
   if not hasattr(self,'pending_raw'):self.pending_raw=b''
   offset=0
   while offset<len(raw):
    take=min(65536-len(self.pending_raw),len(raw)-offset);self.pending_raw+=raw[offset:offset+take];offset+=take
    if len(self.pending_raw)==65536:
     self.member(self.pending_raw);self.pending_raw=b''
  def member(self,block):
   assert 0<len(block)<=65536
   member=gzip.compress(block,mtime=0);sent=0
   while sent<len(member):
    n=os.write(self.fd,member[sent:]);assert n>0;sent+=n
   os.lseek(self.fd,self.compressed_count,os.SEEK_SET);parts=[];count=0
   while count<len(member):
    x=os.read(self.fd,len(member)-count);assert x;parts.append(x);count+=len(x)
   checked=b''.join(parts);assert checked==member and gzip.decompress(checked)==block
   self.compressed_h.update(member);self.compressed_count+=len(member);self.h.update(block);self.count+=len(block);self.members+=1;self.characters+=len(self.decoder.decode(block,final=False))
  def close(self):
   primary=None
   try:
    if getattr(self,'pending_raw',b''):
     self.member(self.pending_raw);self.pending_raw=b''
    self.characters+=len(self.decoder.decode(b'',final=True));self.binding['after'],self.binding['after_atime_ns_POINT_ONLY']=snap(self.fd);assert self.binding['after']['st_size']==self.compressed_count
    self.binding.update(bytes=self.compressed_count,sha256=self.compressed_h.hexdigest(),decoded_JSON_bytes=self.count,decoded_JSON_sha256=self.h.hexdigest(),decoded_UTF8_characters=self.characters,gzip_members=self.members,SAMEOUTPUTFD_ALLcompressed_bytes_BYTEWISE_readback=True,EVERY_member_decoded_BYTEWISE_equal_to_original_NEW_JSON_stream_chunk=True,whole_original_NEW_JSON_stream_losslessly_retained=True)
   except BaseException as e:primary=e;self.binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
   try:os.close(self.fd);self.binding['close_return_fd']=self.fd
   except BaseException as e:
    self.binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
   save(self.binding['role']+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(self.binding,indent=2))
   if primary is not None:raise primary



 class CompressedUTF8:
  def __init__(self,fd,row):
   self.fd=fd;self.row=row;self.outer=0;self.oh=hashlib.sha256();self.generated=0;self.delivered=0;self.ih=hashlib.sha256();self.members=0;self.pending=b'';self.buffer=b'';self.chars=0;self.u=codecs.getincrementaldecoder('utf-8')('strict')
  def member(self):
   assert self.members<self.row['gzip_members'];d=zlib.decompressobj(31);parts=[];count=0
   while not d.eof:
    if not self.pending:
     assert self.outer<self.row['encoded_bytes'];x=os.read(self.fd,min(65536,self.row['encoded_bytes']-self.outer));assert x;self.outer+=len(x);self.oh.update(x);self.pending=x
    x=d.decompress(self.pending,65537-count);parts.append(x);count+=len(x);assert count<=65536;self.pending=d.unused_data if d.eof else d.unconsumed_tail
   self.buffer=b''.join(parts);self.members+=1;self.generated+=len(self.buffer);assert self.generated<=self.row['decoded_JSON_bytes'];self.ih.update(self.buffer);self.chars+=len(self.u.decode(self.buffer,final=False))
  def read(self,n):
   assert n>=0;n=min(n,self.row['decoded_JSON_bytes']-self.delivered);parts=[];count=0
   while count<n:
    if not self.buffer:self.member()
    take=min(n-count,len(self.buffer));assert take>0;parts.append(self.buffer[:take]);self.buffer=self.buffer[take:];count+=take
   self.delivered+=count;return b''.join(parts)
  def finish(self):
   self.chars+=len(self.u.decode(b'',final=True))
   assert self.generated==self.delivered==self.row['decoded_JSON_bytes'] and self.members==self.row['gzip_members'] and not self.buffer and not self.pending and self.outer==self.row['encoded_bytes'] and self.oh.hexdigest()==self.row['encoded_sha256'] and self.ih.hexdigest()==self.row['decoded_JSON_sha256'] and self.chars==self.row['decoded_UTF8_characters']
 @contextlib.contextmanager
 def compressed_input(row,role):
  b={'role':role,'path':row['path'],'outer_range':[0,row['encoded_bytes']],'outer_sha256':row['encoded_sha256'],'inner_range':[0,row['decoded_JSON_bytes']],'inner_sha256':row['decoded_JSON_sha256'],'members':row['gzip_members'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=snap(fd);assert b['before']['st_size']==row['encoded_bytes'];reader=CompressedUTF8(fd,row);yield reader,b;reader.finish();b['after'],b['after_atime_ns_POINT_ONLY']=snap(fd);assert b['before']==b['after'];b.update(outer_bytes=reader.outer,outer_sha256=reader.oh.hexdigest(),decoded_JSON_bytes=reader.delivered,decoded_JSON_sha256=reader.ih.hexdigest(),decoded_UTF8_characters=reader.chars,ALL_member_CRC_boundaries_checked=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
 def output_descriptor(out):
  return {'path':str(out.path),'encoded_bytes':out.compressed_count,'encoded_sha256':out.compressed_h.hexdigest(),'decoded_JSON_bytes':out.count,'decoded_JSON_sha256':out.h.hexdigest(),'decoded_UTF8_characters':out.characters,'gzip_members':out.members}
 class FragmentRecorder:
  def __init__(self,original,indices):
   self.original=original;self.indices=indices;self.table=[];self.index={};self.positions=0;self.indices.emit('[')
  def emit(self,raw):
   if isinstance(raw,str):raw=raw.encode('utf-8')
   if not raw:return
   self.original.emit(raw);i=self.index.get(raw)
   if i is None:i=len(self.table);self.index[raw]=i;self.table.append(raw)
   if self.positions:self.indices.emit(',')
   self.indices.emit(str(i));self.positions+=1
  def close(self):
   self.indices.emit(']\n');self.indices.close();self.original.close()
 class JSONEventOutput:
  def __init__(self,emit):self.emit=emit;self.stack=[];self.root=False
  def before(self):
   if not self.stack:assert not self.root;self.root=True;return
   f=self.stack[-1]
   if f['kind']=='array':
    if not f['first']:self.emit(',')
    f['first']=False
   else:assert f['pending'];f['pending']=False
  def key(self,value):
   f=self.stack[-1];assert f['kind']=='object' and not f['pending']
   if not f['first']:self.emit(',')
   f['first']=False;self.emit(json.dumps(value,ensure_ascii=True,separators=(',',':')));self.emit(':');f['pending']=True
  def start(self,kind):
   self.before();self.emit('{' if kind=='object' else '[');self.stack.append({'kind':kind,'first':True,'pending':False})
  def end(self,kind):
   f=self.stack.pop();assert f['kind']==kind and not f['pending'];self.emit('}' if kind=='object' else ']')
  def atom(self,value):self.before();self.emit(json.dumps(value,ensure_ascii=True,separators=(',',':')))
  def finish(self):assert self.root and not self.stack;self.emit('\n')
 class PacketWire:
  def __init__(self,compressed,packet_row,runtime_row):
   self.source=compressed;self.packet_row=packet_row;self.runtime_row=runtime_row;self.rr=bj.BoundedJSON(compressed.read,packet_row['decoded_JSON_bytes']);self.keys=self.rr.object_keys();self.table=[];self.position_count=0;self.generated=0;self.delivered=0;self.buffer=b'';self.h=hashlib.sha256();self.chars=0;self.u=codecs.getincrementaldecoder('utf-8')('strict');self.ended=False;seen=[]
   for key in self.keys:
    seen.append(key)
    if key=='encoding':assert self.rr.value()=='EXACT_UTF8_JSON_WIRE_FRAGMENTS_TABLE_ORDERED_POSITIONS_v1'
    elif key=='original_runtime_binding':
     self.binding=self.rr.value();assert self.binding['original_runtime']==runtime_row
    elif key=='table_b64':
     for encoded in self.rr.array_values():
      assert isinstance(encoded,str);raw=base64.b64decode(encoded,validate=True);assert raw;self.table.append(raw)
    elif key=='indices_ordered':self.indices=self.rr.array_values();break
    else:raise AssertionError(('unexpected_new_packet_header',key))
   assert seen==['encoding','original_runtime_binding','table_b64','indices_ordered'] and len(self.table)==self.binding['unique_wire_fragments']
  def next_fragment(self):
   assert not self.ended
   try:i=next(self.indices)
   except StopIteration:
    assert list(self.keys)==[];self.rr.finish();assert self.rr.bytes_read==self.packet_row['decoded_JSON_bytes'] and self.rr.digest.hexdigest()==self.packet_row['decoded_JSON_sha256'];self.ended=True;return False
   assert type(i) is int and 0<=i<len(self.table);raw=self.table[i];self.buffer=raw;self.position_count+=1;self.generated+=len(raw);assert self.generated<=self.runtime_row['decoded_JSON_bytes'];self.h.update(raw);self.chars+=len(self.u.decode(raw,final=False));return True
  def read(self,n):
   assert n>=0;n=min(n,self.runtime_row['decoded_JSON_bytes']-self.delivered);parts=[];count=0
   while count<n:
    if not self.buffer:assert self.next_fragment(),'early exact wire sequence end'
    take=min(n-count,len(self.buffer));assert take>0;parts.append(self.buffer[:take]);self.buffer=self.buffer[take:];count+=take
   self.delivered+=count;return b''.join(parts)
  def finish(self):
   assert not self.buffer and self.delivered==self.generated==self.runtime_row['decoded_JSON_bytes']
   if not self.ended:assert not self.next_fragment(),'extra original wire fragment'
   self.chars+=len(self.u.decode(b'',final=True));assert self.position_count==self.binding['ordered_wire_fragment_positions'] and self.h.hexdigest()==self.runtime_row['decoded_JSON_sha256'] and self.chars==self.runtime_row['decoded_UTF8_characters']

 raw_runtime=NewOutput(P/'NEW71-derived-runtime-metadata-original-PRIVATE.json.gz','FIRST_NEW71_original_runtime_JSON');index_output=NewOutput(P/'NEW71-ordered-wire-indices-original-PRIVATE.json.gz','FIRST_NEW71_original_wire_indices_JSON');recorder=FragmentRecorder(raw_runtime,index_output);writer=JSONEventOutput(recorder.emit)
 group_key='ALL_NEW_per_actual_source_topfield_groups_PRIVATE';records_key='ALL_original_string_SCALARVALUES_nativeorder_duplicates_locations_PRIVATE';input_stack=[];current_record=None;group_counts=[];total_values=0
 def takepath():
  if not input_stack:return []
  f=input_stack[-1]
  if f['kind']=='object':assert f['key'] is not None;p=f['path']+[f['key']];f['key']=None;return p
  p=f['path']+[f['index']];f['index']+=1;return p
 def record_path(path):
  return len(path)>=4 and path[0]==group_key and type(path[1]) is int and path[2]==records_key and type(path[3]) is int
 row=declaration['exact_whole_identity_checked_ledger_copy']
 with compressed_input(row,'FIRST_NEW71_runtime_projection_from_wholechecked_ledger') as (dr,b):
  rr=bj.BoundedJSON(dr.read,row['decoded_JSON_bytes'])
  for event,value in rr.document_events():
   if event=='key':
    f=input_stack[-1];assert f['kind']=='object';f['key']=value;path=f['path']+[value]
    if record_path(path):
     if len(path)==5:
      assert current_record is not None and value in ['original_scalar_ordinal_WITHIN_group_ZERO_based','original_source_JSON_field_location_UNCHANGED','original_scalar_value_UNCHANGED'];current_record['keys'].add(value)
     continue
    writer.key('literal_values' if len(path)==3 and path[0]==group_key and path[2]==records_key else value)
   elif event in ['object_start','array_start']:
    path=takepath();kind='object' if event=='object_start' else 'array';input_stack.append({'kind':kind,'path':path,'key':None,'index':0})
    if record_path(path):
     if len(path)==4:
      assert kind=='object' and current_record is None;current_record={'group':path[1],'ordinal':path[3],'keys':set(),'ordinal_seen':False,'value_seen':False}
     continue
    writer.start(kind)
    if path==[]:
     assert kind=='object';writer.key('NEW71_EXPLICITLY_DERIVED_runtime_METADATA_ONLY_projection_note');writer.atom(declaration['runtime_projection_note'])
    if len(path)==3 and path[0]==group_key and path[2]==records_key:
     assert kind=='array' and path[1]==len(group_counts);group_counts.append(0)
   elif event in ['object_end','array_end']:
    f=input_stack.pop();path=f['path'];kind='object' if event=='object_end' else 'array';assert f['kind']==kind
    if record_path(path):
     if len(path)==4:
      assert current_record is not None and current_record['keys']=={'original_scalar_ordinal_WITHIN_group_ZERO_based','original_source_JSON_field_location_UNCHANGED','original_scalar_value_UNCHANGED'} and current_record['ordinal_seen'] and current_record['value_seen'];group_counts[path[1]]+=1;current_record=None
     continue
    writer.end(kind)
   elif event.startswith('atom_'):
    path=takepath()
    if record_path(path):
     if len(path)==5 and path[4]=='original_scalar_value_UNCHANGED':
      assert event=='atom_str' and isinstance(value,str) and current_record is not None and not current_record['value_seen'];writer.atom(value);current_record['value_seen']=True;total_values+=1
     elif len(path)==5 and path[4]=='original_scalar_ordinal_WITHIN_group_ZERO_based':
      assert type(value) is int and value==path[3] and current_record is not None and not current_record['ordinal_seen'];current_record['ordinal_seen']=True
     continue
    writer.atom(value)
   else:raise AssertionError(('unexpected_original_document_event',event))
  assert not input_stack and current_record is None and rr.bytes_read==row['decoded_JSON_bytes'] and rr.digest.hexdigest()==row['decoded_JSON_sha256']
 assert len(group_counts)==291 and group_counts==v['original_291_groupcounts_UNCHANGED'] and total_values==28720117
 writer.finish();recorder.close();runtime_row=output_descriptor(raw_runtime);indices_row=output_descriptor(index_output)
 save('FIRST-derived-runtime-original-and-wire-index-descriptors.json',json.dumps({'runtime':runtime_row,'indices':indices_row,'unique_wire_fragments':len(recorder.table),'ordered_wire_fragment_positions':recorder.positions,'ALL291groupcounts_UNCHANGED':group_counts,'ALL28720117ordered_literal_VALUES_retained':total_values,'all_original_PRIVATE_ledger_fields_UNCHANGED':True},ensure_ascii=True,indent=2))
 packet=NewOutput(P/'NEW71-exact-wire-fragment-packet-original-PRIVATE.json.gz','FIRST_NEW71_original_exact_wire_packet_JSON');packet.emit('{"encoding":"EXACT_UTF8_JSON_WIRE_FRAGMENTS_TABLE_ORDERED_POSITIONS_v1","original_runtime_binding":');binding={'original_runtime':runtime_row,'unique_wire_fragments':len(recorder.table),'ordered_wire_fragment_positions':recorder.positions};packet.emit(json.dumps(binding,ensure_ascii=True,separators=(',',':')));packet.emit(',"table_b64":[')
 for i,fragment in enumerate(recorder.table):
  if i:packet.emit(',')
  packet.emit(json.dumps(base64.b64encode(fragment).decode('ascii')))
 packet.emit('],"indices_ordered":')
 save('NEW-generated-index-copy-range-countSHA-BEFORE-contentIO.json',json.dumps(indices_row,indent=2))
 with compressed_input(indices_row,'FIRST_new_ordered_indices_verbatim_embedding') as (dr,b):
  count=0
  while count<indices_row['decoded_JSON_bytes']:
   block=dr.read(min(65536,indices_row['decoded_JSON_bytes']-count));assert block;packet.emit(block);count+=len(block)
 packet.emit('}\n');packet.close();packet_row=output_descriptor(packet);save('FIRST-exact-wire-packet-descriptor.json',json.dumps({'packet':packet_row,'original_runtime':runtime_row,'original_indices':indices_row,'exact_projection_value_count':total_values,'exact_projection_groupcounts':group_counts,'byte_fragment_reuse_NOT_record_or_alias_dedup':True,'all_admission_flags':False,'ownership':None},ensure_ascii=True,indent=2))
 # FIRST exact reconstructed-wire BYTEWISE/UTF8STRING proof. Both complete originals remain private.
 with compressed_input(runtime_row,'FIRST_original_runtime_BYTEWISE_input') as (a,ba),compressed_input(packet_row,'FIRST_packet_BYTEWISE_input') as (p,bp):
  wire=PacketWire(p,packet_row,runtime_row);count=0;chars=0;u1=codecs.getincrementaldecoder('utf-8')('strict');u2=codecs.getincrementaldecoder('utf-8')('strict')
  while count<runtime_row['decoded_JSON_bytes']:
   n=min(65536,runtime_row['decoded_JSON_bytes']-count);x=a.read(n);y=wire.read(n);assert len(x)==len(y)==n and x==y;s1=u1.decode(x,final=False);s2=u2.decode(y,final=False);assert s1==s2;chars+=len(s1);count+=n
  x=u1.decode(b'',final=True);y=u2.decode(b'',final=True);assert x==y;chars+=len(x);wire.finish();assert chars==runtime_row['decoded_UTF8_characters']
 counts=collections.Counter()
 with compressed_input(runtime_row,'FIRST_original_runtime_ALLfield_events_input') as (a,ba),compressed_input(packet_row,'FIRST_packet_ALLfield_events_input') as (p,bp):
  wire=PacketWire(p,packet_row,runtime_row);r1=bj.BoundedJSON(a.read,runtime_row['decoded_JSON_bytes']);r2=bj.BoundedJSON(wire.read,runtime_row['decoded_JSON_bytes']);sentinel=object()
  for x,y in itertools.zip_longest(r1.document_events(),r2.document_events(),fillvalue=sentinel):
   assert x is not sentinel and y is not sentinel and x[0]==y[0] and type(x[1]) is type(y[1]) and x[1]==y[1];counts[x[0]]+=1
  wire.finish();assert r1.bytes_read==r2.bytes_read==runtime_row['decoded_JSON_bytes'] and r1.digest.hexdigest()==r2.digest.hexdigest()==runtime_row['decoded_JSON_sha256'] and r1.characters_consumed==r2.characters_consumed==runtime_row['decoded_UTF8_characters']
 codec_proof={'original_runtime':runtime_row,'packet':packet_row,'ALL_original_runtime_bytes_equal_reconstructed_packet_wire':True,'whole_UTF8JSONSTRING_characters_equal':True,'exhaustive_ordered_structure_duplicatekeys_arraypositions_typedleaves_EVERYstandardPythonfield_equal':True,'event_counts':dict(counts),'total_ordered_events':sum(counts.values()),'ALL291_original_groupcounts_preserved':group_counts,'ALL28720117_original_ordered_VALUES_retained':total_values,'ALL_original_positions_duplicates_retained_through_ordered_wire_indices_NOT_aliasdedup':True,'unique_wire_fragments':len(recorder.table),'ordered_wire_fragment_positions':recorder.positions,'entire_original_PRIVATE9GBledger_and_input_fields_stattimes_FDcredentials_relationships_UNCHANGED':True,'not_selected_schema_or_sample_equality_of_original_runtime_JSON':True,'complete_BEFORE_any_collector_source_adoption_or_public_projection':True,'no_old_oracle180_tests_or_wholeledger_proof_replays':True,'not_SDKbodytransport_source_runtime_workload_copy_GC_cohort_gate_change_RAMrepair_cleanup_retry_or_schemawaiver':True,'all_admission_flags':False,'ownership':None};save('FIRST-whole-runtime-wire-JSONSTRING-PythonALLfield-equality-proof.json',json.dumps(codec_proof,ensure_ascii=True,indent=2))
 result={'phase':'FIRST_NEW71_derived_runtime_exact_wire_format_COMPLETE_CONSUMED_SOURCEwriter_NOTentered_NOTadmitted','directory':str(P),'runtime_original':runtime_row,'packet_original':packet_row,'ordered_indices_original':indices_row,'codec_proof':codec_proof,'input_bindings':len(bindings),'original_PRIVATE_ledger_UNCHANGED':True,'no_new_plaintext_results_materialized_deleted':True,'no_Source20_runtime_edit_import_test_build_adoption_SDKquery_Actions_native_numerical_cleanup':True,'all_admission_flags':False,'ownership':None};save('FIRST-runtime-metadata-format-completion.json',json.dumps(result,ensure_ascii=True,indent=2))
 CP=B/'current-task-checkpoint.json';before=CP.read_bytes();save('checkpoint-before-runtime-format.json',before);d=json.loads(before);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1'];node['FIRST_NEW71_runtime_metadata_exact_wire_format']=result;node['phase']='FIRST_inputs_qualification_wholeledgeridentity_and_runtime_wire_format_COMPLETE_CONSUMED_SOURCEwriter_NOTentered';d['active_turn_status'].update(new_directory71_preparation='runtime_wire_format_COMPLETE_CONSUMED_SOURCEwriter_NOTentered',next='FIRST unentered NEW71collector/workflow SOURCEwriter fromexactqualifiedruntimepacket+unchangedSOURCE94092bytes. Allinitialbindings-qualification-wholeledgeridentity-runtimeformat-ALLfield-codecproof bodies CONSUMED/no replay. Preservealloldfunctions39jobs separate49/63/190/199/29beforeNEW71-loader-beforeINPUTIO/new39SOURCEfalse-new40guard-notactualadmission/parsed33-inheritedall199labelUNCHANGED/no Source20-runtimeadoption-SDKquery-build-native-numerical-cleanup/allsetupUNADMITTED.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=True),flush=True);lease.verify_identity()
