import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0417_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,re,datetime,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-NEW39campaign-SOURCE-condition-qualification-v1';v=json.loads(sys.argv[1]);declaration=v['declaration'];row=declaration['exact_saved_metadata_input']
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration-and-actual-root-context-PRIVATE.json',sys.argv[1]);save('controller.py',sys.argv[2]);free=shutil.disk_usage(B).free;save('fresh-scoped-floor-BEFORE_SOURCEcondition_validation.json',json.dumps({'free_bytes':free,'floor':1073741824,'NOTbuild_authority':True},indent=2));assert free>=1073741824
 binding={'path':row['path'],'range':[0,row['bytes']],'expected_sha256':row['sha256'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
 try:
  s=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];assert stat.S_ISREG(s.st_mode) and s.st_size==row['bytes'];binding['before']={k:getattr(s,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=s.st_atime_ns;parts=[];n=0
  while n<row['bytes']:
   x=os.read(fd,min(65536,row['bytes']-n));assert x;parts.append(x);n+=len(x)
  raw=b''.join(parts);assert hashlib.sha256(raw).hexdigest()==row['sha256'];z=os.fstat(fd);binding['after']={k:getattr(z,k) for k in keys};binding['after_atime_ns_POINT_ONLY']=z.st_atime_ns;assert binding['before']==binding['after']
 except BaseException as e:primary=e;binding['primary_error']={'kind':type(e).__name__,'text':str(e)}
 try:os.close(fd);binding['close_return_fd']=fd
 except BaseException as e:
  binding['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
  if primary is None:primary=e
 save('new-source-validation-INPUTFD-binding-PRIVATE.json',json.dumps(binding,indent=2))
 if primary is not None:raise primary
 data=json.loads(raw);assert v['actual_original_sourcewriter_final_return_UNCHANGED']['exit_code']==0 and data['workflow_Ruby_preservation']['NEW71_SOURCE_old39_new40_jobs_preserved'] is True
 rows=data['workflow_Ruby_preservation']['ALL39_original_if_text_for_FIRST_NEW71_campaign_question'];assert len(rows)==39
 class SourceCondition:
  def __init__(self,text):
   assert type(text) is str;self.original=text;self.tokens=[];position=0
   pattern=re.compile(r"\s*(\|\||&&|==|!=|\(|\)|'[^'\\]*'|[A-Za-z_][A-Za-z0-9_.]*)")
   while position<len(text):
    if not text[position:].strip():break
    match=pattern.match(text,position);assert match,('unsupported_source_token',position,text[position:position+80]);self.tokens.append(match.group(1));position=match.end()
   self.index=0
  def take(self,expected=None):
   assert self.index<len(self.tokens);value=self.tokens[self.index]
   if expected is not None:assert value==expected,(value,expected)
   self.index+=1;return value
  def peek(self):return self.tokens[self.index] if self.index<len(self.tokens) else None
  def primary(self):
   token=self.take()
   if token=='(':
    value=self.or_expr();self.take(')');return value
   if token.startswith("'"):return token[1:-1]
   if token=='github.event_name':return declaration['event_name']
   if token=='inputs.campaign':return declaration['campaign']
   if token=='always':
    self.take('(');self.take(')');return True
   raise AssertionError(('unsupported_source_identifier',token))
  def equality(self):
   left=self.primary()
   if self.peek() in ('==','!='):
    operator=self.take();right=self.primary();assert type(left) is type(right)
    return left==right if operator=='==' else left!=right
   return left
  def and_expr(self):
   left=self.equality();assert type(left) is bool
   while self.peek()=='&&':
    self.take('&&');right=self.equality();assert type(right) is bool;left=left and right
   return left
  def or_expr(self):
   left=self.and_expr()
   while self.peek()=='||':
    self.take('||');right=self.and_expr();assert type(right) is bool;left=left or right
   return left
  def result(self):
   value=self.or_expr();assert self.index==len(self.tokens) and type(value) is bool;return value
 results=[]
 for original in rows:
  result=SourceCondition(original['if']).result();assert result is False
  results.append({'original_job_UNCHANGED':original['job'],'original_if_text_UNCHANGED':original['if'],'NEW71_campaign_SOURCE_comparison_performed':True,'NEW71_campaign_SOURCE_condition_result':result,'not_actual_job_SKIP_observation_or_runtime_admission':True})
 newexpr=data['workflow_Ruby_preservation']['NEW40_if_text'];newresult=SourceCondition(newexpr).result();assert newresult is True
 proof={'scope_declaration_UNCHANGED':declaration,'source_workflow':data['workflow'],'source_collector':data['collector'],'ALL39_NEW71campaign_SOURCEcondition_results':results,'ALL39_NEW71campaign_SOURCEfalse_PASS':all(r['NEW71_campaign_SOURCE_condition_result'] is False for r in results),'NEW40_job_if_UNCHANGED':newexpr,'NEW40_job_SOURCEtrue_PASS':newresult,'NEW39_SOURCEcount':len(results),'NEW40_SOURCEtotaljobs':40,'always_builtin_TRUE_SOURCE_semantics_no_actions_execution':True,'all_tokens_consumed_no_eval_exec_import_globals_or_fallback':True,'original38PASSraw_BYTEEXACT_reused_NOreevaluation':data['original38PASSraw_reused_BYTEEXACT_NOreevaluation'],'original_source_validation_UNPERFORMED_NULL_fields_immutable_newfacts_SEPARATE':True,'original_parsed_jobs33_STALE_inherited_all199_label_UNMODIFIED':True,'actual_old_jobs_SKIPPED_UNMEASURED':None,'all_admission_flags':False,'ownership':None}
 out=json.dumps(proof,ensure_ascii=True,indent=2).encode();save('ALL39-NEW71campaign-SOURCEfalse-NEW40true-BEFOREdispatch.json',out)
 receipt={'directory':str(P),'original_sourcewriter_execsession':55611,'original_sourcewriter_tool_status':0,'original_sourcewriter_Ruby_PID':data['Ruby_actual_completion']['pid'],'original_sourcewriter_Ruby_signed_status':data['Ruby_actual_completion']['signed_status'],'original_sourcewriter_Ruby_BOTH_EOF':data['Ruby_actual_completion']['stdout_eof'] and data['Ruby_actual_completion']['stderr_eof'],'proof_bytes':len(out),'proof_sha256':hashlib.sha256(out).hexdigest(),'ALL39_SOURCEfalse_PASS':True,'NEW40_SOURCEtrue_PASS':True,'SOURCEcounts_NOT_actualSKIPs_or_admission':True,'actual_job_SKIPs_UNMEASURED':None,'collector':data['collector'],'workflow':data['workflow'],'source_validation_bytes':len(raw),'source_validation_sha256':hashlib.sha256(raw).hexdigest(),'all_admission_flags':False,'ownership':None};save('completion.json',json.dumps(receipt,indent=2))
 CP=B/'current-task-checkpoint.json';before=CP.read_bytes();save('checkpoint-before-source-condition-facts.json',before);d=json.loads(before);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1'];node['FIRST_NEW39_SOURCEfalse_NEW40true_NEW71campaign']=receipt;node['phase']='FIRST_NEW71_sourcewriter_AST_reverse_39to40_preservation_NEW39_SOURCEfalse_NEW40true_COMPLETE_CONSUMED_review_publication_STATIC_pending_NOTadmitted';d['active_turn_status'].update(new_directory71_preparation='FIRST_NEW71_SOURCEwriter_and_NEW39SOURCEfalse_NEW40true_COMPLETE_CONSUMED_review_publication_STATIC_pending',next='FIRST genuinelyNEWgenerated71collector-workflow SOURCEreview andpublication/localSTATICbeforefutureGitBOTHfullreadbacks-dispatch. Allinitialbindings-qualification-whole9GB-runtimecodec-sourcewriter-AST-reverse39to40-NEW39conditions bodies CONSUMED/no reexecution. Old38PASSraw9102 BYTEEXACTreused/originalparsed33-all199labelUNCHANGED. NoSDK-Actions-headerbody-directoryquery-build-native-numerical-Source20runtimeadoption-cleanup/allsetupUNADMITTED.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt));lease.verify_identity()
