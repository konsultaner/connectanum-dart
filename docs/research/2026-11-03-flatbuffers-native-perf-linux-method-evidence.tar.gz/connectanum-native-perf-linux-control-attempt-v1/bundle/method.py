#!/usr/bin/env python3
"""OWN unprivileged namespaced Linux method controls; never capture admission."""
import base64, fcntl, hashlib, json, os, select, signal, socket, stat, subprocess
import sys, time, traceback, types
from pathlib import Path

SOURCE = Path("/opt/control")
RAW = Path("/tmp/method")
PYTHON = "/usr/local/bin/python3.14"
sha = lambda b: hashlib.sha256(b).hexdigest()

def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.write("\n")

def emit(value):
    print(json.dumps(value, sort_keys=True, allow_nan=False), flush=True)

def file_sha(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256")
    return digest.hexdigest()

def checked_modules():
    manifest = json.loads((SOURCE / "manifest.json").read_bytes())
    for name, digest in manifest["all20source_sha256"].items():
        path = SOURCE / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022
        assert file_sha(path) == digest
    assert file_sha(SOURCE / "method.py") == manifest["method_sha256"]
    assert file_sha(Path(PYTHON)) == manifest["method_python_elf_sha256"]
    modules = {}
    for name in ("native_perf_guard", "native_perf_blocked_exec", "native_perf_handoff"):
        path = SOURCE / "tool" / (name + ".py")
        raw = path.read_bytes()
        assert sha(raw) == manifest["all20source_sha256"]["tool/" + name + ".py"]
        module = types.ModuleType(name)
        module.__file__ = str(path)
        sys.modules[name] = module
        exec(compile(raw, str(path), "exec"), module.__dict__)
        modules[name] = module
    return manifest, modules

def own_start(pid):
    raw = Path("/proc") / str(pid) / "stat"
    data = raw.read_bytes()
    # Actual production parser is used separately for the blocked READY comparison.
    end = data.rfind(b") ")
    assert end >= 0
    return data[end + 2:].split()[19].decode("ascii")

def pidfd_open(pid):
    fd = os.pidfd_open(pid, 0)
    assert not os.get_inheritable(fd)
    return fd

def pidfd_events(fd):
    poller = select.poll()
    poller.register(fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    return [[number, flags] for number, flags in poller.poll(0)]

def target(directory):
    directory = Path(directory)
    fds = []
    for name in Path("/proc/self/fd").iterdir():
        try:
            info = os.fstat(int(name.name))
        except OSError:
            continue
        fds.append({"fd": int(name.name), "mode": info.st_mode,
                    "device": str(info.st_dev), "inode": str(info.st_ino)})
    write_json(directory / "target.json", {
        "pid": os.getpid(), "parent_pid": os.getppid(), "start_ticks": own_start(os.getpid()),
        "uid": os.getuid(), "euid": os.geteuid(), "gid": os.getgid(), "egid": os.getegid(),
        "executable_sha256": file_sha(Path("/proc/self/exe")), "open_fds": fds,
        "argv": sys.argv, "capture_ready": False})
    return 0

def wait_blocked(child, record):
    while record["status"] is None:
        try:
            record["status"] = child.wait(5)
        except sys.modules["native_perf_guard"].GuardError as error:
            record.setdefault("bounded_waits", []).append(str(error))
            emit({"event": "owned_pending", "case": record["case"], "capture_ready": False})

def blocked_case(label, release, manifest, modules, actors):
    directory = RAW / label
    directory.mkdir(mode=0o700)
    guard = modules["native_perf_guard"]
    blocked = modules["native_perf_blocked_exec"]
    argv = [PYTHON, "-I", "-S", "-B", str(SOURCE / "method.py"), "target", str(directory)]
    policy = guard.FrozenLaunch.freeze(argv, dict(os.environ), 1000, 1000)
    nonce = manifest["case_nonces"][label]
    spec = blocked.BlockedSpec(policy, manifest["method_python_elf_sha256"],
        manifest["declaration_sha256"], nonce, directory, RAW, 10)
    record = {"case": label, "status": None, "release_intended": release, "go_attempted": False,
              "pid": None, "pidfd_before": None, "pidfd_after": None, "errors": []}
    actors.append(record)
    child = None
    pidfd = None
    with (directory / "child.log").open("xb") as log:
        try:
            child = blocked.start_blocked(spec, log.fileno())
            record["pid"] = child.pid
            ready = child.read_ready()
            (directory / "ready.raw").write_bytes(child.ready_bytes)
            write_json(directory / "ready.json", ready)
            assert ready["test_exec_callback"] is False
            assert ready["effective_uid"] == ready["effective_gid"] == 1000
            assert ready["parent_pid"] == os.getpid() and ready["pid"] == child.pid
            assert ready["driver_sha256"] == manifest["method_python_elf_sha256"]
            assert ready["environment_sha256"] == blocked.environment_hash(os.environ)
            assert str(ready["start_ticks"]) == own_start(child.pid)
            pidfd = pidfd_open(child.pid)
            record["pidfd_before"] = pidfd_events(pidfd)
            assert record["pidfd_before"] == []
            if release:
                marker = {"declaration_sha256": spec.declaration_sha256, "nonce": nonce}
                with (directory / "capture-consumed.json").open("xb") as stream:
                    stream.write(json.dumps(marker, sort_keys=True).encode() + b"\n")
                token = (spec.declaration_sha256 + ":" + nonce + "\n").encode("ascii")
                (directory / "method-go-token.raw").write_bytes(token)
                record["go_attempted"] = True
                guard._write_all(child.go_fd, token, os.write)
            child.close_go()
        except BaseException as error:
            record["errors"].append({"type": type(error).__name__, "reason": str(error),
                                     "traceback": traceback.format_exc()})
        finally:
            if child is not None:
                if child.go_fd >= 0:
                    # Method-only finite child: before any token this is negative EOF.
                    # After an attempted token keep ownership and wait naturally.
                    child.close_go()
                wait_blocked(child, record)
                if pidfd is not None:
                    record["pidfd_after"] = pidfd_events(pidfd)
                    os.close(pidfd)
                remaining = os.read(child.ready_fd, 8192)
                (directory / "ready-after.raw").write_bytes(remaining)
                os.close(child.ready_fd)
    if not record["errors"]:
        assert record["pidfd_after"] and record["status"] == (0 if release else 78)
        if release:
            result = json.loads((directory / "target.json").read_bytes())
            record["target"] = result
            assert result["pid"] == record["pid"]
            assert result["start_ticks"] == str(ready["start_ticks"])
            assert result["executable_sha256"] == manifest["method_python_elf_sha256"]
            assert {x["fd"] for x in result["open_fds"]} == {0, 1, 2}
        else:
            assert not (directory / "target.json").exists()
            assert not (directory / "capture-consumed.json").exists()
    write_json(directory / "result.json", record)
    assert not record["errors"], label + " control failed"
    return record

def handoff_client(directory, parent_pid):
    manifest, modules = checked_modules()
    handoff = modules["native_perf_handoff"]
    directory = Path(directory)
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    # This connection happens in this separately exec'ed Python image.
    sock.connect(str(directory / "wire.sock"))
    wire = handoff.HandoffWire.live(sock, expected_uid=1000, expected_gid=1000,
                                   expected_pid=int(parent_pid), timeout=10)
    endpoints = list(os.pipe()) + list(os.pipe())
    cr, cw, ar, aw = endpoints
    result = {"pid": os.getpid(), "start_ticks": own_start(os.getpid()),
              "peer": vars(wire.peer), "source": "actual_namespaced_kernel_credentials",
              "capture_ready": False, "status": None}
    try:
        with wire.once():
            wire.send_frame({"event": "method_offer", "nonce": manifest["case_nonces"]["handoff"],
                             "pid": os.getpid()})
            wire.send_rights((cw, ar))
            for fd in (cw, ar):
                endpoints.remove(fd)
                os.close(fd)
            wire.send_frame({"event": "method_copies_closed",
                             "nonce": manifest["case_nonces"]["handoff"]})
            poller = select.poll()
            poller.register(cr, select.POLLIN | select.POLLHUP)
            assert poller.poll(10000)
            assert os.read(cr, 16) == b"method-ping"
            os.write(aw, b"method-ack")
            result["status"] = 0
    finally:
        result["wire_evidence"] = wire.evidence
        write_json(directory / "client.json", result)
        sock.close()
        for fd in endpoints:
            os.close(fd)
    return 0

def handoff_case(manifest, modules, actors):
    directory = RAW / "handoff"
    directory.mkdir(mode=0o700)
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    listener.bind(str(directory / "wire.sock"))
    listener.listen(1)
    listener.settimeout(12)
    record = {"case": "handoff", "status": None, "pid": None, "errors": []}
    actors.append(record)
    process, pidfd, wire = None, None, None
    with (directory / "child.log").open("xb") as log:
        try:
            process = subprocess.Popen([PYTHON, "-I", "-S", "-B", str(SOURCE / "method.py"),
                "handoff-client", str(directory), str(os.getpid())],
                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                close_fds=True, cwd=RAW, env=dict(os.environ))
            record["pid"] = process.pid
            record["start_ticks"] = own_start(process.pid)
            pidfd = pidfd_open(process.pid)
            record["pidfd_before"] = pidfd_events(pidfd)
            assert record["pidfd_before"] == []
            connection, _ = listener.accept()
            wire = modules["native_perf_handoff"].HandoffWire.live(connection,
                expected_uid=1000, expected_gid=1000, expected_pid=process.pid, timeout=10)
            record["peer"] = vars(wire.peer)
            with wire.once():
                offer = wire.read_frame()
                assert offer == {"event": "method_offer",
                    "nonce": manifest["case_nonces"]["handoff"], "pid": process.pid}
                cw, ar = wire.read_rights()
                receipt = wire.read_frame()
                assert receipt == {"event": "method_copies_closed",
                    "nonce": manifest["case_nonces"]["handoff"]}
                record["received_fds"] = []
                for fd, direction in ((cw, os.O_WRONLY), (ar, os.O_RDONLY)):
                    info = os.fstat(fd)
                    assert stat.S_ISFIFO(info.st_mode)
                    assert fcntl.fcntl(fd, fcntl.F_GETFL) & os.O_ACCMODE == direction
                    assert not os.get_inheritable(fd)
                    record["received_fds"].append({"fd": fd, "direction": direction,
                        "device": str(info.st_dev), "inode": str(info.st_ino),
                        "noninheritable": True})
                assert (os.fstat(cw).st_dev, os.fstat(cw).st_ino) != (os.fstat(ar).st_dev, os.fstat(ar).st_ino)
                os.write(cw, b"method-ping")
                poller = select.poll()
                poller.register(ar, select.POLLIN | select.POLLHUP)
                assert poller.poll(10000)
                assert os.read(ar, 16) == b"method-ack"
        except BaseException as error:
            record["errors"].append({"type": type(error).__name__, "reason": str(error),
                                     "traceback": traceback.format_exc()})
        finally:
            if wire is not None:
                record["wire_evidence"] = wire.evidence
                wire.socket.close()
                for fd in list(wire.received_fds):
                    wire.received_fds.remove(fd)
                    os.close(fd)
            listener.close()
            if process is not None:
                while record["status"] is None:
                    try:
                        record["status"] = process.wait(5)
                    except subprocess.TimeoutExpired:
                        emit({"event": "owned_pending", "case": "handoff", "capture_ready": False})
                if pidfd is not None:
                    record["pidfd_after"] = pidfd_events(pidfd)
                    os.close(pidfd)
    write_json(directory / "result.json", record)
    assert not record["errors"] and record["status"] == 0 and record["pidfd_after"]
    client = json.loads((directory / "client.json").read_bytes())
    assert client["status"] == 0 and client["pid"] == process.pid
    return record

def publish_artifacts():
    records = []
    for path in sorted(RAW.rglob("*")):
        info = path.lstat()
        name = str(path.relative_to(RAW))
        if stat.S_ISREG(info.st_mode):
            assert info.st_size <= 2 * 1024**2
            data = path.read_bytes()
            record = {"event": "artifact", "path": name, "size": len(data),
                      "sha256": sha(data), "data_base64": base64.b64encode(data).decode("ascii")}
            emit(record)
            records.append({key: record[key] for key in ("path", "size", "sha256")})
        else:
            emit({"event": "special_metadata", "path": name, "mode": info.st_mode,
                  "device": str(info.st_dev), "inode": str(info.st_ino)})
    return records

def coordinator():
    RAW.mkdir(mode=0o700)
    actors, errors, results = [], [], []
    try:
        manifest, modules = checked_modules()
        assert sys.platform == "linux" and os.getuid() == os.geteuid() == os.getgid() == os.getegid() == 1000
        assert signal.getsignal(signal.SIGCHLD) == signal.SIG_DFL
        status = Path("/proc/self/status").read_bytes()
        (RAW / "coordinator-proc-status.raw").write_bytes(status)
        assert b"CapEff:\t0000000000000000\n" in status
        assert b"NoNewPrivs:\t1\n" in status
        write_json(RAW / "context.json", {"kind": "namespaced_unprivileged_method_only",
            "uname": list(os.uname()), "version": sys.version, "executable": sys.executable,
            "uid": os.getuid(), "gid": os.getgid(), "pid": os.getpid(),
            "start_ticks": own_start(os.getpid()),
            "namespaces": {n: os.readlink("/proc/self/ns/" + n) for n in
                ("pid", "mnt", "net", "user", "ipc", "uts", "cgroup")},
            "declaration_sha256": manifest["declaration_sha256"], "capture_ready": False})
        for label, release in (("fdexec-positive", True), ("pre-go-eof-negative", False)):
            results.append(blocked_case(label, release, manifest, modules, actors))
        results.append(handoff_case(manifest, modules, actors))
    except BaseException as error:
        errors.append({"type": type(error).__name__, "reason": str(error),
                       "traceback": traceback.format_exc()})
    write_json(RAW / "summary.json", {"scope": "namespaced_unprivileged_Linux_method_only",
        "capture_ready": False, "live_admission": False, "results": results,
        "known_actor_statuses": actors, "errors": errors})
    artifact_records = publish_artifacts()
    emit({"event": "method_footer", "capture_ready": False, "live_admission": False,
          "all_declared_cases_completed": len(results) == 3, "case_count": len(results),
          "errors": errors, "known_actor_statuses": [{"case": x["case"], "pid": x["pid"],
            "status": x["status"]} for x in actors], "artifacts": artifact_records})
    return 0 if len(results) == 3 and not errors else 1

if __name__ == "__main__":
    role = sys.argv[1]
    if role == "target":
        sys.exit(target(sys.argv[2]))
    if role == "handoff-client":
        sys.exit(handoff_client(sys.argv[2], sys.argv[3]))
    assert role == "coordinator"
    sys.exit(coordinator())
