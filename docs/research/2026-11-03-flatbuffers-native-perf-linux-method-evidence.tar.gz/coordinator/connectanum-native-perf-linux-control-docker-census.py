"""Read-only local Docker preparation. No image/container/VM/build/benchmark."""
from pathlib import Path
import sys,os,json,hashlib,types,shutil,re,stat,datetime,time
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');out=Path('/tmp').resolve()/'connectanum-native-perf-linux-control-docker-census'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(lease):
 lease.verify_identity();assert shutil.disk_usage(root).free>=1024**3
 cp=json.loads(Path('/tmp/connectanum-current-task-checkpoint.json').read_text());expected=cp['native_perf_only_diagnostic_design']['current_source_sha256']
 files={p:(root/p).read_bytes() for p in expected};assert {p:sha(b) for p,b in files.items()}==expected
 source=root/'tool/native_perf_build_producer.py';mod=types.ModuleType('docker_method_preparation');mod.__file__=str(source)
 exec(compile(files['tool/native_perf_build_producer.py'],str(source),'exec'),mod.__dict__)
 entry=shutil.which('docker');assert entry is not None
 entry=Path(entry);target=entry.resolve(strict=True);binary_sha=mod._regular_hash(target,owners={os.getuid(),0})
 env=dict(os.environ);overrides={k:bool(env.get(k)) for k in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']}
 out.mkdir(mode=0o700)
 declaration={'kind':'read-only-docker-local-context-preparation-v1','scope':'local method environment inquiry ONLY, not Linux/kernel/admission proof',
 'capture_ready':False,'producer_sha256':expected['tool/native_perf_build_producer.py'],'all20source_sha256':expected,
 'docker_entry':str(entry),'docker_target':str(target),'docker_read_sha256':binary_sha,'environment_sha256':sha(json.dumps(env,sort_keys=True,ensure_ascii=True).encode()),
 'target_override_presence_only':overrides,'command_templates':[[str(entry),'context','show'],[str(entry),'context','inspect','{same_context}'],[str(entry),'--context','{same_context}','version','--format','{{json .Server}}']],
 'remote_endpoints_refused':True,'no_image_pull_container_create_VM_or_build':True,'declared':now()}
 mod._write_json(out/'declaration.json',declaration);decl_sha=mod._regular_hash(out/'declaration.json');operations=[];records=[]
 def complete(status,reason,**fields):
  mod._write_json(out/'summary.json',{'kind':'read-only-docker-preparation-result-v1','capture_ready':False,'status':status,'reason':reason,
  'declaration_sha256':decl_sha,'records':records,'no_image_container_VM_build_or_kernel_control':True,'free_bytes':shutil.disk_usage(root).free,'finished':now(),**fields})
  print(json.dumps({'status':status,'reason':reason,'commands':len(records),'directory':str(out)}))
 def observe(name,argv):
  lease.verify_identity();assert mod._regular_hash(out/'declaration.json')==decl_sha
  assert mod._regular_hash(target,owners={os.getuid(),0})==binary_sha and entry.resolve(strict=True)==target
  operation=mod.AuxiliaryCommand(directory=out,name=name,argv=argv,cwd=root,environment=env,lease_check=lease.verify_identity,
      stdout_max=1024**2,stderr_max=1024**2)
  operations.append(operation);operation.start();result=operation.result
  while result is None:result=operation.wait(5)
  records.append(result)
  if result['status']!='success':return None
  return mod._read_bound_metadata(out/(name+'.stdout'),result['outputs']['stdout']['snapshot'],1024**2)
 if any(overrides.values()):return complete('refused','unresolved Docker target override; inherited environment retained, not cleared')
 raw=observe('context-show',[str(entry),'context','show'])
 if raw is None:return complete('refused','Docker context inquiry returned nonzero; raw status/streams retained')
 context=raw.decode('utf-8').strip()
 if not re.fullmatch('[A-Za-z0-9][A-Za-z0-9_.-]{0,63}',context):return complete('refused','context name outside declared grammar')
 raw=observe('context-inspect',[str(entry),'context','inspect',context])
 if raw is None:return complete('refused','local context metadata inquiry failed')
 metadata=json.loads(raw)
 if type(metadata) is not list or len(metadata)!=1 or metadata[0].get('Name')!=context:return complete('refused','context metadata differs')
 endpoint=metadata[0].get('Endpoints',{}).get('docker',{}).get('Host')
 if type(endpoint) is not str or not endpoint.startswith('unix:///') or '?' in endpoint or '#' in endpoint:return complete('refused','endpoint is not a declared local Unix socket')
 socket=Path(endpoint[7:]);resolved=socket.resolve(strict=True);info=resolved.stat()
 if not stat.S_ISSOCK(info.st_mode) or info.st_uid not in (0,os.getuid()):return complete('refused','local endpoint socket identity/owner unsupported')
 raw=observe('server-version',[str(entry),'--context',context,'version','--format','{{json .Server}}'])
 if raw is None:return complete('refused','local Docker server inquiry failed; no image/container actions')
 server=json.loads(raw)
 if type(server) is not dict or server.get('Os')!='linux':return complete('refused','server did not report Linux')
 assert {p:sha((root/p).read_bytes()) for p in expected}==expected
 return complete('supporting_only','local endpoint/server metadata observed; actual kernel controls still unexecuted',context=context,endpoint=endpoint,
     reported_server_version=server.get('Version'),reported_architecture=server.get('Arch'),reported_OS=server.get('Os'))

end=time.monotonic()+45;errors=[]
while True:
 admitted=False
 try:
  with local_resource_lease(exclusive=True) as lease:admitted=True;run(lease)
 except LocalResourceLeaseError as error:
  if admitted:raise
  errors.append(str(error))
  if time.monotonic()>=end:
   with Path('/tmp/connectanum-native-perf-linux-control-docker-census-admission-refusal.json').open('x') as f:json.dump({'errors':errors,'before_declaration_child_or_Docker_actions':True},f,indent=2)
   print('Resource lease unavailable; Docker preparation did not start.');break
  time.sleep(.5)
 else:break
