from pathlib import Path
import urllib.request,json,hashlib,sys,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
root=Path('/tmp').resolve()/'connectanum-native-perf-linux-control-primary'
sha=lambda b:hashlib.sha256(b).hexdigest()
with local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();root.mkdir(mode=0o700);receipts=[]
 def fetch(url,name,headers=None,maximum=8*1024**2):
  request=urllib.request.Request(url,headers=headers or {})
  with urllib.request.urlopen(request,timeout=30) as response:
   data=response.read(maximum+1);assert len(data)<=maximum;status=response.status;response_headers=dict(response.headers)
  with (root/name).open('xb') as f:f.write(data)
  receipts.append({'url':url,'file':name,'size':len(data),'sha256':sha(data),'status':status})
  return data,response_headers
 for url,name in [
 ('https://docs.docker.com/engine/manage-resources/contexts/','docker-contexts.html'),
 ('https://docs.docker.com/reference/cli/docker/container/cp/','docker-cp.html'),
 ('https://docs.docker.com/reference/cli/docker/container/run/','docker-run.html'),
 ('https://raw.githubusercontent.com/docker-library/official-images/master/library/python','official-python-library.txt')]:fetch(url,name)
 auth_url='https://auth.docker.io/token?service=registry.docker.io&scope=repository:library/python:pull'
 with urllib.request.urlopen(auth_url,timeout=30) as response:auth=json.load(response)
 # Ephemeral anonymous registry bearer remains in memory only, never argv/env/raw logs.
 token=auth.get('token') or auth['access_token'];assert type(token) is str and token
 headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json'}
 index,ih=fetch('https://registry-1.docker.io/v2/library/python/manifests/3.14-slim-trixie','python-index.json',headers)
 index_digest='sha256:'+sha(index);assert ih.get('docker-content-digest',ih.get('Docker-Content-Digest'))==index_digest
 decoded=json.loads(index);assert decoded['schemaVersion']==2
 matches=[m for m in decoded['manifests'] if m.get('platform',{}).get('os')=='linux' and m.get('platform',{}).get('architecture')=='arm64' and m.get('platform',{}).get('variant') in (None,'v8')]
 assert len(matches)==1;descriptor=matches[0];digest=descriptor['digest'];assert digest.startswith('sha256:')
 manifest,mh=fetch('https://registry-1.docker.io/v2/library/python/manifests/'+digest,'python-arm64-manifest.json',headers)
 assert 'sha256:'+sha(manifest)==digest;parsed=json.loads(manifest);layers=parsed['layers'];compressed=sum(x['size'] for x in layers)
 assert 0<compressed<=512*1024**2
 config,headers_unused=fetch('https://registry-1.docker.io/v2/library/python/blobs/'+parsed['config']['digest'],'python-config.json',{'Authorization':'Bearer '+token})
 assert 'sha256:'+sha(config)==parsed['config']['digest']
 receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'NEW primary/source/public OCI metadata only, no image pull/container/VM/kernel/build/data','sources':receipts,'image_repository':'docker.io/library/python','tag_before_data':'3.14-slim-trixie','index_digest':index_digest,'platform_descriptor':descriptor,'selected_platform_digest':digest,'image_config_digest':parsed['config']['digest'],'compressed_layer_bytes':compressed,'auth_response_NOT_retained':'ephemeral anonymous registry bearer held in memory, no token value persisted','capture_ready':False}
 with (root/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 lease.verify_identity();print(json.dumps({'primary_files':len(receipts),'platform_digest':digest,'config_digest':parsed['config']['digest'],'compressed_layer_bytes':compressed}))
