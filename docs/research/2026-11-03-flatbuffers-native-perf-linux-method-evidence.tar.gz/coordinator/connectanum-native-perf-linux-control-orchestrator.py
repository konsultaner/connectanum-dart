"""Single NEW OWN Linux method attempt; no product build/capture/acceptance."""
from pathlib import Path
import ast, base64, datetime, hashlib, json, os, re, shutil, stat, sys, time, types
sys.path.insert(0, "/Users/konsultaner/.codex/skills/local-model-companions/scripts")
from ollama_companion import local_resource_lease, LocalResourceLeaseError
WT = Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
OUT = Path("/private/tmp/connectanum-native-perf-linux-control-attempt-v1")
PRIMARY = Path("/private/tmp/connectanum-native-perf-linux-control-primary")
METHOD = Path("/tmp/connectanum-native-perf-linux-control-method.py")
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(lease):
    lease.verify_identity()
    assert shutil.disk_usage(WT).free >= 1536 * 1024**2
    cp = json.loads(Path("/tmp/connectanum-current-task-checkpoint.json").read_bytes())
    expected = cp["native_perf_only_diagnostic_design"]["current_source_sha256"]
    assert len(expected) == 20
    sources = {name: (WT / name).read_bytes() for name in expected}
    assert {name: sha(raw) for name, raw in sources.items()} == expected
    method = METHOD.read_bytes()
    ast.parse(method)
    receipt = json.loads((PRIMARY / "receipt.json").read_bytes())
    digest = receipt["selected_platform_digest"]
    assert digest == "sha256:29434a59c93070e470f84663e4289026e04644ea44b5220ef7e07d653318ca1f"
    image = "docker.io/library/python@" + digest
    config = receipt["image_config_digest"]
    assert config == "sha256:fe83005fb105be014095e304ce578212522449ec2ad47649ef4833ef9a84abda"
    assert sha((PRIMARY / "python-arm64-manifest.json").read_bytes()) == digest[7:]
    mod = types.ModuleType("linux_method_command_owner")
    mod.__file__ = str(WT / "tool/native_perf_build_producer.py")
    exec(compile(sources["tool/native_perf_build_producer.py"], mod.__file__, "exec"), mod.__dict__)
    census = json.loads(Path("/private/tmp/connectanum-native-perf-linux-control-docker-census/summary.json").read_bytes())
    assert census["status"] == "supporting_only"
    endpoint = census["endpoint"]
    assert endpoint.startswith("unix:///") and census["context"] == "desktop-linux"
    sock = Path(endpoint[7:]).resolve(strict=True)
    si = sock.stat()
    assert stat.S_ISSOCK(si.st_mode) and si.st_uid in (0, os.getuid())
    socket_stamp = (si.st_dev, si.st_ino, si.st_uid)
    entry = Path("/usr/local/bin/docker")
    target = entry.resolve(strict=True)
    docker_sha = mod._regular_hash(target, owners={0, os.getuid()})
    env = dict(os.environ)
    assert not any(env.get(k) for k in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"))
    OUT.mkdir(mode=0o700)
    commands = OUT / "commands"
    commands.mkdir()
    bundle = OUT / "bundle"
    bundle.mkdir(mode=0o755)
    (bundle / "tool").mkdir(mode=0o755)
    for name, raw in sources.items():
        with (bundle / name).open("xb") as stream:
            stream.write(raw)
        (bundle / name).chmod(0o644)
    with (bundle / "method.py").open("xb") as stream:
        stream.write(method)
    (bundle / "method.py").chmod(0o644)
    nonce = os.urandom(16).hex()
    container_name = "ct132-method-" + nonce
    declared = {
        "kind": "own-unprivileged-linux-method-intake-v1", "declared": now(),
        "scope": "namespaced finite mechanism controls ONLY; never live capture admission",
        "capture_ready": False, "live_admission": False,
        "source_head": "601108ea6216464bd00ae29c16cfaf0a59c71db6",
        "all20source_sha256": expected, "method_sha256": sha(method),
        "primary_receipt_sha256": sha((PRIMARY / "receipt.json").read_bytes()),
        "platform_digest": digest, "image_config_digest": config,
        "selected_tag_metadata_only": receipt["tag_before_data"],
        "platform": "linux/arm64", "image_reference": image, "container_name": container_name,
        "docker_entry": str(entry), "docker_target": str(target), "docker_read_sha256": docker_sha,
        "local_endpoint": endpoint, "socket_stamp": [str(v) for v in socket_stamp],
        "environment_sha256": sha(json.dumps(env, sort_keys=True, ensure_ascii=True).encode()),
        "storage_admission": {"test_floor_bytes": 1024**3, "image_allowance_bytes": 512*1024**2,
                              "build_floor_bytes_UNCHANGED": 12*1024**3, "no_build_authorized": True},
        "cases": ["fdexec-positive", "pre-go-eof-negative", "handoff"],
        "case_nonces": {name: os.urandom(16).hex() for name in
                        ("fdexec-positive", "pre-go-eof-negative", "handoff")},
        "guest_policy": {"uid": 1000, "gid": 1000, "cap_drop": "ALL", "network": "none",
            "readonly_root": True, "no_new_privileges": True, "memory": 268435456,
            "pids_limit": 32, "cpus": 1, "tmpfs_bytes": 16777216,
            "no_mounts_of_host_data": True, "no_added_capabilities": True,
            "no_security_relaxation": True, "no_restart_kill_retry_or_cleanup": True},
        "command_order": ["image-pull", "image-inspect", "image-save", "container-create",
            "container-inspect-before", "copy-python-elf", "copy-bundle", "copy-bundle-back",
            "container-inspect-staged", "attach-start-ONCE", "wait-natural", "container-inspect-after"],
        "command_template": [str(entry), "--host", endpoint, "{one-declared-operation}"],
        "guest_command": ["/usr/local/bin/python3.14", "-I", "-S", "-B",
                          "/opt/control/method.py", "coordinator"],
        "limitations": ["No original diagnostic host/kernel/credentials/perf/access/inheritance/arming proof.",
            "No actual original WAMP/SDK/compiler/native/roles/privateCOW/clock/compiledclosure/acceptance.",
            "Real os.execve(fd) API, not syscall-level tracing or proof of every delegated loaded image.",
            "EOF is not writer authenticity or whole descendant completion.",
            "Namespace user1000 credentials are actual only within this Docker control context.",
            "Live independent preflight provider absent; live SessionController CLOSED."]
    }
    mod._write_json(OUT / "declaration.json", declared)
    declaration_sha = mod._regular_hash(OUT / "declaration.json")
    operations, records = [], []
    known_container = None
    frozen_manifest_sha = None
    def recheck():
        lease.verify_identity()
        assert mod._regular_hash(OUT / "declaration.json") == declaration_sha
        assert entry.resolve(strict=True) == target and mod._regular_hash(target, owners={0, os.getuid()}) == docker_sha
        info = sock.stat()
        assert (info.st_dev, info.st_ino, info.st_uid) == socket_stamp
        assert {name: sha((WT / name).read_bytes()) for name in expected} == expected
        assert sha(METHOD.read_bytes()) == declared["method_sha256"]
        if frozen_manifest_sha is not None:
            assert mod._regular_hash(bundle / "manifest.json") == frozen_manifest_sha
    def observe(name, args, *, allow_failure=False):
        recheck()
        operation = mod.AuxiliaryCommand(directory=commands, name=name,
            argv=[str(entry), "--host", endpoint, *args], cwd=WT, environment=env,
            lease_check=lease.verify_identity, stdout_max=8*1024**2, stderr_max=8*1024**2)
        operations.append(operation)  # Prepared owner BEFORE spawn.
        operation.start()
        result = operation.result
        while result is None:
            result = operation.wait(5)
        records.append(result)
        mod._write_json(OUT / (name + "-record.json"), result)
        raw = mod._read_bound_metadata(commands / (name + ".stdout"),
                                       result["outputs"]["stdout"]["snapshot"], 8*1024**2)
        if result["status"] != "success" and not allow_failure:
            raise RuntimeError("declared Docker operation failed: " + name)
        return raw
    def inspect_container(name):
        raw = observe(name, ["container", "inspect", known_container])
        decoded = json.loads(raw)
        assert type(decoded) is list and len(decoded) == 1
        data = decoded[0]
        assert data["Id"] == known_container and data["Image"] == config
        assert data["Name"] == "/" + container_name
        cfg, host = data["Config"], data["HostConfig"]
        assert cfg["User"] == "1000:1000"
        assert cfg["Entrypoint"] == ["/usr/local/bin/python3.14"]
        assert cfg["Cmd"] == ["-I", "-S", "-B", "/opt/control/method.py", "coordinator"]
        assert not cfg["OpenStdin"] and not cfg["Tty"]
        assert host["NetworkMode"] == "none" and host["ReadonlyRootfs"] is True
        assert host["CapDrop"] == ["ALL"] and not host["CapAdd"] and host["Privileged"] is False
        assert not host["Binds"] and not host.get("Mounts")
        assert host["PidsLimit"] == 32 and host["Memory"] == 268435456
        assert host["MemorySwap"] == 268435456 and host["NanoCpus"] == 1000000000
        assert host["RestartPolicy"]["Name"] == "no"
        assert host["SecurityOpt"] == ["no-new-privileges:true"]
        assert host["Tmpfs"] == {"/tmp": "rw,nosuid,nodev,noexec,size=16777216,mode=1777"}
        return data
    try:
        observe("image-pull", ["image", "pull", "--platform", "linux/arm64", image])
        image_data = json.loads(observe("image-inspect", ["image", "inspect", image]))
        assert len(image_data) == 1 and image_data[0]["Id"] == config
        assert image_data[0]["Os"] == "linux" and image_data[0]["Architecture"] == "arm64"
        assert image_data[0]["RootFS"]["Layers"] == json.loads((PRIMARY / "python-config.json").read_bytes())["rootfs"]["diff_ids"]
        image_archive = OUT / "method-image.tar"
        assert not image_archive.exists()
        assert shutil.disk_usage(OUT).free >= 1536*1024**2
        observe("image-save", ["image", "save", "--output", str(image_archive), image])
        assert image_archive.stat().st_size <= 512*1024**2
        mod._write_json(OUT / "method-image-receipt.json", {
            "scope": "third-party method input retained LOCAL ONLY, not project-native/source evidence",
            "file": image_archive.name, "sha256": mod._regular_hash(image_archive),
            "size": image_archive.stat().st_size, "capture_ready": False})
        cid_raw = observe("container-create", ["container", "create", "--name", container_name,
            "--user", "1000:1000", "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
            "--network", "none", "--read-only",
            "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=16777216,mode=1777",
            "--memory", "268435456", "--memory-swap", "268435456", "--pids-limit", "32",
            "--cpus", "1", "--workdir", "/tmp", "--entrypoint", "/usr/local/bin/python3.14",
            image, "-I", "-S", "-B", "/opt/control/method.py", "coordinator"])
        cid = cid_raw.decode("ascii").strip()
        assert re.fullmatch("[0-9a-f]{64}", cid)
        known_container = cid
        before = inspect_container("container-inspect-before")
        assert before["State"]["Status"] == "created" and before["State"]["Running"] is False
        elf_dir = OUT / "method-image-executable"
        elf_dir.mkdir()
        observe("copy-python-elf", ["container", "cp", cid + ":/usr/local/bin/python3.14", str(elf_dir / "python3.14")])
        elf_path = elf_dir / "python3.14"
        assert elf_path.read_bytes()[:4] == b"\x7fELF" and elf_path.stat().st_size <= 32*1024**2
        elf_sha = mod._regular_hash(elf_path)
        manifest = {"kind": "namespaced_linux_method_manifest_v1", "capture_ready": False,
            "live_admission": False, "declaration_sha256": declaration_sha,
            "container_id": cid, "image_reference": image, "image_config_digest": config,
            "all20source_sha256": expected, "method_sha256": sha(method),
            "method_python_elf_sha256": elf_sha, "case_nonces": declared["case_nonces"],
            "manifest_written_before_ANY_guest_start": True}
        mod._write_json(bundle / "manifest.json", manifest)
        (bundle / "manifest.json").chmod(0o644)
        frozen_manifest_sha = mod._regular_hash(bundle / "manifest.json")
        observe("copy-bundle", ["container", "cp", str(bundle), cid + ":/opt/control"])
        back = OUT / "bundle-roundtrip"
        observe("copy-bundle-back", ["container", "cp", cid + ":/opt/control", str(back)])
        expected_bundle = {str(p.relative_to(bundle)): mod._regular_hash(p)
                           for p in bundle.rglob("*") if p.is_file()}
        actual_bundle = {str(p.relative_to(back)): mod._regular_hash(p)
                         for p in back.rglob("*") if p.is_file()}
        assert expected_bundle == actual_bundle
        staged = inspect_container("container-inspect-staged")
        assert staged["State"]["Status"] == "created" and staged["State"]["Running"] is False
        mod._write_json(OUT / "staged-before-start.json", {
            "declaration_sha256": declaration_sha, "manifest_sha256": frozen_manifest_sha,
            "actual_roundtrip_files": actual_bundle, "container_id": cid,
            "root_owned_guest_files_to_be_checked_by_guest": True,
            "capture_ready": False, "live_admission": False})
        raw_guest = observe("attach-start-once", ["container", "start", "--attach", cid], allow_failure=True)
        # No restart/retry/reset; raw stream is retained even if parsing fails.
        natural_wait_raw = observe("wait-natural", ["container", "wait", cid])
        after = inspect_container("container-inspect-after")
        state = after["State"]
        assert state["Status"] == "exited" and state["Running"] is False
        assert type(state["ExitCode"]) is int
        assert natural_wait_raw == (str(state["ExitCode"]) + "\n").encode("ascii")
        assert state["StartedAt"] and state["FinishedAt"]
        extracted = OUT / "guest-raw"
        extracted.mkdir(mode=0o700)
        footer, artifact_records, special, pending = None, [], [], []
        def pairs(items):
            out = {}
            for key, value in items:
                assert key not in out
                out[key] = value
            return out
        assert raw_guest.endswith(b"\n")
        for line in raw_guest.splitlines():
            value = json.loads(line, object_pairs_hook=pairs)
            event = value.get("event")
            assert footer is None
            if event == "artifact":
                name = value["path"]
                rel = Path(name)
                assert name and not rel.is_absolute() and all(x not in ("..", ".") for x in rel.parts)
                data = base64.b64decode(value["data_base64"], validate=True)
                assert type(value["size"]) is int and value["size"] == len(data) <= 2*1024**2
                assert sha(data) == value["sha256"]
                output = extracted / rel
                output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                with output.open("xb") as stream:
                    stream.write(data)
                artifact_records.append({key: value[key] for key in ("path", "size", "sha256")})
            elif event == "special_metadata":
                special.append(value)
            elif event == "owned_pending":
                pending.append(value)
            elif event == "method_footer":
                footer = value
            else:
                raise RuntimeError("unknown method output; raw retained")
        assert state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["Error"]
        assert footer is not None and footer["artifacts"] == artifact_records
        assert footer["capture_ready"] is False and footer["live_admission"] is False
        assert footer["all_declared_cases_completed"] is True and footer["case_count"] == 3 and not footer["errors"]
        assert [(x["case"], x["status"]) for x in footer["known_actor_statuses"]] == [
            ("fdexec-positive", 0), ("pre-go-eof-negative", 78), ("handoff", 0)]
        recheck()
        mod._write_json(OUT / "summary.json", {"scope": "actual_namespaced_unprivileged_Linux_method_ONLY",
            "capture_ready": False, "live_admission": False, "source_admitted": False,
            "declaration_sha256": declaration_sha, "manifest_sha256": frozen_manifest_sha,
            "container_id": cid, "container_state": state, "method_python_elf_sha256": elf_sha,
            "known_actor_statuses": footer["known_actor_statuses"], "artifact_records": artifact_records,
            "special_metadata": special, "pending_records": pending, "command_records": records,
            "source20_unchanged": True, "no_canonical_build_originalSDK_native_perf_or_benchmark": True,
            "free_bytes": shutil.disk_usage(WT).free, "finished": now()})
        print(json.dumps({"result": "three_method_cases_complete", "capture_ready": False,
                          "source_admitted": False, "directory": str(OUT)}))
    except BaseException as error:
        # Terminal attempt: retain partial command data, known CID/actors; no retries.
        mod._write_json(OUT / "failure.json", {"capture_ready": False, "live_admission": False,
            "error_type": type(error).__name__, "reason": str(error), "container_id": known_container,
            "commands": records, "finished": now(), "no_retry_cleanup_restart_or_kill": True})
        raise

deadline = time.monotonic() + 45
errors = []
while True:
    admitted = False
    try:
        with local_resource_lease(exclusive=True) as lease:
            admitted = True
            run(lease)
    except LocalResourceLeaseError as error:
        if admitted:
            raise
        errors.append(str(error))
        if time.monotonic() >= deadline:
            path = Path("/tmp/connectanum-native-perf-linux-control-method-admission-refusal.json")
            with path.open("x") as stream:
                json.dump({"errors": errors, "before_attempt_or_any_Docker_actions": True}, stream, indent=2)
            print("Unstarted method resource admission refused.")
            break
        time.sleep(.5)
    else:
        break
