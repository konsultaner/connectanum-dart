import sys,pathlib,json,hashlib,subprocess,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];slot=len(calls);row=dict(argv=argv,Popen_attempted=True,pid=None,status=None,stdout_eof=None,stderr_eof=None);calls.append(row)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  row['parent_pipe_FDstats']={name:dict(fd=stream.fileno(),dev=os.fstat(stream.fileno()).st_dev,ino=os.fstat(stream.fileno()).st_ino) for name,stream in [('stdout',child.stdout),('stderr',child.stderr)]}
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n')
  out,err=child.communicate();status=child.wait();row.update(status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   path=q/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   st=path.stat();assert st.st_size==len(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest();row[label+'_pathstat']=dict(dev=st.st_dev,ino=st.st_ino,size=st.st_size)
  (q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();status=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==names and not production
 h=json.loads((P/'after-edit-hashes.json').read_text());prior=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-status-poll-progress-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items()) and all(h[k]==v for k,v in prior.items() if 'build_producer.py' not in k)
 before=(P/'source-before.py').read_text();current=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert current==(P/'candidate-producer-v2.py').read_text() and current==(P/'after-producer.py').read_text()
 old=ast.parse(before);new=ast.parse(current);oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_direct_wait_guard'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','_wait_natural_status','_constructor_guard','_complete'})
 methods=(P/'candidate-methods.py.txt').read_text();init=(P/'candidate-init.py.txt').read_text();schema=(P/'candidate-schema.py.txt').read_text();fields=(P/'candidate-data-fields-v2.txt').read_text()
 projected=current.replace(methods,(P/'old-direct-wait-block-v2.txt').read_text(),1).replace(init,'',1).replace('        self._direct_wait_guard()\n','',1).replace((P/'candidate-complete-guard-v2.txt').read_text(),'',1).replace(schema,'',1).replace(fields,'',1)
 assert projected==before and tests==(P/'tests-before.py').read_text()+'\n\n'+(P/'new-tests.py').read_text()+'\n\n'+(P/'new-history-test.py').read_text()
 def output_literal(node):
  return next(x for x in ast.walk(node) if isinstance(x,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='whole_descendant_exit_proven' for k in x.keys))
 assert ast.dump(output_literal(om['_complete']))==ast.dump(output_literal(nm['_complete']))
 forbidden={'repr','str','add_note','_write_json','close','_close_slot','wait','kill','_complete'}
 names_calls=[x.func.attr if isinstance(x.func,ast.Attribute) else x.func.id if isinstance(x.func,ast.Name) else '' for x in ast.walk(nm['_wait_natural_status']) if isinstance(x,ast.Call)]
 assert not (set(names_calls)&forbidden)
 body=ast.get_source_segment(current,nm['_wait_natural_status'])
 assert body.index("check();self._natural_wait_process=process")<body.index("row['lookup_attempted']=True;method=process.wait")<body.index("row['wait_attempted']=True")
 assert body.index("row['raw_return']=status;row['returned']=True")<body.index("if type(status) is not int")<body.index("self._natural_wait_status=status")
 assert body.index("timeout_error=received;row['timeout_error']=received")<body.index("check();row['completed']=True")
 assert body.rfind("if timeout_error is not None:raise timeout_error")>body.index("except BaseException as error:")

 guard_calls=[]
 for name,node in nm.items():
  for call in ast.walk(node):
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='_direct_wait_guard':guard_calls.append(dict(caller=name,keywords=[ast.unparse(x) for x in call.keywords]))
 assert {x['caller'] for x in guard_calls}=={'_constructor_guard','_complete'}
 invariant=dict(ROOT_whole_final_affected_methods_new8_helpers_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_BYTEexact=True,old_public_wait_defer_other_methods_factories_gates_emit_freeze_auxpredicates_exact=True,original_result_literal_ASTexact=True,normal_int_signed_nonzero_and_expected_timeout_semantics_preserved=True,original_normal_constructor_handle_refs_before_methodlookup=True,public_pointer_mismatch_refuses_before_witnessbind_lookup_wait=True,rawreturn_beforeformat_postchecks_witnesscommit=True,timeout_exception_retained_beforepostchecks_rethrown_OUTSIDE_broadcatch=True,completed_timeout_record_NOTactor_exit_or_release=True,unknown_first_permanent_no_report_cleanup_retry_restore_replay=True,ordinary_latestrow_full_pre_finalization_and_passive_history=True,guard_calls=guard_calls,ctor_return_normal_allocation_facts_DATApreconditions_NOTpartialPopen_methodauthority_or_auth=True,read_select_lease_backingFD_init_generic_enclosing_historical_transitive_fullphysicalEX_originalruntimeadmission_INCOMPLETE=True,model_full_current_source_approval=False)

 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 reports=[];journals=[]
 for stage in ('before','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('wait-before-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);reports.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
   assert d['original_handle_retained'] is True
   if stage=='after-selected':
    assert d['row_present'] is True and d['row_original_process'] is True
    native=[x for x in d['events'] if x['stage'].startswith('native_')]
    if d['mode'] in ('foreign-before','drift','invalid-bool','unknown-return'):
     assert d['guard_raises_received_first'] is True and d['source_private_first'] is True and d['row_error_is_received'] is True
     assert d['source_status_is_None'] is True and d['row_completed'] is False and d['pending'] is True and d['finished'] is False and d['source_result_is_None'] is True
     assert d['natural_wait_observed'] is False and d['natural_wait_status'] is None
     if d['mode']=='foreign-before':assert not native and d['row_wait_attempted'] is False and d['natural_wait_process_original'] is False
     else:
      assert len(native)==1 and native[0]['stage']=='native_source_wait' and native[0]['source_intent_before_native'] is True
      if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['row_returned'] is None and d['row_raw_value'] is None
      elif d['mode']=='invalid-bool':assert d['raised_is_ProducerError'] is True and d['row_returned'] is True and d['row_raw_value'] is False and d['row_value_valid'] is not True
      else:assert d['raised_is_ProducerError'] is True and d['row_returned'] is True and type(d['row_raw_value']) is int and d['row_raw_value']==0
    elif d['mode']=='pending':
     assert d['raised_is_original_timeout'] is True and d['guard_error_absent'] is True
     assert d['row_timeout_received'] is True and d['row_timeout_is_original'] is True
     assert d['row_returned'] is None and d['row_raw_value'] is None and d['row_completed'] is True
     assert d['natural_wait_observed'] is False and d['natural_wait_status'] is None
     assert len(native)==1 and native[0]['stage']=='native_source_wait_timeout' and native[0]['source_intent_before_native'] is True
    else:
     value=7 if d['mode']=='nonzero' else 0
     assert d['row_returned'] is True and d['row_value_valid'] is True and d['row_completed'] is True
     assert type(d['method_return']) is int and d['method_return']==value and d['natural_wait_observed'] is True
     assert d['natural_wait_process_original'] is True and type(d['row_raw_value']) is int and d['row_raw_value']==value
  for path in sorted((P/stage/'fixtures').rglob('wait-unit-cleanup.json')):
   raw=path.read_bytes();d=json.loads(raw);journals.append(dict(stage=stage,path=str(path.relative_to(P)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
 assert len(reports)==14 and len(journals)==14
 waits=[r for j in journals for r in j['data'] if r['kind']=='bound_same_finite_wait'];assert len(waits)==28 and all(type(r['status']) is int and r['status']==r['expected'] for r in waits)
 assert sum(r['status']==0 for r in waits)==26 and sum(r['status']==7 for r in waits)==2
 for name,data in [('new-precleanup-reports.json',reports),('new-unit-journals.json',journals)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 b=json.loads((P/'before/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert (b['tests'],b['failures'],b['errors'])==(7,4,0) and (a['tests'],a['failures'],a['errors'])==(16,0,0)
 history_reports=[];history_journals=[]
 for stage in ('before-history-guard','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('history-guard-before-cleanup.json')):
   raw=path.read_bytes();data=json.loads(raw);history_reports.append(dict(stage=stage,path=str(path.relative_to(P)),sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),data=data))
   if stage=='after-selected':assert all(data[k] is True for k in ['raised_is_first','guard_is_first','private_first_is_original','pending','result_is_None','all_original_logs_open','result_publication_absent']) and data['finished'] is False
  for path in sorted((P/stage/'fixtures').rglob('history-guard-unit-cleanup.json')):
   data=json.loads(path.read_text());history_journals.append(dict(stage=stage,path=str(path.relative_to(P)),data=data))
 assert len(history_reports)==2 and len(history_journals)==2
 hw=[row for j in history_journals for row in j['data'] if row['kind']=='bound_same_finite_wait'];assert len(hw)==2 and all(type(row['status']) is int and row['status']==0 for row in hw)
 hb=json.loads((P/'before-history-guard/result.json').read_text());assert (hb['tests'],hb['failures'],hb['errors'])==(1,1,0)
 with (q/'new-history-guard-control.json').open('x') as f:json.dump(dict(before=hb,reports=history_reports,journals=history_journals,new_pure_guard_callback_NOTnative_error=True,model_BEFOREthis_new_control_and_wrapperfix=True),f,indent=2)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],NEWbefore7=b,AFTERselected16=a,not_aggregated_or_current20canonical_or_originalruntimeadmission=True,source_Git=dict(head=head,branch=branch,untracked20_exact=True,production_packages_native_diffempty=True,four_signed0_BOTHseparateEOF=True,DATA_only=True),planning=json.loads((P/'test-planning/finish.json').read_text()),review=json.loads((P/'review/finish.json').read_text()),ROOT_review_qualification=json.loads((P/'ROOT-review-assessment.json').read_text()),ROOT_independent_wholefinal_source_tests_AST_qualified_NOTmodel_fullapproval=True,candidate_UNEXECUTED_before_edit=True,review_BEFORE_final_wrapper_and_eighth_control=True,ROOT_review_qualification_v1_v2_assertions_failed_before_assessment_outputs=True,new_directwait_journals=14,new_history_guard_journals=2,new_known_boundwait_rows=30,new_signed0_rows=28,new_signed7_rows=2,cached_possible_NOTfreshsyscall=True,only_pureguardprobe_aftererror_NOsecond_sourcewait_poll=True,two_actual_OWN_normal_SourceAux_commands_not_other_task_actors=True,normal_ctor_facts_DATApreconditions_NOTmethodauthority_auth_or_EXrelease=True,bool_is_ROOTinjected_notspontaneouskernel_return=True,TimeoutExpired_distinct_from_UNKNOWNcall_and_exitstatus_boolFalse_never0coercion=True,finite8s_pendinggate_ROOTrelease_afterevidence_bounded10sSAMEwait_UNITnotbenchmarkfreeze=True,ROOTknown_parentFD_rawlog_cleanup_afterevidence_UNITonly_NOTliveEX=True,logical_history_sharedrefs_NOTexactheapRSS_bound_timing_or_cause=True,required_legacy_setup_actorFD_APIreturns_notallserialized_no_reconstruction=True,all_named_operational_controllers_BEFOREcalls_inline_artifact_preparation_not_saved_before_call=True,other18helpers3bins_BYTEexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,outside_old_cleanup_spacechange_cause_UNMEASURED=True,no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_OPEN_DRAFT_base130_issue103_milestoneOPEN=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_direct_wait_progress'];v.update(new_epoch_UNTESTED=False,ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW directwait postcomponent4Git0/BOTHseparateEOF/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='FinalCHANGEDepoch sixteen selected PASS=8matchingNEW+8affected; ROOTqualified NOTmodelcurrentapproval/current20canonical/admission')
 c['active_turn_status']='Aux_direct_wait1ba592_95e1fb_selected16PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],NEWbefore7='4FAIL3normalPASS0ERROR',AFTERselected16='PASS',new_unit_journals=16,new_boundwait_rows=30,signed0=28,signed7=2,free_bytes=free)))
