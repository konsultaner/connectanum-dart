class AuxiliaryDirectWaitHistoryGuardTests(unittest.TestCase):
    """NEW pure whole-history guard fault on an actual finite Aux completion."""
    def test_whole_history_guard_error_is_retained_before_finalization_IO(self):
        base=Path(tempfile.mkdtemp(prefix='aux-wait-history-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        actors=[];pipes=[];logs=[];closed=set();cleanup=[];events=[]
        real_allocate=producer.AuxiliaryCommand._allocate_process;native_pipe=os.pipe;native_close=os.close;native_open=Path.open
        original_guard=getattr(producer.AuxiliaryCommand,'_direct_wait_guard',None)
        first=OSError(5,'OWN pure full wait history guard fault');raised=None;guard_error=None;a=None
        def allocate(current,record):
            value=real_allocate(current,record);actors.append(dict(process=value,bound_wait=value.wait));return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            value=native_close(fd);closed.add(fd);return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            if path in (base/'history-source.stdout',base/'history-source.stderr'):logs.append(value)
            return value
        def history_guard(current,*,whole=False):
            if whole:events.append(dict(stage='pure_whole_history_guard'));raise first
            if original_guard is not None:return original_guard(current,whole=whole)
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),
            mock.patch.object(os,'close',closing),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                a=producer.AuxiliaryCommand(directory=base,name='history-source',argv=[sys.executable,'-c','pass'],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);a.start()
                with mock.patch.object(producer.AuxiliaryCommand,'_direct_wait_guard',history_guard,create=True):
                    try:a.wait(timeout=10)
                    except BaseException as error:raised=error
                    # Pure probe only. No source native wait/poll/replay after fault.
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            report=dict(events=events,raised_is_first=raised is first,guard_is_first=guard_error is first,
                private_first_is_original=getattr(a,'_deferred_primary_error',None) is first,
                pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                all_original_logs_open=all(not log.closed for log in logs),
                natural_wait_observed=a._natural_wait_observed,natural_wait_status=a._natural_wait_status,
                result_publication_absent=not (base/'history-source.json').exists(),
                scope='pure guard callback with one actual own finite SourceAux, not native fault/SDK/physicalEX or full historical corruption prevention')
            with (base/'history-guard-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertEqual([dict(stage='pure_whole_history_guard')],events)
            self.assertIs(first,raised);self.assertIs(first,guard_error);self.assertTrue(report['private_first_is_original'])
            self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
            self.assertTrue(report['all_original_logs_open']);self.assertTrue(report['result_publication_absent'])
        finally:
            for actor in actors:
                value=actor['bound_wait'](10);cleanup.append(dict(kind='bound_same_finite_wait',pid=actor['process'].pid,status=value,expected=0,cached_possible=True));self.assertIs(type(value),int);self.assertEqual(0,value)
            for item in pipes:
                fd=item['fd']
                if fd in closed:continue
                st=os.fstat(fd);self.assertEqual((st.st_dev,st.st_ino),(item['dev'],item['ino']));value=native_close(fd)
                cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
            for log in logs:
                if not log.closed:
                    fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                    log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',fd=fd,returned=True))
            with (base/'history-guard-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)
