import sys,pathlib,json,hashlib,os,io,types,unittest,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize;assert free>=1073741824
 q=P/'after-selected';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 for name,b in [('producer.py',source),('existing-tests.py',tests)]:
  with (q/name).open('xb') as f:f.write(b)
 newnames=["test_foreign_actual_handle_refuses_before_direct_wait","test_actual_wait_return_then_pointer_drift_refuses_witness_publish","test_actual_wait_return_then_bool_is_not_status_zero","test_actual_wait_return_then_fault_retains_unknown_and_first","test_normal_cached_zero_direct_wait_preserved","test_normal_cached_nonzero_direct_wait_preserved","test_actual_timeout_reraises_same_without_exit_or_quarantine"]
 names=['AuxiliaryDirectWaitProgressTests.'+name for name in newnames]
 names+=['AuxiliaryStatusPollProgressTests.test_actual_poll_return_then_pointer_drift_refuses_status_publish','AuxiliaryBufferWriteProgressTests.test_native_full_write_hash_return_then_fault_keeps_first_guard','AuxiliaryDeferredErrorQuarantineTests.test_actual_status_observation_then_fault_has_no_reporting','AuxiliaryFinalizationQuarantineTests.test_native_flush_then_error_stops_before_finally_close','AuxiliaryCreatorCloseQuarantineTests.test_native_close_return_then_error_keeps_creator_intent','AllocatedAuxiliaryProcessTests.test_normal_allocated_Auxiliary_history_remains_DATA_only','AuxiliaryNaturalWaitWitnessTests.test_natural_nonzero_is_retained_not_invented_zero','ProducerTests.test_receipt_fixture_canonical_links_actual_logs_and_inputs']
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,selection=names,scope='7matchingNEW+8affected poll/buffer/defer/finalization/creator/history/nonzero/Fixture callers at NEWsourceepoch; no oldepoch replay/aggregate/current20canonical',final_hashes=h),f,indent=2)
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,tm))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 with (q/'tests.log').open('x') as f:f.write(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_original_runtime_admission=True)
 with (q/'result.json').open('x') as f:json.dump(value,f,indent=2)
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];entry=n['auxiliary_direct_wait_progress']
 entry.update(candidate_UNIMPLEMENTED=False,review_pending=False,model_review_status=json.loads((P/'review/finish.json').read_text())['status'],after_selected=str(q/'result.json'),after_selected_tests=value['tests'],after_selected_failures=value['failures'],after_selected_errors=value['errors'],ROOT_final_qualification_pending=True,source_uncommitted_uncanonical_unadmitted=True)
 n['current_helper_source_epoch'].update(producer_sha256=value['source_sha256'],test_sha256=value['test_sha256'],hashes_file=str(P/'after-edit-hashes.json'),final_epoch_UNTESTED=False,verification_scope='NEW direct wait candidate: selected15 result recorded; ROOTfinal pending; not current20canonical/runtime admission')
 c['active_turn_status']='Aux_direct_wait_candidate_implemented_afterselection_recorded_ROOTqualification_pending_no_SDK_native_capture';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:value[k] for k in ['tests','failures','errors','source_sha256','test_sha256']}));print(out.getvalue()[-6500:])
