import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');result=json.loads((p/'before/result.json').read_text());assert (result['tests'],result['failures'],result['errors'])==(7,4,0)
 reports=[];journals=[]
 for path in sorted((p/'before/fixtures').rglob('wait-before-cleanup.json')):
  raw=path.read_bytes();d=json.loads(raw);reports.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
  assert d['original_handle_retained'] is True
  calls=[x for x in d['events'] if x['stage'].startswith('native_')]
  if d['mode']=='foreign-before':assert len(calls)==1 and calls[0]['stage']=='native_foreign_wait' and d['natural_wait_status']==0
  if d['mode']=='drift':assert d['public_handle_is_original'] is False and d['natural_wait_status']==0 and d['raised_is_ProducerError'] is False
  if d['mode']=='invalid-bool':assert d['raised_is_ProducerError'] is True and d['guard_raises_received_first'] is False
  if d['mode']=='unknown-return':assert d['raised_is_injected'] is True and d['guard_raises_received_first'] is False and d['source_private_first'] is False
 for path in sorted((p/'before/fixtures').rglob('wait-unit-cleanup.json')):
  raw=path.read_bytes();d=json.loads(raw);journals.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=d))
 waits=[r for j in journals for r in j['data'] if r['kind']=='bound_same_finite_wait'];assert len(reports)==7 and len(journals)==7 and len(waits)==14
 assert all(type(r['status']) is int and r['status']==r['expected'] for r in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_epoch='1ba592/95e1fb',NEWbefore7='4FAIL3normalPASS0ERROR',public_pointer_foreign_directwait_observed=True,post_return_drift_wait_witness_published0=True,boolFalse_rejected_but_permanent_first_guard_missing=True,directcallee_unknownerror_first_guard_missing_notclaimed_fullwaitcaller_bug=True,normalcached0_cached7_actualTimeoutExpired_PASS=True,reports=reports,journals=journals,known_finite_bound_waits=14,signed0_rows=sum(1 for r in waits if r['status']==0),signed7_rows=sum(1 for r in waits if r['status']==7),cached_possible=True,only_pureguardprobe_aftererror_no_second_source_wait_poll=True,unit_finite_filegate_release_NOTbenchmarkfreeze=True,selected_parentFDfacts_NOTfullchildFD_instruction_delegate_census_or_physicalEX=True,source_UNCHANGED_candidate_UNIMPLEMENTED=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_direct_wait_progress']=dict(path=str(p),candidate_UNIMPLEMENTED=True,historical_before_epoch='1ba592/95e1fb',NEWbefore7='4FAIL3normalPASS0ERROR',ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),planning_status=0,review_pending=True,read_select_lease_backingFD_init_generic_enclosing_historical_fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 c['active_turn_status']='Aux_direct_wait_NEWbefore7_4FAIL3normalPASS_candidate_unexecuted_review_pending_source_unchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(NEWbefore7='4FAIL3normalPASS0ERROR',known_finite_boundwaits=14,signed0=assessment['signed0_rows'],signed7=assessment['signed7_rows'],source_unchanged=True)))
