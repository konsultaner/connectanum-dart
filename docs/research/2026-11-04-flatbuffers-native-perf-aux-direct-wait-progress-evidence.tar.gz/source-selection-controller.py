import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW Aux direct SAMEactor Popen.wait original handle/lookup/args/attempt/rawreturn/timeout progress; source/test snapshot and narrow methods only; no tests/models/SDK/nativebuild/HEAD/Git/archive/cleanup',producer_expected='1ba5924728472e9f55ee975f7d29a76de8085d47671c4d886acdf0b12ad45f00',test_expected='95e1fbf72f27df45be7c357fad6b43c080f9a1fb531a1685f03affc608ce613d',actual_official_EX=True,prior_components_consumed_no_unchanged_repeats=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='1ba5924728472e9f55ee975f7d29a76de8085d47671c4d886acdf0b12ad45f00' and hashlib.sha256(tests).hexdigest()=='95e1fbf72f27df45be7c357fad6b43c080f9a1fb531a1685f03affc608ce613d'
 for name,data in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(data)
 source=source.decode();c=next(x for x in ast.parse(source).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 methods={x.name:ast.get_source_segment(source,x) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in ('_wait_natural_status','wait','_constructor_guard','_constructor_record')}
 with (P/'selected-source.json').open('x') as f:json.dump(methods,f,indent=2)
 l.verify_identity();print(methods['_wait_natural_status'])
