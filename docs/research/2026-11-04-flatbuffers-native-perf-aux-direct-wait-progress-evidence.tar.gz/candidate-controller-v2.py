import sys,pathlib,json,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');before=(p/'source-before.py').read_text();s=before
 methods=(p/'candidate-methods.py.txt').read_text();init=(p/'candidate-init.py.txt').read_text();schema=(p/'candidate-schema.py.txt').read_text();full=(p/'candidate-complete-guard-v2.txt').read_text()
 c=next(x for x in ast.parse(before).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');old=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_wait_natural_status')
 rows=before.splitlines(True);oldblock=''.join(rows[old.lineno-1:old.end_lineno]);assert s.count(oldblock)==1;s=s.replace(oldblock,methods,1)
 needle='        self.intent={';assert s.count(needle)==1;s=s.replace(needle,init+needle,1)
 needle='        self._status_poll_guard()\n\n    def _constructor_record';assert s.count(needle)==1;s=s.replace(needle,'        self._status_poll_guard()\n        self._direct_wait_guard()\n\n    def _constructor_record',1)
 c=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');node=next(x for x in c.body if isinstance(x,ast.FunctionDef) and x.name=='_complete')
 body=ast.get_source_segment(s,node);needle='        self._constructor_guard()\n';assert body.count(needle)==1;replacement=body.replace(needle,needle+full,1);assert s.count(body)==1;s=s.replace(body,replacement,1)
 needle="            buffer_state=values.get('_buffer_write_state');buffer_journal=values.get('_buffer_write_journal')";assert s.count(needle)==1;s=s.replace(needle,schema+needle,1)
 fields="                direct_wait_fields_valid=wait_ok,direct_wait_quarantined=wait_quarantined,\n                direct_wait_entries=len(wait_journal) if type(wait_journal) is list else None,\n                direct_wait_returned=wait_last.get('returned') if type(wait_last.get('returned')) is bool else None,\n                direct_wait_raw_status=wait_last.get('raw_return') if type(wait_last.get('raw_return')) is int else None,\n                direct_wait_timeout_received=wait_last.get('timeout_received') if type(wait_last.get('timeout_received')) is bool else None,\n                direct_wait_completed=wait_last.get('completed') if type(wait_last.get('completed')) is bool else None,\n"
 needle='                buffer_write_fields_valid=buffer_ok,buffer_write_quarantined=buffer_quarantined,';assert s.count(needle)==1;s=s.replace(needle,fields+needle,1);ast.parse(s)
 for name,body in [('candidate-producer-v2.py',s),('old-direct-wait-block-v2.txt',oldblock),('candidate-data-fields-v2.txt',fields)]:
  with (p/name).open('x') as f:f.write(body)
 with (p/'candidate-v2.diff').open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='1ba592-before',tofile='NEW-direct-wait-candidate')))
 l.verify_identity();print('private direct wait candidate UNEXECUTED; no source edit')
