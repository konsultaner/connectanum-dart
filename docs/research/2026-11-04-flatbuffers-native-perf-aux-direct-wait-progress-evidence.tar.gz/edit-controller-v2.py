import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-direct-wait-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-status-poll-progress-v1/after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 before=(P/'source-before.py').read_text();oldtests=(P/'tests-before.py').read_text();candidate=(P/'candidate-producer-v2.py').read_text();newtests=(P/'new-tests.py').read_text()
 assert (R/'tool/native_perf_build_producer.py').read_text()==before and (R/'tool/test_native_perf_build_producer.py').read_text()==oldtests
 methods=(P/'candidate-methods.py.txt').read_text();init=(P/'candidate-init.py.txt').read_text();schema=(P/'candidate-schema.py.txt').read_text();fields=(P/'candidate-data-fields-v2.txt').read_text()
 projected=candidate.replace(methods,(P/'old-direct-wait-block-v2.txt').read_text(),1).replace(init,'',1).replace('        self._direct_wait_guard()\n','',1).replace((P/'candidate-complete-guard-v2.txt').read_text(),'',1).replace(schema,'',1).replace(fields,'',1)
 assert projected==before;tests=oldtests+'\n\n'+newtests+'\n\n'+(P/'new-history-test.py').read_text();ast.parse(candidate);ast.parse(tests)
 declaration=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_official_EX=True,scope='Aux direct SAMEactor wait original normal-constructor handle/lookup/timeout/attempt/rawreturn/postchecks; expected stable TimeoutExpired preserved; init/ctor-guard/complete-history-precheck/typedDATA+7newtests',NEWbefore7='4FAIL3normalPASS0ERROR',separate_NEW_history_guard1='1FAIL0ERROR',review_before_final_wrapper_hunk_and_new_control=True,old_source_sha256=hashlib.sha256(before.encode()).hexdigest(),old_test_sha256=hashlib.sha256(oldtests.encode()).hexdigest(),new_source_sha256=hashlib.sha256(candidate.encode()).hexdigest(),new_test_sha256=hashlib.sha256(tests.encode()).hexdigest(),original_source_BYTEprojectsback=True,original_tests_PREFIXexact=True,no_SDK_nativebuild_canonical_capture_sourceadoption=True)
 with (P/'edit-declaration.json').open('x') as f:json.dump(declaration,f,indent=2)
 with (P/'source-write-attempt.json').open('x') as f:json.dump(dict(path=str(R/'tool/native_perf_build_producer.py'),sha256=declaration['new_source_sha256']),f)
 (R/'tool/native_perf_build_producer.py').write_text(candidate)
 with (P/'tests-write-attempt.json').open('x') as f:json.dump(dict(path=str(R/'tool/test_native_perf_build_producer.py'),sha256=declaration['new_test_sha256']),f)
 (R/'tool/test_native_perf_build_producer.py').write_text(tests)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert all(after[k]==v for k,v in h.items() if 'build_producer.py' not in k)
 for name,body in [('after-producer.py',candidate),('after-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(body)
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(after,f,indent=2)
 with (P/'edit-invariants.json').open('x') as f:json.dump(dict(original_source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_exact=True,all_old_factories_gates_defer_emit_freeze_auxpredicates_exact=True,production601_unedited=True,new_epoch_UNTESTED=True),f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_direct_wait_progress'];v.update(candidate_UNIMPLEMENTED=False,new_epoch_UNTESTED=True,after_edit_hashes=str(P/'after-edit-hashes.json'),review_pending=False)
 n['current_helper_source_epoch'].update(producer_sha256=after['tool/native_perf_build_producer.py'],test_sha256=after['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'after-edit-hashes.json'),final_epoch_UNTESTED=True,verification_scope='NEW direct wait progress candidate UNTESTED; before7=4FAIL3normalPASS; not current20canonical/admission')
 c['active_turn_status']='Aux_direct_wait_candidate_implemented_UNTESTED_noSDK_native_capture';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=after['tool/native_perf_build_producer.py'],test=after['tool/test_native_perf_build_producer.py'],source_projectsback=True,other18helpers3bins_exact=True,UNTESTED=True)))
