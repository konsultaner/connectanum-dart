class AuxiliaryDirectWaitProgressTests(unittest.TestCase):
    """NEW original-handle/direct wait progress; finite unit actors only."""
    def _wait_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-direct-wait-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        release=base/'finite-pending-release';auxiliaries=[];actors=[];logs={};pipes=[];closed=[];closed_numbers=set()
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close
        real_allocate=producer.AuxiliaryCommand._allocate_process
        events=[];cleanup=[];a=None;b=None;raised=None;guard_error=None;returned=object();first=OSError(5,'OWN native poll return hidden by ROOT fault')
        def allocate(current,record):
            value=real_allocate(current,record)
            actors.append(dict(name=current.name,process=value,bound_wait=value.wait,bound_poll=value.poll,expected=7 if current.name=='wait-source' and mode=='nonzero' else 0))
            return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for name in ('wait-source','wait-foreign'):
                for role in ('stdout','stderr'):
                    if path==base/(name+'.'+role):logs[name+'.'+role]=value
            return value
        def piping():
            value=native_pipe()
            for fd in value:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            value=native_close(fd);closed_numbers.add(fd);closed.append(dict(fd=fd,raw_None=value is None));return value
        def latest():
            journal=getattr(a,'_direct_wait_journal',None)
            return journal[-1] if type(journal) is list and journal and type(journal[-1]) is dict else {}
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                if mode=='pending':
                    code="import pathlib,time;p=pathlib.Path("+repr(str(release))+");end=time.monotonic()+8\nwhile not p.exists() and time.monotonic()<end: time.sleep(.005)"
                else:code='raise SystemExit('+str(7 if mode=='nonzero' else 0)+')'
                a=producer.AuxiliaryCommand(directory=base,name='wait-source',argv=[sys.executable,'-c',code],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);auxiliaries.append(a);a.start()
                b=producer.AuxiliaryCommand(directory=base,name='wait-foreign',argv=[sys.executable,'-c','pass'],
                    cwd=base,environment=dict(os.environ),lease_check=lambda:None);auxiliaries.append(b);b.start()
                original=next(x for x in actors if x['name']=='wait-source')
                foreign=next(x for x in actors if x['name']=='wait-foreign')
                if mode!='pending':
                    status=original['bound_wait'](10);events.append(dict(stage='ROOT_pre_wait_source',status=status,cached_possible=True))
                    self.assertEqual(original['expected'],status)
                status=foreign['bound_wait'](10);events.append(dict(stage='ROOT_pre_wait_foreign',status=status,cached_possible=True));self.assertEqual(0,status)
                timeout_error=None
                def source_wait(*,timeout):
                    nonlocal timeout_error
                    row=latest();intent=(row.get('process') is original['process']
                        and row.get('wait_attempted') is True and row.get('returned') is None)
                    try:value=original['bound_wait'](timeout=timeout)
                    except subprocess.TimeoutExpired as error:
                        timeout_error=error;events.append(dict(stage='native_source_wait_timeout',source_intent_before_native=intent,timeout=timeout));raise
                    events.append(dict(stage='native_source_wait',raw_return=value,source_intent_before_native=intent,timeout=timeout))
                    if mode=='drift':a.process=foreign['process']
                    if mode=='invalid-bool':return False
                    if mode=='unknown-return':raise first
                    return value
                def foreign_wait(*,timeout):
                    value=foreign['bound_wait'](timeout=timeout);events.append(dict(stage='native_foreign_wait',raw_return=value,timeout=timeout));return value
                original['process'].wait=source_wait;foreign['process'].wait=foreign_wait
                if mode=='foreign-before':a.process=foreign['process']
                try:returned=a._wait_natural_status(timeout=0)
                except BaseException as error:raised=error
                if mode in ('foreign-before','drift','invalid-bool','unknown-return','pending'):
                    # Pure guard only; no second source native wait or poll.
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            row=latest();native_calls=[x for x in events if x['stage'].startswith('native_')]
            report=dict(mode=mode,events=events,raised_is_injected=raised is first,
                raised_is_ProducerError=type(raised) is producer.ProducerError,
                raised_is_original_timeout=timeout_error is not None and raised is timeout_error,
                guard_raises_received_first=raised is not None and guard_error is raised,
                guard_error_absent=guard_error is None,
                original_handle_retained=a._constructor_quarantine.get('allocated_process') is original['process'],
                public_handle_is_original=a.process is original['process'],
                source_status_is_None=a.status is None,source_status=a.status,
                method_return=returned if type(returned) is int else None,
                natural_wait_observed=a._natural_wait_observed,natural_wait_status=a._natural_wait_status,
                natural_wait_process_original=a._natural_wait_process is original['process'],
                pending=a.pending,finished=a.finished,source_result_is_None=a.result is None,
                source_private_first=raised is not None and getattr(a,'_deferred_primary_error',None) is raised,
                row_present=bool(row),row_original_process=row.get('process') is original['process'],
                row_lookup_attempted=row.get('lookup_attempted'),row_lookup_returned=row.get('lookup_returned'),
                row_wait_attempted=row.get('wait_attempted'),row_returned=row.get('returned'),
                row_raw_value=row.get('raw_return'),row_value_valid=row.get('value_valid'),
                row_timeout_received=row.get('timeout_received'),row_timeout_is_original=timeout_error is not None and row.get('timeout_error') is timeout_error,
                row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                known_ROOT_created_parent_pipe_slots=pipes,known_ROOT_native_close_returns=closed,
                scope='TWO own finite SourceAux commands and ROOT bound native wait; cached returns possible; source facts not actor ownership/auth/physicalEX/SDK')
            with (base/'wait-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['original_handle_retained'])
            if mode in ('zero','nonzero'):
                self.assertIsNone(raised);self.assertIs(type(returned),int);self.assertEqual(7 if mode=='nonzero' else 0,returned)
                self.assertEqual(1,len(native_calls));self.assertEqual('native_source_wait',native_calls[0]['stage'])
                self.assertTrue(a._natural_wait_observed);self.assertIs(a._natural_wait_process,original['process'])
                self.assertEqual(returned,a._natural_wait_status)
            elif mode=='pending':
                self.assertIsNotNone(timeout_error);self.assertIs(timeout_error,raised);self.assertIsNone(guard_error)
                self.assertFalse(a._natural_wait_observed);self.assertIsNone(a._natural_wait_status)
                self.assertEqual(1,len(native_calls));self.assertEqual('native_source_wait_timeout',native_calls[0]['stage'])
            else:
                if mode=='foreign-before':
                    self.assertEqual([],native_calls);self.assertIs(type(raised),producer.ProducerError)
                elif mode in ('drift','invalid-bool'):
                    self.assertIs(type(raised),producer.ProducerError);self.assertEqual(1,len(native_calls))
                    self.assertEqual('native_source_wait',native_calls[0]['stage'])
                else:self.assertIs(first,raised);self.assertEqual(1,len(native_calls))
                self.assertIs(raised,guard_error);self.assertTrue(report['source_private_first'])
                self.assertTrue(report['row_original_process']);self.assertTrue(report['row_error_is_received'])
                self.assertIsNone(a.status);self.assertTrue(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result)
                self.assertFalse(a._natural_wait_observed);self.assertIsNone(a._natural_wait_status)
                self.assertFalse(report['row_completed'])
                if mode=='foreign-before':
                    self.assertFalse(report['row_wait_attempted']);self.assertIsNone(a._natural_wait_process)
                else:
                    self.assertTrue(native_calls[0]['source_intent_before_native'])
                    if mode=='unknown-return':self.assertIsNone(report['row_returned']);self.assertIsNone(report['row_raw_value'])
                    else:
                        self.assertIs(report['row_returned'],True)
                        if mode=='invalid-bool':self.assertIs(report['row_raw_value'],False);self.assertIsNot(report['row_value_valid'],True)
                        else:self.assertIs(type(report['row_raw_value']),int);self.assertEqual(0,report['row_raw_value'])
        finally:
            # Root-only finite release is never a source continuation/cleanup API.
            try:
                if not release.exists():
                    with release.open('x') as f:f.write('OWN finite unit release only')
            finally:
                for actor in actors:
                    value=actor['bound_wait'](10)
                    cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=actor['expected'],cached_possible=True))
                    self.assertIs(type(value),int);self.assertEqual(actor['expected'],value)
                for item in pipes:
                    fd=item['fd']
                    if fd in closed_numbers:continue
                    st=os.fstat(fd);self.assertEqual((item['dev'],item['ino']),(st.st_dev,st.st_ino));value=native_close(fd)
                    cleanup.append(dict(kind='known_ROOT_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
                for name,log in logs.items():
                    if not log.closed:
                        fd=log.fileno();st=os.fstat(fd);pt=Path(log.name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                        log.close();cleanup.append(dict(kind='known_ROOT_rawlog_close',name=name,fd=fd,returned=True))
                with (base/'wait-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_foreign_actual_handle_refuses_before_direct_wait(self):self._wait_case('foreign-before')
    def test_actual_wait_return_then_pointer_drift_refuses_witness_publish(self):self._wait_case('drift')
    def test_actual_wait_return_then_bool_is_not_status_zero(self):self._wait_case('invalid-bool')
    def test_actual_wait_return_then_fault_retains_unknown_and_first(self):self._wait_case('unknown-return')
    def test_normal_cached_zero_direct_wait_preserved(self):self._wait_case('zero')
    def test_normal_cached_nonzero_direct_wait_preserved(self):self._wait_case('nonzero')
    def test_actual_timeout_reraises_same_without_exit_or_quarantine(self):self._wait_case('pending')
