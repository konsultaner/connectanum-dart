def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))