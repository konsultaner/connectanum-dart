import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-file-snapshot-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();assert source==(P/'candidate-producer-v1.py').read_bytes();assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'snapshot_regressions-v1.py').read_bytes()
 parts=json.loads((P/'projection-parts-v1.json').read_text());assert source.decode().replace(parts['new_class'],'',1).replace(parts['new_function'],parts['old'],1)==(P/'before-producer.py').read_text()
 projection=json.loads((P/'candidate-ROOT-projection.json').read_text());assert projection['wholeSource_BYTE_projectsback'] and projection['oldtest_PREFIX_exact']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(5,4,1,0);assert(a['tests'],a['failures'],a['errors'])==(23,0,0)
 assert len(b['leases'])==10 and len(a['leases'])==46 and all(x['raw_None'] for x in b['leases']+a['leases'])
 def views(path,key):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if key in v}
 old=views(P/'before-units/fixtures','waitless_direct_snapshot');new=views(P/'after-selected/fixtures','waitless_direct_snapshot');assert len(old)==len(new)==5
 assert old['read_secondary'][0]['received_formatting'] and not old['read_secondary'][0]['received_first']
 cleanup={}
 for phase,data in [('before',old),('after',new)]:
  rows=[x for v,d in data.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text())];assert len(rows)==5
  assert sum(x['ROOT_close'] for x in rows)==(0 if phase=='before' else 3);cleanup[phase]=rows
 for mode,(v,d) in new.items():
  assert v['Source_attempt_present'] and len(v['ROOT_fds'])==1 and v['ROOT_fds'][0]['inheritable'] is False
  assert not any(x['kind'] in ('repr_first','note_first','repr_secondary') for x in v['calls'])
  if mode=='normal':assert v['Source_returned'] and v['Source_completed'] and v['Source_close_returned']
  else:
   assert not v['Source_returned'] and v['pure_guard_same_received'] and v['Source_first_received'] and not v['Source_completed'] and not v['Source_close_returned']
   row=v['Source_steps'][-1]
   if mode=='read_None':assert v['received_type']=='ProducerError' and row['stage']=='read' and row['returned'] and row['raw_None']
   else:assert v['received_first'] and not row['returned'] and row['raw_None'] and row['error_first']
   assert sum(x['kind']=='Source_close_attempt' for x in v['calls'])==(1 if mode=='close_unknown' else 0)
 affected=views(P/'after-selected/fixtures','ROOT_actual_fsync_fds')
 if not affected:
  candidates=[]
  for f in (P/'after-selected/fixtures').glob('*/view-before-ROOT-cleanup.json'):
   v=json.loads(f.read_text())
   if 'end' in str(v.get('limits','')).lower() and 'waitless_direct_snapshot' not in v:candidates.append((v,f.parent))
  affected={str(i):item for i,item in enumerate(candidates)}
 assert len(affected)==8,len(affected)
 w=[x for v,d in affected.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text()) if x.get('kind')=='ROOT_same_original_bound_wait'];assert len(w)==8 and sorted(x['status'] for x in w)==[0]*7+[3]
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]};assert all(x['status']==0 and x['both_separate_EOF'] for x in models.values())
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=5,failures=4,passes=1,errors=0,actual_originalfirst_replacement=1,scope='firstreplacement+3retention-refusalwitnesspolicies NOT4nativekernelbugs/RAMcause'),after=a,
 ROOT=dict(**projection,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,direct_unit_views=10,new_child_actors=0,affected_end_views=8,affected_same_originalboundwaits=w,parent_BEFORE_EXverify_None=10,parent_AFTER_EXverify_None=46,known_directFD_cleanup=cleanup),models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True,corrections=json.loads((P/'model-ROOT-corrections.json').read_text())),limits=json.loads("[\"ONLY_file_snapshot replaced by retained _FileSnapshotAttempt; reuse unchanged _JSONWriteAttempt pure step/privatefirst/guard only, no writer runs. All existing classes/producer methods/helpers exceptthatfunction/factories/frozenpredicates exact. Healthy Pathonce/defaultmaximum16GiB/nativeopen flags/fstat-UIDcondition shortcircuit/hash/readsize1MiB/countthenhashupdate/growth/fstat-pathstat shortcircuit/digestBEFOREclose/resultsize-SHA/ignoredclose return order preserved. No SourceSDK/GC/workload/gate/cohort changes.\",\"NEW5 BEFOREae71b6/test0226dc=4FAIL1normalPASS0ERROR. Actualreadbytes thenROOTFirst oldfinallycloses; actualreadFirst+actualcloseNone thenSecondary.__repr__raisesFormatting replacesoriginalFirst (ONEactualfirstreplacement); actualcloseNone thenROOTFirst lacksretainedunknownclose witness; actualreadbytes thenknownNone treatedEOF/laterProducerError-finallyclose. Strongerretention/refusal/return-witness policies plusfirstreplacement NOT4spontaneousnativekernelbugs/RAMcause. Final23PASS=5matchingNEW+18affected(8endcommand10actualwaitcallers); no oldwriter-regularhash-end BEFORE/model-numericalreplay/aggregate-current20canonical/admission.\",\"Sourceunknownread/close rows rawNone-returnedFalse NEVERROOTknownbytes-nativeNone-closed filled. KnownNone read rowreturnedTrue/rawNone refusedBEFOREEOF-furtherIO/close. Firstprivate latch originalerror beforesecondarymetadata. Aftersteprefusal outerexcept pureguard blockssecondfailmetadata; no Sourceclose-repr-note-nextIO-retry-replay-reset afterunknown/invalid. NormalonlyoneSourceclose; closed-fd number retainedasDATA/close_returnedflag NOTlivecapability/ownership-EXrelease/admission, no fdreset or fieldderivedcleanup.\",\"DirectNEW5 use newOWN22B files, nochild/SDK/benchmark. MODULELOCALproducer.os facade delegatesnativeopen-read-close; ROOTregisteractualFD/devino/flags/inheritable BEFOREfault. NativeO_RDONLY|NOFOLLOW|NONBLOCK|CLOEXEC unchanged/ROOTobservedinheritableFalse DATAnotactualFDexec-inheritance proof. ROOTknownFDdevino cleanup AFTERevidence onlyifsame/stillopen; BEFOREall5alreadyclosed/noRootclose; AFTER3unknown-invalidreadFDs ROOTclosed3, unknownclose+normal alreadyclosed/no reclose. ROOTknownclose NEVERSourceadopted; no borrowedFD/Sourcecleanup/fullFD-interpreter-delegate-descendantclosure.\",\"10directviews=5BEFORE5AFTER plus8affectedendcommandviews separate.10BEFORE46AFTER parentCURRENT officialDarwinEXverifyNone UNITnotfullindependentEX-originalLinuxcredentials/ownership. NEWdirectunit hasZEROchild actors;8affectedSAMEoriginalboundROOTwait10 signed7zero1three/cachedpossible separate finiteUNIT. Source/legacyfixture/internalFD/APIreturns notallserialized/no reconstruction-globalPIDscan-kill-globalabsence-fullreap; Sourceunit/controller0 notSDK-canonical-admission.\",\"Qwen64696planning0/full1104stdout393stderr;GLM65624review0/full2939stdout765stderr/BOTH EOF-naturalstatuses/fullanswers/reaped/ROOTqualified NOTwholecurrentapproval. Rejectlegacyclose/add_note forunknownread/requirecloseonceeverynegative/fakebyte-script assumptions; actualnativewrappersused. Rejectsuppresspureguard/alwayssecondfail andfdNone-reset cure: inheritedguard sourceknownpure closure raisesactualsameprivatefirst, retainedfdintegeronlyobservation/no postreturnSourceconsumer. Earlierconstructor-metadata-globalbindings-returnshapes-ABA/calleeinternals remainincomplete/no unchangedreviewrepeat.\",\"IMPORTANT: rawreadrows and hash-update args retain chunkobjects inprocess-lifetime attempts. Healthy read sizes/order remain streamed, but fixed-memory streaming is NOTestablished; logical references grow withsuccessfulreads/files. Heap/RSS magnitude/timing/leakcause UNMEASURED/no memorybound/RAMrepair/trim-pop-reset-evict-deleteauthority. Default16GiB is logicalfilelimit, notheapRSSbound. Onlynormal22B directfile plusaffectedfixturelogs tested, no largefilememory/timing claim or Sourceadoption.\",\"Candidatev1/privatev1 UNEXECUTEDbeforeedit/firstBEFORE respectively; modelseesfinalcandidate/privatev1; ROOTwholeSource-tests-AST/reverseprojection/oldtestPREFIXexact/other18helpers3bins/23hashes/fourNEWGit0-BOTH/601ownbranch20untrackedproductionempty DATA. Historicalartifacts untouched/privateartifactsoutsideHELPERBUNDLE20. RetainedbeforeSourceartifact orientation DATAonly/actualSourcehashescheckedbeforetests; no SourceHEAD scan before rootproof.\",\"All20uncommitteduncanonicalunadmitted/production601exact. EarlierSnapshotconstructor-registration/globalbindings-open-fstat-returnshapes-calleeinterior/otherAPIs/enclosing-publicunknownCtor/historical-transitive/fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission INCOMPLETE. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement. ProviderABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; PR132OPENdraft#130/issue103milestoneOPEN. Storagefloors/recheck DATA notbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.\"]"),storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());state['native_perf_only_diagnostic_design']['producer_file_snapshot_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,ROOT_pending=False,docs_pending=True);state['active_turn_status']='Producer_file_snapshot_selected23PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(state,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected23PASS=True,direct_views=10,new_child_actors=0,affected_end_views=8,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
