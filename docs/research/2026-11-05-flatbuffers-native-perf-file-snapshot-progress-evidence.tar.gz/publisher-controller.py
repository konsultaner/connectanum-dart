import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-file-snapshot-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-file-snapshot-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='5076127cf124b1481240f4d708a9b0719de60a0b'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment-v2.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Preserve snapshot read failures before cleanup or formatting\n\nThe legacy log-snapshot helper closed its FD after an unknown read return. If that close also failed and formatting the secondary error raised, it replaced the original read error. Snapshot attempts now retain the first error, FD and per-call observations before I/O. Unknown reads or closes and known invalid None reads refuse further cleanup or reporting. Native close completion stays unknown when only ROOT observed its return; the retained FD number is data, not ownership or release authority.\n\nNEW5 beforeae71b6/0226dc yields4FAIL/1normalPASS/0ERROR: one actual first replacement plus stronger retention/refusal/witness policies, not four spontaneous kernel bugs or a RAM cause. Finald42980/0c3ddf passes23selected=5matchingNEW+18affected(8endcommand10actualwaitcallers). Normal bytes, size/SHA, flags, read sizes, short-circuit order and digest-before-close remain exact. Ten direct views use no child actors; the eight affected end-command views retain finite original-bound ROOT waits. CurrentDarwinEX observations/known-FD cleanup are UNIT facts, not full independent EX/originalLinuxcredentials/allactorclosure. Qwen64696/GLM65624 complete0/fullanswers/reaped, ROOTqualified. The collector's first discriminator failed; new collector/assessment files correct readback without replaying tests/models.\n\nRead rows and hash-update arguments retain chunk objects in process-lifetime attempts. The original read size/order is preserved, but fixed-memory streaming is not established. Heap/RSS magnitude and timing are unmeasured; this is not a RAM repair. Source remains uncommitted, uncanonical and unadmitted, and strict acceptance remains incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-file-snapshot-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: preserve file snapshot first before cleanup'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_file_snapshot_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Snapshot earlierconstructor-registration/metadata-globalbindings-open-fstat-returnshapes-calleeinterior/otherAPIs/enclosing-publicunknownCtor; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Currentd42980/0c3ddf ONLY_file_snapshot retainedattempt/purefirst-stepreuse, sourceunknownread-close rawNone-returnedFalse NEVERROOTknownbytes-None-closed filled/knownNone readrowTRUE refusedBEFOREEOF-close; no Sourceclose-repr-note-nextIO-retry-replay-reset afterunknown/invalid/pureguardonly. Nativehealthyreadflags-size/hash/stat/digestBEFOREclose/ignoredclosereturn orderexact; oldallotherclassesmethodshelpersfactoriesfrozenpredicates exact/wholeSourceBYTEprojectback/oldtestPREFIXexact. NEW5beforeae71b6/0226dc=4FAIL1normalPASS0ERROR:ONEreadFirst replacedbysecondarycloseerrorreprFormatting +3retention-refusalwitnesspolicies NOT4nativekernelbugs-RAMcause; final23PASS=5NEW18affected(8end10actualwaitcallers)/no oldwriter-regularhash-end BEFORE/model-numericalreplay-aggregate-current20canonical-admission.10directviews5+5/ZEROnewchild/EX10before46after/Rootafterevidence knownFDclose3negative-readfiles only/old5+unknownclose-normalalreadyclosed/noreclose-borrowedFD.8affectedRootsameboundwait10 signed7zero1threeCached UNITnotSourcecleanup-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. RetainedfdintegerDATA notlivecapability/ownership-EXrelease/no fdreset. Qwen64696=0/1104out393err-GLM65624=0/2939out765err/fullanswers-reaped-ROOTqualified/rejectclose-everynegative/addnote/suppressguard-secondfail/fdNone-reset cure/no modelwholecurrentapproval. IMPORTANT rawreadrows/hashupdateargs retainchunkobjects processlife; readsize-order preserved NOTfixedmemory streaming; heapRSSgrowth/timing-leakcause UNMEASURED/no memorybound-RAMrepair-trim-reset-evict-deleteauthority/default16GiBlogicalfilelimitNOTheapbound. Candidatev1-privatev1UNEXECUTEDbeforeedit-firstBEFORE/controllersBEFOREcalls/ROOTwholefinalAST/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. Rootcollectorv1 exit1 wrongaffectedviewdiscriminator0/actualall8record_original_command present; newcollector-assessment-v2 preservesv1/no Source-test-model-archive replay/no Sourcebug-RAMcause. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_file_snapshot_selected23PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
