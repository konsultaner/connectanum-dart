"""NEW direct native-FD file-snapshot controls; no benchmark or child launch."""
import os
import io
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class FileSnapshotBoundaryTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_FIXTURES'])
        self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root))
        self.path=self.base/'input.bin';self.body=b'SNAPSHOT-control-bytes'
        with self.path.open('xb') as output:output.write(self.body)

    def _case(self,mode):
        calls=[];fds=[];evidence_ready=False;native_os=producer.os
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        class Formatting(RuntimeError):pass
        class Secondary(OSError):
            def __repr__(self):calls.append(dict(kind='repr_secondary'));raise formatting
        first=First('ROOT read-or-close first');formatting=Formatting('ROOT secondary rendering replaces first');secondary=Secondary('ROOT after native close')
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs)
                info=native_os.fstat(raw)
                fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)))
                calls.append(dict(kind='native_open_return',fd=raw,flags=flags))
                return raw
            def read(self,fd,size):
                raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
                if sum(x['kind']=='native_read_return' for x in calls)==1:
                    if mode in ('read_unknown','read_secondary'):raise first
                    if mode=='read_None':return None
                return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt',fd=fd));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None))
                if mode=='close_unknown':raise first
                if mode=='read_secondary':raise secondary
                return raw
        received=None;guard_error=None;returned=False;result=None;attempt=None
        try:
            before=len(getattr(producer,'_FILE_SNAPSHOT_ATTEMPTS',[]))
            with mock.patch.object(producer,'os',OSFacade()):
                try:result=producer._file_snapshot(self.path);returned=True
                except BaseException as error:received=error
            attempts=getattr(producer,'_FILE_SNAPSHOT_ATTEMPTS',[])[before:];attempt=attempts[-1] if attempts else None
            if mode!='normal' and attempt is not None:
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=[] if attempt is None else attempt.steps
            view=dict(mode=mode,waitless_direct_snapshot=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,received_formatting=received is formatting,pure_guard_same_received=received is not None and guard_error is received,
                Source_attempt_present=attempt is not None,Source_completed=None if attempt is None else attempt.completed,Source_first_received=False if attempt is None else attempt.first_error is received,
                Source_fd_None=None if attempt is None else attempt.fd is None,Source_close_returned=None if attempt is None else attempt.close_returned,
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_bytes=type(r['raw']) is bytes,error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='DirectOWNfile/nativeopen-read-close viaMODULELOCALosfacade; nochild/SDK/canonical/capture. ROOTregisteractualFD BEFOREfault; Sourceunknownbytes-closeNEVERROOTknownbytes-None-closed filled. ParentDarwinEXNone UNITnotoriginalLinux-fullindependentEX-allFD-interpreter-delegate-descendantclosure/ownership/admission. Negativepureguardonly; RootknownFDdevino closeAFTERevidence ifstillopen/same; never recloseclosedFD. Strongattempt-growthUNMEASURED/noheapRSS-leakcause-trim-reset-evict-deleteauthority.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable'])
            self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags'])
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertEqual(dict(size=len(self.body),sha256=hashlib.sha256(self.body).hexdigest()),result)
                self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls))
                if attempt is not None:self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned)
            else:
                self.assertFalse(returned)
                if mode=='read_None':self.assertTrue(type(received) is producer.ProducerError)
                else:self.assertTrue(received is first)
                self.assertTrue(attempt is not None);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed)
                self.assertFalse(any(x['kind'] in ('repr_first','note_first','repr_secondary') for x in calls))
                expected_close=1 if mode=='close_unknown' else 0
                self.assertEqual(expected_close,sum(x['kind']=='Source_close_attempt' for x in calls))
                last=rows[-1];self.assertEqual('close' if mode=='close_unknown' else 'read',last['stage'])
                if mode=='read_None':self.assertTrue(last['returned']);self.assertIsNone(last['raw'])
                else:self.assertFalse(last['returned']);self.assertIsNone(last['raw']);self.assertTrue(last['error'] is first)
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('snapshot pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);path=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(path.st_dev,path.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_native_read_then_first_stops_before_close(self):self._case('read_unknown')
    def test_actual_native_read_then_first_preserves_first_before_secondary_formatting(self):self._case('read_secondary')
    def test_actual_native_close_then_first_keeps_unknown_close_without_reclose(self):self._case('close_unknown')
    def test_actual_native_read_then_None_refuses_known_invalid_read_before_close(self):self._case('read_None')
    def test_new_normal_file_stream_bytes_size_sha_flags_and_close(self):self._case('normal')
