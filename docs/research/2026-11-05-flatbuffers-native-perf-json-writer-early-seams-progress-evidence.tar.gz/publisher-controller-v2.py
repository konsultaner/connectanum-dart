import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-early-seams-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-json-writer-early-seams-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='568937c9e02e95d19a3595ac0e2d3666195dd4dd'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation-v2.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Cover writer early API refusal paths\n\nNine new controls pass on unchanged producerb84c8e:8negative early open/lookup/enter/encode/fileno/metadata cases and1new distinct manager/enteredwriter normal case. No writer behavior fix or new production defect is established. The private class ran once before append; final test22e506 retains the exact old prefix and AST-equivalent appended class without a replay. Historical factory21 and earlier selections remain separate, not an aggregate/current20canonical/admission.\n\nROOT qualifies final source/tests/AST/23hashes/other19helpers3bins and4newGit0/BOTHstreams/601/20untracked/productiondiffempty DATA. Nine views/8knownparentFD ROOTcloses AFTERevidence and18currentDarwinEXverifyNone are UNIT facts, not Sourcepublication/durability/independentphysicalEX/originalLinuxcredentials. Qwen6967/GLM7167advisory0/fullanswers are ROOTqualified. Pathconversion/otherAPI/backingFD/enclosing-historical-transitive/fullindependentEX/runtime immutableCOMPLETE admission remain incomplete. All20helpers uncommitteduncanonicalunadmitted/production601. No SDK/build/capture/adoption/RAMrepair/strictacceptance.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-json-writer-early-seams-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: record writer early API coverage'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['json_writer_early_seams_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Pathconversion and other writer/hash/initializer API-negative seams; actual FileIO backingwriter/internalFD errors; enclosingproducer cleanup/reporting and original factory suffix intent/raw barriers; independent frozenhistorical continuation/logsealing; transitiveunknownactors/sharedjournalwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Currentproducerb84c8e UNCHANGED/test22e506 appended AST-equivalent privateNEW9PASS (8negative1normal) only; class executed once BEFOREappend/no replay. No Sourcewriter fix or new productiondefect; priorb84c8e/6908a9 factory21PASS historical/notaggregate/current20canonical/admission. UnknownPopenCtor permanentrefusal/no field-derived ownerclose API; retainknownhandles beforeIO, boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; owner_emit_attempted/oldfreezeauxpredicates unchanged; FDclose/status/EOF/helpercompletion/sourcefacts NEVEREXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='JSONwriter_early_NEW9PASS_testsonly_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
