import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-json-writer-early-seams-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1024**3
 q=P/'new-units';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_JSON_EARLY_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tests=(P/'json_writer_early_regressions-v3.py').read_bytes();tm=types.ModuleType('json_writer_early_regressions');tm.__file__=str(P/'json_writer_early_regressions-v3.py');sys.modules[tm.__name__]=tm;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 cls=tm.JSONWriterEarlySeamTests;names=unittest.defaultTestLoader.getTestCaseNames(cls);assert len(names)==9
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),candidate_tests_sha256=hashlib.sha256(tests).hexdigest(),selection=names,expected9=True,original_producer_UNCHANGED=True,no_unchanged_controls_replay=True),f,indent=2)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 out=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromTestCase(cls);result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(suite)
 (q/'tests.log').write_text(out.getvalue());value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),selection=names,leases=leases,source_UNCHANGED=True,not_canonical_runtime_admission=True,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors])
 (q/'result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['json_writer_early_seams_progress'];n.update(new_tests_pending=False,new_units=value);c['active_turn_status']='JSONwriter_early_NEW9_'+str(value['failures'])+'FAIL_'+str(value['errors'])+'ERROR_Sourceunchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(value));print(out.getvalue()[-2200:])
 if not result.wasSuccessful():sys.exit(1)
