import sys,pathlib,json,ast,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-json-writer-early-seams-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());before=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==(P/'before-producer.py').read_bytes()
 tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();addition=(P/'json_writer_early_regressions-v3.py').read_bytes()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+addition
 tree=ast.parse(tests);private=ast.parse(addition)
 cls=next(n for n in private.body if isinstance(n,ast.ClassDef) and n.name=='JSONWriterEarlySeamTests')
 assert sum(isinstance(n,ast.ClassDef) and n.name==cls.name for n in tree.body)==1
 assert ast.dump(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls.name),include_attributes=False)==ast.dump(cls,include_attributes=False)
 assert [k for k in h if h[k]!=before[k]]==['tool/test_native_perf_build_producer.py']
 result=json.loads((P/'new-units/result.json').read_text());assert(result['tests'],result['passes'],result['failures'],result['errors'])==(9,9,0,0)
 assert len(result['leases'])==18 and all(x['raw_None'] for x in result['leases'])
 found={}
 for f in sorted((P/'new-units/fixtures').glob('*/view-before-ROOT-cleanup.json')):
  v=json.loads(f.read_text());found[v['mode']]=(v,f.parent)
 assert len(found)==9
 clean=[]
 for mode,(v,base) in found.items():
  assert v['Source_attempt_present'] and v['Source_render_before_asserts']==[]
  if mode=='normal':
   assert v['completed'] and v['result_None'] and v['received_type'] is None
   assert v['Source_manager_original'] and v['Source_writer_original'] and v['native_closed']
  else:
   assert v['completed'] is False and not v['result_None'] and v['pure_guard_first_is_received'] and v['pure_guard_no_monitored_IO']
   assert not v['native_closed'] and not any(x['stage']=='exit' for x in v['events'])
   if mode=='metadata_error':
    assert v['Source_public_first_None'] and v['Source_secondary_contains_metadata']
   else:assert v['Source_public_first_is_received']
  rows=v['source_rows']
  if mode=='open_fault':assert v['Source_manager_None'] and v['Source_writer_None'] and rows[-1]['stage']=='open' and not rows[-1]['returned']
  if mode=='enter_fault':assert v['Source_manager_original'] and v['Source_writer_None'] and rows[-1]['stage']=='enter' and not rows[-1]['returned']
  if mode in ('enter_lookup','exit_lookup'):assert rows[-1]['stage']==mode and rows[-1]['method_known'] and not rows[-1]['returned']
  if mode=='write_lookup':assert rows[-1]['stage']=='write' and not rows[-1]['method_known'] and not rows[-1]['returned']
  if mode=='fileno_false':assert rows[-1]['stage']=='fileno' and rows[-1]['returned'] and rows[-1]['raw_False']
  if mode=='encode_error':assert v['received_type']=='UnicodeEncodeError' and rows[-1]['stage']=='encode' and not rows[-1]['returned']
  x=json.loads((base/'ROOT-known-writer-cleanup.json').read_text());clean.append(dict(mode=mode,**x))
 assert sum(x['attempted'] for x in clean)==8
 assert all(x['identity_match'] is True and x['returned'] is None for x in clean if x['attempted'])
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 planning=json.loads((P/'test-planning/result.json').read_text());review=json.loads((P/'test-review/result.json').read_text())
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 scope='ONLY9 previously unexecuted writer early API seams/distinct enteredwriter coverage on unchanged original producer. No new Source defect/fix or benchmark result.',
 selected_new_result=result,ROOT=dict(whole_final_source_tests_AST_qualified=True,producer_BYTES_unchanged=True,oldtests_BYTES_PREFIX_exact=True,appended_class_AST_exact_to_executed_private_v3=True,other19_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=9,known_native_ROOT_closes=clean,current_parent_EX_verify_None=18,Source_unknown_vs_ROOT_known_handles_separate=True,no_new_actor_or_child_launch=True,no_registry_reset_eviction_or_Source_replay=True),
 models=dict(planning=planning,review=review,advisory_ROOTqualified_not_wholecurrentapproval=True),
 limits=['8negatives+1new distinct manager/enteredwriter normal control pass unchanged producer; no BEFORE-failing productionregression and no Sourcefix. Tests append only after private execution; AST/BYTE equivalence validated without unchanged test or caller suite replay.',
 'Special lookup metaclass errors/open-enter-write postreturns/Falsefileno/surrogate text are controlled ROOT seams, not spontaneous kernelbugs; encode does execute actual native UnicodeEncodeError. Normal ensure_ascii output remains intact.',
 'Source open/enter raw UNKNOWN is notfilled from ROOTknown native handles. Known False fd remains invalid not0. Metadatafirst publicNone doesnot mean privatefirstlost; pure closureguard preserves exactreceivedfirst without render.',
 'No Source exit or further writer IO afterfailure; onlypureguard. Eight ROOTknownparent closes afterraws/assertions+devino check are UNITcleanup, not Sourcepublication-durability-actorcensus-physicalEXrelease/livecontinuation. Buffered output mayappear only during ROOTclose.',
 '18current parent officialDarwinEXverifyNone observations are not independent fullactualEX/originalLinuxcredentials. Initial FD/setup/interpreter-delegate-descendant calls notall serialized; no fullclosure/reap/API reconstruction claim.',
 'Pathconversion and globalUNKNOWNnamespace negative excluded/no reset-retry-replay. Invalid enteredwriter values, other invalid returns and earlier hash/init/backingFD/enclosing/historical/transitive scope remain incomplete.',
 'Registry/rows/closures/tracebacks/rawbytes growth UNMEASURED/notheapRSSbound-leak-timing-cause/reset-evict-delete authority.',
 'Privatev1-v2 UNEXECUTED; v2 corrected ROOTmode->Sourcewrite stage, v3 adds write lookup methodNone assertion BEFOREfirst execution. No invented testfailures.',
 'All20helpers uncommitteduncanonicalunadmitted/privatecontrollers outsideHELPERBUNDLE20/production601exact; no actualSDK-build-current20canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictacceptance.',
 'Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse; FD/object/status/EOF/source facts neverphysicalEX or admission.'],
 remaining=['pathconversion/otherwriter-hash-initializer negative API seams','actualFileIO backingwriter/internalFD errors','enclosingproducer cleanup/reporting and factory suffix progress','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedjournalwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['json_writer_early_seams_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],docs_pending=True);c['active_turn_status']='JSONwriter_early_NEW9PASS_Sourceunchanged_testsonly_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],new9PASS=True,producer_UNCHANGED=True,git4_0_BOTH_EOF=True,Rootknowncloses8=True,free_bytes=free,full_admission=False)))
