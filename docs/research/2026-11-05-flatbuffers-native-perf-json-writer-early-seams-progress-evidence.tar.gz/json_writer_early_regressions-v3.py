"""NEW original writer early-API seams; process-life journals are never reset."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock
import native_perf_build_producer as producer


class JSONWriterEarlySeamTests(unittest.TestCase):
    def _seam_case(self, mode):
        base=Path(tempfile.mkdtemp(prefix='writer-early-'+mode+'-',dir=os.environ.get('CONNECTANUM_JSON_EARLY_FIXTURES',tempfile.gettempdir()))).resolve()
        path=base/'data.json';value={'z':'\u00e4','a':[1,True,None]}
        events=[];handles={};render=[];flags={'armed':False}
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after native operation');metadata_error=OSError('ROOT public metadata setter')
        native_open=Path.open;native_dumps=json.dumps;native_fsync=os.fsync
        def stage(name,fn,*args,**kwargs):
            row=dict(stage=name,attempted=True,returned=False);events.append(row)
            raw=fn(*args,**kwargs);row['returned']=True
            if raw is None:row['raw_kind']='None'
            else:row['raw_kind']=type(raw).__name__
            if type(raw) in (bool,int):row['raw_value']=raw
            if (mode=='open_fault' and name=='open') or (mode=='enter_fault' and name=='enter') or (mode=='metadata_error' and name=='write'):
                if mode=='metadata_error':flags['armed']=True
                raise first
            return raw

        class Writer:
            def __getattribute__(self,name):
                if name=='write':
                    events.append(dict(stage='write_lookup'))
                    if mode=='write_lookup':raise first
                return object.__getattribute__(self,name)
            def write(self,payload):return stage('write',handles['native'].write,payload)
            def flush(self):return stage('flush',handles['native'].flush)
            def fileno(self):
                raw=stage('fileno',handles['native'].fileno)
                return False if mode=='fileno_false' else raw

        class ManagerMeta(type):
            def __getattribute__(cls,name):
                if name in ('__enter__','__exit__'):
                    label='enter_lookup' if name=='__enter__' else 'exit_lookup'
                    events.append(dict(stage=label))
                    if mode==label:raise first
                return type.__getattribute__(cls,name)

        class Manager(metaclass=ManagerMeta):
            def __enter__(self):
                stage('enter',handles['native'].__enter__)
                return handles['entered_writer']
            def __exit__(self,*args):return stage('exit',handles['native'].__exit__,*args)

        def opening(actual,*args,**kwargs):
            if actual!=path:return native_open(actual,*args,**kwargs)
            # Retain actual handle before fallible identity reads/ROOT errors.
            f=native_open(actual,*args,**kwargs);handles['native']=f
            handles['close']=f.close;handles['fileno']=f.fileno
            info=os.fstat(handles['fileno']());handles['identity']=(info.st_dev,info.st_ino)
            handles['entered_writer']=Writer();handles['manager']=Manager()
            return stage('open',lambda:handles['manager'])
        def dumping(actual,*args,**kwargs):
            raw=stage('json',native_dumps,actual,*args,**kwargs)
            # Controlled callee result, followed by actual native encode error.
            return '\ud800' if mode=='encode_error' else raw
        def syncing(fd):return stage('fsync',native_fsync,fd)
        def setting(a,name,raw):
            if name=='first_error' and flags['armed']:raise metadata_error
            object.__setattr__(a,name,raw)

        received=None;sentinel=object();result=sentinel
        with mock.patch.object(Path,'open',opening),mock.patch.object(producer.json,'dumps',dumping),mock.patch.object(producer.os,'fsync',syncing),mock.patch.object(producer._JSONWriteAttempt,'__setattr__',setting,create=True):
            try:result=producer._write_json(path,value)
            except BaseException as error:received=error
        records=producer._JSON_WRITE_ATTEMPTS
        found=[r for r in records if r.path==path];attempt=found[-1] if found else None
        pure_error=None;before_guard=len(events)
        if mode!='normal' and attempt is not None:
            try:attempt.guard()
            except BaseException as error:pure_error=error
        output=path.read_bytes() if path.exists() else None
        rows=[] if attempt is None else [dict(stage=r['stage'],attempted=r['attempted'],returned=r['returned'],raw_kind='None' if r['raw'] is None else type(r['raw']).__name__,raw_False=r['raw'] is False,method_known=r['method'] is not None,error_is_received=r['error'] is received and received is not None) for r in attempt.steps]
        view=dict(mode=mode,events=events,source_rows=rows,received_type=None if received is None else type(received).__name__,received_original=received is first,
            completed=None if attempt is None else attempt.completed,result_None=result is None,Source_attempt_present=attempt is not None,
            Source_manager_original=attempt is not None and attempt.manager is handles.get('manager'),Source_manager_None=attempt is not None and attempt.manager is None,
            Source_writer_original=attempt is not None and attempt.writer is handles.get('entered_writer'),Source_writer_None=attempt is not None and attempt.writer is None,
            Source_public_first_is_received=attempt is not None and attempt.first_error is received and received is not None,
            Source_public_first_None=attempt is not None and attempt.first_error is None,
            Source_secondary_contains_metadata=attempt is not None and any(x is metadata_error for x in attempt.secondary_errors),
            pure_guard_first_is_received=pure_error is received and received is not None,pure_guard_no_monitored_IO=before_guard==len(events),Source_render_before_asserts=list(render),
            native_closed=handles['native'].closed,ROOT_native_identity=list(handles['identity']),output_size=None if output is None else len(output),output_sha256=None if output is None else hashlib.sha256(output).hexdigest(),
            limits='Unique literal path; no reset/replay/second Sourcewrite. Current official EX parent only, not independent physicalEX/originalLinuxcredentials/full backingFD-delegate census/durability/admission.')
        (base/'view-before-ROOT-cleanup.json').write_text(native_dumps(view,indent=2)+'\n')
        if output is not None:(base/'observed-output.bin').write_bytes(output)
        try:
            self.assertIsNotNone(attempt)
            self.assertEqual([],render)
            if mode=='normal':
                self.assertIsNone(received);self.assertIsNone(result);self.assertTrue(attempt.completed)
                self.assertIs(attempt.manager,handles['manager']);self.assertIs(attempt.writer,handles['entered_writer']);self.assertIsNot(attempt.manager,attempt.writer)
                self.assertEqual((native_dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode(),output)
                self.assertEqual(['path','open','enter_lookup','exit_lookup','enter','json','encode','write','flush','fileno','fsync','exit'],[r['stage'] for r in attempt.steps])
            else:
                self.assertIsNotNone(received);self.assertIs(result,sentinel);self.assertFalse(attempt.completed)
                if mode=='encode_error':self.assertIs(type(received),UnicodeEncodeError)
                elif mode=='fileno_false':self.assertIs(type(received),producer.ProducerError)
                else:self.assertIs(received,first)
                self.assertIs(pure_error,received);self.assertEqual(before_guard,len(events))
                self.assertFalse(any(e['stage']=='exit' for e in events))
                failed={'open_fault':'open','enter_fault':'enter','metadata_error':'write','encode_error':'encode','fileno_false':'fileno','write_lookup':'write'}.get(mode,mode)
                self.assertEqual(failed,attempt.steps[-1]['stage'])
                if mode=='fileno_false':
                    self.assertTrue(attempt.steps[-1]['returned']);self.assertIs(attempt.steps[-1]['raw'],False)
                    self.assertFalse(any(e['stage']=='fsync' for e in events))
                else:
                    self.assertFalse(attempt.steps[-1]['returned']);self.assertIsNone(attempt.steps[-1]['raw'])
                if mode=='open_fault':self.assertIsNone(attempt.manager)
                else:self.assertIs(attempt.manager,handles['manager'])
                if mode in ('open_fault','enter_lookup','exit_lookup','enter_fault'):self.assertIsNone(attempt.writer)
                else:self.assertIs(attempt.writer,handles['entered_writer'])
                if mode=='exit_lookup':self.assertFalse(any(e['stage']=='enter' for e in events))
                if mode in ('enter_lookup','exit_lookup','enter_fault'):self.assertFalse(any(e['stage']=='json' for e in events))
                if mode=='write_lookup':
                    self.assertFalse(any(e['stage']=='write' for e in events));self.assertIsNone(attempt.steps[-1]['method'])
                if mode=='encode_error':self.assertFalse(any(e['stage']=='write_lookup' for e in events))
                if mode=='metadata_error':
                    self.assertIsNone(attempt.first_error);self.assertTrue(any(x is metadata_error for x in attempt.secondary_errors))
                else:self.assertIs(attempt.first_error,received)
        finally:
            # Known native handle only AFTER rawview/assertions; no Source cleanup.
            f=handles['native'];cleanup=dict(attempted=False,returned=None,identity_match=None)
            if not f.closed:
                try:
                    a=os.fstat(handles['fileno']());b=path.stat()
                    same=(a.st_dev,a.st_ino)==handles['identity']==(b.st_dev,b.st_ino)
                    cleanup['identity_match']=same
                    if same:cleanup['attempted']=True;cleanup['returned']=handles['close']()
                except BaseException as error:cleanup['error_type']=type(error).__name__
            (base/'ROOT-known-writer-cleanup.json').write_text(native_dumps(cleanup,indent=2)+'\n')

    def test_actual_open_then_ROOT_error_does_not_adopt_hidden_manager(self):self._seam_case('open_fault')
    def test_enter_special_lookup_error_stops_before_exit_lookup(self):self._seam_case('enter_lookup')
    def test_exit_special_lookup_error_stops_before_actual_enter(self):self._seam_case('exit_lookup')
    def test_actual_enter_then_ROOT_error_keeps_Source_writer_UNKNOWN(self):self._seam_case('enter_fault')
    def test_write_lookup_error_stops_before_actual_write(self):self._seam_case('write_lookup')
    def test_actual_encode_error_has_no_write_or_exit(self):self._seam_case('encode_error')
    def test_actual_fileno_then_False_is_invalid_not_fd_zero(self):self._seam_case('fileno_false')
    def test_actual_write_error_private_first_survives_public_metadata_damage(self):self._seam_case('metadata_error')
    def test_normal_distinct_manager_and_entered_writer_keep_full_bytes(self):self._seam_case('normal')
