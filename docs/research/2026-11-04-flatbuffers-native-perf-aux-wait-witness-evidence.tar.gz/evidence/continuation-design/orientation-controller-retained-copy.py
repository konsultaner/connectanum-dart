import sys,pathlib,ast,json,hashlib,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-known-actor-wait-design');p.mkdir()
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 raw=(r/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()=='76597e4c3272017326b60e1060d6135a729b53a18476b59ef16aeb632f8e41c6'
 text=raw.decode();tree=ast.parse(text)
 wanted={'AuxiliaryCommand':{'_complete','wait'},'CommandProducer':{'_drain_output'},'_RetainedPreflightOwner':{'_checked_partial_command','_wait_partial_command','_capture_known_actors','_freeze_known_actors'}}
 selected=''
 for node in tree.body:
  if isinstance(node,ast.ClassDef) and node.name in wanted:
   for f in node.body:
    if isinstance(f,ast.FunctionDef) and f.name in wanted[node.name]:
     selected+='\nCLASS '+node.name+' lines '+str(f.lineno)+'-'+str(f.end_lineno)+'\n'+ast.get_source_segment(text,f)+'\n'
 with (p/'current-selected-source.txt').open('x') as f:f.write(selected)
 with (p/'declaration.json').open('x') as f:json.dump(dict(scope='NEW readonly known-actor continuation design; no old inventory-review replay',source_sha256=hashlib.sha256(raw).hexdigest(),
 no_source_or_runtime_edit=True,no_tests_SDK_build_canonical_workload=True,existing_source_components_NOTliveadmission=True),f,indent=2)
 prompt='NEW routing question, max5 bullets <=180 words total, source only. For a future separate bounded wait on ONE exact frozen known recipe or auxiliary, identify which selected methods actually read output/wait/close/publish and which raw fields legitimately change on natural progress. Distinguish cached Popen.returncode vs actual signed wait+EOF, recipe outputFD/log/hash lifetime, auxiliary result/log lifetime, and identity bindings that must stay fixed. Inventory alone permanently blocks ordinary pipeline and has NO wait/closure authority; future API unimplemented. Do not propose cleanup/retry/retag/auxpredicate waiver or infer actor/descendant/physicalEX closure. Missing context explicitly unknown.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--repo',str(r),'--file',str(p/'current-selected-source.txt'),'--prompt',prompt,'--num-predict','1100','--max-response-chars','7000','--timeout','150','--save-output',str(p/'summary.txt')]
 with (p/'summary-command.json').open('x') as f:json.dump(argv,f,indent=2)
 with (p/'summary-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);status=proc.wait()
 with (p/'summary-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,selected_chars=len(selected),
  source_unchanged=hashlib.sha256((r/'tool/native_perf_build_producer.py').read_bytes()).hexdigest()==hashlib.sha256(raw).hexdigest()),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,summary_exists=(p/'summary.txt').exists(),selected_chars=len(selected))))
