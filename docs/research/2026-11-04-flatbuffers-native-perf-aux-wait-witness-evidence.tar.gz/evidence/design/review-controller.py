import sys,pathlib,json,difflib,subprocess,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-witness-design');e=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-witness')
 selected=''
 for rel in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'):
  a=(e/'original-source'/rel).read_text();b=(e/'fixed-source'/rel).read_text()
  selected+=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='original/'+rel,tofile='current/'+rel,n=3))
 with (p/'selected-final-diff.txt').open('x') as f:f.write(selected)
 prompt='Review this NEW narrow auxiliary direct-wait witness diff. Max2 concrete bugs <=150words TOTAL/no code. Marker records exact-int Popen.wait RETURN before fallible _complete/log/metadata IO; poll never sets it, exact Popen retained before wait, process drift refused, timeout keepsFalse/None until known wait. Scope direct METHODfact ONLY/no wait-syscall/allactor/descendant/physicalEX-release/admission/originalhost proof; no fullknownactorAPI implemented. Original wait callsites unchanged except route through helper; no newspawn/audit/producerretag/receipt, no opcode/SDK/GC/workload probe. Before7tests=6missingAPIerrors+1FAIL mockedFalse return accepted; fixed11PASS=7new+4requiredrealauxcallers. Positive actual finitePopen waits, negative boolreturn mockedONLY; fixture privatecompletion neverliveworkaround. Focus loss/overwrite of first process-status witness and actual failure ordering. Do not invent APIs/closureclaims or suggest cleanup/retry/cancel/olddata rerun.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--file',str(p/'selected-final-diff.txt'),'--prompt',prompt,'--num-predict','1800','--max-response-chars','9000','--timeout','150','--save-output',str(p/'review.txt')]
 with (p/'review-command.json').open('x') as f:json.dump(argv,f,indent=2)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(c.read_text());n=d['native_perf_only_diagnostic_design']
 h=json.loads((e/'fixed-hashes.json').read_text());n['current_helper_source_epoch']=dict(producer_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],hashes_file=str(e/'fixed-hashes.json'),all20_uncommitted_uncanonical_unadmitted=True,production601_no_edit=True)
 d['active_turn_status']='aux_wait_witness_fixed11PASS_selected_review_running_no_fullbridge_or_admission';c.write_text(json.dumps(d,indent=2)+'\n')
 with (p/'review-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);status=proc.wait()
 with (p/'review-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,selected_chars=len(selected),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py']),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,answer_exists=(p/'review.txt').exists(),selected_chars=len(selected))))
