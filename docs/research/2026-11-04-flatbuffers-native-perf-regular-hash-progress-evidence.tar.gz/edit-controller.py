import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-regular-hash-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();old=(P/'before-producer.py').read_text();tests=(P/'before-tests.py').read_text()
 assert (R/'tool/native_perf_build_producer.py').read_text()==old
 assert (R/'tool/test_native_perf_build_producer.py').read_text()==tests
 source=(P/'candidate-assembled-v2.py').read_text();newtests=tests+'\n\n'+(P/'regular_hash_regressions.py').read_text();ast.parse(source);ast.parse(newtests)
 oldother=[ast.dump(n,include_attributes=False) for n in ast.parse(old).body if not(isinstance(n,ast.FunctionDef) and n.name=='_regular_hash')]
 newother=[ast.dump(n,include_attributes=False) for n in ast.parse(source).body if not(isinstance(n,ast.FunctionDef) and n.name=='_regular_hash' or isinstance(n,ast.ClassDef) and n.name=='_RegularHashAttempt' or isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='_REGULAR_HASH_ATTEMPTS' for x in n.targets))]
 assert oldother==newother
 (R/'tool/native_perf_build_producer.py').write_text(source);(R/'tool/test_native_perf_build_producer.py').write_text(newtests)
 before=json.loads((P/'before-hashes.json').read_text());h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in before}
 changed=[k for k in before if h[k]!=before[k]];assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').write_text(source);(P/'after-tests.py').write_text(newtests);(P/'after-edit-hashes.json').write_text(json.dumps(h,indent=2))
 result=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],other18_helpers3bins_unchanged=True,all_old_tests_PREFIX_exact=True,other_source_AST_exact=True,JSON_writer_CLASS_and_function_BYTE_exact=True,candidates_UNEXECUTED_before_edit=True)
 (P/'edit-result.json').write_text(json.dumps(result,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['regular_hash_progress'];n.update(source_UNCHANGED=False,candidate_UNIMPLEMENTED=False,edit=result,model_pending=False,after_pending=True);c['active_turn_status']='RegularHash_NEW8_before6FAIL2PASS_minimalrepair_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(result))
