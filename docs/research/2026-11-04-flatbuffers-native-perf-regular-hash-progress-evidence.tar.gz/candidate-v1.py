# Read-attempt records are observations, never credentials or ownership.
_REGULAR_HASH_ATTEMPTS = []


class _RegularHashAttempt(_JSONWriteAttempt):
    def __init__(self,path,maximum,owners):
        # Reuse only unchanged pure step/first-error machinery. No writer runs.
        super().__init__(path,None)
        self.maximum=maximum
        self.owners=owners
        self.fd=None
        self.digest=None

    def run(self):
        call=self._step
        fail=self._fail
        original_path=self.original_path
        maximum=self.maximum
        owners=self.owners
        try:
            if owners is None:owners={call('getuid',lambda:os.getuid)}
            path=call('path',lambda:Path,(original_path,))
            self.path=path
            absolute=call('is_absolute',lambda:path.is_absolute)
            if absolute is not True:raise ProducerError('input path must be canonical without symlinks')
            resolved=call('resolve',lambda:path.resolve,(),dict(strict=True))
            if type(resolved) is not type(path) or resolved!=path:
                raise ProducerError('input path must be canonical without symlinks')
            before=call('stat_before',lambda:path.stat,(),dict(follow_symlinks=False))
            if type(before) is not os.stat_result:raise ProducerError('unknown input stat return')
            fd=call('open',lambda:os.open,(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC))
            if type(fd) is not int or fd<0:raise ProducerError('unknown input open return')
            self.fd=fd
            info=call('fstat',lambda:os.fstat,(fd,))
            if type(info) is not os.stat_result:raise ProducerError('unknown input fstat return')
            identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
            if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
                raise ProducerError('input type/owner/mode/size differs')
            if identity(before)!=identity(info):raise ProducerError('input changed before read')
            h=call('hash_ctor',lambda:hashlib.sha256)
            count=0
            while True:
                requested=min(1024**2,maximum+1-count)
                part=call('read',lambda:os.read,(fd,requested))
                if type(part) is not bytes or len(part)>requested:
                    raise ProducerError('unknown input read return')
                if not part:break
                updated=call('hash_update',lambda:h.update,(part,))
                if updated is not None:raise ProducerError('unknown input hash update return')
                count+=len(part)
                if count>maximum:raise ProducerError('input grew beyond bound')
            if count!=info.st_size:raise ProducerError('input changed during read')
            final_info=call('fstat_after',lambda:os.fstat,(fd,))
            if type(final_info) is not os.stat_result or identity(final_info)!=identity(info):
                raise ProducerError('input changed during read')
            final_path=call('stat_after',lambda:path.stat,(),dict(follow_symlinks=False))
            if type(final_path) is not os.stat_result or identity(final_path)!=identity(info):
                raise ProducerError('input changed during read')
            digest=call('hexdigest',lambda:h.hexdigest)
            if type(digest) is not str or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
                raise ProducerError('unknown input digest return')
            closed=call('close',lambda:os.close,(fd,))
            if closed is not None:raise ProducerError('unknown input close return')
            self.digest=digest
            self.completed=True
            return digest
        except BaseException as error:
            fail(error,self.steps[-1] if self.steps else None)


def _regular_hash(path, maximum=1024**3, *, owners=None):
    attempt=_RegularHashAttempt(path,maximum,owners)
    _REGULAR_HASH_ATTEMPTS.append(attempt) # Retain BEFORE path/FD operations.
    return attempt.run()
