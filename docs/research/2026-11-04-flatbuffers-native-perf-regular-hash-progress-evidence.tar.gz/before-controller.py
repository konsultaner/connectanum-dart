import sys,json,pathlib,hashlib,subprocess,os,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-regular-hash-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 for name,snapshot in [('native_perf_build_producer.py','before-producer.py'),('test_native_perf_build_producer.py','before-tests.py')]:
  assert (R/'tool'/name).read_bytes()==(P/snapshot).read_bytes(),name
 floor=shutil.disk_usage(P).free
 assert floor>=1024**3
 q=P/'before-units';q.mkdir()
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(P)+os.pathsep+str(R/'tool');env['CONNECTANUM_REGULAR_HASH_FIXTURES']=str(q/'fixtures');pathlib.Path(env['CONNECTANUM_REGULAR_HASH_FIXTURES']).mkdir()
 argv=[sys.executable,'-B','-m','unittest','-v','regular_hash_regressions.RegularHashProgressTests']
 (q/'command-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(P),helper_sha256=hashlib.sha256((P/'regular_hash_regressions.py').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((R/'tool/native_perf_build_producer.py').read_bytes()).hexdigest(),free_bytes=floor,Popen_attempted=True,pid=None),indent=2))
 child=subprocess.Popen(argv,cwd=P,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (q/'start.json').write_text(json.dumps(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())))
 out,err=child.communicate();status=child.wait();(q/'stdout.bin').write_bytes(out);(q/'stderr.bin').write_bytes(err)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 (q/'result.json').write_text(json.dumps(result,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['regular_hash_progress'];n.update(before_units=result,NEWtests_UNEXECUTED=False,candidate_UNIMPLEMENTED=True,source_UNCHANGED=True,model_pending=False);cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(result));print(err.decode(errors='replace')[-1500:])
