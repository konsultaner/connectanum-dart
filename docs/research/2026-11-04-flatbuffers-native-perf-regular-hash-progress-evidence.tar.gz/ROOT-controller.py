import sys,pathlib,json,ast,hashlib,subprocess,re,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-regular-hash-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert source==(P/'candidate-assembled-v2.py').read_text()
 assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'regular_hash_regressions.py').read_text()
 old=ast.parse((P/'before-producer.py').read_text());current=ast.parse(source)
 other=lambda t:[ast.dump(n,include_attributes=False) for n in t.body if not(isinstance(n,ast.FunctionDef) and n.name=='_regular_hash' or isinstance(n,ast.ClassDef) and n.name=='_RegularHashAttempt' or isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='_REGULAR_HASH_ATTEMPTS' for x in n.targets))]
 assert other(old)==other(current)
 beforelog=(P/'before-units/stderr.bin').read_text();matches=re.findall(r'^(test_.*) \.\.\. (FAIL|ok|ERROR)$',beforelog,re.M)
 assert len(matches)==8 and sum(x[1]=='FAIL' for x in matches)==6 and sum(x[1]=='ok' for x in matches)==2
 after=json.loads((P/'after-selected/result.json').read_text());assert(after['tests'],after['failures'],after['errors'])==(23,0,0)
 views=lambda path:{v['mode']:v for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())]}
 b=views(P/'before-units/fixtures');a=views(P/'after-selected/fixtures');assert len(b)==len(a)==8
 assert b['read_close_note_fault']['first_is_metadata'] and b['read_close_note_fault']['render_calls']==['add_note']
 assert a['read_close_note_fault']['first_is_original'] and a['read_close_note_fault']['render_calls']==[]
 assert b['false_EOF']['result_is_digest'] and not a['false_EOF']['result_is_digest']
 for mode,v in a.items():
  assert v['source_attempt_present']
  if mode.startswith('normal'):assert v['source_completed'] and v['result_is_digest']
  else:assert not v['source_completed'] and not v['result_is_digest']
 for mode in ['read_fault','read_close_note_fault','post_fstat_fault','false_EOF','open_fault']:
  assert not any(row['stage']=='close' for row in a[mode]['events'])
 assert a['open_fault']['source_fd'] is None and type(a['open_fault']['ROOT_actual_fd']) is int
 assert a['close_fault']['ROOT_actual_close_returned'] and not a['close_fault']['source_rows'][-1]['returned']
 assert a['false_EOF']['source_rows'][-1]['raw']==dict(kind='bool',value=False)
 clean=[json.loads(f.read_text()) for f in (P/'after-selected/fixtures').glob('*/ROOT-known-FD-cleanup.json')]
 actual=[x for x in clean if x['attempted']];assert len(clean)==8 and len(actual)==5 and all(x['identity_match'] and x['returned'] is None for x in actual)
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=8,failures=6,normal_passes=2,errors=0,interpretation='read/post-read-fstat unwanted-close, readfirst-close-add_note mask, FalseEOF completion, open/close postreturn retention policies; NOT6 kernel/native defects'),after=after,ROOT=dict(whole_final_source_tests_AST_qualified=True,other_source_AST_and_JSON_writer_body_exact=True,all_old_test_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=16,known_original_FD_ROOT_cleanup_AFTER_evidence=5,hidden_open_fd_never_Source_adopted=True,normal_flags_owner_mode_size_identity_chunk_update_digest_close_order_preserved=True),models=dict(Qwen=dict(pid=93157,status=0,stdout_size=2062,stderr_size=477,advisory_ROOTqualified=True),GLM=dict(pid=93451,status=1,stdout_size=0,stderr_size=1079,reason='token limit',FULL_partial_final='ABSENT',not_reconstructed=True,reachable_reaped_NOT_unavailable_or_approval=True)),scope='Regular hash selected read/post-fstat/FalseEOF/open-close postreturn retention only; not aggregate/current20canonical/runtimeadmission',limits=['Shared pure step/error machinery reused via subclass; parent JSON writer not run and remains byte exact. Read same input can be independent observations; no resumable owner/recovery API','Native FD numbers/stat/path/count/hash/digest/None/close/EOF/source facts DATA not auth/kernelidentity/atomicABA/originalLinux credentials/ownership/physicalEX/admission','Unknown Source open or close remains UNKNOWN despite ROOT actual return; no adoption/reclose/reconstruction','Registry/rawbytes/closure/traceback growth UNMEASURED, no exactheapRSSbound/leak/timing/cause/evict-reset waiver','Initial canonical/resolve/stat/open invalidFD/stat-type/hash-update/digest/close-invalid/metadata-damage branches SOURCE only, not executed closure','Direct14callsite inventory+captured Auxhash is source data; selected FIXTURE receipts/tool-version actors are not actualSDK/build/canonical/native admission','Before8child signed1+BOTHseparateEOF; after23same-process currentofficialEX, not independent full physicalEX controller','ROOT known original FD cleanup after raw evidence UNITonly; legacy setup/actorFD/interpreter/delegate/descendant APIs not all serialized; no full closure/reap claim','Candidate v1 unexecuted; v2 assembly places subclass after parent before actual Source edit; syntax/order correction not invented runtime failure','No old selected tests/models/archives/numerical data repeat; source tools all20uncommitted-uncanonical-unadmitted; production601 exact; provider absent/gate raises/controller closed/ownershipNone/all3flagsFalse'],storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'),remaining=['unexecuted writer/hash earlierAPI-negative seams','earlier init/originalfactorypartialobject retention/backing FileIO writers','enclosingproducer cleanup/reporting','frozenhistorical independent continuation/logsealing','transitive unknown actors/sharedjournal writers/interpreterdelegates','fullindependent actualofficialEX + originalruntime immutableCOMPLETE admission before diagnostics'])
 (P/'ROOT-assessment.json').write_text(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['regular_hash_progress'];n.update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],model_pending=False);c['active_turn_status']='RegularHash_selected23PASS_ROOTqualified_DOCS_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],tests=23,git4_0_BOTH_EOF=True,free_bytes=free,admission=False)))
