"""NEW own regular-file hash IO units; never SDK/kernel/capture admission."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock
import native_perf_build_producer as producer


class RegularHashProgressTests(unittest.TestCase):
    def _hash_case(self,mode):
        root=Path(os.environ.get('CONNECTANUM_REGULAR_HASH_FIXTURES',tempfile.gettempdir()))
        base=Path(tempfile.mkdtemp(prefix='regular-hash-'+mode+'-',dir=root)).resolve()
        path=base/'input.bin';payload=b'OWN-regular-hash-\x00-body';path.write_bytes(payload)
        native_open=os.open;native_fstat=os.fstat;native_read=os.read;native_close=os.close
        events=[];reads=[];handle={};render=[];eof=False;fault=False
        class Primary(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise metadata
        primary=Primary('ROOT unknown call');metadata=OSError('ROOT note metadata fault');secondary=OSError('ROOT post-close secondary')
        def scalar(raw):
            if raw is None:return dict(kind='None',value=None)
            if type(raw) in (int,bool,str):return dict(kind=type(raw).__name__,value=raw)
            if type(raw) is bytes:return dict(kind='bytes',size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
            return dict(kind=type(raw).__name__)
        def record(stage,fn,*args):
            row=dict(stage=stage,attempted=True,returned=False);events.append(row)
            try:raw=fn(*args)
            except BaseException as error:row['error_type']=type(error).__name__;raise
            row.update(returned=True,raw=scalar(raw));return raw
        def opening(actual,flags,*args):
            nonlocal fault
            fd=record('open',native_open,actual,flags,*args);handle['fd']=fd;handle['flags']=flags
            info=native_fstat(fd);handle['identity']=(info.st_dev,info.st_ino);handle['native_close_returned']=False
            if mode=='open_fault':fault=True;raise primary
            return fd
        def stating(fd):
            nonlocal fault
            value=record('fstat',native_fstat,fd)
            if mode=='post_fstat_fault' and eof:fault=True;raise primary
            return value
        def reading(fd,size):
            nonlocal eof,fault
            value=record('read',native_read,fd,size);reads.append(value)
            if mode in ('read_fault','read_close_note_fault') and not fault:fault=True;raise primary
            if value==b'':
                eof=True
                if mode=='false_EOF':fault=True;return False
            return value
        def closing(fd):
            nonlocal fault
            value=record('close',native_close,fd);handle['native_close_returned']=True
            if mode=='read_close_note_fault':raise secondary
            if mode=='close_fault':fault=True;raise primary
            return value
        marker=object();result=marker;received=None
        with mock.patch.object(producer.os,'open',opening),mock.patch.object(producer.os,'fstat',stating),mock.patch.object(producer.os,'read',reading),mock.patch.object(producer.os,'close',closing):
            try:
                if mode=='normal_explicit':result=producer._regular_hash(path,len(payload),owners={os.getuid()})
                else:result=producer._regular_hash(path)
            except BaseException as error:received=error
        attempt=None
        records=getattr(producer,'_REGULAR_HASH_ATTEMPTS',None)
        if type(records) is list:
            candidates=[a for a in records if getattr(a,'path',None)==path]
            if candidates:attempt=candidates[-1]
        rows=[] if attempt is None else [dict(stage=r['stage'],returned=r['returned'],raw=scalar(r['raw']),error_type=None if r['error'] is None else type(r['error']).__name__) for r in attempt.steps]
        view=dict(mode=mode,events=events,render_calls=render,first_is_original=received is primary,
            first_is_metadata=received is metadata,received_type=None if received is None else type(received).__name__,
            result_is_digest=type(result) is str,result=None if type(result) is not str else result,
            source_attempt_present=attempt is not None,source_fd=None if attempt is None else attempt.fd,
            ROOT_actual_fd=handle['fd'],ROOT_actual_close_returned=handle['native_close_returned'],
            source_completed=False if attempt is None else attempt.completed,source_rows=rows,
            raw_read_sizes=[len(v) for v in reads],limits='Native parent read-FD facades only, no full FD/delegate census/atomicABA/credential/physicalEX/admission')
        (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n')
        for i,raw in enumerate(reads):(base/('read-'+str(i)+'.bin')).write_bytes(raw)
        try:
            self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,handle['flags'])
            if mode.startswith('normal'):
                self.assertTrue(received is None)
                self.assertEqual(hashlib.sha256(payload).hexdigest(),result)
                self.assertEqual(['open','fstat','read','read','fstat','close'],[x['stage'] for x in events])
                if attempt is not None:self.assertTrue(attempt.completed)
            else:
                if mode=='false_EOF':
                    self.assertTrue(received is not None,'False EOF was accepted as a complete digest')
                    self.assertEqual(['open','fstat','read','read'],[x['stage'] for x in events])
                else:
                    self.assertTrue(received is primary,'source close/add_note replaced original first')
                    if mode=='open_fault':self.assertEqual(['open'],[x['stage'] for x in events])
                    elif mode in ('read_fault','read_close_note_fault'):self.assertEqual(['open','fstat','read'],[x['stage'] for x in events])
                    elif mode=='post_fstat_fault':self.assertEqual(['open','fstat','read','read','fstat'],[x['stage'] for x in events])
                self.assertEqual([],render,'source rendered/noted the error')
                self.assertIsNotNone(attempt,'hash attempt/original FD intent not retained')
                self.assertTrue(attempt.first_error is received)
                self.assertFalse(attempt.completed)
                if mode=='open_fault':self.assertIsNone(attempt.fd,'hidden ROOT open return was adopted')
                else:self.assertEqual(handle['fd'],attempt.fd)
                count=len(events)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('pure guard accepted failed hash attempt')
                self.assertEqual(count,len(events),'pure guard performed native IO')
        finally:
            cleanup=dict(attempted=False,returned=None,identity_match=None,ROOT_already_known_native_close=handle['native_close_returned'])
            if not handle['native_close_returned']:
                try:
                    info=native_fstat(handle['fd']);info2=path.stat()
                    cleanup['identity_match']=(info.st_dev,info.st_ino)==handle['identity']==(info2.st_dev,info2.st_ino)
                    if cleanup['identity_match']:
                        cleanup['attempted']=True;cleanup['returned']=native_close(handle['fd'])
                except BaseException as error:cleanup['error_type']=type(error).__name__
            (base/'ROOT-known-FD-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_read_then_fault_has_no_source_close(self):self._hash_case('read_fault')
    def test_actual_read_first_survives_close_and_hostile_add_note(self):self._hash_case('read_close_note_fault')
    def test_actual_post_read_fstat_then_fault_has_no_source_close(self):self._hash_case('post_fstat_fault')
    def test_actual_EOF_then_False_is_not_digest_completion(self):self._hash_case('false_EOF')
    def test_actual_close_then_fault_retains_unknown_and_first(self):self._hash_case('close_fault')
    def test_actual_open_then_fault_never_adopts_hidden_ROOT_fd(self):self._hash_case('open_fault')
    def test_normal_actual_bytes_flags_digest_and_close_order(self):self._hash_case('normal')
    def test_normal_explicit_owner_and_exact_maximum_preserved(self):self._hash_case('normal_explicit')
