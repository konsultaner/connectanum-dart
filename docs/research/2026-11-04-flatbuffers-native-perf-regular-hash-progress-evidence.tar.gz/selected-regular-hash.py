def _regular_hash(path, maximum=1024**3, *, owners=None):
    owners={os.getuid()} if owners is None else owners
    path=Path(path)
    if not path.is_absolute() or path.resolve(strict=True)!=path:
        raise ProducerError('input path must be canonical without symlinks')
    before=path.stat(follow_symlinks=False)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
            raise ProducerError('input type/owner/mode/size differs')
        if identity(before)!=identity(info):raise ProducerError('input changed before read')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            h.update(part);count+=len(part)
            if count>maximum:raise ProducerError('input grew beyond bound')
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info):
            raise ProducerError('input changed during read')
        return h.hexdigest()
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('input close failed: '+repr(e))
