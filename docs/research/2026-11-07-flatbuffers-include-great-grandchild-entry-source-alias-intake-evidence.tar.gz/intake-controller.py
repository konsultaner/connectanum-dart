import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-include-grandchild-directory-inputs-v1/FIRST-originalActions-v1';P=B/'2026-11-07-actions-include-great-grandchild-entry-source-alias-intake-v1';O=A/'ROOT-NEW-ALL190-directory-input-assessment-PRIVATE.json';I=A/'actual-new-artifact-member-index.json';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST saved-data source/alias intake for ALL5067 NEW one-level entries fromoriginalActions42375656726/source06088b0d595946196f8b99aa748f2d52bf1b27bc. Exactoriginalsavedresult/index/report/priorCP sources/boundedranges declaredBEFOREcontentIO; report/index ONLYlocate originalrecords. ALL190newliteralparent-directoryrefs+EACHsinglechildbasename staySEPARATE/nativeorder-duplicates/names-namehex-modes-types-UIDGID/fulloriginalstat-times retained. Compare ONLYsaved literalnames/namehex/readlinkmetadata vsALLstrings underEVERYpriorCP actions_ node except current190acquisition andNEWintake nodes; everymatching-nonmatchingcandidate/scalarposition/location/overlappingcharacter-UTF8offset retained. Nonmatching scalar ordinal runs explicitlyderived lossless positions overfullretained scalararray, notdata discard. Eachnonlink readlink comparison UNPERFORMED/countNULL NOTzero. No pathsplit-basenameextraction/automaticjoin-normalize-resolve-follow-recursion/bodyopenhash/SDKquery-imagehash-Actions refresh/candidateexecution/import-headercompile/bootstrap-dependency-build-native-driver-perf-numerical/Source20-runtime adoption. ALL4868bodiesUNOPENED/199newdirsDEFERRED; 0NEWsymlinks/rawreadlinks THISdataset only; earlier6and18links UNEXPANDED-UNFOLLOWED/oldtopncurses.h literalcurses.h originalrawreadlinkhexNOTsavedNULL neverretrofilled. Original1425metadata/fullstat-times/63queryepochs/1229latelexical-bodyepoch/original190DEFERRED6earlierlinks/prior1280-49-1199-old63DEFERRED18olderlinks/ALLpriorledgers unchanged vsNEW190queryepoch. Matches/nonmatches NOTglobalabsence-newness-previousqueryabsence-aliasidentity-bodycoverage-effectivecompiler-defaultsysroot-CargoCFGflavor-ABI-runtimecohort-originaldrivercredentials-access-ownership-permission-queryauthority-globalnoreplayproof. No oldbody-reader-parser-model-SDKquery-imagehash-Actions-acquisition-journal-archive-numerical replay/newnamespace-alone retry. Wholeoriginalprivatefields unchanged. PointregularO_NOFOLLOW-sameFD-boundedcountSHA-stat-close notatomicABA-origin-pathchain-globalactorFD-originaldrivercredentials-access-effectivecompilerABI-continuousofficialphysicalEX-crash admission/separateouterPID-EOFNULL. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.',
 'exact_sources':[{'role':'original_saved_result','path':str(O),'range':[0,21618013],'sha256':'7d1b45c39fc32fe52e446610d2aa022ea3489b795f75941dff9ead67d47a9082'},{'role':'original_index_ONLYlocate_report','path':str(I),'range':[0,609],'sha256':'fcc2104cdc9ad3242357c46879d6db37ca51b60bc6a59c36e5612f01c9a6561a'},{'role':'located_report_ONLYoriginal_records','original_basename':'include-grandchild-directory-inputs.json','range':[0,19028747],'sha256':'2bfdcea074ba0c13cc7bc1ea2f89d3b17c403e3f01ba5ea97dff31a4581ac9bd'},{'role':'prior_CP_metadata','path':str(CP),'range':'pointFDsize declaredBEFOREcontentIO','ALL_prior_actions_nodes_excluding_exact_names':['actions_include_grandchild_directory_inputs_v1','actions_include_great_grandchild_entry_source_alias_intake_v1']}],'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-exact-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw

 originalraw=read_bounded(O,21618013,'7d1b45c39fc32fe52e446610d2aa022ea3489b795f75941dff9ead67d47a9082','original_saved_result');original=json.loads(originalraw);save('original-full-saved-result-bound-PRIVATE.json',originalraw)
 indexraw=read_bounded(I,609,'fcc2104cdc9ad3242357c46879d6db37ca51b60bc6a59c36e5612f01c9a6561a',role='original_index');index=json.loads(indexraw);found=[r for r in index if pathlib.PurePosixPath(r['name']).name=='include-grandchild-directory-inputs.json'];assert len(found)==1;ir=found[0];name=pathlib.PurePosixPath(ir['name']);assert not name.is_absolute() and '..' not in name.parts and ir['bytes']==19028747 and ir['sha256']=='2bfdcea074ba0c13cc7bc1ea2f89d3b17c403e3f01ba5ea97dff31a4581ac9bd';RP=A/'artifact-members'/ir['name']
 save('located-report-exact-source-range-BEFORE-content-IO.json',json.dumps({'path':str(RP),'range':[0,19028747],'sha256':ir['sha256'],'index_ONLYlocates_original_records_notprior_journal_comparison':True},indent=2));reportraw=read_bounded(RP,19028747,ir['sha256'],'original_report');report=json.loads(reportraw)
 assert original['ALL190_original_observations']==report['observations'] and len(report['observations'])==190 and report['workflow_revision']==original['source_commit']=='06088b0d595946196f8b99aa748f2d52bf1b27bc' and str(report['run_id'])==str(original['run_id'])=='42375656726'
 save('original-index-bound-PRIVATE.json',indexraw);save('original-report-bound-PRIVATE.json',reportraw)
 cpraw=read_bounded(CP,None,None,role='prior_CP_metadata');prior=json.loads(cpraw);save('original-prior-CP-bound-PRIVATE.json',cpraw)
 excluded=declaration['exact_sources'][3]['ALL_prior_actions_nodes_excluding_exact_names'];nodes=[key for key in prior if key.startswith('actions_') and key not in excluded];scalars=[]
 def walk(x,path):
  if isinstance(x,str):scalars.append({'location':path,'value':x})
  elif isinstance(x,dict):
   for key,value in x.items():walk(value,path+[key])
  elif isinstance(x,list):
   for ordinal,value in enumerate(x):walk(value,path+[ordinal])
 for key in nodes:walk(prior[key],[key])
 def matches(candidate):
  if candidate is None:return None
  assert isinstance(candidate,str) and candidate!='';out=[]
  for scalarordinal,scalar in enumerate(scalars):
   value=scalar['value'];positions=[];start=0
   while True:
    at=value.find(candidate,start)
    if at<0:break
    positions.append(at);start=at+1
   if positions:out.append({'prior_CP_scalar_ordinal_ZERO_based':scalarordinal,'location':scalar['location'],'original_scalar':value,'literal_character_offsets':positions,'UTF8_byte_offsets':[len(value[:at].encode('utf-8',errors='surrogatepass')) for at in positions],'exact_scalar_equal':value==candidate})
  return out
 def nonmatching_runs(matched):
  selected={row['prior_CP_scalar_ordinal_ZERO_based'] for row in matched};runs=[];start=None
  for ordinal in range(len(scalars)):
   if ordinal not in selected:
    if start is None:start=ordinal
   elif start is not None:runs.append([start,ordinal]);start=None
  if start is not None:runs.append([start,len(scalars)])
  assert sum(end-begin for begin,end in runs)+len(selected)==len(scalars)
  return runs
 relationships=[];typecounts=collections.Counter();linkrecords=[];namematched=0;hexmatched=0;linkmatched=0;linkhexmatched=0
 for parentordinal,parent in enumerate(report['observations']):
  assert parent['ordinal']==parentordinal and 'absent_at_open_only' not in parent
  for entryordinal,entry in enumerate(parent['entries']):
   assert entry['ordinal']==entryordinal and entry['parent_reference_separate_NOT_joined']==parent['source_directory_reference']
   name=entry['name'];namehex=entry['name_bytes_hex'];assert os.fsdecode(bytes.fromhex(namehex))==name and name not in ['','.','..'] and '/' not in name and '\0' not in name
   s=entry.get('separate_lstat');mode=None if s is None else s['st_mode'];typ='unknown' if mode is None else 'regular' if stat.S_ISREG(mode) else 'directory' if stat.S_ISDIR(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other';typecounts[typ]+=1
   link=entry['separate_readlink_literal'];linkhex=entry['separate_readlink_bytes_hex']
   if typ=='symlink':assert link is not None and linkhex is not None and os.fsdecode(bytes.fromhex(linkhex))==link
   else:assert link is None and linkhex is None
   safe={'source_originalActions_run_id':original['run_id'],'source_originalActions_revision':original['source_commit'],'parent_query_ordinal_ZERO_based':parentordinal,'child_entry_ordinal_ZERO_based':entryordinal,'literal_parent_reference_SEPARATE':parent['source_directory_reference'],'literal_child_name_SEPARATE':name,'original_name_bytes_hex':namehex,'saved_type_derived_from_original_mode':typ,'original_separate_lstat_full_stat_times_PRIVATE':s,'original_separate_readlink_literal_UNEXPANDED_UNFOLLOWED':link,'original_separate_readlink_rawhex_UNEXPANDED_UNFOLLOWED':linkhex,'original_full_child_record_PRIVATE':entry,'original_parent_query_record_except_children_PRIVATE':{k:value for k,value in parent.items() if k!='entries'},'parent_child_NOT_joined_resolved_followed_or_executed':True,'alias_identity':None}
   nm=matches(name);hm=matches(namehex);lm=matches(link);lhm=matches(linkhex);namematched+=bool(nm);hexmatched+=bool(hm);linkmatched+=bool(lm);linkhexmatched+=bool(lhm)
   relation={'new_saved_record_position_ONE_based':len(relationships)+1,'original_separate_parent_child_metadata':safe,'ALL_prior_CP_name_matches_PRIVATE':nm,'ALL_prior_CP_namehex_matches_PRIVATE':hm,'ALL_nonmatching_prior_CP_name_scalar_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':nonmatching_runs(nm),'ALL_nonmatching_prior_CP_namehex_scalar_ordinal_runs_ZERO_based_HALF_OPEN_PRIVATE':nonmatching_runs(hm),'prior_CP_name_comparison_performed':True,'prior_CP_namehex_comparison_performed':True,'ALL_prior_CP_link_literal_matches_PRIVATE':lm,'ALL_prior_CP_link_rawhex_matches_PRIVATE':lhm,'prior_CP_name_scalar_match_count':len(nm),'prior_CP_namehex_scalar_match_count':len(hm),'ALL_nonmatching_prior_CP_link_literal_scalar_ordinal_runs_PRIVATE':None if lm is None else nonmatching_runs(lm),'ALL_nonmatching_prior_CP_link_rawhex_scalar_ordinal_runs_PRIVATE':None if lhm is None else nonmatching_runs(lhm),'prior_CP_link_literal_scalar_match_count':None if lm is None else len(lm),'prior_CP_link_rawhex_scalar_match_count':None if lhm is None else len(lhm),'link_comparison_performed':link is not None,'alias_identity':None,'query_permission_from_matches_or_nonmatches':None};relationships.append(relation)
   if typ=='symlink':linkrecords.append(safe)
 assert len(relationships)==5067 and dict(typecounts)=={'regular':4868,'directory':199} and len(linkrecords)==0
 summary={'source_run_id':original['run_id'],'source_revision':original['source_commit'],'ALL190_original_parent_queries_preserved':190,'ALL5067_original_new_child_records':5067,'type_counts_from_original_modes':{key:typecounts[key] for key in ['regular','directory','symlink','other','unknown']},'NEW_raw_readlink_records_THISdataset':0,'ALL5067_nonlink_comparison_count_fields_UNPERFORMED_NULL':True,'prior_CP_actions_node_count':len(nodes),'prior_CP_string_scalar_count':len(scalars),'record_name_candidates_with_prior_CP_scalar_matches':namematched,'record_name_candidates_without_prior_CP_scalar_matches':5067-namematched,'record_namehex_candidates_with_prior_CP_scalar_matches':hexmatched,'record_namehex_candidates_without_prior_CP_scalar_matches':5067-hexmatched,'symlink_literal_candidates_with_prior_CP_matches':linkmatched,'symlink_literal_candidates_without_prior_CP_matches':len(linkrecords)-linkmatched,'symlink_rawhex_candidates_with_prior_CP_matches':linkhexmatched,'symlink_rawhex_candidates_without_prior_CP_matches':len(linkrecords)-linkhexmatched,'link_comparisons_performed':0,'link_comparisons_UNPERFORMED_NULL':5067,'saved_metadata_read_binding_count':len(bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_headerbody_reads':0,'new_recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'ALL5067_original_child_relationships_with_NEW_counts':relationships,'ALL_original_NEW_symlink_metadata_UNEXPANDED_UNFOLLOWED':linkrecords,'ALL190_original_parent_query_records_PRIVATE_preserved':report['observations'],'original_saved_result_ALL_fields_PRIVATE_preserved':original,'original_report_ALL_fields_PRIVATE_preserved':report,'original_index_ALL_fields_PRIVATE_preserved':index,'ALL_prior_CP_nodes_selected':nodes,'ALL_prior_CP_scalars_PRIVATE':scalars,'ALL_four_savedmetadata_read_bindings_PRIVATE_fullstat-times':bindings,'original_metadata_sources':declaration['exact_sources']}
 raw=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL5067-great-grandchild-entry-source-alias-intake-PRIVATE.json',raw);descriptor={'result_saved':'ROOT-FIRST-ALL5067-great-grandchild-entry-source-alias-intake-PRIVATE.json','result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-intake-result.json',before);d=json.loads(before);d['actions_include_great_grandchild_entry_source_alias_intake_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL5067_saved_entry_source_alias_relationships_NOT_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(raw),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_grandchild_entry_source_alias_intake='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL5067savedentry metadata/priorCPname-namehex-link relationships COMPLETE_CONSUMED; fourdeclaredbounded savedmetadata bindings/no SDKquery orbodyread. Summary thenFIRSTpublication fromoriginalsavedresult only. All4868bodiesUNOPENED/199dirsDEFERRED/0NEWlinks THISdataset; allpriorrecords-stat-times-epochs-earlier6and18linksUNEXPANDED/oldncursesrawhexNULL protected. No oldquery-reader-parser-model-Actions-acquisition-archive-numerical replay/Source20-runtime adoption/build.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
