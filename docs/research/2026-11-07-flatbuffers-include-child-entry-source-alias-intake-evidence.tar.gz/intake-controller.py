import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0829_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-include-directory-inputs-v1/Actions-v1';P=B/'2026-11-07-actions-include-child-entry-source-alias-intake-v1';CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'question':'FIRST NEW source/alias relationships for ALL1280captured child-entry records from ALL49directory metadata, not old49query/report-journal validation/SDKhash/headerbody/parser/model/Actions/archive/numerical replay.',
 'sources_BEFORE_IO':{'current_prior_CP_metadata':str(CP),'actual_saved_artifact_index':str(A/'actual-new-artifact-member-index.json'),'exact_original_saved_result':{'path':str(A/'ROOT-NEW-ALL49-directory-inputs-assessment-PRIVATE.json'),'range':[0,1807158],'sha256':'320d0e5c659e38ce3ec6d8994118541816c3f74653e69e54845a59a663cdc19a'},'report_locator':'Exact index ONLYlocates unique basename include-directory-inputs.json; exact reportpath/range1805520/SHA8c16cf4715609bb02a7ffbf2d2298bfbd723d9321914f5d219c79b75be5e8375 declared BEFOREreportIO. CP/index exact namedfiles full SAME-FD size range saved BEFOREcontent read.'},
 'comparison':'ALLpriorCP actions_* string scalar metadata EXCLUDING current acquisition actions_include_directory_inputs_v1 and this NEW intake node, no favorabletype/language-version-ABI/defaultcompiler filter. Compare literal childname/namehex/readlinkstring/rawreadlinkhex via allsubstring offsets+exactscalar flags. Keep ALLmatches/nonmatches/duplicatebasename rows/ALL49parent refs SEPARATE; never construct parent+child path, split/resolve/follow/read body/import/compile/SDKquery.',
 'epochs':'ALL210originalmetadata/160latelexical/original49DEFERREDflags unchanged vsNEW49queryepoch; all18NEWrawreadlinkbytes keptUNEXPANDED-UNFOLLOWED and NEVERretrofill old ncurses.h-curses.h originalhexNOTsavedNULL. Allfulloriginalstat-times/private fullrecords kept, no aliasidentity/newness/absence/bodycoverage/access/ownership/permission inference.',
 'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def state(fd):
  s=os.fstat(fd);return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']}
 def read(path,role,expected=None):
  row={'path':str(path),'role':role,'before_open_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};bindings.append(row);fd=None;primary=None;raw=None
  try:
   fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);row['open_return_fd']=fd;before=state(fd);row['before']=before;assert stat.S_ISREG(before['st_mode'])
   if expected:assert before['st_size']==expected['bytes']
   save('BEFORE-content-range-'+str(len(bindings))+'.json',json.dumps({'exact_path':str(path),'SAME_FD_metadata_before_content_IO':before,'bounded_range':[0,before['st_size']],'role':role},indent=2))
   parts=[];h=hashlib.sha256();done=0
   while done<before['st_size']:
    chunk=os.pread(fd,min(65536,before['st_size']-done),done)
    if not chunk:raise RuntimeError('Unexpected savedmetadata EOF; partial relationship namespace quarantined')
    parts.append(chunk);done+=len(chunk);h.update(chunk)
   assert os.pread(fd,1,done)==b'';row.update(bytes=done,sha256=h.hexdigest(),read_EOF=True)
   if expected:assert h.hexdigest()==expected['sha256']
   after=state(fd);row['after']=after;assert before==after;raw=b''.join(parts)
  except BaseException as e:primary=e;row['primary_error']={'kind':type(e).__name__,'text':str(e)}
  if fd is not None:
   try:os.close(fd);row['close_return_fd']=fd
   except BaseException as e:
    row['close_error']={'kind':type(e).__name__,'text':str(e)}
    if primary is None:primary=e
  if primary is not None:raise primary
  return raw
 try:
  rawcp=read(CP,'priorCP_metadata_NEW_child_source_alias_question');d=json.loads(rawcp);save('checkpoint-before-intake.json',rawcp)
  index=json.loads(read(A/'actual-new-artifact-member-index.json','actual_index_ONLYlocate_originalreport'));reports=[r for r in index if pathlib.PurePosixPath(r['name']).name=='include-directory-inputs.json'];assert len(reports)==1;member=reports[0];name=pathlib.PurePosixPath(member['name']);assert not name.is_absolute() and '..' not in name.parts and member['bytes']==1805520 and member['sha256']=='8c16cf4715609bb02a7ffbf2d2298bfbd723d9321914f5d219c79b75be5e8375';rp=A/'artifact-members'/name
  save('exact-report-source-declaration-BEFORE-report-IO.json',json.dumps({'path':str(rp),'range':[0,1805520],'actual_index_record':member,'ONLYlocates_originalrecords_NOToldwritejournalcomparison':True},indent=2))
  rawreport=read(rp,'originalreport_NEW_ALL1280relationships',member);report=json.loads(rawreport);assert str(report['run_id'])=='42355093028' and report['workflow_revision']=='7520bfd0c37d217e9e17d2b6be819aa32177b8a9'
  rawsaved=read(A/'ROOT-NEW-ALL49-directory-inputs-assessment-PRIVATE.json','originalsavedresult_metadata_locator_prior_epoch_ledgers_NOTjournalrecomparison',{'bytes':1807158,'sha256':'320d0e5c659e38ce3ec6d8994118541816c3f74653e69e54845a59a663cdc19a'});saved=json.loads(rawsaved);assert saved['run_id']==42355093028 and saved['source_commit']==report['workflow_revision']
  save('original-report-bound-PRIVATE.json',rawreport);save('original-saved-result-bound-PRIVATE.json',rawsaved)
  exclude={'actions_include_directory_inputs_v1','actions_include_child_entry_source_alias_intake_v1'};nodes=[k for k in d if k.startswith('actions_') and k not in exclude];scalars=[]
  def walk(x,path):
   if isinstance(x,dict):
    for k,z in x.items():walk(z,path+[k])
   elif isinstance(x,list):
    for i,z in enumerate(x):walk(z,path+[i])
   elif isinstance(x,str):scalars.append((path,x))
  for node in nodes:walk(d[node],[node])
  def allmatches(needles):
   matches=[];counts={role:0 for role,needle in needles};unperformed=[]
   for role,needle in needles:
    if needle=='':unperformed.append(role)
   for path,text in scalars:
    hits=[]
    for role,needle in needles:
     if needle=='':continue
     positions=[];start=0
     while True:
      at=text.find(needle,start)
      if at<0:break
      positions.append(at);start=at+len(needle)
     if positions:hits.append({'role':role,'exact_scalar':text==needle,'literal_substring_offsets':positions});counts[role]+=1
    if hits:matches.append({'JSON_location':path,'literal_scalar':text,'ALL_matches':hits})
   for role in unperformed:counts[role]=None
   return matches,counts,unperformed
  relationships=[];safe=[];parent_relations=[];typecounts={k:0 for k in ['regular','directory','symlink','other','unknown_lstat_point_absence']};symlinks=[]
  groups=report['observations'];assert len(groups)==49
  for group in groups:
   assert 'absent_at_open_only' not in group;parent=group['source_directory_reference'];pm,pc,pu=allmatches([('literal_parent_reference',parent)]);parent_relations.append({'directory_ordinal':group['ordinal'],'literal_parent_reference':parent,'ALL_prior_CP_matches':pm,'matching_scalar_counts':pc,'reference_NOT_joined_with_child':True})
   for entry in group['entries']:
    ordinal=len(relationships);name=entry['name'];namehex=entry['name_bytes_hex'];assert os.fsdecode(bytes.fromhex(namehex))==name and entry['parent_reference_separate_NOT_joined']==parent and entry['target_UNEXPANDED_UNFOLLOWED'] is True
    st=entry.get('separate_lstat');mode=st['st_mode'] if st is not None else None;kind=('regular' if stat.S_ISREG(mode) else 'directory' if stat.S_ISDIR(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other') if mode is not None else 'unknown_lstat_point_absence';typecounts[kind]+=1
    needles=[('literal_child_name',name),('original_name_bytes_hex',namehex)]
    link=entry['separate_readlink_literal'];linkhex=entry['separate_readlink_bytes_hex']
    if link is not None:assert isinstance(linkhex,str) and os.fsdecode(bytes.fromhex(linkhex))==link;needles += [('NEW_literal_readlink_UNEXPANDED',link),('NEW_original_readlink_bytes_hex_UNEXPANDED',linkhex)]
    matches,counts,unperformed=allmatches(needles)
    item={'ordinal':ordinal,'directory_ordinal':group['ordinal'],'child_ordinal':entry['ordinal'],'literal_parent_reference_SEPARATE':parent,'original_complete_entry_record':entry,'ALL_prior_CP_matches':matches,'matching_scalar_counts':counts,'empty_needle_comparison_unperformed_roles':unperformed,'parent_child_NOT_joined_resolved_followed_or_executed':True};relationships.append(item)
    pub={'ordinal':ordinal,'directory_ordinal':group['ordinal'],'child_ordinal':entry['ordinal'],'literal_parent_reference_SEPARATE':parent,'literal_child_name_SEPARATE':name,'original_name_bytes_hex':namehex,'saved_mode':mode,'saved_type_derived_from_original_mode':kind,'saved_uid':st['st_uid'] if st is not None else None,'saved_gid':st['st_gid'] if st is not None else None,'NEW_original_readlink_literal_UNEXPANDED_UNFOLLOWED':link,'NEW_original_readlink_bytes_hex_UNEXPANDED_UNFOLLOWED':linkhex,'matching_scalar_counts':counts,'empty_needle_comparison_unperformed_roles':unperformed,'parent_child_NOT_joined_resolved_followed_or_executed':True};safe.append(pub)
    if kind=='symlink':symlinks.append(pub)
  assert len(relationships)==1280 and len(safe)==1280 and len(parent_relations)==49 and len(symlinks)==18 and sum(typecounts.values())==1280
  qualification='FIRST NEW ALL1280literal parent/child source-alias metadata relationships only; ALL49parent refs and childnames remainSEPARATE/no lexicaljoin/resolve/follow/recursivequery/bodyopen-hash/import/compile/SDKquery/Actions/acquisition/numerical/Source20-runtime adoption. ALLmatches/offsets/locations/nonmatches/duplicatebasenames/modes-types-UIDGID/namehex/18NEWrawreadlinks preserved with no favorablelanguage-version-ABI/defaultcompiler filter or aliasdedup. PriorCPmetadata current49acquisition+thisnewintake excluded asNOTprior; no currentSDK/headerbody/imagehash/journal-oldscope refresh. Matches/nonmatches NOTaliasidentity/newness/absence/bodycoverage/access/ownership/permission/effectivecompiler-sysroot-ABI. Old210metadata/160lexicalepochs/original49DEFERREDflags unchanged vsNEW49queryepoch; oldncurses.h-curses.h originalreadlinkhexNOTsavedNULL neverretrofilled fromNEW18. ALLpriorledgers protectedNOTrevalidated. PointsameFD/read-countSHA/stat/close notatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.'
  summary={'phase':'FIRST_ALL1280_include_child_entry_source_alias_relationships_COMPLETE_CONSUMED_NOT_admitted','source_run':42355093028,'source_commit':report['workflow_revision'],'prior_CP_string_scalar_count':len(scalars),'prior_CP_actions_node_count':len(nodes),'ALL49_parent_reference_count':49,'ALL1280_entry_count':1280,'derived_original_mode_type_counts_NOT_currentquery':typecounts,'entries_with_literal_name_matches':sum(x['matching_scalar_counts']['literal_child_name']>0 for x in safe),'entries_without_literal_name_matches':sum(x['matching_scalar_counts']['literal_child_name']==0 for x in safe),'entries_with_namehex_matches':sum(x['matching_scalar_counts']['original_name_bytes_hex']>0 for x in safe),'ALL18_NEW_symlink_count':18,'new_symlinks_with_literal_target_matches':sum(x['matching_scalar_counts']['NEW_literal_readlink_UNEXPANDED']>0 for x in symlinks if x['matching_scalar_counts']['NEW_literal_readlink_UNEXPANDED'] is not None),'new_symlinks_with_raw_targethex_matches':sum(x['matching_scalar_counts']['NEW_original_readlink_bytes_hex_UNEXPANDED']>0 for x in symlinks if x['matching_scalar_counts']['NEW_original_readlink_bytes_hex_UNEXPANDED'] is not None),'read_binding_count':len(bindings),'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':qualification}
  result={'summary':summary,'ALL1280_relationships':relationships,'ALL49_parent_relationships':parent_relations,'ALL1280_safe_metadata':safe,'ALL18_NEW_symlink_metadata':symlinks,'prior_CP_actions_nodes':nodes,'ALL_prior_declared_metadata_preserved_NOT_revalidated':report['ALL_prior_declared_metadata_preserved_NOT_revalidated'],'original_NEW49_input_scope_preserved':report['NEW_ALL49_explicit_input_scope']}
  full=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL1280-source-alias-intake-PRIVATE.json',full);save('FIRST-ALL1280-summary.json',json.dumps(summary,indent=2)+'\n');save('metadata-read-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('NEW-derived-model-selection.json',json.dumps({'summary':summary,'ALL18_NEW_symlinks':symlinks,'ALL49_parent_matching_scalar_counts':[{'directory_ordinal':x['directory_ordinal'],'literal_parent_reference':x['literal_parent_reference'],'matching_scalar_counts':x['matching_scalar_counts']} for x in parent_relations]},ensure_ascii=True,indent=2))
  d['actions_include_child_entry_source_alias_intake_v1']={'directory':str(P),**summary,'original_saved_result_bytes':len(full),'original_saved_result_sha256':hashlib.sha256(full).hexdigest(),'full_assessment':str(P/'ROOT-FIRST-ALL1280-source-alias-intake-PRIVATE.json'),'public_documentation_pending':True};d['active_turn_status']['next']='NEW ALL1280child source/alias relationships COMPLETE_CONSUMED; summarize NEW data/publish ALL1280metadata/18rawlink/49parents/counts before separatelydeclared inputs. Parent/child remainSEPARATE/nojoins/no bodyqueries/recursion/Actions; CPnonmatchesNOTnewness-absence-alias-bodycoverage-permission. Oldepochs/priorledgers/oldncurseshexNULL protected/allsetupUNADMITTED/flagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
  descriptor={'result_saved':'ROOT-FIRST-ALL1280-source-alias-intake-PRIVATE.json','result_bytes':len(full),'result_sha256':hashlib.sha256(full).hexdigest(),'summary':summary};save('FIRST-original-saved-result-descriptor.json',json.dumps(descriptor,indent=2));print(json.dumps(descriptor),flush=True);lease.verify_identity()
 except BaseException as e:save('failure-bindings-PRIVATE.json',json.dumps(bindings,indent=2));save('failure.json',json.dumps({'kind':type(e).__name__,'text':str(e),'partial_unknowns_quarantined':True},indent=2));raise
