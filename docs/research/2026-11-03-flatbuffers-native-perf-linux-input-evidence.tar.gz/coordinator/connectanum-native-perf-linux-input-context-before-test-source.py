"""NEW OWN file/synthetic-proc context-bound regression; no Linux/VM/benchmark."""
import base64, contextlib, hashlib, io, json, os, sys, types, unittest
from pathlib import Path
ROOT = Path("/private/tmp/connectanum-native-perf-linux-input-context-fixtures")
SOURCE = Path("/tmp/connectanum-native-perf-linux-input-observer.py")
class ContextBound(unittest.TestCase):
    def test_context_retains_bounded_prefix_before_refusal(self):
        ROOT.mkdir(mode=0o700)
        fake = ROOT / "proc"; fake.mkdir()
        owned = ROOT / "source"; owned.mkdir()
        large = b"x" * (384 * 1024)
        for name in ("status", "uid_map", "gid_map", "mountinfo", "stat"):
            (fake / name).write_bytes(large if name == "status" else b"fixture\n")
        data = b"OWN small source\n"; (owned / "input.py").write_bytes(data)
        manifest = {"host_source_owner_uid": os.getuid(), "inputs": [
            {"name": "input.py", "sha256": hashlib.sha256(data).hexdigest()}]}
        (owned / "manifest.json").write_text(json.dumps(manifest))
        raw_source = SOURCE.read_bytes()
        module = types.ModuleType("context_observer_fixture")
        module.__file__ = str(SOURCE)
        exec(compile(raw_source, str(SOURCE), "exec"), module.__dict__)
        module.ROOT = owned
        def paths(value):
            return fake if str(value) == "/proc/self" else Path(value)
        module.Path = paths
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            status = module.main()
        raw = output.getvalue().encode()
        (ROOT / "actual-observer-output.jsonl").write_bytes(raw)
        values = [json.loads(line) for line in raw.splitlines()]
        observed = next(value for value in values if value.get("event") == "context_raw" and value["name"] == "status")
        decoded = base64.b64decode(observed["data_base64"])
        self.assertLessEqual(len(decoded), 262145)
        self.assertEqual(decoded, large[:262145])
        self.assertTrue(observed["truncated"])
        self.assertEqual(status, 1)
        self.assertFalse(values[-1]["capture_ready"])
        self.assertTrue(values[-1]["context_errors"])
if __name__ == "__main__":
    unittest.main()
