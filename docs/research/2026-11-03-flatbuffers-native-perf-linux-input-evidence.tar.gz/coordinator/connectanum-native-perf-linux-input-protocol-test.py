"""NEW synthetic protocol guards; no kernel/benchmark/admission."""
import base64, copy, hashlib, json, types, unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path("/private/tmp/connectanum-native-perf-linux-input-protocol-fixtures")
MODULE = Path("/tmp/connectanum-native-perf-linux-input-protocol.py")
class ProtocolGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        ROOT.mkdir(mode=0o700)
        cls.mod = types.ModuleType("owned_input_protocol")
        cls.mod.__file__ = str(MODULE)
        exec(compile(MODULE.read_bytes(), str(MODULE), "exec"), cls.mod.__dict__)
    def fixture(self):
        digest = hashlib.sha256(b"own").hexdigest()
        inputs = [{"name": "tool/own.py", "sha256": digest}]
        header = {"event": "observation_start", "scope": "fresh_source_input_metadata_only",
            "capture_ready": False, "source_admitted": False, "live_admission": False,
            "manifest_sha256": "b"*64, "method_source_read_sha256": "a"*64,
            **{key: "1000" for key in ("uid","euid","gid","egid")}}
        values = [header]
        data = b"ctx\n"
        for name in ("status","uid_map","gid_map","mountinfo","stat"):
            values.append({"event": "context_raw", "name": name, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(), "data_base64": base64.b64encode(data).decode(),
                "truncated": False})
        snapshot = {"device": "1", "inode": "2", "size": "3", "mode": 0o100644,
            "uid": "0", "gid": "0", "mtime_ns": "1", "ctime_ns": "2", "regular": True}
        values.extend([
            {"event": "input_start", "name": "tool/own.py", "capture_ready": False},
            {"event": "input_stat", "name": "tool/own.py", "capture_ready": False,
                "observation": copy.deepcopy(snapshot)},
            {"event": "input_final", "name": "tool/own.py", "capture_ready": False,
                "path_before": copy.deepcopy(snapshot), "fd_before": copy.deepcopy(snapshot),
                "fd_after": copy.deepcopy(snapshot), "path_after": copy.deepcopy(snapshot),
                "sha256": digest, "expected_sha256": digest, "expected_hash_match": True,
                "stable_bounded_snapshot": True, "bytes_read": 3, "errors": [],
                "fd_close_observed": True, "host_owner_uid_data_only": "501",
                "old_predicate_components_for_NEW_instance_only": {
                    "regular": True, "owner_equals_declared_host_uid": False,
                    "not_group_or_other_writable": True}},
            {"event": "observation_footer", "scope": "fresh_source_input_metadata_only",
                "capture_ready": False, "source_admitted": False, "live_admission": False,
                "input_count": 1, "all_declared_inputs_read_stable": True, "context_errors": [],
                "test_children_spawned": 0, "tool_modules_imported": 0,
                "old_predicate_false_names_for_NEW_instance_only": ["tool/own.py"]}])
        return values, inputs
    def run_record(self, name, values, inputs):
        raw = b"".join(json.dumps(v).encode()+b"\n" for v in values)
        with (ROOT/(name+".jsonl")).open("xb") as stream:
            stream.write(raw)
        return self.mod.parse_observation(raw, inputs, "a"*64, "b"*64, 501)
    def test_owner_mismatch_is_observation_never_permission(self):
        values, inputs = self.fixture()
        result = self.run_record("positive-data-only", values, inputs)
        self.assertIs(result["capture_ready"], False)
        self.assertIs(result["source_admitted"], False)
        self.assertIs(result["live_admission"], False)
        self.assertEqual(result["inputs"][0]["path_before"]["uid"], "0")
    def test_authority_and_bool_integer_alias_refused(self):
        for name, mutation in [
            ("authority", lambda v: v[0].update(capture_ready=True)),
            ("bool-count", lambda v: v[-1].update(input_count=True)),
            ("uid-integer", lambda v: v[0].update(uid=1000))]:
            values, inputs = self.fixture();mutation(values)
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.run_record(name, values, inputs)
    def test_wrong_encoded_length_refused_before_decode(self):
        values, inputs = self.fixture();values[1]["bytes"] = 1
        with patch.object(self.mod.base64, "b64decode",
                          side_effect=AssertionError("decoder reached")), self.assertRaises(ValueError):
            self.run_record("predecode-length", values, inputs)
    def test_order_and_partial_footer_refused(self):
        values, inputs = self.fixture()
        values[1], values[2] = values[2], values[1]
        with self.assertRaises(ValueError):
            self.run_record("order", values, inputs)
        values, inputs = self.fixture()
        with self.assertRaises((ValueError, IndexError)):
            self.run_record("missing-footer", values[:-1], inputs)
    def test_nested_predicate_and_mode_semantics_refused(self):
        values, inputs = self.fixture()
        values[8]["old_predicate_components_for_NEW_instance_only"]["regular"] = "true"
        with self.assertRaises(ValueError):
            self.run_record("nested-bool", values, inputs)
        values, inputs = self.fixture()
        for item,key in [(values[7],"observation"),(values[8],"path_before"),
                         (values[8],"fd_before"),(values[8],"fd_after"),(values[8],"path_after")]:
            item[key]["mode"] = 0o040755
        with self.assertRaises(ValueError):
            self.run_record("mode-contradiction", values, inputs)
if __name__ == "__main__":
    unittest.main()
