#!/usr/bin/env python3
"""Fresh OWN metadata-only source observation; no tool imports or test children."""
import base64, hashlib, json, os, stat, sys
from pathlib import Path
ROOT = Path("/opt/control")
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def emit(value):
    print(json.dumps(value, sort_keys=True, allow_nan=False), flush=True)

def snapshot(info):
    return {"device": str(info.st_dev), "inode": str(info.st_ino), "size": str(info.st_size),
        "mode": info.st_mode, "uid": str(info.st_uid), "gid": str(info.st_gid),
        "mtime_ns": str(info.st_mtime_ns), "ctime_ns": str(info.st_ctime_ns),
        "regular": stat.S_ISREG(info.st_mode)}

def raw_record(name, raw):
    emit({"event": "context_raw", "name": name, "bytes": len(raw), "sha256": sha(raw),
          "data_base64": base64.b64encode(raw).decode("ascii")})

def observe(path, name, expected_sha, host_owner):
    record = {"event": "input_final", "name": name, "errors": [], "fd_close_observed": None,
              "expected_sha256": expected_sha, "host_owner_uid_data_only": str(host_owner),
              "capture_ready": False}
    fd = None
    try:
        before = snapshot(path.lstat())
        record["path_before"] = before
        # Retain actual metadata BEFORE file type, owner or mode validation.
        emit({"event": "input_stat", "name": name, "observation": before,
              "host_uid_equality_is_NOT_assumed": True, "capture_ready": False})
        record["old_predicate_components_for_NEW_instance_only"] = {
            "regular": before["regular"],
            "owner_equals_declared_host_uid": before["uid"] == str(host_owner),
            "not_group_or_other_writable": not bool(before["mode"] & 0o022)}
        if not before["regular"]:
            raise RuntimeError("nonregular declared input, no content open")
        if int(before["size"]) > 1024**2:
            raise RuntimeError("declared source input size limit")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        record["fd_before"] = snapshot(os.fstat(fd))
        digest, offset = hashlib.sha256(), 0
        while True:
            raw = os.pread(fd, min(65536, 1024**2 + 1 - offset), offset)
            if not raw:
                break
            digest.update(raw)
            offset += len(raw)
            if offset > 1024**2:
                raise RuntimeError("declared source input grew beyond bound")
        record["bytes_read"] = offset
        record["sha256"] = digest.hexdigest()
        record["fd_after"] = snapshot(os.fstat(fd))
        record["path_after"] = snapshot(path.lstat())
        record["stable_bounded_snapshot"] = (
            record["path_before"] == record["fd_before"] == record["fd_after"] == record["path_after"])
        record["expected_hash_match"] = record["sha256"] == expected_sha
    except BaseException as error:
        record["errors"].append({"type": type(error).__name__, "errno": getattr(error, "errno", None),
                                 "reason": str(error)})
    finally:
        if fd is not None:
            closing = fd
            fd = None
            try:
                os.close(closing)
                record["fd_close_observed"] = True
            except BaseException as error:
                record["fd_close_observed"] = False
                record["errors"].append({"type": type(error).__name__,
                    "errno": getattr(error, "errno", None), "operation": "close"})
    emit(record)
    return record

def main():
    # This observer only reports. It imports NONE of the20 tool sources,
    # spawns NO child and issues NO authorization or original workload request.
    manifest_raw = (ROOT / "manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    emit({"event": "observation_start", "scope": "fresh_source_input_metadata_only",
        "capture_ready": False, "source_admitted": False, "live_admission": False,
        "manifest_sha256": sha(manifest_raw), "uid": str(os.getuid()), "euid": str(os.geteuid()),
        "gid": str(os.getgid()), "egid": str(os.getegid()),
        "groups": [str(n) for n in os.getgroups()], "pid": os.getpid(),
        "uname": list(os.uname()), "python_version": sys.version,
        "method_source_read_sha256": sha(Path(__file__).read_bytes())})
    context_errors = []
    for name in ("status", "uid_map", "gid_map", "mountinfo", "stat"):
        try:
            raw_record(name, (Path("/proc/self") / name).read_bytes())
        except BaseException as error:
            context_errors.append({"name": name, "type": type(error).__name__,
                                   "errno": getattr(error, "errno", None)})
    records = []
    for item in manifest["inputs"]:
        emit({"event": "input_start", "name": item["name"], "capture_ready": False})
        records.append(observe(ROOT / item["name"], item["name"],
                               item["sha256"], manifest["host_source_owner_uid"]))
    emit({"event": "observation_footer", "scope": "fresh_source_input_metadata_only",
        "capture_ready": False, "source_admitted": False, "live_admission": False,
        "input_count": len(records), "context_errors": context_errors,
        "all_declared_inputs_read_stable": all(
            not r["errors"] and r.get("stable_bounded_snapshot") is True
            and r.get("expected_hash_match") is True and r["fd_close_observed"] is True for r in records),
        "old_predicate_false_names_for_NEW_instance_only": [
            r["name"] for r in records
            if not all(r.get("old_predicate_components_for_NEW_instance_only", {}).values())],
        "test_children_spawned": 0, "tool_modules_imported": 0,
        "limits": "Not original failed stat reconstruction, host authenticity, COW/compiled closure, privilege or capture admission."})
    return 0 if not context_errors and all(not r["errors"] for r in records) else 1

if __name__ == "__main__":
    sys.exit(main())
