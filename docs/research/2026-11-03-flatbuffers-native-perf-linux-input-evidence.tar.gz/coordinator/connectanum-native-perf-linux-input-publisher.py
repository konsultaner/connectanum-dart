import sys, os, io, stat, json, hashlib, tarfile, shutil, subprocess, datetime
from pathlib import Path
T=Path("/private/tmp")
D=Path("/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart")
W=Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
R=T/"connectanum-native-perf-linux-input-observation"
stem="2026-11-03-flatbuffers-native-perf-linux-input"
sha=lambda b:hashlib.sha256(b).hexdigest()
def call(argv,cwd=D):
    result=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode:raise RuntimeError(result.stderr.decode(errors="replace")[-1600:])
    return result.stdout
ACTIVE_LEASE.verify_identity()
cpfile=Path("/tmp/connectanum-current-task-checkpoint.json")
prior=cpfile.read_bytes()
cp=json.loads(prior)
n=cp["native_perf_only_diagnostic_design"]
expected=n["current_source_sha256"]
assert {k:sha((W/k).read_bytes()) for k in expected}==expected
assert call(["git","rev-parse","HEAD"],W).decode().strip()=="601108ea6216464bd00ae29c16cfaf0a59c71db6"
assert not call(["git","diff","HEAD","--","packages","native"],W)
assert not call(["git","status","--porcelain"])
assert call(["git","branch","--show-current"]).decode().strip()=="codex/flatbuffers-acceptance-status"
s=json.loads((R/"summary.json").read_bytes())
o=json.loads((R/"observations.json").read_bytes())
decl=json.loads((R/"declaration.json").read_bytes())
assert s["input_count"]==20 and len(o["inputs"])==20 and len(s["command_records"])==8
assert all(x["returncode"]==0 and x["outputs"]["stdout"]["eof"] and x["outputs"]["stderr"]["eof"] for x in s["command_records"])
assert s["container_state"]["ExitCode"]==0 and s["container_state"]["OOMKilled"] is False
assert decl["host_source_owner_uid_data_only"]==501
assert all(o["header"][k]=="1000" for k in ("uid","euid","gid","egid"))
assert all(x["path_before"]["uid"]==x["path_before"]["gid"]=="1000" and x["path_before"]["mode"]==0o100644 for x in o["inputs"])
assert b"CapEff:\t0000000000000000\n" in (R/"contexts/status.raw").read_bytes()
assert b"NoNewPrivs:\t1\n" in (R/"contexts/status.raw").read_bytes()
assert b" - fakeowner " in (R/"contexts/mountinfo.raw").read_bytes()
assert json.loads((T/"connectanum-native-perf-linux-input-context-before-tests.json").read_bytes())["status"]==1
assert json.loads((T/"connectanum-native-perf-linux-input-context-fixed-tests.json").read_bytes())["status"]==0
assert json.loads((T/"connectanum-native-perf-linux-input-protocol-tests.json").read_bytes())["status"]==0
models={
"tests93670":"Qwen complete/reaped advisory. Reject BaseException/finally allegation, arbitrary mode string conversion and hypothetical SIGINT/CLI test; raw small mode is exact and u64 fields are strings. Root independently identifies unbounded context read and retains before FAIL/fix.",
"review22524":"Qwen complete/reaped advisory. Reject cancellation deadline:45s only unstarted admission; bounded5s waits retain same owned command until natural signed status+bothEOF. Reject rm/cleanup, fabricated CID, exist_ok/chmod reset; unknown staysNULL, stopped evidence protected, mkdir default already exclusive0700. Daemon/host authenticity and exhaustion remain limitations, never live admission."}
with (T/"connectanum-native-perf-linux-input-model-root-qualification.json").open("x") as f:
    json.dump({"models":models,"all_complete_reaped":True,"capture_ready":False},f,indent=2)
with (T/"connectanum-native-perf-linux-input-publication-preparation-failures.json").open("x") as f:
    json.dump({"first":"Python publisher SyntaxError before execution/resource/source mutation","second":"JS orchestrator SyntaxError before nested tool execution","no_control_test_or_kernel_rerun":True,"original_errors_retained_in_this_chat":True},f,indent=2)
files={}
special=[]
excluded=[]
for root in sorted(T.glob("connectanum-native-perf-linux-input-*")):
    if root.is_file():files["coordinator/"+root.name]=root
    elif root.is_dir():
        for p in sorted(root.rglob("*")):
            if p.is_dir():continue
            member=root.name+"/"+p.relative_to(root).as_posix()
            info=p.lstat()
            if p.name=="method-python-ELF":
                excluded.append({"member":member,"bytes":info.st_size,"sha256":sha(p.read_bytes()),"retained_LOCAL_ONLY":True})
            elif stat.S_ISREG(info.st_mode):files[member]=p
            else:special.append({"member":member,"mode":info.st_mode,"device":str(info.st_dev),"inode":str(info.st_ino),"target_sha256":sha(os.readlink(p).encode()) if p.is_symlink() else None})
public=D/"docs/research"
archive=public/(stem+"-evidence.tar.gz")
assert not archive.exists()
metadata=json.dumps({"special_nodes_metadata_only":special,"third_party_ELF_LOCAL_ONLY":excluded},indent=2,sort_keys=True).encode()+b"\n"
with tarfile.open(archive,"w:gz") as tar:
    for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
    item=tarfile.TarInfo("archive-retention-metadata.json")
    item.size=len(metadata)
    tar.addfile(item,io.BytesIO(metadata))
verified=[]
with tarfile.open(archive,"r:gz") as tar:
    for item in tar.getmembers():
        assert item.isfile()
        stream=tar.extractfile(item)
        raw=stream.read()
        stream.close()
        original=metadata if item.name=="archive-retention-metadata.json" else files[item.name].read_bytes()
        assert raw==original
        verified.append({"member":item.name,"bytes":len(raw),"sha256":sha(raw)})
free=shutil.disk_usage(W).free
a={"scope":"NEW current-instance source-input metadata ONLY; not historical stat reconstruction or admission",
"capture_ready":False,"source_admitted":False,"live_admission":False,
"source20_unchanged":True,"production_packages_native_source_unchanged":True,
"source_head":"601108ea6216464bd00ae29c16cfaf0a59c71db6","all20source_sha256":expected,
"actual_command_statuses":[0]*8,"all_command_stream_EOF":True,"actual_container_exit":0,"OOMKilled":False,
"declared_input_count":20,"all20_exact_hash_stable_path_FD_stat_and_observed_close":True,
"actual_current_namespace_UID_EUID_GID_EGID":{k:o["header"][k] for k in ("uid","euid","gid","egid")},
"host_source_UID_data":501,"all20_actual_file_UID_GID":"1000:1000","all20_actual_file_mode":"0100644",
"NEW_instance_predicate_components":{"regular":True,"not_group_or_other_writable":True,"owner_equals_host_UID501":False},
"actual_current_proc_status":{"CapEff":"0000000000000000","NoNewPrivs":"1","Seccomp":"2"},
"actual_current_OWN_mount":"ro,nosuid,nodev /opt/control, filesystem reported fakeowner; complete raw retained",
"test_children_spawned":0,"tool_modules_imported":0,
"input_chain":{k:decl[k] for k in ("image_manifest_digest","config_digest","expected_method_ELF_sha256","host_source_sha256","observer_sha256","protocol_sha256")},
"declaration_sha256":s["declaration_sha256"],"manifest_sha256":s["manifest_sha256"],
"roundtrip_before_sole_new_start":True,"image_pull_inspect_save_not_rerun":True,"old_containers_not_restarted":True,
"chown_owner_expansion_source_guard_bypass":False,
"context_regression":"ONE actual private-observer beforeFAIL:393216byte full read of384KiB OWN synthetic proc fixture; changed-source guardPASS retains max262145byte prefix/truncation/error/unobserved tail, no reread. Logical IO only, not heap/RSS magnitude.",
"protocol_guards":"FIVE separate NEW synthetic guardsPASS: data-only authority, scalar types, pre-decode encoded length, order/footer, nested predicate/mode. Never combined6/canonical/old78 rerun.",
"models":models,"all_own_command_model_parents_complete_reaped":True,
"archive":{"path":"docs/research/"+archive.name,"sha256":sha(archive.read_bytes()),"members":len(verified),"all_regular_members_byte_exact":True,"special_nodes_metadata_only":True,"third_party_ELF_image_LOCAL_ONLY":True,"old194member_archive_not_reread":True},
"free_bytes":free,"build_floor_bytes":12*1024**3,"build_admission_open":False,"disk_change_cause_unmeasured":True,"no_cleanup":True}
a["limits"]=[
"Old failing stat was not serialized; NEW observations do not identify its exact failing predicate or retroactively prove old runtime context.",
"Namespace UID1000 differs from host UID501 data in this instance; no general translation rule, accepted owner expansion or original credential change inferred.",
"Current context only; not original diagnostic host/kernel/root/map_files/pidfd/FDexec/wire/perf/inheritance/arming/metadata/loss/role/clock/COW/compiled-source proof.",
"Bounded hash/path/FD/stat and readonly mount are not global atomic/ABA/write prevention or malicious-daemon authenticity.",
"Independent live provider absent; require_live_admission ALWAYSraises/liveSessionController CLOSED. Source20 uncommitted/uncanonical; no own fullcanonical/production/source archive/native/driver/RLIB/SDK/compiler/WAMP/VM/benchmark/capture/strict dispatch.",
"All original benchmark UID/GID/env/argv/--dart dart/SDK/GC/allocator/workers/controls/fresh bodies/windows/samples/gates unchanged. Original strict evidence consumed; no RAM repair/acceptance."]
a["next"]="Bind host-source UID data and namespace-controller/artifact UID in separate immutable method contexts; require exact selected namespaceUID1000 and hashes/owner/mode without expanding allowed owners or deriving authority from observations. Meaningful context regression/root review before fresh nonbenchmark primitive controls. Never restart/refill terminal containers. Full own canonical/provenance/original-host Linux/root/perf controls and live provider still unresolved before diagnostic data."
with (public/(stem+"-assessment.json")).open("x") as f:json.dump(a,f,indent=2);f.write("\n")
with (public/(stem+"-preparation.md")).open("x") as f:f.write(PUBLIC_NOTE)
paragraph=("## Current source UID context observed; live admission closed (2026-11-03)\n\n"
"A NEW metadata-only observer records all20exact source files and actual\n"
"UID/EUID/GID/EGID1000. All files are regular0644 with UID/GID1000, while\n"
"host source UID data501 differs. Current raw status has CapEff0/NoNewPrivs1/\n"
"Seccomp2 and OWN read-only fakeowner mount. This is current input context,\n"
"not the old unrecorded stat or original-host trust.\n"
"[Actual context, guards and limits](research/"+stem+"-preparation.md).\n\n"
"Eight command parents and the new observer naturally exit0; no tool import,\n"
"test child/primitive/perf/VM/benchmark or old-container restart. One changed\n"
"context guard and five separate NEW protocol guards pass. Source20/production\n"
"601 unchanged/uncommitted/uncanonical, live provider closed. No owner waiver,\n"
"RAM repair/strict dispatch. Free "+f"{free/1e9:.2f}"+"GB; unchanged12GiB build floor closed,\n"
"cause unmeasured/no cleanup. Both strict campaigns remain failed.\n\n")
anchor="## Linux method source setup refused"
for rel in ("docs/project_state.md","docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md"):
    p=D/rel
    text=p.read_text()
    assert anchor in text
    insert=paragraph if rel.endswith("project_state.md") else paragraph.replace("(research/","(../research/")
    p.write_text(text.replace(anchor,insert+anchor,1))
names=["docs/project_state.md","docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md","docs/research/"+stem+"-preparation.md","docs/research/"+stem+"-assessment.json","docs/research/"+archive.name]
call(["git","add","--",*names])
assert set(call(["git","diff","--cached","--name-only"]).decode().splitlines())==set(names)
call(["git","commit","-m","docs: retain current namespace source metadata observation"])
commit=call(["git","rev-parse","HEAD"]).decode().strip()
call(["git","push","github","codex/flatbuffers-acceptance-status"])
assert not call(["git","status","--porcelain"])
rb=T/"connectanum-native-perf-linux-input-root-readback.json"
with rb.open("x") as f:
    json.dump({"docs_commit":commit,"assessment":a,"archive_members_verified":verified,"local_original_files":{k:str(v) for k,v in files.items()},"protected_new_container_id":s["container_id"],"capture_ready":False,"source_admitted":False,"all_own_sessions_complete_reaped":True},f,indent=2);f.write("\n")
with (T/"connectanum-native-perf-linux-input-checkpoint-before.json").open("xb") as f:f.write(prior)
n.update({"phase":"linux_input_METADATA20_namespaceUID1000_hostUID501_dataONLY_no_admission_or_primitive_cases",
"linux_input_root_readback":str(rb),"linux_input_phase_docs_commit":commit,"linux_input_archive_sha256":a["archive"]["sha256"],"linux_input_archive_members":len(verified),"linux_input_context_guard_PASS":1,"linux_input_protocol_guards_PASS_separately":5,"linux_input_actual_observed_files":20,"linux_input_commands_natural_exit0":8,"linux_input_actual_namespace_UID":1000,"linux_input_host_source_UID_data":501,"linux_input_actual_namespace_source_UID":1000,"linux_input_actual_file_mode":"0100644","linux_input_prior_failed_stat_reconstructed":False,"linux_input_actual_primitive_cases":0,"linux_input_protected_stopped_container":s["container_id"],"linux_input_source20_unchanged":True,"linux_input_models":models,"linux_input_all_own_sessions_complete_reaped":True,"linux_input_publication_pending":False,"last_free_bytes":free,"current_free_bytes_about":free,"build_disk_admission_open":False,"next":a["next"]})
cp["status_docs_commit"]=commit
cp["updated_utc"]=cp["last_heartbeat_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
cp["last_heartbeat_summary"]="NEW20source metadata actualUID1000/0644 vs hostUID501.8commands0;1context+5separate protocol guardsPASS. Source20unchanged/liveproviderclosed/no primitives/build/benchmark/cleanup."
cpfile.write_text(json.dumps(cp,indent=2)+"\n")
intro=("Latest2026-11-03 metadata-only control: a NEW OWN namespace records all20exact source files UID/GID1000 regular0644 and actual UID/EUID/GID/EGID1000; host source UID data501 differs. Current raw proc status has CapEff0/NoNewPrivs1/Seccomp2 and OWN read-only fakeowner mount. Current observations do not reconstruct the prior missing stat or authenticate the original host/root. Eight command parents and the new observer exit0; no tool import/test child/pidfd/FDexec/wire/perf/VM/benchmark. One changed context-bound guard plus five separate NEW protocol guards pass, no combined6/canonical claim. Source20/production601 unchanged; no owner waiver/old-container restart/cleanup. Live provider/controller CLOSED, strict acceptance/RAM repair unresolved.\n\nEvidence: docs/research/"+stem+"-preparation.md and matching assessment/archive at docs-only "+commit+".\n\n")
descriptions=[]
for kind,num,endpoint in (("pr132",132,"pulls"),("issue103",103,"issues")):
    before=json.loads(call(["gh","api","repos/konsultaner/connectanum-dart/"+endpoint+"/"+str(num)]))
    assert before["state"]=="open"
    if endpoint=="pulls":
        assert before["draft"] and before["head"]["sha"]=="40ddcb3ff0dbf947ef21b8e7fb9cca3465a502b5" and before["base"]["ref"]=="codex/flatbuffers-byte-vector-views"
    body=intro+before["body"]
    p=T/("connectanum-native-perf-linux-input-"+kind+"-body.md")
    with p.open("x") as f:f.write(body)
    call(["gh","pr" if endpoint=="pulls" else "issue","edit",str(num),"--repo","konsultaner/connectanum-dart","--body-file",str(p)])
    after=json.loads(call(["gh","api","repos/konsultaner/connectanum-dart/"+endpoint+"/"+str(num)]))
    assert after["body"]==body
    descriptions.append({"kind":kind,"body_sha256":sha(body.encode()),"readback_exact":True})
with (T/"connectanum-native-perf-linux-input-GitHub-description-receipt.json").open("x") as f:
    json.dump({"docs_commit":commit,"descriptions":descriptions,"descriptions_only":True,"head_base_draft_issue_open_unchanged":True,"no_GitHub_token_comments_messages":True},f,indent=2)
print(json.dumps({"docs_commit":commit,"archive_members":len(verified),"archive_sha256":a["archive"]["sha256"],"free_bytes":free,"root_readback":str(rb),"primitive_cases":0}))
