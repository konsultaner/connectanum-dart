OWN small source
