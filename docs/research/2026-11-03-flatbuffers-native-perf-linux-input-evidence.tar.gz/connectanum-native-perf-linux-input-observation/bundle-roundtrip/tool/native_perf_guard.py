#!/usr/bin/env python3
"""Before-data guard primitives. This module has no benchmark/capture entrypoint.

Identity witnesses and the launch policy must come from a separately verified
controller. These primitives do not establish Linux perf inheritance, loaded
image identity, sampler privilege provenance or capture readiness.
"""

from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping, Sequence


class GuardError(RuntimeError):
    pass


def _integer(value: int, minimum: int) -> bool:
    return type(value) is int and value >= minimum


def _digest(value: str) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


@dataclass(frozen=True)
class ProcessStat:
    pid: int
    parent_pid: int
    start_ticks: int


def parse_process_stat(text: str) -> ProcessStat:
    """Parse Linux stat without splitting a comm containing spaces or ')'."""
    prefix, opening, rest = text.partition(" (")
    _comm, closing, tail = rest.rpartition(") ")
    fields = tail.split()
    try:
        if not opening or not closing or len(fields) < 20:
            raise ValueError()
        pid, parent, start = int(prefix), int(fields[1]), int(fields[19])
        if (pid <= 0 or parent < 0 or start <= 0 or len(fields[0]) != 1
                or not fields[0].isascii() or not fields[0].isalpha()):
            raise ValueError()
        return ProcessStat(pid, parent, start)
    except (ValueError, IndexError) as error:
        raise GuardError("invalid process stat witness") from error


@dataclass(frozen=True)
class ProcessInstance:
    pid: int
    start_ticks: int
    executable_sha256: str
    effective_uid: int
    effective_gid: int

    def __post_init__(self) -> None:
        if not (_integer(self.pid, 1) and _integer(self.start_ticks, 1)
                and _integer(self.effective_uid, 0) and _integer(self.effective_gid, 0)
                and _digest(self.executable_sha256)):
            raise GuardError("invalid process instance witness")


@dataclass(frozen=True)
class PipeIdentity:
    device: int
    inode: int

    def __post_init__(self) -> None:
        if not (_integer(self.device, 0) and _integer(self.inode, 1)):
            raise GuardError("invalid pipe identity witness")

    @classmethod
    def from_fd(cls, fd: int) -> PipeIdentity:
        info = os.fstat(fd)
        if not stat.S_ISFIFO(info.st_mode):
            raise GuardError("acknowledgement channel is not a pipe")
        return cls(info.st_dev, info.st_ino)


@dataclass(frozen=True)
class PipeChannel:
    read_end: PipeIdentity
    write_end: PipeIdentity

    @classmethod
    def from_fds(cls, read_fd: int, write_fd: int) -> PipeChannel:
        import fcntl

        if (read_fd == write_fd
                or fcntl.fcntl(read_fd, fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY
                or fcntl.fcntl(write_fd, fcntl.F_GETFL) & os.O_ACCMODE != os.O_WRONLY):
            raise GuardError("invalid pipe endpoint directions")
        return cls(PipeIdentity.from_fd(read_fd), PipeIdentity.from_fd(write_fd))

    @property
    def identities(self) -> frozenset[PipeIdentity]:
        # Darwin gives endpoints different identities; Linux may share one.
        # The controller supplies the actual creator pair, not an inferred peer.
        return frozenset((self.read_end, self.write_end))


@dataclass(frozen=True)
class FrozenLaunch:
    argv: tuple[str, ...]
    environment: tuple[tuple[str, str], ...]
    effective_uid: int
    effective_gid: int

    def __post_init__(self) -> None:
        if (type(self.argv) is not tuple or not self.argv or not self.argv[0]
                or any(not isinstance(arg, str) or "\0" in arg for arg in self.argv)
                or type(self.environment) is not tuple
                or any(type(pair) is not tuple or len(pair) != 2
                       or not isinstance(pair[0], str) or not pair[0]
                       or "=" in pair[0] or "\0" in pair[0]
                       or not isinstance(pair[1], str) or "\0" in pair[1]
                       for pair in self.environment)
                or tuple(sorted(self.environment)) != self.environment
                or len({pair[0] for pair in self.environment}) != len(self.environment)
                or not _integer(self.effective_uid, 0) or not _integer(self.effective_gid, 0)):
            raise GuardError("invalid frozen launch")

    @classmethod
    def freeze(cls, argv: Sequence[str], environment: Mapping[str, str],
               effective_uid: int, effective_gid: int) -> FrozenLaunch:
        if (isinstance(argv, (str, bytes)) or not argv
                or any(not isinstance(arg, str) or "\0" in arg for arg in argv)
                or not argv[0] or any(not isinstance(k, str) or not k or "=" in k
                                      or "\0" in k or not isinstance(v, str) or "\0" in v
                                      for k, v in environment.items())
                or not _integer(effective_uid, 0) or not _integer(effective_gid, 0)):
            raise GuardError("invalid frozen launch")
        return cls(tuple(argv), tuple(sorted(environment.items())), effective_uid, effective_gid)

    def validate(self, argv: Sequence[str], environment: Mapping[str, str],
                 instance: ProcessInstance) -> None:
        # Never include environment contents in error text or public evidence.
        if tuple(argv) != self.argv:
            raise GuardError("driver argv changed")
        if tuple(sorted(environment.items())) != self.environment:
            raise GuardError("driver environment changed")
        if (instance.effective_uid, instance.effective_gid) != (
                self.effective_uid, self.effective_gid):
            raise GuardError("driver credentials changed")


def _write_all(fd: int, data: bytes, writer: Callable[[int, bytes], int]) -> None:
    offset = 0
    while offset < len(data):
        count = writer(fd, data[offset:])
        if type(count) is not int or count <= 0 or count > len(data) - offset:
            raise GuardError("invalid write progress")
        offset += count


class ArmingGate:
    """Fail permanently on a bad event; never retry or launch a process here.

    Pipe identities bind endpoints, not writer credentials. The controller must
    separately prove the sampler's actual process/image and private FD ownership.
    """

    def __init__(self, sampler: ProcessInstance, wrapper: ProcessInstance,
                 control_pipe: PipeChannel, ack_pipe: PipeChannel,
                 go_pipe: PipeChannel,
                 policy: FrozenLaunch, declaration_sha256: str, nonce: str):
        if (sampler.pid == wrapper.pid or control_pipe.identities & ack_pipe.identities
                or go_pipe.identities & (control_pipe.identities | ack_pipe.identities)
                or not _digest(declaration_sha256)
                or not isinstance(nonce, str)
                or re.fullmatch(r"[0-9a-f]{32}", nonce) is None):
            raise GuardError("invalid arming declaration")
        self.sampler, self.wrapper = sampler, wrapper
        self.control_pipe, self.ack_pipe = control_pipe, ack_pipe
        self.go_pipe = go_pipe
        self.policy = policy
        self.declaration_sha256, self.nonce = declaration_sha256, nonce
        self.state = "created"

    def _require(self, condition: bool, message: str) -> None:
        if not condition:
            self.state = "failed"
            raise GuardError(message)

    def blocked(self, wrapper: ProcessInstance,
                wrapper_open_pipes: frozenset[PipeIdentity]) -> None:
        self._require(self.state == "created", "unexpected blocked event")
        self._require(wrapper == self.wrapper, "wrapper instance changed")
        self._require(isinstance(wrapper_open_pipes, frozenset), "missing pipe witness")
        self._require(not (self.control_pipe.identities | self.ack_pipe.identities) & wrapper_open_pipes,
                      "wrapper inherited sampler channels")
        self.state = "failed"
        self.policy.validate(self.policy.argv, dict(self.policy.environment), wrapper)
        self.state = "blocked"

    def request_enable(self, sampler: ProcessInstance) -> bytes:
        self._require(self.state == "blocked", "sampler enable out of order")
        self._require(sampler == self.sampler, "sampler instance changed")
        self.state = "waiting_ack"
        return b"enable\n"

    def acknowledge(self, channel: PipeIdentity, line: bytes,
                    sampler: ProcessInstance) -> None:
        self._require(self.state == "waiting_ack", "sampler ack out of order")
        self._require(channel == self.ack_pipe.read_end, "ack came from a different channel")
        self._require(sampler == self.sampler, "sampler instance changed")
        self._require(line == b"ack\n", "invalid sampler acknowledgement")
        self.state = "armed"

    def consume(self, directory: Path, writer: Callable[[int, bytes], int] = os.write) -> Path:
        """Any existing or partial marker is terminal; preserve raw I/O errors."""
        self._require(self.state == "armed", "consumed marker out of order")
        self.state = "failed"
        directory = directory.resolve(strict=True)
        directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        fd = None
        try:
            fd = os.open("capture-consumed.json",
                         os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                         0o600, dir_fd=directory_fd)
            data = json.dumps({"declaration_sha256": self.declaration_sha256,
                               "nonce": self.nonce}, sort_keys=True).encode() + b"\n"
            _write_all(fd, data, writer)
            os.fsync(fd)
            os.fsync(directory_fd)
        finally:
            if fd is not None:
                os.close(fd)
            os.close(directory_fd)
        self.state = "consumed"
        return directory / "capture-consumed.json"

    def release(self, go_fd: int, sampler: ProcessInstance, wrapper: ProcessInstance,
                argv: Sequence[str], environment: Mapping[str, str],
                writer: Callable[[int, bytes], int] = os.write) -> None:
        self._require(self.state == "consumed", "driver release out of order")
        # A partial/failed write can have reached the child. It is never retried.
        self.state = "failed"
        self._require(sampler == self.sampler, "sampler instance changed")
        self._require(wrapper == self.wrapper, "wrapper instance changed")
        self.policy.validate(argv, environment, wrapper)
        import fcntl

        try:
            identity = PipeIdentity.from_fd(go_fd)
        except GuardError as error:
            raise GuardError("release channel is not a pipe") from error
        if (identity != self.go_pipe.write_end
                or fcntl.fcntl(go_fd, fcntl.F_GETFL) & os.O_ACCMODE != os.O_WRONLY):
            raise GuardError("release channel changed")
        token = f"{self.declaration_sha256}:{self.nonce}\n".encode("ascii")
        _write_all(go_fd, token, writer)
        self.state = "released"


if __name__ == "__main__":
    raise SystemExit("Guard primitives only: no capture or benchmark entrypoint")
