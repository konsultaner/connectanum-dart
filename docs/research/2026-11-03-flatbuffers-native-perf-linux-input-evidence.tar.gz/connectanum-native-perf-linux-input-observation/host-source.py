"""Fresh metadata-only input observation; no original workload or tool mutation."""
import ast, datetime, hashlib, json, os, re, shutil, stat, sys, time, types
from pathlib import Path
sys.path.insert(0, "/Users/konsultaner/.codex/skills/local-model-companions/scripts")
from ollama_companion import local_resource_lease, LocalResourceLeaseError
W = Path("/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart")
T = Path("/private/tmp")
OUT = T / "connectanum-native-perf-linux-input-observation"
OLD = T / "connectanum-native-perf-linux-control-attempt-v2"
OBSERVER = T / "connectanum-native-perf-linux-input-observer.py"
PROTOCOL = T / "connectanum-native-perf-linux-input-protocol.py"
sha = lambda raw: hashlib.sha256(raw).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(lease):
    lease.verify_identity()
    assert shutil.disk_usage(W).free >= 1024**3
    cp = json.loads(Path("/tmp/connectanum-current-task-checkpoint.json").read_bytes())
    expected = cp["native_perf_only_diagnostic_design"]["current_source_sha256"]
    sources = {name: (W / name).read_bytes() for name in expected}
    assert len(sources) == 20 and {name: sha(raw) for name, raw in sources.items()} == expected
    observer, protocol = OBSERVER.read_bytes(), PROTOCOL.read_bytes()
    ast.parse(observer); ast.parse(protocol)
    host_sha = sha(Path(__file__).read_bytes())
    mod = types.ModuleType("input_observation_command_owner")
    mod.__file__ = str(W / "tool/native_perf_build_producer.py")
    exec(compile(sources["tool/native_perf_build_producer.py"], mod.__file__, "exec"), mod.__dict__)
    parser = types.ModuleType("input_observation_protocol")
    parser.__file__ = str(PROTOCOL)
    exec(compile(protocol, str(PROTOCOL), "exec"), parser.__dict__)
    old_declaration_raw = (OLD / "declaration.json").read_bytes()
    old_declaration = json.loads(old_declaration_raw)
    image = old_declaration["image_reference"]
    digest = "sha256:29434a59c93070e470f84663e4289026e04644ea44b5220ef7e07d653318ca1f"
    assert image == "docker.io/library/python@" + digest
    exported_raw = (OLD / "exported-identity-receipt.json").read_bytes()
    exported = json.loads(exported_raw)
    assert exported["manifest_digest"] == digest
    assert exported["config_digest"] == "sha256:fe83005fb105be014095e304ce578212522449ec2ad47649ef4833ef9a84abda"
    expected_elf_sha = json.loads((OLD / "bundle/manifest.json").read_bytes())["method_python_elf_sha256"]
    endpoint = old_declaration["local_endpoint"]
    assert endpoint.startswith("unix:///")
    sock = Path(endpoint[7:]).resolve(strict=True)
    socket_info = sock.stat()
    assert stat.S_ISSOCK(socket_info.st_mode) and socket_info.st_uid in (0, os.getuid())
    socket_stamp = (socket_info.st_dev, socket_info.st_ino, socket_info.st_uid)
    entry = Path(old_declaration["docker_entry"])
    target = entry.resolve(strict=True)
    docker_sha = mod._regular_hash(target, owners={0, os.getuid()})
    assert str(target) == old_declaration["docker_target"] and docker_sha == old_declaration["docker_read_sha256"]
    env = dict(os.environ)
    assert not any(env.get(k) for k in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"))
    OUT.mkdir(mode=0o700)
    commands = OUT / "commands"; commands.mkdir()
    bundle = OUT / "bundle"; bundle.mkdir(mode=0o755)
    (bundle / "tool").mkdir(mode=0o755)
    for name, raw in {**sources, "observer.py": observer}.items():
        with (bundle / name).open("xb") as stream:
            stream.write(raw)
        (bundle / name).chmod(0o644)
    inputs = [{"name": name, "sha256": value} for name, value in expected.items()]
    container_name = "ct132-input-" + os.urandom(16).hex()
    declaration = {
        "kind": "fresh-own-source-input-metadata-observation-v1", "declared": now(),
        "scope": "NEW metadata-only current-instance source observation; never historical stat reconstruction",
        "capture_ready": False, "source_admitted": False, "live_admission": False,
        "host_source_sha256": host_sha, "observer_sha256": sha(observer), "protocol_sha256": sha(protocol),
        "all20source_sha256": expected, "inputs_in_original_declared_order": inputs,
        "host_source_owner_uid_data_only": os.getuid(), "host_uid_mapping_equality_NOT_assumed": True,
        "completed_image_intake_and_export_receipt_sha256": sha(exported_raw),
        "predecessor_declaration_sha256": sha(old_declaration_raw),
        "image_reference": image, "image_manifest_digest": digest,
        "config_digest": exported["config_digest"], "expected_method_ELF_sha256": expected_elf_sha,
        "docker_entry": str(entry), "docker_target": str(target), "docker_sha256": docker_sha,
        "local_endpoint": endpoint, "socket_stamp": [str(n) for n in socket_stamp],
        "environment_sha256": sha(json.dumps(env, sort_keys=True, ensure_ascii=True).encode()),
        "new_container_name": container_name,
        "policy": "configured1000:1000 cap-dropALL no-new-privileges networknone readonlyroot; onlyOWNbundleREADONLY; tmpfs16MiB/memory256MiB/pids32/cpu1",
        "prior_terminal_container_never_restarted": True,
        "no_image_pull_inspect_save_or_old_control_repeat": True,
        "no_tool_imports_children_FDexec_pidfd_wire_perf_VM_benchmark": True,
        "no_chown_owner_mode_waiver_or_source_canonical_admission": True,
        "context_bound_bytes_per_file": 262144, "source_bound_bytes_per_file": 1048576,
        "test_storage_floor_bytes": 1024**3, "build_floor_UNCHANGED_bytes": 12*1024**3,
        "command_templates_in_order": ["create-new", "inspect-before", "copy-new-instance-ELF",
            "copy-OWN-readonly-inputs-back", "inspect-staged", "start-attach-ONCE",
            "wait-natural", "inspect-after"],
        "command_prefix": [str(entry), "--host", endpoint],
        "guest_argv": ["/usr/local/bin/python3.14", "-I", "-S", "-B", "/opt/control/observer.py"]}
    mod._write_json(OUT / "declaration.json", declaration)
    declaration_sha = mod._regular_hash(OUT / "declaration.json")
    for name, raw in (("host-source.py", Path(__file__).read_bytes()), ("protocol-source.py", protocol)):
        with (OUT / name).open("xb") as stream:
            stream.write(raw)
    operations, records = [], []
    cid, manifest_sha = None, None
    def recheck():
        lease.verify_identity()
        assert mod._regular_hash(OUT / "declaration.json") == declaration_sha
        assert sha(Path(__file__).read_bytes()) == host_sha
        assert sha(OBSERVER.read_bytes()) == sha(observer) and sha(PROTOCOL.read_bytes()) == sha(protocol)
        assert {name: sha((W / name).read_bytes()) for name in expected} == expected
        assert entry.resolve(strict=True) == target and mod._regular_hash(target, owners={0, os.getuid()}) == docker_sha
        info = sock.stat()
        assert (info.st_dev, info.st_ino, info.st_uid) == socket_stamp
        if manifest_sha is not None:
            assert mod._regular_hash(bundle / "manifest.json") == manifest_sha
    def observe(name, args, allow_failure=False):
        recheck()
        operation = mod.AuxiliaryCommand(directory=commands, name=name,
            argv=[str(entry), "--host", endpoint, *args], cwd=W, environment=env,
            lease_check=lease.verify_identity, stdout_max=8*1024**2, stderr_max=8*1024**2)
        operations.append(operation)
        operation.start()
        result = operation.result
        while result is None:
            result = operation.wait(5)
        records.append(result)
        mod._write_json(OUT / (name + "-record.json"), result)
        raw = mod._read_bound_metadata(commands / (name + ".stdout"),
                                       result["outputs"]["stdout"]["snapshot"], 8*1024**2)
        if result["status"] != "success" and not allow_failure:
            raise RuntimeError("declared observation operation failed: " + name)
        return raw
    def inspect(name):
        raw = observe(name, ["container", "inspect", cid])
        data = json.loads(raw)[0]
        assert data["Id"] == cid and data["Image"] == digest and data["Name"] == "/" + container_name
        cfg, host = data["Config"], data["HostConfig"]
        assert cfg["User"] == "1000:1000"
        assert cfg["Entrypoint"] == ["/usr/local/bin/python3.14"]
        assert cfg["Cmd"] == ["-I", "-S", "-B", "/opt/control/observer.py"]
        assert not cfg["Tty"] and not cfg["OpenStdin"]
        assert host["NetworkMode"] == "none" and host["ReadonlyRootfs"] is True and host["Privileged"] is False
        assert host["CapDrop"] == ["ALL"] and not host["CapAdd"] and not host["Binds"]
        assert host["SecurityOpt"] == ["no-new-privileges:true"]
        assert host["Memory"] == host["MemorySwap"] == 268435456 and host["PidsLimit"] == 32 and host["NanoCpus"] == 1000000000
        assert host["RestartPolicy"]["Name"] == "no"
        assert host["Tmpfs"] == {"/tmp": "rw,nosuid,nodev,noexec,size=16777216,mode=1777"}
        mounts = host["Mounts"]
        assert len(mounts) == 1 and mounts[0]["Type"] == "bind" and mounts[0]["Source"] == str(bundle)
        assert mounts[0]["Target"] == "/opt/control" and mounts[0]["ReadOnly"] is True
        assert mounts[0]["BindOptions"]["Propagation"] == "rprivate"
        actual = [item for item in data["Mounts"] if item["Destination"] == "/opt/control"]
        assert len(actual) == 1 and actual[0]["Source"] == str(bundle) and actual[0]["RW"] is False
        return data
    try:
        raw = observe("create-new", ["container", "create", "--name", container_name,
            "--user", "1000:1000", "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
            "--network", "none", "--read-only", "--mount",
            "type=bind,source=" + str(bundle) + ",target=/opt/control,readonly,bind-propagation=rprivate",
            "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=16777216,mode=1777",
            "--memory", "268435456", "--memory-swap", "268435456", "--pids-limit", "32",
            "--cpus", "1", "--workdir", "/tmp", "--entrypoint", "/usr/local/bin/python3.14",
            image, "-I", "-S", "-B", "/opt/control/observer.py"])
        cid = raw.decode("ascii").strip()
        assert re.fullmatch("[0-9a-f]{64}", cid)
        assert inspect("inspect-before")["State"]["Status"] == "created"
        elf = OUT / "method-python-ELF"
        observe("copy-new-instance-elf", ["container", "cp", cid + ":/usr/local/bin/python3.14", str(elf)])
        assert mod._regular_hash(elf) == expected_elf_sha and elf.read_bytes()[:4] == b"\x7fELF"
        manifest = {"kind": "source_input_metadata_observation_only", "capture_ready": False,
            "source_admitted": False, "live_admission": False, "declaration_sha256": declaration_sha,
            "container_id": cid, "observer_sha256": sha(observer), "inputs": inputs,
            "host_source_owner_uid": os.getuid(), "host_uid_equality_NOT_assumed": True}
        mod._write_json(bundle / "manifest.json", manifest); (bundle / "manifest.json").chmod(0o644)
        manifest_sha = mod._regular_hash(bundle / "manifest.json")
        back = OUT / "bundle-roundtrip"
        observe("copy-readonly-inputs-back", ["container", "cp", cid + ":/opt/control", str(back)])
        original = {str(p.relative_to(bundle)): mod._regular_hash(p) for p in bundle.rglob("*") if p.is_file()}
        copied = {str(p.relative_to(back)): mod._regular_hash(p) for p in back.rglob("*") if p.is_file()}
        assert original == copied
        assert inspect("inspect-staged")["State"]["Status"] == "created"
        mod._write_json(OUT / "before-any-guest-start.json", {
            "capture_ready": False, "declaration_sha256": declaration_sha,
            "manifest_sha256": manifest_sha, "roundtrip_file_sha256": copied, "container_id": cid})
        raw = observe("start-attach-once", ["container", "start", "--attach", cid], allow_failure=True)
        waited = observe("wait-natural", ["container", "wait", cid])
        after = inspect("inspect-after")
        state = after["State"]
        assert state["Status"] == "exited" and state["Running"] is False
        assert waited == (str(state["ExitCode"]) + "\n").encode()
        result = parser.parse_observation(raw, inputs, sha(observer), manifest_sha, os.getuid())
        assert state["ExitCode"] == 0 and state["OOMKilled"] is False and not state["Error"]
        context_dir = OUT / "contexts"; context_dir.mkdir()
        for name, data in result.pop("contexts").items():
            with (context_dir / (name + ".raw")).open("xb") as stream:
                stream.write(data)
        mod._write_json(OUT / "observations.json", result)
        recheck()
        mod._write_json(OUT / "summary.json", {
            "scope": "NEW current-instance input metadata ONLY, not previous failed stat reconstruction",
            "capture_ready": False, "source_admitted": False, "live_admission": False,
            "declaration_sha256": declaration_sha, "manifest_sha256": manifest_sha,
            "container_id": cid, "container_state": state, "source20_unchanged": True,
            "input_count": len(result["inputs"]), "actual_uid_euid_gid_egid": {
                key: result["header"][key] for key in ("uid", "euid", "gid", "egid")},
            "actual_file_owner_modes": [{"name": item["name"], "uid": item["path_before"]["uid"],
                "gid": item["path_before"]["gid"], "mode": item["path_before"]["mode"],
                "predicate_components_for_NEW_instance_only": item["old_predicate_components_for_NEW_instance_only"]}
                for item in result["inputs"]],
            "test_children_spawned": 0, "tool_modules_imported": 0,
            "no_old_container_image_source_guard_or_primitive_case_rerun": True,
            "command_records": records, "free_bytes": shutil.disk_usage(W).free, "finished": now()})
        print(json.dumps({"scope": "metadata_observation_only", "inputs": len(result["inputs"]),
            "capture_ready": False, "source_admitted": False, "directory": str(OUT)}))
    except BaseException as error:
        mod._write_json(OUT / "failure.json", {"capture_ready": False, "source_admitted": False,
            "live_admission": False, "container_id": cid, "commands": records,
            "type": type(error).__name__, "reason": str(error), "finished": now(),
            "no_retry_restart_cleanup_or_permission": True})
        raise

end = time.monotonic() + 45
while True:
    admitted = False
    try:
        with local_resource_lease(exclusive=True) as lease:
            admitted = True
            run(lease)
    except LocalResourceLeaseError:
        if admitted or time.monotonic() > end:
            raise
        time.sleep(.5)
    else:
        break
