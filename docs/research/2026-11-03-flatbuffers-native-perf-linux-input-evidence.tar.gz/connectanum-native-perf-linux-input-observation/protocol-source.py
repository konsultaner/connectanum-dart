"""Validator for observation protocol ONLY, never source admission."""
import base64, hashlib, json, re, stat
def parse_observation(raw, inputs, observer_sha, manifest_sha, host_owner_uid):
    if type(host_owner_uid) is not int or host_owner_uid < 0:
        raise ValueError("host owner data type differs")
    if type(raw) is not bytes or not raw or len(raw) > 4 * 1024**2 or not raw.endswith(b"\n"):
        raise ValueError("incomplete/oversized observation stream")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate observation key")
            result[key] = value
        return result
    values = [json.loads(line, object_pairs_hook=pairs,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite observation"))) for line in raw.splitlines()]
    def authority(value):
        if value.get("capture_ready") is not False:
            raise ValueError("observation cannot confer capture authority")
    header = values[0]
    if header.get("event") != "observation_start" or header.get("scope") != "fresh_source_input_metadata_only":
        raise ValueError("wrong observation header")
    authority(header)
    if header.get("source_admitted") is not False or header.get("live_admission") is not False:
        raise ValueError("observation cannot confer source/live admission")
    if header.get("manifest_sha256") != manifest_sha or header.get("method_source_read_sha256") != observer_sha:
        raise ValueError("observation context changed")
    if any(header.get(name) != "1000" for name in ("uid", "euid", "gid", "egid")):
        raise ValueError("declared method credentials differ")
    index, contexts = 1, {}
    for name in ("status", "uid_map", "gid_map", "mountinfo", "stat"):
        item = values[index]
        index += 1
        if item.get("event") != "context_raw" or item.get("name") != name:
            raise ValueError("context record missing/reordered")
        size = item.get("bytes")
        if type(size) is not int or not 0 <= size <= 262145 or type(item.get("truncated")) is not bool:
            raise ValueError("context bound/schema differs")
        encoded = item.get("data_base64")
        if type(encoded) is not str or len(encoded) != 4 * ((size + 2) // 3):
            raise ValueError("context encoded length differs before decode")
        data = base64.b64decode(encoded, validate=True)
        if len(data) != size or hashlib.sha256(data).hexdigest() != item["sha256"] or item["truncated"]:
            raise ValueError("context incomplete/hash mismatch")
        contexts[name] = data
    records = []
    for expected in inputs:
        start, observation, final = values[index:index+3]
        index += 3
        if [x.get("event") for x in (start, observation, final)] != ["input_start", "input_stat", "input_final"]:
            raise ValueError("input observation framing differs")
        if any(x.get("name") != expected["name"] for x in (start, observation, final)):
            raise ValueError("input name/order differs")
        for item in (start, observation, final):
            authority(item)
        if final.get("errors") != [] or final.get("fd_close_observed") is not True:
            raise ValueError("input observation incomplete")
        snapshots = [observation.get("observation")] + [
            final.get(key) for key in ("path_before", "fd_before", "fd_after", "path_after")]
        if any(type(x) is not dict for x in snapshots) or any(x != snapshots[0] for x in snapshots):
            raise ValueError("input snapshot changed")
        for state in snapshots:
            if (type(state.get("mode")) is not int or not 0 <= state["mode"] <= 0o177777
                or type(state.get("regular")) is not bool or state["regular"] is not True
                or not stat.S_ISREG(state["mode"])):
                raise ValueError("input stat type differs")
            for key in ("device", "inode", "size", "uid", "gid", "mtime_ns", "ctime_ns"):
                if type(state.get(key)) is not str or re.fullmatch(r"0|[1-9][0-9]*", state[key]) is None:
                    raise ValueError("input integer encoding differs")
        if (final.get("sha256") != expected["sha256"]
            or final.get("expected_sha256") != expected["sha256"]
            or final.get("expected_hash_match") is not True
            or final.get("stable_bounded_snapshot") is not True
            or type(final.get("bytes_read")) is not int
            or final["bytes_read"] != int(snapshots[0]["size"])):
            raise ValueError("input content binding differs")
        components = final.get("old_predicate_components_for_NEW_instance_only")
        required = {"regular": True,
            "owner_equals_declared_host_uid": snapshots[0]["uid"] == str(host_owner_uid),
            "not_group_or_other_writable": not bool(snapshots[0]["mode"] & 0o022)}
        if (final.get("host_owner_uid_data_only") != str(host_owner_uid)
            or type(components) is not dict or set(components) != set(required)
            or any(type(components[key]) is not bool or components[key] != value
                   for key, value in required.items())):
            raise ValueError("observed predicate annotation differs")
        records.append(final)
    if index != len(values)-1:
        raise ValueError("unexpected/extra observation records")
    footer = values[-1]
    authority(footer)
    if (footer.get("event") != "observation_footer" or footer.get("scope") != header["scope"]
        or footer.get("source_admitted") is not False or footer.get("live_admission") is not False
        or type(footer.get("input_count")) is not int or footer["input_count"] != len(inputs)
        or footer.get("all_declared_inputs_read_stable") is not True
        or footer.get("context_errors") != []
        or type(footer.get("test_children_spawned")) is not int or footer["test_children_spawned"] != 0
        or type(footer.get("tool_modules_imported")) is not int or footer["tool_modules_imported"] != 0):
        raise ValueError("observation footer differs")
    false_names = [item["name"] for item in records
                   if not all(item["old_predicate_components_for_NEW_instance_only"].values())]
    if footer.get("old_predicate_false_names_for_NEW_instance_only") != false_names:
        raise ValueError("observed predicate summary differs")
    return {"scope": "metadata_observation_protocol_only", "capture_ready": False,
        "source_admitted": False, "live_admission": False,
        "header": header, "contexts": contexts, "inputs": records, "footer": footer}
