import sys,pathlib,json,ast,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-path-input-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());beforeh=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'candidate-v3.py').read_text() and tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'aux_path_input_regressions-v4.py').read_bytes()
 parts=json.loads((P/'candidate-projection-parts-v3.json').read_text())
 assert source.replace(parts['new_step'],parts['old_step'],1).replace((P/'candidate-extra-v1.py').read_text(),'',1).replace(parts['new_wrapper'],parts['old_wrapper'],1).replace(parts['new_paths'],parts['old_paths'],1)==(P/'before-producer.py').read_text()
 assert sorted(k for k in h if h[k]!=beforeh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());x=json.loads((P/'before-extra-unit/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text())
 assert(b['tests'],b['failures'],b['passes'],b['errors'])==(6,5,1,0);assert(x['tests'],x['failures'],x['errors'])==(1,1,0);assert(a['tests'],a['failures'],a['errors'])==(74,0,0)
 assert len(a['leases'])==148 and all(row['raw_None'] for row in a['leases']);assert len(b['leases'])==12 and len(x['leases'])==2 and all(row['raw_None'] for row in b['leases']+x['leases'])
 def views(path):
  return {v['mode']:v for f in sorted(path.glob('*/view-before-unit-assertions.json')) for v in [json.loads(f.read_text())]}
 old=views(P/'before-units/fixtures');extra=views(P/'before-extra-unit/fixtures');new=views(P/'after-selected/fixtures')
 assert len(old)==6 and len(extra)==1 and len(new)==7
 for mode in ('argv_drift','environment_drift'):
  assert old[mode]['constructor_returned_object'] and old[mode]['intent_exists'] and old[mode]['Source_initializer_completed']
 assert old['argv_drift']['intent_argv0_empty'] and old['environment_drift']['actual_OWN_env_NUL']
 assert extra['fail_alias_drift']['constructor_returned_object'] and extra['fail_alias_drift']['intent_exists'] and extra['fail_alias_drift']['Source_fail_alias_None']
 for mode,v in new.items():
  assert v['Source_context_present'] and v['Source_render_before_asserts']==[] and not v['process_present'] and v['Source_public_constructor_returned'] is None
  assert all(row['raw_None'] for row in v['leases'])
  if mode=='normal_pathlike':
   assert v['Source_context_completed'] and v['Source_initializer_completed'] and v['Source_initializer_returned'] is True and v['constructor_returned_object'] and v['intent_exists']
   assert [row['role'] for row in v['events'] if row['kind']=='actual_fspath']==['directory','cwd']
   assert len(v['path_rows'])==4 and all(row['returned'] and not row['error_is_received'] for row in v['path_rows'])
  else:
   assert v['Source_first_received'] and v['pure_guard_first_is_received'] and v['pure_guard_no_monitored_IO']
   assert not v['Source_initializer_completed'] and v['Source_initializer_returned'] is None and not v['constructor_returned_object'] and not v['intent_exists']
   if mode in ('argv_drift','environment_drift','fail_alias_drift'):
    assert [row['role'] for row in v['events'] if row['kind']=='actual_fspath']==['directory']
    assert not any(row['kind'] in ('actual_resolve_return','hash_attempt','writer_attempt') for row in v['events'])
    assert len(v['path_rows'])==1 and v['path_rows'][0]['returned'] and not v['Source_context_completed']
   elif mode=='late_hash_fault':
    assert v['Source_context_completed'] and len(v['path_rows'])==4 and all(row['returned'] and not row['error_is_received'] for row in v['path_rows'])
    assert v['initializer_row_error_is_received']
   else:assert not v['path_rows'][-1]['returned'] and v['path_rows'][-1]['raw_kind']=='None' and v['path_rows'][-1]['error_is_received']
 assert new['fail_alias_drift']['Source_fail_alias_None'] and new['fail_alias_drift']['initializer_row_error_is_received']
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 before=dict(original6=dict(tests=6,failures=5,passes=1,errors=0),separateNEW1=dict(tests=1,failures=1,errors=0,original6_NOTreplayed=True),meaning='2actualinputvalidation gaps: ordinary PathLike callback aftervalidation producesemptyargv/NULenvinput andoldconstructor writesintent. 3oldfirstalreadyescapes butpercallwitnessmissing; separatefailaliaspolicyoldconstructorcompletes. NOT6nativekernelbugs/RAMcause.'),
 after=a,ROOT=dict(whole_final_source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=13,new_Source_worker_child_launches=0,no_globalactorabsence_or_fullreapclaim=True,current_parent_before6_EXverify_None=12,current_parent_extra1_EXverify_None=2,current_parent_AFTER_EXverify_None=148,originalpublictypecall_allocation_signature_Popen_factories_frozenpredicates_exact=True,shared_step_fail_bound_AFTERguard_BEFOREcallee=True,outerinit_fail_bound_beforecallbacks=True,healthy_pathrows_not_latehash_error=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM_v1_review=json.loads((P/'candidate-review-v2/result.json').read_text()),full_partial_final='ABSENT/notreconstructed',no_modelwholecurrentapproval=True),
 scope='ONLY4originalearlyPathcalls/inputcontext drift + boundfailurecaptured insharedpure_step/outerinitializer; no broader runtimeadmission',
 limits=['Candidatesv1-v2-v3 UNEXECUTED beforefinalSourceedit; privatev1-v3 UNEXECUTED, privatev2original6 BEFORE, privatev4separateextra1 BEFORE andmatching7 AFTER. GLMreviewv1 BEFOREboundfail/sharedstep/extra1 changes; ROOTfinalsource-tests-AST independentlyqualifies, notmodelapproval.',
 'Reviewcontrollerv1 template readmissingcandidate-v2.py AFTERnamespace mkdir BEFOREcontext-command-Popen/backend. Oldnamespace terminal; v2newnamespace removesunusedpreamble/no modelrepeat-unavailable inference. RawAPI retained.',
 'AFTERtooldisplay/actualAPIoutput was truncated by2400token cap; full preexistingresult.json/tests.log retained fromcontroller. MissingrawAPIoutput not reconstructed; signedouter0 andon-disk74results distinctfacts.',
 'Boundoriginalclass/function/ownerrefs/argv-envsnapshots andpureguard areDATA notkernelidentity-ABA-auth-credentials-ownership-physicalEX/admission. Caller mutations remain; no freeze-copy-away-restore. Contextcompleted meanspaths only; initializer/publicconstructor/ownerassociation remain separate.',
 'Source public_constructor_returned remainsNone evennormal; no adoption frominitializedfields/partialPopenmethods/field-derived ownerclose. No negativeSource start-wait-reinit-replay; onlypureguard.',
 '13newviews/12+2before and148AFTER parentEXverifyNone observations currentDarwinonly, notindependentfullEX-originalLinuxcredentials. New7unitSourcechild0, affectedfixtureactors/models/Git separatelyscoped/knownunitcleanup notliveownership/EXrelease/fullreaping.',
 'ActualFileIO/backingFD/setup/interpreter-delegate-descendant/sharedhistoricalwriter APIreturns notallserialized/no reconstruction/fullclosure. Existingaffectedunit cleanup/waits remainUNITnotruntime authority.',
 'OtherPathreturnshape/foreign-equality/metadatabinding/actorABA/latebody/inputthreads/historical-logsealing/transitiveclosure branches Sourceonly/unexecuted; no allAPI closure.',
 'NativeJSONwriter/hashbody contracts and normalcallorder retained exceptshared_step failbinding. 36writer/hash cases reexecuted because sharedbaseCHANGED, notunchangedcontrol replay; total74=7matchingNEW+67affected.',
 'Recordrefs/fullenvsnapshots/journals/closures/raw/traceback growthUNMEASURED/no exactheapRSSbound-leak-timing-cause-trim-reset-evict-delete authority.',
 'All20helpers uncommitteduncanonicalunadmitted/privatecontrollers outsideHELPERBUNDLE20/production601exact; no actualSDK-nativebuild-current20canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictacceptance. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.'],
 remaining=['remainingearlierinit/writer/hash APInegative-seams/actualFileIO backingwriter-internalFD errors','enclosingproducer cleanup/reporting/factorysuffix progress','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedjournalwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['auxiliary_path_input_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Auxiliary_path_NEW7_matching74PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected74PASS=True,new_views=13,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
