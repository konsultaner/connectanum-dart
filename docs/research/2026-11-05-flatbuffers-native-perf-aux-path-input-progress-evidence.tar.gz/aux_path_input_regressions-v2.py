"""NEW early Aux PathLike input drift and per-call progress controls."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import unittest
from unittest import mock
import native_perf_build_producer as producer


class AuxiliaryPathInputProgressTests(unittest.TestCase):
    def _path_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-path-'+mode+'-',dir=os.environ.get('CONNECTANUM_AUX_PATH_FIXTURES',tempfile.gettempdir()))).resolve()
        directory=base/'outputs';cwd=base/'cwd';directory.mkdir();cwd.mkdir()
        argv=[sys.executable,'-c','pass'];environment=dict(os.environ);environment['OWN_AUX_PATH_VALUE']='declared'
        initial_argv=tuple(argv);initial_environment=tuple(environment.items())
        events=[];seen={};render=[];leases=[]
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after native early call')
        class Delegate:
            def __init__(self,role,path):self.role=role;self.path=path
            def __fspath__(self):
                events.append(dict(kind='actual_fspath',role=self.role))
                if self.role=='directory' and mode=='argv_drift':argv[0]=''
                if self.role=='directory' and mode=='environment_drift':environment['OWN_AUX_PATH_VALUE']='ROOT\0changed'
                return str(self.path)
        directory_input=Delegate('directory',directory) if mode in ('argv_drift','environment_drift','normal_pathlike') else directory
        cwd_input=Delegate('cwd',cwd) if mode in ('argv_drift','environment_drift','normal_pathlike') else cwd
        cls=producer.AuxiliaryCommand;original_init=cls.__init__;original_resolve=Path.resolve;original_hash=producer._regular_hash;original_writer=producer._write_json
        original_source_file=Path(producer.__file__).resolve()
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def initializing(a,*args,**kwargs):
            seen['object']=a;events.append(dict(kind='actual_init_enter'))
            raw=original_init(a,*args,**kwargs);events.append(dict(kind='actual_init_return',raw_None=raw is None));return raw
        def resolving(actual,*args,**kwargs):
            raw=original_resolve(actual,*args,**kwargs)
            if actual in (directory,cwd):
                role='directory' if actual==directory else 'cwd';events.append(dict(kind='actual_resolve_return',role=role,same=raw==actual))
                if mode==role+'_resolve_fault':raise first
            return raw
        def hashing(actual,*args,**kwargs):
            events.append(dict(kind='hash_attempt',is_producer=actual==original_source_file))
            raw=original_hash(actual,*args,**kwargs);events.append(dict(kind='actual_hash_return',is_producer=actual==original_source_file))
            if mode=='late_hash_fault' and actual==original_source_file:raise first
            return raw
        def writing(*args,**kwargs):
            events.append(dict(kind='writer_attempt'));raw=original_writer(*args,**kwargs);events.append(dict(kind='writer_return',raw_None=raw is None));return raw

        received=None;result_marker=object();result=result_marker
        with mock.patch.object(cls,'__init__',initializing),mock.patch.object(Path,'resolve',resolving),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer,'_write_json',writing):
            try:result=cls(directory=directory_input,name='early-path',argv=argv,cwd=cwd_input,environment=environment,lease_check=verifying,stdout_max=1024)
            except BaseException as error:received=error
        a=seen.get('object');record=None if a is None else getattr(a,'_initialization_progress',None)
        context=None if record is None else getattr(record,'initial_path_context',None)
        rows=[] if record is None else [r for r in record.steps if r['stage'].startswith('initial_')]
        outer=[] if record is None else [r for r in record.steps if r['stage']=='initializer']
        guard_error=None;before_guard=len(events)
        if mode!='normal_pathlike' and record is not None:
            try:record.guard()
            except BaseException as error:guard_error=error
        file=directory/'early-path-intent.json';raw=file.read_bytes() if file.exists() else None
        intent=json.loads(raw) if raw is not None else None
        view=dict(mode=mode,events=events,leases=leases,received_type=None if received is None else type(received).__name__,received_original=received is first,
            constructor_returned_object=result is a and a is not None,initializer_record_present=record is not None,
            Source_public_constructor_returned=None if record is None else record.public_constructor_returned,
            Source_initializer_returned=None if record is None else record.initializer_returned,Source_initializer_completed=False if record is None else record.initializer_completed,
            Source_context_present=context is not None,Source_context_completed=context is not None and context['completed'],
            Source_first_received=record is not None and received is not None and record.first_error is received,
            pure_guard_first_is_received=guard_error is received and received is not None,pure_guard_no_monitored_IO=before_guard==len(events),
            path_rows=[dict(stage=r['stage'],returned=r['returned'],raw_kind='None' if r['raw'] is None else type(r['raw']).__name__,error_is_received=r['error'] is received and received is not None) for r in rows],
            initializer_row_error_is_received=bool(outer) and outer[-1]['error'] is received and received is not None,
            intent_exists=raw is not None,intent_argv0_empty=intent is not None and intent['argv'][0]=='',
            actual_argv_drift=tuple(argv)!=initial_argv,actual_OWN_env_NUL='\0' in environment['OWN_AUX_PATH_VALUE'],
            Source_render_before_asserts=list(render),process_present=a is not None and getattr(a,'process',None) is not None,
            limits='Actual ordinary public typecall/native PathLike/resolve; capturedobjects/rows/initializerfacts DATA not publicconstructor-knownreturn/ownerassociation/physicalEX/heapRSS/admission. No Source start-wait-reinit/replay.')
        (base/'view-before-unit-assertions.json').write_text(json.dumps(view,indent=2)+'\n')
        if raw is not None:(base/'observed-intent.json').write_bytes(raw)
        self.assertEqual([],render);self.assertIsNotNone(record);self.assertFalse(view['process_present']);self.assertIsNone(record.public_constructor_returned)
        self.assertTrue(all(x['raw_None'] for x in leases))
        if mode=='normal_pathlike':
            self.assertIsNone(received);self.assertIs(result,a);self.assertTrue(record.initializer_completed);self.assertTrue(record.initializer_returned is True)
            self.assertEqual([dict(kind='actual_fspath',role='directory'),dict(kind='actual_fspath',role='cwd')],[e for e in events if e['kind']=='actual_fspath'])
            self.assertEqual(list(initial_argv),intent['argv']);self.assertEqual(str(cwd),intent['cwd'])
            self.assertEqual(hashlib.sha256(json.dumps(dict(initial_environment),sort_keys=True,ensure_ascii=True).encode()).hexdigest(),intent['environment_sha256'])
            if context is not None:self.assertTrue(context['completed'])
        else:
            if mode in ('argv_drift','environment_drift'):self.assertIs(type(received),producer.ProducerError,'early PathLike input drift advanced into initialization/intent publication')
            else:self.assertIs(received,first)
            self.assertIs(record.first_error,received);self.assertIs(guard_error,received);self.assertFalse(record.initializer_completed);self.assertIsNone(record.initializer_returned)
            self.assertIsNotNone(context,'per-native early path context not retained');self.assertEqual(before_guard,len(events))
            self.assertFalse(file.exists())
            if mode in ('argv_drift','environment_drift'):
                self.assertEqual(['directory'],[e['role'] for e in events if e['kind']=='actual_fspath'])
                self.assertFalse(any(e['kind'] in ('actual_resolve_return','hash_attempt','writer_attempt') for e in events))
                self.assertEqual(['initial_directory_path'],[r['stage'] for r in rows]);self.assertTrue(rows[0]['returned'])
            elif mode in ('directory_resolve_fault','cwd_resolve_fault'):
                self.assertFalse(any(e['kind'] in ('hash_attempt','writer_attempt') for e in events))
                self.assertFalse(rows[-1]['returned']);self.assertIsNone(rows[-1]['raw']);self.assertIs(rows[-1]['error'],received)
            else:
                self.assertTrue(context['completed']);self.assertEqual(4,len(rows));self.assertTrue(all(r['returned'] and r['error'] is None for r in rows))
                self.assertTrue(outer[-1]['error'] is received);self.assertFalse(outer[-1]['returned'])
                self.assertFalse(any(e['kind']=='writer_attempt' for e in events))

    def test_actual_directory_fspath_argv_drift_stops_before_next_Path(self):self._path_case('argv_drift')
    def test_actual_directory_fspath_environment_NUL_drift_stops_before_next_Path(self):self._path_case('environment_drift')
    def test_actual_directory_resolve_then_ROOT_error_keeps_raw_UNKNOWN(self):self._path_case('directory_resolve_fault')
    def test_actual_cwd_resolve_then_ROOT_error_keeps_raw_UNKNOWN(self):self._path_case('cwd_resolve_fault')
    def test_late_actual_hash_error_does_not_contaminate_successful_path_steps(self):self._path_case('late_hash_fault')
    def test_normal_actual_PathLike_delegates_each_once_and_keeps_original_intent(self):self._path_case('normal_pathlike')
