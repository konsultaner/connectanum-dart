def _auxiliary_initial_paths(owner,directory,cwd,argv,environment):
    record=owner._initialization_progress
    call=record._step;guard=record.guard;fail=record._fail
    constructor=Path
    context=dict(object=owner,record=record,directory_input=directory,cwd_input=cwd,
        argv=argv,environment=environment,constructor=constructor,guard=guard,fail=fail,
        input_values=None,directory=None,cwd=None,directory_received=False,cwd_received=False,
        directory_resolved=None,cwd_resolved=None,completed=False)
    record.initial_path_context=context # Original refs BEFORE either Path call.

    def values():
        if (type(argv) is not list or not argv
            or any(type(x) is not str or not x or '\0' in x for x in argv)
            or type(environment) is not dict
            or any(type(k) is not str or type(v) is not str or '\0' in k+v for k,v in environment.items())):
            raise ProducerError('auxiliary early path input shape changed')
        return (tuple(argv),tuple(environment.items()))

    def check():
        guard() # Bound private first BEFORE current metadata checks.
        if (owner._initialization_progress is not record or record.object is not owner
            or record.guard is not guard or record._fail is not fail or Path is not constructor
            or record.initial_path_context is not context):
            raise ProducerError('auxiliary early path binding changed')
        if values()!=context['input_values']:
            raise ProducerError('auxiliary early path inputs changed')
        if context['directory_received'] and owner.directory is not context['directory']:
            raise ProducerError('auxiliary early directory reference changed')
        if context['cwd_received'] and owner.cwd is not context['cwd']:
            raise ProducerError('auxiliary early cwd reference changed')

    try:
        context['input_values']=values()
        value=call('initial_directory_path',lambda:constructor,(directory,))
        context['directory']=value;context['directory_received']=True
        owner.directory=value
        check()
        value=call('initial_cwd_path',lambda:constructor,(cwd,))
        context['cwd']=value;context['cwd_received']=True
        owner.cwd=value
        check()
        value=call('initial_directory_resolve',lambda:context['directory'].resolve,(),dict(strict=True))
        context['directory_resolved']=value
        check()
        if value!=context['directory']:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        value=call('initial_cwd_resolve',lambda:context['cwd'].resolve,(),dict(strict=True))
        context['cwd_resolved']=value
        check()
        if value!=context['cwd']:
            raise ProducerError('auxiliary directory/cwd must be canonical')
        context['completed']=True # Paths only, never initializer/public constructor/EX.
    except BaseException as error:
        # Native call errors already own their step row. Post-check errors have
        # no invented native-call attribution; bind first before metadata.
        fail(error)


