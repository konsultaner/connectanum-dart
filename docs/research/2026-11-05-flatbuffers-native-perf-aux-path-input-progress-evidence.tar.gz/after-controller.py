import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil,re,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-path-input-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1024**3;q=P/'after-selected';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir()
 tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();tree=ast.parse(tests)
 classes=dict(AuxiliaryPathInputProgressTests=6,AuxiliaryEarlyInitializationTests=6,AuxiliaryInitLeaseProgressTests=7,AuxiliaryFactoryCallProgressTests=7,AuxiliaryConstructorQuarantineTests=8)
 environment_names=set()
 for cls in classes:
  node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
  environment_names.update(re.findall(r'CONNECTANUM_[A-Z0-9_]+',ast.get_source_segment(tests.decode(),node)))
 for key in environment_names:
  if 'FIXTURES' in key:os.environ[key]=str(fixtures)
 os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 names=[]
 for cls,count in classes.items():
  found=unittest.defaultTestLoader.getTestCaseNames(getattr(tm,cls));assert len(found)==count,(cls,len(found),count);names.extend(cls+'.'+name for name in found)
 names+=['ProducerTests.test_positive_exact_source_commands_and_output_bytes','ProducerTests.test_receipt_fixture_canonical_links_actual_logs_and_inputs','ProducerTests.test_receipt_fixture_production_keeps_fixture_kind_and_output_links']
 assert len(names)==37
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,selection=names,expected_count=37,scope='6matchingNEW+31affected publicearlyinit/INITlease/factory/constructor/CommandProducer receipt cases; no unchangedwriter-hash suite/numerical replay/current20canonical/admission',fixture_environment_names=sorted(environment_names),hashes=h),f,indent=2)
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,tm))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(suite)
 (q/'tests.log').write_text(out.getvalue());v=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,leases=leases,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors],not_fullcanonical_admission=True)
 (q/'result.json').write_text(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['auxiliary_path_input_progress'].update(after_pending=False,after_result=v);c['active_turn_status']='Auxiliary_path_AFTER'+str(v['tests'])+'_'+str(v['failures'])+'FAIL_'+str(v['errors'])+'ERROR_ROOTpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v));print(out.getvalue()[-1600:])
 if not result.wasSuccessful():sys.exit(1)
