import sys,pathlib,json,ast,hashlib,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,v):
  with path.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 h=json.loads((P/'corrected-unverified-hashes.json').read_text());assert all(sha((R/rel).read_bytes())==digest for rel,digest in h.items())
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=16*1024**2
 path=R/'tool/test_native_perf_build_producer.py';s=path.read_text();c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='AllocatedCommandProcessTests');part=ast.get_source_segment(s,c)
 old="factory_new=foreign_allocator if mode=='allocator_drift' else real_class.__new__";assert part.count(old)==1;new=part.replace(old,"factory_new=foreign_allocator if mode=='allocator_drift' else mod._COMMAND_POPEN_NEW",1)
 old="mock.patch.object(real_class,'__new__',new=factory_new)";assert new.count(old)==1;new=new.replace(old,"mock.patch.object(mod,'_COMMAND_POPEN_NEW',new=factory_new)",1)
 assert s.count(part)==1;s=s.replace(part,new,1);ast.parse(s);path.write_text(s)
 hashes={}
 for rel in h:
  raw=(R/rel).read_bytes();target=P/'final-unverified-source23'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(raw)
  hashes[rel]=sha(raw)
 put(P/'final-unverified-hashes.json',hashes)
 data=[]
 for test in sorted((P/'matching-source-fixtures').iterdir()):
  if not test.is_dir() or not test.name.startswith('aux-allocated-'):continue
  for mode in ['normal','oserror']:
   p=test/mode/'result.json'
   if p.exists():
    row=json.loads(p.read_text())
    if 'history_rows' in row:
     assert row['history_rows']==[] and row['native_wait_observed'] and type(row['native_wait_status']) is int and row['native_wait_status']==0
     assert len(row['unit_FD_cleanup'])==4 and len(row['unit_writer_cleanup'])==2
     data.append(dict(mode=mode,result_sha256=sha(p.read_bytes()),native_wait_status=row['native_wait_status'],FD_cleanup_records=len(row['unit_FD_cleanup']),writer_cleanup_records=len(row['unit_writer_cleanup']),history_rows_empty=True))
 assert len(data)==2
 put(P/'shared-allocator-seam-and-cleanup-qualification.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),older_Direct_run_case_same_native_class_new_mock_pattern_migrated=True,only_two_lines_seam_change_assertions_unchanged=True,no_new_Direct_failure_count_or_test_claim=True,negative_allocator_only_capsule_constant_no_fake_positive=True,no_tests_requested_floor_unchanged=True,hashes=hashes,ROOT_cleanup_timing_correction='The two initial history tests IndexError at rows[0] occurs AFTER run_case saved result and completed its actual SAMEwait0 and FD/log unit-cleanup metadata. Earlier planned/unexecuted correction declaration assumed beforecleanup; no such declaration file was created before assertion failures. Actual retained reports, not rerun/reconstructed journals, establish this timing. Metadata still not full physicalFD/writer/delegate/instructionclosure proof.',actual_retained_initial_history_reports=data))
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(checkpoint.read_text());n=v['native_perf_only_diagnostic_design'];n['aux_allocation_implementation'].update(source_sha256=hashes['tool/native_perf_build_producer.py'],test_sha256=hashes['tool/test_native_perf_build_producer.py'],final_static_epoch_UNTESTED=True,older_direct_allocator_seam_only_migrated=True,cleanup_timing_qualification=str(P/'shared-allocator-seam-and-cleanup-qualification.json'));n['current_helper_source_epoch']=dict(producer_sha256=hashes['tool/native_perf_build_producer.py'],test_sha256=hashes['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'final-unverified-hashes.json'),all20_untracked_uncommitted_uncanonical_unadmitted=True,production601_unedited=True,phase='Final static Auxiliary + explicit Direct test allocator seam correction UNTESTED:1GiB floor closed');checkpoint.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source=hashes['tool/native_perf_build_producer.py'],test=hashes['tool/test_native_perf_build_producer.py'],tests_requested=False,initial_history_cleanup_metadata_verified_without_rerun=True)))
