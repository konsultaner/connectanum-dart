import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');D=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-debug');D.mkdir()
 value=json.loads((P/'matching-source-tests.json').read_text())
 context='NEW matching Auxiliary source units14=11PASS/3ERROR; do not repeat11passing tests. Actualfinite Popen/unitfixtures/syntheticowners only, notSDK/canonical. Need cluster setup/helper errors and minimal harness corrections, max3/max200words. No guessedcommands/kill/retry/sourceflagsoftening/SDK-physicalEX-release approval. Errorcases may have unit teardown signedwait before fullFD-logcleanup; omitted journals never reconstructed. ROOT verifies and only blockedcases plus affected cleanup callers at newtestepoch.\n\n'+json.dumps(value['errors_detail'],indent=2)
 assert len(context)<14000
 (D/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','debug','--stdin','--num-predict','1300','--max-input-chars','14000','--max-response-chars','7000','--timeout','180','--save-output',str(D/'debug.txt'),'--prompt','Cluster only these3new unit errors, max3concrete corrections/max200words. No unchangedrepeat/sourceassertionsoftening or closure approval.']
 def put(name,v):
  with (D/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 put('command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);put('started.json',dict(pid=child.pid))
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (D/(label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-7000:])
