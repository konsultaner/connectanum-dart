import sys,pathlib,json,hashlib,datetime,os,ast,types,subprocess,time,fcntl,errno
from unittest import mock
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/private-after').resolve();P.mkdir(mode=0o700)
 D=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-design')
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation/implemented-hashes.json').read_text())
 buffers={}
 for rel,digest in h.items():
  raw=(R/rel).read_bytes();assert sha(raw)==digest;buffers[rel]=raw
  target=P/'source23'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as out:out.write(raw)
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;assert free>=1024**3
 put(P/'declaration.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='NEW Auxiliary path AFTER five semantic controls at implemented source epoch; consumed BEFORE not rerun unchanged',hashes=h,free_bytes=free,test_floor=1024**3,no_source_native_SDK_build_canonical_capture=True,no_current_source_HEAD_query=True,original_public_aux_cleanup_unchanged=True,root_early_instance_reference_unit_only_not_library_backfill=True))
 real_class=subprocess.Popen;real_init=real_class.__init__;real_pipe=os.pipe;states=[];all_reports=[]
 def identity(st):return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink)
 def native_name(value):return type.__dict__['__name__'].__get__(type(value),type)
 child_code=("import os,time,json,sys\nfrom pathlib import Path\nready,release=map(Path,sys.argv[1:])\n"
  "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_AUX_ALLOC_UNIT')}))\n"
  "deadline=time.monotonic()+8\n"
  "while not release.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
  "raise SystemExit(0 if release.exists() else 78)\n")
 for mode in ['oserror','runtime','false_return','normal','class_drift']:
  lease.verify_identity()
  C=P/mode;C.mkdir(mode=0o700);repo=C/'repo';repo.mkdir();run=C/'run';run.mkdir()
  ready=C/'ready.json';release=C/'release'
  argv=[sys.executable,'-c',child_code,str(ready),str(release)]
  environment=dict(os.environ);environment['OWN_AUX_ALLOC_UNIT']=mode
  injected=OSError(5,'OWN AUX fault AFTER real original init') if mode=='oserror' else RuntimeError('OWN AUX fault AFTER real original init')
  state=dict(mode=mode,aux=None,child=None,wait=None,real_init_returned=False,before_init=None,args=None,kwargs=None,foreign_calls=0,init_entered=False,pipe_pairs=[],known_logs=[],public_error=None,start_return=None,unit_wait_observed=False,unit_wait_status=None)
  states.append(state)
  def own_pipe():
   pair=real_pipe()
   if not state['init_entered'] and len(state['pipe_pairs'])<2:
    rows=[dict(fd=fd,identity=None,access=None) for fd in pair];state['pipe_pairs'].append(rows)
    for row in rows:
     row['identity']=identity(os.fstat(row['fd']));row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
   return pair
  def initializer(instance,*args,**kwargs):
   # Exact object and original callable retained before any real initializer I/O.
   state['child']=instance;state['init_entered']=True;state['args']=args;state['kwargs']=kwargs
   assert len(args)==1 and args[0]==argv
   aux=state['aux'];record=getattr(aux,'_process_allocation',None)
   for stream in aux.streams.values():
    if stream['log'] is not None:state['known_logs'].append(stream['log'])
   state['before_init']=dict(source_record_native=type(record) is dict,
    allocated_reference_present=type(record) is dict and record.get('allocated_process') is instance,
    returned_process_present=aux.process is instance,pending=aux.pending,finished=aux.finished,
    source_argv_tuple=type(aux.argv) is tuple,source_environment_mappingproxy=type(aux.environment) is types.MappingProxyType,
    actual_instance_exact_class=type(instance) is real_class)
   put(C/'before-real-initializer.json',state['before_init'])
   real_init(instance,*args,**kwargs)
   state['real_init_returned']=True;state['wait']=instance.wait
   if mode in ('oserror','runtime'):raise injected
   if mode=='false_return':return False
   return None
  def outer_init(instance,*args,**kwargs):return initializer(instance,*args,**kwargs)
  def foreign_init(instance,*args,**kwargs):
   state['foreign_calls']+=1;state['uninitialized_instance']=instance
   raise RuntimeError('OWN foreign Auxiliary initializer BEFORE real native init')
  name='_aux_allocation_after_'+mode;mod=types.ModuleType(name);mod.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[name]=mod
  try:
   with mock.patch.object(real_class,'__init__',outer_init):
    exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
    aux=object.__new__(mod.AuxiliaryCommand);state['aux']=aux
    mod.AuxiliaryCommand.__init__(aux,directory=run,name='owned-aux',argv=argv,cwd=repo,environment=environment,lease_check=lease.verify_identity,stdout_max=1024**2,stderr_max=1024**2)
    with mock.patch.object(real_class,'__init__',foreign_init if mode=='class_drift' else outer_init),mock.patch.object(os,'pipe',own_pipe):
     try:state['start_return']=aux.start()
     except BaseException as error:state['public_error']=error
  finally:sys.modules.pop(name)
  child=state['child'];record=getattr(aux,'_process_allocation',None)
  report=dict(mode=mode,source_sha256=h['tool/native_perf_build_producer.py'],actual_real_init_returned=state['real_init_returned'],source_before_init=state['before_init'],
   source_allocated_reference_after=child is not None and type(record) is dict and record.get('allocated_process') is child,
   source_process_is_child=child is not None and aux.process is child,
   source_process_None=aux.process is None,source_pending=aux.pending,source_finished=aux.finished,
   source_status=aux.status,source_natural_wait_before_unit=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status,process_is_child=child is not None and aux._natural_wait_process is child),
   source_result_type=native_name(state['start_return']),public_error_type=None if state['public_error'] is None else native_name(state['public_error']),
   source_spawn_error_is_string=type(aux.spawn_error) is str,foreign_initializer_calls=state['foreign_calls'],
   private_primary_is_injected=aux._allocation_primary_error is injected,private_primary_type=None if aux._allocation_primary_error is None else native_name(aux._allocation_primary_error),
   native_wait_observed=False,native_wait_status=None,unit_FD_cleanup=[],unit_writer_cleanup=[],
   no_original_SDK_kernel_RAM_defect_claim=True,no_source_state_backfill_or_retag=True)
  if state['kwargs'] is not None:
   kw=state['kwargs'];stdout=aux.streams['stdout'];stderr=aux.streams['stderr']
   writers=[rows[1]['fd'] for rows in state['pipe_pairs']]
   report['constructor_arguments']=dict(exact_class=type(child) is real_class,argv_exact=state['args'][0]==argv,
    cwd_exact=kw.get('cwd')==repo,environment_equal=kw.get('env')==environment,
    environment_is_original_start_copy=type(kw.get('env')) is dict and kw.get('env') is not aux.environment and kw.get('env') is not environment,
    stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_writer=len(writers)==2 and kw.get('stdout')==writers[0],
    stderr_original_writer=len(writers)==2 and kw.get('stderr')==writers[1],writers_distinct=len(writers)==2 and writers[0]!=writers[1],close_fds=kw.get('close_fds') is True)
  put(C/'source-after-call-before-unit-wait.json',report)
  if state['real_init_returned']:
   until=time.monotonic()+3
   while not ready.exists() and time.monotonic()<until:time.sleep(.005)
   assert ready.exists()
   ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw);report['ready_data']=json.loads(ready_raw)
   assert report['ready_data']==dict(cwd=str(repo),case=mode)
   release.mkdir(mode=0o700)
   status=state['wait'](3);state['unit_wait_observed']=True;state['unit_wait_status']=status
   report['native_wait_observed']=True;report['native_wait_status']=status
   # Save exact SAMEPopen.wait return BEFORE root FD/log cleanup or later source wait API.
   put(C/'actual-wait-before-root-FD-cleanup.json',dict(pid=child.pid,status=status,exact_signed_int=type(status) is int,source_wait_before_unit=report['source_natural_wait_before_unit'],root_early_instance_only_unit_cleanup_not_sourcebackfill=True,not_fresh_syscall_or_physicalclosure_proof=True))
   assert type(status) is int and status==0
   if mode=='normal':
    # One affected actual Auxiliary caller. Its wait may return cached status0, not fresh syscall proof.
    returned=aux.wait(3);report['normal_source_wait_API_return']=returned
    put(C/'normal-source-wait-API-return.json',dict(returned=returned,natural_wait_observed=aux._natural_wait_observed,natural_wait_status=aux._natural_wait_status,pending=aux.pending,finished=aux.finished))
  elif child is not None:
   put(C/'unknown-real-init-quarantine.json',dict(exact_object_retained=True,status=None,no_invented_zero=True))
   raise AssertionError('unexpected real initializer failure; actual EX must remain with retained state')
  for pair in reversed(state['pipe_pairs']):
   for row in reversed(pair):
    fd=row['fd'];entry=dict(fd=fd,unit_only=True,normal_close_observed=None)
    try:now=os.fstat(fd)
    except OSError as error:
     assert error.errno==errno.EBADF;entry['observed_errno']=error.errno
    else:
     assert identity(now)==tuple(row['identity']) and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
     if row['access']==os.O_RDONLY:
      pieces=[]
      while True:
       raw=os.read(fd,65536)
       if not raw:break
       pieces.append(raw)
      suffix=b''.join(pieces)
      with (C/('unit-reader-'+str(fd)+'-suffix.bin')).open('xb') as out:out.write(suffix)
      entry.update(actual_reader_EOF=True,size=len(suffix),sha256=sha(suffix))
     entry['close_intent']=True;returned=os.close(fd);entry['normal_close_observed']=returned is None
    report['unit_FD_cleanup'].append(entry)
  seen=[]
  for log in state['known_logs']+[stream['log'] for stream in aux.streams.values()]:
   if log is None or any(log is item for item in seen):continue
   seen.append(log);entry=dict(closed_before_unit_cleanup=log.closed)
   if not log.closed:
    fd=log.fileno();held=os.fstat(fd);assert identity(held)==identity(pathlib.Path(log.name).stat())
    entry['close_intent']=True;returned=log.close();entry['normal_close_return']=returned is None;entry['closed_after']=log.closed
   report['unit_writer_cleanup'].append(entry)
  report['source_natural_wait_after_unit']=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status)
  for path in sorted(run.iterdir()):
   if path.is_file():
    raw=path.read_bytes()
    with (C/(path.name+'.retained')).open('xb') as out:out.write(raw)
  if mode=='normal':
   passed=(report['actual_real_init_returned'] and report['native_wait_status']==0 and report['source_process_is_child'] and all(report['constructor_arguments'].values()) and report['normal_source_wait_API_return']['status']=='success')
  elif mode=='class_drift':passed=state['foreign_calls']==0
  else:
   passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present'] and report['source_allocated_reference_after'] and report['native_wait_status']==0)
  report['expected_property_passed']=passed
  report['declared_boundary_reached']=(len(state['pipe_pairs'])==2 and (state['foreign_calls']==0 and type(record) is dict and record.get('reserved') is True and record.get('constructor_attempted') is True if mode=='class_drift' else state['real_init_returned']))
  put(C/'result.json',report);all_reports.append(report);lease.verify_identity()
 assert all(row['declared_boundary_reached'] for row in all_reports)
 for rel,digest in h.items():assert sha((R/rel).read_bytes())==digest
 summary=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controls=5,passed=sum(row['expected_property_passed'] for row in all_reports),failed=sum(not row['expected_property_passed'] for row in all_reports),hashes=h,
  all_boundaries_reached=True,no_missing_API_errors=True,actual_finite_children=[dict(mode=row['mode'],status=row['native_wait_status']) for row in all_reports if row['native_wait_observed']],
  no_source_edit_current20_canonical_native_SDK_kernel_benchmark_capture=True,root_actual_official_EX_current_Darwin_finite_only=True,
  raw_limits='Root exact instance held BEFORErealinit for unitcleanup only, source neverbackfilled. Source handler may closecopies/complete/publish while actual child exists in injected faultmodel. NormalsourcewaitAPI afterrootwait mayobserve cached0, not fresh syscall. RetiredFDnotreclosed/no closedreadEOF reconstruction. No fulltransitiveFD/delegate/descendant/EXrelease/admission/nativeimage proof. Errorobjects private/savedbool-nativeclassnames. Administrative fixture file API returns not exhaustively serialized.')
 put(P/'summary.json',summary);assert summary['passed']==5 and summary['failed']==0
 lease.verify_identity();print(json.dumps({k:summary[k] for k in ['controls','passed','failed','actual_finite_children','all_boundaries_reached']}))
