import sys,pathlib,json,hashlib,ast,copy,subprocess,datetime,os,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');Q=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-root-assessment');Q.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,v):
  with path.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 old=json.loads((P/'original-hashes.json').read_text());new=json.loads((P/'final-unverified-hashes.json').read_text())
 assert len(new)==23 and set(old)==set(new)
 for rel,digest in new.items():assert sha((R/rel).read_bytes())==digest
 assert sorted(rel for rel in old if old[rel]!=new[rel])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 before=(P/'original-source23/tool/native_perf_build_producer.py').read_text();after=(R/'tool/native_perf_build_producer.py').read_text()
 def classes(t):return {n.name:n for n in t.body if isinstance(n,ast.ClassDef)}
 def methods(c):return {n.name:n for n in c.body if isinstance(n,ast.FunctionDef)}
 bt,at=ast.parse(before),ast.parse(after);bc,ac=classes(bt),classes(at);assert set(bc)==set(ac)
 allowed={'AuxiliaryCommand':{'__init__','start','_allocation_record','_retain_allocation_error','_initialize_process','_allocate_process'},'_RetainedPreflightOwner':{'_capture_command_history'}}
 unchanged=[]
 for name in bc:
  b,a=methods(bc[name]),methods(ac[name])
  assert set(a)-set(b)==({'_allocation_record','_retain_allocation_error','_initialize_process','_allocate_process'} if name=='AuxiliaryCommand' else set())
  for method in b:
   if method not in allowed.get(name,set()):
    assert ast.get_source_segment(before,b[method])==ast.get_source_segment(after,a[method]),(name,method);unchanged.append(name+'.'+method)
 top=lambda t,s:[ast.get_source_segment(s,n) for n in t.body if not isinstance(n,ast.ClassDef)]
 assert top(bt,before)==top(at,after)
 bmethods,amethods=methods(bc['AuxiliaryCommand']),methods(ac['AuxiliaryCommand'])
 newfields={'self._process_allocation','self._allocated_process','self._process_allocation_arguments','self._allocation_primary_error','self._allocation_secondary_errors','self._process_allocation_binding'}
 constructor=copy.deepcopy(amethods['__init__'])
 constructor.body=[n for n in constructor.body if not(isinstance(n,ast.Assign) and any(ast.unparse(target) in newfields|{'allocation'} for target in n.targets))]
 assert ast.dump(constructor,include_attributes=False)==ast.dump(bmethods['__init__'],include_attributes=False)
 original_call=next(n for n in ast.walk(bmethods['start']) if isinstance(n,ast.Call) and ast.unparse(n.func)=='subprocess.Popen')
 class Normalize(ast.NodeTransformer):
  def visit_Assign(self,node):
   if any(ast.unparse(target) in ('allocation',"allocation['reserved']") for target in node.targets):return None
   return self.generic_visit(node)
  def visit_Expr(self,node):
   if isinstance(node.value,ast.Call) and ast.unparse(node.value.func) in ('self._allocation_record','self._retain_allocation_error'):return None
   return self.generic_visit(node)
  def visit_Call(self,node):
   if ast.unparse(node.func)=='self._allocate_process':
    assert [ast.unparse(x) for x in node.args]==['allocation'];return copy.deepcopy(original_call)
   return self.generic_visit(node)
 normalized=Normalize().visit(copy.deepcopy(amethods['start']))
 assert ast.dump(normalized,include_attributes=False)==ast.dump(bmethods['start'],include_attributes=False)
 helper=ast.get_source_segment(after,amethods['_allocate_process'])
 assert helper.index('arguments=(list(self.argv)')<helper.index('process=allocator(cls)')
 assert helper.index('self._allocated_process=process')<helper.index('returned=self._initialize_process(initializer,process,arguments)')
 init=ast.get_source_segment(after,amethods['_initialize_process'])
 assert '_COMMAND_POPEN_INIT' not in init and 'self.cwd' not in init and 'self.environment' not in init
 bcap=ast.get_source_segment(before,methods(bc['_RetainedPreflightOwner'])['_capture_command_history']);capnode=methods(ac['_RetainedPreflightOwner'])['_capture_command_history'];cap=ast.get_source_segment(after,capnode)
 marker='        for index,(aux,aux_data)'
 assert bcap[:bcap.index(marker)]==cap[:cap.index(marker)]
 binding_assigns=[n for n in ast.walk(capnode) if isinstance(n,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='binding' for target in n.targets)]
 assert len(binding_assigns)==1 and isinstance(binding_assigns[0].value,ast.List)
 tbefore=(P/'original-source23/tool/test_native_perf_build_producer.py').read_text();tafter=(R/'tool/test_native_perf_build_producer.py').read_text()
 tbt,tat=ast.parse(tbefore),ast.parse(tafter);tbc,tac=classes(tbt),classes(tat);assert set(tac)-set(tbc)=={'AllocatedAuxiliaryProcessTests'}
 for name in tbc:
  b,a=methods(tbc[name]),methods(tac[name]);assert set(b)==set(a)
  for method in b:
   if (name,method)!=('AllocatedCommandProcessTests','run_case'):
    assert ast.get_source_segment(tbefore,b[method])==ast.get_source_segment(tafter,a[method]),(name,method)
 assert top(tbt,tbefore)==top(tat,tafter)
 direct=ast.get_source_segment(tafter,methods(tac['AllocatedCommandProcessTests'])['run_case'])
 direct=direct.replace("factory_new=foreign_allocator if mode=='allocator_drift' else mod._COMMAND_POPEN_NEW","factory_new=foreign_allocator if mode=='allocator_drift' else real_class.__new__",1).replace("mock.patch.object(mod,'_COMMAND_POPEN_NEW',new=factory_new)","mock.patch.object(real_class,'__new__',new=factory_new)",1)
 assert direct==ast.get_source_segment(tbefore,methods(tbc['AllocatedCommandProcessTests'])['run_case'])
 newtests=[name for name in methods(tac['AllocatedAuxiliaryProcessTests']) if name.startswith('test_')];assert len(newtests)==13
 for name in ['AllocatedCommandProcessTests','AllocatedAuxiliaryProcessTests']:
  assert "mock.patch.object(real_class,'__new__'" not in ast.get_source_segment(tafter,tac[name])
 put(Q/'invariants.json',dict(other21_selected_files_byteexact=True,other_original_source_and_test_nodes_byteexact_except_declared_scopes=True,Aux_ctor_projects_back_AST_exact=True,Aux_start_projects_back_AST_exact_including_public_cleanup=True,original_start_argument_copy_evaluation_static_preserved=True,private_record_before_constructor_intent_and_lease=True,allocated_before_initializer=True,captured_initializer_forwarded_locally=True,owner_capture_prefix_before_Aux_loop_byteexact=True,capture_binding_list_not_shadowed=True,older_Direct_test_two_line_capsule_allocator_seam_only=True,new_Aux_unit_methods=newtests,root_static_only_not_test_or_model_fullsource_approval=True,unchanged_source_methods=unchanged))
 with (Q/'whole-affected-methods-and-new-tests.txt').open('x') as f:
  for cname,names in allowed.items():
   for name in sorted(names):f.write(cname+'.'+name+'\n'+ast.get_source_segment(after,methods(ac[cname])[name])+'\n\n')
  f.write(ast.get_source_segment(tafter,tac['AllocatedAuxiliaryProcessTests']))
 for rel in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']:
  a=(P/'original-source23'/rel).read_text();b=(R/rel).read_text()
  with (Q/(pathlib.Path(rel).name+'.diff')).open('x') as f:f.write(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True))))
 initial=json.loads((P/'matching-source-tests.json').read_text());assert (initial['tests'],initial['failures'],initial['errors'])==(14,0,3)
 private=json.loads((P/'private-after/summary.json').read_text());assert (private['controls'],private['passed'],private['failed'])==(5,5,0)
 assert all(row['status']==0 and type(row['status']) is int for row in private['actual_finite_children'])
 debug=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-debug/finish.json').read_text());review=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-review/finish.json').read_text());assert debug['direct_status']==0 and review['direct_status']==1 and debug['reaped'] and review['reaped']
 # New post-static source-state purpose; no tests/version/bootstrap/native probes.
 commands=[]
 def git(*args):
  argv=['git','-C',str(R),*args];record=dict(argv=argv,pid=None,status=None,stdout_eof=False,stderr_eof=False);commands.append(record)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);record['handle']=child;record['pid']=child.pid
  stdout,stderr=child.communicate();record['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (Q/('post-'+str(len(commands)-1)+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   record[label+'_eof']=True;record[label+'_size']=len(raw);record[label+'_sha256']=sha(raw)
  put(Q/('post-'+str(len(commands)-1)+'-return.json'),{k:v for k,v in record.items() if k!='handle'})
  assert type(record['status']) is int and record['status']==0;lease.verify_identity();return stdout.decode()
 assert git('branch','--show-current').strip()=='codex/flatbuffers-native-perf-guard'
 assert git('rev-parse','HEAD').strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 lines=git('status','--porcelain').splitlines();assert len(lines)==20 and all(row.startswith('?? tool/') for row in lines)
 assert git('diff','HEAD','--','packages','native')==''
 put(Q/'post-Git.json',[{k:v for k,v in row.items() if k!='handle'} for row in commands])
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='Auxiliary_allocation_implemented_STATIC_corrected_epoch_UNTESTED_TESTFLOOR_CLOSED',hashes=new,baseline_hashes=old,source_sha256=new['tool/native_perf_build_producer.py'],test_sha256=new['tool/test_native_perf_build_producer.py'],
  implementation='Private allocation ledger/originaltuplebinding/exactallocatedref/errorstate BEFOREctor intenthash-write/lease; reservation BEFOREstartIO; pinned original class/new/init; original start argv/env copies/argumentrefs BEFOREallocator; allocated BEFOREcapturedinit; process/pending onlynormalNone-return; typed partialAuxDATA unknown/quarantine, no wait/release authority. Old publiccleanup projects back AST exact after removing scoped changes.',
  distinct_tests=dict(consumed_BEFORE5='4FAIL1PASS, never unchangedrerun',private_AFTER5=dict(passed=5,failed=0,source_hash=private['hashes']['tool/native_perf_build_producer.py'],actual_four_waits=private['actual_finite_children']),initial_matching14=dict(passed=11,failures=0,errors=3,source_hash=initial['source_sha256']['tool/native_perf_build_producer.py'],test_hash=initial['source_sha256']['tool/test_native_perf_build_producer.py']),new_declared_methods=13,final_static_epoch_UNTESTED=True,no_combined_full_final13_or_aggregate_canonical=True),
  corrections='Two history tests error at emptyrows[0]; ROOT static finds Aux local binding overwrites capture closure LIST with TUPLE before process()->hold()->append. Renamed allocation_binding. Original private workererror objects/text were not saved, never reconstructed. RequiredFixture fails Gitsetup BEFOREnativeGit due nativeclass __new__ mock typecall slot mutation; remove nativeclass allocator mocking from newAux fixture AND same two-line priorDirect fixture pattern, negative onlycapsule allocatorconstant, actualpositives remain real. No new Direct failure count. New helper/error diagnostics STATIC, not executed since1GiB floor closed.',
  initial_cleanup_qualification=json.loads((P/'shared-allocator-seam-and-cleanup-qualification.json').read_text())['ROOT_cleanup_timing_correction'],
  models=dict(debug=debug,review=review,qualifications='Qwen55766 debug complete0/advisory: ROOT rejects guessed Python3.14/argv cause, Git/version repro/commands and fake row seeding; source binding shadow/nativeclass mock supported. Qwen59284 selected corrected source221e/test89c6 review direct1/tokenlimit1800/stdout0/stderr614/lastprogress6771visiblechars/FULLpartialfinalABSENT/reachable/reaped, not unavailable/approval/no repeat. Finaltest89b3 differs by explicit olderDirect two-line seam only after review. ROOT whole affected final source/tests/AST static qualified; no model fullcurrent-source approval.'),
  administration='Initial wrong _observe_status signature assertion AFTERtwo fresh preeditGit0 receipts/originalsnapshot BEFOREsourcewrite/testactors. Corrected EX twice refused BEFOREbody with literal active companion; no bypass, not backendunavailable. Later v2 actualEX admits source edit. Initial candidateJS guard falsepositive matches release. before tools/filesystem/source/tests/fulltoolbody notregularfile. Matching14 actual, then1GiB preflight fails BEFOREsource/test changes/actors. Static-only16MiB edit guard NOT test/buildfloor waiver. Static correction sourcewritten then history-indent assertion BEFOREtestwrite; distinct AST-scoped correction completes, all originals retained/no reset.',
  raw_limits='ActualfiniteOWNPython/Popen and SYNTHETIC unregisteredowners/operations/leasecallbacks with realThreads; no SDK/compiler/version/bootstrap/native/canonical/benchmark. RequiredFixture initialerror in Gitsetup before nativeGit/no new sixSHIM or fullFixture receipt success. RootofficialEX spansknownfinitecases, no originalLinux-rootperf/fullinstructionclosure. Private errors/refs/savedbool-nativeclassnames; initial private workererror notserialized. Actual existing run_case result files prove SAMEwait0 and FD/log unitcleanup metadata precede history IndexError; not full kernelclose/writer/delegate/descendant or physicalEXrelease. Negative sourcewaitFalse-null notbackfilled; normalAuxwait maycached0, no freshsyscall. No liveunitcleanup/recovery/retag/heapRSSbound. Legacy setup/APIreturns notallsaved/no reconstruction.',
  provenance='Implementation/correction/test/debug/review controller originals saved BEFORE executions except failed early JS toolbody notregularfile; retained copies aftercalls remain distinct. No beforeexecution admission. All20 untracked/uncommitted/uncanonical/unadmitted; production601 unedited/privatecontrollersoutsideHELPERBUNDLE20. Other21 source/bin files and original source/test nodes except explicit scopes byteexact. FourNEWpoststaticGit0/BOTHseparateEOF/branch601/20untracked/productiondiffempty DATA only, not native-output-loadedinstructionproof.',
  pending='Before any tests fresh1GiBcheck; final-targeted8 verification pending current epoch. Build12GiBfloor CLOSED. No cleanup; old92NoDeletionplan terminal. Fresh inactiveOWN/protectedhashes/receipt/EX declaration needed for any future reclaim; never protected evidence/natives/RLIBs/exes/other-taskdata. Then originalpubliccleanup/historycontinuation-logseal/transitivegenericFD/auditpartialunknownactors/sharedjournal-writers/interpreter-delegate-descendant/fullactualofficialEX and originalruntime provenance/ROOT-qualified immutableCOMPLETEadmission before diagnosticdata.',
  live=dict(provider_absent=True,gate_always_raises=True,controller_closed=True,ownership=None,capture_ready=False,source_admitted=False,live_admission=False,no_SDK_native_build_canonical_kernel_broker_benchmark_capture=True,no_RAMcause_repair_acceptance=True,no_source_commit_push_adoption_strictdispatch=True),
  free_bytes=free,test_floor_bytes=1073741824,test_floor_open=free>=1073741824,build_floor_bytes=12884901888,build_floor_open=free>=12884901888,cause_unmeasured=True,no_cleanup=True)
 put(Q/'assessment.json',assessment);put(P/'current-hashes.json',new)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(checkpoint.read_text());n=v['native_perf_only_diagnostic_design'];n['aux_allocation_implementation'].update(root_assessment=str(Q/'assessment.json'),publication_pending=True,source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],final_epoch_UNTESTED=True,verification_deferred_testfloor=True,final_source_static_ROOT_qualified=True,no_model_fullsource_approval=True);n['last_free_bytes']=free;v['updated_utc']=assessment['utc'];checkpoint.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],test_floor_open=assessment['test_floor_open'],free_bytes=free,postGit4_signed0_BOTHEOF=True,final_epoch_UNTESTED=True)))
