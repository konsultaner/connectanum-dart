import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');a=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-debug')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='74d611a8528011d4d6116688b1413991de24a5ae'
 assert git('status','--porcelain')==''
 h=json.loads((p/'current-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 logical_budget=sum(path.stat().st_size for root in [p,a,final_root,pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-review')] for path in root.rglob('*') if path.is_file() and not path.is_symlink())
 assert before>=64*1024**2+2*logical_budget
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  controller_order_qualified_per_kind=True,administrative_archive_budget_only_bytes=64*1024**2+2*logical_budget,logical_regular_bytes_preflight=logical_budget,build_12GiB_and_test_1GiB_floors_NOT_waived=True))
 base='2026-11-04-flatbuffers-native-perf-aux-allocation-implementation';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'implementation'),(a,'debug'),(final_root,'root-final'),(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-review'),'review')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='Original executable controllers saved BEFORE execution, copies aftercalls; failed initialJS fulltoolbody notregularfile. Percommand receipts distinct; no execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Auxiliary allocation implemented; corrected epoch awaits verification\n\nAuxiliaryCommand now reserves a private allocation ledger and durable original\nbinding, exact allocated-process reference and private first/staged errors before\nconstructor intent hashing/writing and the lease callback. Start reserves its\nsingle attempt before I/O. The helper pins/checks the original Popen class,\nresolved standard allocator and initializer, binds the original start list/\nenvironment copies and argument references before allocation, and holds the\nexact object before initializer I/O. Process/pending still follow normal None-only\nconstruction. Frozen Auxiliary DATA retains partial actors/unknown starts and\nquarantines them without inventing pid/status/liveness/wait or release authority.\nOriginal repr/defer/add_note/pipe-close/complete/publication policy remains\nunchanged outside this allocation scope and may mask errors or close copies.\n\nThe consumed BEFORE5=4FAIL/1PASS does not run again unchanged. At initial source\nd5f0bdd0c5234f81d92276255b79aabaf4e370a9f6da3aba727600eeba3c4788,\nprivate AFTER5 passes with four actual finite Python same-Popen signed0 method\nwaits. Matching source14 then yields11PASS/3ERROR: thirteen new Auxiliary methods\nand one required existing Fixture receipt caller. Two history methods raise at\nempty rows. Source inspection finds the new Auxiliary local binding overwrites\nthe capture closure's list with a tuple; a subsequent allocated-Popen hold calls\nappend on that tuple. The original private worker error objects/text were not\nserialized and are not reconstructed. The third error occurs during required\nFixture Git setup before native Git: a test's native-class __new__ mock changes\nnormal type-call slot behavior. No new shell-version-shim or complete Fixture\nreceipt success is established by that failed caller.\n\nStatic corrections rename the Auxiliary local to allocation_binding, preserving\nthe capture list, and move allocator negatives to the private capsule constant.\nActual positive processes stay the real Popen class. The same two-line allocator\nseam migration is applied to the older Direct fixture's matching class-mock\npattern; no separate new Direct failure count is claimed. Assertions remain.\nNew history diagnostics are source only and unexecuted at the corrected epoch.\nThere is no combined full-final13, aggregate pass count or canonical result.\n\nThe final corrected source/test epoch is UNTESTED because the separate1GiB test\nfloor closed. Two verification preflights refuse before tests/actors; the first\nalso precedes source/test mutation. Subsequent edits and AST checks use a declared\nsmall source-edit budget, not a test/build floor waiver. Eight targeted methods\nare prepared: the two blocked histories, required Fixture caller, changed\nAuxiliary allocator/normal cases, changed Direct allocator/normal cases and an\naffected actual two-command frozen-history caller. Run only after a fresh1GiB\ncheck at this exact epoch. The12GiB build floor also remains closed.\n\nFinal producer:\n221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd.\nFinal test:\n89b36b7eb786ff3e1b2496c76232ee23fb1f512863bbaa877ec6bba8f8fc49b8.\nOnly the pair changes from the phase baseline. Four Auxiliary helpers, constructor\nprivate state/start reservation-call-error retention and the owner Auxiliary\nDATA tail are scoped changes. Removing those additions/restoring the constructor\ncall projects both original constructor/start ASTs back exactly, including public\ncleanup. CommandProducer, other Auxiliary/owner methods, module functions/\nfactories/gates/emitters, original test nodes except the explicit Direct seam,\nand other18 helpers+3 bins remain byteexact. The capture prefix before its\nAuxiliary tail is exact. ROOT verifies that the capture list is no longer\nshadowed, argument copies precede allocation, and the captured initializer is\nforwarded locally. Static checks are not execution approval.\n\nQwen55766 debug completes0 and is reaped. ROOT rejects its guessed Python3.14/\nargv incompatibility, Git/version repro, guessed commands and fake row seeding;\nthe closure shadow and test allocator mutation are supported by source.\nQwen59284 selected corrected source221e/test89c6 review returns direct1 at\ntoken limit1800, stdout0/stderr614 bytes. Its last progress reports6771 visible\ncharacters; full partial/final output is absent. It is reachable and reaped,\nnot unavailable or approval. No unchanged review repeats. Only the explicit\nolder Direct two-line test seam changes after that review. ROOT qualifies whole\naffected final methods/tests and invariants statically; no model has approved\nthe full current source or physical closure.\n\nAdministrative failures remain retained. The initial wrong observe-status\nsignature assertion follows two fresh pre-edit Git0 receipts/original snapshot,\nbut precedes source write or test actors. Two corrected EX requests are refused\nbefore body by an active companion reservation; no bypass or backend-unavailable\nclaim. A later v2 uses actual EX and applies the patch. An initial candidate JS\nguard mistakes release. for a lease reference and fails before tools/filesystem/\nsource/tests; its full tool body is not a regular file. A later static correction\nwrites the source, then an indentation-specific history selector assertion fails\nbefore test write. A distinct AST-scoped correction completes. Originals and\npartial evidence remain; no reset or gap reconstruction.\n\nROOT corrects an earlier planned, unexecuted cleanup inference: both initial\nhistory IndexErrors happen after run_case saves its result and completes actual\nsame-Popen wait0 and FD/log unit-cleanup metadata. Existing retained result files\nshow that order; no rerun or reconstructed journal is used. Those metadata\nstill do not prove every kernel close/writer/delegate/descendant or physical EX\nrelease. Initial private worker error objects/text remain absent. Legacy setup/\nAPI returns are not all saved.\n\nNew cases use actual finite OWN Python/Popen, synthetic unregistered owners/\noperations/callbacks and real Threads. Private ready/release/deadline is not GO\nor an original workload. Root-held instances exist before real initialization\nfor unit cleanup only, never library backfill. Negative source wait markers remain\nFalse/null; normal Auxiliary wait can use cached0 rather than a fresh syscall.\nNo retired-FD reclose, closed-reader EOF reconstruction, live fixture recovery,\nsource retag or exact heap/RSS bound is claimed. Official EX spans known finite\ncontrols; original Linux/root/perf and full instruction closure remain unproved.\n\nFour new post-static Git commands return signed0 with both separate streams at\nEOF: expected branch, HEAD601, twenty untracked helpers and empty tracked\nproduction diff. All20 remain uncommitted, uncanonical and unadmitted;\nproduction601 is unedited. Private controllers stay outside HELPERBUNDLE20.\nController originals precede execution except the failed early JS tool body;\ncopies retained after calls keep their actual order. No source commit/push/\nadoption/strict dispatch or actual SDK/version/bootstrap/compiler/native/\ncanonical/kernel/broker/benchmark/capture occurs.\n\nNext restore the test floor through a separately declared safe OWN resource\npreflight or wait for available space, then execute the targeted corrected\nverification. The old92 NoDeletion plan is terminal and must not resume.\nAny future reclaim needs fresh inactive OWN/protected-hash/receipt/EX declaration;\nprotected evidence, natives, RLIBs, executables and other-task data are excluded.\nNo cleanup is performed. Original public cleanup, historical continuation/log\nsealing, transitive generic FDs, audit partial/unknown actors, shared journals/\nhistorical writers, interpreter/delegate/descendant coverage and the independent\nfull actual officialEX controller remain incomplete. Original PATH/SDK/bootstrap/\nfirst3locks/hiddenconfigs/current20 canonical/new source package/OWN native-driver-\nstatic RLIB/compiler-tool-kernel, actual original-host credentials/access/pidfd/\nFDexec/inheritance/arming/metadata/role/time/coverage and ROOT-qualified immutable\nCOMPLETE admission remain necessary before diagnostic data. No borrowed cohort/\nconfig/native transplant, favorable redo, SDK change or postGO as preproof.\n\nProvider absent, gate always raises, controller closed, ownershipNone, all three\nflagsFalse. No RAM cause/repair or strict acceptance. Assessment free580669440B\nis below1GiB and12GiB; recheck before tests/builds. Cause unmeasured/no cleanup.\nDocumentation publication uses a separately declared bounded administrative\narchive budget and never waives either floor. PR132 stays OPEN DRAFT on130;\nissue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Auxiliary allocation implemented; final verification blocked by storage\n\nPrivate Auxiliary allocation/first-error state precedes intent/lease I/O; exact allocated Popen precedes initializer I/O, preserving argument-copy/None semantics. Partial history remains DATA/quarantined. Initial private AFTER5PASS and matching14=11PASS/3ERROR are separate: two history errors expose an introduced capture-list shadow; the required Fixture caller fails Git setup after a test class allocator mock changes type-call slots. Static source/explicit allocator-seam corrections are retained at221e/89b3, but this final epoch is UNTESTED: free580669440B closes the1GiB test floor and12GiB build floor. Eight targeted checks await a fresh test-floor pass. No floor waiver, cleanup, source adoption or capture;20helpers remain uncommitted/uncanonical/unadmitted and production601 unedited. Full physical EX/original-runtime admission and strict acceptance remain incomplete.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-aux-allocation-implementation-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-aux-allocation-implementation-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-aux-allocation-implementation-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: retain Auxiliary allocation corrections and storage blocker')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['aux_allocation_implementation'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['aux_allocation_implementation_GitHub_descriptions_pending']=True;n['aux_allocation_implementation_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
