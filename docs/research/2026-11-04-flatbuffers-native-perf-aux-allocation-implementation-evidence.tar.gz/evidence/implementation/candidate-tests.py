

class AllocatedAuxiliaryProcessTests(unittest.TestCase):
    """Actual finite Auxiliary capsules; no SDK/canonical/physical closure."""
    def setUp(self):
        self.base=Path(tempfile.mkdtemp(prefix='aux-allocated-',dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.states=[];self.owners=[]
    def run_case(self,mode,observe_history=False):
        import pathlib,types,fcntl,errno,time
        P=self.base;R=Path(producer.__file__).resolve().parent.parent
        source=Path(producer.__file__).read_bytes();h={'tool/native_perf_build_producer.py':digest(source)}
        buffers={'tool/native_perf_build_producer.py':source};sha=digest
        def put(path,value):
            with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
        def identity(st):return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink)
        def native_name(value):return type.__dict__['__name__'].__get__(type(value),type)
        real_class=producer._COMMAND_POPEN_TYPE;real_init=real_class.__init__;real_pipe=os.pipe
        child_code=("import os,time,json,sys\nfrom pathlib import Path\nready,release=map(Path,sys.argv[1:])\n"
          "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_AUX_ALLOC_UNIT')}))\n"
          "deadline=time.monotonic()+8\n"
          "while not release.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
          "raise SystemExit(0 if release.exists() else 78)\n")
        C=P/mode;C.mkdir(mode=0o700);repo=C/'repo';repo.mkdir();run=C/'run';run.mkdir()
        ready=C/'ready.json';release=C/'release'
        argv=[sys.executable,'-c',child_code,str(ready),str(release)]
        environment=dict(os.environ);environment['OWN_AUX_ALLOC_UNIT']=mode
        injected=OSError(5,'OWN AUX fault AFTER real original init') if mode=='oserror' else RuntimeError('OWN AUX fault AFTER real original init')
        state=dict(mode=mode,aux=None,child=None,wait=None,real_init_returned=False,before_init=None,args=None,kwargs=None,foreign_calls=0,init_entered=False,pipe_pairs=[],known_logs=[],public_error=None,start_return=None,unit_wait_observed=False,unit_wait_status=None,repr_hook_calls=0,allocator_calls=0,factory_calls=0)
        self.states.append(state);state['unit_release']=release
        if mode=='repr_hook':
         hook_fault=RuntimeError('OWN old repr hook fault')
         class BadRepr(RuntimeError):
          def __repr__(self):
           state['repr_hook_calls']+=1
           raise hook_fault
         injected=BadRepr('OWN AFTER actual Auxiliary init')
        def foreign_new(cls,*args,**kwargs):
         state['allocator_calls']+=1
         raise RuntimeError('OWN foreign allocator BEFORE native allocation')
        def foreign_factory(*args,**kwargs):
         state['factory_calls']+=1
         raise RuntimeError('OWN foreign factory BEFORE native allocation')
        def own_pipe():
         pair=real_pipe()
         if not state['init_entered'] and len(state['pipe_pairs'])<2:
          rows=[dict(fd=fd,identity=None,access=None) for fd in pair];state['pipe_pairs'].append(rows)
          for row in rows:
           row['identity']=identity(os.fstat(row['fd']));row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
         return pair
        def initializer(instance,*args,**kwargs):
         # Exact object and original callable retained before any real initializer I/O.
         state['child']=instance;state['init_entered']=True;state['args']=args;state['kwargs']=kwargs
         assert len(args)==1 and args[0]==argv
         aux=state['aux'];record=getattr(aux,'_process_allocation',None)
         for stream in aux.streams.values():
          if stream['log'] is not None:state['known_logs'].append(stream['log'])
         state['before_init']=dict(source_record_native=type(record) is dict,
          allocated_reference_present=type(record) is dict and record.get('allocated_process') is instance,
          returned_process_present=aux.process is instance,pending=aux.pending,finished=aux.finished,
          source_argv_tuple=type(aux.argv) is tuple,source_environment_mappingproxy=type(aux.environment) is types.MappingProxyType,
          actual_instance_exact_class=type(instance) is real_class)
         put(C/'before-real-initializer.json',state['before_init'])
         real_init(instance,*args,**kwargs)
         state['real_init_returned']=True;state['wait']=instance.wait
         if mode in ('oserror','runtime','repr_hook'):raise injected
         if mode=='false_return':return False
         return None
        def outer_init(instance,*args,**kwargs):return initializer(instance,*args,**kwargs)
        def foreign_init(instance,*args,**kwargs):
         state['foreign_calls']+=1;state['uninitialized_instance']=instance
         raise RuntimeError('OWN foreign Auxiliary initializer BEFORE real native init')
        name='_aux_allocation_after_'+mode;mod=types.ModuleType(name);mod.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[name]=mod
        try:
         with mock.patch.object(real_class,'__init__',outer_init):
          exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
          aux=object.__new__(mod.AuxiliaryCommand);state['aux']=aux
          actual_dispatch=mod.AuxiliaryCommand._initialize_process
          def dispatch(current,initializer,instance,arguments):
           if mode=='initializer_global_drift':
            saved=mod._COMMAND_POPEN_INIT;mod._COMMAND_POPEN_INIT=foreign_init
            try:return actual_dispatch(current,initializer,instance,arguments)
            finally:mod._COMMAND_POPEN_INIT=saved
           if mode=='initializer_arguments_drift':
            saved_cwd=current.cwd;saved_environment=current.environment
            alternate=C/'alternate-repo';alternate.mkdir()
            current.cwd=alternate;current.environment=types.MappingProxyType({'OWN_AUX_ALLOC_UNIT':'DRIFT'})
            try:return actual_dispatch(current,initializer,instance,arguments)
            finally:current.cwd=saved_cwd;current.environment=saved_environment
           return actual_dispatch(current,initializer,instance,arguments)
          checks=[0]
          def callback():
           checks[0]+=1
           if mode=='ledger_drift' and checks[0]==2:
            state['original_allocation']=aux._process_allocation
            aux._process_allocation=dict(aux._process_allocation)
          mod.AuxiliaryCommand.__init__(aux,directory=run,name='owned-aux',argv=argv,cwd=repo,environment=environment,lease_check=callback,stdout_max=1024**2,stderr_max=1024**2)
          with mock.patch.object(real_class,'__init__',foreign_init if mode=='class_drift' else outer_init), \
               mock.patch.object(real_class,'__new__',foreign_new if mode=='allocator_drift' else real_class.__new__), \
               mock.patch.object(subprocess,'Popen',foreign_factory if mode=='factory_drift' else real_class), \
               mock.patch.object(mod.AuxiliaryCommand,'_initialize_process',dispatch),mock.patch.object(os,'pipe',own_pipe):
           try:state['start_return']=aux.start()
           except BaseException as error:state['public_error']=error
        finally:sys.modules.pop(name)
        child=state['child'];record=getattr(aux,'_process_allocation',None)
        report=dict(mode=mode,source_sha256=h['tool/native_perf_build_producer.py'],actual_real_init_returned=state['real_init_returned'],source_before_init=state['before_init'],
         source_allocated_reference_after=child is not None and type(record) is dict and record.get('allocated_process') is child,
         source_process_is_child=child is not None and aux.process is child,
         source_process_None=aux.process is None,source_pending=aux.pending,source_finished=aux.finished,
         source_status=aux.status,source_natural_wait_before_unit=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status,process_is_child=child is not None and aux._natural_wait_process is child),
         source_result_type=native_name(state['start_return']),public_error_type=None if state['public_error'] is None else native_name(state['public_error']),
         source_spawn_error_is_string=type(aux.spawn_error) is str,foreign_initializer_calls=state['foreign_calls'],
         private_primary_is_injected=aux._allocation_primary_error is injected,private_primary_type=None if aux._allocation_primary_error is None else native_name(aux._allocation_primary_error),
         native_wait_observed=False,native_wait_status=None,unit_FD_cleanup=[],unit_writer_cleanup=[],
         no_original_SDK_kernel_RAM_defect_claim=True,no_source_state_backfill_or_retag=True,
         repr_hook_calls=state['repr_hook_calls'],foreign_allocator_calls=state['allocator_calls'],foreign_factory_calls=state['factory_calls'],
         public_error_is_hook_fault=mode=='repr_hook' and state['public_error'] is hook_fault,
         ledger_original_retained=mode=='ledger_drift' and aux._process_allocation_binding[0] is state.get('original_allocation'))
        state['report']=report
        if state['kwargs'] is not None:
         kw=state['kwargs'];stdout=aux.streams['stdout'];stderr=aux.streams['stderr']
         writers=[rows[1]['fd'] for rows in state['pipe_pairs']]
         report['constructor_arguments']=dict(exact_class=type(child) is real_class,argv_exact=state['args'][0]==argv,
          cwd_exact=kw.get('cwd')==repo,environment_equal=kw.get('env')==environment,
          environment_is_original_start_copy=type(kw.get('env')) is dict and kw.get('env') is not aux.environment and kw.get('env') is not environment,
          stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_writer=len(writers)==2 and kw.get('stdout')==writers[0],
          stderr_original_writer=len(writers)==2 and kw.get('stderr')==writers[1],writers_distinct=len(writers)==2 and writers[0]!=writers[1],close_fds=kw.get('close_fds') is True)
        put(C/'source-after-call-before-unit-wait.json',report)
        if observe_history:
         op=object.__new__(mod.CommandProducer)
         op._command_attempts=[];op._command_attempt=None;op.records=[];op.auxiliary_operations=[aux]
         op.process=None;op.pending=False;op.finished=True;op.lease_check=aux.lease_check
         owner=mod._RetainedPreflightOwner('fixture','e'*32,dict(lease_check=aux.lease_check))
         self.owners.append(owner);owner._operation=op;owner._failed=True;owner._initialized=True
         owner._pending=False;owner._finished=True
         original=RuntimeError('SYNTHETIC failed owner for Auxiliary DATA only')
         owner._first_error_object=original;owner._first_error='RuntimeError'
         owner.freeze_command_history();view=owner.observe(2);rows=owner.command_history_observations()
         report['history_view']=dict(view);report['history_rows']=[dict(row) for row in rows]
         put(C/'history-before-unit-wait.json',dict(view=dict(view),rows=report['history_rows']))

        if state['real_init_returned']:
         until=time.monotonic()+3
         while not ready.exists() and time.monotonic()<until:time.sleep(.005)
         assert ready.exists()
         ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw);report['ready_data']=json.loads(ready_raw)
         assert report['ready_data']==dict(cwd=str(repo),case=mode)
         release.mkdir(mode=0o700)
         status=state['wait'](3);state['unit_wait_observed']=True;state['unit_wait_status']=status
         report['native_wait_observed']=True;report['native_wait_status']=status
         # Save exact SAMEPopen.wait return BEFORE root FD/log cleanup or later source wait API.
         put(C/'actual-wait-before-root-FD-cleanup.json',dict(pid=child.pid,status=status,exact_signed_int=type(status) is int,source_wait_before_unit=report['source_natural_wait_before_unit'],root_early_instance_only_unit_cleanup_not_sourcebackfill=True,not_fresh_syscall_or_physicalclosure_proof=True))
         assert type(status) is int and status==0
         if mode in ('normal','initializer_global_drift','initializer_arguments_drift'):
          # One affected actual Auxiliary caller. Its wait may return cached status0, not fresh syscall proof.
          returned=aux.wait(3);report['normal_source_wait_API_return']=returned
          put(C/'normal-source-wait-API-return.json',dict(returned=returned,natural_wait_observed=aux._natural_wait_observed,natural_wait_status=aux._natural_wait_status,pending=aux.pending,finished=aux.finished))
        elif child is not None:
         put(C/'unknown-real-init-quarantine.json',dict(exact_object_retained=True,status=None,no_invented_zero=True))
         raise AssertionError('unexpected real initializer failure; actual EX must remain with retained state')
        for pair in reversed(state['pipe_pairs']):
         for row in reversed(pair):
          fd=row['fd'];entry=dict(fd=fd,unit_only=True,normal_close_observed=None)
          try:now=os.fstat(fd)
          except OSError as error:
           assert error.errno==errno.EBADF;entry['observed_errno']=error.errno
          else:
           assert identity(now)==tuple(row['identity']) and fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
           if row['access']==os.O_RDONLY:
            pieces=[]
            while True:
             raw=os.read(fd,65536)
             if not raw:break
             pieces.append(raw)
            suffix=b''.join(pieces)
            with (C/('unit-reader-'+str(fd)+'-suffix.bin')).open('xb') as out:out.write(suffix)
            entry.update(actual_reader_EOF=True,size=len(suffix),sha256=sha(suffix))
           entry['close_intent']=True;returned=os.close(fd);entry['normal_close_observed']=returned is None
          report['unit_FD_cleanup'].append(entry)
        seen=[]
        for log in state['known_logs']+[stream['log'] for stream in aux.streams.values()]:
         if log is None or any(log is item for item in seen):continue
         seen.append(log);entry=dict(closed_before_unit_cleanup=log.closed)
         if not log.closed:
          fd=log.fileno();held=os.fstat(fd);assert identity(held)==identity(pathlib.Path(log.name).stat())
          entry['close_intent']=True;returned=log.close();entry['normal_close_return']=returned is None;entry['closed_after']=log.closed
         report['unit_writer_cleanup'].append(entry)
        report['source_natural_wait_after_unit']=dict(observed=aux._natural_wait_observed,status=aux._natural_wait_status)
        for path in sorted(run.iterdir()):
         if path.is_file():
          raw=path.read_bytes()
          with (C/(path.name+'.retained')).open('xb') as out:out.write(raw)
        if mode in ('normal','initializer_global_drift','initializer_arguments_drift'):
         passed=(report['actual_real_init_returned'] and report['native_wait_status']==0 and report['source_process_is_child'] and all(report['constructor_arguments'].values()) and report['normal_source_wait_API_return']['status']=='success')
        elif mode in ('class_drift','allocator_drift','factory_drift'):passed=state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0
        elif mode=='ledger_drift':passed=report['ledger_original_retained'] and not state['real_init_returned'] and not state['pipe_pairs']
        elif mode=='repr_hook':passed=report['source_allocated_reference_after'] and report['private_primary_is_injected'] and report['public_error_is_hook_fault'] and report['repr_hook_calls']==1
        else:
         passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present'] and report['source_allocated_reference_after'] and report['native_wait_status']==0)
        report['expected_property_passed']=passed
        report['declared_boundary_reached']=(not state['pipe_pairs'] and not state['real_init_returned'] if mode=='ledger_drift' else len(state['pipe_pairs'])==2 and ((state['foreign_calls']==state['allocator_calls']==state['factory_calls']==0 and type(record) is dict and record.get('constructor_attempted') is True) if mode in ('class_drift','allocator_drift','factory_drift') else state['real_init_returned']))

        state['unit_cleanup_complete']=True
        put(C/'result.json',report);return report

    def test_retains_before_actual_initializer_then_OSError(self):
        row=self.run_case('oserror')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['source_process_is_child']);self.assertTrue(row['source_finished'])
    def test_retains_before_actual_initializer_then_RuntimeError(self):
        row=self.run_case('runtime')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertFalse(row['source_process_is_child'])
    def test_non_None_initializer_return_preserves_allocated_instance(self):
        row=self.run_case('false_return')
        self.assertTrue(row['expected_property_passed']);self.assertEqual('TypeError',row['private_primary_type'])
        self.assertFalse(row['source_process_is_child'])
    def test_normal_original_arguments_two_writers_and_environment_copies(self):
        row=self.run_case('normal')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(all(row['constructor_arguments'].values()))
        self.assertTrue(row['source_before_init']['allocated_reference_present'])
        self.assertFalse(row['source_before_init']['returned_process_present'])
    def test_initializer_drift_refuses_foreign_hook(self):
        row=self.run_case('class_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_allocator_drift_refuses_foreign_hook(self):
        row=self.run_case('allocator_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_allocator_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_factory_drift_refuses_foreign_hook(self):
        row=self.run_case('factory_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_factory_calls'])
        self.assertIsNone(row['native_wait_status'])
    def test_captured_initializer_survives_late_global_rebind(self):
        row=self.run_case('initializer_global_drift')
        self.assertTrue(row['expected_property_passed']);self.assertEqual(0,row['foreign_initializer_calls'])
        self.assertEqual(0,row['native_wait_status'])
    def test_argument_copies_bind_before_late_initializer_seam(self):
        row=self.run_case('initializer_arguments_drift')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(all(row['constructor_arguments'].values()))
        self.assertEqual('initializer_arguments_drift',row['ready_data']['case'])
    def test_private_first_error_precedes_old_repr_hook_failure(self):
        row=self.run_case('repr_hook')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['private_primary_is_injected'])
        self.assertTrue(row['public_error_is_hook_fault']);self.assertEqual(1,row['repr_hook_calls'])
    def test_replaced_ledger_refuses_before_Popen(self):
        row=self.run_case('ledger_drift')
        self.assertTrue(row['expected_property_passed']);self.assertTrue(row['ledger_original_retained'])
        self.assertIsNone(row['native_wait_status'])
    def test_normal_allocated_Auxiliary_history_remains_DATA_only(self):
        row=self.run_case('normal',True);rows=row['history_rows']
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        auxiliary=next(item for item in rows if item['role']=='auxiliary')
        self.assertTrue(auxiliary['retained_allocated_process']);self.assertEqual(auxiliary['pid'],auxiliary['allocated_pid'])
        self.assertTrue(auxiliary['constructor_returned']);self.assertFalse(auxiliary['start_outcome_unknown'])
        for item in rows:
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(item[flag])
    def test_failed_initializer_allocated_Auxiliary_stays_unknown_DATA(self):
        row=self.run_case('oserror',True);rows=row['history_rows']
        self.assertFalse(rows[0]['snapshot_checked']);self.assertTrue(rows[0]['quarantined'])
        auxiliary=next(item for item in rows if item['role']=='auxiliary')
        self.assertTrue(auxiliary['retained_allocated_process']);self.assertFalse(auxiliary['retained_process'])
        self.assertIs(type(auxiliary['allocated_pid']),int);self.assertIsNone(auxiliary['allocated_cached_returncode'])
        self.assertTrue(auxiliary['start_outcome_unknown']);self.assertFalse(auxiliary['initializer_returned'])
    def tearDown(self):
        rows=[]
        for owner in self.owners:
            thread=owner._thread
            if thread is not None:
                returned=thread.join(3)
                rows.append(dict(kind='known_unit_thread',join_return_None=returned is None,alive=thread.is_alive()))
                self.assertFalse(thread.is_alive())
        for state in self.states:
            if state.get('real_init_returned'):
                if state.get('unit_wait_observed'):
                    status=state['unit_wait_status'];origin='already_recorded_actual_unit_wait'
                else:
                    gate=state.get('unit_release')
                    if gate is not None and not gate.exists():gate.mkdir(mode=0o700)
                    status=state['wait'](3);origin='actual_unit_teardown_wait'
                rows.append(dict(kind=origin,pid=state['child'].pid,status=status,not_library_witness=True))
                self.assertEqual(0,status)
        with (self.base/'unit-final-teardown.json').open('x') as out:json.dump(rows,out,indent=2)
