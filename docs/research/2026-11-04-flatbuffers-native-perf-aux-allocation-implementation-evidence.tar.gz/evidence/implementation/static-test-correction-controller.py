import sys,pathlib,json,ast,hashlib,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,v):
  with path.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 expected=json.loads((P/'matching-source-hashes.json').read_text());expected['tool/native_perf_build_producer.py']='221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd'
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in expected.items())
 assert os.statvfs(R).f_bavail*os.statvfs(R).f_frsize>=16*1024**2
 path=R/'tool/test_native_perf_build_producer.py';s=path.read_text();tree=ast.parse(s);c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AllocatedAuxiliaryProcessTests');part=ast.get_source_segment(s,c)
 old="mock.patch.object(real_class,'__new__',foreign_new if mode=='allocator_drift' else real_class.__new__)"
 assert part.count(old)==1;newpart=part.replace(old,"mock.patch.object(mod,'_COMMAND_POPEN_NEW',foreign_new if mode=='allocator_drift' else mod._COMMAND_POPEN_NEW)",1)
 target=next(line for line in newpart.splitlines() if "report['history_view']=dict(view);report['history_rows']" in line)
 indent=target[:len(target)-len(target.lstrip())]
 extra=["private=owner._history_primary_error","report['history_private_error_type']=None if private is None else native_name(private)","frames=[]","if private is not None:","    tb=BaseException.__dict__['__traceback__'].__get__(private,BaseException)","    while tb is not None:","        frames.append(dict(file=tb.tb_frame.f_code.co_filename,line=tb.tb_lineno,function=tb.tb_frame.f_code.co_name));tb=tb.tb_next","report['history_private_error_frames']=frames"]
 newpart=newpart.replace(target,target+'\n'+'\n'.join(indent+line for line in extra),1)
 assert s.count(part)==1;s=s.replace(part,newpart,1);ast.parse(s);path.write_text(s)
 hashes={}
 for rel in expected:
  raw=(R/rel).read_bytes();target=P/'corrected-unverified-source23'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(raw)
  hashes[rel]=sha(raw)
 put(P/'corrected-unverified-hashes.json',hashes)
 put(P/'static-corrections-receipt.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),initial14=dict(passed=11,errors=3,failures=0),test_floor_refused_before_any_new_source_test_mutation_or_actor=True,source_then_static_controller_renames_capture_shadow_binding=True,static_history_indent_assertion_AFTER_sourcewrite_BEFORE_testwrite=True,source_at_partial_assertion='221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd',test_at_partial_assertion=expected['tool/test_native_perf_build_producer.py'],test_selector_and_seam_correction_now_AST_scoped_to_newclass=True,no_tests_or_native_actors_requested=True,corrected_epoch_UNTESTED=True,private_worker_error_object_text_initially_absent_not_reconstructed=True,source_bug_static_inference='Aux local binding assignment overwrites outer capture list used by hold closure; next allocated-Popen hold calls tuple.append',test_bug='global class __new__ mock changes typecall slot; allocatornegative now capsule constant only',no_Python_SDK_version_or_argv_cause_inferred=True,source_small_edit_floor_only_bytes=16777216,test_floor_unchanged_bytes=1073741824,hashes=hashes))
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(checkpoint.read_text());n=v['native_perf_only_diagnostic_design'];n['aux_allocation_implementation'].update(source_sha256=hashes['tool/native_perf_build_producer.py'],test_sha256=hashes['tool/test_native_perf_build_producer.py'],source_corrections_applied=True,source_corrections_pending=False,corrected_epoch_UNTESTED_due_testfloor=True,static_corrections_receipt=str(P/'static-corrections-receipt.json'),new_source_verification_pending=True);n['current_helper_source_epoch']=dict(producer_sha256=hashes['tool/native_perf_build_producer.py'],test_sha256=hashes['tool/test_native_perf_build_producer.py'],hashes_file=str(P/'corrected-unverified-hashes.json'),all20_untracked_uncommitted_uncanonical_unadmitted=True,production601_unedited=True,phase='STATIC corrected Auxiliary source/test epoch UNTESTED because1GiB floor closed');checkpoint.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source=hashes['tool/native_perf_build_producer.py'],test=hashes['tool/test_native_perf_build_producer.py'],tests_requested=False)))
