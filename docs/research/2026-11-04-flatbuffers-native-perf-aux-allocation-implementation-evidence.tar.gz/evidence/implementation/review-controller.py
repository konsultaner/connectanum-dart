import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');D=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation-review');D.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');h=json.loads((P/'corrected-unverified-hashes.json').read_text())
 raw=(R/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==h['tool/native_perf_build_producer.py']
 s=raw.decode();classes={n.name:n for n in ast.parse(s).body if isinstance(n,ast.ClassDef)}
 selected='\n\n'.join(ast.get_source_segment(s,n) for n in classes['AuxiliaryCommand'].body if isinstance(n,ast.FunctionDef) and n.name in ('__init__','start','_allocation_record','_retain_allocation_error','_initialize_process','_allocate_process'))
 capture=ast.get_source_segment(s,next(n for n in classes['_RetainedPreflightOwner'].body if isinstance(n,ast.FunctionDef) and n.name=='_capture_command_history'))
 selected+='\n\nCapture outer binding=[]; hold(value) closure appends to that LIST. Auxiliary loop now uses distinct allocation_binding (previous local binding shadow caused tuple.append path). Snapshot references/data only, no polling/wait/FD I/O.\n'+capture[capture.index("        for index,(aux,aux_data)"):]
 context='NEW selected Auxiliary allocation implementation221eeb/test89c586 staticcorrections UNTESTED:1GiB testfloor closed (observed659MB); no test/build floorwaiver. ConsumedBEFORE5=4FAIL1PASS; initialchangedsource d5f0 privateAFTER5PASS; sourceunits14=11PASS3ERROR (2emptyhistory rows from workererror not serialized, one requiredFixtureGitsetupPopenTypeError). ROOT static finds capture closure binding LIST overwritten by Aux binding TUPLE then process()->hold()->append; renamed local allocation_binding. Original private workererror objects/text NOT reconstructed. Unit class __new__ patch changes typecall slots; remove all nativeclassallocator mutation, allocatornegative onlycapsuleconstant, realpositive unchanged. No SDK/Pythonversion/argv blame or probes. Targetedverification pending floor; source/testAST only sincefix. Exact allocatedref beforeinit, originalstartcopies and arguments beforeallocator, None-onlyreturn; old process/pending onlynormalreturn. Private firsterror BEFOREoldrepr/_defer/cleanup, sameerror secondary occurrence allowed/noerrorhooks. Original public cleanup/close/_complete/publish UNCHANGED/incomplete/maymask-closecopies; not repaired or releaseproof. Auxiliary DATA retains partial allocatedactor/unknown start and quarantines; ordinarysuccessvalid. All3flagsFalse/providerABSENT/gateclosed/no canonical/adoption/capture/nativeproof. Bounded bindings NOTatomic/globalABA/auth; no unknownFDclose/retry/cancel/GCdiscard/SDKchange. Review max1 concrete NEW code-supported defect/max180words; no physicalclosure or fullcurrent-source approval. ROOT verifies.\n\n'+selected
 assert len(context)<19000
 def put(name,v):
  with (D/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 put('declaration.json',dict(scope='NEW selected corrected Auxiliary code static review only, verification pending storagefloor',hashes=h,no_SDK_canonical_capture=True))
 (D/'context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','1800','--max-input-chars','19000','--max-response-chars','8500','--timeout','180','--save-output',str(D/'review.txt'),'--prompt','Selected NEW Auxiliary methods and DATA loop only, max1 concrete source defect/max180words. No unchangedrepeat/fullsource/physicalrelease approval.']
 put('command-before.json',dict(argv=argv,chars=len(context),sha256=hashlib.sha256(context.encode()).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);put('started.json',dict(pid=child.pid))
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (D/(label+'.bin')).open('xb') as f:f.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-8500:])
