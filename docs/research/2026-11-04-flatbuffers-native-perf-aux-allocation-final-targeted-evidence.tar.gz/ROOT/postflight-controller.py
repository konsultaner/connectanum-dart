import sys,pathlib,json,hashlib,subprocess,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-final-targeted');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');A=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();calls=[]
 def command(argv):
  row=dict(argv=argv,pid=None,status=None,stdout_eof=False,stderr_eof=False);calls.append(row)
  process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=process.pid
  stdout,stderr=process.communicate();row['status']=process.wait()
  for label,b in [('stdout',stdout),('stderr',stderr)]:
   with (P/(str(len(calls)-1)+'-'+label+'.bin')).open('xb') as f:f.write(b)
   row[label+'_eof']=True;row[label+'_sha256']=hashlib.sha256(b).hexdigest();row[label+'_size']=len(b)
  with (P/'postflight-command-progress.json').open('w') as f:json.dump(calls,f,indent=2)
  assert row['status']==0,(argv,stderr[:300])
  return stdout
 head=command(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()
 branch=command(['git','-C',str(R),'branch','--show-current']).decode().strip()
 status=command(['git','-C',str(R),'status','--porcelain=v1','--untracked-files=all']).decode()
 production=command(['git','-C',str(R),'diff','--exit-code','HEAD','--','packages','native'])
 expected=json.loads((A/'final-unverified-hashes.json').read_text());assert all(hashlib.sha256((R/rel).read_bytes()).hexdigest()==sha for rel,sha in expected.items())
 helpers={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in status.splitlines()) and {line[3:] for line in status.splitlines()}==helpers and not production
 result=json.loads((A/'final-targeted-tests.json').read_text());assert result['tests']==8 and result['failures']==result['errors']==0
 inventory=[]
 for root,dirs,files in os.walk(A/'final-targeted-fixtures',followlinks=False):
  for name in files:
   path=pathlib.Path(root,name)
   if path.is_symlink():continue
   st=path.stat();inventory.append(dict(path=str(path.relative_to(A)),size=st.st_size))
 with (P/'new-fixture-inventory.json').open('x') as f:json.dump(inventory,f,indent=2)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),selected_tests=8,failures=0,errors=0,outer_signed_status=0,source_sha256=expected,source_unchanged_after_selection=True,HEAD=head,branch=branch,status20_untracked=True,production_diff_empty=True,four_new_Git_commands_natural_status0_both_streams_consumed=True,fixture_regular_files=len(inventory),scope='separate current221e/89b3 eight finite OWN unit/Fixture checks; no fullfinal13/current20canonical/SDK/compiler/native/benchmark/capture/admission',actual_official_EX_for_known_finite_test_controller=True,limitations=['Required legacy Fixture setup/actor/FD/API returns are not all systematically serialized; no reconstruction or whole physical closure claim.','Actual Fixture uses tinyGit and shell version SHIMS/finite Python/synthetic output, not SDK/bootstrap/compiler/canonical/native/workload.','Unit known-SAMEactor waits, FD cleanup, field restoration and frozen DATA are never live recovery/EX release/admission.','No new model/full-current-source approval; prior ROOT final-source/AST qualification plus source unchanged and these selected checks only.'])
 with (P/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2);f.write('\n')
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(cp.read_text());n=v['native_perf_only_diagnostic_design']
 n['aux_allocation_final_targeted_verification']=dict(path=str(P),assessment=str(P/'assessment.json'),result=str(A/'final-targeted-tests.json'),selected8_PASS=True,outer_status=0,source_epoch='221e/89b3',no_fullfinal13_or_canonical_claim=True,publication_pending=True)
 n['current_helper_source_epoch'].update(final_epoch_UNTESTED=False,verification_scope='Separate final-targeted eight affected OWN finite unit/Fixture checks PASS, not fullfinal13/current20canonical/admission',latest_postflight=str(P/'assessment.json'))
 n['aux_allocation_implementation'].update(final_epoch_UNTESTED=False,verification_deferred_testfloor=False,final_targeted_selected_tests=8,final_targeted_failures=0,final_targeted_errors=0,full_final13_or_canonical=False)
 v['active_turn_status']='Auxiliary221e_89b3_separate_final_targeted8_PASS_uncanonical_unadmitted_quarantine_UNIMPLEMENTED'
 cp.write_text(json.dumps(v,indent=2)+'\n');lease.verify_identity();print(json.dumps({k:assessment[k] for k in ['selected_tests','failures','errors','HEAD','branch','fixture_regular_files']}))
