import sys,pathlib,json,hashlib,tarfile,io,gzip,subprocess,datetime,os,stat
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-final-targeted');A=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-implementation');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();commands=[]
 def git(*args):
  child=subprocess.Popen(['git','-C',str(D),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait()
  commands.append(dict(argv=['git','-C',str(D),*args],pid=child.pid,status=status,stdout=out.decode(),stderr=err.decode(),stdout_eof=True,stderr_eof=True))
  with (P/'publication-commands.json').open('w') as f:json.dump(commands,f,indent=2)
  assert status==0,(args,err[:300])
  return out.decode().strip()
 assert git('branch','--show-current')=='codex/flatbuffers-acceptance-status' and not git('status','--porcelain')
 base=git('rev-parse','HEAD');assessment=json.loads((P/'assessment.json').read_text())
 selected=[]
 for path in P.iterdir():
  if path.is_file() and not path.is_symlink() and path.name!='publication-commands.json':selected.append(('ROOT/'+path.name,path))
 for name in ['final-targeted-source','final-targeted-fixtures']:
  for root,dirs,files in os.walk(A/name,followlinks=False):
   for fn in files:
    path=pathlib.Path(root,fn)
    if not path.is_symlink():selected.append(('selected/'+str(path.relative_to(A)),path))
 for name in ['final-targeted-controller.py','final-targeted-execution-declaration.json','final-targeted-hashes.json','final-targeted-tests.json','final-targeted-tests.log','final-unverified-hashes.json']:
  selected.append(('selected/'+name,A/name))
 selected.sort();manifest=[];payload=[]
 for name,path in selected:
  before=path.stat();data=path.read_bytes();after=path.stat()
  assert stat.S_ISREG(before.st_mode) and (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
  manifest.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()));payload.append((name,data))
 prefix='docs/research/2026-11-04-flatbuffers-native-perf-aux-allocation-final-targeted'
 archive=D/(prefix+'-evidence.tar.gz')
 with archive.open('xb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tf:
    for name,data in payload:
     item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o600;item.mtime=0;tf.addfile(item,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(manifest)
  for member,expected in zip(members,manifest):
   assert member.isfile() and member.name==expected['path'];data=tf.extractfile(member).read()
   assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256']
 archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
 public=dict(assessment,evidence_archive_sha256=archive_sha,evidence_regular_members=len(manifest),all_selected_regular_members_byteexact=True,manifest=manifest,prior_tests_not_repeated_or_combined=True)
 with (D/(prefix+'-assessment.json')).open('x') as f:json.dump(public,f,indent=2);f.write('\n')
 note='''# Final Auxiliary allocation targeted verification — 2026-11-04

The eight previously prepared affected checks pass at producer221eeb04012ffcbed10b0a2023895e852d1609121abe45f2eaf004fcefe02dfd/test89b36b7eb786ff3e1b2496c76232ee23fb1f512863bbaa877ec6bba8f8fc49b8:8 tests,0 failures,0 errors. The actual coordinator returned signed0. The official exclusive lease and a fresh1GiB storage check preceded execution; storage had been reopened by the separately user-authorized lossless cleanup.

The selection checks the corrected Auxiliary history capture, failed initializer DATA, the actual Fixture receipt caller, Auxiliary allocator refusal and argument/two-writer/environment-copy preservation, the explicitly migrated Direct allocator seam and normal constructor caller, and the affected two-command frozen history caller. Earlier separate passing selections were not repeated or combined. This is not a full-final13/current20canonical result.

All23 selected helper/bin file hashes remain byteexact after execution. Four new source Git reads each returned0 with both streams consumed: branch native-perf-guard/HEAD601, exactly20 untracked helper files, empty production packages/native diff. These are source/Git DATA, not compiled or loaded native instruction proof. No source branch commit/push/adoption, SDK/compiler/native build, canonical verification, kernel/broker/benchmark/capture or strict dispatch occurred.

Fixtures use finite OWN Python processes/Threads, synthetic callbacks and the existing tinyGit/six shell-version SHIMS/synthetic output/Fixture receipt path. The actual Fixture caller is not an SDK/bootstrap/compiler/native/canonical run. Known SAMEactor unit waits, FD cleanup and restored fields never authorize live recovery, physical EX release or admission. Required legacy setup/actor/FD/API returns were not all systematically serialized; no missing observation is reconstructed. Frozen history is DATA and not a heap/RSS bound. Prior source/AST ROOT qualification plus unchanged hashes and this selected run do not become model full-current-source approval.

The archived new stage retains the23 selected sources, selected fixture regular files, raw result/log, execution declaration/controller, actual outer tool return and new postflight source/Git receipts. Every selected regular member was read back byteexact. No old archive, completed campaign or model/control was rerun. The Auxiliary uncertainty quarantine design remains unimplemented; next work needs genuinely new meaningful real BEFORE regressions and a minimal behavior change, followed by matching AFTER/affected callers. Existing emit/freeze/auxiliary gates stay fixed. Full independent physical EX coverage, original-runtime provenance/admission and strict48/50 acceptance remain incomplete. PR132 remains open/draft.

[Assessment and exact manifest](2026-11-04-flatbuffers-native-perf-aux-allocation-final-targeted-assessment.json), [new selected evidence](2026-11-04-flatbuffers-native-perf-aux-allocation-final-targeted-evidence.tar.gz).
'''
 with (D/(prefix+'-preparation.md')).open('x') as f:f.write(note)
 block='''## 2026-11-04 — Eight final-source targeted allocation checks pass

The prepared affected selection at unchanged221e/89b3 passes8/0failures/0errors; actual coordinator signed0. It covers the corrected Auxiliary history/allocator paths, required actual Fixture receipt caller, explicitly migrated Direct seam and two-command frozen-history caller. Earlier separate selections were not repeated or combined; this is not full-final13/current20canonical or original-runtime admission. All23 helper/bin hashes remain unchanged; four new source Git reads return0/BOTH streams, branch601/20untracked/productiondiffempty DATA only.

Storage floors are open after the separate user-authorized lossless cleanup. No SDK/native build/canonical/kernel/broker/benchmark/capture or source adoption/strict dispatch occurred. The Auxiliary constructor-uncertainty quarantine design remains unimplemented; genuinely new meaningful real BEFORE regressions and minimal fix/AFTER are next. Physical EX/original-runtime provenance/strict acceptance remain incomplete.

'''
 for name,link in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  file=D/name;text=file.read_text();i=text.index('## 2026-11-04 — User-requested lossless')
  refs='[Selection and limits]('+link+pathlib.Path(prefix+'-preparation.md').name+'), [assessment]('+link+pathlib.Path(prefix+'-assessment.json').name+'), [evidence]('+link+pathlib.Path(prefix+'-evidence.tar.gz').name+').\n\n'
  file.write_text(text[:i]+block+refs+text[i:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 git('diff','--check');git('add','--',*paths);git('commit','-m','docs: record eight final allocation checks');head=git('rev-parse','HEAD');git('push','origin','codex/flatbuffers-acceptance-status');assert not git('status','--porcelain')
 result=dict(docs_commit=head,previous_docs_commit=base,evidence_archive_sha256=archive_sha,selected_regular_members=len(manifest),all_selected_regular_members_byteexact=True,DOCS_ONLY=True,source_unchanged=True)
 with (P/'root-readback.json').open('x') as f:json.dump(result,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(cp.read_text());n=v['native_perf_only_diagnostic_design'];n['aux_allocation_final_targeted_verification'].update(publication_pending=False,ROOT_readback=str(P/'root-readback.json'),docs_commit=head,evidence_archive_sha256=archive_sha,selected_regular_members=len(manifest));cp.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(result))
