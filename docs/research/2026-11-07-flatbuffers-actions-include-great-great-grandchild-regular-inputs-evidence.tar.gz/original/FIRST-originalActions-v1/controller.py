import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)



import subprocess,base64,time,datetime,zipfile,io,os,shutil,stat
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-regular-inputs-v1';S=P/'FIRST-local-static-binding-v1';A=P/'FIRST-originalActions-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();A.mkdir()
 def save(n,b):
  with (A/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 inputs=[('collector',S/'collector-bound-PRIVATE',14622722,'35f18374649bde94ded2fff22b0f2747e4758ebb7974541d307aa0ddcec03a7e'),('workflow',S/'workflow-bound-PRIVATE',485969,'5096d225c3d1114a1a3409eb69cda7802f0bd68586ff255e6b3a79f1d16fec2e'),('NEW2279scope',S/'NEW2279scope-bound-PRIVATE',6409181,'601d18c6047db53f7159d16a9748ced542b69b89cf5b3b6da1e47c004e1a471c'),('original_validation',S/'original_new_validation-bound-PRIVATE',9625,'50c78bccefb41b1ac9bb793c0321271fb97860f8934381f2765c01ad7b67fd57'),('original36PASS',S/'original36-condition-PASS-BYTEEXACT-NOT-reevaluated.json',8546,'e6050839ca8ed8d07d340581854e2abe4ccdc1dc00d61b9a9995909e44afc871')]
 declaration={'scope':v['declaration_scope'],'exact_saved_inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':sha} for r,p,n,sha in inputs],'exact_static_expected_metadata':{'path':str(S/'FIRST-NEW2279-static-report-field-bindings-PRIVATE.json'),'range':'pointFDsize declaredBEFOREcontentIO'},'actual_bound_newjob_metadata':{'path':str(S/'FIRST-newjob-collector-uploader-bindings.json'),'range':'pointFDsize declaredBEFOREcontentIO'},'parent_commit_record':{'path':str(B/'2026-11-07-actions-include-great-great-grandchild-directory-inputs-v1/FIRST-originalActions-v1/FIRST-new199-commit.stdout'),'range':'pointFDsize declaredBEFOREcontentIO','expected_commit':'c4b4e6b2d7bce853d008b9c91cccb811088ad6ed'},'all_admission_flags':False,'ownership':None}
 save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-source-static-context.json',json.dumps(v,ensure_ascii=True,indent=2));save('ROOT-review-qualification.md',v['ROOT_review_qualification']);free=shutil.disk_usage(A).free;save('fresh-before-preflight-floor.json',json.dumps({'free_bytes':free,'required_bytes':1073741824,'not_build_authority':True}));assert free>=1073741824;bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw


 raws={}
 for role,path,size,sha0 in inputs:
  data=read_bounded(path,size,sha0,role);raws[role]=data;save(role+'-bound-PRIVATE',data)
 staticraw=read_bounded(S/'FIRST-NEW2279-static-report-field-bindings-PRIVATE.json',None,None,'NEW54staticbindings');save('original-static54-bindings-bound-PRIVATE.json',staticraw);static=json.loads(staticraw);expected=static['expected_static_report_fields'];assert len(expected)==54 and len(expected['source_regular_references'])==2279
 jobraw=read_bounded(S/'FIRST-newjob-collector-uploader-bindings.json',None,None,'actual_NEW2279_newjob_metadata');save('original-newjob-bindings-bound-PRIVATE.json',jobraw);newjob=json.loads(jobraw);assert newjob['declared_regularfile_stdin_NOTidenticalFDtopology'] is True
 parentpath=B/'2026-11-07-actions-include-great-great-grandchild-directory-inputs-v1/FIRST-originalActions-v1/FIRST-new199-commit.stdout';parentraw=read_bounded(parentpath,None,None,'actual_parent_commit_record');save('original-parent-commit-record-bound-PRIVATE.json',parentraw);parentrecord=json.loads(parentraw);parent='c4b4e6b2d7bce853d008b9c91cccb811088ad6ed';assert parentrecord['sha']==parent;save('ALL-eight-source-input-bindings-PRIVATE.json',json.dumps(bindings,indent=2))
 source=raws['workflow'];collector=raws['collector'];scoped=raws['NEW2279scope'];scope=json.loads(scoped);validation=json.loads(raws['original_validation']);conditions=json.loads(raws['original36PASS'])
 assert validation==v['source_validation'] and validation['ALL36_old_jobs_unchanged'] and validation['whole_original_workflow_reverse_projection_BYTEEXACT'] and validation['whole_original_collector_reverse_projection_BYTEEXACT'] and validation['ALL_original_metadata_functions_guards_fields_preserved'] and validation['all_original1199_1229_4868_guards_separate_before_NEW2279_loader_before_INPUTIO'] and validation['whole_scope_BYTEEXACT_UTF8JSONSTRING_PythonALLfield_equality'] and validation['whole_runtime_ledger_BYTEEXACT_UTF8JSONSTRING_PythonALLfield_equality'] and validation['ALL36oldconditions_SOURCE_false_BEFOREdispatch'] and validation['parsed_jobs']==33
 assert len(conditions)==36 and all(r['NEW_dispatch_SOURCE_false_NOT_actualskip'] is True for r in conditions);save('original36-PASS-byteexact-reuse-NOTreevaluated.json',raws['original36PASS'])
 assert expected['NEW_ALL2279_great_great_grandchild_regular_input_scope']==scope and expected['NEW_great_great_grandchild_scope_exact_JSON_bytes']==len(scoped) and expected['NEW_great_great_grandchild_scope_exact_JSON_sha256']==hashlib.sha256(scoped).hexdigest()
 assert v['static_binding_summary']['saved_input_read_bindings']==7 and v['static_binding_summary']['expected_static_report_field_count']==54 and v['static_binding_summary']['first_newjob_static_binding_completion']['signed_status']==0
 children=[]
 def native(label,args):
  save(label+'-request.json',json.dumps({'argv':args,'cwd':str(A)},indent=2));p=subprocess.Popen(args,cwd=A,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(p);save(label+'-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_IO':True},indent=2));o,e=p.communicate();status=p.wait();save(label+'.stdout',o);save(label+'.stderr',e);r={'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(o),'stderr_bytes':len(e),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_sha256':hashlib.sha256(e).hexdigest()};save(label+'-completion.json',json.dumps(r,indent=2));print(json.dumps({'label':label,**r}),flush=True);assert status==0;return o
 def api(label,method,endpoint,body=None,object_media=False):
  args=['gh','api','--hostname','github.com','--method',method,endpoint]
  if object_media:args+=['-H','Accept: application/vnd.github.object+json']
  if body is not None:save(label+'-body.json',json.dumps(body,ensure_ascii=True,indent=2));args+=['--input',str(A/(label+'-body.json'))]
  return native(label,args)
 repo='repos/konsultaner/connectanum-dart';branch='codex/pr132-actions-include-great-great-grandchild-regular-inputs-20261107';path='.github/workflows/wamp-profile-benchmarks.yml';cpth='.github/collectors/pr132_include_great_great_grandchild_regular_inputs.py';campaign='flatbuffers_include_great_great_grandchild_regular_inputs'
 blobs={}
 for label,fpath,data in [('workflow',path,source),('collector',cpth,collector)]:
  created=json.loads(api('FIRST-new2279-'+label+'-Gitblob-create','POST',repo+'/git/blobs',{'content':data.decode(),'encoding':'utf-8'}));gitsha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert created['sha']==gitsha;blobs[label]={'path':fpath,'sha':gitsha,'data':data}
 entries=[{'path':row['path'],'mode':'100644','type':'blob','sha':row['sha']} for row in blobs.values()]
 t=json.loads(api('FIRST-new2279-atomic-TWOfile-tree','POST',repo+'/git/trees',{'base_tree':parentrecord['tree']['sha'],'tree':entries}))
 committed=json.loads(api('FIRST-new2279-commit','POST',repo+'/git/commits',{'message':'Declare all2279 include great-great-grandchild regular body inputs [skip ci]','tree':t['sha'],'parents':[parent]}));sha=committed['sha'];assert [x['sha'] for x in committed['parents']]==[parent] and committed['tree']['sha']==t['sha']
 made=json.loads(api('FIRST-new2279-branch','POST',repo+'/git/refs',{'ref':'refs/heads/'+branch,'sha':sha}));assert made['object']['sha']==sha
 fullreadbacks=[]
 for label,row in blobs.items():
  located=json.loads(api('FIRST-new2279-'+label+'-commit-path-metadata-ONLYlocator','GET',repo+'/contents/'+row['path']+'?ref='+sha,object_media=True));assert located['type']=='file' and located['path']==row['path'] and located['size']==len(row['data']) and located['sha']==row['sha']
  blob=json.loads(api('FIRST-new2279-'+label+'-FULL-Gitblob-JSON-readback','GET',repo+'/git/blobs/'+located['sha']));assert blob['sha']==row['sha'] and blob['encoding']=='base64' and blob['size']==len(row['data'])
  assert isinstance(blob['content'],str) and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\r\n' for c in blob['content']);decoded=base64.b64decode(blob['content']);assert decoded==row['data'] and len(decoded)==len(row['data']) and hashlib.sha256(decoded).hexdigest()==hashlib.sha256(row['data']).hexdigest();save('FIRST-new2279-'+label+'-FULL-byteexact-readback',decoded)
  fullreadbacks.append({'path':row['path'],'git_blob_sha':row['sha'],'bytes':len(decoded),'sha256':hashlib.sha256(decoded).hexdigest(),'explicit_new_commit_filepath_metadata_ONLYlocator':True,'FULL_Gitblob_JSON_base64_decoded_byteexact_BEFOREdispatch':True,'metadata_body_field_NOT_content_proof':True,'contents_metadata_encoding_POINT_ONLY':located.get('encoding'),'contents_metadata_content_characters_POINT_ONLY':len(located.get('content',''))})
 save('source-publication-receipt.json',json.dumps({'source_commit':sha,'parent':parent,'branch':branch,'atomic_TWOfile_tree':entries,'BOTH_full_byteexact_readbacks_BEFOREdispatch':fullreadbacks,'ALL36oldconditions_PASSraw_reused_BYTEEXACT_NOT_reevaluated':True,'original_static54_bindings_consumed_NOT_reextracted':True,'all_admission_flags':False,'ownership':None},indent=2))
 api('FIRST-dispatch-only-NEW2279-great-great-grandchild-regular-inputs','POST',repo+'/actions/workflows/265291183/dispatches',{'ref':branch,'inputs':{'campaign':campaign}})
 run=None
 for i in range(8):
  rows=json.loads(api('FIRST-discover-NEW2279-run-'+str(i),'GET',repo+'/actions/workflows/265291183/runs?branch='+branch+'&event=workflow_dispatch&per_page=5'))['workflow_runs'];found=[x for x in rows if x['head_sha']==sha];assert len(found)<=1
  if found:run=found[0];break
  time.sleep(5)
 assert run is not None,'Unknown dispatch outcome terminal/no redispatch';rid=run['id'];save('actual-new-run-identity.json',json.dumps(run,indent=2));print(json.dumps({'new_run':rid,'source_commit':sha}),flush=True)
 cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-watch.json',before);d=json.loads(before);node=d['actions_include_great_great_grandchild_regular_inputs_v1'];node.update(phase='NEW_ALL2279_source_dispatched_ONCE_originalwatch_pending_NOT_admitted',source_commit=sha,parent_source=parent,branch=branch,run_id=rid,raw_directory=str(A),all_admission_flags=False)
 d['active_turn_status'].update(new_include_great_great_grandchild_regular_inputs='NEWoriginalActions2279_watch_pending',source_commit=sha,run_id=rid,all_admission_flags=False,RAM_repair_FINAL_strict48_50_cleanCI='INCOMPLETE');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 native('FIRST-watch-only-NEW2279-run',['gh','run','watch',str(rid),'--repo','konsultaner/connectanum-dart','--exit-status','--interval','10'])
 final=json.loads(api('FIRST-new2279-final','GET',repo+'/actions/runs/'+str(rid)));assert final['status']=='completed' and final['conclusion']=='success'
 jobs=json.loads(api('FIRST-new2279-jobs','GET',repo+'/actions/runs/'+str(rid)+'/jobs?per_page=100'))['jobs'];target=[x for x in jobs if x['name']=='FlatBuffers include great-great-grandchild regular inputs (no execution)'];assert len(target)==1 and target[0]['conclusion']=='success';jid=target[0]['id'];assert len(jobs)==37 and all(x['conclusion']=='skipped' for x in jobs if x['id']!=jid)
 log=api('FIRST-new2279-job-log','GET',repo+'/actions/jobs/'+str(jid)+'/logs');arts=json.loads(api('FIRST-new2279-artifact-list','GET',repo+'/actions/runs/'+str(rid)+'/artifacts?per_page=100'))['artifacts'];assert len(arts)==1;art=arts[0];rawzip=api('FIRST-new2279-artifact-zip','GET',repo+'/actions/artifacts/'+str(art['id'])+'/zip');zsha=hashlib.sha256(rawzip).hexdigest();assert len(rawzip)==art['size_in_bytes']
 if art.get('digest'):assert art['digest']=='sha256:'+zsha
 Z=zipfile.ZipFile(io.BytesIO(rawzip));infos=Z.infolist();assert len(infos)==len(set(x.filename for x in infos));destroot=A/'artifact-members';destroot.mkdir();index=[]
 for info in infos:
  name=pathlib.PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts
  if info.is_dir():continue
  data=Z.read(info);dest=destroot/info.filename;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
  index.append({'name':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 save('actual-new-artifact-member-index.json',json.dumps(index,indent=2))
 def member(basename):
  found=[x for x in index if pathlib.PurePosixPath(x['name']).name==basename];assert len(found)==1
  return found[0],(destroot/found[0]['name']).read_bytes()
 rm,reportraw=member('include-great-great-grandchild-regular-inputs.json');report=json.loads(reportraw);assert report['workflow_revision']==sha and str(report['run_id'])==str(rid)
 for key,value in expected.items():assert report[key]==value,key
 refs=scope['ALL2279_new_literal_regular_BODYINPUT_references'];assert [r['source_reference'] for r in report['observations']]==refs and len(refs)==2279 and report['remaining_known_input_output_FDs']==[] and report['all_admission_flags'] is False;assert 'ownership' not in report
 sm,sraw=member('NEW-great-great-grandchild-scope-BEFORE-INPUT-IO.json');assert sraw==scoped and sraw.decode()==scoped.decode() and json.loads(sraw)==scope
 jm,jraw=member('operations.jsonl');events=[json.loads(line) for line in jraw.splitlines() if line];writes=[x for x in events if x.get('operation')=='report_bytes_written'];assert len(writes)==1 and writes[0]['bytes']==len(reportraw) and writes[0]['sha256']==hashlib.sha256(reportraw).hexdigest()
 scopeevents=[x for x in events if x.get('operation')=='NEW_scope_output_open_return_BEFORE_INPUT'];assert len(scopeevents)==1 and scopeevents[0]['bytes']==len(scoped) and scopeevents[0]['sha256']==hashlib.sha256(scoped).hexdigest()
 present=[];absent=[];matched=[];total=0
 for ordinal,row in enumerate(report['observations']):
  assert row['ordinal']==ordinal
  if 'absent_at_open_only' in row:assert 'saved_member' not in row;absent.append(row['source_reference']);continue
  assert row['source_fd_before']==row['source_fd_after'] and row['bytes']==row['source_fd_before']['size'] and row['same_saved_output_FD_stream_matches'] is True
  mr=[x for x in index if pathlib.PurePosixPath(x['name']).name==row['saved_member']];assert len(mr)==1 and mr[0]['bytes']==row['bytes'] and mr[0]['sha256']==row['sha256']
  saved_events=[x for x in events if x.get('operation')=='input_stream_saved' and x.get('source')==row['source_reference']];assert len(saved_events)==1 and saved_events[0]['bytes']==row['bytes'] and saved_events[0]['sha256']==row['sha256']
  present.append(row['source_reference']);total+=row['bytes'];matched.append({'source_reference':row['source_reference'],'saved_member':mr[0]['name'],'bytes':row['bytes'],'sha256':row['sha256'],'saved_stream_independently_matches_ONCE':True})
 assert len(present)+len(absent)==2279 and report['regular_source_INPUT_body_opens']==len(present) and report['regular_source_INPUT_hashes']==len(present)
 for key in ['entry_symlink_target_follows','recursive_walks','directory_queries','collector_child_executions','native_information_queries','candidate_executions','environment_mutations']:assert report[key]==0
 result={'source_commit':sha,'parent_source':parent,'branch':branch,'run_id':rid,'run_url':run['html_url'],'job_id':jid,'job_conclusion':'success','ALL36_previous_jobs':'skipped_not_rerun','parsed_and_actual_jobs':37,'artifact_id':art['id'],'artifact_bytes':len(rawzip),'artifact_sha256':zsha,'job_log_bytes':len(log),'job_log_sha256':hashlib.sha256(log).hexdigest(),'report_bytes':len(reportraw),'report_sha256':hashlib.sha256(reportraw).hexdigest(),'present_regular_streams':len(present),'absent_at_open_only':absent,'total_new_regular_stream_bytes':total,'ALL2279_source_refs':refs,'ALL2279_new_stream_bindings':matched,'NEW_ALL2279_exact_public_safe_scope':scope,'ALL_preserved_static_report_fields':expected,'ALL2279_original_observations_PRIVATE':report['observations'],'new_runtime_facts_SEPARATE_NOT_preproof_retrofill':{k:report[k] for k in v['static_binding_summary']['pending_runtime_field_names']},'immutable_original_preproof_runtime_values_UNMEASURED':None,'new_source_validation':validation,'ROOT_review_qualification':v['ROOT_review_qualification'],'all_new_saved_body_interiors_UNINSPECTED':True,'entry_symlink_target_follows':0,'recursive_walks':0,'directory_queries':0,'collector_child_executions':0,'native_information_queries':0,'candidate_executions':0,'environment_mutations':0,'remaining_known_input_output_FDs':[],'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':report['qualification'],'original_report_ownership_field_PRESENT':False,'policy_ownership_UNADMITTED':None}
 rawresult=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-NEW-ALL2279-regular-great-great-grandchild-input-assessment-PRIVATE.json',rawresult);rawcp=cp.read_bytes();save('checkpoint-before-acquisition-result.json',rawcp);d=json.loads(rawcp);d['actions_include_great_great_grandchild_regular_inputs_v1'].update(phase='COMPLETE_CONSUMED_FIRST_ORIGINAL_Actions_ALL2279_regular_great_great_grandchild_INPUTS_NOT_admitted',raw_directory=str(A),source_commit=sha,run_id=rid,job_id=jid,original_saved_result=str(A/'ROOT-NEW-ALL2279-regular-great-great-grandchild-input-assessment-PRIVATE.json'),original_saved_result_bytes=len(rawresult),original_saved_result_sha256=hashlib.sha256(rawresult).hexdigest(),present_regular_streams=len(present),absent_at_open_only=absent,total_new_regular_stream_bytes=total,artifact_id=art['id'],artifact_bytes=len(rawzip),artifact_sha256=zsha,report_bytes=len(reportraw),report_sha256=hashlib.sha256(reportraw).hexdigest(),public_documentation_pending=True,model_review_pending=False,all_admission_flags=False);d['active_turn_status'].update(new_include_great_great_grandchild_regular_inputs='COMPLETE_CONSUMED_publication_pending',next='FIRST ALL2279originalActions regularstreams acquired/matchedONCE/bodyinteriorsUNINSPECTED. FIRSTnew savedresult summary-publication only/no oldquery-source-parser-model-Actionsacquisition-archive-numerical replay/Source20-runtimeadoption-build-cleanup. Current7STATICbindings54fields10UNMEASUREDpreproofimmutable/newruntimefactsSEPARATE/36PASSrawBYTEEXACTreuse/parsed33STALE-SOURCE36new37vsactual37NOTadmission. OriginalregularreportownershipABSENT/policyNoneUNADMITTED/notSourcefieldrestore/oldownershipKeyErrornamespaceFOREVERterminal-oldfinalresultNULL-firstRemainingProofONCE. All2279newphysicalepoch separate from2308metadata199epochs29dirsDEFERRED0NEWlinks/older5067metadata190epochs199DEFERRED0NEWlinks/4868physical-localread/prior6and18linksunfollowed-oldncursesrawhexNULL/allledgers unchanged. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 descriptor={k:result[k] for k in ['source_commit','parent_source','branch','run_id','run_url','job_id','ALL36_previous_jobs','parsed_and_actual_jobs','artifact_id','artifact_bytes','artifact_sha256','job_log_bytes','job_log_sha256','report_bytes','report_sha256','present_regular_streams','absent_at_open_only','total_new_regular_stream_bytes','all_admission_flags','ownership']};descriptor.update(result_saved='ROOT-NEW-ALL2279-regular-great-great-grandchild-input-assessment-PRIVATE.json',result_bytes=len(rawresult),result_sha256=hashlib.sha256(rawresult).hexdigest());save('original-saved-result-descriptor.json',json.dumps(descriptor,indent=2));print(json.dumps(descriptor),flush=True);lease.verify_identity()
