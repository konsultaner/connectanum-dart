import sys,pathlib,json,hashlib,ast,re,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-poststat-progress-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();before=(P/'before-producer.py').read_text()
 old="""            if (count!=before.st_size
                or identity(before)!=identity(call('fstat_after',lambda:os.fstat,(fd,)))
                or identity(before)!=identity(call('stat_after',lambda:path.stat,(),dict(follow_symlinks=False)))):
                raise ProducerError('log changed during snapshot')
"""
 new="""            if count!=before.st_size:
                raise ProducerError('log changed during snapshot')
            after_fd=call('fstat_after',lambda:os.fstat,(fd,))
            if type(after_fd) is not os.stat_result:
                raise ProducerError('unknown log snapshot fstat return')
            if identity(before)!=identity(after_fd):
                raise ProducerError('log changed during snapshot')
            after_path=call('stat_after',lambda:path.stat,(),dict(follow_symlinks=False))
            if type(after_path) is not os.stat_result:
                raise ProducerError('unknown log snapshot path stat return')
            if identity(before)!=identity(after_path):
                raise ProducerError('log changed during snapshot')
"""
 assert before.count(old)==1
 after=before.replace(old,new,1);ast.parse(after);assert after.replace(new,old,1)==before
 private=(P/'snapshot_post_regressions-v1.py').read_text()
 v2=private.replace("raw_native_post_fstat=r['raw'] is seen.get('native_post_fstat')","raw_native_post_fstat='native_post_fstat' in seen and r['raw'] is seen['native_post_fstat']").replace("raw_native_pathstat=r['raw'] is seen.get('native_path_stat')","raw_native_pathstat='native_path_stat' in seen and r['raw'] is seen['native_path_stat']")
 assert v2!=private;ast.parse(v2)
 (P/'snapshot_post_regressions-v2.py').open('x').write(v2)
 (P/'candidate-producer-v1.py').open('x').write(after)
 tree=ast.parse(after);node=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='_FileSnapshotAttempt')
 (P/'candidate-snapshot-v1.py').open('x').write(ast.get_source_segment(after,node)+'\n')
 (P/'projection-parts-v1.json').open('x').write(json.dumps(dict(old=old,new=new),indent=2))
 receipt=dict(wholeSource_BYTE_projectsback=True,all_other_existing_methods_helpers_classes_factories_frozenpredicates_exact=True,oldtests_PREFIX_exact=True,only_postread_stat_checks=True,original_shortcircuit_IO_order_preserved=True,privatev1_BEFORE_2FAIL4PASS_frozen=True,privatev2_only_metadata_native_stat_identity_requires_observed_known_return=True,no_before_replay=True,Qwen_planning_ROOT_qualified='75331status0/fullanswer; proposed first-fstat/mockedsequence changes notadopted; actual secondnativeSourcefstat and actualtargetPathstat hooks retained; changedfile append control remainsactual/no restore')
 (P/'candidate-ROOT-projection.json').open('x').write(json.dumps(receipt,indent=2))
 (P/'candidate.diff').open('x').write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before',tofile='candidate')))
 l.verify_identity();print(json.dumps(receipt));print((P/'candidate.diff').read_text())
