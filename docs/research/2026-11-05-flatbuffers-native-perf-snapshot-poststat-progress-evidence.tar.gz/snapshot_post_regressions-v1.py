"""NEW snapshot post-read native FD/path stat controls."""
import os
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class SnapshotPostStatTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_POSTSTAT_FIXTURES']);self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root));self.path=self.base/'poststat-input.bin';self.body=b'POSTSTAT-control-bytes'
        with self.path.open('xb') as output:output.write(self.body)

    def _case(self,mode):
        native_os=producer.os;native_stat=type(self.path).stat;calls=[];fds=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT poststat first')
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs);info=native_os.fstat(raw);fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)));calls.append(dict(kind='native_open_return',fd=raw,flags=flags));return raw
            def fstat(self,fd):
                raw=native_os.fstat(fd);calls.append(dict(kind='native_Source_fstat_return',size=raw.st_size));n=sum(x['kind']=='native_Source_fstat_return' for x in calls)
                if n==2:
                    seen['native_post_fstat']=raw
                    if mode=='fstat_None':return None
                    if mode=='fstat_unknown':raise first
                    if mode=='changed':
                        calls.append(dict(kind='ROOT_append_attempt',beforeopen=True));writer=self_outer.path.open('ab');seen['append_writer']=writer
                        info=native_os.fstat(writer.fileno());seen['append_identity']=(info.st_dev,info.st_ino);count=writer.write(b'!');flushed=writer.flush();closed=writer.close()
                        calls.append(dict(kind='ROOT_append_return',count=count,flush_None=flushed is None,close_None=closed is None,closed=writer.closed))
                return raw
            def read(self,fd,size):
                raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw)));return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt'));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None));return raw
        self_outer=self
        def stat(path,*args,**kwargs):
            raw=native_stat(path,*args,**kwargs)
            if path==self.path:
                seen['native_path_stat']=raw;calls.append(dict(kind='native_target_Pathstat_return',size=raw.st_size,follow_symlinks=kwargs.get('follow_symlinks'),positional_args=len(args)))
                if mode=='path_None':return None
                if mode=='path_unknown':raise first
            return raw
        returned=False;result=None;received=None;guard_error=None;attempt=None
        try:
            before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(type(self.path),'stat',stat):
                try:result=producer._file_snapshot(self.path);returned=True
                except BaseException as error:received=error
            attempt=producer._FILE_SNAPSHOT_ATTEMPTS[before:][-1]
            if mode!='normal':
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=attempt.steps
            view=dict(mode=mode,snapshot_poststat_control=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,pure_guard_same_received=received is not None and guard_error is received,Source_first_received=attempt.first_error is received,
                Source_completed=attempt.completed,Source_close_returned=attempt.close_returned,ROOT_native_post_fstat_known='native_post_fstat' in seen,ROOT_native_path_stat_known='native_path_stat' in seen,
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_native_post_fstat=r['raw'] is seen.get('native_post_fstat'),raw_native_pathstat=r['raw'] is seen.get('native_path_stat'),error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='DirectOWNfile/modulelocalos/nativefstat counts Sourceonly; actualPathclass.stat wrapper targetsuniqueOWNpath/delegatesoriginalargs/restoredafteroneSourcecall (no Sourcefieldrestore). ROOTactualFD/devino beforefault/knownsameopenFDcleanupAFTERevidence only/no borrowedclosedreclose. KnownNone TRUE vsunknownNoneFalse neverROOTknownstatfilled; actualchangedfile appendnotrestored. ZEROchild/DarwinEXNone UNITnotSourcecleanup-fullEX-originalLinux-allFD-interpreter-descendantclosure-ownership-admission. RawchunksUNCHANGED/NOTfixedmemory/heapRSS-timing-causeUNMEASURED.')
            (self.base/'input-after.bin').write_bytes(self.path.read_bytes());(self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable']);self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags'])
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned);self.assertEqual(dict(size=len(self.body),sha256=hashlib.sha256(self.body).hexdigest()),result)
                self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls));self.assertEqual(2,sum(x['kind']=='native_Source_fstat_return' for x in calls))
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed);self.assertFalse(attempt.close_returned)
                self.assertFalse(any(x['kind'] in ('Source_close_attempt','repr_first','note_first') for x in calls));self.assertFalse(any(r['stage']=='hexdigest' for r in rows))
                last=rows[-1]
                if mode.endswith('unknown'):
                    self.assertTrue(received is first);self.assertFalse(last['returned']);self.assertIsNone(last['raw']);self.assertTrue(last['error'] is first)
                else:self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(last['returned'])
                if mode.startswith('fstat'):
                    self.assertEqual('fstat_after',last['stage']);self.assertTrue('native_post_fstat' in seen);self.assertFalse(any(x['kind']=='native_target_Pathstat_return' for x in calls))
                else:self.assertEqual('stat_after',last['stage']);self.assertTrue('native_path_stat' in seen)
                if mode.endswith('None'):self.assertIsNone(last['raw'])
                if mode=='changed':
                    self.assertEqual(self.body+b'!',self.path.read_bytes());self.assertTrue(last['raw'] is seen['native_path_stat']);self.assertTrue(seen['append_writer'].closed)
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('poststat pure guard returned')
                self.assertEqual(count,len(calls))
            for row in calls:
                if row['kind']=='native_target_Pathstat_return':self.assertTrue(row['follow_symlinks'] is False);self.assertEqual(0,row['positional_args'])
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);path=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(path.st_dev,path.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_native_postread_fstat_then_None_refuses_known_invalid_stat(self):self._case('fstat_None')
    def test_native_pathstat_then_None_refuses_known_invalid_stat(self):self._case('path_None')
    def test_native_postread_fstat_then_first_keeps_unknown_stat(self):self._case('fstat_unknown')
    def test_native_pathstat_then_first_keeps_unknown_stat(self):self._case('path_unknown')
    def test_actual_appended_OWNfile_is_refused_without_restoration(self):self._case('changed')
    def test_new_normal_poststat_file_preserves_native_sha_order(self):self._case('normal')
