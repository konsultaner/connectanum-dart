import sys,pathlib,json,hashlib,ast,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-poststat-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert source==(P/'candidate-producer-v1.py').read_bytes();assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'snapshot_post_regressions-v2.py').read_bytes()
 parts=json.loads((P/'projection-parts-v1.json').read_text());assert source.decode().replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 v1=(P/'snapshot_post_regressions-v1.py').read_text();v2=(P/'snapshot_post_regressions-v2.py').read_text()
 assert v2.replace("raw_native_post_fstat='native_post_fstat' in seen and r['raw'] is seen['native_post_fstat']","raw_native_post_fstat=r['raw'] is seen.get('native_post_fstat')").replace("raw_native_pathstat='native_path_stat' in seen and r['raw'] is seen['native_path_stat']","raw_native_pathstat=r['raw'] is seen.get('native_path_stat')")==v1
 projection=json.loads((P/'candidate-ROOT-projection.json').read_text());assert projection['wholeSource_BYTE_projectsback'] and projection['oldtests_PREFIX_exact']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(6,2,4,0);assert(a['tests'],a['failures'],a['errors'])==(40,0,0)
 assert len(b['leases'])==12 and len(a['leases'])==80 and all(x['raw_None'] for x in b['leases']+a['leases'])
 def views(path,key):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if key in v}
 old=views(P/'before-units/fixtures','snapshot_poststat_control');new=views(P/'after-selected/fixtures','snapshot_poststat_control')
 prior1=views(P/'after-selected/fixtures','waitless_direct_snapshot');prior2=views(P/'after-selected/fixtures','snapshot_open_stat_control');prior3=views(P/'after-selected/fixtures','snapshot_hash_control');end=views(P/'after-selected/fixtures','record_original_command')
 assert len(old)==len(new)==6 and len(prior1)==len(prior2)==5 and len(prior3)==6 and len(end)==8
 for mode in ('fstat_None','path_None'):
  v=old[mode][0];assert v['received_type']=='AttributeError' and v['Source_steps'][-1]['returned'] and v['Source_steps'][-1]['raw_None'] and v['pure_guard_same_received']
 cleanup={}
 for phase,data,count in [('before',old,5),('after-new',new,5),('after-prior-snapshot',prior1,3),('after-prior-openstat',prior2,4),('after-prior-hash',prior3,5)]:
  rows=[x for v,d in data.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text())];assert len(rows)==len(data) and sum(x['ROOT_close'] for x in rows)==count
  assert all(x['evidence_ready'] and (not x['ROOT_close'] or x['original_FD_path_identity_match']) for x in rows);cleanup[phase]=rows
 for mode,(v,d) in new.items():
  assert v['ROOT_native_post_fstat_known'] and len(v['ROOT_fds'])==1 and v['ROOT_fds'][0]['inheritable'] is False
  calls=v['calls'];rows=v['Source_steps']
  if mode=='normal':
   assert v['Source_returned'] and v['Source_completed'] and v['Source_close_returned'] and v['result']==dict(size=22,sha256=hashlib.sha256(b'POSTSTAT-control-bytes').hexdigest())
   assert [x['stage'] for x in rows]==['path','open','fstat_before','getuid','hash_ctor','read','hash_update','read','fstat_after','stat_after','hexdigest','close']
  else:
   assert not v['Source_returned'] and v['pure_guard_same_received'] and v['Source_first_received'] and not v['Source_completed'] and not v['Source_close_returned']
   assert not any(x['kind'] in ('Source_close_attempt','repr_first','note_first') for x in calls)
   assert not any(x['stage']=='hexdigest' for x in rows);row=rows[-1]
   if mode.endswith('unknown'):assert v['received_first'] and not row['returned'] and row['raw_None'] and row['error_first']
   else:assert v['received_type']=='ProducerError' and row['returned']
   if mode.endswith('None'):assert row['raw_None'] and not row['raw_native_post_fstat'] and not row['raw_native_pathstat']
   if mode.startswith('fstat'):
    assert row['stage']=='fstat_after' and not v['ROOT_native_path_stat_known'] and not any(x['kind']=='native_target_Pathstat_return' for x in calls)
   else:assert row['stage']=='stat_after' and v['ROOT_native_path_stat_known']
   if mode=='changed':
    assert (d/'input-after.bin').read_bytes()==b'POSTSTAT-control-bytes!'
    assert [x['size'] for x in calls if x['kind']=='native_Source_fstat_return']==[22,22]
    assert [x['size'] for x in calls if x['kind']=='native_target_Pathstat_return']==[23]
    assert row['raw_native_pathstat']
  for x in calls:
   if x['kind']=='native_target_Pathstat_return':assert x['follow_symlinks'] is False and x['positional_args']==0
 waits=[x for v,d in end.values() for x in json.loads((d/'ROOT-unit-cleanup.json').read_text()) if x.get('kind')=='ROOT_same_original_bound_wait'];assert len(waits)==8 and sorted(x['status'] for x in waits)==[0]*7+[3]
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]};assert all(x['status']==0 and x['both_separate_EOF'] for x in models.values());assert all((P/d/'answer.txt').exists() for d in ('test-planning','candidate-review'))
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=6,failures=2,passes=4,errors=0,scope='2knownpostreadstatshape refusal/classificationpolicies NOT2nativekernelbugs/RAMcause'),after=a,ROOT=dict(**projection,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_direct_views=12,new_child_actors=0,affected_snapshot_direct_views=16,affected_end_views=8,affected_same_originalboundwaits=waits,parent_BEFORE_EXverify_None=12,parent_AFTER_EXverify_None=80,known_directFD_cleanup=cleanup),models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True,corrections=json.loads((P/'model-ROOT-corrections.json').read_text())),limits=json.loads("[\"ONLY_FileSnapshotAttempt.run post-read stat-shape checks: exact os.stat_result for fstat_after BEFORE identity fields/Pathstat, exact os.stat_result for stat_after BEFORE identity fields/digest/close. KnownNone rowTRUE/rawNone retained; no ROOT-known native stat substitution. Unknownnative-completed-thenFirst rowNoneFalse/first/pureguard unchanged. Original count mismatch and fstat identity mismatch shortcircuit subsequent nativeIO; native flags/read/update/fstat/Pathstat/digest/close order preserved. Immutable native stat_result before-field reads move across returned call; bindings/callee-interior/ABA are not proved.\",\"NEW6 BEFORE958c4b/e9cc2a=2FAIL4PASS0ERROR: native second Sourcefstat/stat_result thenROOTNone and native targetPathstat thenROOTNone produced AttributeError; two known-shape refusal/classification policies, NOT two spontaneous native kernel bugs/RAM cause. Two distinct unknownstat-completion controls, actual1Bappend changed-file refusal and distinct normal22B/fullnativeSHA-size alreadyPASS. Final99d39c/dfd8e9 selected40PASS=6matchingNEW+34affected(16previoussnapshot8end10actualwaitcallers); no old16 BEFORE/model-numericalreplay/aggregate-current20canonical/admission.\",\"Module-local producer.os facade; ROOTsetup nativefstat is outside Source second-fstat count. Actual Pathclass.stat bounded wrapper delegates original args/kwargs for all paths and faults only uniqueOWN target, restored after oneSourcecall; no Pathconstructor/sorted/mockstat-result or globalos mutation. Actual targetPathstat receives follow_symlinks=False/zero positionalargs. During changed control ROOTappends1B after actualsecondnativefstat returns insideROOT but before Source wrapper returns; actual Pathstat sees22->23B/changedmetadata, file is retained changed/no restoration. Native stat identity/FD integers DATA not semantic authentication/atomicABA/ownership/admission.\",\"Five newnegative modes use only pureguard after refusal/no Sourceclose-repr-note-nextIO-retry-replay-restore/reset. SourceknownNone TRUE vsunknownNoneFalse neverROOTknownstatfilled. ROOTactualOWNFD/devino/flags/inheritableFalse retained BEFOREfault; ROOTsameopenFDclose AFTERevidence/assertions only. NormalSourcealreadyclosed/no reclose-borrowedFD. Retainedclosed-or-open fields/helpercompleted facts do not establish ownership_complete/go_close_confirmed/EXrelease/runtimeadmission.\",\"12newdirectviews=6BEFORE6AFTER/ZEROnewchild plus16priorSnapshotdirectviews and8endviews separate. Parent12BEFORE80AFTER officialCURRENTDarwinEXverifyNone UNITnotfull independentEX-originalLinuxcredentials/allactorclosure. ROOTnewdirectFDclose5BEFORE5AFTER AFTERevidence/devino;16priorRootclose12separate;8endROOTsameoriginalboundwait10 signed7zero1three/cachedpossible finiteUNITnotSourcecleanup/liveownership/fullFD-interpreter-delegate-descendantclosure. Setup/internalFD/APIreturnsnotallserialized/no reconstruction-globalPIDscan-kill-globalabsence-fullreap.\",\"Qwen75331=0/1456stdout397stderr andGLM76552=0/1572stdout594stderr, fullanswers/BOTH separateEOF/reaped/ROOTqualified NOTwholecurrentapproval. RejectQwen first-fstat/mockedsequence substitution; actual declared secondfstat/Pathstat controls retained. GLM identity-preserving content/ABA concern remainsUNPROVED; do not add anotherhash/replay/restore. GLM lambda-call theory rejected by inherited_step lookup then boundmethod(*args,**kwargs); explicitfollow_symlinksFalse assertion alreadyexists. Correct modelLinux wording to observedDarwin UNIT, not originalLinux/fullEX.\",\"Candidatev1 unexecuted beforeedit; privatev1 firstBEFOREfrozen/privatev2 beforecandidate-review/edit/firstAFTER only fixes2 raw-native-stat identity view predicates to require observed knownreturn. V1 None-is-missing.get(None) metadata can mislabel absentstat asnative; no oldviewrewrite orBEFOREreplay/ROOTknownadoption. Behaviorassertions exact; existingwholeoldtestPREFIXexact/newv2append. WholeSourceBYTEprojectback/allotherexistingmethodsclasseshelpersfactoriesfrozenpredicates exact/other18helpers3bins/23hashes/fourNEWGit0-BOTH/601ownbranch20untracked-productionempty DATA; controllers beforecalls/availableactualAPI retained, notallsetupAPI serialized.\",\"Rawreadrows/hashupdateargs chunkretention UNCHANGED/processlifetime/NOTfixedmemory streaming. Default16GiB logicalfilelimit NOTheapRSSbound; heapRSS magnitude/growth/timing/leakcauseUNMEASURED/no memorybound-RAMrepair-trim-pop-reset-evict-deleteauthority. Direct22B/23Bnormal-mutation files andaffectedfixturelogs notbenchmarkfreshbodies/SDK/Dartbroker evidence. OriginalSDK/GC/worker/body/window/sample/ownership/gates untouched.\",\"All20uncommitteduncanonicalunadmitted/production601exact. EarlierSnapshotconstructor-registration/metadata-globalbindings-hashfactory/getuid-returnshape/statcontents-calleeinterior-ABA/otherAPIs/enclosing-publicunknownCtor/historical-transitive/full independent actualofficialEX+originalruntimeimmutableCOMPLETEadmission INCOMPLETE. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement. ProviderABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/no Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; PR132OPENdraft#130/issue103milestoneOPEN. Storagefloors/recheck DATA notbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.\"]"),storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());state['native_perf_only_diagnostic_design']['producer_snapshot_poststat_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,ROOT_pending=False,docs_pending=True);state['active_turn_status']='Producer_snapshot_poststat_selected40PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(state,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected40PASS=True,direct_views=12,new_child_actors=0,affected_snapshot_views=16,affected_end_views=8,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
