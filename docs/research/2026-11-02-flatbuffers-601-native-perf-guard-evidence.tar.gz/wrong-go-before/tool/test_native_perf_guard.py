from __future__ import annotations

import errno
import json
import os
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from native_perf_guard import (
    ArmingGate, FrozenLaunch, GuardError, PipeChannel, PipeIdentity, ProcessInstance, parse_process_stat,
)


class ProcessWitnessTests(unittest.TestCase):
    def test_stat_comm_spaces_and_closing_parentheses(self):
        fields = ["S", "23", *(["0"] * 17), "987", "0", "0"]
        result = parse_process_stat("77 (a ) strange ) name) " + " ".join(fields))
        self.assertEqual((result.pid, result.parent_pid, result.start_ticks), (77, 23, 987))

    def test_incomplete_stat_is_rejected(self):
        for value in ("77 a b", "77 (name) S 23", "0 (name) " + "0 " * 25):
            with self.subTest(value=value), self.assertRaises(GuardError):
                parse_process_stat(value)

    def test_invalid_process_identity_is_rejected(self):
        for change in ({"pid": True}, {"start_ticks": 0}, {"effective_uid": -1},
                       {"executable_sha256": "x" * 64}):
            with self.subTest(change=change), self.assertRaises(GuardError):
                ProcessInstance(**{**dict(pid=10, start_ticks=20, executable_sha256="a" * 64,
                                          effective_uid=1000, effective_gid=1000), **change})

    def test_mutable_or_duplicate_launch_policy_is_refused(self):
        for argv, environment in [(["driver"], ()), (("driver",), {"key": "value"}),
                                  (("driver",), (("key", "one"), ("key", "two")))]:
            with self.subTest(argv=argv, environment=environment), self.assertRaises(GuardError):
                FrozenLaunch(argv, environment, 1000, 1000)


@unittest.skipUnless(os.name == "posix", "POSIX pipe/marker guards")
class ArmingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.fds = []
        self.control = self.pipe()
        self.ack = self.pipe()
        self.go = self.pipe()
        self.stdout = self.pipe()
        self.sampler = ProcessInstance(10, 100, "a" * 64, 0, 0)
        self.wrapper = ProcessInstance(20, 200, "b" * 64, 1000, 1000)
        self.argv = ("/owned/http_stream", "--router-worker-counts", "1")
        self.env = {"CONNECTANUM_BENCH_WAMP_REUSE_WORKER": "1", "PRIVATE_TEST": "secret-value"}
        self.policy = FrozenLaunch.freeze(self.argv, self.env, 1000, 1000)
        self.gate = ArmingGate(self.sampler, self.wrapper,
                               PipeChannel.from_fds(*self.control),
                               PipeChannel.from_fds(*self.ack), self.policy, "c" * 64, "d" * 32)
        self.addCleanup(self.close_fds)

    def pipe(self):
        pair = os.pipe()
        self.fds.extend(pair)
        return pair

    def close_fds(self):
        for fd in self.fds:
            os.close(fd)

    def blocked(self):
        self.gate.blocked(self.wrapper, frozenset({PipeIdentity.from_fd(self.stdout[1])}))

    def armed(self):
        self.blocked()
        self.assertEqual(self.gate.request_enable(self.sampler), b"enable\n")
        self.gate.acknowledge(PipeIdentity.from_fd(self.ack[0]), b"ack\n", self.sampler)

    def consumed(self):
        self.armed()
        return self.gate.consume(self.directory)

    def assert_no_go(self):
        os.set_blocking(self.go[0], False)
        with self.assertRaises(BlockingIOError):
            os.read(self.go[0], 200)

    def test_real_pipe_token_only_after_arm_and_durable_consumption(self):
        self.blocked()
        self.assert_no_go()
        self.gate.request_enable(self.sampler)
        self.assert_no_go()
        self.gate.acknowledge(PipeIdentity.from_fd(self.ack[0]), b"ack\n", self.sampler)
        self.assert_no_go()
        marker = self.gate.consume(self.directory)
        self.assertEqual(json.loads(marker.read_bytes())["declaration_sha256"], "c" * 64)
        self.assert_no_go()
        self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env)
        self.assertEqual(os.read(self.go[0], 200), ("c" * 64 + ":" + "d" * 32 + "\n").encode())
        self.assertEqual(self.gate.state, "released")

    def test_workload_stdout_cannot_spoof_ack(self):
        self.blocked()
        self.gate.request_enable(self.sampler)
        with self.assertRaises(GuardError):
            self.gate.acknowledge(PipeIdentity.from_fd(self.stdout[0]), b"ack\n", self.sampler)
        self.assertEqual(self.gate.state, "failed")
        with self.assertRaises(GuardError):
            self.gate.acknowledge(PipeIdentity.from_fd(self.ack[0]), b"ack\n", self.sampler)
        self.assert_no_go()

    def test_inherited_sampler_ack_pipe_refuses_wrapper(self):
        with self.assertRaises(GuardError):
            self.gate.blocked(self.wrapper, frozenset({PipeIdentity.from_fd(self.ack[1])}))
        self.assert_no_go()

    def test_inherited_sampler_control_pipe_refuses_wrapper(self):
        with self.assertRaises(GuardError):
            self.gate.blocked(self.wrapper, frozenset({PipeIdentity.from_fd(self.control[1])}))
        self.assert_no_go()

    def test_pipe_creator_pair_records_both_endpoints(self):
        channel = PipeChannel.from_fds(*self.ack)
        self.assertIn(PipeIdentity.from_fd(self.ack[0]), channel.identities)
        self.assertIn(PipeIdentity.from_fd(self.ack[1]), channel.identities)
        with self.assertRaises(GuardError):
            PipeChannel.from_fds(self.ack[1], self.ack[0])

    def test_root_driver_is_refused_even_when_sampler_is_root(self):
        root_wrapper = replace(self.wrapper, effective_uid=0, effective_gid=0)
        gate = ArmingGate(self.sampler, root_wrapper, PipeChannel.from_fds(*self.control),
                         PipeChannel.from_fds(*self.ack), self.policy, "c" * 64, "d" * 32)
        with self.assertRaisesRegex(GuardError, "credentials"):
            gate.blocked(root_wrapper, frozenset())
        self.assertEqual(gate.state, "failed")

    def test_pid_reuse_starttime_mismatch_refuses_release(self):
        self.consumed()
        with self.assertRaisesRegex(GuardError, "wrapper instance"):
            self.gate.release(self.go[1], self.sampler, replace(self.wrapper, start_ticks=201),
                              self.argv, self.env)
        self.assert_no_go()

    def test_sampler_exec_image_change_refuses_ack(self):
        self.blocked()
        self.gate.request_enable(self.sampler)
        with self.assertRaisesRegex(GuardError, "sampler instance"):
            self.gate.acknowledge(PipeIdentity.from_fd(self.ack[0]), b"ack\n",
                                  replace(self.sampler, executable_sha256="e" * 64))
        self.assert_no_go()

    def test_ack_before_enable_is_permanently_refused(self):
        self.blocked()
        with self.assertRaises(GuardError):
            self.gate.acknowledge(PipeIdentity.from_fd(self.ack[0]), b"ack\n", self.sampler)
        with self.assertRaises(GuardError):
            self.gate.request_enable(self.sampler)

    def test_release_without_consumed_marker_is_refused(self):
        self.armed()
        with self.assertRaises(GuardError):
            self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env)
        self.assert_no_go()

    def test_changed_argv_refuses_release(self):
        self.consumed()
        with self.assertRaisesRegex(GuardError, "argv"):
            self.gate.release(self.go[1], self.sampler, self.wrapper, (*self.argv[:-1], "2"), self.env)
        self.assert_no_go()

    def test_wrong_go_pipe_is_refused(self):
        self.consumed()
        with self.assertRaisesRegex(GuardError, "release channel"):
            self.gate.release(self.stdout[1], self.sampler, self.wrapper, self.argv, self.env)
        self.assert_no_go()

    def test_injected_vm_flags_refuse_without_exposing_environment(self):
        self.consumed()
        with self.assertRaises(GuardError) as raised:
            self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv,
                              {**self.env, "DART_VM_OPTIONS": "--profiler"})
        self.assertNotIn("secret-value", str(raised.exception))
        self.assert_no_go()

    def test_mutating_input_environment_does_not_change_frozen_policy(self):
        self.env["DART_VM_OPTIONS"] = "--profiler"
        with self.assertRaisesRegex(GuardError, "environment"):
            self.policy.validate(self.argv, self.env, self.wrapper)

    def test_existing_marker_is_not_overwritten(self):
        marker = self.directory / "capture-consumed.json"
        marker.write_bytes(b"original evidence")
        self.armed()
        with self.assertRaises(FileExistsError):
            self.gate.consume(self.directory)
        self.assertEqual(marker.read_bytes(), b"original evidence")
        self.assertEqual(self.gate.state, "failed")
        self.assert_no_go()

    def test_symlink_marker_is_not_followed(self):
        target = self.directory / "protected"
        target.write_bytes(b"unchanged")
        (self.directory / "capture-consumed.json").symlink_to(target)
        self.armed()
        with self.assertRaises(OSError):
            self.gate.consume(self.directory)
        self.assertEqual(target.read_bytes(), b"unchanged")
        self.assert_no_go()

    def test_partial_marker_on_injected_enospc_is_preserved(self):
        calls = 0

        def writer(fd, data):
            nonlocal calls
            calls += 1
            if calls == 1:
                return os.write(fd, data[:9])
            raise OSError(errno.ENOSPC, "injected writer fault")

        self.armed()
        with self.assertRaises(OSError):
            self.gate.consume(self.directory, writer=writer)
        marker = self.directory / "capture-consumed.json"
        self.assertEqual(len(marker.read_bytes()), 9)
        self.assertEqual(self.gate.state, "failed")
        with self.assertRaises(GuardError):
            self.gate.consume(self.directory)
        self.assertEqual(len(marker.read_bytes()), 9)
        self.assert_no_go()

    def test_short_marker_writes_complete_without_losing_bytes(self):
        self.armed()
        marker = self.gate.consume(self.directory, writer=lambda fd, data: os.write(fd, data[:3]))
        self.assertEqual(json.loads(marker.read_bytes())["nonce"], "d" * 32)

    def test_failed_release_does_not_retry_after_partial_token(self):
        marker = self.consumed()
        before = marker.read_bytes()
        calls = 0

        def writer(fd, data):
            nonlocal calls
            calls += 1
            if calls == 1:
                return os.write(fd, data[:5])
            raise BrokenPipeError("injected release fault")

        with self.assertRaises(BrokenPipeError):
            self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env, writer=writer)
        self.assertEqual(os.read(self.go[0], 200), b"ccccc")
        self.assertEqual(marker.read_bytes(), before)
        with self.assertRaises(GuardError):
            self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env)
        self.assert_no_go()

    def test_repeated_release_is_refused(self):
        self.consumed()
        self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env)
        os.read(self.go[0], 200)
        with self.assertRaises(GuardError):
            self.gate.release(self.go[1], self.sampler, self.wrapper, self.argv, self.env)
        self.assert_no_go()

    def test_regular_file_is_not_an_ack_pipe(self):
        with (self.directory / "file").open("wb") as file:
            with self.assertRaises(GuardError):
                PipeIdentity.from_fd(file.fileno())


if __name__ == "__main__":
    unittest.main()
