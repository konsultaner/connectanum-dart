owned synthetic source fixture
