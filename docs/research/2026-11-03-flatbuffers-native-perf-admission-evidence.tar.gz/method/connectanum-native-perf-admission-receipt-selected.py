native_perf_input_census.py:47-77
class CensusContext:
    census_id: str
    source_commit: str
    runtime_commit: str
    owner_uid: int
    elf_machine: int
    lock_hashes: dict
    sdks: dict

    def __post_init__(self):
        if (not _hex(self.census_id, 32) or not _hex(self.source_commit, 40) or not _hex(self.runtime_commit, 40)
                or type(self.owner_uid) is not int or self.owner_uid < 0
                or type(self.elf_machine) is not int or not 0 < self.elf_machine < 65536
                or type(self.lock_hashes) is not dict or set(self.lock_hashes) != {'canonical', 'execution'}
                or any(type(v) is not dict or set(v) != {'pub', 'transport', 'bench'}
                       or any(not _hex(h, 64) for h in v.values()) for v in self.lock_hashes.values())
                or type(self.sdks) is not dict or set(self.sdks) != {'canonical', 'execution'}
                or any(type(v) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', v) for v in self.sdks.values())):
            raise CensusError('invalid immutable census context')
        object.__setattr__(self, 'lock_hashes', _freeze(self.lock_hashes))
        object.__setattr__(self, 'sdks', _freeze(self.sdks))


@dataclass(frozen=True)
class CheckedCensus:
    files: object
    bindings: object
    aliases: tuple
    scope: str = 'file_checks_only'



native_perf_input_census.py:195-270
def verify_census(manifest, context):
    if not isinstance(context, CensusContext) or type(manifest) is not dict or set(manifest) != {'context', 'files', 'bindings'}:
        raise CensusError('invalid input census schema')
    files, bindings = manifest['files'], manifest['bindings']
    if (type(files) is not dict or not 16 <= len(files) <= 64
            or any(type(role) is not str for role in files) or not set(ROLES) <= set(files)):
        raise CensusError('missing or invalid input roles')
    if any(type(entry) is not dict or set(entry) != {'path', 'sha256'}
           or type(entry['path']) is not str or not _hex(entry['sha256'], 64) for entry in files.values()):
        raise CensusError('invalid file entry schema before IO')
    configs = set(files) - set(ROLES)
    if not configs or any(not re.fullmatch('[a-z_]+/[A-Za-z0-9_-]{1,64}', role) or not role.startswith('config/') for role in configs):
        raise CensusError('unknown input role')
    expected_context = {'census_id': context.census_id, 'source_commit': context.source_commit,
        'runtime_commit': context.runtime_commit, 'source_archive_sha256': files['source_archive'].get('sha256')}
    if type(manifest['context']) is not dict or manifest['context'] != expected_context:
        raise CensusError('manifest source/context differs')
    if type(bindings) is not dict or set(bindings) != {'canonical', 'execution'}:
        raise CensusError('invalid config phase bindings')
    used = set()
    for phase, consumers in bindings.items():
        if (type(consumers) is not dict or not {'server', 'client'} <= set(consumers)
                or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}', k) for k in consumers)
                or any(type(v) is not str or v not in configs for v in consumers.values())):
            raise CensusError('config consumer binding differs')
        used.update(consumers.values())
    if used != configs:
        raise CensusError('unbound generated config input')
    records, objects, aliases, identities = {}, {}, [], {}
    for role, entry in files.items():
        kind = ROLES.get(role, 'json')
        record, value = _read(role, entry, kind, context)
        records[role], objects[role] = record, value
        identities.setdefault((record['device'], record['inode']), []).append(role)
        if '/' in role and role.split('/')[0] in ('canonical', 'execution'):
            phase, lock = role.split('/')
            if record['sha256'] != context.lock_hashes[phase][lock]:
                raise CensusError('actual lock cohort differs: ' + role)
    for roles in identities.values():
        if len(roles) > 1:
            if set(roles) != {'canonical/pub', 'execution/pub'} or context.lock_hashes['canonical']['pub'] != context.lock_hashes['execution']['pub']:
                raise CensusError('conflicting input role inode alias')
            aliases.append(tuple(sorted(roles)))
    common = {'census_id': context.census_id, 'source_commit': context.source_commit,
              'runtime_commit': context.runtime_commit, 'source_archive_sha256': records['source_archive']['sha256']}
    for phase, role, kind in [('canonical', 'canonical_receipt', 'own-canonical-v1'),
                              ('execution', 'production_receipt', 'own-production-v1')]:
        receipt = objects[role]
        extra = {'native_sha256'} if phase == 'canonical' else {'outputs', 'features'}
        if (set(receipt) != set(common) | {'kind', 'sdk', 'log_sha256', 'lock_hashes', 'package_configs', 'commands'} | extra
                or any(type(receipt[k]) is not str or receipt[k] != v for k, v in common.items())
                or receipt['kind'] != kind or receipt['sdk'] != context.sdks[phase]):
            raise CensusError('own source receipt context or SDK differs: ' + role)
        if receipt['lock_hashes'] != dict(context.lock_hashes[phase]):
            raise CensusError('receipt lock cohort differs: ' + role)
        expected_configs = {consumer: records[config]['sha256'] for consumer, config in bindings[phase].items()}
        if receipt['package_configs'] != expected_configs:
            raise CensusError('receipt config hashes differ: ' + role)
        log_role = 'canonical_log' if phase == 'canonical' else 'production_log'
        if receipt['log_sha256'] != records[log_role]['sha256']:
            raise CensusError('complete declared log digest differs: ' + role)
        _commands(receipt['commands'], canonical=phase == 'canonical')
        if phase == 'canonical':
            if receipt['native_sha256'] != records['canonical_native']['sha256']:
                raise CensusError('own canonical native differs')
        else:
            features = receipt['features']
            if (type(features) is not list or any(type(v) is not str or not v for v in features)
                    or any(v.split('/')[-1] == 'ffi-test' for v in features)):
                raise CensusError('ffi-test or invalid production feature receipt')
            if receipt['outputs'] != {r: records[r]['sha256'] for r in ('native_elf', 'driver_elf', 'static_rlib')}:
                raise CensusError('actual production output hashes differ')
    return CheckedCensus(_freeze(records), _freeze(copy_bindings(bindings)), tuple(sorted(aliases)))


def copy_bindings(bindings):

native_perf_build_producer.py:482-608
def _receipt_source_audit(run):
    path=run.directory/'receipt-source-audit.jsonl'
    audit=path.open('xb');index=0
    try:
        def observe(*argv):
            nonlocal index
            number=index;index+=1
            out=run.directory/f'receipt-git-{number:03}.stdout';err=run.directory/f'receipt-git-{number:03}.stderr'
            with out.open('xb') as o,err.open('xb') as e:
                cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
                result=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=o,stderr=e,close_fds=True,env=run.environment)
            stdout=_file_snapshot(out,32*1024**2);stderr=_file_snapshot(err,32*1024**2)
            record={'argv':cmd,'returncode':result.returncode,'stdout':stdout,'stderr':stderr}
            audit.write((json.dumps(record,sort_keys=True)+'\n').encode());audit.flush();os.fsync(audit.fileno())
            if result.returncode:raise ProducerError('receipt source observation failed; original bytes retained')
            return out.read_bytes()
        run._source_guard(observe)
    finally:
        primary=sys.exception()
        try:audit.close()
        except OSError as e:
            if primary is None:raise
            primary.add_note('receipt source audit close failed: '+repr(e))
    return _regular_hash(path)


def _emit(run,phase,fixture):
    if type(run) is not CommandProducer or phase not in ('canonical','execution'):
        raise ProducerError('owned producer and valid phase required')
    if run.pending or not run.finished or not run.evidence_complete or run.result['status']!='success':
        raise ProducerError('successful complete owned producer required')
    if fixture:
        if run.provenance!='fixture':raise ProducerError('fixture emitter only accepts fixture provenance')
    elif run.provenance!=('canonical_recipe' if phase=='canonical' else 'production_recipe'):
        raise ProducerError('live receipt cannot adopt fixture or foreign producer provenance')
    if run.receipt_attempted:raise ProducerError('receipt attempt is permanently terminal')
    run.receipt_attempted=True
    try:
        _write_json(run.directory/'receipt-attempt.json',{'census_id':run.census_id,'phase':phase,'fixture':fixture,'terminal':True})
        if run.census_id is None or run.expected_sdk is None or not {'server','client'}<=set(run.config_bindings):
            raise ProducerError('receipt context was not declared before child')
        intent=_read_json(run.directory/'intent.json',run.intent_sha256)
        sealed=_read_json(run.directory/'result.json',run.result_sha256)
        if (intent['census_id']!=run.census_id or intent['expected_sdk']!=run.expected_sdk
            or intent['config_bindings']!=dict(run.config_bindings) or intent['inputs']!=dict(run.inputs)
            or intent['source_commit']!=run.source_commit or intent['runtime_commit']!=run.runtime_commit
            or intent['expected_archive_sha256']!=run.source_archive_sha256 or sealed!=run.result
            or intent['provenance']!=run.provenance or sealed['provenance']!=run.provenance
            or sealed['kind']!=('fixture-command-evidence-v1' if fixture else 'own-command-evidence-v1')):
            raise ProducerError('pre-child receipt context changed')
        if _regular_hash(run.directory/'journal.jsonl')!=run.journal_sha256:raise ProducerError('sealed journal changed')
        source_audit_sha256=_receipt_source_audit(run);run._input_guard()
        if _regular_hash(run.directory/'source.tar')!=run.source_archive_sha256:raise ProducerError('sealed archive changed')
        if set(run.tools)!=set(VERSION_ARGS) or len(sealed['commands'])!=len(run.commands):raise ProducerError('six probes and all recipes required')
        recipes=[];dart=None
        for index,record in enumerate(sealed['commands']):
            if (record['argv']!=list(run.commands[index]) or (record['kind'],record['tool'])!=run.task_kinds[index]
                or record['returncode']!=0 or record['spawn_error'] is not None):raise ProducerError('command phase/argv/status differs')
            log=_file_snapshot(run.directory/f'command-{index:03}.log')
            if log!={'size':record['log_bytes'],'sha256':record['log_sha256']}:raise ProducerError('command log changed')
            if record['kind']=='recipe':recipes.append({'argv':record['argv'],'exit':record['returncode']})
            elif record['tool']=='dart':dart=_dart_sdk(record['version_line'])
        if dart!=run.expected_sdk:raise ProducerError('actual reported SDK differs')
        if not fixture and [r['argv'] for r in recipes]!=(CANONICAL_RECIPES if phase=='canonical' else PRODUCTION_RECIPES):
            raise ProducerError('live phase recipe differs')
        expected_roles={'canonical_native'} if phase=='canonical' else {'native_elf','driver_elf','static_rlib'}
        if set(sealed['outputs'])!=expected_roles:raise ProducerError('own output roles differ')
        for role,entry in sealed['outputs'].items():
            path=Path(entry['path'])
            if not fixture:
                if phase=='canonical':
                    expected=run.repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')
                    if path!=expected:raise ProducerError('canonical native outside own output')
                elif role=='static_rlib':
                    if path.parent!=run.directory/'target/release/deps' or not re.fullmatch(r'libct_core-[A-Za-z0-9_]+\.rlib',path.name):raise ProducerError('RLIB outside own production target')
                elif path!=run.directory/'target/release'/('libct_ffi.so' if role=='native_elf' else 'http_stream'):
                    raise ProducerError('production artifact outside own target')
            if _regular_hash(path)!=entry['sha256']:raise ProducerError('own output bytes changed')
        complete=run.directory/'complete-command.log'
        with complete.open('xb') as out:
            for index,record in enumerate(sealed['commands']):
                fd=os.open(run.directory/f'command-{index:03}.log',os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
                try:
                    h=hashlib.sha256();count=0
                    while True:
                        part=os.read(fd,1024**2)
                        if not part:break
                        count+=len(part)
                        if count>record['log_bytes']:raise ProducerError('command log grew during copy')
                        h.update(part);out.write(part)
                    if count!=record['log_bytes'] or h.hexdigest()!=record['log_sha256']:raise ProducerError('command bytes changed during copy')
                finally:
                    primary=sys.exception()
                    try:os.close(fd)
                    except OSError as e:
                        if primary is None:raise
                        primary.add_note('command log close failed: '+repr(e))
            out.flush();os.fsync(out.fileno())
        common={'census_id':run.census_id,'source_commit':run.source_commit,'runtime_commit':run.runtime_commit,
                'source_archive_sha256':run.source_archive_sha256,'sdk':dart,'log_sha256':_regular_hash(complete,maximum=16*1024**3),
                'lock_hashes':{k:run.inputs[p] for k,p in LOCK_PATHS.items()},
                'package_configs':{k:run.inputs[p] for k,p in run.config_bindings.items()},'commands':recipes}
        receipt={'kind':('fixture-' if fixture else 'own-')+('canonical-v1' if phase=='canonical' else 'production-v1'),**common}
        if phase=='canonical':receipt['native_sha256']=sealed['outputs']['canonical_native']['sha256']
        else:receipt.update(outputs={k:v['sha256'] for k,v in sealed['outputs'].items()},features=[])
        _write_json(run.directory/'input-receipt.json',receipt)
        binding={'scope':'command-produced links only; independent canonical breadth/descendant/SDK-image/root admission still required',
                 'capture_ready':False,'fixture':fixture,'census_id':run.census_id,'intent_sha256':run.intent_sha256,
                 'result_sha256':run.result_sha256,'journal_sha256':run.journal_sha256,'source_audit_sha256':source_audit_sha256,'receipt_sha256':_regular_hash(run.directory/'input-receipt.json'),
                 'log_sha256':receipt['log_sha256']}
        _write_json(run.directory/'receipt-binding.json',binding)
        return receipt
    except BaseException as e:
        try:_write_json(run.directory/'receipt-failure.json',{'primary_error':repr(e),'terminal':True})
        except BaseException as secondary:e.add_note('receipt failure publication failed: '+repr(secondary))
        raise


def emit_receipt(run):
    if (type(run) is not CommandProducer or run.provenance not in ('canonical_recipe','production_recipe')
        or type(run.result) is not dict or run.result.get('kind')!='own-command-evidence-v1' or run.result.get('provenance')!=run.provenance):
        raise ProducerError('live receipt requires actual live-factory provenance')
    return _emit(run,'canonical' if run.provenance=='canonical_recipe' else 'execution',False)


def emit_fixture_receipt(run,phase):
    return _emit(run,phase,True)