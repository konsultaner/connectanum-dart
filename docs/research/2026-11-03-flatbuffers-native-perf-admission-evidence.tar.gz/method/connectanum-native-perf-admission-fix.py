from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
stages=r'''    def _refuse(self,primary,stage,index):
        self._terminal=True
        try:self._write('fixture-refused.json',{'capture_ready':False,'fixture_only':True,'stage':stage,'index':index,
            'error':type(primary).__name__,'reason':str(primary),'evidence':self.evidence})
        except BaseException as secondary:primary.add_note('fixture refusal evidence failed: '+repr(secondary))

    def authorize_fixture(self,stage,index,provider):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(provider) is not FixturePreflight or provider.declaration_sha256!=self._sha
                    or type(index) is not int or (stage,index)!=self._expected):
                raise AdmissionError('fixture stage or evaluated declaration differs')
            self._expected=('IN_PROGRESS',index)  # Ambiguous publication is terminal, never retry.
            self.recheck()
            value={'kind':'fixture_only_permission','capture_ready':False,'declaration_sha256':self._sha,'stage':stage,'index':index}
            self._write(f'fixture-{index}-{stage.lower()}.json',value)
            self._expected=({'START':'ENABLE','ENABLE':'GO','GO':'FINISH'}[stage],index)
            return value
        except BaseException as primary:
            self._refuse(primary,stage,index)
            raise

    def finish_fixture(self,index,*,driver_exit,sampler_exit,rows):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(index) is not int or ('FINISH',index)!=self._expected or type(driver_exit) is not int
                    or type(sampler_exit) is not int or type(rows) is not int or not 0<=rows<=33):
                raise AdmissionError('invalid fixture finish')
            self._expected=('IN_PROGRESS',index)
            value={'capture_ready':False,'fixture_only':True,'driver_exit':driver_exit,'sampler_exit':sampler_exit,'rows':rows,'index':index}
            self._write(f'fixture-{index}-finish.json',value)
            if driver_exit==sampler_exit==0 and rows==33 and index<9:self._expected=('START',index+1)
            else:self._expected=('TERMINAL',index);self._terminal=True
            return value
        except BaseException as primary:
            self._refuse(primary,'FINISH',index)
            raise

'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool')
 p=root/'native_perf_admission.py';s=p.read_text().replace('@dataclass(frozen=True)\nclass CaptureDeclaration:', '_PREPARED=object()\n\n\n@dataclass(frozen=True,init=False)\nclass CaptureDeclaration:',1)
 s=s.replace('    raw: bytes\n    _launches: tuple\n','''    raw: bytes
    _launches: tuple

    def __init__(self,raw,launches,*,_prepared=None):
        if _prepared is not _PREPARED:raise AdmissionError('use validated declaration preparation')
        object.__setattr__(self,'raw',raw);object.__setattr__(self,'_launches',launches)
''',1)
 s=s.replace("            files['census/'+role]=_entry({'path':record['path'],'sha256':record['sha256']})", "            files['census/'+role]={**_entry({'path':record['path'],'sha256':record['sha256']}),\n                'checked_identity':{k:str(record[k]) for k in ('device','inode','size','owner_uid','mode')}}",1)
 s=s.replace('return cls(_bytes(value),tuple(launches))','return cls(_bytes(value),tuple(launches),_prepared=_PREPARED)',1)
 s=s.replace("self._expected=('START',0);self.evidence=[]","self._expected=('START',0);self._terminal=False;self.evidence=[]",1)
 s=s.replace("            pos=0\n            while pos<before.st_size:", "            expected=self._data['files'][role].get('checked_identity')\n            if expected is not None and expected!={k:str(v) for k,v in {'device':before.st_dev,'inode':before.st_ino,'size':before.st_size,'owner_uid':before.st_uid,'mode':before.st_mode}.items()}:\n                raise AdmissionError('checked census file instance changed')\n            pos=0\n            while pos<before.st_size:",1)
 a=s.index('    def authorize_fixture(');b=s.index('    def bind_fixture_session(',a);s=s[:a]+stages+s[b:]
 s=s.replace('    def bind_fixture_session(self,spec,index):\n        run=',"    def bind_fixture_session(self,spec,index):\n        if type(index) is not int or not 0<=index<10:raise AdmissionError('invalid sealed invocation index')\n        run=",1);p.write_text(s)
 p=root/'test_native_perf_admission.py';s=p.read_text();s=s.replace("        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('GO',0,p)\n        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight('f'*64))\n",'',1)
 new=r'''
    def test_evaluated_digest_mismatch_is_terminal(self):
        r=self.reservation()
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight('f'*64))
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))
''';s=s.replace("\nif __name__=='__main__':unittest.main()",new+"\nif __name__=='__main__':unittest.main()");p.write_text(s)
 p=root/'native_perf_session.py';s=p.read_text().replace("'native_perf_build_producer','native_perf_metadata','native_perf_mapped_images')","'native_perf_build_producer','native_perf_metadata','native_perf_mapped_images','native_perf_admission')",1)
 s=s.replace("'native_perf_handoff', 'native_perf_mapped_images')","'native_perf_handoff', 'native_perf_mapped_images', 'native_perf_input_census', 'native_perf_admission')",1)
 s=s.replace("mapped=importlib.import_module('native_perf_mapped_images'))","mapped=importlib.import_module('native_perf_mapped_images'),\n        admission=importlib.import_module('native_perf_admission'))",1)
 s=s.replace('on_release_attempt=None):','on_release_attempt=None, capture_check=None):',1)
 s=s.replace('    command = gate.request_enable(first_sampler.instance)',"    if capture_check is not None:capture_check('ENABLE')\n    command = gate.request_enable(first_sampler.instance)",1)
 s=s.replace('    gate.consume(Path(marker_directory))',"    if capture_check is not None:capture_check('GO')\n    gate.consume(Path(marker_directory))",1)
 s=s.replace('def __init__(self, spec, backend, *, blocked_child=None):','def __init__(self, spec, backend, *, blocked_child=None, capture_reservation=None, invocation_index=0, preflight=None):',1)
 a=s.index("        if (type(backend.fixture_only) is not bool",s.index('class SessionController:'))
 gate='''        # File-checked JSON and fixture permissions never authorize live data.
        if backend.fixture_only is False:_api().admission.require_live_admission(capture_reservation)
        if capture_reservation is not None:
            if (backend.fixture_only is not True or type(capture_reservation) is not _api().admission.CaptureReservation
                    or type(preflight) is not _api().admission.FixturePreflight):
                raise SessionError('invalid fixture capture boundary')
            capture_reservation.bind_fixture_session(spec,invocation_index)
        self.capture_reservation,self.invocation_index,self.preflight=capture_reservation,invocation_index,preflight
''';s=s[:a]+gate+s[a:]
 a=s.index('    def start_mapped(',s.index('class SessionController'))
 method='''    def _capture_check(self,stage):
        if self.capture_reservation is not None:
            return self.capture_reservation.authorize_fixture(stage,self.invocation_index,self.preflight)

''';s=s[:a]+method+s[a:]
 s=s.replace("        self.state = 'failed'\n        listener = PrivateListener(self.directory, 'sampler.sock')","        self.state = 'failed'\n        self._capture_check('START')\n        listener = PrivateListener(self.directory, 'sampler.sock')",1)
 s=s.replace('on_release_attempt=release_attempt)','on_release_attempt=release_attempt, capture_check=self._capture_check)',1);p.write_text(s)
 p=root/'test_native_perf_session.py';s=p.read_text().replace('len(session.BUNDLE_FILES),18','len(session.BUNDLE_FILES),20');p.write_text(s);lease.verify_identity()
