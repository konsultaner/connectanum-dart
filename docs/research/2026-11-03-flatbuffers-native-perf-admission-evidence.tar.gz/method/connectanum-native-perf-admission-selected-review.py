def require_live_admission(_alleged):
    # No JSON, checked-file object, fixture, or caller boolean substitutes for
    # actual independently produced preflight. No live provider exists yet.
    raise UnresolvedLiveAdmission('actual independent live preflight provider is unresolved; live capture is closed')


class CaptureReservation:
    """Terminal private reservation with held input FDs; fixture stages only."""
    def __init__(self,declaration):
        if type(declaration) is not CaptureDeclaration:raise AdmissionError('exact immutable declaration required')
        self.declaration=declaration;self._data=declaration.as_dict();self._sha=declaration.sha256
        self.path=Path(self._data['output_dir']);self._fds={};self._identities={};self._directory=None;self.closed=False
        self._expected=('START',0);self._terminal=False;self.evidence=[]
        self.path.mkdir(mode=0o700)  # Existing/partial namespace stays terminal forever.
        try:
            self._directory=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self._dir_identity=self._identity(os.fstat(self._directory))[:2]
            self._write('attempt.json',{'declaration_sha256':self._sha,'declaration':self._data,'capture_ready':False})
            for role,entry in self._data['files'].items():self._pin(role,entry)
            (self.path/'runs').mkdir(mode=0o700)
            for run in self._data['runs']:
                p=Path(run['directory']);p.mkdir(mode=0o700);(p/'markers').mkdir(mode=0o700)
        except BaseException as primary:
            try:self._write('reservation-refused.json',{'error':type(primary).__name__,'errno':getattr(primary,'errno',None),'reason':str(primary),'evidence':self.evidence})
            except BaseException as secondary:primary.add_note('reservation evidence failure: '+repr(secondary))
            try:self.close()
            except BaseException as secondary:primary.add_note('reservation cleanup failure: '+repr(secondary))
            raise

    @staticmethod
    def _identity(info):
        return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_size,info.st_mtime_ns,info.st_ctime_ns)

    def _directory_check(self):
        if self._directory is None:raise AdmissionError('reservation metadata is closed')
        info=self.path.lstat();opened=os.fstat(self._directory)
        if (not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode)!=0o700 or info.st_uid!=self._data['owner_uid']
                or (info.st_dev,info.st_ino)!=self._dir_identity or (opened.st_dev,opened.st_ino)!=self._dir_identity):
            raise AdmissionError('reservation directory identity differs')

    def _write(self,name,value):
        self._directory_check();fd=None;primary=None
        try:
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self._directory)
            data=_bytes(value);offset=0
            while offset<len(data):
                count=os.write(fd,data[offset:])
                if count<=0:raise AdmissionError('invalid reservation write progress')
                offset+=count
            os.fsync(fd);os.fsync(self._directory);self._directory_check()
        except BaseException as error:primary=error;raise
        finally:
            if fd is not None:
                owned,fd=fd,None
                try:os.close(owned)
                except BaseException as error:
                    if primary is None:raise
                    primary.add_note('reservation write close failure: '+repr(error))

    def _hash(self,role,fd,path):
        before=os.fstat(fd);event={'role':role,'path':str(path),'bytes_read':0};self.evidence.append(event)
        digest=hashlib.sha256()
        try:
            owners={self._data['owner_uid']}
            if role in ('perf_elf','python_elf'):owners.add(0)
            if (not stat.S_ISREG(before.st_mode) or before.st_uid not in owners or before.st_mode&0o6022
                    or not 0<before.st_size<=2*1024**3):raise AdmissionError('unsafe bounded declared input')
            expected=self._data['files'][role].get('checked_identity')
            if expected is not None and expected!={k:str(v) for k,v in {'device':before.st_dev,'inode':before.st_ino,'size':before.st_size,'owner_uid':before.st_uid,'mode':before.st_mode}.items()}:
                raise AdmissionError('checked census file instance changed')
            pos=0
            while pos<before.st_size:
                chunk=os.pread(fd,min(1024**2,before.st_size-pos),pos)
                if not chunk:raise AdmissionError('short declared input read')
                pos+=len(chunk);digest.update(chunk);event.update(bytes_read=pos,partial_sha256=digest.hexdigest())
            ident=self._identity(before)
            if (self._identity(os.fstat(fd))!=ident or self._identity(path.lstat())!=ident
                    or path.resolve(strict=True)!=path):raise AdmissionError('declared input identity changed')
            if digest.hexdigest()!=self._data['files'][role]['sha256']:raise AdmissionError('declared input bytes changed')
            if role in self._identities and ident!=self._identities[role]:raise AdmissionError('pinned input instance changed')
            event['identity']=[str(v) for v in ident]
            return ident
        except BaseException as error:event.update(error=type(error).__name__,errno=getattr(error,'errno',None));raise

    def _pin(self,role,entry):
        path=Path(entry['path'])
        if path.resolve(strict=True)!=path or not stat.S_ISREG(path.lstat().st_mode):raise AdmissionError('declared input must be canonical regular file')
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        self._fds[role]=fd  # Register before fallible hash/flag work.
        os.set_inheritable(fd,False);self._identities[role]=self._hash(role,fd,path)

    def recheck(self):
        self._directory_check()
        if self.declaration.sha256!=self._sha:raise AdmissionError('immutable declaration digest changed')
        for role,fd in self._fds.items():self._hash(role,fd,Path(self._data['files'][role]['path']))

    def _refuse(self,primary,stage,index):
        self._terminal=True
        try:self._write('fixture-refused.json',{'capture_ready':False,'fixture_only':True,'stage':stage,'index':index,
            'error':type(primary).__name__,'reason':str(primary),'evidence':self.evidence})
        except BaseException as secondary:primary.add_note('fixture refusal evidence failed: '+repr(secondary))

    def authorize_fixture(self,stage,index,provider):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(provider) is not FixturePreflight or provider.declaration_sha256!=self._sha
                    or type(index) is not int or (stage,index)!=self._expected):
                raise AdmissionError('fixture stage or evaluated declaration differs')
            self._expected=('IN_PROGRESS',index)  # Ambiguous publication is terminal, never retry.
            self.recheck()
            value={'kind':'fixture_only_permission','capture_ready':False,'declaration_sha256':self._sha,'stage':stage,'index':index}
            self._write(f'fixture-{index}-{stage.lower()}.json',value)
            self._expected=({'START':'ENABLE','ENABLE':'GO','GO':'FINISH'}[stage],index)
            return value
        except BaseException as primary:
            self._refuse(primary,stage,index)
            raise

    def finish_fixture(self,index,*,driver_exit,sampler_exit,rows):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(index) is not int or ('FINISH',index)!=self._expected or type(driver_exit) is not int
                    or type(sampler_exit) is not int or type(rows) is not int or not 0<=rows<=33):
                raise AdmissionError('invalid fixture finish')
            self._expected=('IN_PROGRESS',index)
            value={'capture_ready':False,'fixture_only':True,'driver_exit':driver_exit,'sampler_exit':sampler_exit,'rows':rows,'index':index}
            self._write(f'fixture-{index}-finish.json',value)
            if driver_exit==sampler_exit==0 and rows==33 and index<9:self._expected=('START',index+1)
            else:self._expected=('TERMINAL',index);self._terminal=True
            return value
        except BaseException as primary:
            self._refuse(primary,'FINISH',index)
            raise

    def bind_fixture_session(self,spec,index):
        if type(index) is not int or not 0<=index<10:raise AdmissionError('invalid sealed invocation index')
        run=self._data['runs'][index]
        if (spec.declaration!=self._sha or spec.nonce!=run['nonce'] or spec.directory!=run['directory']
                or spec.controller_uid!=self._data['owner_uid'] or spec.controller_gid!=self._data['gid']
                or spec.driver_path!=self._data['files']['census/driver_elf']['path']
                or spec.driver_sha!=self._data['files']['census/driver_elf']['sha256']
                or spec.perf_path!=self._data['files']['perf_elf']['path'] or spec.perf_sha!=self._data['files']['perf_elf']['sha256']
                or spec.bootstrap_image!=self._data['files']['python_elf']['sha256'] or spec.bundle_sha!=self._data['tool_bundle_sha256']):
            raise AdmissionError('session differs from sealed invocation')


# Session hooks
    def __init__(self, spec, backend, *, blocked_child=None, capture_reservation=None, invocation_index=0, preflight=None):
        # File-checked JSON and fixture permissions never authorize live data.
        if backend.fixture_only is False:_api().admission.require_live_admission(capture_reservation)
        if capture_reservation is not None:
            if (backend.fixture_only is not True or type(capture_reservation) is not _api().admission.CaptureReservation
                    or type(preflight) is not _api().admission.FixturePreflight):
                raise SessionError('invalid fixture capture boundary')
            capture_reservation.bind_fixture_session(spec,invocation_index)
        self.capture_reservation,self.invocation_index,self.preflight=capture_reservation,invocation_index,preflight
        if (type(backend.fixture_only) is not bool
                or blocked_child is None and not backend.fixture_only
                or blocked_child is not None and (not isinstance(blocked_child, _api().blocked.BlockedChild)
                    or not _int(blocked_child.pid, 1) or blocked_child.pid != spec.wrapper_pid)):
            raise SessionError('original owned driver binding required')
        # Binding transfers process reaping and GO-writer ownership. The caller
        # retains its readiness/log FDs and closes them after natural exits.
        self.spec, self.backend = spec, backend
        self.directory = PrivateDirectory(spec.directory, spec.controller_uid)
        self.state = 'new'
        self.ends = self.boot = self.handle = None
        self.sampler_child = None
        self.audited_phases = []
        self.release_attempted = False
        self.driver = blocked_child
        self.driver_exit = None
        self.cleanup_errors = []
        self.sampler_exit = None
        self.sampler_close_errors = []
        self.completion = None
        self.peer = None
        self.sampler_channels_closed = False
        self.refusal_go_closed = False
        self.refusal_go_close_error = False
        self.refusal_launcher_exit = None
        self.refusal_peer_exited = None
        self.refusal_errors = []
        self.refusal_completion = None
        self.mapped_operations = []

    def _capture_check(self,stage):
        if self.capture_reservation is not None:
            return self.capture_reservation.authorize_fixture(stage,self.invocation_index,self.preflight)

