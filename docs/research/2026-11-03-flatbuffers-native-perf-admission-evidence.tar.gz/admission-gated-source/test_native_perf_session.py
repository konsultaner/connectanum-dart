from __future__ import annotations

import dataclasses
import errno
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import socket
import stat
import tempfile
import time
import types
import unittest
from unittest.mock import patch

import native_perf_session as session
from native_perf_session import PrivateDirectory, PrivateListener, PinnedElf, SessionSpec, SessionError
from native_perf_guard import FrozenLaunch, ProcessStat, ProcessInstance, PipeIdentity
from native_perf_blocked_exec import BlockedSpec, start_blocked, _open_fds
from native_perf_handoff import Peer, _channel
from native_perf_proc_witness import ProcessWitness, FdWitness


class FixtureHandle:
    def __init__(self, pid):
        self.pid, self.alive, self.closed = pid, True, False
    def require_alive(self):
        if not self.alive or self.closed:
            raise SessionError('synthetic owned helper is not alive')
    def wait_exited(self, timeout):
        if self.closed or self.alive:
            raise SessionError('authenticated sampler did not exit')
    def close(self):
        self.closed = True


class FixtureBackend:
    fixture_only = True
    def __init__(self, spec, log_fd, *, corrupt=None, bad_ack=False, shutdown_wait=0, data_payload=b"synthetic perf fixture", sampler_result=0):
        self.spec, self.log_fd, self.corrupt, self.bad_ack = spec, log_fd, corrupt, bad_ack
        self.children, self.boot = [], None
        self.handles = {}
        self.shutdown_wait, self.data_payload, self.sampler_result = shutdown_wait, data_payload, sampler_result
        self.records = Path(spec.directory) / 'exec-fixture.json'
    def _identity(self):
        return {'pid': os.getpid(), 'start_ticks': os.getpid() + 100,
                'image_sha256': self.spec.bootstrap_image, 'fixture_only': True}
    def launch(self, mode, phase=None):
        pid = os.fork()
        if pid == 0:
            os.dup2(self.log_fd, 2)
            peer = Peer(self.spec.controller_pid, self.spec.controller_uid, self.spec.controller_gid)
            try:
                # Match live Popen close_fds=True BEFORE any helper handshake;
                # CLOEXEC/non-inheritable alone would not prevent fork inheritance.
                read_null = os.open(os.devnull, os.O_RDONLY)
                write_null = os.open(os.devnull, os.O_WRONLY)
                os.dup2(read_null, 0)
                os.dup2(write_null, 1)
                for inherited in _open_fds():
                    if inherited > 2:
                        os.close(inherited)
                Path(self.spec.directory, 'fixture-bootstrap-' + str(os.getpid()) + '.json').write_text(json.dumps(
                    {'fixture_only': True, 'pid': os.getpid(), 'open_fds': _open_fds()}))
                if mode == 'helper':
                    def callback(fd, argv, env):
                        inventory = _open_fds()
                        self.records.write_text(json.dumps({'fixture_only': True, 'pid': os.getpid(),
                            'uid': os.geteuid(), 'argv': list(argv), 'open_fds': inventory,
                            'image_fd': fd, 'image_cloexec': not os.get_inheritable(fd),
                            'stdin': dataclasses.asdict(PipeIdentity.from_fd(0)),
                            'stdout': dataclasses.asdict(PipeIdentity.from_fd(1))}))
                        deadline = time.monotonic() + 5
                        while select.select([0], [], [], max(0, deadline - time.monotonic()))[0]:
                            data = os.read(0, 128)
                            if not data:
                                if self.shutdown_wait:
                                    time.sleep(self.shutdown_wait)
                                if self.data_payload is not None:
                                    Path(self.spec.directory, 'perf.data').write_bytes(self.data_payload)
                                if self.sampler_result < 0:
                                    signal.signal(-self.sampler_result, signal.SIG_DFL)
                                    os.kill(os.getpid(), -self.sampler_result)  # OWN nonbenchmark fixture ONLY.
                                os._exit(self.sampler_result)
                            if data != b'enable\n':
                                raise SessionError('unexpected fixture sampler control')
                            os.write(1, b'wrong\n' if self.bad_ack else b'ack\n')
                            if time.monotonic() >= deadline:
                                return
                    session.run_helper(self.spec, fixture_peer=peer, identity=self._identity, exec_callback=callback)
                elif mode == 'mapped':
                    session.run_mapped_auditor(self.spec, phase, fixture_peer=peer, identity=self._identity,
                                              collector=self.mapped_collector, transform=getattr(self,'mapped_corrupt',None))
                    time.sleep(getattr(self,'mapped_delay',0))
                else:
                    directory = PrivateDirectory(self.spec.directory, self.spec.controller_uid)
                    sock, wire = session.connect_wire(self.spec, 'audit-' + phase + '.sock', fixture_peer=peer)
                    session.helper_preface(wire, self.spec, 'audit-' + phase, self._identity())
                    followup = session.new_round(sock, wire, spec=self.spec, as_controller=False)
                    with followup.once():
                        request = followup.read_frame()
                        target = request['target']
                        control, ack = _channel(target['control']), _channel(target['ack'])
                        pid, start = target['sampler_pid'], target['sampler_start']
                        def fd(number, identity, flags):
                            return FdWitness(number, 'pipe', identity.device, identity.inode, flags, 'fixture-pipe')
                        sampler = ProcessWitness(ProcessStat(pid, self.spec.controller_pid, start),
                            ProcessInstance(pid, start, self.spec.perf_sha, self.spec.controller_uid, self.spec.controller_gid),
                            (self.spec.controller_uid,) * 4, (self.spec.controller_gid,) * 4, self.spec.perf_argv(),
                            (0, 1, 64, 0, 0, stat.S_IFREG | 0o700), self.spec.perf_path,
                            (fd(0, control.read_end, os.O_RDONLY), fd(1, ack.write_end, os.O_WRONLY),
                             FdWitness(2, 'regular', self.spec.log_device, self.spec.log_inode, os.O_WRONLY, 'fixture-log')), True)
                        wrapper = ProcessWitness(ProcessStat(self.spec.wrapper_pid, self.spec.controller_pid, self.spec.wrapper_start),
                            ProcessInstance(self.spec.wrapper_pid, self.spec.wrapper_start, self.spec.wrapper_image,
                                            self.spec.controller_uid, self.spec.controller_gid),
                            (self.spec.controller_uid,) * 4, (self.spec.controller_gid,) * 4, self.spec.wrapper_argv,
                            (0, 2, 64, 0, 0, stat.S_IFREG | 0o700), self.spec.driver_path, (), True)
                        report = {'context': self.spec.context('audit-' + phase), 'fixture_only': True,
                                  'sampler': dataclasses.asdict(sampler), 'wrapper': dataclasses.asdict(wrapper),
                                  'actual_driver_fd_sha256': self.spec.driver_sha,
                                  'raw_evidence': [{'fixture_only': True, 'phase': phase}]}
                        if self.corrupt:
                            report = self.corrupt(phase, report)
                        receipt = session.write_report(directory, 'audit-' + phase + '.json', report)
                        followup.send_frame({'event': 'audit_report', **self.spec.context('audit-' + phase), 'receipt': receipt})
                    sock.close()
                    directory.close()
                os._exit(0)
            except BaseException as error:
                # OWN callback fixture only; preserve its error, no root/perf execution.
                try:
                    Path(self.spec.directory, 'fixture-error-' + str(os.getpid()) + '.json').write_text(json.dumps(
                        {'fixture_only': True, 'error': type(error).__name__, 'reason': str(error)}))
                except BaseException as publication_error:
                    try:
                        os.write(2, json.dumps({'fixture_only': True, 'error': type(error).__name__,
                                               'publication_error': type(publication_error).__name__}).encode() + b'\n')
                    except BaseException:
                        pass
                finally:
                    os._exit(78)  # Never fall through into the parent unittest runner.
        child = types.SimpleNamespace(pid=pid)
        self.children.append(child)
        return child
    def accept(self, listener, child):
        return listener.accept(fixture_peer=Peer(child.pid, self.spec.controller_uid, self.spec.controller_gid))
    def handle(self, peer):
        handle = FixtureHandle(peer.pid)
        self.handles[peer.pid] = handle
        return handle
    def wait_sampler(self, child, timeout):
        if not any(child is existing for existing in self.children):
            raise SessionError('sampler launcher is not an owned child')
        deadline = time.monotonic() + timeout
        while True:
            pid, status = os.waitpid(child.pid, os.WNOHANG)
            if pid:
                if pid in self.handles:
                    self.handles[pid].alive = False
                return os.waitstatus_to_exitcode(status)
            if time.monotonic() >= deadline:
                raise SessionError('sampler launch did not exit')
            time.sleep(.002)
    def wait_auditor(self, child):
        pid, status = os.waitpid(child.pid, 0)
        if os.waitstatus_to_exitcode(status) != 0:
            raise SessionError('fixture auditor failed')
    def reap(self):
        for child in self.children:
            deadline = time.monotonic() + 1
            while True:
                try:
                    found, status = os.waitpid(child.pid, os.WNOHANG)
                except ChildProcessError:
                    break
                if found:
                    break
                if time.monotonic() >= deadline:
                    os.kill(child.pid, signal.SIGKILL)  # OWN nonbenchmark callback only.
                    os.waitpid(child.pid, 0)
                    break
                time.sleep(.005)


@unittest.skipUnless(os.name == 'posix' and hasattr(os, 'fork'), 'OWN POSIX fixtures')
class SessionTests(unittest.TestCase):
    """No real Linux/root/pidfd/perf/ELF exec/native library/benchmark evidence."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ct-session-', dir='/tmp')
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name).resolve()
        self.directory.chmod(0o700)
        self.private = PrivateDirectory(self.directory, os.geteuid())
        self.addCleanup(self.private.close)
        self.log = (self.directory / 'sampler-log.json').open('wb')
        self.addCleanup(self.log.close)
        self.perf = self.directory / 'perf-fixture'
        self.perf.write_bytes(b'\x7fELFowned non-executed perf fixture')
        self.perf.chmod(0o700)
        self.driver = self.directory / 'driver-fixture'
        self.driver.write_bytes(b'owned driver exec CALLBACK fixture')
        self.driver.chmod(0o700)
        self.marker = self.directory / 'marker'
        self.marker.mkdir(mode=0o700)
        self.executed = self.directory / 'driver-executed.json'
        policy = FrozenLaunch.freeze((str(self.driver), 'fixture-argument'), os.environ.copy(), os.geteuid(), os.getegid())
        self.policy = policy
        self.child = None
        self.controllers, self.backends = [], []
        self.addCleanup(self.cleanup)
    def cleanup(self):
        for controller in self.controllers:
            try:
                if getattr(controller, 'release_attempted', False) and controller.driver_exit is None:
                    controller.wait_driver(self.child, 1)
                if hasattr(controller, 'finish_sampler') and controller.state in ('driver_finished', 'sampler_pending'):
                    controller.finish_sampler(1)
                elif (hasattr(controller, 'finish_refused') and not controller.release_attempted
                      and controller.driver is self.child and controller.state not in ('refusal_finished', 'refusal_quarantined')):
                    controller.finish_refused(self.child, 1)
                controller.close_metadata()
            except (OSError, SessionError, session._api().guard.GuardError):
                pass
        if self.child:
            self.child.close_go()
            try:
                self.child.wait(1)
            except ChildProcessError:
                pass
            except Exception:
                os.kill(self.child.pid, signal.SIGKILL)  # OWN callback only, not a campaign.
                os.waitpid(self.child.pid, 0)
            os.close(self.child.ready_fd)
        # OWN fixture teardown only: after its driver wait, close known fixture
        # channels even for deliberate provenance quarantine, then reap only the
        # exact forked callback children. This is not a live cleanup workaround.
        for controller in self.controllers:
            if controller.ends is not None:
                controller.ends.close()
        for backend in self.backends:
            backend.reap()
        for controller in self.controllers:
            if controller.handle is not None:
                controller.handle.close()
            controller.directory.close()
        evidence = os.environ.get('CONNECTANUM_PERF_SESSION_FIXTURE_EVIDENCE')
        if evidence:
            # Preserve all OWN fixture files/logs/transcripts before temp cleanup.
            target = Path(evidence) / self._testMethodName
            inventory = {str(p.relative_to(self.directory)): {'mode': p.lstat().st_mode,
                         'device': p.lstat().st_dev, 'inode': p.lstat().st_ino}
                         for p in self.directory.rglob('*')}
            def skip_sockets(directory, names):
                return [name for name in names if not (Path(directory, name).is_dir() or Path(directory, name).is_symlink() or stat.S_ISREG(Path(directory, name).lstat().st_mode))]
            shutil.copytree(self.directory, target, symlinks=True, ignore=skip_sockets)
            (target / 'fixture-node-inventory.json').write_text(json.dumps(inventory))

    def spec(self, wrapper_pid=99999):
        info = os.fstat(self.log.fileno())
        return SessionSpec('a' * 64, 'b' * 32, os.getpid(), os.geteuid(), os.getegid(), str(self.directory),
            wrapper_pid, 123, 'e' * 64, ('owned-python-fixture',), str(self.driver),
            hashlib.sha256(self.driver.read_bytes()).hexdigest(), str(self.perf),
            hashlib.sha256(self.perf.read_bytes()).hexdigest(), 'e' * 64, 'c' * 64, info.st_dev, info.st_ino)
    def setup_controller(self, *, driver_wait=0, start_helper=True, **options):
        def driver_callback(fd, argv, env):
            self.executed.write_text(json.dumps({'fixture_only': True, 'argv': list(argv)}))
            if driver_wait:
                time.sleep(driver_wait)
        blocked = BlockedSpec(self.policy, hashlib.sha256(self.driver.read_bytes()).hexdigest(),
                              'a' * 64, 'b' * 32, self.marker, Path.cwd(), 3)
        self.child = start_blocked(blocked, self.log.fileno(), test_exec=driver_callback)
        self.child.read_ready(1)
        spec = self.spec(self.child.pid)
        backend = FixtureBackend(spec, self.log.fileno(), **options)
        self.backends.append(backend)
        controller = session.SessionController(spec, backend, blocked_child=self.child)
        self.controllers.append(controller)
        if start_helper:
            controller.start_helper()
        return controller

    def test_private_node_and_directory_identity_and_retention(self):
        listener = PrivateListener(self.private, 'owned.sock')
        listener.verify()
        listener.close()
        self.assertTrue((self.directory / 'owned.sock').is_socket())
        with self.assertRaisesRegex(SessionError, 'exists'):
            PrivateListener(self.private, 'owned.sock')

    def test_existing_node_or_insecure_directory_refuses(self):
        (self.directory / 'existing.sock').write_text('protected fixture')
        with self.assertRaisesRegex(SessionError, 'exists'):
            PrivateListener(self.private, 'existing.sock')
        self.assertEqual((self.directory / 'existing.sock').read_text(), 'protected fixture')
        self.directory.chmod(0o755)
        with self.assertRaisesRegex(SessionError, 'permissions'):
            self.private.verify()
        self.directory.chmod(0o700)

    def test_socket_node_replacement_is_not_deleted(self):
        listener = PrivateListener(self.private, 'replaced.sock')
        (self.directory / 'replaced.sock').rename(self.directory / 'old.sock')
        (self.directory / 'replaced.sock').write_text('retain replacement')
        with self.assertRaisesRegex(SessionError, 'node changed'):
            listener.accept(fixture_peer=Peer(os.getpid(), os.geteuid(), os.getegid()))
        listener.close()
        self.assertEqual((self.directory / 'replaced.sock').read_text(), 'retain replacement')

    def test_pinned_image_bytes_and_named_path_drift_refuse(self):
        image = PinnedElf(self.perf, hashlib.sha256(self.perf.read_bytes()).hexdigest())
        self.addCleanup(image.close)
        self.perf.rename(self.directory / 'old-perf')
        self.perf.write_bytes(b'\x7fELFnew unexpected fixture image')
        self.perf.chmod(0o700)
        with self.assertRaisesRegex(SessionError, 'changed'):
            image.verify()

    def test_exclusive_report_authentication_and_terminal_partial(self):
        report = {'fixture_only': True, 'data': 'synthetic'}
        receipt = session.write_report(self.private, 'audit.json', report)
        self.assertEqual(session.read_report(self.private, receipt), report)
        with self.assertRaises(FileExistsError):
            session.write_report(self.private, 'audit.json', report)
        (self.directory / 'audit.json').write_text('mutated')
        with self.assertRaisesRegex(SessionError, 'identity|digest'):
            session.read_report(self.private, receipt)

    def test_report_boolean_receipt_and_schema_are_refused(self):
        receipt = session.write_report(self.private, 'schema.json', {'fixture_only': True})
        bad = dict(receipt, inode=False)
        with self.assertRaisesRegex(SessionError, 'receipt'):
            session.read_report(self.private, bad)

    def test_full_two_audits_ack_marker_go_and_same_pid_callback(self):
        controller = self.setup_controller()
        helper_pid = controller.boot['pid']
        gate = controller.arm(self.child, self.policy, self.marker)
        self.assertEqual(gate.state, 'released')
        self.assertEqual(controller.audited_phases, ['before-enable', 'before-go'])
        self.assertEqual(controller.wait_driver(self.child, 1), 0)
        self.assertTrue(self.executed.exists())
        record = json.loads((self.directory / 'exec-fixture.json').read_text())
        self.assertEqual(record['pid'], helper_pid)
        self.assertEqual(record['uid'], os.geteuid())
        self.assertEqual(record['argv'], list(controller.spec.perf_argv()))
        self.assertTrue(record['image_cloexec'])
        self.assertEqual(set(record['open_fds']), {0, 1, 2, record['image_fd']})
        self.assertTrue((self.marker / 'capture-consumed.json').exists())
        self.assertTrue((self.directory / 'controller-before-go.json').exists())

    def test_bad_second_audit_never_writes_marker_or_go(self):
        def corrupt(phase, report):
            if phase == 'before-go':
                report['sampler']['argv'] = (*report['sampler']['argv'], '--unexpected-flag')
            return report
        controller = self.setup_controller(corrupt=corrupt)
        with self.assertRaisesRegex(SessionError, 'sampler audit'):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse(self.executed.exists())
        self.assertFalse((self.marker / 'capture-consumed.json').exists())
        self.assertTrue((self.directory / 'audit-before-go.json').exists())
        self.assertEqual(controller.state, 'failed')

    def test_fixture_report_cannot_be_admitted_as_live(self):
        controller = self.setup_controller()
        controller.audit('before-enable')
        raw = json.loads((self.directory / 'audit-before-enable.json').read_text())
        with self.assertRaisesRegex(SessionError, 'provenance'):
            session.admit_audit(controller.spec, raw, 'before-enable', controller.boot,
                                controller.ends.control, controller.ends.ack, fixture_only=False)
        with self.assertRaisesRegex(SessionError, 'out of order'):
            controller.audit('before-enable')

    def test_spoofed_ack_never_writes_marker_or_go(self):
        controller = self.setup_controller(bad_ack=True)
        with self.assertRaises(Exception):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse((self.marker / 'capture-consumed.json').exists())
        self.assertFalse(self.executed.exists())
        self.assertEqual(controller.audited_phases, ['before-enable'])

    def test_existing_consumed_marker_never_releases_or_retries(self):
        controller = self.setup_controller()
        marker = self.marker / 'capture-consumed.json'
        marker.write_bytes(b'partial retained fixture marker')
        with self.assertRaises(FileExistsError):
            controller.arm(self.child, self.policy, self.marker)
        self.assertEqual(marker.read_bytes(), b'partial retained fixture marker')
        self.assertFalse(self.executed.exists())
        with self.assertRaisesRegex(SessionError, 'rearm'):
            controller.arm(self.child, self.policy, self.marker)

    def test_fixed_perf_argv_is_attach_only_flat_unfiltered_clock(self):
        spec = self.spec()
        argv = spec.perf_argv()
        self.assertIn('--pid', argv)
        self.assertIn('--inherit', argv)
        self.assertIn('--delay=-1', argv)
        self.assertIn('cpu-clock', argv)
        self.assertNotIn('cpu-clock:u', argv)
        self.assertNotIn('--', argv)
        self.assertNotIn('-g', argv)
        self.assertEqual(argv[0], str(self.perf))

    def test_live_cli_never_chooses_darwin_or_fixture_fallback(self):
        with patch('native_perf_session.sys.platform', 'darwin'):
            with self.assertRaisesRegex(SessionError, 'Linux'):
                session._check_root_linux()
        payload = dataclasses.asdict(self.spec())
        payload['fixture_only'] = True
        with self.assertRaisesRegex(SessionError, 'schema'):
            SessionSpec.from_json(payload)

    def test_spec_scalar_types_and_unknown_report_fields_refuse(self):
        original = self.spec()
        for field, value in [('controller_uid', False), ('wrapper_start', 0), ('declaration', 'bad')]:
            with self.subTest(field=field), self.assertRaises(SessionError):
                dataclasses.replace(original, **{field: value})
        with self.assertRaisesRegex(SessionError, 'provenance'):
            session.admit_audit(original, {'fixture_only': False}, 'before-enable', {}, None, None)

    def test_bundle_hash_drift_is_refused_before_own_module_import(self):
        root = self.directory / 'bundle'
        (root / 'tool').mkdir(parents=True)
        files = {}
        for relative in session.BUNDLE_FILES:
            path = root / relative
            path.write_bytes(b'owned synthetic source fixture\n')
            path.chmod(0o600)
            files[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest = self.directory / 'manifest.json'
        manifest.write_bytes(session._bytes({'files': files}))
        digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
        verified = session.verified_bundle(root, manifest, digest, os.geteuid())
        self.assertEqual(set(verified), set(session.BUNDLE_FILES))
        (root / 'tool/native_perf_guard.py').write_bytes(b'changed source')
        with self.assertRaisesRegex(SessionError, 'digest'):
            session.verified_bundle(root, manifest, digest, os.geteuid())

    def test_verified_byte_loader_ignores_preexisting_module_cache(self):
        # Isolate module cache mutation in an OWN child. No image exec/root/native.
        result = self.directory / 'loader.json'
        pid = os.fork()
        if pid == 0:
            sources = {f'tool/{name}.py': f'VERIFIED_MARKER = {index}\n'.encode()
                       for index, name in enumerate(session.MODULE_ORDER)}
            for name in session.MODULE_ORDER:
                __import__('sys').modules[name] = types.SimpleNamespace(VERIFIED_MARKER='poisoned-cache')
            session.load_verified_modules(sources, self.directory)
            result.write_text(json.dumps([__import__('sys').modules[name].VERIFIED_MARKER for name in session.MODULE_ORDER]))
            os._exit(0)
        os.waitpid(pid, 0)
        self.assertEqual(json.loads(result.read_text()), list(range(len(session.MODULE_ORDER))))

    def test_go_eof_failure_preserves_sampler_until_driver_natural_exit(self):
        controller = self.setup_controller(driver_wait=.5)
        original = self.child.close_go
        def close_then_fail():
            original()
            raise OSError(errno.EIO, 'injected post-close GO error')
        with patch.object(self.child, 'close_go', side_effect=close_then_fail):
            with self.assertRaisesRegex(OSError, 'post-close GO'):
                controller.arm(self.child, self.policy, self.marker)
        deadline = time.monotonic() + 1
        while not self.executed.exists() and time.monotonic() < deadline:
            time.sleep(.005)
        self.assertTrue(self.executed.exists(), 'full token+EOF actually reached OWN callback')
        self.assertTrue((self.marker / 'capture-consumed.json').exists())
        with self.assertRaisesRegex(SessionError, 'natural exit'):
            controller.close_metadata()
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        self.assertEqual(controller.wait_driver(self.child, 1), 0)
        if hasattr(controller, 'finish_sampler'):
            controller.finish_sampler(1)
        controller.close_metadata()

    def test_actual_sampler_wrong_log_fd_refuses_before_marker(self):
        def corrupt(phase, report):
            for fd in report['sampler']['fds']:
                if fd['number'] == 2:
                    fd['inode'] += 1
            return report
        controller = self.setup_controller(corrupt=corrupt)
        with self.assertRaisesRegex(SessionError, 'log'):
            controller.arm(self.child, self.policy, self.marker)
        self.assertFalse(self.executed.exists())
        self.assertFalse((self.marker / 'capture-consumed.json').exists())

    def test_protocol_save_error_preserves_primary_refusal(self):
        backend = FixtureBackend(self.spec(), self.log.fileno())
        self.backends.append(backend)
        controller = session.SessionController(backend.spec, backend)
        self.controllers.append(controller)
        with patch.object(backend, 'launch', side_effect=SessionError('primary launch refusal')):
            with patch.object(controller, '_save', side_effect=OSError(errno.ENOSPC, 'injected log refusal')):
                with self.assertRaisesRegex(SessionError, 'primary launch refusal') as caught:
                    controller.start_helper()
        self.assertTrue(any('log refusal' in note for note in getattr(caught.exception, '__notes__', [])))

    def test_stale_controller_ack_fd_refuses_before_enable_or_read(self):
        controller = self.setup_controller()
        original_ack = os.dup(controller.ends.ack_fd)
        self.addCleanup(os.close, original_ack)
        unrelated, writer = os.pipe()
        os.write(writer, b'ack\n')
        os.close(writer)
        try:
            os.dup2(unrelated, controller.ends.ack_fd)
        finally:
            os.close(unrelated)
        writes = []
        real_write = session._api().guard._write_all
        def observe(fd, data, function):
            if fd == controller.ends.control_fd:
                writes.append(data)
            return real_write(fd, data, function)
        with patch.object(session._api().guard, '_write_all', side_effect=observe):
            with self.assertRaisesRegex(SessionError, 'ack pipe changed'):
                controller.arm(self.child, self.policy, self.marker)
        self.assertEqual(writes, [], 'unverified controller ACK must prevent sampler enable')
        self.assertEqual(os.read(controller.ends.ack_fd, 128), b'ack\n')
        self.assertFalse((self.marker / 'capture-consumed.json').exists())

    def test_low_numbered_pinned_image_refuses_before_stdio_mapping(self):
        result = self.directory / 'low-fd-refusal.json'
        pid = os.fork()
        if pid == 0:
            os.close(0)
            try:
                image = PinnedElf(self.perf, hashlib.sha256(self.perf.read_bytes()).hexdigest())
            except SessionError as error:
                result.write_text(json.dumps({'fixture_only': True, 'refused': str(error)}))
                os._exit(0)
            image.close()
            os._exit(79)
        _, status = os.waitpid(pid, 0)
        self.assertEqual(os.waitstatus_to_exitcode(status), 0)
        self.assertIn('pinned sampler ELF changed', json.loads(result.read_text())['refused'])

    def test_driver_wait_timeout_retains_sampler_and_terminal_marker(self):
        controller = self.setup_controller(driver_wait=.15)
        controller.arm(self.child, self.policy, self.marker)
        with self.assertRaisesRegex(session._api().guard.GuardError, 'did not exit'):
            controller.wait_driver(self.child, .001)
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        with self.assertRaisesRegex(SessionError, 'natural exit'):
            controller.close_metadata()
        with self.assertRaisesRegex(SessionError, 'rearm'):
            controller.arm(self.child, self.policy, self.marker)
        self.assertTrue((self.marker / 'capture-consumed.json').exists())
        self.assertEqual(controller.wait_driver(self.child, 1), 0)
        with self.assertRaisesRegex(SessionError, 'natural-exit wait'):
            controller.wait_driver(self.child, 1)

    def test_completion_metadata_cannot_close_before_sampler_natural_exit(self):
        controller = self.setup_controller(shutdown_wait=.15)
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        with self.assertRaisesRegex(SessionError, 'sampler natural exit'):
            controller.close_metadata()
        self.assertGreaterEqual(controller.ends.control_fd, 0)

    def test_completion_requires_driver_exit_before_closing_channels(self):
        controller = self.setup_controller(driver_wait=.15)
        controller.arm(self.child, self.policy, self.marker)
        with self.assertRaisesRegex(SessionError, 'driver natural exit'):
            controller.finish_sampler(.01)
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        controller.wait_driver(self.child, 1)
        result = controller.finish_sampler(1)
        self.assertEqual(result['sampler_exit'], 0)
        self.assertEqual(result['errors'], [])
        self.assertEqual(result['artifact']['sha256'], hashlib.sha256(b'synthetic perf fixture').hexdigest())
        self.assertEqual((self.directory / 'perf.data').read_bytes(), b'synthetic perf fixture')
        self.assertTrue((self.directory / 'sampler-exit.json').exists())
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_sampler(1)
        controller.close_metadata()

    def test_completion_timeout_preserves_pending_and_does_not_reclose_reused_fd(self):
        controller = self.setup_controller(shutdown_wait=.15)
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        old_control = controller.ends.control_fd
        with self.assertRaisesRegex(SessionError, 'sampler launch did not exit'):
            controller.finish_sampler(.001)
        self.assertEqual(controller.state, 'sampler_pending')
        with self.assertRaisesRegex(SessionError, 'sampler natural exit'):
            controller.close_metadata()
        unrelated = os.open(self.directory / 'owned-reused-fd.json', os.O_CREAT | os.O_WRONLY, 0o600)
        if unrelated != old_control:
            with self.assertRaises(OSError):
                os.fstat(old_control)
            os.dup2(unrelated, old_control)
            os.close(unrelated)
        try:
            identity = os.fstat(old_control).st_ino
            result = controller.finish_sampler(1)
            self.assertEqual(result['sampler_exit'], 0)
            self.assertEqual(os.fstat(old_control).st_ino, identity)
        finally:
            os.close(old_control)

    def test_completion_nonzero_sampler_keeps_all_raw_bytes_and_exit(self):
        controller = self.setup_controller(sampler_result=7, data_payload=b'partial synthetic raw data')
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        result = controller.finish_sampler(1)
        self.assertEqual(result['sampler_exit'], 7)
        self.assertTrue(result['errors'])
        self.assertEqual((self.directory / 'perf.data').read_bytes(), b'partial synthetic raw data')
        stored = json.loads((self.directory / 'sampler-exit.json').read_text())
        self.assertEqual(stored, result)
        self.assertTrue((self.marker / 'capture-consumed.json').exists())

    def test_completion_artifact_fifo_symlink_and_small_limit_are_retained_refusals(self):
        fifo = self.directory / 'perf.data'
        os.mkfifo(fifo, 0o600)
        with self.assertRaisesRegex(SessionError, 'regular'):
            session.sampler_artifact(self.private, maximum=64)
        self.assertTrue(fifo.is_fifo())
        fifo.rename(self.directory / 'saved-fifo')
        target = self.directory / 'owned-target.json'
        target.write_bytes(b'own synthetic bytes')
        fifo.symlink_to(target)
        with self.assertRaises((OSError, SessionError)):
            session.sampler_artifact(self.private, maximum=64)
        self.assertTrue(fifo.is_symlink())
        fifo.rename(self.directory / 'saved-link')
        fifo.write_bytes(b'oversize for declared tiny fixture limit')
        with self.assertRaisesRegex(SessionError, 'size'):
            session.sampler_artifact(self.private, maximum=2)
        self.assertEqual(fifo.read_bytes(), b'oversize for declared tiny fixture limit')

    def test_completion_rejects_a_launcher_exit_without_actual_sampler_exit(self):
        controller = self.setup_controller()
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        with patch.object(controller.backend, 'wait_sampler', return_value=0):
            with self.assertRaisesRegex(SessionError, 'authenticated sampler did not exit'):
                controller.finish_sampler(.01)
        self.assertEqual(controller.state, 'sampler_pending')
        controller.backend.wait_sampler(controller.sampler_child, 1)
        self.assertEqual(controller.finish_sampler(1)['sampler_exit'], 0)

    def test_completion_signed_actual_own_signal_exit_remains_negative(self):
        controller = self.setup_controller(sampler_result=-signal.SIGTERM, data_payload=b'owned signal fixture raw')
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        result = controller.finish_sampler(1)
        self.assertEqual(result['sampler_exit'], -signal.SIGTERM)
        self.assertEqual(result['errors'], [{'type': 'sampler_exit', 'exit': -signal.SIGTERM}])
        self.assertEqual((self.directory / 'perf.data').read_bytes(), b'owned signal fixture raw')

    def test_completion_partial_report_failure_is_terminal_without_second_read(self):
        controller = self.setup_controller()
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        def partial(directory, name, value):
            self.assertEqual(name, 'sampler-exit.json')
            fd = os.open(directory.name(name), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(fd, b'{')
            finally:
                os.close(fd)
            raise OSError(errno.ENOSPC, 'injected partial completion report')
        with patch.object(session, 'sampler_artifact', wraps=session.sampler_artifact) as reads:
            with patch.object(session, 'write_report', side_effect=partial):
                with self.assertRaisesRegex(OSError, 'partial completion report'):
                    controller.finish_sampler(1)
            self.assertEqual(controller.state, 'sampler_finished')
            with self.assertRaisesRegex(SessionError, 'terminal'):
                controller.finish_sampler(1)
            self.assertEqual(reads.call_count, 1)
        self.assertEqual((self.directory / 'sampler-exit.json').read_bytes(), b'{')
        self.assertEqual(controller.completion['sampler_exit'], 0)
        controller.close_metadata()

    def test_completion_metadata_closes_only_after_both_processes_finished(self):
        controller = self.setup_controller()
        controller.arm(self.child, self.policy, self.marker)
        controller.wait_driver(self.child, 1)
        directory_fd = controller.directory.fd
        controller.finish_sampler(1)
        controller.close_metadata()
        self.assertEqual(controller.directory.fd, -1)
        self.assertTrue(controller.handle.closed)
        with self.assertRaises(OSError):
            os.fstat(directory_fd)

    def test_refusal_metadata_cannot_close_with_pre_go_actors_live(self):
        controller = self.setup_controller()
        with self.assertRaisesRegex(SessionError, 'natural exit'):
            controller.close_metadata()
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        self.assertFalse(self.executed.exists())

    def test_refusal_bad_ack_reaps_owned_driver_and_actual_bound_helper(self):
        controller = self.setup_controller(bad_ack=True)
        with self.assertRaises(session._api().guard.GuardError):
            controller.arm(self.child, self.policy, self.marker)
        report = controller.finish_refused(self.child, 1)
        self.assertEqual(report['driver_exit'], 78)
        self.assertEqual(report['launcher_exit'], 0)
        self.assertTrue(report['actual_peer_exit_observed'])
        self.assertTrue(report['ownership_complete'])
        self.assertFalse(report['driver_release_attempted'])
        self.assertFalse(self.executed.exists())
        self.assertFalse((self.marker / 'capture-consumed.json').exists())
        controller.close_metadata()
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def test_refusal_keeps_existing_partial_marker_and_no_go(self):
        controller = self.setup_controller()
        marker = self.marker / 'capture-consumed.json'
        marker.write_bytes(b'original partial marker')
        with self.assertRaises(FileExistsError):
            controller.arm(self.child, self.policy, self.marker)
        report = controller.finish_refused(self.child, 1)
        self.assertTrue(report['ownership_complete'])
        self.assertEqual(marker.read_bytes(), b'original partial marker')
        self.assertFalse(self.executed.exists())
        with self.assertRaisesRegex(SessionError, 'rearm'):
            controller.arm(self.child, self.policy, self.marker)

    def test_refusal_post_go_rejects_before_any_endpoint_change(self):
        controller = self.setup_controller(driver_wait=.15)
        controller.arm(self.child, self.policy, self.marker)
        endpoints = controller.ends.control_fd, controller.ends.ack_fd, self.child.go_fd
        with self.assertRaisesRegex(SessionError, 'release attempt'):
            controller.finish_refused(self.child, 1)
        self.assertEqual((controller.ends.control_fd, controller.ends.ack_fd, self.child.go_fd), endpoints)
        self.assertGreaterEqual(controller.ends.control_fd, 0)
        controller.wait_driver(self.child, 1)
        controller.finish_sampler(1)

    def test_refusal_ambiguous_go_rejects_and_preserves_active_sampler(self):
        controller = self.setup_controller(driver_wait=.15)
        close = self.child.close_go
        def close_then_error():
            close()
            raise OSError(errno.EIO, 'OWN ambiguous GO close')
        with patch.object(self.child, 'close_go', side_effect=close_then_error):
            with self.assertRaisesRegex(OSError, 'ambiguous GO'):
                controller.arm(self.child, self.policy, self.marker)
        endpoints = controller.ends.control_fd, controller.ends.ack_fd
        with self.assertRaisesRegex(SessionError, 'release attempt'):
            controller.finish_refused(self.child, 1)
        self.assertEqual((controller.ends.control_fd, controller.ends.ack_fd), endpoints)
        controller.wait_driver(self.child, 1)
        self.assertTrue(self.executed.exists())
        controller.finish_sampler(1)

    def test_refusal_unknown_peer_quarantines_instead_of_trusting_launcher(self):
        controller = self.setup_controller(start_helper=False)
        with patch.object(controller.backend, 'accept', side_effect=SessionError('OWN pre-peer refusal')):
            with self.assertRaisesRegex(SessionError, 'pre-peer refusal'):
                controller.start_helper()
        with self.assertRaisesRegex(SessionError, 'identity incomplete'):
            controller.finish_refused(self.child, 1)
        report = json.loads((self.directory / 'refusal-exit.json').read_text())
        self.assertFalse(report['ownership_complete'])
        self.assertFalse(report['actual_peer_exit_observed'])
        self.assertEqual(report['driver_exit'], 78)
        self.assertIsNotNone(report['launcher_exit'])
        self.assertFalse(self.executed.exists())
        with self.assertRaisesRegex(SessionError, 'identity'):
            controller.close_metadata()
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def test_refusal_launch_never_started_records_absence_without_fake_zero(self):
        controller = self.setup_controller(start_helper=False)
        with patch.object(controller.backend, 'launch', side_effect=SessionError('OWN launch refusal')):
            with self.assertRaisesRegex(SessionError, 'launch refusal'):
                controller.start_helper()
        report = controller.finish_refused(self.child, 1)
        self.assertTrue(report['ownership_complete'])
        self.assertFalse(report['helper_started'])
        self.assertIsNone(report['launcher_exit'])
        self.assertIsNone(report['actual_peer_exit_observed'])
        self.assertEqual(report['driver_exit'], 78)
        controller.close_metadata()

    def test_refusal_timeout_continues_wait_without_relaunch_or_second_close(self):
        controller = self.setup_controller(shutdown_wait=.15)
        with self.assertRaises((SessionError, session._api().guard.GuardError)):
            controller.finish_refused(self.child, .001)
        self.assertEqual(controller.state, 'refusal_pending')
        self.assertEqual(self.child.go_fd, -1)
        with self.assertRaisesRegex(SessionError, 'natural exit'):
            controller.close_metadata()
        report = controller.finish_refused(self.child, 1)
        self.assertTrue(report['ownership_complete'])
        self.assertEqual(len(controller.backend.children), 1)
        self.assertFalse(self.executed.exists())

    def test_refusal_reused_go_fd_is_not_closed_and_quarantine_is_terminal(self):
        controller = self.setup_controller()
        go = self.child.go_fd
        saved = os.dup(go)
        os.close(go)
        decoy = os.open(self.directory / 'OWN-decoy.json', os.O_CREAT | os.O_WRONLY, 0o600)
        if decoy != go:
            os.dup2(decoy, go)
            os.close(decoy)
        try:
            identity = os.fstat(go).st_ino
            with self.assertRaisesRegex(SessionError, 'GO endpoint'):
                controller.finish_refused(self.child, 1)
            self.assertEqual(os.fstat(go).st_ino, identity)
            report = json.loads((self.directory / 'refusal-exit.json').read_text())
            self.assertFalse(report['ownership_complete'])
            self.assertFalse(self.executed.exists())
        finally:
            os.close(go)  # OWN decoy; restore only for OWN fixture teardown, never a capture retry.
            self.child.go_fd = saved
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def test_refusal_rejects_foreign_child_object_without_closing_borrowed_fd(self):
        controller = self.setup_controller()
        borrowed = dataclasses.replace(self.child)
        before = os.fstat(self.child.go_fd).st_ino
        with self.assertRaisesRegex(SessionError, 'owned driver'):
            controller.finish_refused(borrowed, 1)
        self.assertEqual(os.fstat(self.child.go_fd).st_ino, before)
        self.assertFalse(self.executed.exists())

    def test_refusal_publication_identity_error_keeps_primary(self):
        controller = self.setup_controller(start_helper=False)
        with patch.object(controller.backend, 'accept', side_effect=SessionError('OWN pre-peer publication refusal')):
            with self.assertRaisesRegex(SessionError, 'pre-peer publication refusal'):
                controller.start_helper()
        with patch.object(session, 'write_report', side_effect=OSError(errno.ENOSPC, 'OWN refusal publication')):
            with self.assertRaisesRegex(SessionError, 'identity incomplete') as caught:
                controller.finish_refused(self.child, 1)
        self.assertTrue(any('refusal publication' in note for note in getattr(caught.exception, '__notes__', [])))
        self.assertEqual(controller.state, 'refusal_quarantined')
        self.assertFalse(controller.refusal_completion['ownership_complete'])
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def test_refusal_publication_wrong_go_error_already_keeps_primary(self):
        controller = self.setup_controller()
        go = self.child.go_fd
        saved = os.dup(go)
        os.close(go)
        decoy = os.open(self.directory / 'OWN-publication-decoy.json', os.O_CREAT | os.O_WRONLY, 0o600)
        if decoy != go:
            os.dup2(decoy, go)
            os.close(decoy)
        try:
            identity = os.fstat(go).st_ino
            with patch.object(session, 'write_report', side_effect=OSError(errno.ENOSPC, 'OWN GO publication')):
                with self.assertRaisesRegex(SessionError, 'GO endpoint') as caught:
                    controller.finish_refused(self.child, 1)
            self.assertTrue(any('GO publication' in note for note in getattr(caught.exception, '__notes__', [])))
            self.assertEqual(os.fstat(go).st_ino, identity)
        finally:
            os.close(go)
            self.child.go_fd = saved  # OWN fixture teardown only; API remains quarantined.
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def test_refusal_publication_uncertain_go_close_is_not_complete_ownership(self):
        controller = self.setup_controller(start_helper=False)
        go = self.child.go_fd
        real_close = os.close
        injected = []
        def close_then_error(fd):
            if fd == go and not injected:
                injected.append(fd)
                real_close(fd)
                raise OSError(errno.EIO, 'OWN uncertain GO closure')
            return real_close(fd)
        with patch.object(session.os, 'close', side_effect=close_then_error):
            with self.assertRaisesRegex(SessionError, 'closure incomplete'):
                controller.finish_refused(self.child, 1)
        report = json.loads((self.directory / 'refusal-exit.json').read_text())
        self.assertFalse(report['ownership_complete'])
        self.assertTrue(report['known_processes_exited'])
        self.assertEqual(report['driver_exit'], 78)
        self.assertTrue(report['errors'])
        self.assertFalse(self.executed.exists())
        with self.assertRaisesRegex(SessionError, 'terminal'):
            controller.finish_refused(self.child, 1)

    def mapped_setup(self, *, delay=0, corrupt=None):
        import native_perf_mapped_images as mapped
        root=self.directory/'role-proc';role=root/'300';anchor=root/'99999'
        for p in (role,anchor):(p/'map_files').mkdir(parents=True)
        exe=self.directory/'role-dart';native=self.directory/'role-native';driver=self.directory/'role-driver'
        for p,suffix in [(exe,b'dart'),(native,b'native'),(driver,b'driver')]:
            p.write_bytes(b'\x7fELF\x02\x01'+bytes(58)+suffix);p.chmod(0o600)
        spec=dataclasses.replace(self.spec(),driver_path=str(driver),driver_sha=session._sha(driver.read_bytes()))
        argv=(b'dart',b'worker',b'',b'\xff')
        def process(p,pid,parent,start,image,args):
            fields=['S',str(parent)]+['0']*17+[str(start)]
            (p/'stat').write_text(f'{pid} (role fixture) '+ ' '.join(fields)+'\n')
            (p/'status').write_text('Uid:\t'+ '\t'.join([str(spec.controller_uid)]*4)+'\nGid:\t'+'\t'.join([str(spec.controller_gid)]*4)+'\n')
            (p/'cmdline').write_bytes(b'\0'.join(args)+b'\0');(p/'exe').symlink_to(image)
        process(role,300,99999,901,exe,argv);process(anchor,99999,spec.controller_pid,123,driver,(b'driver',))
        st=native.stat();(role/'maps').write_text(f'1000-2000 r-xp 0 {os.major(st.st_dev):x}:{os.minor(st.st_dev):x} {st.st_ino} /ignored (deleted)\n')
        (role/'map_files'/'1000-2000').symlink_to(native)
        target={'role':'client','pid':300,'start_ticks':'901','exe_path':str(exe),'exe_sha256':session._sha(exe.read_bytes()),'native_path':str(native),'native_sha256':session._sha(native.read_bytes()),'argv_hex':[v.hex() for v in argv]}
        backend=FixtureBackend(spec,self.log.fileno());backend.mapped_delay=delay;backend.mapped_corrupt=corrupt
        def collect(request):
            return session._collect_mapped_with_readers(spec,request,session._api().proc.ProcReader.fixture(root),mapped.MappedImageReader.fixture(root,FixtureHandle,artifact_owner_uid=spec.controller_uid),FixtureHandle)
        backend.mapped_collector=collect;self.backends.append(backend)
        return spec,backend,target,root

    def mapped_exchange(self, *, delay=0, corrupt=None):
        spec,backend,target,root=self.mapped_setup(delay=delay,corrupt=corrupt)
        op=session.MappedAuditExchange(spec,backend,'d'*32,target)
        # OWN fixture fallback closes only inert metadata after all known children
        # have been naturally reaped by each test. No live cleanup workaround.
        def close_fixture():
            if op.handle is not None:op.handle.close()
            if op.directory is not None:op.directory.close()
        self.addCleanup(close_fixture)
        return op,target,root

    def test_mapped_transport_positive_natural_reaping_and_raw_context(self):
        op,target,_=self.mapped_exchange();r=op.start()
        self.assertTrue(r['observation']['observed']);self.assertFalse(r['capture_ready']);self.assertTrue(r['fixture_only'])
        self.assertEqual([p['pid'] for p in r['lineage']],[300,99999]);self.assertEqual(r['target_sha256'],session._sha(session._bytes(target)))
        result=op.finish(1);self.assertTrue(result['ownership_complete']);self.assertEqual(result['launcher_exit'],0);self.assertTrue(result['peer_exited'])
        op.close_metadata()

    def test_mapped_transport_terminal_existing_attempt_no_relaunch(self):
        op,_,_=self.mapped_exchange();path=self.directory/('a'+'d'*32+'.json');path.write_bytes(b'partial-terminal')
        with self.assertRaises(FileExistsError):op.start()
        self.assertEqual(path.read_bytes(),b'partial-terminal');self.assertEqual(len(op.backend.children),0)
        with self.assertRaises(SessionError):op.start()
        op.finish(1);op.close_metadata()

    def test_mapped_transport_requires_post_go_controller_state(self):
        spec,backend,target,_=self.mapped_setup();controller=session.SessionController(spec,backend)
        self.addCleanup(controller.directory.close)
        with self.assertRaises(SessionError):controller.start_mapped('d'*32,target)
        self.assertEqual(len(backend.children),0)

    def test_mapped_transport_fixture_cannot_admit_live(self):
        op,target,_=self.mapped_exchange();r=op.start()
        with self.assertRaises(SessionError):session.admit_mapped_report(op.spec,r,op.request_id,target,fixture_only=False)
        op.finish(1);op.close_metadata()

    def test_mapped_transport_pending_natural_wait_no_second_launch(self):
        op,_,_=self.mapped_exchange(delay=.15);op.start()
        with self.assertRaises(SessionError):op.finish(.005)
        self.assertFalse(op.finalized);self.assertEqual(len(op.backend.children),1)
        with self.assertRaises(SessionError):op.close_metadata()
        op.finish(1);op.close_metadata();self.assertEqual(len(op.backend.children),1)

    def test_mapped_transport_unknown_launch_quarantines_null_status(self):
        op,_,_=self.mapped_exchange()
        with patch.object(op.backend,'launch',side_effect=OSError(5,'unconfirmed launch fault')):
            with self.assertRaises(OSError):op.start()
        r=op.finish(1);self.assertIsNone(r['launcher_exit']);self.assertFalse(r['ownership_complete'])
        with self.assertRaises(SessionError):op.close_metadata()

    def test_mapped_transport_partial_final_report_terminal(self):
        op,_,_=self.mapped_exchange();op.start();real=session.write_report
        def partial(directory,name,value):
            if name.startswith('x'):
                with directory.name(name).open('xb') as f:f.write(b'partial')
                raise OSError(errno.ENOSPC,'synthetic report failure')
            return real(directory,name,value)
        with patch.object(session,'write_report',side_effect=partial):
            with self.assertRaises(OSError):op.finish(1)
        with self.assertRaises(SessionError):op.finish(1)
        self.assertEqual((self.directory/('x'+'d'*32+'.json')).read_bytes(),b'partial');op.close_metadata()

    def test_mapped_transport_broken_positive_parent_chain_refuses(self):
        op,_,root=self.mapped_exchange();p=root/'300'/'stat';p.write_text(p.read_text().replace('S 99999 ','S 77777 '))
        with self.assertRaises(SessionError):op.start()
        self.assertIsNotNone(op.report);self.assertIn('error',op.report)
        op.finish(1);op.close_metadata()

    def test_mapped_transport_parent_cycle_refuses(self):
        op,_,root=self.mapped_exchange();p=root/'300'/'stat';p.write_text(p.read_text().replace('S 99999 ','S 300 '))
        with self.assertRaises(SessionError):op.start()
        self.assertIn('cycle',op.report['error']['reason']);op.finish(1);op.close_metadata()

    def test_mapped_transport_bundle_binds_all18_exact_sources(self):
        self.assertEqual(len(session.BUNDLE_FILES),20)
        self.assertIn('native_perf_mapped_images',session.MODULE_ORDER)
        self.assertIn('tool/native_perf_build_producer.py',session.BUNDLE_FILES)

    def test_mapped_transport_oversize_target_before_any_launch(self):
        spec,backend,target,_=self.mapped_setup();target['argv_hex']=['ab'*5000]
        with self.assertRaises(SessionError):session.MappedAuditExchange(spec,backend,'d'*32,target)
        self.assertEqual(len(backend.children),0);self.assertFalse((self.directory/('a'+'d'*32+'.json')).exists())

    def test_mapped_transport_wrong_context_retained_and_owned_exit(self):
        def corrupt(r):r['target_sha256']='f'*64;return r
        op,_,_=self.mapped_exchange(corrupt=corrupt)
        with self.assertRaises(SessionError):op.start()
        self.assertEqual(op.report['target_sha256'],'f'*64)
        result=op.finish(1);self.assertTrue(result['ownership_complete']);self.assertFalse(result['report_admitted']);op.close_metadata()

    def test_mapped_transport_malformed_lineage_is_schema_refusal(self):
        def corrupt(r):r['lineage'][1]=None;return r
        op,_,_=self.mapped_exchange(corrupt=corrupt)
        try:
            with self.assertRaises(SessionError):op.start()
        finally:op.finish(1);op.close_metadata()

    def test_mapped_transport_nested_boolean_mapping_is_schema_refusal(self):
        def corrupt(r):
            r['observation']['mappings'][0]['device_major']=True
            r['observation']['native_mappings'][0]['mapping']['device_major']=True
            return r
        op,_,_=self.mapped_exchange(corrupt=corrupt)
        try:
            with self.assertRaises(SessionError):op.start()
        finally:op.finish(1);op.close_metadata()

    def test_mapped_transport_target_input_is_frozen(self):
        op,target,_=self.mapped_exchange();target['role']='server';target['argv_hex'].append('abcd')
        try:self.assertEqual(op.start()['role'],'client')
        finally:op.finish(1);op.close_metadata()

    def test_mapped_new_ownership_launcher_zero_without_peer_exit_stays_pending(self):
        op,_,_=self.mapped_exchange();op.start()
        with patch.object(op.handle,'wait_exited',side_effect=SessionError('actual peer exit not yet witnessed')):
            with self.assertRaises(SessionError):op.finish(1)
        self.assertEqual(op.launcher_exit,0);self.assertFalse(op.finalized)
        self.assertIsNone(op.peer_exited)
        self.assertTrue(op.finish(1)['ownership_complete']);op.close_metadata()

    def test_mapped_new_ownership_parent_retains_failed_start_operation(self):
        spec,backend,target,_=self.mapped_setup();controller=session.SessionController(spec,backend)
        self.addCleanup(controller.directory.close)
        controller.release_attempted=True  # Explicit synthetic release state; no GO/workload.
        with patch.object(backend,'launch',side_effect=OSError(5,'unconfirmed launch')):
            with self.assertRaises(OSError):controller.start_mapped('d'*32,target)
        self.assertEqual(len(controller.mapped_operations),1)
        op=controller.mapped_operations[0];self.addCleanup(op.directory.close)
        with self.assertRaisesRegex(SessionError,'mapped observer'):controller.close_metadata()
        self.assertFalse(op.finish(1)['ownership_complete'])
        with self.assertRaisesRegex(SessionError,'mapped observer'):controller.close_metadata()

    def test_mapped_new_ownership_bad_boot_quarantines_after_known_natural_exits(self):
        op,_,_=self.mapped_exchange();original=op.backend._identity
        op.backend._identity=lambda:{**original(),'image_sha256':'f'*64}
        with self.assertRaises(SessionError):op.start()
        result=op.finish(1)
        self.assertEqual(result['launcher_exit'],78);self.assertTrue(result['peer_exited'])
        self.assertFalse(result['boot_verified']);self.assertFalse(result['ownership_complete'])
        with self.assertRaises(SessionError):op.close_metadata()

    def test_capture_admission_live_constructor_cannot_skip_preflight(self):
        controller=self.setup_controller(start_helper=False)
        alleged=types.SimpleNamespace(fixture_only=False);attempted=None
        try:
            with self.assertRaisesRegex(RuntimeError,'preflight'):
                attempted=session.SessionController(controller.spec,alleged,blocked_child=self.child)
        finally:
            if attempted is not None:attempted.directory.close()  # Inert OWN fixture metadata only.
