"""Immutable prelaunch contract and terminal reservation; NOT live admission.

Actual own command/image/kernel preflight is unresolved. Neither file-checked
JSON nor a fixture permission can authorize a live capture. Future role outcomes
belong after GO; this module never pretends those already exist before launch.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat

from native_perf_guard import FrozenLaunch
from native_perf_input_census import CensusContext, CheckedCensus, ROLES


class AdmissionError(RuntimeError):pass
class UnresolvedLiveAdmission(AdmissionError):pass

RUNTIME='601108ea6216464bd00ae29c16cfaf0a59c71db6'
POLICY_SHA='197043dd6ff3cd1415177e753978c98bd7792afe079703b43f13567599558e3f'
TOOL_FILES=tuple(sorted('tool/'+prefix+name+'.py' for name in ('native_perf_guard','native_perf_blocked_exec',
    'native_perf_proc_witness','native_perf_handoff','native_perf_session','native_perf_input_census',
    'native_perf_build_producer','native_perf_metadata','native_perf_mapped_images','native_perf_admission') for prefix in ('','test_')))


def _bytes(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _sha(value):return hashlib.sha256(value).hexdigest()
def _digest(value):return type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None

def _json(raw):
    def pairs(items):
        value={}
        for k,v in items:
            if k in value:raise AdmissionError('duplicate declaration field')
            value[k]=v
        return value
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _v:(_ for _ in ()).throw(AdmissionError('nonfinite declaration')))


def _entry(value):
    if (type(value) is not dict or set(value)!={'path','sha256'} or type(value['path']) is not str
            or not Path(value['path']).is_absolute() or '..' in Path(value['path']).parts or not _digest(value['sha256'])):
        raise AdmissionError('invalid declared input entry')
    return dict(value)


_PREPARED=object()


@dataclass(frozen=True,init=False)
class CaptureDeclaration:
    raw: bytes
    _launches: tuple

    def __init__(self,raw,launches,*,_prepared=None):
        if _prepared is not _PREPARED:raise AdmissionError('use validated declaration preparation')
        object.__setattr__(self,'raw',raw);object.__setattr__(self,'_launches',launches)

    @property
    def sha256(self):return _sha(self.raw)
    def as_dict(self):return _json(self.raw)
    def launch(self,index):
        if type(index) is not int or not 0<=index<10:raise AdmissionError('invalid invocation index')
        return self._launches[index]

    @classmethod
    def prepare(cls,*,context,checked,policy_bytes,scenarios,source_root,tool_hashes,extra_files,
                output_dir,environment,gid,nonce):
        if (type(context) is not CensusContext or type(checked) is not CheckedCensus or checked.scope!='file_checks_only'
                or context.runtime_commit!=RUNTIME or type(gid) is not int or not 0<=gid<2**32
                or type(nonce) is not str or re.fullmatch('[0-9a-f]{32}',nonce) is None
                or type(policy_bytes) is not bytes or _sha(policy_bytes)!=POLICY_SHA
                or type(tool_hashes) is not dict or set(tool_hashes)!=set(TOOL_FILES)
                or any(not _digest(v) for v in tool_hashes.values())
                or type(extra_files) is not dict or set(extra_files)!={'perf_elf','python_elf','router_config'}):
            raise AdmissionError('invalid exact prelaunch context')
        source_root,output_dir=Path(source_root),Path(output_dir)
        if (not source_root.is_absolute() or source_root!=source_root.resolve(strict=True)
                or not output_dir.is_absolute() or '..' in output_dir.parts
                or output_dir.parent!=output_dir.parent.resolve(strict=True)
                or output_dir==source_root or source_root in output_dir.parents):
            raise AdmissionError('invalid canonical source/output layout')
        policy=_json(policy_bytes)
        fixed={'runtime_source':RUNTIME,'rows':330,'warmups':3,'repetitions':7,'minimum_duration_ms':10000,
               'minimum_samples':1000,'concurrency':1,'in_flight':1,'router_workers':1,'native_threads':1,'request_response_bytes':65536}
        if any(type(policy.get(k)) is not type(v) or policy[k]!=v for k,v in fixed.items()):
            raise AdmissionError('frozen source policy differs')
        names={r['scenario']+'.toml' for r in policy['runs']}
        if type(scenarios) is not dict or set(scenarios)!=names or len(policy['runs'])!=10:
            raise AdmissionError('all10 original scenarios required')
        if (type(environment) is not dict or any(environment.get(k)!=v for k,v in policy['driver_source_environment_additions'].items())):
            raise AdmissionError('original environment additions differ')
        files={}
        if not set(ROLES)<=set(checked.files):raise AdmissionError('checked input roles incomplete')
        for role,record in checked.files.items():
            files['census/'+role]={**_entry({'path':record['path'],'sha256':record['sha256']}),
                'checked_identity':{k:str(record[k]) for k in ('device','inode','size','owner_uid','mode')}}
        for role,entry in extra_files.items():files[role]=_entry(entry)
        for name in sorted(names):
            entry=_entry(scenarios[name])
            if entry['sha256']!=policy['source_scenario_matches'][name]['selected_sha256']:
                raise AdmissionError('selected source scenario digest differs')
            files['scenario/'+name]=entry
        for relative,digest in tool_hashes.items():files[relative]={'path':str(source_root/relative),'sha256':digest}
        launches=[];runs=[]
        for index,run in enumerate(policy['runs']):
            if len(run['order'])!=33 or run['status']!='planned' or run['rows_completed']!=0:
                raise AdmissionError('frozen invocation schedule differs')
            values={'driver':files['census/driver_elf']['path'],'native_lib':files['census/native_elf']['path'],
                'router_config':files['router_config']['path'],'scenarios':files['scenario/'+run['scenario']+'.toml']['path'],
                'results':str(output_dir/run['results'])}
            argv=tuple(v.format(**values) for v in policy['driver_argv_template'])
            launch=FrozenLaunch.freeze(argv,environment,context.owner_uid,gid);launches.append(launch)
            runs.append({'index':index,'scenario':run['scenario'],'kind':run['kind'],'order':list(run['order']),
                'argv':list(argv),'environment_sha256':_sha(_bytes(launch.environment)),
                'nonce':_sha((nonce+'|'+run['scenario']).encode())[:32],'directory':str(output_dir/('i'+str(index)))})
        value={'scope':'prelaunch_manifest_binding_only','capture_ready':False,'nonce':nonce,'census_id':context.census_id,
            'source_commit':context.source_commit,'runtime_commit':RUNTIME,'owner_uid':context.owner_uid,'gid':gid,
            'sdks':dict(context.sdks),'lock_hashes':{k:dict(v) for k,v in context.lock_hashes.items()},
            'bindings':{k:dict(v) for k,v in checked.bindings.items()},'aliases':[list(v) for v in checked.aliases],
            'policy_sha256':POLICY_SHA,'tool_hashes':dict(tool_hashes),'tool_bundle_sha256':_sha(_bytes({'files':tool_hashes})),
            'source_root':str(source_root),'output_dir':str(output_dir),'files':files,'runs':runs,
            'unresolved':['actual independent command/SDK/compiler/source/config/native provenance',
                'real Linux access/credential/pidfd/FDexec/inheritance/arming/metadata controls',
                'future role outcomes/clock/metadata association after GO; retain every partial/unknown/lost record']}
        return cls(_bytes(value),tuple(launches),_prepared=_PREPARED)


@dataclass(frozen=True)
class FixturePreflight:
    declaration_sha256: str
    def __post_init__(self):
        if not _digest(self.declaration_sha256):raise AdmissionError('invalid fixture evaluation digest')
    @property
    def fixture_only(self):return True


def require_live_admission(_alleged):
    # No JSON, checked-file object, fixture, or caller boolean substitutes for
    # actual independently produced preflight. No live provider exists yet.
    raise UnresolvedLiveAdmission('actual independent live preflight provider is unresolved; live capture is closed')


class CaptureReservation:
    """Terminal private reservation with held input FDs; fixture stages only."""
    def __init__(self,declaration):
        if type(declaration) is not CaptureDeclaration:raise AdmissionError('exact immutable declaration required')
        self.declaration=declaration;self._data=declaration.as_dict();self._sha=declaration.sha256
        self.path=Path(self._data['output_dir']);self._fds={};self._identities={};self._directory=None;self.closed=False
        self._expected=('START',0);self._terminal=False;self.evidence=[]
        self.path.mkdir(mode=0o700)  # Existing/partial namespace stays terminal forever.
        try:
            self._directory=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self._dir_identity=self._identity(os.fstat(self._directory))[:2]
            self._write('attempt.json',{'declaration_sha256':self._sha,'declaration':self._data,'capture_ready':False})
            for role,entry in self._data['files'].items():self._pin(role,entry)
            (self.path/'runs').mkdir(mode=0o700)
            for run in self._data['runs']:
                p=Path(run['directory']);p.mkdir(mode=0o700);(p/'markers').mkdir(mode=0o700)
        except BaseException as primary:
            try:self._write('reservation-refused.json',{'error':type(primary).__name__,'errno':getattr(primary,'errno',None),'reason':str(primary),'evidence':self.evidence})
            except BaseException as secondary:primary.add_note('reservation evidence failure: '+repr(secondary))
            try:self.close()
            except BaseException as secondary:primary.add_note('reservation cleanup failure: '+repr(secondary))
            raise

    @staticmethod
    def _identity(info):
        return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_size,info.st_mtime_ns,info.st_ctime_ns)

    def _directory_check(self):
        if self._directory is None:raise AdmissionError('reservation metadata is closed')
        info=self.path.lstat();opened=os.fstat(self._directory)
        if (not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode)!=0o700 or info.st_uid!=self._data['owner_uid']
                or (info.st_dev,info.st_ino)!=self._dir_identity or (opened.st_dev,opened.st_ino)!=self._dir_identity):
            raise AdmissionError('reservation directory identity differs')

    def _write(self,name,value):
        self._directory_check();fd=None;primary=None
        try:
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self._directory)
            data=_bytes(value);offset=0
            while offset<len(data):
                count=os.write(fd,data[offset:])
                if count<=0:raise AdmissionError('invalid reservation write progress')
                offset+=count
            os.fsync(fd);os.fsync(self._directory);self._directory_check()
        except BaseException as error:primary=error;raise
        finally:
            if fd is not None:
                owned,fd=fd,None
                try:os.close(owned)
                except BaseException as error:
                    if primary is None:raise
                    primary.add_note('reservation write close failure: '+repr(error))

    def _hash(self,role,fd,path):
        before=os.fstat(fd);event={'role':role,'path':str(path),'bytes_read':0};self.evidence.append(event)
        digest=hashlib.sha256()
        try:
            owners={self._data['owner_uid']}
            if role in ('perf_elf','python_elf'):owners.add(0)
            if (not stat.S_ISREG(before.st_mode) or before.st_uid not in owners or before.st_mode&0o6022
                    or not 0<before.st_size<=2*1024**3):raise AdmissionError('unsafe bounded declared input')
            expected=self._data['files'][role].get('checked_identity')
            if expected is not None and expected!={k:str(v) for k,v in {'device':before.st_dev,'inode':before.st_ino,'size':before.st_size,'owner_uid':before.st_uid,'mode':before.st_mode}.items()}:
                raise AdmissionError('checked census file instance changed')
            pos=0
            while pos<before.st_size:
                chunk=os.pread(fd,min(1024**2,before.st_size-pos),pos)
                if not chunk:raise AdmissionError('short declared input read')
                pos+=len(chunk);digest.update(chunk);event.update(bytes_read=pos,partial_sha256=digest.hexdigest())
            ident=self._identity(before)
            if (self._identity(os.fstat(fd))!=ident or self._identity(path.lstat())!=ident
                    or path.resolve(strict=True)!=path):raise AdmissionError('declared input identity changed')
            if digest.hexdigest()!=self._data['files'][role]['sha256']:raise AdmissionError('declared input bytes changed')
            if role in self._identities and ident!=self._identities[role]:raise AdmissionError('pinned input instance changed')
            event['identity']=[str(v) for v in ident]
            return ident
        except BaseException as error:event.update(error=type(error).__name__,errno=getattr(error,'errno',None));raise

    def _pin(self,role,entry):
        path=Path(entry['path'])
        if path.resolve(strict=True)!=path or not stat.S_ISREG(path.lstat().st_mode):raise AdmissionError('declared input must be canonical regular file')
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        self._fds[role]=fd  # Register before fallible hash/flag work.
        os.set_inheritable(fd,False);self._identities[role]=self._hash(role,fd,path)

    def recheck(self):
        self._directory_check()
        if self.declaration.sha256!=self._sha:raise AdmissionError('immutable declaration digest changed')
        for role,fd in self._fds.items():self._hash(role,fd,Path(self._data['files'][role]['path']))

    def _refuse(self,primary,stage,index):
        self._terminal=True
        try:self._write('fixture-refused.json',{'capture_ready':False,'fixture_only':True,'stage':stage,'index':index,
            'error':type(primary).__name__,'reason':str(primary),'evidence':self.evidence})
        except BaseException as secondary:primary.add_note('fixture refusal evidence failed: '+repr(secondary))

    def authorize_fixture(self,stage,index,provider):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(provider) is not FixturePreflight or provider.declaration_sha256!=self._sha
                    or type(index) is not int or (stage,index)!=self._expected):
                raise AdmissionError('fixture stage or evaluated declaration differs')
            self._expected=('IN_PROGRESS',index)  # Ambiguous publication is terminal, never retry.
            self.recheck()
            value={'kind':'fixture_only_permission','capture_ready':False,'declaration_sha256':self._sha,'stage':stage,'index':index}
            self._write(f'fixture-{index}-{stage.lower()}.json',value)
            self._expected=({'START':'ENABLE','ENABLE':'GO','GO':'FINISH'}[stage],index)
            return value
        except BaseException as primary:
            self._refuse(primary,stage,index)
            raise

    def finish_fixture(self,index,*,driver_exit,sampler_exit,rows):
        if self._terminal or self.closed:raise AdmissionError('reservation is permanently terminal')
        try:
            if (type(index) is not int or ('FINISH',index)!=self._expected or type(driver_exit) is not int
                    or type(sampler_exit) is not int or type(rows) is not int or not 0<=rows<=33):
                raise AdmissionError('invalid fixture finish')
            self._expected=('IN_PROGRESS',index)
            value={'capture_ready':False,'fixture_only':True,'driver_exit':driver_exit,'sampler_exit':sampler_exit,'rows':rows,'index':index}
            self._write(f'fixture-{index}-finish.json',value)
            if driver_exit==sampler_exit==0 and rows==33 and index<9:self._expected=('START',index+1)
            else:self._expected=('TERMINAL',index);self._terminal=True
            return value
        except BaseException as primary:
            self._refuse(primary,'FINISH',index)
            raise

    def bind_fixture_session(self,spec,index):
        if type(index) is not int or not 0<=index<10:raise AdmissionError('invalid sealed invocation index')
        run=self._data['runs'][index]
        if (spec.declaration!=self._sha or spec.nonce!=run['nonce'] or spec.directory!=run['directory']
                or spec.controller_uid!=self._data['owner_uid'] or spec.controller_gid!=self._data['gid']
                or spec.driver_path!=self._data['files']['census/driver_elf']['path']
                or spec.driver_sha!=self._data['files']['census/driver_elf']['sha256']
                or spec.perf_path!=self._data['files']['perf_elf']['path'] or spec.perf_sha!=self._data['files']['perf_elf']['sha256']
                or spec.bootstrap_image!=self._data['files']['python_elf']['sha256'] or spec.bundle_sha!=self._data['tool_bundle_sha256']):
            raise AdmissionError('session differs from sealed invocation')

    def close(self):
        if self.closed:return
        self.closed=True;errors=[]
        for role in list(self._fds):
            fd=self._fds.pop(role)
            try:os.close(fd)
            except BaseException as error:errors.append(error)
        fd,self._directory=self._directory,None
        if fd is not None:
            try:os.close(fd)
            except BaseException as error:errors.append(error)
        if errors:
            for error in errors[1:]:errors[0].add_note('secondary close failure: '+repr(error))
            raise errors[0]
