"""Synthetic census/ELF/log fixtures only; no live provider or runtime capture."""
import hashlib
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

import native_perf_admission as admission
from native_perf_guard import FrozenLaunch
from test_native_perf_input_census import InputCensusTests

BASE=Path(os.environ['CONNECTANUM_PERF_ADMISSION_FIXTURES']).resolve()
REPO=Path(__file__).resolve().parent.parent
POLICY=Path('/tmp/connectanum-601-native-perf-source-policy-binding.json')
SCENARIOS=Path('/tmp/connectanum-601-native-perf-source-policy-binding/selected-generator/scenarios')


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.root=BASE/self._testMethodName;self.root.mkdir(parents=True)
        self.fixture=InputCensusTests('runTest');self.fixture.setUp();self.fixture._testMethodName=self._testMethodName
        self.addCleanup(self.fixture.doCleanups)
        self.checked=self.fixture.verify();self.context=self.fixture.context
        self.env={'CONNECTANUM_SKIP_NATIVE_BUILD':'1','CONNECTANUM_BENCH_WAMP_REUSE_WORKER':'1','OWN_SECRET':'do-not-publish-this-value'}
        self.extra={}
        for name in ['perf_elf','python_elf','router_config']:
            p=self.root/name;p.write_bytes(b'OWN synthetic '+name.encode());p.chmod(0o600)
            self.extra[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        self.scenarios={}
        for p in sorted(SCENARIOS.glob('*.toml')):
            target=self.root/p.name;target.write_bytes(p.read_bytes());target.chmod(0o600)
            self.scenarios[p.name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
        self.tools={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in REPO.glob('tool/*native_perf*.py')}
        self.kwargs=dict(context=self.context,checked=self.checked,policy_bytes=POLICY.read_bytes(),scenarios=self.scenarios,
            source_root=REPO,tool_hashes=self.tools,extra_files=self.extra,output_dir=self.root/'capture',
            environment=self.env,gid=os.getegid(),nonce='c'*32)
        self.reservations=[];self.addCleanup(self.close_all)

    def close_all(self):
        for reservation in self.reservations:reservation.close()

    def declaration(self,**changes):return admission.CaptureDeclaration.prepare(**{**self.kwargs,**changes})
    def reservation(self):
        value=admission.CaptureReservation(self.declaration());self.reservations.append(value);return value

    def test_policy_all10_original_order_330_proposed_rows(self):
        decl=self.declaration();value=decl.as_dict();policy=json.loads(POLICY.read_bytes())
        self.assertEqual([x['scenario'] for x in value['runs']],[x['scenario'] for x in policy['runs']])
        self.assertEqual([x['order'] for x in value['runs']],[x['order'] for x in policy['runs']])
        self.assertEqual(sum(len(x['order']) for x in value['runs']),330)
        self.assertEqual(value['scope'],'prelaunch_manifest_binding_only');self.assertFalse(value['capture_ready'])
        self.assertEqual(len(value['tool_hashes']),20)

    def test_original_argv_and_env_values_never_published(self):
        decl=self.declaration();value=decl.as_dict();launch=decl.launch(0)
        self.assertIsInstance(launch,FrozenLaunch)
        self.assertEqual(launch.argv[1:3],('--dart','dart'));self.assertIn('--collect-wamp-vm-metrics',launch.argv)
        self.assertNotIn(self.env['OWN_SECRET'],json.dumps(value));self.assertEqual(dict(launch.environment),self.env)

    def test_declaration_deep_freeze_not_mutable_alias(self):
        decl=self.declaration();old=decl.raw
        self.env['OWN_SECRET']='changed';self.tools.clear();self.extra['perf_elf']['sha256']='f'*64
        v=decl.as_dict();v['runs'][0]['order'].reverse()
        self.assertEqual(decl.raw,old);self.assertEqual(dict(decl.launch(0).environment)['OWN_SECRET'],'do-not-publish-this-value')

    def test_wrong_policy_or_subset_refuses(self):
        with self.assertRaises(admission.AdmissionError):self.declaration(policy_bytes=b'{}')
        broken=dict(self.scenarios);broken.pop(next(iter(broken)))
        with self.assertRaises(admission.AdmissionError):self.declaration(scenarios=broken)

    def test_changed_scenario_bytes_refuses_before_fixture_start(self):
        r=self.reservation();p=Path(next(iter(self.scenarios.values()))['path']);p.write_bytes(b'changed')
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))
        self.assertTrue((self.root/'capture'/'attempt.json').is_file())

    def test_changed_pinned_native_retains_terminal_reservation(self):
        r=self.reservation();Path(self.checked.files['native_elf']['path']).write_bytes(b'changed ELF')
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))
        with self.assertRaises(FileExistsError):admission.CaptureReservation(self.declaration())

    def test_existing_partial_output_directory_forever_terminal(self):
        out=self.root/'capture';out.mkdir();(out/'attempt.json').write_bytes(b'partial')
        with self.assertRaises(FileExistsError):admission.CaptureReservation(self.declaration())
        self.assertEqual((out/'attempt.json').read_bytes(),b'partial')

    def test_pinned_fd_sourcepath_replacement_refuses(self):
        r=self.reservation();p=Path(self.extra['router_config']['path']);old=p.with_suffix('.retained');p.rename(old);p.write_bytes(old.read_bytes());p.chmod(0o600)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight(r.declaration.sha256))

    def test_fixture_stages_strict_order_and_expected_evaluation_digest(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('GO',0,p)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',0,admission.FixturePreflight('f'*64))
        self.assertEqual(r.authorize_fixture('START',0,p)['kind'],'fixture_only_permission')
        r.authorize_fixture('ENABLE',0,p);r.authorize_fixture('GO',0,p)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',1,p)
        r.finish_fixture(0,driver_exit=0,sampler_exit=0,rows=33)
        r.authorize_fixture('START',1,p)

    def test_nonzero_partial_fixture_finish_retains_status_and_stops(self):
        r=self.reservation();p=admission.FixturePreflight(r.declaration.sha256)
        for stage in ['START','ENABLE','GO']:r.authorize_fixture(stage,0,p)
        value=r.finish_fixture(0,driver_exit=-15,sampler_exit=2,rows=4)
        self.assertEqual(value['driver_exit'],-15);self.assertEqual(value['rows'],4)
        with self.assertRaises(admission.AdmissionError):r.authorize_fixture('START',1,p)

    def test_live_authorization_cannot_be_minted_by_json_or_fixture(self):
        r=self.reservation()
        for alleged in [None,{'ready':True,'capture_ready':True},admission.FixturePreflight(r.declaration.sha256)]:
            with self.assertRaises(admission.UnresolvedLiveAdmission):admission.require_live_admission(alleged)
        self.assertFalse(r.declaration.as_dict()['capture_ready'])

    def test_twenty_tool_set_and_scalar_types_refuse(self):
        bad=dict(self.tools);bad.pop(next(iter(bad)))
        with self.assertRaises(admission.AdmissionError):self.declaration(tool_hashes=bad)
        with self.assertRaises(admission.AdmissionError):self.declaration(gid=True)
        with self.assertRaises(admission.AdmissionError):self.declaration(nonce='not-hex')

    def test_close_relinquishes_fd_ownership_once(self):
        r=self.reservation();real=os.close
        def uncertain(fd):real(fd);raise OSError(5,'synthetic close ambiguity')
        with patch('native_perf_admission.os.close',side_effect=uncertain) as close:
            with self.assertRaises(OSError):r.close()
            count=close.call_count;r.close();self.assertEqual(close.call_count,count)


if __name__=='__main__':unittest.main()
