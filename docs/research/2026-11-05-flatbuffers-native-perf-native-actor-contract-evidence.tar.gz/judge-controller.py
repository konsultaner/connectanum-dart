import pathlib,hashlib,importlib.util,json,subprocess,sys,os
P=pathlib.Path('/tmp/connectanum-native-perf-native-actor-contract-v1')
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q=P/'judge';Q.mkdir()
 def save(name,obj):
  with (Q/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 context=(P/'native-actor-contract-candidate.md').read_bytes();assert len(context)<20000
 with (Q/'context.txt').open('xb') as f:f.write(context)
 prompt='Review this NEW UNIMPLEMENTED static contract. Give at most four concrete issues and an evidence-bounded recommendation. Do not treat clone3, cgroup, validator, or keeper crash behavior as executed/proved. Direct-child creation is not transitive SDK actor closure. Preserve original argv/env/UID/GID/SDK/cohort and no freezes/capability grants/host selection/global scans/retries. Identify a permissible next proof, or state that no live invocation is justified. No Source fix from static inference, no fixture-to-live retagging, no self-authorized expected output hashes. Distinguish missing mechanism from missing requirement.'
 argv=[sys.executable,str(h),'judge','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--prompt',prompt,'--reasoning-budget','512','--num-predict','2048','--timeout','300','--max-input-chars','20000','--save-output',str(Q/'answer.txt')]
 save('command-before.json',dict(argv=argv,context_size=len(context),context_sha256=sha(context),Popen_attempted=True,pid=None))
 p=subprocess.Popen(argv,cwd='/tmp',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
 save('native-handles-before-IO.json',dict(pid=pid,original_bound_wait_streams_retained=True))
 out,err=p.communicate(input=context);status=wait(10)
 for role,b in [('stdout',out),('stderr',err)]:
  with (Q/(role+'.bin')).open('xb') as f:f.write(b)
 result=dict(pid=pid,status=status,both_separate_EOF=True,signed_native_int=type(status) is int,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err),complete_answer_exists=(Q/'answer.txt').is_file(),no_native_SDK_workload=True)
 save('result.json',result);lease.verify_identity();print(json.dumps(result))
