
import pathlib,hashlib,json,datetime,importlib.util,subprocess,stat,tarfile,io
P=pathlib.Path('/tmp/connectanum-native-perf-native-actor-contract-v1')
D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
EXPECTED='a478b4631eb9460f977a9fb33302fe28b06f4e88'
PREFIX='docs/research/2026-11-05-flatbuffers-native-perf-native-actor-contract'
SCOPE='NEW static native direct-actor/FD and independent generated-input contract; UNIMPLEMENTED, zero new tests/SDK/syscalls'
common="## 2026-11-05 — Bound a native actor-creation and generated-input contract\n\nA new static candidate specifies direct child creation with an original kernel pidfd and a preallocated actor/pipe registry. A later ROOT refinement proposes a shared atomic registration barrier and gives a conditional ordering argument. Both remain unimplemented: ABI, signal paths, child close journals, error handling and physical lease lifetime have no native execution proof.\n\nThe direct reference does not register descendants created inside an unchanged shell, Dart/pub or Cargo/compiler tree. Cgroup population and PID lists cannot supply the required actor/FD/exec/exit evidence; a new group, migration, freeze or privilege grant is not proposed. No original-host access or syscall was probed. Independent output validation is also contract-only: policy provenance, exact slot/search closure, bench first-writer schedule and validator implementation remain absent.\n\nGLM's complete judgment recommends changes and is ROOT-qualified. Its claim about exhaustive kernel mechanisms is unsupported, and its proposed experiment is not authorized by this prose. GLM reviewed the first candidate, not ROOT's later paper barrier. No current twenty-helper/runtime source operation, new test, SDK/recipe/build/native syscall or capture occurred. Provider remains absent and all admission flags false; original-runtime qualification, RAM repair, final strict 48/50 and clean final CI remain incomplete.\n\n"
note="# Native actor-creation and generated-input contract\n\n## 2026-11-05 — Bound a native actor-creation and generated-input contract\n\nA new static candidate specifies direct child creation with an original kernel pidfd and a preallocated actor/pipe registry. A later ROOT refinement proposes a shared atomic registration barrier and gives a conditional ordering argument. Both remain unimplemented: ABI, signal paths, child close journals, error handling and physical lease lifetime have no native execution proof.\n\nThe direct reference does not register descendants created inside an unchanged shell, Dart/pub or Cargo/compiler tree. Cgroup population and PID lists cannot supply the required actor/FD/exec/exit evidence; a new group, migration, freeze or privilege grant is not proposed. No original-host access or syscall was probed. Independent output validation is also contract-only: policy provenance, exact slot/search closure, bench first-writer schedule and validator implementation remain absent.\n\nGLM's complete judgment recommends changes and is ROOT-qualified. Its claim about exhaustive kernel mechanisms is unsupported, and its proposed experiment is not authorized by this prose. GLM reviewed the first candidate, not ROOT's later paper barrier. No current twenty-helper/runtime source operation, new test, SDK/recipe/build/native syscall or capture occurred. Provider remains absent and all admission flags false; original-runtime qualification, RAM repair, final strict 48/50 and clean final CI remain incomplete.\n\n\nThe proposed native helper would use `clone3` with `CLONE_PIDFD`, without sharing FD tables or introducing namespaces/cgroups. The manual documents a child pidfd in parent storage; that direct reference does not establish a whole SDK process tree. See [clone(2)](https://man7.org/linux/man-pages/man2/clone.2.html).\n\nKernel cgroup documentation describes inherited membership, possible migration, non-atomic PID enumeration and live-process population. These observations do not establish signed reaping, actor identity or complete FD/exec ownership. No cgroup access, control or migration operation ran. See [cgroup v2](https://docs.kernel.org/admin-guide/cgroup-v2.html). Applying these API facts to reject a closure shortcut is ROOT's inference; original-host behavior remains unmeasured.\n\nThe paper barrier requires the child to perform only lock-free shared-atomic loads before parent registration succeeds. The parent would publish readiness with release ordering, and the child would use acquire ordering before its separately journaled close/read/exec continuation. That argument is conditional on an independently qualified native implementation and ABI. Parent failure keeps the proposed gate closed; crash survival, scheduling cost, native error outcomes and continuous physical EX remain unproved. It supplies no SDK or frozen-driver change authority.\n\nGenerated observations remain UNADMITTED. A separate validator and predeclared original-cohort policy must supply authority; the candidate, schema, absence statement and generator's own hashes cannot create it. Historical LOCAL/HOSTED cohorts remain distinct. No borrowed bytes, expected-hash filling, extra unlock/metadata recipe or favorable regeneration is permitted.\n\nThe full proposal, ROOT refinement, model answer and qualifications are retained in the evidence archive. New primary web tool returns stay local; the public index records their exact saved-return SHA/size and source URLs, not a full-page body hash. Initial checkpoint metadata was read without SH and supplies DATA only. The first combined documentation/policy output truncated; the entire frozen policy was then read under official SH. Neither omission was reconstructed.\n\nNext work must specify native ABI/signal/FD-close/error/lease obligations before any finite non-SDK experiment, and separately establish a permitted original transitive registration mechanism and independent cohort authority. This static contract authorizes no invocation or admission.\n"
h=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');s=h.stat();assert(s.st_uid,s.st_gid,s.st_size)==(501,20,35983);assert hashlib.sha256(h.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8';sp=importlib.util.spec_from_file_location('companion',h);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();Q=P/'publication-v1';Q.mkdir();commands=[]
 def git(*args):
  i=len(commands);argv=['git',*args];save(Q/f'git-{i}-attempt-before.json',dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None))
  p=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=p.wait;pid=p.pid;outstream=p.stdout;errstream=p.stderr
  save(Q/f'git-{i}-handles-before-IO.json',dict(pid=pid,original_bound_wait_streams_retained=True))
  out,err=p.communicate();status=wait(10)
  for role,b in [('stdout',out),('stderr',err)]:
   with (Q/f'git-{i}-{role}.bin').open('xb') as f:f.write(b)
  row=dict(argv=argv,pid=pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=sha(out),stderr_sha256=sha(err));commands.append(row);save(Q/f'git-{i}-result.json',row);assert status==0
  return out
 assert git('rev-parse','HEAD').decode().strip()==EXPECTED
 assert git('branch','--show-current').decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git('status','--porcelain','--untracked-files=all')==b''
 files=[D/'docs/project_state.md',D/'docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',D/(PREFIX+'-preparation.md'),D/(PREFIX+'-assessment.json'),D/(PREFIX+'-evidence.tar.gz')]
 assert all(not x.exists() for x in files[2:])
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 excluded={'actual-primary-web-tool-returns.json'};selected=[]
 for f in sorted(P.rglob('*')):
  if Q in f.parents or f==Q or str(f.relative_to(P)) in excluded:continue
  st=f.lstat()
  if stat.S_ISDIR(st.st_mode):continue
  assert stat.S_ISREG(st.st_mode),str(f);b=f.read_bytes();assert len(b)<=120*1024*1024
  selected.append(dict(path=str(f.relative_to(P)),size=len(b),sha256=sha(b)))
 save(P/'selected-member-manifest.json',dict(scope=SCOPE,members=selected,selected_regular_members_without_this_manifest=len(selected),LOCAL_ONLY_excluded=list(excluded),no_old_Source20_runtime_SDK_or_archive_scan=True))
 b=(P/'selected-member-manifest.json').read_bytes();members=selected+[dict(path='selected-member-manifest.json',size=len(b),sha256=sha(b))]
 with files[4].open('xb') as out:
  with tarfile.open(fileobj=out,mode='w:gz') as tf:
   for row in members:
    b=(P/row['path']).read_bytes();assert len(b)==row['size'] and sha(b)==row['sha256'];info=tarfile.TarInfo(row['path']);info.size=len(b);info.mode=0o644;tf.addfile(info,io.BytesIO(b))
 with tarfile.open(files[4],'r:gz') as tf:
  actual=tf.getmembers();assert len(actual)==len(members) and all(v.isfile() for v in actual)
  for entry,row in zip(actual,members):
   b=tf.extractfile(entry).read();assert entry.name==row['path'] and b==(P/row['path']).read_bytes() and sha(b)==row['sha256']
 archive_sha=sha(files[4].read_bytes())
 assessment['public_evidence']=dict(archive=PREFIX+'-evidence.tar.gz',sha256=archive_sha,selected_regular_members=len(members),all_selected_BYTEEXACT=True,scope=SCOPE,full_primary_tool_returns_LOCAL_ONLY=True)
 save(files[3],assessment)
 with files[2].open('x') as f:f.write(note+'\n[Assessment](2026-11-05-flatbuffers-native-perf-native-actor-contract-assessment.json), [evidence](2026-11-05-flatbuffers-native-perf-native-actor-contract-evidence.tar.gz).\n')
 for path,rel in [(files[0],'research/'),(files[1],'../research/')]:
  text=path.read_text();anchor='## 2026-11-05 — Preserve the keeper lease through a publication failure';assert text.count(anchor)==1
  links=f'[Declaration and limits]({rel}2026-11-05-flatbuffers-native-perf-native-actor-contract-preparation.md), [assessment]({rel}2026-11-05-flatbuffers-native-perf-native-actor-contract-assessment.json), [evidence]({rel}2026-11-05-flatbuffers-native-perf-native-actor-contract-evidence.tar.gz).\n\n'
  path.write_text(text.replace(anchor,common+links+anchor,1))
 names=[str(v.relative_to(D)) for v in files]
 assert {v[3:] for v in git('status','--porcelain','--untracked-files=all').decode().splitlines()}==set(names)
 git('add','--',*names);git('diff','--cached','--check')
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(names)
 git('commit','-m','docs: bound native actor and input authority contract')
 commit=git('rev-parse','HEAD').decode().strip();git('push','origin','codex/flatbuffers-acceptance-status')
 assert git('status','--porcelain','--untracked-files=all')==b''
 lease.verify_identity();receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=commit,archive_sha256=archive_sha,selected_regular_members=len(members),all_selected_BYTEEXACT=True,scope=SCOPE,docs_only_files=names,git_commands=commands,Source_commitpush_adoption=False,full_admission=False)
 save(P/'publication-readback.json',receipt)
 path=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');cp=json.loads(path.read_text());n=cp['native_perf_only_diagnostic_design']
 n['native_actor_contract']=dict(directory=str(P),declaration=str(P/'declaration.json'),ROOT_assessment=str(P/'ROOT-assessment.json'),candidate=str(P/'native-actor-contract-candidate.md'),refinement=str(P/'ROOT-refinement.md'),publication=receipt,new_tests=0,Source20_runtime_operations=0,original_SDK_native_or_cgroup_calls=0,GLM_judge_pid=65808,GLM_full_natural0_ROOT_qualified=True,direct_barrier_UNIMPLEMENTED=True,transitive_mechanism='ABSENT',independent_output_authority='ABSENT',full_admission=False,docs_pending=False,descriptions_pending=False,GitHub_description_update_not_needed='Static proposal changes no production runtime or incomplete-admission claims; saved description remains accurate.',automation_pending=True)
 n['phase']='Native_actor_output_contract_static_UNIMPLEMENTED_docs_complete_original_admission_incomplete';n['next']=assessment['next']
 cp['status_docs_commit']=commit;cp['active_turn_status']='Native_actor_output_contract_docs_complete_admin_pending';cp['updated_utc']=receipt['utc']
 cp['last_heartbeat_summary']='NEW static native direct-clone3/pidfd/FD registry candidate and ROOT shared-atomic registration-barrier refinement UNIMPLEMENTED. GLM65808 natural0/full7242out1026err/BOTH EOF ROOTqualified/recommendCHANGE; no universal kernel-mechanism impossibility or host availability proof. Transitive SDK registration, independent output/cohort policy authority and original physicalEX/crash qualification ABSENT. New primary clone/cgroup docs only/no old ptrace/UAPI replay; full actual web returns local-only/index hashes tool-return not webpage. Initial checkpoint read lackedSH DATAonly; full frozen policy later completely read after combined-output truncation; no omitted records reconstructed. ZERO Source20/runtime edits/imports/census/tests/SDK-build-native-cgroup-capture/adoption. Full admission/RAMrepair/final48-50CI incomplete.'
 path.write_text(json.dumps(cp,indent=2)+'\n')
 print(json.dumps({k:receipt[k] for k in ['docs_commit','archive_sha256','selected_regular_members','all_selected_BYTEEXACT']}))
