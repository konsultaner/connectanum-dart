import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,re,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-include-child-regular-inputs-v1/Actions-v1';P=B/'2026-11-07-actions-include-child-regular-interiors-v1'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST NEW bounded saved-data physical interpretation of ALL1199regular child BODY streams fromActions42357611946/source405a896d8610307ca07b065bbcc6eac261974bf2. This question has no previous body interpretation; allold160body/question/query/model/acquisition scopes remain CONSUMED. Exact originalsavedresult/its original-index-derived member bindings ONLYlocate savedmembers and preserve originalmetadata; no report-journalcomparison/acquisition/SDKhashrefresh. Every1199exact local OWNartifact source/[0,original_saved_size) declaration saved BEFOREbodyIO. Physical LF lines/first-space-tab-skipped#byte candidates/literalkeyword/include operand delimiters and literalbackslash-LF/CRLF flags ONLY; comments-splicing-macros-conditions-Ctokenization/effective directives-dependencies UNEVALUATED. Allbodyrawcandidate-lines andfullstat-times PRIVATE. All1280metadata/49separate-parent-child-queryepochs/1199latelexicalepoch/63dirsDEFERRED/18rawlinksUNEXPANDED-UNFOLLOWED/oldtopncurses.h-curses.h originalrawhexNOTsavedNULL/allpriorledgers unchanged. No includeoperand joins/pathsplit/normalization/aliasdedup/resolve/follow/recursion/nativequery/headerimport-compile-execute/bootstrap/build/Actions/numerical/Source20-runtime adoption. PointcountSHA/stat/close notatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission; allunknownpartial/crashoutcomespermanentquarantine.',
 'exact_saved_locator':{'path':str(A/'ROOT-NEW-ALL1199-regular-child-input-assessment-PRIVATE.json'),'range':[0,8247935],'bytes':8247935,'sha256':'da9687e243a235c51a8c161f4a9012b0b105ace2ff7fc00f3b7930e9f7bfb8c5'},
 'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[];keyword=collections.Counter();operands=[];files=[];allrows=[];totalbytes=0;totalphysical=0;allbackLF=0;allbackCRLF=0
 def read_exact(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_saved_bytes':size,'expected_saved_sha256':expected,'open_return_fd':None,'close_return_fd':None}
  bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd
  try:
   s=os.fstat(fd);before={k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns']};binding['before']=before;assert stat.S_ISREG(s.st_mode) and s.st_size==size
   parts=[];sha=hashlib.sha256();count=0
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyEOF terminal/no replay';parts.append(chunk);sha.update(chunk);count+=len(chunk)
   eof=os.read(fd,1);assert eof==b'';z=os.fstat(fd);after={k:getattr(z,k) for k in before};binding.update(after=after,bytes=count,sha256=sha.hexdigest(),EOF=True);assert before==after and count==size and sha.hexdigest()==expected
   return b''.join(parts)
  finally:
   os.close(fd);binding['close_return_fd']=fd
 loc=declaration['exact_saved_locator'];originalraw=read_exact(pathlib.Path(loc['path']),loc['bytes'],loc['sha256'],'NEW1199physicalscope_savedmetadata_locator_ONLY');original=json.loads(originalraw);assert original['run_id']==42357611946 and original['source_commit']=='405a896d8610307ca07b065bbcc6eac261974bf2';scope=original['NEW_ALL1199_exact_public_safe_scope'];refs=original['ALL1199_source_refs'];rows=original['ALL1199_new_stream_bindings'];assert len(rows)==len(refs)==1199 and [x['source_reference'] for x in rows]==refs and len(scope['ALL1280_original_safe_metadata'])==1280 and len(scope['ALL63_newchild_directories_DEFERRED_NO_query_recursion'])==63 and len(scope['ALL18_newchild_symlinks_UNEXPANDED_UNFOLLOWED'])==18
 plan=[]
 for ordinal,row in enumerate(rows,1):
  member=pathlib.PurePosixPath(row['saved_member']);assert not member.is_absolute() and '..' not in member.parts;path=A/'artifact-members'/row['saved_member']
  plan.append({'ordinal':ordinal,'saved_source':str(path),'source_reference_earlier_explicit_lexical_epoch':row['source_reference'],'original_index_member':row['saved_member'],'range':[0,row['bytes']],'bytes':row['bytes'],'sha256':row['sha256']})
 save('ALL1199-exact-saved-sources-ranges-BEFORE-body-IO.json',json.dumps({'scope':'FIRST newphysicalinterpretation boundedranges declaration; original-index-derived savedmembers ONLYlocators/not effectiveinclude/SDKquery/ownership proof','original_source_run':42357611946,'original_source_commit':original['source_commit'],'ALL1199':plan,'all_prior_metadata_preserved_UNCHANGED':scope,'all_admission_flags':False},ensure_ascii=True,indent=2))
 save('original-full-locator-bound-PRIVATE.json',originalraw)
 for entry in plan:
  raw=read_exact(pathlib.Path(entry['saved_source']),entry['bytes'],entry['sha256'],'FIRST_NEW1199_savedregular_physical_body');totalbytes+=len(raw);phys=raw.count(b'\n')+bool(raw and not raw.endswith(b'\n'));totalphysical+=phys;blf=raw.count(b'\\\n');bcrlf=raw.count(b'\\\r\n');allbackLF+=blf;allbackCRLF+=bcrlf
  try:raw.decode('utf-8');utf8=True
  except UnicodeDecodeError:utf8=False
  fc=collections.Counter();candidates=0;ops=0;offset=0;previous_lf=False;previous_crlf=False
  lines=raw.split(b'\n')
  if raw.endswith(b'\n'):lines=lines[:-1]
  if raw==b'':lines=[]
  assert len(lines)==phys
  for li,segment in enumerate(lines,1):
   has_lf=offset+len(segment)<len(raw);line=segment+(b'\n' if has_lf else b'');trimmed=segment.lstrip(b' \t');lf_cont=line.endswith(b'\\\n');crlf_cont=line.endswith(b'\\\r\n')
   if trimmed.startswith(b'#'):
    kbytes=trimmed[1:].lstrip(b' \t');match=re.match(rb'([A-Za-z_][A-Za-z_0-9]*)',kbytes);key=match.group(1).decode('ascii') if match else '';fc[key]+=1;keyword[key]+=1;candidates+=1
    record={'source_ordinal':entry['ordinal'],'source_reference':entry['source_reference_earlier_explicit_lexical_epoch'],'physical_line_ordinal':li,'physical_offset':offset,'physical_length':len(line),'physical_raw_bytes_hex':line.hex(),'literal_keyword_candidate':key if key else None,'literal_keyword_bytes_hex':match.group(1).hex() if match else None,'previous_physical_line_backslash_LF':previous_lf,'this_physical_line_backslash_LF':lf_cont,'previous_physical_line_backslash_CRLF':previous_crlf,'this_physical_line_backslash_CRLF':crlf_cont,'effective_directive':None}
    allrows.append(record)
    if key in ['include','include_next']:
     op=kbytes[match.end():].lstrip(b' \t');rn=None;end=None;kind='macro_empty_or_other'
     if op.startswith(b'<'):
      end=op.find(b'>',1)
      if end>=1:rn=op[1:end];kind='angle_literal_delimited_bytes'
     elif op.startswith(b'"'):
      end=op.find(b'"',1)
      if end>=1:rn=op[1:end];kind='quote_literal_delimited_bytes'
     operands.append({'candidate_ordinal':len(operands)+1,'source_ordinal':entry['ordinal'],'source_reference':entry['source_reference_earlier_explicit_lexical_epoch'],'physical_line_ordinal':li,'physical_offset':offset,'physical_length':len(line),'physical_raw_bytes_hex_PRIVATE':line.hex(),'literal_keyword_candidate':key,'raw_operand_bytes_hex':op.hex(),'raw_delimiter_class':kind,'raw_name_bytes_hex':rn.hex() if rn is not None else None,'raw_tail_after_first_literal_delimiter_bytes_hex':op[end+1:].hex() if rn is not None else None,'previous_physical_line_backslash_LF':previous_lf,'this_physical_line_backslash_LF':lf_cont,'previous_physical_line_backslash_CRLF':previous_crlf,'this_physical_line_backslash_CRLF':crlf_cont,'effective_include_request':None,'alias_identity':None});ops+=1
   offset+=len(line);previous_lf=lf_cont;previous_crlf=crlf_cont
  assert offset==len(raw)
  files.append({'source_ordinal':entry['ordinal'],'source_reference':entry['source_reference_earlier_explicit_lexical_epoch'],'saved_member':entry['original_index_member'],'declared_range':entry['range'],'saved_bytes':len(raw),'physical_LF_line_count':phys,'first_space_tab_skipped_hash_candidates':candidates,'literal_keyword_counts':dict(fc),'include_operand_candidates':ops,'literal_backslash_LF_pairs':blf,'literal_backslash_CRLF_pairs':bcrlf,'UTF8_strict_decode_succeeded':utf8,'NUL_bytes':raw.count(b'\0'),'semantic_C_CPP_preprocessing_NOT_performed':True})
 assert totalbytes==13769073 and len(files)==1199 and len(bindings)==1200 and sum(keyword.values())==len(allrows) and len(operands)==keyword['include']+keyword['include_next']
 delimited=sum(x['raw_name_bytes_hex'] is not None for x in operands)
 summary={'source_run':42357611946,'source_commit':original['source_commit'],'ALL1199_saved_body_file_count':len(files),'saved_body_bytes':totalbytes,'LF_delimited_physical_lines':totalphysical,'first_space_tab_skipped_hash_candidate_count':len(allrows),'literal_keyword_candidate_counts':dict(keyword),'ALL_include_operand_candidate_count':len(operands),'raw_literal_delimited_operand_count':delimited,'macro_empty_or_other_operand_count':len(operands)-delimited,'literal_backslash_LF_pairs':allbackLF,'literal_backslash_CRLF_pairs':allbackCRLF,'strict_UTF8_body_count':sum(x['UTF8_strict_decode_succeeded'] for x in files),'bodies_with_NUL_bytes':sum(x['NUL_bytes']>0 for x in files),'total_NUL_bytes':sum(x['NUL_bytes'] for x in files),'read_binding_count':len(bindings),'comments_splicing_macros_conditions_C_tokenization':'UNEVALUATED','effective_directive_dependency_paths':None,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'ALL1199_files':files,'ALL_physical_hash_candidates_PRIVATE':allrows,'ALL_include_operand_candidates_PRIVATE':operands,'ALL1200_read_bindings_PRIVATE_fullstat-times':bindings,'ALL_original_safe_metadata_epochs_preserved':scope,'original_acquisition_source_validation_NOT_revalidated':original['new_source_validation'],'ALL_prior_static_metadata_preserved_NOT_revalidated':original['ALL_preserved_static_report_fields'],'new_sdk_queries':0,'new_Actions_queries':0,'header_imports_compiles_executions':0,'Source20_runtime_adoption':False}
 full=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL1199-physical-interpretation-PRIVATE.json',full)
 descriptor={'result_saved':'ROOT-FIRST-ALL1199-physical-interpretation-PRIVATE.json','result_bytes':len(full),'result_sha256':hashlib.sha256(full).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 cp=B/'current-task-checkpoint.json';cpraw=cp.read_bytes();save('checkpoint-before-physical-result.json',cpraw);d=json.loads(cpraw);d['actions_include_child_regular_interiors_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL1199_savedregular_physical_interpretation_NOT_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(full),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_child_regular_interiors='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL1199new savedregular physical interpretation complete/ALLrawcandidates-private/semanticpreprocessingUNEVALUATED. Bounded NEW summary thenFIRSTpublication; no oldbody-parser-model-query-Actions-acquisition-archive replay, Source20/runtime adoption/build/numerical. AllsetupUNADMITTED/flagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
