import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import os,stat,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-07-actions-include-grandchild-operand-source-alias-intake-v1'
F=B/'2026-11-07-actions-include-grandchild-regular-interiors-v1/ROOT-FIRST-ALL1229-grandchild-physical-interpretation-PRIVATE.json'
G=B/'2026-11-07-actions-include-grandchild-entry-source-alias-intake-v1/ROOT-FIRST-ALL1425-grandchild-entry-source-alias-intake-PRIVATE.json'
CP=B/'current-task-checkpoint.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST saved-data source/alias intake for ALL3748 NEW physical include/include_next operands fromALL1229saved grandchild bodies/originalActions42369382026/sourceadcb77059cf1f81f61ecf039eca245617a02d752. Declare exact two savedmetadata sources/ranges BEFOREIO. Compare ONLY stored raw_name_bytes_hex decodedbytes against EACH original separatelycaptured original_name_bytes_hex decodedbytes for ALL1425originalrecords, nativeorder andduplicatebasenames retained. 3747rawdelimited performed/1macro-empty-other raw_nameNULL UNPERFORMED/match-countNULL NOTzero. Preserve ALL3748originalfullphysicalrecords/rawoperands/order/byteoffsets/4previous-current LF-CRLF flags/effective_include_requestNULL/alias_identityNULL, allmatches andallnonmatches plus ALL1425originalfullmetadata-stat-times/63queryepochs/1229latelexical-bodyepoch/190DEFERRED/6rawlinksUNEXPANDED-UNFOLLOWED/prior1280-49-1199-old63DEFERRED-18olderlinks-oldtopncurses.h literalcurses.h originalrawhexNOTsavedNULL/allpriorledgers unchanged. No pathsplit/basenameextraction/automaticjoin-normalize-resolve-follow-recursion/query/favorabletype-language-version-ABI-defaultcompiler filter/aliasdedup. Matches/nonmatches NOTaliasidentity/absence/newness/bodycoverage/effectivedependency/compiler-sysroot-CargoCFGflavor-ABI/runtimecohort/originaldriveraccess-credentials/ownership/permission/queryauthority. No oldbody-reader-parser-model/SDKquery-imagehash/Actions-acquisition-journal-archive/numerical replay/candidateexecution/import-headercompile/bootstrap/dependency/build/driver/perf/Source20-runtime adoption. TwoNEWregularO_NOFOLLOW/sameFD/boundedcountSHA/stat/close pointbindings NOTatomicABA-origin/pathchain/globalactorFD/continuousofficialphysicalEX-crash admission; separateouterPID-pipeEOFNULL. Comments-splicing-macros-conditions-Ctokenization UNEVALUATED. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI incomplete.',
 'exact_sources':[{'role':'original_NEWphysicalmetadata','path':str(F),'range':[0,73551419],'sha256':'a8a372c7899c171c9d4671be9c48ba7fdc92d8942f259e008ac04af8e5b153fd'},{'role':'original1425grandchildmetadata','path':str(G),'range':[0,52690769],'sha256':'0f5476239568af58909b07d94fe33fa568241be4c3cb13db5b3bf349683e40ea'}],
 'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and h.hexdigest()==expected;raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw

 fraw=read_bounded(F,73551419,declaration['exact_sources'][0]['sha256'],'original_NEWphysicalmetadata');save('original-physicalmetadata-bound-PRIVATE.json',fraw);save('FIRST-physicalmetadata-read-binding.json',json.dumps(bindings[-1],indent=2));physical=json.loads(fraw)
 graw=read_bounded(G,52690769,declaration['exact_sources'][1]['sha256'],'original1425grandchildmetadata');save('original-grandchildmetadata-bound-PRIVATE.json',graw);save('SECOND-grandchildmetadata-read-binding.json',json.dumps(bindings[-1],indent=2));grandchild=json.loads(graw)
 operands=physical['ALL_new_include_operand_candidates_PRIVATE_original_rowhex'];records=grandchild['ALL1425_original_child_relationships_with_NEW_counts']
 assert len(operands)==3748 and len(records)==1425
 names=[];types=collections.Counter()
 for ordinal,relation in enumerate(records,1):
  assert relation['new_saved_record_position_ONE_based']==ordinal
  original=relation['original_separate_parent_child_metadata'];name=bytes.fromhex(original['original_name_bytes_hex']);assert isinstance(original['literal_child_name_SEPARATE'],str) and os.fsdecode(name)==original['literal_child_name_SEPARATE']
  names.append(name);types[original['saved_type_derived_from_original_mode']]+=1
 assert dict(types)=={'regular':1229,'directory':190,'symlink':6}
 candidate_relations=[];original_matching_positions=[[] for _ in records];matched=0;nonmatched=0;unperformed=0;paircount=0;pairtypes=collections.Counter()
 for position,op in enumerate(operands,1):
  assert op['global_include_operand_position_ONE_based']==position and op['effective_include_request'] is None and op['alias_identity'] is None
  rawhex=op['raw_name_bytes_hex']
  if rawhex is None:
   assert op['raw_name_literal_surrogateescape'] is None and op['raw_delimiter_classification']=='macro_empty_or_other'
   unperformed+=1;matching=None;nonmatching=None;count=None;performed=False
  else:
   name=bytes.fromhex(rawhex);matching=[];nonmatching=[];performed=True
   for originalposition,originalname in enumerate(names,1):
    if name==originalname:
     matching.append(originalposition);original_matching_positions[originalposition-1].append(position);pairtypes[records[originalposition-1]['original_separate_parent_child_metadata']['saved_type_derived_from_original_mode']]+=1
    else:nonmatching.append(originalposition)
   assert len(matching)+len(nonmatching)==1425;count=len(matching);paircount+=count;matched+=bool(matching);nonmatched+=not bool(matching)
  candidate_relations.append({'original_include_operand_position_ONE_based':position,'original_full_physical_operand_PRIVATE_preserved':op,'comparison_performed':performed,'literal_raw_name_to_original_name_byte_match_count':count,'ALL_matching_original_child_record_positions_ONE_based':matching,'ALL_nonmatching_original_child_record_positions_ONE_based_PRIVATE':nonmatching,'comparison_domain_ALL1425_original_records_no_filter':True,'alias_identity':None,'effective_include_request':None,'query_permission_from_matches_or_nonmatches':None})
 assert unperformed==1 and matched+nonmatched==3747 and sum(len(x) for x in original_matching_positions)==paircount
 original_relations=[]
 for position,(old,positions) in enumerate(zip(records,original_matching_positions),1):
  original_relations.append({'original_saved_record_position_ONE_based':position,'original_full_relation_ALLfields_PRIVATE_preserved':old,'ALL_matching_NEW_operand_candidate_positions_ONE_based':positions,'performed_NEW_operand_match_count':len(positions),'performed_NEW_operand_nonmatch_count':3747-len(positions),'UNPERFORMED_NEW_operand_candidate_positions_ONE_based':[r['original_include_operand_position_ONE_based'] for r in candidate_relations if not r['comparison_performed']],'alias_identity':None,'query_permission_from_matches_or_nonmatches':None})
 summary={'physical_body_source_run_id':42369382026,'physical_body_source_revision':'adcb77059cf1f81f61ecf039eca245617a02d752','original_metadata_source_run_id':42365704161,'original_metadata_source_revision':'ed183100f5dff2c40a1a748b630960979114094f','capture_epochs_SEPARATE_not_cohort_equality_proof':True,'ALL_new_operand_candidates':3748,'raw_delimited_comparisons_performed':3747,'macro_empty_other_comparisons_UNPERFORMED':1,'UNPERFORMED_candidate_match_count':None,'performed_candidates_with_literal_byte_matches':matched,'performed_candidates_without_literal_byte_matches':nonmatched,'candidate_to_original_record_match_relations':paircount,'original_child_records_with_NEW_candidate_matches':sum(bool(x) for x in original_matching_positions),'original_child_records_without_NEW_candidate_matches':sum(not x for x in original_matching_positions),'ALL_original_child_records':1425,'original_type_counts_from_original_modes':dict(types),'match_relation_original_type_counts_METADATA_ONLY':dict(pairtypes),'saved_metadata_read_binding_count':len(bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_headerbody_reads':0,'new_recursive_queries':0,'candidate_executions':0,'effective_C_preprocessing_semantics':'UNEVALUATED','all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 result={'summary':summary,'ALL3748_candidate_to_original_child_relationships_PRIVATE':candidate_relations,'ALL1425_original_child_to_NEW_candidate_relationships_PRIVATE':original_relations,'original_physical_result_ALL_fields_PRIVATE_preserved':physical,'original1425_metadata_result_ALL_fields_PRIVATE_preserved':grandchild,'ALL_two_savedmetadata_read_bindings_PRIVATE_fullstat-times':bindings,'exact_saved_metadata_sources':declaration['exact_sources']}
 raw=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL3748-grandchild-operand-source-alias-intake-PRIVATE.json',raw)
 descriptor={'result_saved':'ROOT-FIRST-ALL3748-grandchild-operand-source-alias-intake-PRIVATE.json','result_bytes':len(raw),'result_sha256':hashlib.sha256(raw).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 before=CP.read_bytes();save('checkpoint-before-intake-result.json',before);d=json.loads(before);d['actions_include_grandchild_operand_source_alias_intake_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL3748_saved_physical_operand_source_alias_metadata_NOT_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(raw),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_include_grandchild_operand_source_alias_intake='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL3748savedphysical operand literalrawname bytes vsALL1425originalchildname bytes COMPLETE_CONSUMED. 3747performed/1macro-other UNPERFORMED-countNULL; allfullrecords-order-offsets-4continuationflags/effectiveincludes-aliasesNULL preserved. TwoNEWsavedmetadata bindings/no SDK-Actions-headerbodyquery. FIRST boundedsummary thenpublication only; no oldbody-reader-parser-model-query-acquisition-archive-numerical replay/adoption/build.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor),flush=True);lease.verify_identity()
