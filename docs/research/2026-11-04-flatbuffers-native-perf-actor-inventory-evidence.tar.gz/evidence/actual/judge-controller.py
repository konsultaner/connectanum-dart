import sys,pathlib,hashlib,json,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory-design')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 raw=(r/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()=='dc491908a26d7b9c44e190acacb8ae197a3ad51833d1c6b2fd75680f21081c73'
 lines=raw.decode().splitlines()
 ranges=[(239,249),(269,381),(398,401),(426,454),(573,610),(1089,1125),(1183,1213),(1246,1271)]
 selected='\n\n'.join('SOURCE LINES '+str(a)+'-'+str(b)+'\n'+'\n'.join(str(i+1)+': '+lines[i] for i in range(a-1,b)) for a,b in ranges)
 with (p/'judge-selected-source.txt').open('x') as f:f.write(selected)
 proposal=dict(kind='NEW design-only known-actor inventory extension',source_sha256=hashlib.sha256(raw).hexdigest(),unimplemented=True,
  intent='independent serialized-worker inventory of exact recipe Popen and frozen tuple of all known AuxiliaryCommand handles, including unknown/missing start markers; NO closure authority',
  coverage='constructor failure AND later wait failure after owner initialized=True; older partial APIs only permit failed/uninitialized and keep their predicates BYTEEXACT',
  retention='registry/actor references before callback/fstat or later IO; terminal immutable scalar observations only; new commands/restarts/retries/reset/cancel/publication forbidden',
  unknown='unknown/missing partial fields or ambiguous launch with no retained Popen remain unresolved; no empty-ledger/closed-log/EOF/thread inference; official EX must remain physically held',
  status='not implementation/canonical/liveadmission/originalhost/rootperf/SDK proof',
  companion_summary_root_corrections=['owner._operation is CommandProducer, NOT AuxiliaryCommand (register hook/exact type contract); auxiliary list is nested',
   'constructor except branches on actual pending: it is false to say constructor failure always leaves pendingFalse',
   'write_close_confirmed/EOF are output facts, NOT uncertain-start marker or child ownership proof; invented output_write_uncertain line209 not supported',
   'actual Popen stored before later writes, but absence after fallible Popen does not establish all delegated actors absent'])
 with (p/'proposal-v1.json').open('x') as f:json.dump(proposal,f,indent=2)
 prompt='NEW architecture judgment, not a repeat review of old APIs. Max4 findings, each supported by selected source. Proposal is unimplemented: add a separate worker-only known-actor inventory for BOTH constructor failure and later wait failure with owner initialized=True. Retain exact CommandProducer, optional recipe Popen/record and tuple of all existing AuxiliaryCommand objects before callback/fstat. Cache immutable strictly typed scalar rows for known actor plus missing/uncertain fields. NO actor/descendant/EX-release/admission completion flag. Existing continue_auxiliary_wait predicate remains byteexact; recipe pending or closed writers DO NOT waive it. A future separate exact-known-aux wait may use frozen actor entries; no raw handles for observer, no producer end/finish or new spawns/audits/publication/restarts/cancel. Unknown/missing launch state with no handle permanently quarantines; controller must retain ACTUAL official EX through known handles and unresolved starts. Object close, EOF and Thread join are not actor closure. Evaluate whether freeze-only inventory can help independently without pretending whole closure, and the minimum safe distinction for initialized later-failure vs constructor-failure. Do not invent existing APIs, suggest raw observer access/fixture private cleanup/predicate retagging or global-lock atomicity; source may reveal missing primitives. No source/build/SDK/kernel/workload controls authorized by advice. ROOT validates.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','judge','--repo',str(r),'--file',str(p/'judge-selected-source.txt'),'--prompt',prompt,'--reasoning-budget','512','--num-predict','2200','--max-response-chars','10000','--timeout','180','--save-output',str(p/'judge.txt')]
 with (p/'judge-command.json').open('x') as f:json.dump(argv,f,indent=2)
 with (p/'judge-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);status=proc.wait()
 with (p/'judge-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,selected_chars=len(selected),source_unchanged=hashlib.sha256((r/'tool/native_perf_build_producer.py').read_bytes()).hexdigest()==proposal['source_sha256']),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,selected_chars=len(selected),judge_exists=(p/'judge.txt').exists())))
