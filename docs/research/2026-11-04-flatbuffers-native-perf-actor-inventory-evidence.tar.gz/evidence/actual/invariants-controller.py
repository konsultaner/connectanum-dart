import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory');r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 original=json.loads((p/'original-hashes.json').read_text());final=json.loads((p/'final-hashes.json').read_text())
 changed=[k for k in original if original[k]!=final[k]]
 assert changed==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'] or set(changed)=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 for rel,digest in final.items():assert sha((r/rel).read_bytes())==digest,rel
 invariants={}
 for rel in changed:
  old=(p/'original-source'/rel).read_text();new=(p/'final-source'/rel).read_text()
  a=ast.parse(old);b=ast.parse(new)
  lookup={x.name:x for x in b.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
  for node in a.body:
   if isinstance(node,ast.FunctionDef):
    assert ast.get_source_segment(old,node)==ast.get_source_segment(new,lookup[node.name]),node.name
   elif isinstance(node,ast.ClassDef):
    if node.name=='_RetainedPreflightOwner':
     methods={f.name:f for f in lookup[node.name].body if isinstance(f,ast.FunctionDef)}
     differences=[]
     for f in node.body:
      if isinstance(f,ast.FunctionDef) and ast.get_source_segment(old,f)!=ast.get_source_segment(new,methods[f.name]):differences.append(f.name)
     assert differences==['__init__','_schedule','_work'],differences
    else:assert ast.get_source_segment(old,node)==ast.get_source_segment(new,lookup[node.name]),node.name
 invariants=dict(source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],
  changed_files=changed,changed_original_owner_methods=['__init__','_schedule','_work'],
  original_module_functions_factories_gates_otherclasses_otherownermethods_testclasses_byteexact=True,
  other18tools_and_selected3bins_byteexact=True,all23_current_source_bytes_match_final_snapshot=True,
  scope='filedata and AST invariants only; only producer+test compiled for finite fixtures, no20canonical or compiled closure')
 stages={}
 for stage in ('before','implemented','strict-before','final'):
  v=json.loads((p/(stage+'-tests.json')).read_text());recipes=[];aux=[]
  for path in (p/(stage+'-fixtures')).rglob('known-actors.json'):
   recipes.extend(json.loads(path.read_text()))
  for path in (p/(stage+'-fixtures')).rglob('known-auxiliary-actors.json'):
   aux.extend(json.loads(path.read_text()))
  assert all(row['status']==0 and row['merged_output_eof'] and row['sha256']==row['stream_sha256'] and row['record_count']==1 for row in recipes)
  assert all(row['returncode']==0 and all(s['eof'] and s['snapshot_matches_stream'] for s in row['outputs'].values()) for row in aux)
  stages[stage]=dict(tests=v['tests'],failures=v['failures'],errors=v['errors'],recorded_recipe_rows=len(recipes),recorded_auxiliary_rows=len(aux),
   all_recorded_new_recipe_natural0_mergedEOF_stream_matches_file=True,all_recorded_auxiliary_natural0_twoEOF_snapshot_matches_stream=True)
 with (p/'source-invariants.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),invariants=invariants,stage_results=stages),f,indent=2)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(c.read_text());n=d['native_perf_only_diagnostic_design']
 n['current_helper_source_epoch']=dict(producer_sha256=invariants['source_sha256'],test_sha256=invariants['test_sha256'],hashes_file=str(p/'final-hashes.json'),
  all20_uncommitted_uncanonical_unadmitted=True,production601_no_edit_in_this_phase=True)
 n['known_actor_inventory_component']['review_running_tool_session']=40514
 d['active_turn_status']='known_actor_inventory_FINAL16PASS_source_invariants_checked_selected_model_review_running'
 c.write_text(json.dumps(d,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(invariants=invariants,stages=stages)))
