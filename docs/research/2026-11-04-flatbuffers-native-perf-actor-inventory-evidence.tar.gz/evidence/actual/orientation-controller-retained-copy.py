import sys,pathlib,hashlib,json,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory-design');p.mkdir()
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 raw=(r/'tool/native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='dc491908a26d7b9c44e190acacb8ae197a3ad51833d1c6b2fd75680f21081c73'
 lines=raw.decode().splitlines()
 ranges=[(223,394),(396,457),(573,619),(669,753),(1076,1246),(1246,1279)]
 selected='\n\n'.join('SOURCE LINES '+str(a)+'-'+str(b)+'\n'+'\n'.join(str(i+1)+': '+lines[i] for i in range(a-1,b)) for a,b in ranges)
 with (p/'selected-current-source.txt').open('x') as f:f.write(selected)
 declaration=dict(scope='NEW readonly current actor ownership/inventory orientation, not replay of old owner design or method',source_sha256=hashlib.sha256(raw).hexdigest(),ranges=ranges,
  no_tests_build_SDK_recipe_or_workload=True,all_source_unchanged=True,advisory_no_whole_actor_or_lease_closure_claim=True)
 with (p/'declaration.json').open('x') as f:json.dump(declaration,f,indent=2)
 prompt='Summarize ONLY these current source ranges, max 6 bullets with line refs. NEW question: which exact waitable Popen/auxiliary handles and uncertain start markers are retained BEFORE fallible IO, and where can a failed/uninitialized owner have recipe plus auxiliary state simultaneously? Distinguish recipe pending, auxiliary pending, process None, launch exception, constructor failure and worker completion. Do not propose changes, reruns, cleanup, cancellation or terminal retagging. The later parent writer object sealer only closes objects and does NOT grant actor closure/auxiliary predicate waiver. State any missing ranges; no global descendant/physical lease proof.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--repo',str(r),'--file',str(p/'selected-current-source.txt'),'--prompt',prompt,'--num-predict','1500','--max-response-chars','10000','--timeout','150','--save-output',str(p/'summary.txt')]
 with (p/'summary-command.json').open('x') as f:json.dump(argv,f,indent=2)
 with (p/'summary-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
  status=proc.wait()
 with (p/'summary-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,source_unchanged=hashlib.sha256((r/'tool/native_perf_build_producer.py').read_bytes()).hexdigest()==declaration['source_sha256']),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,selected_chars=len(selected),summary_exists=(p/'summary.txt').exists())))
