import sys,pathlib,json,ast,hashlib,datetime,subprocess,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory');r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 with (p/'attempt-root-assessment-v2.json').open('x') as f:json.dump(dict(scope='NEW component root assessment, distinct from old design root assessment',prior_controller_save_collision_before_newbody_or_data=True,no_overwrite_or_oldpath_mutation=True),f,indent=2)
 sha=lambda b:hashlib.sha256(b).hexdigest()
 original=json.loads((p/'original-hashes.json').read_text());final=json.loads((p/'final-current-hashes.json').read_text())
 changed=[k for k in original if original[k]!=final[k]];assert set(changed)=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 for rel,digest in final.items():assert sha((r/rel).read_bytes())==digest,rel
 for rel in changed:
  old=(p/'original-source'/rel).read_text();new=(p/'final-current-source'/rel).read_text()
  a=ast.parse(old);b=ast.parse(new);lookup={x.name:x for x in b.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
  for node in a.body:
   if isinstance(node,ast.FunctionDef):assert ast.get_source_segment(old,node)==ast.get_source_segment(new,lookup[node.name]),node.name
   elif isinstance(node,ast.ClassDef):
    if node.name=='_RetainedPreflightOwner':
     methods={f.name:f for f in lookup[node.name].body if isinstance(f,ast.FunctionDef)}
     differences=[f.name for f in node.body if isinstance(f,ast.FunctionDef) and ast.get_source_segment(old,f)!=ast.get_source_segment(new,methods[f.name])]
     assert differences==['__init__','_schedule','_work'],differences
    else:assert ast.get_source_segment(old,node)==ast.get_source_segment(new,lookup[node.name]),node.name
 assert (p/'final-source/tool/native_perf_build_producer.py').read_bytes()==(p/'final-current-source/tool/native_perf_build_producer.py').read_bytes()
 # The final addition changes one test only; retain earlier result scope separately.
 a=(p/'final-source/tool/test_native_perf_build_producer.py').read_text();b=(p/'final-current-source/tool/test_native_perf_build_producer.py').read_text()
 aa=next(x for x in ast.parse(a).body if isinstance(x,ast.ClassDef) and x.name=='KnownActorInventoryTests')
 bb=next(x for x in ast.parse(b).body if isinstance(x,ast.ClassDef) and x.name=='KnownActorInventoryTests')
 bm={f.name:f for f in bb.body if isinstance(f,ast.FunctionDef)}
 for f in aa.body:
  if isinstance(f,ast.FunctionDef):assert ast.get_source_segment(a,f)==ast.get_source_segment(b,bm[f.name]),f.name
 gitrows=[];handles=[]
 for index,args in enumerate([['rev-parse','HEAD'],['branch','--show-current'],['diff','--exit-code','HEAD','--','packages','native'],['status','--porcelain','--untracked-files=all']]):
  record=dict(argv=['git','-C',str(r),*args],process=None,status=None);handles.append(record)
  record['process']=subprocess.Popen(record['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
  proc=record['process'];out,err=proc.communicate();status=proc.wait()
  assert status==0,(args,status)
  for role,data in [('stdout',out),('stderr',err)]:
   with (p/(str(index)+'-root-git.'+role)).open('xb') as f:f.write(data)
  gitrows.append(dict(argv=record['argv'],pid=proc.pid,direct_status=status,same_Popen_final_wait=status,
   stdout_size=len(out),stdout_sha256=sha(out),stderr_size=len(err),stderr_sha256=sha(err),both_separate_EOF=True))
  if index==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  if index==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  if index==2:assert out==b''
  if index==3:
   lines=out.decode().splitlines();assert len(lines)==20 and all(line.startswith('?? tool/') and 'native_perf_' in line for line in lines)
 stages={}
 for stage in ('before','implemented','strict-before','final','final-current'):
  value=json.loads((p/(stage+'-tests.json')).read_text());recipes=[];legacy_aux=[];aux=[];unclassified=[]
  for path in (p/(stage+'-fixtures')).rglob('known-actors.json'):
   for row in json.loads(path.read_text()):
    if {'status','merged_output_eof','sha256','stream_sha256','record_count'}<=row.keys():recipes.append(row)
    elif {'status','stdout_eof','stderr_eof'}<=row.keys():legacy_aux.append(row)
    else:unclassified.append(dict(path=str(path.relative_to(p)),keys=list(row)))
  for path in (p/(stage+'-fixtures')).rglob('known-auxiliary-actors.json'):aux.extend(json.loads(path.read_text()))
  assert all(row['status']==0 and row['merged_output_eof'] and row['sha256']==row['stream_sha256'] and row['record_count']==1 for row in recipes)
  assert all(row['status']==0 and row['stdout_eof'] and row['stderr_eof'] for row in legacy_aux)
  assert all(row['returncode']==0 and all(s['eof'] and s['snapshot_matches_stream'] for s in row['outputs'].values()) for row in aux)
  stages[stage]=dict(tests=value['tests'],failures=value['failures'],errors=value['errors'],recorded_recipe_rows=len(recipes),
   recorded_new_auxiliary_full_result_rows=len(aux),required_legacy_auxiliary_scalar_rows=len(legacy_aux),
   unclassified_rows=unclassified,recorded_recipe_natural0_mergedEOF_streamfile_matches=True,
   recorded_new_auxiliary_natural0_twoEOF_snapshotstream_matches=True,legacy_auxiliary_only_recorded_status0_twoEOF_not_digest_claim=True)
 assessment=dict(kind='worker_only_known_actor_object_inventory_source_component_v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],
  APIs='freeze_known_actors(), known_actor_observations()',changed_files=changed,
  original_module_functions_factories_emitters_gates_CommandProducer_AuxiliaryCommand_other_owner_methods_original_testclasses_byteexact=True,
  original_owner_init_schedule_work_extended_only=True,other18tools_and_selected3bins_byteexact=True,
  implementation_final_to_finalcurrent_byteexact=True,prior_KnownActorInventoryTests_methods_byteexact_last_test_added_only=True,
  production601_tracked_packages_native_diff_empty=True,helper_branch_HEAD_601=True,all20_uncommitted_uncanonical_unadmitted=True,
  private_controllers_not_HELPERBUNDLE20=True,
  semantics='Failed initialized OR uninitialized owner, previous actualThreadjoin+settledstart/no busy waiver; ONEattempt beforeThreadsetup; all later producer actions refuse. Worker retains current producer/Popen/record-list-currentrecord/auxlist-tuple-dicts/Popen/originalcallback before callback; typed cached primitive objectfacts only/no poll-wait-FDIO.',
  strict_fields='pid+returncode key presence/types; original owner callback identity bound in producer+aux and retained before invoking; unknown fields/drift quarantine and keep exact available pre-callback refs; never invent0 or empty-ledger success.',
  observation_limits='CURRENT recipe and retained auxiliary object snapshot only; cached Popen.returncode NOTfresh wait/poll/liveness/credential/role/compiled/descendant/allwriter/whole-inventory or physicalEX-release authority. No global ABA/atomicity/auth/writeprevention.',
  original_auxiliary_predicate_unchanged_no_waiver=True,
  new_inventory_action_only_skips_raw_pending_finished_postcatch_refresh_owner_cache_historical=True,
  raw_producer_state_not_retagged_no_end_finish_audit_spawn_FDclose_publication=True,
  no_repr_str_custom_equality_add_note_newhooks=True,
  stage_results=stages,
  before10_errors_missing_API_only_NOTproductiondefects=True,initial14PASS_scope='10new+4requiredcallers',
  new_strict2FAIL='missing returncode accepted as validunknown; foreign producer lease field accepted; UNITprep regressions, not canonical/RAMdefects',
  fixed16PASS_scope='12new+4requiredcallers, separate from initial14',
  final_current1PASS_scope='ONE NEW foreign-producer callback guard; implementation byteexact, testsource changed; NOTcombined17/31/fullcanonical',
  fixture_scope='Finite actual OWN Python/FIXTURE, source/archive/input guards MOCKED; factory error after ctor return OR injected later wait after actual aux launch. No observed original ctor/build/SDKfailure. PrivateDirreleaseNOTGO; recipeONEmergedpipe, auxTWOseparatepipes; nextsentinelsunlaunched.',
  fixture_only_private_same_actor_drain_close_field_restore_NEVER_live_workaround=True,
  actual_official_EX_through_known_fixture_workers_children_and_4_new_root_Git=True,unit_lease_callbacks_SYNTHETIC=True,
  returned_views_and_legacy_Git_setup_APIreturns_NOTall_systematically_serialized=True,
  controller_failures=['First functions JSparse SyntaxError before nestedtool/filesystem/body not separately retained/no reconstruction','First final coordinator Pythonparse unmatchedparenthesis beforebody/sourcewrite/test; exactsavedterminalcoordinator','New component root controller save refused existing old design-controller path before newbody or artifactreads/Git; old file preserved; explicit distinct new component controller','Initial root posttest audit KeyError merged_output_eof on required legacy auxiliary schema; no source mutation/publication; scalar-only original rows NOTreconstructed as merged/digest proof'],
  models=json.loads("{\"Gemma_summary\":{\"tool_session\":39218,\"helper_pid\":92375,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"advisory\":true,\"root_rejects\":[\"owner operation may be AuxiliaryCommand\",\"constructor failure always pendingFalse\",\"EOF/write-close flags prove uncertain start/ownership\"]},\"GLM_design\":{\"tool_session\":87500,\"helper_pid\":92603,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"advisory\":true,\"root_rejects\":[\"freeze must be inside constructor catch to avoid cleanup after synchronous unwind\",\"constructor failure auxiliaries all prestart\",\"inverted original aux predicate\",\"private handle retention conflicts with scalar-only observer\",\"omit typed pending facts entirely\",\"initializedTrue alone proves later wait failure\"],\"root_accepts\":\"distinct initialization/parent-start/worker-call/partial actor facts; no predicate waiver or physical closure\"},\"Qwen_test_planning\":{\"tool_session\":53251,\"helper_pid\":93270,\"direct_status\":1,\"reaped\":true,\"token_limit\":true,\"last_reported_visible_chars\":6874,\"full_partial_final_absent\":true,\"backend_reachable_not_unavailable_or_approval\":true},\"Qwen_final_selected_review\":{\"tool_session\":40514,\"helper_pid\":94191,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"selected_chars\":27917,\"review_source_epoch\":\"76597e4c3272017326b60e1060d6135a729b53a18476b59ef16aeb632f8e41c6\",\"review_test_epoch\":\"1aecffdf842c0f001340051fea4c868ccb316c68d7edc99735c1085f2b276c39\",\"root_rejects\":[\"callback drift is false-error/lost state: exact refs AND primitive rows captured before callback, changed identity deliberately quarantines\",\"missing returncode accepted: explicit key-presence check sets fields invalid, and new BEFORE regression now passes\",\"no op identity check: op is first binding element compared by identity\",\"global GIL/observer lock atomicity or callback descendant closure not claimed\"],\"root_accepts\":\"ONE new deterministic foreign-producer swap guard, PASS separately with implementation byteexact; review before last test addition, ROOT checks it\",\"not_model_final_current_full_source_approval\":true}}"),
  current20_canonical_or_full_instruction_closure=False,
  no_SDK_native_build_originalhost_kernel_broker_benchmark_capture_strictdispatch=True,
  no_RAM_cause_repair_acceptance=True,actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,
  process_life_registry_handle_history_counts_NOT_heap_RSSbound=True,
  next='Independent exact known-actor continuation and full physicalEX bridge still absent; inventory freeze blocks ordinary pipeline. Original PATH/bootstrap/SDK/firstgeneration locks/configs/current20canonical/native-driver-RLIB/originalhost controls/provenance/immutableCOMPLETEadmission required before diagnosticdata.',
  root_git=gitrows,free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize)
 with (p/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2);f.write('\n')
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(c.read_text());n=d['native_perf_only_diagnostic_design']
 component=n['known_actor_inventory_component'];component.update(review_pending=False,publication_pending=True,assessment=str(p/'assessment.json'),
  source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],final16PASS='12new+4requiredcallers',separate_new_final1PASS=True,
  all_own_model_test_sessions_terminal=True,actor_ownership_complete=None,all_admission_flags=False)
 n['current_helper_source_epoch']=dict(producer_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],hashes_file=str(p/'final-current-hashes.json'),all20_uncommitted_uncanonical_unadmitted=True,production601_unchanged=True)
 n['known_actor_inventory_design']['historical_design_only_before_implementation']=True;n['known_actor_inventory_design']['unimplemented']=False
 d['updated_utc']=assessment['utc'];d['active_turn_status']='known_actor_inventory_16PASS_plus_separate_NEW1PASS_root_assessed_publication_pending_fullbridge_incomplete'
 c.write_text(json.dumps(d,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],stages=stages,free_after=assessment['free_after'])))
