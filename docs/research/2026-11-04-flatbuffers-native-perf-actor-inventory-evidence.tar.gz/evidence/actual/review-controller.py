import sys,pathlib,json,hashlib,difflib,subprocess
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory-design');e=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory')
 selected=''
 for rel in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'):
  a=(e/'original-source'/rel).read_text();b=(e/'final-source'/rel).read_text()
  selected+=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='original/'+rel,tofile='current/'+rel,n=3))
 with (p/'final-selected-diff.txt').open('x') as f:f.write(selected)
 prompt='Review this NEW source-component diff. Strictly max3 concrete bugs, <=180 words TOTAL, line refs and no code; say none if none. Focus lost known Popen/aux references before callback, typed cached scalar views/no customhooks, false unknown-status or closure, initialized later-failure vs constructor vs parentstart, terminalfreeze preventing nextpipeline. Only object snapshots/no poll/wait/FD_IO/allactor/admission. Original ordinarywait/auxpredicate/body and current actor classes unchanged; new dispatch skips raw scalar refresh ONLY inventory so historical ownercache stays separate. Caller actualphysicalEX required. Do not suggest raw observer access/global-lock atomicity/private cleanup/reset/cancel/producerretag/newbuild or invented API. Tests actualfinite Python/FIXTURE+mocked boundaries, never workload or canonical proof. Audit diff as advisory; ROOT verifies.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--file',str(p/'final-selected-diff.txt'),'--prompt',prompt,'--num-predict','2200','--max-response-chars','10000','--timeout','180','--save-output',str(p/'review.txt')]
 with (p/'review-command.json').open('x') as f:json.dump(argv,f,indent=2)
 with (p/'review-command.log').open('xb') as log:
  proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT);status=proc.wait()
 with (p/'review-finish.json').open('x') as f:json.dump(dict(pid=proc.pid,direct_status=status,known_parent_wait_return=status,selected_chars=len(selected),
  source_sha256=hashlib.sha256((e/'final-source/tool/native_perf_build_producer.py').read_bytes()).hexdigest(),
  test_sha256=hashlib.sha256((e/'final-source/tool/test_native_perf_build_producer.py').read_bytes()).hexdigest()),f,indent=2)
 lease.verify_identity();print(json.dumps(dict(direct_status=status,pid=proc.pid,answer_exists=(p/'review.txt').exists(),selected_chars=len(selected))))
