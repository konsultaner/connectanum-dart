import sys,pathlib,json,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-actor-inventory')
 with (p/'assessment-finalizer-attempt.json').open('x') as f:json.dump(dict(scope='Finalize retained component report only, NO Git/AST/test/model/control rerun',terminal=True,
  prior_component_root_V2_NameError_R_after_4_Git_and_invariant_assertions=True,missing_per_Git_API_returns_NOT_reconstructed=True),f,indent=2)
 final=json.loads((p/'final-current-hashes.json').read_text());stages={}
 for stage in ('before','implemented','strict-before','final','final-current'):
  v=json.loads((p/(stage+'-tests.json')).read_text())
  stages[stage]=dict(tests=v['tests'],failures=v['failures'],errors=v['errors'],scope=v['scope'])
 gitdata=[]
 for index in range(4):
  row=dict(index=index,direct_status=None,pid=None,API_return_array_NOT_serialized=True,kind='retained_stream_FILEDATA_only',streams={})
  for role in ('stdout','stderr'):
   path=p/(str(index)+'-root-git.'+role);raw=path.read_bytes()
   row['streams'][role]=dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  gitdata.append(row)
 assessment=dict(kind='worker_only_known_actor_object_inventory_source_component_v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],
 APIs='freeze_known_actors(), known_actor_observations()',changed_files=['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'],
 original_module_functions_factories_emitters_gates_CommandProducer_AuxiliaryCommand_other_owner_methods_original_testclasses_byteexact=True,
 original_owner_init_schedule_work_extended_only=True,other18tools_and_selected3bins_byteexact=True,
 implementation_final_to_finalcurrent_byteexact=True,prior_KnownActorInventoryTests_methods_byteexact_last_test_added_only=True,
 invariant_evidence_qualification='ROOT exact AST/file assertions in component-root-V2 complete before later NameError; exact original/final snapshots retained. Per-assertion API returns not separately serialized; no rerun to fill.',
 production601_no_edit_by_this_phase=True,all20_uncommitted_uncanonical_unadmitted=True,private_controllers_not_HELPERBUNDLE20=True,
 semantics='Failed initialized OR uninitialized owner; previous exactThreadjoin+settledstart/busyguard. ONEattempt beforeThreadsetup; all later producer actions refuse. Worker retains current producer/Popen/record-list-currentrecord/auxlist-tuple-dicts/Popen/originalcallback BEFORE callback. Immutable typed primitive cached objectfacts; no poll/wait/FDIO.',
 strict_fields='pid+returncode key presence/types; original owner callback identity bound to producer+aux and retained before invoking; missing/unknown fields or drift quarantine exact available pre-callback references; no false0 or empty-ledger success.',
 observation_limits='CURRENT recipe and retained auxiliary object snapshot ONLY. Popen.returncode cached, not fresh wait/poll/liveness/credential/role/compiled/descendant/allwriter/wholeinventory or physicalEX release authority. No atomic/globalABA/auth/writeprevention claim.',
 original_auxiliary_predicate_unchanged_no_waiver=True,new_inventory_only_skips_raw_pending_finished_postcatch_refresh_ownercache_historical=True,
 raw_producer_state_not_retagged_no_end_finish_audit_spawn_FDclose_publication=True,no_repr_str_custom_equality_add_note_newhooks=True,
 stage_results=stages,before10_errors_missing_API_only_NOT10productiondefects=True,initial14PASS_scope='10new+4requiredcallers',
 new_strict2FAIL='Missing cached returncode incorrectly accepted as valid unknown; foreign producer lease field accepted. Real UNITprep regressions, not canonical/RAMdefects.',
 fixed16PASS_scope='12new+4requiredcallers, separate from earlier14',
 final_current1PASS_scope='ONE NEW foreign-producer callback guard; implementation byteexact/testsource changed, NOTcombined17/31/fullcanonical',
 fixture_scope='Finite actual OWN Python/FIXTURE; source/archive/input MOCKED. Factory escapes after actual ctor returns pending OR injected later wait after actual auxiliary launch. No observed original ctor/build/SDKfailure. PrivateDirreleaseNOTGO, recipeONEmergedpipe/auxTWOseparatepipes; nextsentinelsunlaunched.',
 new_recipe_and_auxiliary_natural_status_EOF_digest_claim_scope='Selected tests assert retained known same actors natural0 and recipe mergedEOF/streamfile digests; new Aux fullresult JSONs assert natural0/twoEOF/snapshot-stream matches. Required legacy aux scalar rows have status/twoEOF ONLY, no reconstructed digest.',
 fixture_only_private_same_actor_drain_close_field_restore_NEVER_live_workaround=True,
 ROOT_actual_official_EX_through_known_fixture_workers_children=True,unit_lease_callbacks_SYNTHETIC=True,
 returned_views_and_legacy_Git_setup_APIreturns_NOTall_systematically_serialized=True,
 root_Git_observation='Four administrative Git subprocesses and both stream files per process observed through actual officialEX source path. The later report NameError occurs after waits/assertions. PID/status/API-return array not serialized: NULL here, no reconstruction/rerun or whole-actor closure claim.',
 root_Git_retained_FILEDATA=gitdata,
 controller_failures=['First functions JSparse before nestedtool/filesystem, failed body not separately retained/no reconstruction',
  'First final coordinator Pythonparse unmatchedparenthesis beforebody/sourcewrite/tests, savedexactterminalcoordinator',
  'Initial posttest audit KeyError merged_output_eof on REQUIRED legacy aux scalar schema; source unchanged, no publication; no merged/digest reconstruction',
  'Component root controller SAVE refused existing old design controller path before newbody; old file preserved; explicit distinct component path declared',
  'Component root V2 NameError R notdefined after AST/file assertions and4Git/streamwrites, before assessment publication; terminal retained, NO unchanged Git/AST/test rerun. This finalizer consumes existing retained reports/streams only.'],
 models=json.loads("{\"Gemma_summary\":{\"tool_session\":39218,\"helper_pid\":92375,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"advisory\":true,\"root_rejects\":[\"owner operation may be AuxiliaryCommand\",\"constructor failure always pendingFalse\",\"EOF/write-close flags prove uncertain start/ownership\"]},\"GLM_design\":{\"tool_session\":87500,\"helper_pid\":92603,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"advisory\":true,\"root_rejects\":[\"freeze must be inside constructor catch to avoid cleanup after synchronous unwind\",\"constructor failure auxiliaries all prestart\",\"inverted original aux predicate\",\"private handle retention conflicts with scalar-only observer\",\"omit typed pending facts entirely\",\"initializedTrue alone proves later wait failure\"],\"root_accepts\":\"distinct initialization/parent-start/worker-call/partial actor facts; no predicate waiver or physical closure\"},\"Qwen_test_planning\":{\"tool_session\":53251,\"helper_pid\":93270,\"direct_status\":1,\"reaped\":true,\"token_limit\":true,\"last_reported_visible_chars\":6874,\"full_partial_final_absent\":true,\"backend_reachable_not_unavailable_or_approval\":true},\"Qwen_final_selected_review\":{\"tool_session\":40514,\"helper_pid\":94191,\"direct_status\":0,\"reaped\":true,\"completed_answer_saved\":true,\"selected_chars\":27917,\"review_source_epoch\":\"76597e4c3272017326b60e1060d6135a729b53a18476b59ef16aeb632f8e41c6\",\"review_test_epoch\":\"1aecffdf842c0f001340051fea4c868ccb316c68d7edc99735c1085f2b276c39\",\"root_rejects\":[\"callback drift is false-error/lost state: exact refs AND primitive rows captured before callback, changed identity deliberately quarantines\",\"missing returncode accepted: explicit key-presence check sets fields invalid, and new BEFORE regression now passes\",\"no op identity check: op is first binding element compared by identity\",\"global GIL/observer lock atomicity or callback descendant closure not claimed\"],\"root_accepts\":\"ONE new deterministic foreign-producer swap guard, PASS separately with implementation byteexact; review before last test addition, ROOT checks it\",\"not_model_final_current_full_source_approval\":true}}"),
 ROOT_complete_affected_final_methods_and_last_new_test_checked=True,no_model_final_current_full_source_approval=True,
 current20canonical_or_compiled_instructionclosure=False,no_SDK_native_build_originalhost_kernel_broker_benchmark_capture_strictdispatch=True,
 no_RAM_cause_repair_acceptance=True,actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,
 process_life_retention_counts_NOT_heap_RSSbound=True,
 next='Independent exact known-actor continuation/full physicalEX bridge absent; freeze blocks ordinary pipeline. Original PATH/bootstrap/SDK/firstgeneration locks/configs/current20canonical/native-driver-RLIB/originalhost controls/provenance and immutableCOMPLETEadmission required before diagnosticdata.',
 free_after=os.statvfs(p).f_bavail*os.statvfs(p).f_frsize)
 with (p/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2);f.write('\n')
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');d=json.loads(c.read_text());n=d['native_perf_only_diagnostic_design']
 n['known_actor_inventory_component'].update(review_pending=False,publication_pending=True,assessment=str(p/'assessment.json'),
  source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],fixed16PASS='12new+4requiredcallers',separate_new_final1PASS=True,
  all_own_model_test_sessions_terminal=True,actor_ownership_complete=None,all_admission_flags=False)
 n['current_helper_source_epoch']=dict(producer_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],hashes_file=str(p/'final-current-hashes.json'),all20_uncommitted_uncanonical_unadmitted=True,production601_no_edit=True)
 n['known_actor_inventory_design'].update(unimplemented=False,historical_design_only_before_implementation=True)
 d['updated_utc']=assessment['utc'];d['active_turn_status']='known_actor_inventory_16PASS_plus_separate_NEW1PASS_root_assessed_publication_pending_fullbridge_incomplete'
 c.write_text(json.dumps(d,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],stage_results=stages,free_after=assessment['free_after'])))
