
class ReceiptResourceTests(unittest.TestCase):
    """New raw-resource controls; none establish live/SDK/physical admission."""
    receipt_fixture=ProducerTests.receipt_fixture
    finish=ProducerTests.finish
    make_tool=ProducerTests.make_tool
    git=ReceiptErrorRetentionTests.git

    def setUp(self):
        self.setup_children=[];self.setup_records=[];self.actions={};self.current_run=None
        self.fixture_fd_closes=[]
        ProducerTests.setUp(self)

    def start(self,*modes,**overrides):
        overrides['lease_check']=self.lease_check
        return ProducerTests.start(self,*modes,**overrides)

    def lease_check(self):
        action=self.actions.get('callback')
        if action is not None:action()

    def prepared(self):
        run,_,_,_=self.receipt_fixture();self.current_run=run
        return run

    def rows(self,run):
        rows=[]
        for resource in run.__dict__.get('_receipt_resources',[]):
            error=resource['first_error']
            rows.append(dict(role=resource['role'],path=resource['path'].name,direction=resource['direction'],
                fd=resource['fd'],open_attempted=resource['open_attempted'],open_returned=resource['open_returned'],
                close_attempted=resource['close_attempted'],close_returned=resource['close_returned'],
                offset=resource['offset'],write_uncertain=resource['write_uncertain'],read_uncertain=resource['read_uncertain'],
                pending_size=None if resource['pending_payload'] is None else len(resource['pending_payload']),
                pending_offset=resource['pending_offset'],quarantined=resource['quarantined'],
                first_error_type=None if error is None else type.__getattribute__(type(error),'__name__'),
                actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
        return rows

    def capture(self,run,invoke,extra=None):
        caught=None;result=None
        try:result=invoke()
        except BaseException as error:caught=error
        value=dict(rows=self.rows(run),error_type=None if caught is None else type.__getattribute__(type(caught),'__name__'),
            result_kind=None if result is None else result.get('kind'),
            quarantined=run.__dict__.get('_receipt_resources_quarantined'),
            failure_file_exists=(run.directory/'receipt-failure.json').exists(),
            receipt_attempted=run.receipt_attempted)
        if extra is not None:value.update(extra())
        with (self.base/'resource-control-before-cleanup.json').open('x') as out:json.dump(value,out,indent=2)
        return caught,result,value

    def resource(self,run,role):
        return next(row for row in run._receipt_resources if row['role']==role)

    def test_postwrite_fault_never_replays_audit_bytes_or_closes_uncertain_output(self):
        import io
        run=self.prepared();target=[];writes=[];native_open=Path.open;native_os_open=os.open;native_write=os.write
        failure=OSError(5,'OWN after actual raw metadata write');detached=[]
        class Raw(io.RawIOBase):
            def __init__(self,actual):self.actual=actual
            def writable(self):return True
            def fileno(self):return self.actual.fileno()
            def write(self,data):return os.write(self.actual.fileno(),data)
            def close(self):
                if not self.closed:self.actual.close()
                return super().close()
        def opening(path,*args,**kwargs):
            writer=native_open(path,*args,**kwargs)
            if path.name=='receipt-source-audit.jsonl' and args and args[0]=='xb':
                if type(writer) is io.BufferedWriter:
                    actual=writer.detach();detached.append(writer);target.append(actual.fileno())
                    return io.BufferedWriter(Raw(actual))
                target.append(writer.fileno())
            return writer
        def opening_fd(path,*args,**kwargs):
            fd=native_os_open(path,*args,**kwargs)
            if Path(path).name=='receipt-source-audit.jsonl':target.append(fd)
            return fd
        def write(fd,data):
            count=native_write(fd,data)
            if target and fd==target[-1]:
                writes.append(bytes(data))
                if len(writes)==1:raise failure
            return count
        def source_guard(current,observe=None):
            self.assertTrue(callable(observe));observe('status','--porcelain')
        with mock.patch.object(Path,'open',opening),mock.patch.object(producer.os,'open',opening_fd),\
             mock.patch.object(producer.os,'write',write),mock.patch.object(producer.CommandProducer,'_source_guard',source_guard):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_raw_write_calls=len(writes),written_piece_sizes=[len(part) for part in writes],
                    audit_file_sha256=digest((run.directory/'receipt-source-audit.jsonl').read_bytes()),
                    before_BufferedWriter_over_controlledRaw_actualFileIO=True))
        self.assertTrue(caught is failure);self.assertEqual(1,len(writes))
        resource=self.resource(run,'source_audit')
        self.assertTrue(resource['write_uncertain']);self.assertFalse(resource['close_attempted'])
        self.assertFalse((run.directory/'receipt-failure.json').exists())

    def test_all_receipt_resources_retained_retired_and_JSON_bytes_equivalent(self):
        run=self.prepared();caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'))
        self.assertIsNone(caught);self.assertEqual('fixture-canonical-v1',result['kind'])
        roles={row['role'] for row in run._receipt_resources}
        self.assertTrue({'attempt','source_audit','complete_log','input_receipt','binding'}<=roles)
        self.assertTrue(all(row['close_returned'] is True for row in run._receipt_resources))
        for name in ('receipt-attempt.json','input-receipt.json','receipt-binding.json'):
            raw=(run.directory/name).read_bytes()
            self.assertEqual((json.dumps(json.loads(raw),sort_keys=True,indent=2)+'\n').encode(),raw)
        for line in (run.directory/'receipt-source-audit.jsonl').read_bytes().splitlines():
            self.assertEqual(json.dumps(json.loads(line),sort_keys=True).encode(),line)
        self.assertTrue(all(row['actor_ownership_complete'] is None for row in value['rows']))

    def test_record_and_exact_FD_are_retained_before_following_callback(self):
        run=self.prepared();actual=producer._receipt_resource_io;observed=[]
        def operation(resource,step,value=None):
            if step=='open':
                self.assertTrue(any(item is resource for item in run._receipt_resources))
                self.assertIsNone(resource['fd'])
            return actual(resource,step,value)
        def callback():
            for resource in run._receipt_resources:
                if resource['open_returned'] is True and resource['identity'] is None:
                    self.assertIs(type(resource['fd']),int);observed.append(resource['role'])
        self.actions['callback']=callback
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(observed_FD_before_callback=list(observed)))
        self.assertIsNone(caught);self.assertIn('attempt',observed);self.assertIn('source_audit',observed)

    def test_known_short_write_advances_only_unwritten_suffix(self):
        run=self.prepared();actual=producer._receipt_resource_io;pieces=[]
        def operation(resource,step,value=None):
            if resource['role']=='attempt' and step=='write':
                pieces.append(bytes(value))
                if len(pieces)==1:return actual(resource,step,value[:3])
            return actual(resource,step,value)
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(piece_sizes=[len(part) for part in pieces],suffix_correct=len(pieces)>1 and pieces[1]==pieces[0][3:]))
        self.assertIsNone(caught);self.assertEqual(2,len(pieces));self.assertEqual(pieces[0][3:],pieces[1])

    def test_fsync_failure_allows_one_known_close_and_first_error(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN metadata fsync');closes=[]
        def operation(resource,step,value=None):
            if resource['role']=='source_audit' and step=='fsync':raise failure
            result=actual(resource,step,value)
            if resource['role']=='source_audit' and step=='close':closes.append(resource['fd'])
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_same_audit_close_count=len(closes)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(closes))
        self.assertTrue(self.resource(run,'source_audit')['close_returned'])
        self.assertEqual('OSError',json.loads((run.directory/'receipt-failure.json').read_bytes())['primary_error'])

    def test_actual_close_then_error_is_never_reclosed_or_followed_by_publication(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN after metadata close');closes=[]
        def operation(resource,step,value=None):
            result=actual(resource,step,value)
            if resource['role']=='source_audit' and step=='close':
                closes.append(resource['fd']);raise failure
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(actual_close_calls=len(closes)))
        self.assertTrue(caught is failure);self.assertEqual(1,len(closes))
        resource=self.resource(run,'source_audit');self.assertFalse(resource['close_returned'])
        self.assertFalse((run.directory/'receipt-failure.json').exists())
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            producer._receipt_resource_close(run,resource,failure)
        calls.assert_not_called()

    def test_input_close_uncertainty_prevents_next_copy_input_open(self):
        run=self.prepared();actual=producer._receipt_resource_io;failure=OSError(5,'OWN input close uncertainty');opened=[]
        def operation(resource,step,value=None):
            if step=='open':opened.append(resource['role'])
            result=actual(resource,step,value)
            if resource['role']=='copy_input-000' and step=='close':raise failure
            return result
        with mock.patch.object(producer,'_receipt_resource_io',operation):
            caught,result,value=self.capture(run,lambda:producer.emit_fixture_receipt(run,'canonical'),
                lambda:dict(opened_roles=list(opened)))
        self.assertTrue(caught is failure);self.assertNotIn('copy_input-001',opened)
        self.assertFalse((run.directory/'receipt-failure.json').exists())

    def test_second_emit_refuses_before_resource_IO(self):
        run=self.prepared();producer.emit_fixture_receipt(run,'canonical')
        with mock.patch.object(producer,'_receipt_resource_io') as calls:
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        calls.assert_not_called()

    def tearDown(self):
        self.actions.pop('callback',None)
        for run in self.runs:
            for resource in run.__dict__.get('_receipt_resources',[]):
                if type(resource['fd']) is not int or resource['close_attempted']:continue
                # NEW finite-unit-only known-FD cleanup, never controller permission.
                info=os.fstat(resource['fd']);path=resource['path'].stat()
                self.assertEqual((info.st_dev,info.st_ino),(path.st_dev,path.st_ino))
                os.close(resource['fd']);self.fixture_fd_closes.append(dict(role=resource['role'],
                    fd=resource['fd'],fixture_only_close_returned=True,source_flags_not_retagged=True))
        with (self.base/'fixture-only-resource-closes.json').open('x') as out:json.dump(self.fixture_fd_closes,out,indent=2)
        ReceiptErrorRetentionTests.tearDown(self)

