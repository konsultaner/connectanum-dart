
def _receipt_resource_error(run,resource,stage,error,uncertain=False,secondary=False):
    if resource['first_error'] is None:resource['first_error']=error
    resource['error_stage']=stage
    if uncertain:
        resource['quarantined']=True
        run._receipt_resources_quarantined=True
    _retain_receipt_error(run,stage,error,secondary=secondary)

def _receipt_resource_context(run):
    if type(run._receipt_resources) is not list:
        raise ProducerError('unknown receipt resource ledger')
    if run.lease_check is not run._receipt_resource_lease:
        raise ProducerError('receipt lease callback changed')
    run._receipt_resource_lease()
    if (run.lease_check is not run._receipt_resource_lease
        or run.directory is not run._receipt_resource_directory
        or type(run.directory) is not type(Path())):
        raise ProducerError('receipt directory or callback changed')

def _receipt_resource_guard(run,resource,closing=False):
    if (type(resource) is not dict or any(type(k) is not str for k in resource)
        or not any(item is resource for item in run._receipt_resources)):
        raise ProducerError('unknown exact receipt resource')
    if resource['quarantined'] or resource['close_attempted']:
        raise ProducerError('receipt resource is quarantined or retired')
    if run._receipt_resources_quarantined and not closing:
        raise ProducerError('receipt resource ledger is quarantined')
    try:
        _receipt_resource_context(run)
        if type(resource['binding']) is not tuple or len(resource['binding'])!=3:
            raise ProducerError('unknown receipt resource binding')
        role,path,direction=resource['binding']
        if (resource['role'] is not role or resource['path'] is not path
            or resource['direction'] is not direction or type(path) is not type(Path())
            or path.parent!=run._receipt_resource_directory):
            raise ProducerError('receipt resource binding changed')
        fd=resource['fd']
        if type(fd) is not int or fd<0:raise ProducerError('unknown receipt resource FD')
        import fcntl
        info=os.fstat(fd);current_path=path.lstat()
        identity=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink)
        current=identity(info)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or current!=identity(current_path)
            or os.get_inheritable(fd) is not False
            or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=(os.O_WRONLY if direction=='write' else os.O_RDONLY)):
            raise ProducerError('receipt FD/path/direction changed')
        if resource['identity'] is None:
            resource['identity']=current
            resource['initial_size']=info.st_size
        if current!=resource['identity']:raise ProducerError('receipt FD identity drift')
        expected_size=resource['offset'] if direction=='write' else resource['initial_size']
        if info.st_size!=expected_size:raise ProducerError('receipt file size changed')
        if not (closing and resource['read_uncertain']):
            position=os.lseek(fd,0,os.SEEK_CUR)
            if type(position) is not int or position!=resource['offset']:
                raise ProducerError('receipt FD position changed')
        for other in run._receipt_resources:
            if other is resource or other['close_returned'] is True:continue
            if type(other['fd']) is int and other['fd']==fd:
                raise ProducerError('active receipt FDs alias')
    except BaseException:
        resource['quarantined']=True;run._receipt_resources_quarantined=True
        raise

def _receipt_resource_open(run,role,path,direction):
    if (type(role) is not str or type(path) is not type(Path()) or type(direction) is not str or direction not in ('read','write')
        or type(run._receipt_resources) is not list or run._receipt_resources_quarantined):
        raise ProducerError('receipt resource opening refused')
    if any(type(item) is not dict or type(item.get('path')) is not type(Path()) for item in run._receipt_resources):
        raise ProducerError('unknown earlier receipt resource fields')
    if any(item['path']==path for item in run._receipt_resources):
        raise ProducerError('receipt resource path attempt is permanently terminal')
    resource=dict(role=role,path=path,direction=direction,binding=(role,path,direction),
        fd=None,raw_open_return=None,identity=None,initial_size=None,offset=0,
        open_attempted=False,open_returned=None,close_attempted=False,close_returned=None,
        write_attempted=False,last_write_count=None,write_uncertain=False,read_uncertain=False,
        pending_payload=None,pending_offset=0,last_read=None,fsync_attempted=False,fsync_returned=None,
        quarantined=False,first_error=None,error_stage=None)
    run._receipt_resources.append(resource) # Reserve and retain BEFORE any fallible open/metadata IO.
    try:
        _receipt_resource_context(run)
        if path.parent!=run._receipt_resource_directory:
            raise ProducerError('receipt resource path outside original directory')
        resource['open_attempted']=True
        flags=os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK
        flags|=(os.O_WRONLY|os.O_CREAT|os.O_EXCL) if direction=='write' else os.O_RDONLY
        returned=_receipt_resource_io(resource,'open',flags)
        resource['raw_open_return']=returned
        if type(returned) is not int or returned<0:raise ProducerError('unknown receipt open return')
        resource['fd']=returned # Exact raw FD retained BEFORE callback/fstat or other IO.
        resource['open_returned']=True
        _receipt_resource_guard(run,resource)
        if direction=='write' and resource['initial_size']!=0:
            raise ProducerError('new receipt output is not empty')
        return resource
    except BaseException as error:
        if resource['open_returned'] is None:resource['open_returned']=False
        _receipt_resource_error(run,resource,'resource_open',error,True)
        raise

def _receipt_resource_io(resource,step,value=None):
    if step=='open':return os.open(resource['path'],value,0o666)
    if step=='write':return os.write(resource['fd'],value)
    if step=='read':return os.read(resource['fd'],value)
    if step=='fsync':return os.fsync(resource['fd'])
    if step=='close':return os.close(resource['fd'])
    raise ProducerError('unknown receipt resource IO step')

def _receipt_resource_write(run,resource,payload):
    if type(payload) is not bytes:raise ProducerError('receipt payload must be exact bytes')
    if run._receipt_resources_quarantined or resource['direction']!='write' or resource['pending_payload'] is not None:
        raise ProducerError('receipt write state unavailable')
    resource['pending_payload']=payload;resource['pending_offset']=0
    try:
        while resource['pending_offset']<len(payload):
            _receipt_resource_guard(run,resource)
            resource['write_attempted']=True
            remaining=payload[resource['pending_offset']:]
            count=_receipt_resource_io(resource,'write',remaining)
            resource['last_write_count']=count
            if type(count) is not int or count<=0 or count>len(remaining):
                raise ProducerError('unknown receipt write count')
            resource['pending_offset']+=count;resource['offset']+=count
        resource['pending_payload']=None
    except BaseException as error:
        resource['write_uncertain']=True
        _receipt_resource_error(run,resource,'resource_write',error,True)
        raise

def _receipt_resource_read(run,resource,maximum):
    if resource['direction']!='read' or type(maximum) is not int or maximum<=0:
        raise ProducerError('invalid receipt read')
    try:
        _receipt_resource_guard(run,resource)
        value=_receipt_resource_io(resource,'read',maximum);resource['last_read']=value
        if type(value) is not bytes or len(value)>maximum:raise ProducerError('unknown receipt read return')
        resource['offset']+=len(value)
        return value
    except BaseException as error:
        resource['read_uncertain']=True
        _receipt_resource_error(run,resource,'resource_read',error)
        raise

def _receipt_resource_sync(run,resource):
    try:
        _receipt_resource_guard(run,resource)
        resource['fsync_attempted']=True
        _receipt_resource_io(resource,'fsync')
    except BaseException as error:
        if resource['fsync_attempted']:resource['fsync_returned']=False
        _receipt_resource_error(run,resource,'resource_fsync',error)
        raise
    else:resource['fsync_returned']=True

def _receipt_resource_close(run,resource,primary=None):
    # Unknown write/identity/close MUST NOT be followed by close/reclose or replay.
    if resource['quarantined'] or resource['write_uncertain'] or resource['close_attempted']:return
    try:
        _receipt_resource_guard(run,resource,closing=True)
        resource['close_attempted']=True
        try:_receipt_resource_io(resource,'close')
        except BaseException:
            resource['close_returned']=False
            raise
        else:resource['close_returned']=True
    except BaseException as error:
        _receipt_resource_error(run,resource,'resource_close',error,True,secondary=primary is not None)
        if primary is None:raise

def _receipt_json(run,role,path,value):
    resource=_receipt_resource_open(run,role,path,'write');primary=None
    try:
        payload=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
        _receipt_resource_write(run,resource,payload)
        _receipt_resource_sync(run,resource)
    except BaseException as error:
        primary=error;_retain_receipt_error(run,role,error)
        raise
    finally:_receipt_resource_close(run,resource,primary)

