import sys,pathlib,json,subprocess,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-receipt-resources-design')
 source=(p/'plan-v2.json').read_bytes()
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--num-predict','1500','--max-response-chars','9000','--max-input-chars','40000','--timeout','180','--save-output',str(p/'tests.txt'),'--prompt','Give at most5 focused unittest cases for NEW raw-FD receipt-resource ledger/quarantine plan. Before real BufferedWriter over controlled RawIO/actualFileIO may reflush duplicate metadata after injected post-real-write failure; after explicit rawFD writes must retain unknown payload, skip close/reporting/replay. Cover partial suffix writes, close-then-error/FD reuse, declaration-before-open, unchanged JSON bytes/Fixture kind and first errors. Legacy negative seams must move to bound IO helpers explicitly. No fake Git/SDK/physical-release/heap claims. Max400words/advisory.']
 (p/'tests-command-before.json').write_text(json.dumps(dict(argv=argv,input_sha256=hashlib.sha256(source).hexdigest(),no_source_execution=True),indent=2)+'\n')
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(source);status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (p/('tests-'+label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_size=len(stdout),stderr_size=len(stderr),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (p/'tests-finish.json').write_text(json.dumps(result,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
