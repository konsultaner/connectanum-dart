import sys,pathlib,ast,hashlib,json,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-receipt-resources-design')
 source_path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
 source=source_path.read_bytes();assert hashlib.sha256(source).hexdigest()=='5847df17f0a3acac8a7d54b942c5096a52e13ffa248812cbd12cbccd53d7dfb0'
 source_text=source.decode();lines=source_text.splitlines();tree=ast.parse(source_text)
 selected='\n\n'.join('\n'.join(lines[node.lineno-1:node.end_lineno]) for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('_receipt_resource_context','_receipt_resource_guard','_receipt_resource_write','_receipt_resource_close'))
 context='Review current NEW receipt raw-FD resources. Source helpers/integration only; no full actor/EX release/admission claim. Finite Fixture tests only, never actual SDK/build. Ledger reserved before open, exact FD retained before callbacks/metadata. Unknown write no close/replay/failure JSON. Fsync error permits known close. Callback is mutable/foreign; bounded observations not globally atomic. Identify max2 concrete actionable gaps supported by selected source, max250words. No invented API, no permission weakening, no retry or replay advice. ROOT independently verifies. Historical generic helpers own other FDs outside this ledger.\n\n'+selected
 assert len(context)<34000
 def put(name,data):
  with (work/name).open('x') as out:json.dump(data,out,indent=2);out.write('\n')
 with (work/'focused-review-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','focused-review','--stdin','--num-predict','2300','--max-response-chars','10000','--max-input-chars','34000','--timeout','180','--save-output',str(work/'focused-review.txt'),'--prompt','Review supplied current receipt resource source. Max1 concrete bug/max250words. Preserve fail-closed unknown IO and no replay. Advisory only.']
 put('focused-review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(source).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('focused-review-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('focused-review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-10000:])
