import sys,pathlib,json,ast,hashlib,subprocess,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 source_root=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 cache=pathlib.Path('/tmp/connectanum-native-perf-receipt-resources');design=pathlib.Path('/tmp/connectanum-native-perf-receipt-resources-design')
 root=pathlib.Path('/tmp/connectanum-native-perf-receipt-resources-root-assessment');root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as output_file:json.dump(value,output_file,indent=2);output_file.write('\n')
 put(root/'attempt.json',dict(scope='NEW final receipt resource source component qualification',source_edit=False,runtime_edit=False,wholephysical_EX_release_or_admission=False))
 original=json.loads((cache/'original-hashes.json').read_text());final=json.loads((cache/'caller-handler-hashes.json').read_text())
 assert all(sha((source_root/rel).read_bytes())==digest for rel,digest in final.items())
 assert {rel for rel in original if original[rel]!=final[rel]}=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 before_source=(cache/'original-source/tool/native_perf_build_producer.py').read_text()
 final_source=(source_root/'tool/native_perf_build_producer.py').read_text()
 def nodes(text):
  return {node.name:ast.get_source_segment(text,node) for node in ast.parse(text).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
 before_nodes=nodes(before_source);final_nodes=nodes(final_source)
 changed_original_functions=[]
 for name,body in before_nodes.items():
  if name=='CommandProducer':continue
  if name in ('_receipt_source_audit','_emit'):
   changed_original_functions.append(name);continue
  assert final_nodes[name]==body,name
 def methods(text,class_name):
  node=next(node for node in ast.parse(text).body if isinstance(node,ast.ClassDef) and node.name==class_name)
  return {method.name:ast.get_source_segment(text,method) for method in node.body if isinstance(method,ast.FunctionDef)}
 old_methods=methods(before_source,'CommandProducer');new_methods=methods(final_source,'CommandProducer')
 assert set(old_methods)==set(new_methods)
 assert all(old_methods[name]==new_methods[name] for name in old_methods if name!='__init__')
 def ctor_tree(text):
  node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='CommandProducer')
  method=next(n for n in node.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
  method.body=[n for n in method.body if not (isinstance(n,ast.Assign) and any(isinstance(target,ast.Attribute) and target.attr.startswith('_receipt_resource') for target in n.targets))]
  return ast.dump(method,include_attributes=False)
 assert ctor_tree(before_source)==ctor_tree(final_source)
 assert before_nodes['_emit'].split('run.receipt_attempted=True')[0]==final_nodes['_emit'].split('run.receipt_attempted=True')[0]
 before_test=(cache/'original-source/tool/test_native_perf_build_producer.py').read_text();final_test=(source_root/'tool/test_native_perf_build_producer.py').read_text()
 original_test_nodes=nodes(before_test);final_test_nodes=nodes(final_test)
 changed_tests={'ProducerTests':{'test_receipt_partial_publication_is_terminal_without_second_read'},
  'ReceiptErrorRetentionTests':{'audit_close','copy_failure','test_partial_failure_publication_keeps_primary_secondary_and_no_retry','test_same_primary_object_at_publication_retains_secondary_occurrence'}}
 for name,body in original_test_nodes.items():
  if name not in changed_tests:assert final_test_nodes[name]==body,name
  else:
   old=methods(before_test,name);new=methods(final_test,name);assert set(old)==set(new)
   assert all(old[method]==new[method] for method in old if method not in changed_tests[name])
 put(root/'structural-qualification.json',dict(
  original_module_nodes_except_receipt_audit_emit_and_constructor_byteexact=True,
  all_other_CommandProducer_methods_byteexact=True,all_Auxiliary_and_owner_classes_byteexact=True,
  constructor_only_resource_initializers=True,emit_existing_gates_byteexact=True,
  five_legacy_negative_test_seams_explicitly_migrated=changed_tests_as_lists if False else {key:sorted(value) for key,value in changed_tests.items()},
  other_original_test_methods_and_classes_byteexact=True,
  other18tools_and3bins_byteexact=True,source_functions_ADDED=sorted(set(final_nodes)-set(before_nodes))))
 stages={}
 fixture_reports={}
 for stage in ['before','implemented','legacy-adapted','callback-before','callback-fixed','caller-handler']:
  report_path=cache/(stage+'-tests.json');raw=report_path.read_bytes();report=json.loads(raw)
  stages[stage]=dict(tests=report['tests'],failures=report['failures'],errors=report['errors'],sha256=sha(raw),path=report_path.relative_to(cache).as_posix())
  fixture_reports[stage]=[]
  for pattern in ['new-known-actors.json','resource-control-before-cleanup.json','fixture-only-resource-closes.json']:
   for path in sorted((cache/(stage+'-fixtures')).rglob(pattern)):
    raw=path.read_bytes();data=json.loads(raw)
    fixture_reports[stage].append(dict(path=path.relative_to(cache).as_posix(),sha256=sha(raw),size=len(raw),
      record_kind=pattern,top_keys=sorted(data) if type(data) is dict else None))
 assert [(stages[s]['tests'],stages[s]['failures'],stages[s]['errors']) for s in stages]==[(8,1,7),(9,0,0),(10,0,0),(2,2,0),(6,0,1),(1,0,0)]
 models={}
 for name in ['judge','tests','review','focused-review','focused-review-v2']:
  data=json.loads((design/(name+'-finish.json')).read_text());models[name]=data
 assert models['judge']['direct_status']==models['tests']['direct_status']==models['focused-review-v2']['direct_status']==0
 assert models['review']['direct_status']==1 and models['focused-review']['direct_status']==2
 commands=[];known_children=[]
 def git(*args):
  record=dict(argv=['git','-C',str(source_root),*args],pid=None,status=None,stdout_eof=False,stderr_eof=False);commands.append(record)
  child=subprocess.Popen(record['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);known_children.append(child);record['pid']=child.pid
  stdout,stderr=child.communicate();record['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (root/('git-'+str(len(commands))+'-'+label+'.bin')).open('xb') as output_file:output_file.write(raw)
   record[label+'_eof']=True;record[label+'_sha256']=sha(raw);record[label+'_size']=len(raw)
  put(root/('git-'+str(len(commands))+'-return.json'),record)
  assert record['status']==0;lease.verify_identity();return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain');production_diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify')
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert len(status.splitlines())==20 and {line[3:] for line in status.splitlines()}=={rel for rel in final if rel.startswith('tool/')}
 assert production_diff==''
 assessment=dict(kind='receipt_raw_FD_resource_source_component_v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],bundle20_plus3bins=final,
  behavior='Private receipt resource ledger reserves record before open and retains exact raw returned FD before callback/metadata. Receipt outputs attempt/audit/complete_log/input_receipt/binding/failure and copy-input read FDs use raw os IO, preserving JSON bytes and exclusive terminal paths. Raw FD output avoids BufferedWriter implicit userspace reflush. Known positive short writes advance only suffix; unknown write/count retains pending bytes/offset and quarantines with no fsync/close/replay/failure JSON. Any unknown open/close quarantines all later opens. Fsync error may allow one guarded close. Read error may allow one identity-checked close without re-reading. Close intent precedes nativeclose; normal return/exception remain distinct, unknownclose never recloses or treats retired numeric FD as live.',
  callback_fix='NEW before2FAIL: callback ledger replacement and same-file separate borrowed-FD substitution passed old checks and reached MOCKED IO. No actual wrong-FD write established. Guard context now retains exact ledger/list-of-record identities and every current exact dict field reference before callback, then rejects any observed replacement/cardinality/record/field drift using identity and exact-string key checks before lookups. Original directory/callback references also held across callback. Bounded observations, not atomic/globalABA/auth/foreignwrite prevention.',
  fixtures='Actual finite OWN Git/FIXTURE/six shell version SHIMS and finite Python/synthetic outputs, never actual SDK/compiler/version/bootstrap/native/canonical. Initial replay regression wraps native BufferedWriter over controlled RawIO/realFileIO with post-actual-os.write fault; BEFORE exhibits duplicate write on implicit close, unit fault model not measured original kernel/RAM/data-loss. AFTER one actual write/pending payload retained/no source close/report. Positive Fixture JSON sortedindent2newline and compact auditJSONL byte formats checked. Native fsync/actual-close-then-fault controls; callback controls native write mocked. ROOT actual officialEX through known finite children/threads; unit callbacks synthetic.',
  tests='Before8=1FAIL7missing-helper-APIERROR, not7production defects. Implemented9PASS=8new+1required positive emitter. Explicitly migrated five old negative test seams to rawFD and stricter no-publication after unknown IO; selected10PASS separate, not unchanged blanket suite. NEWcallback2FAIL then selected6=5PASS plus1 loader ERROR from wrong coordinator required-test name. Corrected missing caller-handler control1PASS separate; no rerun of five passing controls. Ten new test cases exist, no combined full-final suite or canonical result.',
  legacy_policy='Five legacy negative methods keep earliest error/secondary identities, partial bytes and terminal/no-second-read assertions. Audit/copy unknownclose and unknownopen now suppress failure JSON instead of attempting metadata IO. Same-primary pre-write failure produces existing empty file b-empty rather than absent buffered report. Test seam/policy changes explicit, not silently dropped assertions.',
  raw_limits='New actual setup Git argv/signedsamePopenwait/BOTHEOF/rawfilesSHA and available LASTrecipe/Aux finalwait plus auxiliary EOF/FDpath/digest rows retained. Prior overwritten command Popen handles not reconstructed; reported0 not full waitjournal/SDK proof. Required legacy setup/APIreturns and all private FD scalars not systematically serialized. Exact errors live privately; persisted booleans/types/stages not error objects. Fixture-only exact own FD close/field restore for negative teardown is never live cleanup/controller permission; source flags never retagged. Process-life resource/error history not heap/RSS bound.',
  models=models,model_qualification='GLM architecture+Qwen tests complete0/advisory. GLM selected current052c review tokenlimit1800/direct1/stdout0/reported4483visiblechars/fullpartialfinalABSENT/reachable/reaped, not unavailable/approval. ROOT independently adds callback regressions/final5847 guard. First focusedreview command typo focused-review invalid CLI/direct2 before backend request. Distinct corrected selected FOUR-method Qwen review5847 complete0/reaped, not fullcurrent-source model approval. ROOT rejects automatic-close-on-identity-uncertainty, inferring unknown write progress/atomic Python-syscall update or relaxing original callback identity; quarantine intentionally retains unresolved handles and forbids replay. Focused review does not prove fullphysical closure.',
  administrative_failures='Outer legacy exec output exceeded model context after actual retained10PASS; consumed retained results without rerun. Callback-fixed coordinator selected nonexistent required caller name =>1loaderERROR, not implementation defect; exact correction executes only previously unexecuted intended caller. First focused review invalidjob parserdirect2/fullstderr retained; no backend model request. Earlier receipt-error branch unknownPID/status/buffers remain unknown forever; NEW declared3:20 branch preflight and finalsource posttest queries are separate purposes/epochs, not reconstruction.',
  remaining='Generic metadata/source hash/read helpers still own OTHER FDs outside this receipt-only ledger. Receipt audit launches auxiliary actors; partial actor/unknownstarts, historical recipe/Git/interpreter/delegate/write-end/descendant coverage and complete independent physicalofficialEX controller remain incomplete. Owner_emit_attempted freeze refusal and old auxiliary predicates unchanged. Resource closes/status/EOF/join/emptyledger/filedata do NOT grant EXrelease or admission. OriginalPATH SDK/bootstrap/first3locks-hiddenconfigs/current20validation-canonical/newsourceepoch package/OWNnative-driver-staticRLIB/compiler-tool-kernel and actualoriginalhost credential/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage still required. No borrowed config/native/cohort/SDKchange/favorableredo/postGO aspreproof.',
  stages=stages,retained_fixture_reports=fixture_reports,posttest_own_Git=commands,posttest_branch=branch,posttest_HEAD=head,
  source_only=True,other18and3bins_byteexact=True,all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,
  actual_native_outputs_instructionclosure_not_proved=True,privatecontrollers_outside_HELPERBUNDLE20=True,
  provider_absent=True,live_gate_always_raises=True,live_controller_closed=True,ownership_complete=None,all3admission_flags=False,
  no_actual_SDK_build_canonical_kernel_broker_benchmark_capture=True,no_RAMcause_repair_or_acceptance=True,
  no_source_commit_push_adoption_strictdispatch=True,free_after=os.statvfs(source_root).f_bavail*os.statvfs(source_root).f_frsize,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['receipt_resources_component'].update(assessment=str(root/'assessment.json'),root_assessment=str(root),review_pending=False,publication_pending=True,
  ROOT_final_source_review=True,full_current_source_model_approval=False,all_known_own_model_test_sessions_terminal=True,never_repeat_unchanged=True)
 native['current_helper_source_epoch'].update(producer_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],hashes_file=str(cache/'caller-handler-hashes.json'))
 native['last_free_bytes']=assessment['free_after'];value['active_turn_status']='receipt_resources_ROOT_qualified_publication_pending'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],free_after=assessment['free_after'],new_posttest_Git=4)))
