import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-producer-failure-preservation-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());beforeh=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts.json').read_text())
 assert source==(P/'candidate-v1.py').read_text()
 assert source.replace(parts['helpers'],'',1).replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'preservation_regressions-v1.py').read_bytes()
 ast.parse(source);ast.parse(tests)
 assert sorted(k for k in h if h[k]!=beforeh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(7,5,2,0);assert(a['tests'],a['failures'],a['errors'])==(15,0,0)
 assert len(b['leases'])==14 and len(a['leases'])==30 and all(r['raw_None'] for r in b['leases']+a['leases'])
 def views(path):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if 'record_original_events' in v}
 old=views(P/'before-units/fixtures');new=views(P/'after-selected/fixtures');assert len(old)==len(new)==7
 assert old['repr_note_mask'][0]['received_note_fault'] and not old['repr_note_mask'][0]['received_first']
 for mode in ('repr_fault','writer_unknown','writer_False'):
  v=old[mode][0];assert v['original_journal_closed'] and v['owner_events_None']
 waits={};cleanup={}
 for phase,data in [('before',old),('after',new)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())]
  known=[r for r in rows if r['kind']=='ROOT_same_original_bound_wait']
  assert len(known)==7 and all(type(r['status']) is int and r['status']==0 for r in known)
  waits[phase]=known;cleanup[phase]=rows
 for mode,(v,d) in new.items():
  assert v['received_first'] and not v['Source_pending'] and v['Source_returncode']==0 and v['Source_output_log_complete'] and not v['Source_evidence_complete']
  assert v['record_present'] and v['record_original_events'] and v['record_primary_first'] and all(r['raw_None'] for r in v['leases'])
  assert not any(c['kind'] in ('add_note_first','str_first') for c in v['calls'])
  rows=v['Source_steps']
  if mode in ('normal','normal_close_False'):
   assert v['record_completed'] and v['owner_events_None'] and v['original_journal_closed'] and v['failure_exists']
   close=next(r for r in rows if r['stage']=='journal_close');assert close['returned']
   if mode=='normal_close_False':assert close['raw_False']
   else:assert close['raw_None']
  else:
   assert not v['record_completed'] and v['pure_guard_first']
   if mode!='close_unknown':
    assert v['owner_events_original'] and not v['original_journal_closed'] and not any(r['stage']=='journal_close' for r in rows)
   if mode in ('repr_fault','repr_note_mask'):
    row=next(r for r in rows if r['stage']=='error_repr');assert not row['returned'] and row['raw_None'] and row['error_is_secondary'] and not v['failure_exists']
   if mode=='writer_unknown':
    row=next(r for r in rows if r['stage']=='failure_write');assert not row['returned'] and row['raw_None'] and row['error_is_secondary'] and v['failure_exists']
   if mode=='writer_False':
    row=next(r for r in rows if r['stage']=='failure_write');assert row['returned'] and row['raw_False'] and v['failure_exists']
   if mode=='close_unknown':
    row=next(r for r in rows if r['stage']=='journal_close');assert not row['returned'] and row['raw_None'] and row['error_is_secondary'] and v['original_journal_closed'] and v['owner_events_None']
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
 before=dict(tests=7,failures=5,passes=2,errors=0,meaning='one firstreplacement viahostileadd_note; unknownrepr/writer-publication continuation andstrongerprogress/refusal policies not5nativekernelbugs/RAMcause'),after=a,
 ROOT=dict(whole_final_Source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=14,parent_BEFORE_EXverify_None=14,parent_AFTER_EXverify_None=30,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup,allotherSourcebodies_Aux_Popen_factories_sharedstep_initialization_deferfailure_finish_frozenpredicates_exact=True),
 models=dict(Qwen=json.loads((P/'test-planning/result.json').read_text()),GLM=json.loads((P/'candidate-review/result.json').read_text()),GLM_full_partial_final='ABSENT/tokenlimit1/notreconstructed',ROOT_independent_qualification_NOTwholecurrent_modelapproval=True),
 limits=['ONLYenclosing_preserve_failure body: firstreceivederrorprivategroup/originaljournal/percallintent-raw/secondaryobjects/unknown-invalidstop/pureguard. _defer_failure/_finish andearlier-enclosing/transitiveAPI flows unchanged/incomplete.',
 'NormalfailureJSON payload/nativeerrorrepr/deferredNone-string, oldsinglefailure_attempted, originaleventsNone BEFOREclose andignoredcloseNone-False-object contract retained. Completedhelper flag DATA notproducer-success/ownership/EX/admission. Successfulhistoricalcontexts notfrozen.',
 'Sourceunknownrepr/write/close return remainsUNKNOWN despiteROOTknowingactualwriterNone/fullfile/closeNone/closedflag. WriterFalse knowninvalidrefusedbeforejournalclose; closedflags/filebytes/status/finished/sourcefacts neverrelease/admission.',
 'Actualfinitefixture command originalnaturalwait+logcomplete+originalcommand_end event precedeROOTfirst.7BEFORE7AFTER SAMEoriginalboundROOTwait10 signed0/cachedpossible.14views/14BEFORE30AFTER parentCURRENT officialDarwinEXverifyNone/SourcecallbacksNone UNITnotindependentfullEX-originalLinuxcredentials-allFD/interpreter/delegate/descendantclosure.',
 'FixtureGitsetup ownoperationbeforelaunch/signedstatus+BOTHseparateEOF stored; SourceAuxiliaryactors metadata/legacysetup/internalFD APIs notallserialized. RootknownjournalRawclose BEFOREBufferedclose AFTERevidence/devino UNITnotSourcecleanup/recovery-EXrelease/globalabsence-fullreap; no omittedfact reconstruction.',
 'Qwen30558status0/full3617stdout569stderr ROOTqualified/rejectraisesNone, publicationabsenceonpostreturnfault, closedNone=>ownership, repeatedhelper replay. GLM31866tokenlimit1/0stdout1252stderr/fullpartialfinalABSENT/notreconstructed/reachable-reapedNOTunavailable-approval; no unchangedreviewrepeat. ROOTmanualwholefinalSource-tests-ASTqualified.',
 'Candidatev1/privatev1UNEXECUTEDbeforeedit/firstBEFORE;7BEFORE once/matching7+8affectedAFTER only. Editresult inheritedsuffixcaller flagkey refersnoauthority only; actualscope isenclosingfailurehandler, notAuxsuffix. AllnamedcontrollersBEFOREcalls/availableactualAPIreturns preserved.',
 'Source15selectedPASS=7matchingNEW+8affectedfailurecallers, notaggregate/fullcurrent20canonical/SDK/nativecompiled/admission. All20uncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact; no Sourcecommit-push-adoption/build-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.',
 'Strongowner/groups/primary-secondary objects/steps/refs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. Globalbinding/metadata/concurrentABA/getter-returnnegative/actualoriginalhandles/frozenhistorical/logsealing/transitiveunknownactors/fullindependentEX-originalruntimeimmutableCOMPLETEadmission remainINCOMPLETE.'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_failure_preservation_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Producer_failure_preservation_selected15PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected15PASS=True,views=14,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
