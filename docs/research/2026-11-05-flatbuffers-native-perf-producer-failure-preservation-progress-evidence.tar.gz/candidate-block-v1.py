_FAILURE_PRESERVATION_GROUPS={}
_FAILURE_PRESERVATION_RECORDS=[]


def _failure_preservation_group(owner,error):
    key=id(owner)
    previous=_FAILURE_PRESERVATION_GROUPS.get(key)
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        previous[1]()
        return previous
    primary=error
    quarantined=[False]
    secondary=[]

    def guard():
        if quarantined[0]:raise primary

    def refuse(received,row=None):
        quarantined[0]=True # Private terminal first BEFORE secondary metadata.
        try:
            if received is not primary:secondary.append(received)
            if row is not None:row['error']=received
        finally:
            raise primary

    group=(owner,guard,refuse,primary,secondary)
    _FAILURE_PRESERVATION_GROUPS[key]=group # Strong owner/first, process lifetime.
    return group


def _failure_preservation_guard(owner):
    group=_FAILURE_PRESERVATION_GROUPS.get(id(owner))
    if group is not None:
        if group[0] is not owner:raise ProducerError('failure preservation owner identity changed')
        group[1]()


    def _preserve_failure(self,error):
        group=_failure_preservation_group(self,error)
        guard=group[1];refuse=group[2];primary=group[3]
        record=dict(owner=self,received_error=error,primary_error=primary,events=None,
            completed=False,steps=[])
        _FAILURE_PRESERVATION_RECORDS.append(record) # Before context lookup/I/O.

        def call(stage,lookup,args=()):
            guard()
            row=dict(stage=stage,attempted=True,lookup=lookup,args=args,
                method=None,returned=False,raw=None,error=None)
            record['steps'].append(row)
            try:
                method=lookup();row['method']=method
                raw=method(*args);row['raw']=raw;row['returned']=True
                return raw
            except BaseException as secondary:
                refuse(secondary,row)

        try:
            directory=call('directory',lambda:getattr,(self,'directory'))
            events=call('events',lambda:getattr,(self,'events'))
            record['events']=events # Original handle BEFORE representation/publication.
            pending=call('pending',lambda:getattr,(self,'pending'))
            attempted=call('failure_attempted',lambda:getattr,(self,'failure_attempted'))
            if type(pending) is not bool or type(attempted) is not bool:
                raise ProducerError('unknown failure preservation flags')
            if not attempted:
                self.failure_attempted=True # Original one terminal publication attempt.
                writer=call('failure_writer_lookup',lambda:lambda:_write_json)
                renderer=call('repr_lookup',lambda:lambda:repr)
                deferred=call('deferred_error',lambda:getattr,(self,'deferred_error'))
                if deferred is not None and type(deferred) is not str:
                    raise ProducerError('unknown deferred failure text')
                text=deferred or call('error_repr',lambda:renderer,(error,))
                if type(text) is not str:raise ProducerError('unknown failure representation')
                uncertain=self.output_write_uncertain
                if type(uncertain) is not bool:raise ProducerError('unknown output write uncertainty')
                payload={'error':text,'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance,
                    'output_write_uncertain':uncertain,
                    'unwritten_output_base64':base64.b64encode(self.output_buffer).decode('ascii') if uncertain else None}
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation context changed')
                raw=call('failure_write',lambda:writer,(directory/'failure.json',payload))
                if raw is not None:raise ProducerError('unknown failure publication return')
                if (self.directory is not directory or self.events is not events
                    or self.pending is not pending or self.failure_attempted is not True
                    or _write_json is not writer):
                    raise ProducerError('failure preservation publication context changed')
            if not pending and events is not None:
                if self.directory is not directory or self.events is not events or self.pending is not pending:
                    raise ProducerError('failure journal context changed')
                closer=call('journal_close_lookup',lambda:lambda:events.close)
                self.events=None # Preserve original clearing-before-close; handle retained.
                call('journal_close',lambda:closer) # Original ignored return, including False.
            record['completed']=True # Helper only, never ownership/EX/admission.
        except BaseException as secondary:
            refuse(secondary)
