"""NEW enclosing producer failure-publication controls; no Source recovery after refusal."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer


class ProducerFailurePreservationTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)

    def _preserve_case(self,mode):
        calls=[];actors=[];leases=[];seen={};evidence_ready=False;phase=['Source']
        class Secondary(ValueError):pass
        class NoteFault(RuntimeError):pass
        secondary=Secondary('ROOT reporting secondary');note_fault=NoteFault('ROOT add_note secondary')
        class First(OSError):
            def __repr__(self):
                calls.append(dict(kind='repr_first',phase=phase[0]))
                if mode in ('repr_fault','repr_note_mask'):raise secondary
                return BaseException.__repr__(self)
            def __str__(self):
                calls.append(dict(kind='str_first',phase=phase[0]));raise RuntimeError('ROOT forbidden str')
            def add_note(self,note):
                calls.append(dict(kind='add_note_first',phase=phase[0]))
                if mode=='repr_note_mask':raise note_fault
                return None
        first=First('ROOT after original command_end event')
        native_allocate=producer.CommandProducer._allocate_command_process
        native_event=producer.CommandProducer._event
        native_writer=producer._write_json
        def verifying():
            value=official_ex_verify();leases.append(dict(raw_None=value is None));return value
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,source_attempt=attempt,process=None,bound_wait=None,log=p.log,reader_fd=p.output_fd,writer_fd=writer)
            actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait
            return raw
        def event(p,event,**fields):
            raw=native_event(p,event,**fields)
            if event=='command_end':
                calls.append(dict(kind='actual_command_end_return',raw_None=raw is None))
                raise first
            return raw
        def writing(path,value):
            if path.name!='failure.json':return native_writer(path,value)
            calls.append(dict(kind='failure_writer_attempt'))
            raw=native_writer(path,value);calls.append(dict(kind='actual_failure_writer_return',raw_None=raw is None))
            if mode=='writer_unknown':raise secondary
            if mode=='writer_False':return False
            return raw
        p=None;received=None;guard_error=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer,'_write_json',writing):
                p=self.start(('ok',),lease_check=verifying)
                events=p.events;seen.update(events=events,buffered_close=events.close,raw=events.raw,raw_close=events.raw.close,raw_fileno=events.raw.fileno)
                fd=seen['raw_fileno']();info=os.fstat(fd);seen['identity']=(info.st_dev,info.st_ino)
                def closing():
                    calls.append(dict(kind='journal_close_attempt',phase=phase[0]))
                    raw=seen['buffered_close']();calls.append(dict(kind='actual_journal_close_return',phase=phase[0],raw_None=raw is None))
                    if mode=='close_unknown':raise secondary
                    if mode=='normal_close_False':return False
                    return raw
                events.close=closing
                with mock.patch.object(producer.CommandProducer,'_event',event):
                    try:p.wait(10)
                    except BaseException as error:received=error
                guard=getattr(producer,'_failure_preservation_guard',None)
                if mode not in ('normal','normal_close_False') and guard is not None:
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in getattr(producer,'_FAILURE_PRESERVATION_RECORDS',[]) if r.get('owner') is p]
            record=records[-1] if records else None
            rows=[] if record is None else record['steps']
            failure=p.directory/'failure.json';data=failure.read_bytes() if failure.exists() else None
            view=dict(mode=mode,received_type=None if received is None else type(received).__name__,received_first=received is first,received_note_fault=received is note_fault,
                Source_pending=p.pending,Source_finished=p.finished,Source_evidence_complete=p.evidence_complete,Source_returncode=p.records[-1]['returncode'],Source_output_log_complete=p.records[-1]['log_complete'],
                owner_events_original=p.events is events,owner_events_None=p.events is None,original_journal_closed=events.closed,original_raw_closed=seen['raw'].closed,
                failure_exists=data is not None,failure_size=None if data is None else len(data),failure_sha256=None if data is None else hashlib.sha256(data).hexdigest(),
                guard_present=guard is not None,pure_guard_first=guard_error is first,record_present=record is not None,
                record_original_events=False if record is None else record.get('events') is events,
                record_primary_first=False if record is None else record.get('primary_error') is first,
                record_completed=None if record is None else record.get('completed'),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,error_is_secondary=r.get('error') is secondary) for r in rows],
                calls=list(calls),leases=leases,fixture_Git=self.fixture_git_commands,
                limits='Actualfinitefixture worker originalnaturalwait beforeRootcommand_end first. Status/finished/closed/journaldata NOTownership/fullEX/admission. ROOTknownactorwait+RawFDcleanup AFTERviews/assertions UNITnotSourcecontinuation.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(received is first);self.assertFalse(p.pending);self.assertEqual(0,p.records[-1]['returncode']);self.assertTrue(p.records[-1]['log_complete'])
            self.assertTrue(all(x['raw_None'] for x in leases));self.assertFalse(any(c['kind']=='add_note_first' for c in calls))
            self.assertFalse(any(c['kind']=='str_first' for c in calls))
            if mode in ('normal','normal_close_False'):
                self.assertTrue(events.closed);self.assertIsNone(p.events);self.assertIsNotNone(data)
                published=json.loads(data);self.assertEqual(BaseException.__repr__(first),published['error']);self.assertEqual('fixture',published['provenance'])
                self.assertEqual(b'fixture-ok\n',(p.directory/'command-000.log').read_bytes())
                if record is not None:self.assertTrue(record['completed']);self.assertTrue(record['events'] is events)
            else:
                if mode!='close_unknown':self.assertFalse(events.closed);self.assertTrue(p.events is events);self.assertFalse(any(c['kind']=='journal_close_attempt' for c in calls))
                else:self.assertTrue(events.closed);self.assertIsNone(p.events)
                self.assertTrue(guard is not None,'pure failure-preservation guard missing');self.assertTrue(guard_error is first)
                self.assertTrue(record is not None);self.assertTrue(record['primary_error'] is first);self.assertTrue(record['events'] is events);self.assertFalse(record['completed'])
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is first)
                else:self.fail('permanently refused failure handler guard returned')
                self.assertEqual(count,len(calls))
        finally:
            phase[0]='ROOT_after_evidence';cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==0)
            if evidence_ready:
                raw=seen['raw'];row=dict(kind='ROOT_known_journal',raw_already_closed=raw.closed,raw_close=False)
                if not raw.closed:
                    fd=seen['raw_fileno']();a=os.fstat(fd);b=(p.directory/'journal.jsonl').stat();same=(a.st_dev,a.st_ino)==seen['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                    if same:returned=seen['raw_close']();row['raw_close']=True;row['raw_close_None']=returned is None
                if raw.closed:
                    try:returned=seen['buffered_close']();row['buffered_close_None']=returned is None
                    except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                row['raw_closed_after']=raw.closed;row['buffered_closed_after']=seen['events'].closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True,known_journal='events' in seen))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_repr_secondary_stops_before_note_and_journal_close(self):self._preserve_case('repr_fault')
    def test_hostile_note_cannot_mask_original_error(self):self._preserve_case('repr_note_mask')
    def test_actual_failure_writer_then_error_stops_unknown_publication(self):self._preserve_case('writer_unknown')
    def test_actual_failure_writer_then_False_stops_before_journal_close(self):self._preserve_case('writer_False')
    def test_actual_journal_close_then_error_retains_original_first_and_handle(self):self._preserve_case('close_unknown')
    def test_new_normal_failure_publication_and_journalclose_None(self):self._preserve_case('normal')
    def test_new_normal_ignored_journalclose_False_after_actual_close(self):self._preserve_case('normal_close_False')
