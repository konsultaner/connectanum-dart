import sys,pathlib,json,ast,hashlib,subprocess,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-producer-finish-publication-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();parts=json.loads((P/'projection-parts-v2.json').read_text())
 assert source==(P/'candidate-v2.py').read_text()
 assert source.replace(parts['helper'],'',1).replace(parts['newwait'],parts['oldwait'],1).replace(parts['new_suffix'],parts['old_suffix'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'finish_regressions-v3.py').read_bytes();ast.parse(source);ast.parse(tests)
 assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 b=json.loads((P/'before-units-v3/result.json').read_text());a=json.loads((P/'after-selected/result.json').read_text());assert(b['tests'],b['failures'],b['passes'],b['errors'])==(8,6,2,0);assert(a['tests'],a['failures'],a['errors'])==(18,0,0)
 assert len(b['leases'])==16 and len(a['leases'])==36 and all(r['raw_None'] for r in b['leases']+a['leases'])
 def views(path):
  return {v['mode']:(v,f.parent) for f in sorted(path.glob('*/view-before-ROOT-cleanup.json')) for v in [json.loads(f.read_text())] if 'record_original_result' in v}
 old=views(P/'before-units-v3/fixtures');new=views(P/'after-selected/fixtures');assert len(old)==len(new)==8
 assert old['write_False'][0]['wait_returned'] and old['write_False'][0]['Source_evidence_complete']
 for mode in ('write_unknown','result_hash_unknown','event_unknown','close_unknown','journal_hash_unknown'):
  assert old[mode][0]['received_first'] and any(x['kind']=='forbidden_preserver' for x in old[mode][0]['calls'])
 waits={};cleanup={}
 for phase,data in [('before-v3',old),('after',new)]:
  rows=[r for v,d in data.values() for r in json.loads((d/'ROOT-unit-cleanup.json').read_text())];known=[r for r in rows if r.get('kind')=='ROOT_same_original_bound_wait']
  assert len(known)==8 and sum(r['status']==0 for r in known)==7 and sum(r['status']==3 for r in known)==1
  waits[phase]=known;cleanup[phase]=rows
  for r in rows:
   if r.get('kind') in ('ROOT_known_log','ROOT_known_journal'):assert r['raw_closed_after']
 for mode,(v,d) in new.items():
  assert v['public_producer_returned'] and v['record_present'] and v['record_original_journal'] and v['record_original_result']
  assert all(row['raw_None'] for row in v['leases']) and not any(c['kind'] in ('forbidden_preserver','repr_first','note_first') for c in v['calls'])
  rows=v['Source_steps'];stages=['result_write','result_hash','finished_event','journal_close','journal_hash']
  if mode in ('normal','normal_failed'):
   assert v['wait_returned'] and v['record_completed'] and v['Source_evidence_complete'] and v['original_journal_closed'] and v['Source_events_None']
   assert v['result_status']==('failed' if mode=='normal_failed' else 'success') and v['Source_returncode']==(3 if mode=='normal_failed' else 0)
   assert [r['stage'] for r in rows]==stages and all(r['returned'] for r in rows)
   if mode=='normal_failed':assert rows[3]['raw_False']
  else:
   assert not v['wait_returned'] and not v['record_completed'] and not v['Source_evidence_complete'] and not v['failure_exists']
   assert v['pure_guard_same_received'] and v['record_primary_received']
   stop={'write_unknown':0,'write_False':0,'result_hash_unknown':1,'event_unknown':2,'close_unknown':3,'journal_hash_unknown':4}[mode]
   assert [r['stage'] for r in rows]==stages[:stop+1]
   if mode=='write_False':assert v['received_type']=='ProducerError' and rows[-1]['raw_False'] and rows[-1]['returned']
   else:assert v['received_first'] and not rows[-1]['returned'] and rows[-1]['raw_None'] and rows[-1]['error_first']
   if stop<3:assert not v['original_journal_closed'] and not v['Source_events_None']
   else:assert v['Source_events_None']
 models={k:json.loads((P/d/'result.json').read_text()) for k,d in [('Qwen','test-planning'),('GLM','candidate-review')]}
 assert models['Qwen']['status']==0 and models['GLM']['status']==1 and not (P/'candidate-review/answer.txt').exists()
 assert all(json.loads((P/d/'result.json').read_text())['errors']==8 for d in ('before-units','before-units-v2'))
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 limits=[
 'ONLY_finish publication suffix and wait catchguard scope complete. Originaloutput selection/payload/resultliteral/initialfinishedTrue andresultassignment beforepublication unchanged DATA; earlierfinish setup/endcommand/enclosingearlyreporting/globalbindings/concurrentABA/historical/transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission incomplete.',
 'BEFORE8v3=6FAIL2normalPASS0ERROR:1invalidwriterFalse acceptedactualsuccess +5actualcallee-thenROOTfirst unknownreturns enterenclosing failurepreserver/repr/close; 5oldfirst alreadyescapes, strongerretention/refusal policies NOT6nativekernelbugs/RAMcause. AFTER18=8matchingNEW+10affectedactualwait-success-failure-timeout-multicommand-deferral-2fixtureReceipts-logclose callers. No unchangedwriter-hash-Aux suites/numerical/modelreplay; notaggregate/current20canonical/admission.',
 'Originaljournal/result/context/percallintent/rawbeforecheck. ActualnativewriterNone/digests/eventNone/closeNone ROOTknownvalues neverfillSourceunknownrawNone-returnedFalse. KnownFalsewriter invalid BEFORElaterIO; actualcloseNone-thenFalse ignorednormal. Negativeonlypureguard/no SourcefailureJSON/repr/add_note/laterhash-event-close-retry-replay/restore. Allknownfield/type/digest/ref/helpercompleted/closed/status facts DATA notsemanticimageauth-atomicABA-originalcredentials-ownership-EXrelease/admission.',
 '16views=8BEFOREv3+8AFTER/16BEFORE36AFTER parentCURRENT officialDarwinEXverifyNone plusSourcecallbacksNone UNITnotfullindependentactualEX-originalLinuxcredentials/allFD-interpreter-delegate-descendantclosure.8BEFORE8AFTER SAMEoriginalRootboundwait10 each7signed0+1signed3/cachedpossible. ROOTknownreader/log/journal devino cleanup AFTERviews/assertions UNITnotSourcecleanup-EXrelease. Some setup/internalFD/APIfactsnotallserialized/no globalabsence-fullreap/reconstruction.',
 'Initialprivatev1 8ERROR0FAIL: immutableio.BufferedWriter.close classpatch refused BEFORE8Source starts/finish units0. Separate5Bnativeinstance-close preflight Sourceunit0 provesinstancehook. Privatev2 8ERROR0FAIL: actual8publicstarts thenROOT wrongBufferedWriter.close descriptor onactualFileIO log BEFOREfinish units; SAME8knownRootwait natural7zero1three/no FDcleanup without evidence_ready. Privatev3 correctionretaineachactualobj.close BEFOREfirstcompletedfinish8; no completedfinishcontrolreplay/setupretryonly. Allsource/harness/raws retained; neverinventomittedreturns.',
 'Qwen37836status0/full3904stdout578stderr/fullanswer ROOTqualified/rejectsuggestedFalsewriterpositive/finallyclose/expectenclosingpreserve, intendedNEWcontract notoldbehavior. GLM38680tokenlimit1/0stdout1068stderr/fullpartialfinalABSENT/notreconstructed/reaped/reachableNOTunavailable-approval/no unchangedreviewrepeat. Reviewcandidatev1 BEFOREROOTv2privatefirstlatch+finally beforesecondarymetadata; bothUNEXECUTEDbeforeedit. ROOTwholefinalSource/tests/AST/results independentlyqualified NOTmodelwholecurrentapproval.',
 'Strongownerrecords/groups/primary-secondary/steps/originalrefs/closures/tracebackgrowthUNMEASURED/noheapRSSbound-leak-timing-cause-trim-reset-evict-deleteauthority. All20helpersuncommitteduncanonicalunadmitted/privateartifactsoutsideHELPERBUNDLE20/production601exact. No Sourcecommit-push-adoption/SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-RAMrepair-strictacceptance; providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.',
 'NamedcontrollerssavedBEFOREcalls. SomeinitialtoolAPIreturnsnotseparatelysaved; availablelateractualreturns retained/omissionsnotreconstructed. Initialheartbeatorientationreturn available0/output8157chars/firstcontextdisplaytruncated, narrowstoredoutputreadnotnewsourcecall. Storagefloors/recheck DATAnotbuild-capture-deletionauthority/causeoutsideoldcleanupUNMEASURED.'
 ]
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=8,failures=6,passes=2,errors=0,scope='1invalidwriterreturn integritygap+5enclosingunknownpublicationcontinuation/retentionpolicies NOT6nativebugs/RAMcause'),after=a,
 ROOT=dict(whole_final_Source_tests_AST_qualified=True,wholeSource_BYTE_projectsback=True,oldtests_BYTES_PREFIX_exact=True,other18helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=16,parent_BEFORE_EXverify_None=16,parent_AFTER_EXverify_None=36,known_same_originalbound_waits=waits,known_unit_cleanup=cleanup,allotherSource_Aux_Popen_constructors_factories_sharedstep_frozenpredicates_exact=True),
 models=dict(**models,ROOT_qualified_NOTwholecurrentapproval=True,GLMv1_beforeROOTv2_privatefirst=True),limits=limits,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(assessment,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['producer_finish_publication_progress'].update(ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],after_pending=False,model_pending=False,docs_pending=True);c['active_turn_status']='Producer_finish_publication_selected18PASS_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],selected18PASS=True,views=16,git4_0_BOTH_EOF=True,free_bytes=free,full_admission=False)))
