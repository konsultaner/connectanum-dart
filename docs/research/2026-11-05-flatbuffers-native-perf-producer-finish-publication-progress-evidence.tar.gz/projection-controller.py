import sys,pathlib,json,ast,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path("/tmp/connectanum-native-perf-producer-finish-publication-progress-v1");s=(p/'before-producer.py').read_text();c=(p/'candidate-v1.py').read_text();parts=json.loads((p/'projection-parts-v1.json').read_text());back=c.replace(parts['helper'],'',1).replace(parts['newwait'],parts['oldwait'],1).replace(parts['new_suffix'],parts['old_suffix'],1);assert back==s
 v=dict(wholeSource_BYTE_projectsback=True,candidate_UNEXECUTED=True,scope='ONLY_finish publication suffix and matching wait catchguard; newmoduleledgers/pureguard. Originaloutputselection/payload/resultliteral/allothermethods/Popenconstructors/factories/frozenpredicates exact.',source_sha256=hashlib.sha256(c.encode()).hexdigest());(p/'candidate-ROOT-projection.json').open('x').write(json.dumps(v,indent=2))
 views=[json.loads(f.read_text()) for f in sorted((p/'before-units-v3/fixtures').glob('*/view-before-ROOT-cleanup.json'))];assert len(views)==8;(p/'before-views-index.json').open('x').write(json.dumps(views,indent=2));print(json.dumps(v))
 t=(p/'before-tests.py').read_text()
 for n in ast.parse(t).body:
  if isinstance(n,ast.ClassDef) and n.name in ('ProducerTests','CommandProducerTests'):print(n.name,[x.name for x in n.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')])
 l.verify_identity()
