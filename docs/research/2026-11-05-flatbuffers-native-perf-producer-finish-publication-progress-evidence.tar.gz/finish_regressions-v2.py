"""NEW terminal producer publication controls; actual fixture calls, no Source recovery."""
import os
import sys
import json
import io
import hashlib
import subprocess
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class ProducerFinishPublicationTests(TestCase):
    def setUp(self):
        self.fixture_git_commands=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        q=self.base/'fixture-Git';q.mkdir(exist_ok=True);i=len(self.fixture_git_commands)
        argv=['git','-C',str(self.repo),*args]
        (q/(str(i)+'-before.json')).write_text(json.dumps(dict(argv=argv,Popen_attempted=True,pid=None)))
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
        out,err=child.communicate();status=child.wait()
        (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
        self.fixture_git_commands.append(dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True))
        self.assertTrue(type(status) is int and status==0)
        return out

    def start(self,*modes,**overrides):return ProducerTests.start(self,*modes,**overrides)


    def _finish_case(self,mode):
        calls=[];actors=[];seen={};leases=[];evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT terminal publication first')
        native_allocate=producer.CommandProducer._allocate_command_process
        native_preserve=producer.CommandProducer._preserve_failure
        native_write=producer._write_json;native_hash=producer._regular_hash
        native_event=producer.CommandProducer._event;native_close=io.BufferedWriter.close
        def verifying():
            raw=official_ex_verify();leases.append(dict(raw_None=raw is None));return raw
        def allocating(p,attempt,argv,writer):
            item=dict(owner=p,process=None,bound_wait=None);actors.append(item)
            raw=native_allocate(p,attempt,argv,writer);item['process']=raw;item['bound_wait']=raw.wait;return raw
        def preserving(p,error):
            calls.append(dict(kind='forbidden_preserver',input_first=error is first));return native_preserve(p,error)
        def writing(path,value):
            target=path.name=='result.json'
            if target:calls.append(dict(kind='result_write_attempt'))
            raw=native_write(path,value)
            if target:
                calls.append(dict(kind='result_write_actual_return',raw_None=raw is None))
                if mode=='write_unknown':raise first
                if mode=='write_False':return False
            return raw
        def hashing(path):
            target=path.name in ('result.json','journal.jsonl')
            kind='result_hash' if path.name=='result.json' else 'journal_hash'
            if target:calls.append(dict(kind=kind+'_attempt'))
            raw=native_hash(path)
            if target:
                calls.append(dict(kind=kind+'_actual_return',native_digest=raw))
                if mode==kind+'_unknown':raise first
            return raw
        def event(p,name,**fields):
            if name=='finished':calls.append(dict(kind='finished_event_attempt'))
            raw=native_event(p,name,**fields)
            if name=='finished':
                calls.append(dict(kind='finished_event_actual_return',raw_None=raw is None))
                if mode=='event_unknown':raise first
            return raw
        def closing(obj):
            target='journal' in seen and obj is seen['journal']['obj']
            if target:calls.append(dict(kind='journal_close_attempt'))
            raw=native_close(obj)
            if target:
                calls.append(dict(kind='journal_close_actual_return',raw_None=raw is None))
                if mode=='close_unknown':raise first
                if mode=='normal_failed':return False
            return raw
        p=None;received=None;guard_error=None;returned=False;result=None
        try:
            with mock.patch.object(producer.CommandProducer,'_allocate_command_process',allocating),mock.patch.object(producer.CommandProducer,'_preserve_failure',preserving),mock.patch.object(producer,'_write_json',writing),mock.patch.object(producer,'_regular_hash',hashing),mock.patch.object(producer.CommandProducer,'_event',event):
                code="import os;os.write(1,b'FINISH-worker-out');os.write(2,b'FINISH-worker-err')"
                if mode=='normal_failed':code+=";os._exit(3)"
                p=self.start(('ok',),commands=[[sys.executable,'-c',code]],lease_check=verifying)
                for role,obj in [('log',p.log),('journal',p.events)]:
                    raw=obj.raw if type(obj) is io.BufferedWriter else obj
                    fd=raw.fileno();info=os.fstat(fd)
                    seen[role]=dict(obj=obj,raw=raw,raw_close=raw.close,buffered_close=native_close.__get__(obj,type(obj)),fileno=raw.fileno,path=p.directory/('journal.jsonl' if role=='journal' else 'command-000.log'),identity=(info.st_dev,info.st_ino))
                fd=p.output_fd;info=os.fstat(fd);seen['reader']=dict(fd=fd,identity=(info.st_dev,info.st_ino))
                with mock.patch.object(seen['journal']['obj'],'close',lambda:closing(seen['journal']['obj'])):
                    try:result=p.wait(10);returned=True
                    except BaseException as error:received=error
                guard=getattr(producer,'_finish_publication_guard',None)
                if mode not in ('normal','normal_failed') and guard is not None:
                    try:guard(p)
                    except BaseException as error:guard_error=error
            records=[r for r in getattr(producer,'_FINISH_PUBLICATION_RECORDS',[]) if r.get('owner') is p]
            record=records[-1] if records else None;rows=[] if record is None else record['steps']
            view=dict(mode=mode,public_producer_returned=True,wait_returned=returned,result_status=None if result is None else result['status'],
                received_type=None if received is None else type(received).__name__,received_first=received is first,
                Source_pending=p.pending,Source_finished=p.finished,Source_returncode=p.records[-1]['returncode'],
                Source_evidence_complete=p.evidence_complete,Source_result_sha256=p.result_sha256,Source_journal_sha256=p.journal_sha256,
                Source_events_None=p.events is None,original_journal_closed=seen['journal']['obj'].closed,
                failure_exists=(p.directory/'failure.json').exists(),guard_present=guard is not None,
                pure_guard_same_received=received is not None and guard_error is received,record_present=record is not None,
                record_original_journal=False if record is None else record.get('events') is seen['journal']['obj'],
                record_original_result=False if record is None else record.get('result') is p.result,
                record_primary_received=False if record is None else record.get('primary_error') is received,
                record_completed=None if record is None else record.get('completed'),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,error_first=r.get('error') is first) for r in rows],
                calls=list(calls),leases=leases,
                limits='Actual publicfixture naturalcommand/logcompletion; Source unknown callee returns notfilled ROOTknownvalues. Knownfield/closed/status/helpercompleted DATA notownership/auth/ABA/physicalEX/admission. ROOTsameboundwait+devinoFDcleanup AFTERevidence UNITonly; no Source retry/replay/cleanup afterbodyfault.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n')
            (self.base/'journal-before-ROOT-cleanup.bin').write_bytes(seen['journal']['path'].read_bytes())
            evidence_ready=True
            self.assertTrue(all(x['raw_None'] for x in leases))
            if mode in ('normal','normal_failed'):
                self.assertTrue(returned);self.assertIsNotNone(result);self.assertIsNone(received)
                self.assertEqual('failed' if mode=='normal_failed' else 'success',result['status'])
                self.assertEqual(3 if mode=='normal_failed' else 0,result['commands'][0]['returncode'])
                self.assertEqual(b'FINISH-worker-outFINISH-worker-err',(p.directory/'command-000.log').read_bytes())
                self.assertEqual(hashlib.sha256((p.directory/'result.json').read_bytes()).hexdigest(),p.result_sha256)
                self.assertEqual(hashlib.sha256((p.directory/'journal.jsonl').read_bytes()).hexdigest(),p.journal_sha256)
                self.assertTrue(p.evidence_complete);self.assertTrue(seen['journal']['obj'].closed)
                if record is not None:self.assertTrue(record['completed'])
            else:
                self.assertFalse(returned)
                if mode=='write_False':self.assertTrue(type(received) is producer.ProducerError)
                else:self.assertTrue(received is first)
                self.assertFalse(any(c['kind'] in ('forbidden_preserver','repr_first','note_first') for c in calls))
                self.assertTrue(guard is not None);self.assertTrue(guard_error is received)
                self.assertTrue(record is not None);self.assertTrue(record['events'] is seen['journal']['obj'])
                self.assertTrue(record['result'] is p.result);self.assertTrue(record['primary_error'] is received);self.assertFalse(record['completed'])
                self.assertFalse(p.evidence_complete);self.assertFalse((p.directory/'failure.json').exists())
                stop={'write_unknown':'result_write','write_False':'result_write','result_hash_unknown':'result_hash','event_unknown':'finished_event','close_unknown':'journal_close','journal_hash_unknown':'journal_hash'}[mode]
                stages=['result_write','result_hash','finished_event','journal_close','journal_hash']
                self.assertEqual(stages[:stages.index(stop)+1],[r['stage'] for r in rows])
                last=rows[-1]
                if mode=='write_False':self.assertTrue(last['returned']);self.assertTrue(last['raw'] is False)
                else:self.assertFalse(last['returned']);self.assertIsNone(last['raw'])
                count=len(calls)
                try:guard(p)
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('finish pure guard returned')
                self.assertEqual(count,len(calls))
                if mode in ('write_unknown','write_False','result_hash_unknown','event_unknown'):
                    self.assertFalse(seen['journal']['obj'].closed);self.assertTrue(p.events is seen['journal']['obj'])
        finally:
            cleanup=[]
            for actor in actors:
                if actor['bound_wait'] is not None:
                    status=actor['bound_wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor['process'].pid,status=status,cached_possible=True));self.assertTrue(type(status) is int and status==(3 if mode=='normal_failed' else 0))
            if evidence_ready:
                reader=seen['reader'];row=dict(kind='ROOT_known_reader',fd=reader['fd'],closed=False)
                try:
                    info=os.fstat(reader['fd']);same=(info.st_dev,info.st_ino)==reader['identity'];row['identity_match']=same
                    if same:
                        data=b'';reads=[]
                        for _ in range(8):
                            try:part=os.read(reader['fd'],65536)
                            except BlockingIOError:reads.append(dict(raw_UNKNOWN=True));break
                            reads.append(dict(size=len(part)));data+=part
                            if not part:break
                        (self.base/'ROOT-reader-after-evidence.bin').write_bytes(data);row['reads']=reads
                        os.close(reader['fd']);row['closed']=True
                except OSError as error:row['error_errno']=error.errno
                cleanup.append(row)
                for role in ('log','journal'):
                    item=seen[role];raw=item['raw'];row=dict(kind='ROOT_known_'+role,raw_already_closed=raw.closed,raw_close=False)
                    if not raw.closed:
                        fd=item['fileno']();a=os.fstat(fd);b=item['path'].stat();same=(a.st_dev,a.st_ino)==item['identity']==(b.st_dev,b.st_ino);row['FD_path_original_identity_match']=same
                        if same:closed=item['raw_close']();row['raw_close']=True;row['raw_close_None']=closed is None
                    if raw.closed:
                        try:closed=item['buffered_close']();row['buffered_close_None']=closed is None
                        except BaseException as error:row['buffered_close_error_type']=type(error).__name__
                    row['raw_closed_after']=raw.closed;cleanup.append(row)
            else:cleanup.append(dict(no_close_without_evidence=True))
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')


    def test_actual_result_write_then_error_stops_enclosing_reporting(self):self._finish_case('write_unknown')
    def test_actual_result_write_then_False_refuses_before_hash(self):self._finish_case('write_False')
    def test_actual_result_hash_then_error_stops_before_event(self):self._finish_case('result_hash_unknown')
    def test_actual_finished_event_then_error_retains_original_journal(self):self._finish_case('event_unknown')
    def test_actual_journal_close_then_error_stops_before_hash(self):self._finish_case('close_unknown')
    def test_actual_journal_hash_then_error_stops_before_complete(self):self._finish_case('journal_hash_unknown')
    def test_new_normal_success_fullbytes_and_hashes(self):self._finish_case('normal')
    def test_new_normal_failed_exit3_ignored_closeFalse(self):self._finish_case('normal_failed')
