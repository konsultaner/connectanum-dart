import sys,pathlib,json,ast,hashlib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path("/tmp/connectanum-native-perf-producer-finish-publication-progress-v1");parts=json.loads((p/'projection-parts-v1.json').read_text());c=(p/'candidate-v1.py').read_text()
 old="""        private_guard=[None]
        def guard():
            if private_guard[0] is not None:private_guard[0]()
"""
 new="""        private_first=[None]
        def guard():
            if private_first[0] is not None:raise private_first[0]
"""
 oldrefuse="""        def refuse(error,row=None):
            group=_failure_preservation_group(self,error)
            private_guard[0]=group[1]
            record['primary_error']=group[3]
            group[2](error,row)
"""
 newrefuse="""        def refuse(error,row=None):
            private_first[0]=error
            try:
                group=_failure_preservation_group(self,error)
                private_first[0]=group[3]
                record['primary_error']=private_first[0]
                group[2](error,row)
            finally:raise private_first[0]
"""
 assert c.count(old)==c.count(oldrefuse)==1;c=c.replace(old,new,1).replace(oldrefuse,newrefuse,1);parts['suffix']=parts['suffix'].replace(old,new,1).replace(oldrefuse,newrefuse,1);parts['new_suffix']=parts['suffix'].rstrip('\n')[4:];ast.parse(c)
 back=c.replace(parts['helper'],'',1).replace(parts['newwait'],parts['oldwait'],1).replace(parts['new_suffix'],parts['old_suffix'],1);assert back==(p/'before-producer.py').read_text()
 (p/'candidate-v2.py').open('x').write(c);(p/'projection-parts-v2.json').open('x').write(json.dumps(parts,indent=2));(p/'candidate-ROOT-projection-v2.json').open('x').write(json.dumps(dict(wholeSource_BYTE_projectsback=True,candidate_UNEXECUTED=True,source_sha256=hashlib.sha256(c.encode()).hexdigest(),reason='ROOT private first latch before secondary group/record metadata and finally samefirst. Originalv1 guard only invoked groupguard after grouprefuse. No Source/test/model replay; v1review retained/finalv2ROOTqualified.'),indent=2))
 l.verify_identity();print(hashlib.sha256(c.encode()).hexdigest())
