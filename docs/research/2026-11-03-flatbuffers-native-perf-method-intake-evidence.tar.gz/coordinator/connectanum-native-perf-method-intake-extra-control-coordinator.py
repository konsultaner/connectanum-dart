root=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
stem=pathlib.Path('/private/tmp/connectanum-native-perf-method-intake')
def save(path,data):
 with pathlib.Path(path).open('xb') as f:f.write(data)
impl=root/'tool/native_perf_admission.py';assert hashlib.sha256(impl.read_bytes()).hexdigest()=='a554dc4039efff204a1a5c35c7a59eaee4312fc3626b8a4224c2d2f770bc68a7'
test=root/'tool/test_native_perf_admission.py';old=test.read_text();assert hashlib.sha256(old.encode()).hexdigest()=='a1153c7c1d8ff1a7884b7f94e655d234b6c81769475a7671d390549fe1dabd19'
qualification={'review_complete_reaped':True,'review_source':'/tmp/connectanum-native-perf-method-intake-review.json','root_qualifications':['No pre-open FD leak: no FD allocated when mkdir/validation refuses; directory FD closes after allocation with ownership popped. Hypothetical future reorder is not a current defect.','O_EXCL is not atomic publication, for either success or refusal. Partial/crashed artifacts and all existing namespaces are permanently terminal; no reader may recover/reset/overwrite/retry them. Rename/unlink not accepted.'],'design_and_test_advice':'Two earlier bounded requests reached token limit exit1 with no final assessment, not unavailable/approval; no unchanged review repeated.','source_unchanged_for_extra_unit':True,'old13_not_rerun':True}
save(str(stem)+'-review-root-qualification.json',(json.dumps(qualification,indent=2)+'\n').encode())
sentinel="if __name__=='__main__':unittest.main()";assert old.count(sentinel)==1
test.write_text(old.replace(sentinel,payload['extra_test']+'\n'+sentinel))
fixture=pathlib.Path(str(stem)+'-partial-fixtures');fixture.mkdir(mode=0o700)
source=pathlib.Path(str(stem)+'-final-source');source.mkdir(mode=0o700)
declared=json.loads(pathlib.Path('/private/tmp/connectanum-native-perf-linux-control-attempt-v3/declaration.json').read_bytes())['all20source_sha256']
data={};hashes={}
for name in declared:
 raw=(root/name).read_bytes();dest=source/name;dest.parent.mkdir(exist_ok=True);save(dest,raw);data[pathlib.Path(name).stem]=(name,raw);hashes[name]=hashlib.sha256(raw).hexdigest()
class Finder(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def find_spec(self,fullname,path=None,target=None):
  return importlib.machinery.ModuleSpec(fullname,self) if fullname in data else None
 def create_module(self,spec):return None
 def exec_module(self,module):
  name,raw=data[module.__name__];module.__file__=str(root/name);exec(compile(raw,module.__file__,'exec'),module.__dict__)
for key in ['CONNECTANUM_PERF_ADMISSION_FIXTURES','CONNECTANUM_PERF_CENSUS_FIXTURES','CONNECTANUM_PERF_INPUT_CENSUS_FIXTURES']:
 os.environ[key]=str(fixture)
for key in re.findall(r"os.environ\[['\"]([^'\"]+)['\"]\]",data['test_native_perf_input_census'][1].decode()):
 os.environ[key]=str(fixture)
finder=Finder();sys.meta_path.insert(0,finder)
try:
 import test_native_perf_admission as tests
 suite=unittest.TestSuite([tests.MethodReceiptIntakeTests('test_partial_observation_is_terminal_without_overwrite')])
 with pathlib.Path(str(stem)+'-partial-tests.log').open('x') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 receipt={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'source_sha256':hashes,'other13_unchanged_not_rerun':True,'fullcanonical':False}
 save(str(stem)+'-partial-tests.json',(json.dumps(receipt,indent=2)+'\n').encode())
 assert result.wasSuccessful(),'new partial-publication guard failed'
 print('NEW_SEPARATE_PARTIAL_GUARD_PASS',flush=True)
 import native_perf_admission as admission
 control=pathlib.Path('/private/tmp/connectanum-native-perf-method-intake-control');control.mkdir(mode=0o700)
 actual=pathlib.Path('/private/tmp/connectanum-native-perf-linux-control-attempt-v3')
 pins={'declaration.json':'c0590bdf10ba8bec25bb7633ebc47f61c27d1cb6efa801a4268e419c552932a7','bundle/manifest.json':'376d818c49787cd4bad2b18460731157b70b891bc422341893edcdf46e129342','summary.json':'a782cf?','guest-raw/context.json':'ef222f94c4b58b24b19e77d1105f951144fd2ae57af6bc008822cd7066646b74','guest-raw/summary.json':'f66203b0525fc64650f77be774377e71727ef5655de45b36d9b0fbc43926e55e'}
 pins['summary.json']='a7821cf47e6f8548586a577db689dcaf11cf3248674d5b9defd15e092cfa13a6'
 inputs={name:{'path':str(actual/name),'sha256':pins[name]} for name in admission.METHOD_RECEIPT_FILES}
 declaration={'kind':'new-historical-receipt-linkage-control','declared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':inputs,'receiver_tool_hashes_declared':hashes,'receiver_compiled_from_snapshot_bytes':True,'old_method_source_epoch':declared,'coordinator_sha256':hashlib.sha256(payload['core'].encode()).hexdigest(),'capture_ready':False,'source_admitted':False,'live_admission':False,'no_old_kernel_controls_or_commands_or_archive_tests_rerun':True,'scope':'five existing JSON receipt links ONLY; original raw command streams/source/executable evidence not revalidated','build_floor_unchanged_bytes':12*1024**3,'no_build':True}
 save(control/'declaration.json',(json.dumps(declaration,indent=2)+'\n').encode())
 value=admission.intake_method_receipts(inputs=inputs,output_dir=control/'observation',receiver_tool_hashes=hashes,owner_uid=os.geteuid())
 assert value['historical_tool_hashes']==declared
 assert value['receiver_tool_hashes_declared']==hashes
 assert value['historical_tool_hashes']['tool/native_perf_admission.py']!=value['receiver_tool_hashes_declared']['tool/native_perf_admission.py']
 assert all(value[k] is False for k in ('capture_ready','source_admitted','live_admission'))
 for name,digest in hashes.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
 summary={'completed':True,'scope':'historical five JSON receipt data continuity ONLY','reported_statuses':[r['status'] for r in value['reported_cases']],'capture_ready':False,'source_admitted':False,'live_admission':False,'no_primitive_or_Docker_or_original_workload_or_capture_or_numeric_execution':True,'current_source_unchanged_after_intake':True,'free_bytes':shutil.disk_usage(root).free,'new_result_sha256':hashlib.sha256((control/'observation/observation.json').read_bytes()).hexdigest()}
 save(control/'summary.json',(json.dumps(summary,indent=2)+'\n').encode());print(json.dumps(summary),flush=True)
finally:sys.meta_path.remove(finder)
