import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-start-lease-design-v2");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-start-lease-design-v1/before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 before=json.loads((P/'before/result.json').read_text());assert (before['tests'],before['failures'],before['errors'])==(6,3,0)
 review=json.loads((P/'review-v2/result.json').read_text());assert review['status']==0
 qualified=json.loads((P/'review-ROOT-assessment.json').read_text());assert qualified['ROOT_candidate_v2_qualified'] is True
 assert json.loads((P/'ROOT-before-assessment.json').read_text())['candidate_BYTEprojectsback'] is True
 source=(P/'candidate-producer-v2.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();new=(P/'new-tests.py').read_bytes();newtests=tests+b'\n'+new;ast.parse(source);ast.parse(newtests)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());v=c['native_perf_only_diagnostic_design']['auxiliary_start_lease_progress'];v.update(source_edit_attempted=True,source_UNCHANGED=False,source_new_epoch_UNTESTED=True,review_pending=False);cp.write_text(json.dumps(c,indent=2)+'\n')
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(newtests)
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==source and (R/'tool/test_native_perf_build_producer.py').read_bytes()==newtests and newtests.startswith(tests)
 after={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h}
 assert all(after[k]==v for k,v in h.items() if k not in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'])
 for name,value in [('after-producer.py',source),('after-existing-tests.py',newtests)]:
  with (P/name).open('xb') as f:f.write(value)
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(after,f,indent=2)
 v.update(source_sha256=after['tool/native_perf_build_producer.py'],test_sha256=after['tool/test_native_perf_build_producer.py'],source_edit_returned=True,original_tests_PREFIXexact=True,other18helpers3bins_unchanged=True)
 c['active_turn_status']='Aux_START_lease_source_edited_UNTESTED';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=after['tool/native_perf_build_producer.py'],test=after['tool/test_native_perf_build_producer.py'],UNTESTED=True,other18helpers3bins_unchanged=True)))
