import sys,pathlib,json,hashlib,ast,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-start-lease-design-v2");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();h=json.loads((P/'after-edit-hashes.json').read_text());actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert actual==h
 s=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();ast.parse(s);ast.parse(tests)
 assert s==(P/'candidate-producer-v2.py').read_text()
 oldtests=pathlib.Path('/tmp/connectanum-native-perf-aux-start-lease-design-v1/before-existing-tests.py').read_bytes();assert tests==oldtests+b'\n'+(P/'new-tests.py').read_bytes()
 assert json.loads((P/'ROOT-before-assessment.json').read_text())['candidate_BYTEprojectsback'] is True
 before=json.loads((P/'before/result.json').read_text());after=json.loads((P/'after-selected/result.json').read_text());assert (before['tests'],before['failures'],before['errors'])==(6,3,0);assert (after['tests'],after['failures'],after['errors'])==(22,0,0)
 commands=[['git','rev-parse','HEAD'],['git','branch','--show-current'],['git','status','--short','--untracked-files=all'],['git','diff','--name-only','HEAD','--','packages','native']]
 git=[]
 for index,argv in enumerate(commands):
  prefix=q/('git-'+str(index))
  with prefix.with_suffix('.before.json').open('x') as f:json.dump(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None),f)
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  with prefix.with_suffix('.start.json').open('x') as f:json.dump(dict(pid=child.pid),f)
  out,err=child.communicate();status=child.wait()
  for name,raw in [('stdout.bin',out),('stderr.bin',err)]:
   with pathlib.Path(str(prefix)+'.'+name).open('xb') as f:f.write(raw)
  result=dict(argv=argv,pid=child.pid,status=status,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),stdout_size=len(out),stderr_size=len(err),both_EOF=True)
  with prefix.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
  assert status==0 and err==b'';git.append((out,result))
 assert git[0][0].decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6';assert git[1][0].decode().strip()=='codex/flatbuffers-native-perf-guard'
 statuslines=git[2][0].decode().splitlines();assert len(statuslines)==20 and all(x.startswith('?? tool/') for x in statuslines);assert git[3][0]==b''
 reports=[];waitrows=[];verifyrows=[]
 for phase in ['before','after-selected']:
  for path in sorted((P/phase/'fixtures').glob('*/start-lease-before-cleanup.json')):
   r=json.loads(path.read_text());cleanup=json.loads(path.with_name('start-lease-unit-cleanup.json').read_text());reports.append(dict(phase=phase,path=str(path),mode=r['mode']))
   verifyrows+=r['calls'];waitrows+=[x for x in cleanup if x['kind']=='bound_same_finite_wait']
   if phase=='after-selected' and r['mode'] in ['buffer-drift','eof-drift','unknown-return']:
    assert r['after_fault_source_attempts']==[] and r['source_actor_returns']==0 and r['guard_raises_received_first'] and r['private_startup_first_is_received']
    assert r['row_original_callback'] and r['row_original_empty_buffer'] and r['row_original_eof_false'] and r['row_error_is_received']
    assert r['started'] is True and r['pending'] is False and r['finished'] is False and r['result_is_None'] is True and r['stdout_exists'] is False
    assert r['row_returned'] is (None if r['mode']=='unknown-return' else True)
 assert len(reports)==12 and len(waitrows)==6 and all(type(x['status']) is int and x['status']==0 for x in waitrows)
 assert len(verifyrows)==26 and all(x['actual_official_verify_returned'] and x['raw_is_None'] for x in verifyrows)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='START-site Auxiliary lease callback only; no INIT/fullphysicalEX/runtimeadmission/RAMrepair/acceptance',
 source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],NEWbefore6='3FAIL3PASS0APIerrors; bufferEOF advance18monitoredattempts each; unknownreturn existingfirst+strongercontextpolicy',
 AFTERselected22='6matchingNEW+16affected PASS/newepoch ONLY/notcombined/current20canonical/admission',
 whole_final_source_tests_AST_qualified=True,source_BYTEprojectsback=True,original_tests_PREFIXexact=True,other18helpers3bins_unchanged=True,original_othermethods_factories_gates_resultliteral_exact=True,
 source_git_new4_actual0_BOTHstreams=True,branch='codex/flatbuffers-native-perf-guard',HEAD='601108ea6216464bd00ae29c16cfaf0a59c71db6',exact20_untracked_uncommitted_uncanonical_unadmitted=True,tracked_packages_native_diffempty_DATA_only=True,
 new_unit_journals=12,new_ROOT_boundwait_rows=6,all_signed0_cached_possible=True,actual_A_facade_CURRENT_official_EX_verify_None_rows=26,not_all_setup_controller_verifier_calls=True,
 new_negative_source_actor_returns0_before_IOadvance=True,raw_return_knownNone_vs_unknown_distinct=True,no_negative_source_wait_or_secondstart=True,
 GLM76789='review0/reaped/stdout6778stderr1201/input30486/fullanswer/ROOTqualified NOTwholecurrentapproval',Qwen75805='planning0/reaped/stdout2237stderr478/fullanswer/ROOTqualified',
 review_v1_76735='argparse2/stdout0stderr1208 BEFOREbackend/model invocation; fresh v2 documented provider correction; no model-answer replay',
 source_reader_v1='StopIteration wrongclass AFTER23hashes/source-tests snapshots/declaration; originalnamespace terminal; artifact-only actualclass selection',
 passive_unknown_malformed='typed static ROOT qualified plus executed healthyhistory DATA caller NOTfullhistoricalcontinuation/runtimeclosure',
 rawlimits='Known unit parentFD-log cleanup afterreports/naturalSAMEwait only. No fullchildFD/interpreter-delegate-descendant/instructioncensus/auth/ABA/physicalEX. Legacysetup/actorFD/APIreturns/inlineartifact notall regularfiles/no reconstruction.',
 initial_controllers='Initial source reader/controller inline actualtoolinput BEFOREcall; originalnamespace terminal. Named model/edit/test/ROOT controllers savedBEFOREcalls; artifact inline methods not all APIreturns serialized.',
 free_bytes=free,storage_floor='OPEN' if free>=12884901888 else 'CLOSED',storage_cause_outside_old_lossless_cleanup_UNMEASURED_no_deletion_authority=True,
 provider_ABSENT=True,gate_alwaysraises=True,controller_CLOSED=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,
 no_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_adoption_cleanup_RAMrepair_strictacceptance=True,reports=reports,git=[x[1] for x in git])
 with (q/'assessment.json').open('x') as f:json.dump(result,f,indent=2)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(result,f,indent=2)
 with (P/'root-readback.json').open('x') as f:json.dump(dict(assessment=str(q/'assessment.json'),source=result['source_sha256'],test=result['test_sha256'],selected22PASS=True,scoped_only=True),f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];v=n['auxiliary_start_lease_progress'];v.update(ROOT_pending=False,ROOT_assessment=str(q/'assessment.json'),ROOT_qualified=True,source_component_only_COMPLETE=True,publication_pending=True,source_new_epoch_UNTESTED=False,never_repeat_unchanged=True)
 n['current_helper_source_epoch'].update(producer_sha256=result['source_sha256'],test_sha256=result['test_sha256'],hashes_file=str(P/'after-edit-hashes.json'),final_epoch_UNTESTED=False,verification_scope='5fc083/fe34de selected22PASS=6new16affected ROOTqualified NOTmodelwholecurrentapproval/current20canonical/admission',latest_postflight=str(q/'assessment.json'))
 c['active_turn_status']='Aux_START_lease5fc083_fe34de_selected22PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity()
 print(json.dumps({k:result[k] for k in ['source_sha256','test_sha256','NEWbefore6','AFTERselected22','new_unit_journals','new_ROOT_boundwait_rows','actual_A_facade_CURRENT_official_EX_verify_None_rows','free_bytes']}))
