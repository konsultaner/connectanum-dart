import sys,pathlib,json,hashlib,ast,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 P=pathlib.Path("/tmp/connectanum-native-perf-aux-start-lease-design-v1");P.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 old=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-wait-lease-progress-v1/after-edit-hashes.json').read_text())
 got={rel:hashlib.sha256((R/rel).read_bytes()).hexdigest() for rel in old};assert got==old
 declaration=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='Before the original START-site Auxiliary lease callback, are original callback/actor/stream handles and intent retained, and does callback context mutation stop before any startup pipe/log/Popen operation?',scope='NEW START-site callback design and predeclared regression, then minimal behavior-preserving repair only if reproduced; INIT remains separate',source_sha256=got['tool/native_perf_build_producer.py'],test_sha256=got['tool/test_native_perf_build_producer.py'],no_tests_models_builds_native_capture_source_edits_this_read=True,original_ignored_return_contract_and_existing_gates_preserved=True,permanent_unknown_refusal_not_physicalEX_or_admission=True,controller_saved_BEFOREcall=False,inline_initial_source_reader_DECLARED_in_actual_toolinput_BEFOREcall=True)
 with (P/'declaration.json').open('x') as f:json.dump(declaration,f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 for name,value in [('before-producer.py',source),('before-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(value)
 with (P/'before-hashes.json').open('x') as f:json.dump(got,f,indent=2)
 tree=ast.parse(source);aux=next(n for n in ast.walk(tree) if isinstance(n,ast.ClassDef) and n.name=='_AuxiliaryCommand')
 selected={}
 for node in aux.body:
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in ['__init__','start','_start','_constructor_guard','_startup_guard','_check_wait_lease']:
   selected[node.name]=ast.get_source_segment(source,node)
 with (P/'selected-source.json').open('x') as f:json.dump(selected,f,indent=2)
 print(json.dumps(dict(Auxiliary_methods=[n.name for n in aux.body if isinstance(n,ast.FunctionDef)],selected=selected),indent=2))
 lease.verify_identity()
