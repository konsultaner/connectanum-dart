class AuxiliaryStartLeaseProgressTests(unittest.TestCase):
    """NEW START-site callback context; delegates current actual official EX verify."""
    def _start_lease_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-start-lease-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        verify=official_ex_verify;actors=[];logs={};pipes=[];closes=[];cleanup=[];calls=[];foreign_calls=[];operations=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_read_json=producer._read_json;native_write_json=producer._write_json
        real_allocate=producer.AuxiliaryCommand._allocate_process;a=None;fault=False;raised=None;guard_error=None
        first=OSError(5,'OWN official verify return hidden by ROOT START callback fault');payload=b'OWN-start-lease-output'
        def rows():
            value=getattr(a,'_start_lease_journal',None) if a is not None else None
            return value if type(value) is list else []
        def observe(kind):
            if fault:operations.append(dict(kind=kind,attempted=True))
        def opening(path,*args,**kwargs):
            observe('Path.open')
            value=native_open(path,*args,**kwargs)
            if path in (base/'start-source.stdout',base/'start-source.stderr'):logs[str(path)]=value
            return value
        def piping():
            observe('os.pipe');value=native_pipe();entry=dict(fds=value,identity_rows=[]);pipes.append(entry)
            for fd in value:
                st=os.fstat(fd);entry['identity_rows'].append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return value
        def closing(fd):
            observe('os.close');row=dict(fd=fd,attempted=True,returned=None);closes.append(row)
            st=os.fstat(fd);row.update(dev=st.st_dev,ino=st.st_ino)
            value=native_close(fd);row.update(returned=True,raw_None=value is None);return value
        def reading_json(*args,**kwargs):observe('_read_json');return native_read_json(*args,**kwargs)
        def writing_json(*args,**kwargs):observe('_write_json');return native_write_json(*args,**kwargs)
        def allocate(current,record):
            observe('_allocate_process')
            value=real_allocate(current,record);actors.append(dict(process=value,bound_wait=value.wait,name=current.name));return value
        def foreign_callback():foreign_calls.append(True);return None
        def callback():
            nonlocal fault
            ordinal=len(calls)+1;row=rows()[-1] if rows() else {}
            intent=(ordinal!=2 or (row.get('callback') is callback and row.get('callback_attempted') is True and row.get('returned') is None))
            value=verify()
            calls.append(dict(ordinal=ordinal,actual_official_verify_returned=True,raw_is_None=value is None,start_intent_before_delegate=intent))
            if ordinal==2:
                if mode in ('buffer-drift','eof-drift','unknown-return'):
                    fault=True
                    if mode=='buffer-drift':a.streams['stdout']['buffer']=b'ROOT-START-buffer'
                    if mode=='eof-drift':a.streams['stdout']['eof']=True
                    if mode=='unknown-return':raise first
                if mode=='false':return False
            return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer,'_read_json',reading_json),mock.patch.object(producer,'_write_json',writing_json),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                a=producer.AuxiliaryCommand(directory=base,name='start-source',argv=[sys.executable,'-c',"import os;os.write(1,"+repr(payload)+")"],
                    cwd=base,environment=dict(os.environ),lease_check=callback)
                if mode=='pre-alias':a.lease_check=foreign_callback;fault=True
                try:
                    a.start()
                    if mode in ('none','false'):a.wait(timeout=10)
                except BaseException as error:raised=error
                if mode in ('buffer-drift','eof-drift','unknown-return'):
                    # Pure guard only, no second start/wait/callback after fault.
                    try:a._constructor_guard()
                    except BaseException as error:guard_error=error
            finally:
                for patch in reversed(patches):patch.stop()
            row=rows()[0] if rows() else {};snap=row.get('streams_before');original_buffer=None;original_eof=None
            if type(snap) is tuple and len(snap)==2 and type(snap[0]) is tuple and len(snap[0])>=8:
                original_buffer=snap[0][6];original_eof=snap[0][7]
            path=base/'start-source.stdout';data=path.read_bytes() if path.exists() else None
            report=dict(mode=mode,calls=calls,foreign_callback_calls=len(foreign_calls),after_fault_source_attempts=operations,
                actual_CURRENT_official_Darwin_EX_ONLY_not_originalLinux_credentials_allactor_FD_interpreter_delegate_EX_or_admission=True,
                raised_is_injected=raised is first,raised_is_ProducerError=type(raised) is producer.ProducerError,
                guard_raises_received_first=raised is not None and guard_error is raised,
                private_startup_first_is_received=raised is not None and a._startup_primary_error is raised,
                callback_original=a._constructor_quarantine_binding[5] is callback,
                source_actor_returns=len(actors),started=a.started,pending=a.pending,finished=a.finished,result_is_None=a.result is None,
                stdout_exists=data is not None,stdout_hex=None if data is None else data.hex(),
                source_buffer_hex=a.streams['stdout']['buffer'].hex(),source_eof=a.streams['stdout']['eof'],
                row_present=bool(row),row_original_callback=row.get('callback') is callback,row_callback_attempted=row.get('callback_attempted'),
                row_returned=row.get('returned'),row_raw_is_None=row.get('raw_return') is None,row_raw_is_False=row.get('raw_return') is False,
                row_completed=row.get('completed'),row_error_is_received=raised is not None and row.get('error') is raised,
                row_original_empty_buffer=original_buffer is not None and type(original_buffer) is bytes and original_buffer==b'',
                row_original_eof_false=original_eof is False,known_ROOT_parent_pipes=pipes,known_ROOT_native_close_returns=closes)
            with (base/'start-lease-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            self.assertTrue(report['callback_original']);self.assertTrue(all(x['actual_official_verify_returned'] and x['raw_is_None'] for x in calls))
            self.assertEqual(0,len(foreign_calls))
            if mode=='pre-alias':
                self.assertIs(type(raised),producer.ProducerError);self.assertEqual(1,len(calls));self.assertEqual([],operations)
                self.assertFalse(a.started);self.assertFalse(a.pending);self.assertEqual([],actors)
            elif mode in ('none','false'):
                self.assertIsNone(raised);self.assertEqual(3,len(calls));self.assertTrue(a.finished);self.assertFalse(a.pending)
                self.assertEqual(1,len(actors));self.assertIsNotNone(a.result);self.assertEqual(payload,data);self.assertEqual(0,a.status)
            else:
                self.assertEqual(2,len(calls));self.assertEqual([],operations);self.assertEqual([],actors)
                if mode=='unknown-return':self.assertIs(first,raised)
                else:self.assertIs(type(raised),producer.ProducerError)
                self.assertIs(raised,guard_error);self.assertTrue(report['private_startup_first_is_received'])
                self.assertTrue(report['row_original_callback']);self.assertTrue(report['row_original_empty_buffer']);self.assertTrue(report['row_original_eof_false'])
                self.assertTrue(report['row_error_is_received']);self.assertTrue(calls[1]['start_intent_before_delegate'])
                self.assertTrue(a.started);self.assertFalse(a.pending);self.assertFalse(a.finished);self.assertIsNone(a.result);self.assertIsNone(data)
                self.assertIsNot(report['row_completed'],True)
                if mode=='unknown-return':self.assertIsNone(report['row_returned'])
                else:self.assertIs(report['row_returned'],True);self.assertTrue(report['row_raw_is_None'])
        finally:
            for actor in actors:
                value=actor['bound_wait'](10);cleanup.append(dict(kind='bound_same_finite_wait',name=actor['name'],pid=actor['process'].pid,status=value,expected=0,cached_possible=True))
                self.assertIs(type(value),int);self.assertEqual(0,value)
            identities={(x['fd'],x.get('dev'),x.get('ino')) for x in closes if x.get('returned') is True and x.get('raw_None') is True};seen=set()
            for item in pipes:
                for identity in item['identity_rows']:
                    key=(identity['fd'],identity['dev'],identity['ino'])
                    if key in seen or key in identities:continue
                    seen.add(key);fd=identity['fd']
                    try:st=os.fstat(fd)
                    except OSError as error:cleanup.append(dict(kind='ROOT_known_FD_stat_error_NOTclosureproof',fd=fd,errno=error.errno));continue
                    if (st.st_dev,st.st_ino)!=(identity['dev'],identity['ino']):
                        cleanup.append(dict(kind='ROOT_known_FD_identity_changed_NOclose_NOTclosureproof',fd=fd));continue
                    value=native_close(fd);cleanup.append(dict(kind='ROOT_known_parent_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
            for name,log in logs.items():
                if not log.closed:
                    fd=log.fileno();st=os.fstat(fd);pt=Path(name).stat();self.assertEqual((st.st_dev,st.st_ino),(pt.st_dev,pt.st_ino))
                    log.close();cleanup.append(dict(kind='ROOT_known_rawlog_close',name=name,fd=fd,returned=True))
            with (base/'start-lease-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_actual_START_verify_then_buffer_drift_stops_before_startup_IO(self):self._start_lease_case('buffer-drift')
    def test_actual_START_verify_then_EOF_drift_stops_before_startup_IO(self):self._start_lease_case('eof-drift')
    def test_actual_START_verify_then_fault_retains_original_callback_context(self):self._start_lease_case('unknown-return')
    def test_existing_START_pre_alias_refusal_has_zero_foreign_calls(self):self._start_lease_case('pre-alias')
    def test_normal_START_actual_verify_None_preserves_output(self):self._start_lease_case('none')
    def test_START_ignored_False_return_preserves_original_contract(self):self._start_lease_case('false')
