import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)


import os,stat,re,collections,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');A=B/'2026-11-07-actions-include-grandchild-regular-inputs-v1/Actions-v1';P=B/'2026-11-07-actions-include-grandchild-regular-interiors-v1';O=A/'ROOT-NEW-ALL1229-regular-grandchild-input-assessment-PRIVATE.json'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST bounded STATIC PHYSICAL-byte interpretation ALL1229NEWsaved regular grandchild BODYstreams/originalActions42369382026/sourceadcb77059cf1f81f61ecf039eca245617a02d752. FIRSTexactoriginalsavedresult[0,14412328)/SHA1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331 ONLYlocates originalsavedmembers. EACH1229exactOWNsavedpath/range[0,originalsize)/SHA declaredBEFOREANYbodyIO. Fulloriginaldata/nativeorder/duplicates/byteoffsets preserved; literalphysicalLFsegments andfirstSPACE-TAB-skipped # candidates only, ASCIIidentifier keyword bytes immediatelyafter# plusliteralSP-TAB. include/include_next rawoperand candidatemetadata only; firstliteralclosing angle-or-doublequote delimiter withoutescape/comment/splice/macro/condition/Ctokenization evaluation. Rawallphysicalcandidate rowhex PRIVATE; rawoperand/namebytes/offsets/4previous-current backslashLF-CRLFflags/effective_include_requestNULL/alias_identityNULL retained. No effective-directive/dependency/include-resolution/compiler-sysroot-CargoCFGflavor-ABI/access-ownership inference or pathsplit-normalize-join-resolve-follow-recursion. Original1425metadata-fullstat-times/63queryepochs/1229lexical-bodyepoch/190DEFERRED/6unfollowed/prior1280-49-1199-old63DEFERRED-18earlierlinks-oldtopncursesrawhexNOTsavedNULL/allledgers unchanged. No originalacquisition-journal/streamcomparison/SDKquery-imagehash/old160-or1199bodyreader-parser/model/Actions/acquisition/archive/numerical replay/candidateexecution/import-headercompile/bootstrap/dependency/build/driver/perf/Source20-runtime adoption. Newbounded regularO_NOFOLLOW/sameFD/countSHA/stat/close pointbindings notatomicABA-origin/pathchain/globalactorFD/continuousphysicalEX-crash admission. No readsoutside declaredranges/no fileEOFprobe, closeunknown permanentlyquarantined/missingfieldsNULL.',
 'exact_saved_locator':{'path':str(O),'range':[0,14412328],'sha256':'1d3e77460634a410ef7927c8f63666b06bf5fa07153a4879957aa448b28fc331'},'all_admission_flags':False,'ownership':None}
 save('declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[1]);bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and h.hexdigest()==expected;raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw
 locatorraw=read_bounded(O,14412328,declaration['exact_saved_locator']['sha256'],'original_saved_result_ONLYmemberlocators');locator=json.loads(locatorraw);save('original-saved-result-bound-PRIVATE.json',locatorraw);members=locator['ALL1229_new_stream_bindings'];assert len(members)==1229 and locator['source_commit']=='adcb77059cf1f81f61ecf039eca245617a02d752' and locator['run_id']==42369382026 and locator['absent_at_open_only']==[]
 plan=[]
 for ordinal,row in enumerate(members):
  name=pathlib.PurePosixPath(row['saved_member']);assert not name.is_absolute() and '..' not in name.parts
  plan.append({'original_member_position_ZERO_based':ordinal,'original_source_reference_METADATA_ONLY':row['source_reference'],'exact_saved_member':row['saved_member'],'exact_OWN_saved_path':str(A/'artifact-members'/row['saved_member']),'range':[0,row['bytes']],'bytes':row['bytes'],'sha256':row['sha256']})
 assert len(plan)==1229 and sum(r['bytes'] for r in plan)==12344049;save('ALL1229-exact-saved-sources-ranges-BEFORE-BODY-IO.json',json.dumps(plan,ensure_ascii=True,indent=2))
 files=[];candidates=[];operands=[];keywords=collections.Counter();delimiters=collections.Counter();totallf=0;totalsegments=0;backslashlf=0;backslashcrlf=0;utf8count=0;nulbytes=0
 ascii_start=b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_';ascii_rest=ascii_start+b'0123456789'
 for original in plan:
  raw=read_bounded(pathlib.Path(original['exact_OWN_saved_path']),original['bytes'],original['sha256'],'FIRST_new_saved_BODY_physical_interpretation');blf=raw.count(b'\\\n');bcrlf=raw.count(b'\\\r\n');nuls=raw.count(b'\x00');utf8_error=None
  try:raw.decode('utf-8');utf8=True
  except UnicodeDecodeError as error:utf8=False;utf8_error={'start':error.start,'end':error.end,'reason':error.reason}
  pieces=raw.split(b'\n');lines=[p+b'\n' for p in pieces[:-1]]
  if pieces[-1]:lines.append(pieces[-1])
  assert b''.join(lines)==raw
  start=0;previous=b'';file_candidates=[];file_operands=[];fk=collections.Counter()
  for lineordinal,line in enumerate(lines,1):
   content=line[:-1] if line.endswith(b'\n') else line;i=0
   while i<len(content) and content[i] in b' \t':i+=1
   if i<len(content) and content[i]==35:
    afterhash=i+1
    while afterhash<len(content) and content[afterhash] in b' \t':afterhash+=1
    end=afterhash
    if end<len(content) and content[end] in ascii_start:
     end+=1
     while end<len(content) and content[end] in ascii_rest:end+=1
    keyword=content[afterhash:end];label=keyword.decode('ascii') if keyword else '<empty-or-nonidentifier>';keywords[label]+=1;fk[label]+=1
    flags={'previous_physical_row_ends_literal_backslash_LF':previous.endswith(b'\\\n'),'previous_physical_row_ends_literal_backslash_CRLF':previous.endswith(b'\\\r\n'),'current_physical_row_ends_literal_backslash_LF':line.endswith(b'\\\n'),'current_physical_row_ends_literal_backslash_CRLF':line.endswith(b'\\\r\n')}
    candidate={'global_physical_candidate_position_ONE_based':len(candidates)+1,'original_member_position_ZERO_based':original['original_member_position_ZERO_based'],'original_source_reference_METADATA_ONLY':original['original_source_reference_METADATA_ONLY'],'exact_saved_member':original['exact_saved_member'],'physical_row_position_ONE_based':lineordinal,'physical_row_start_offset':start,'physical_row_bytes':len(line),'hash_byte_offset':start+i,'literal_keyword_bytes_hex':keyword.hex(),'literal_keyword':keyword.decode('ascii') if keyword else None,'post_keyword_physical_remainder_bytes_hex':content[end:].hex(),'full_original_physical_row_bytes_hex_PRIVATE':line.hex(),**flags,'effective_directive':None,'C_preprocessing_semantics_UNEVALUATED':True}
    candidates.append(candidate);file_candidates.append(candidate['global_physical_candidate_position_ONE_based'])
    if keyword in [b'include',b'include_next']:
     operandstart=end
     while operandstart<len(content) and content[operandstart] in b' \t':operandstart+=1
     operand=content[operandstart:];kind='macro_empty_or_other';rawname=None;nameoffset=None;closedoffset=None
     if operand[:1] in [b'<',b'"']:
      closing=b'>' if operand[:1]==b'<' else b'"';at=operand.find(closing,1)
      if at>=1:kind='raw_angle_delimited' if closing==b'>' else 'raw_double_quote_delimited';rawname=operand[1:at];nameoffset=start+operandstart+1;closedoffset=start+operandstart+at
      else:kind='unterminated_angle_candidate' if closing==b'>' else 'unterminated_double_quote_candidate'
     delimiters[kind]+=1
     op={'global_include_operand_position_ONE_based':len(operands)+1,**candidate,'raw_operand_bytes_hex':operand.hex(),'raw_operand_absolute_offset':start+operandstart,'raw_delimiter_classification':kind,'raw_name_bytes_hex':None if rawname is None else rawname.hex(),'raw_name_literal_surrogateescape':None if rawname is None else rawname.decode('utf-8',errors='surrogateescape'),'raw_name_absolute_offset':nameoffset,'raw_first_closing_delimiter_absolute_offset':closedoffset,'effective_include_request':None,'alias_identity':None,'comments_splicing_macros_conditions_Ctokenization_UNEVALUATED':True}
     operands.append(op);file_operands.append(op['global_include_operand_position_ONE_based'])
   start+=len(line);previous=line
  assert start==len(raw);lf=raw.count(b'\n');totallf+=lf;totalsegments+=len(lines);backslashlf+=blf;backslashcrlf+=bcrlf;utf8count+=utf8;nulbytes+=nuls
  files.append({'original_member_locator':original,'new_saved_read_binding_index_ZERO_based':len(bindings)-1,'bytes_physically_read':len(raw),'literal_LF_count':lf,'physical_LF_segments_including_unterminated_tail_count':len(lines),'unterminated_nonempty_tail':bool(pieces[-1]),'literal_backslash_LF_count':blf,'literal_backslash_CRLF_count':bcrlf,'UTF8_decodable':utf8,'UTF8_decode_error_PRIVATE':utf8_error,'NUL_byte_count':nuls,'ALL_first_SPACE_TAB_skipped_hash_candidate_positions':file_candidates,'ALL_literal_keyword_counts':dict(fk),'ALL_include_operand_candidate_positions':file_operands})
  lease.verify_identity()
 summary={'source_run_id':42369382026,'source_revision':'adcb77059cf1f81f61ecf039eca245617a02d752','ALL1229_saved_body_files_read':len(files),'total_new_body_bytes':sum(r['bytes_physically_read'] for r in files),'total_literal_LF_count':totallf,'total_physical_LF_segments_including_unterminated_tails':totalsegments,'ALL_first_SPACE_TAB_skipped_hash_candidates':len(candidates),'ALL_literal_keyword_counts':dict(keywords),'literal_include_operand_candidates':len(operands),'literal_raw_delimited_operand_candidates':sum(delimiters[k] for k in ['raw_angle_delimited','raw_double_quote_delimited']),'literal_macro_empty_other_or_unterminated_operand_candidates':sum(n for k,n in delimiters.items() if k not in ['raw_angle_delimited','raw_double_quote_delimited']),'ALL_raw_delimiter_classification_counts':dict(delimiters),'literal_backslash_LF_count':backslashlf,'literal_backslash_CRLF_count':backslashcrlf,'UTF8_decodable_file_count':utf8count,'UTF8_undecodable_file_count':1229-utf8count,'NUL_byte_count':nulbytes,'new_saved_read_binding_count':len(bindings),'binding_count_qualification':'1 originalsavedmetadata locator plus1229newbodyrange reads; NOTplan-only/notoldacquisition-journal orstreamcomparison replay','effective_C_preprocessing_semantics':'UNEVALUATED','new_SDK_queries':0,'new_Actions_queries':0,'new_recursive_queries':0,'candidate_executions':0,'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':declaration['scope']}
 assert len(files)==1229 and summary['total_new_body_bytes']==12344049 and len(bindings)==1230
 result={'summary':summary,'ALL1229_file_physical_summaries':files,'ALL_physical_hash_candidates_PRIVATE_original_rowhex':candidates,'ALL_new_include_operand_candidates_PRIVATE_original_rowhex':operands,'ALL1230_saved_read_bindings_PRIVATE_fullstat-times':bindings,'ALL1229_exact_saved_member_read_declarations':plan,'original1229_Actions_saved_result_ALL_fields_PRIVATE_preserved':locator}
 rawresult=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL1229-grandchild-physical-interpretation-PRIVATE.json',rawresult);descriptor={'result_saved':'ROOT-FIRST-ALL1229-grandchild-physical-interpretation-PRIVATE.json','result_bytes':len(rawresult),'result_sha256':hashlib.sha256(rawresult).hexdigest(),'summary':summary};save('FIRST-original-result-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2)+'\n')
 cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-physical-result.json',before);d=json.loads(before);d['actions_include_grandchild_regular_interiors_v1']={'directory':str(P),'phase':'COMPLETE_CONSUMED_FIRST_ALL1229_new_saved_BODY_physical_interpretation_NOT_effective_directives_or_admitted','original_saved_result':str(P/descriptor['result_saved']),'original_saved_result_bytes':len(rawresult),'original_saved_result_sha256':descriptor['result_sha256'],'summary':summary,'model_summary_pending':True,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_grandchild_regular_interiors='COMPLETE_CONSUMED_summary_publication_pending',next='FIRST ALL1229saved-body physicalcandidate/operand interpretation completeCONSUMED; semanticscomments-splicing-macros-conditions-Ctokenization UNEVALUATED/effectiveinclude-aliasNULL. Summary thenFIRSTpublication explicitmetadata selection/fullrawPRIVATE. No oldbody-reader-parser-model-SDKquery-Actions-acquisition-archive/numerical replay or Source20-runtime adoption/build.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor,ensure_ascii=True),flush=True);lease.verify_identity()
