import sys,pathlib,json,ast,hashlib,subprocess,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-regular-hash-early-seams-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());before=json.loads((P/'before-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==(P/'before-producer.py').read_bytes()
 tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();extra=(P/'regular_hash_early_regressions-v1.py').read_bytes();assert tests==(P/'before-tests.py').read_bytes()+b'\n\n'+extra
 tree=ast.parse(tests);private=ast.parse(extra);cls=next(n for n in private.body if isinstance(n,ast.ClassDef) and n.name=='RegularHashEarlySeamTests')
 assert sum(isinstance(n,ast.ClassDef) and n.name==cls.name for n in tree.body)==1
 assert ast.dump(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls.name),include_attributes=False)==ast.dump(cls,include_attributes=False)
 assert [k for k in h if h[k]!=before[k]]==['tool/test_native_perf_build_producer.py']
 result=json.loads((P/'new-units/result.json').read_text());assert(result['tests'],result['passes'],result['failures'],result['errors'])==(9,9,0,0)
 assert len(result['leases'])==18 and all(x['raw_None'] for x in result['leases'])
 found={}
 for f in sorted((P/'new-units/fixtures').glob('*/view-before-ROOT-cleanup.json')):
  v=json.loads(f.read_text());found[v['mode']]=(v,f.parent)
 assert len(found)==9;cleanup=[]
 for mode,(v,base) in found.items():
  assert v['Source_attempt_present'] and v['Source_original_path_retained'] and v['Source_render_before_asserts']==[]
  rows=v['source_rows']
  if mode=='normal2chunks':
   assert v['Source_completed'] and not v['Source_digest_None'] and v['result_is_expected_digest'] and v['input_size']==1048593
   assert [x['raw_size'] for x in v['events'] if x['stage']=='read']==[1048576,17,0]
   assert sum(x['stage']=='close' for x in v['events'])==1
  else:
   assert not v['Source_completed'] and v['Source_digest_None'] and v['Source_first_received'] and v['pure_guard_first_is_received'] and v['pure_guard_no_monitored_IO']
   assert not any(x['stage']=='close' for x in v['events'])
   if mode=='hexdigest_upper':assert rows[-1]['returned'] and rows[-1]['raw_text_uppercase'] and rows[-1]['stage']=='hexdigest'
   else:assert rows[-1]['returned'] is False and rows[-1]['raw_kind']=='None'
   if mode in ('getuid_fault','path_fspath','stat_before_fault'):assert v['Source_fd'] is None and v['ROOT_fd'] is None
   else:assert v['Source_fd_is_ROOT_original']
  cl=json.loads((base/'ROOT-known-FD-cleanup.json').read_text());cleanup.append(dict(mode=mode,**cl))
 assert sum(x['attempted'] for x in cleanup)==5 and all(x['identity_match'] is True and x['returned'] is None for x in cleanup if x['attempted'])
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''

 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],scope='ONLY9 selected previouslyunexecuted regularhash earlyAPI controls on unchanged producer; test-onlyappend afterprivateONCE execution, notSourcefix/productiondefect/current20canonical/admission',selected_new_result=result,
 ROOT=dict(whole_final_source_tests_AST_qualified=True,producer_BYTES_unchanged=True,oldtests_BYTES_PREFIX_exact=True,appended_class_AST_exact_to_executed_private_v1=True,other19_helpers3bins_unchanged=True,hashes23=h,git_commands=git,new_unit_views=9,known_ROOT_FD_closes=cleanup,current_parent_EX_verify_None=18,Source_unknown_vs_ROOT_known_raw_separate=True,no_Source_worker_child_launch_in9units=True,no_globalactorabsence_or_fullreapclaim=True),
 models=dict(planning=json.loads((P/'test-planning/result.json').read_text()),review=json.loads((P/'test-review/result.json').read_text()),advisory_ROOTqualified_NOTwholecurrentapproval=True),
 limits=['NEW9=8negative1newactual2chunknormal on originalSource. No BEFOREfailingregression/Sourcefix; finaltestartifact append-only ASTequivalent to privateclass executedbeforeappend; no replay/unchangedcallersuite/old8controls/numerical aggregate.',
 'First3negatives stopbeforeSourceopen. SourceknownFD/unknownhashconstructor-update-digest raw distinctfrom ROOTknownactualh/None/string; no adoption. ActualPath.__fspath__ error and nativepostreturn faults are controlled unitseams, not spontaneouskernelbugs.',
 'Hashfacade delegates actualnativehash onlyin controlled update/digestcases; newnormal actualnativehash reads1048576+17+0 bytes and closes normally. Unitfixturebody is not benchmark freshbody data or acceptance.',
 '5known original nativeFD ROOTcloses AFTERraws-assertions+devino check UNITonly/notSourcefinallyclose-livecleanup-EXrelease-durability-ABA-auth. NormalSourceclose/EOF/hash are DATA.',
 '18current parent officialDarwinEXverifyNone facts notindependentfullactualEX-originalLinuxcredentials. UnitSourceworkerchild0; namedmodels/Git separatelyretained/notglobalabsence/fullreap. Setup/internalFD/interpreter-delegate-descendant APIreturns notallserialized/no reconstruction.',
 'Privatev1 UNEXECUTED until modelreview/ROOTinspection; actualinputs UID/owners/mode/flags unmodified/no credential-host-cap grants/chown/SDKchange. No Sourcehash retry/replay/reset/eviction.',
 'Other path/resolve/is_absolute/owner-mode-identity/bounds/return variants and metadata/artifactwritefailure negatives SOURCEonly/unexecuted; notallAPIclosure.',
 'Retainedarrays/raw/closure/traceback growth UNMEASURED/no heapRSSbound-leak-timing-cause/reset-evict-delete authority.',
 'All20helpers uncommitteduncanonicalunadmitted/privatecontrollers outsideHELPERBUNDLE20/production601exact; no actualSDK-build-current20canonical-kernel-broker-benchmark-capture-adoption-RAMrepair-strictacceptance. Providerabsent/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse.'],
 remaining=['other writer-hash-initializer API-negative seams','actualFileIO backingwriter/internalFD errors','enclosingproducer cleanup/reporting and factory suffix progress','independent frozenhistorical continuation/logsealing','transitiveunknownactors/sharedjournalwriters/interpreterdelegates','fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission'],
 storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_old_cleanup='UNMEASURED'))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['regular_hash_early_seams_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],docs_pending=True);c['active_turn_status']='Regularhash_early_NEW9PASS_Sourceunchanged_testsonly_ROOTqualified_DOCSpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],new9PASS=True,producer_UNCHANGED=True,git4_0_BOTH_EOF=True,Rootknowncloses5=True,free_bytes=free,full_admission=False)))
