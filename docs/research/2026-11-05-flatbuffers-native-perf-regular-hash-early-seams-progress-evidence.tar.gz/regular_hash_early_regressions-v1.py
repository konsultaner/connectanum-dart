"""NEW regular hash early API coverage; no registry reset or Source replay."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock
import native_perf_build_producer as producer


class RegularHashEarlySeamTests(unittest.TestCase):
    def _hash_early_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='hash-early-'+mode+'-',dir=os.environ.get('CONNECTANUM_HASH_EARLY_FIXTURES',tempfile.gettempdir()))).resolve()
        path=base/'input.bin'
        size=1048593 if mode=='normal2chunks' else 37
        data=(b'0123456789abcdef' *((size+15)//16))[:size]
        path.write_bytes(data);path.chmod(0o600)
        native_sha=hashlib.sha256;native_uid=os.getuid;native_open=os.open;native_fstat=os.fstat;native_read=os.read;native_close=os.close;native_stat=Path.stat
        expected=native_sha(data).hexdigest();events=[];handles={};seen={};render=[]
        class First(OSError):
            def __repr__(self):render.append('repr');raise OSError('ROOT forbidden repr')
            def __str__(self):render.append('str');raise OSError('ROOT forbidden str')
            def add_note(self,note):render.append('add_note');raise OSError('ROOT forbidden note')
        first=First('ROOT after native hash operation')
        def call(stage,fn,*args,**kwargs):
            row=dict(stage=stage,attempted=True,returned=False);events.append(row)
            raw=fn(*args,**kwargs);row['returned']=True;row['raw_kind']='None' if raw is None else type(raw).__name__
            if type(raw) in (int,bool):row['raw_value']=raw
            if type(raw) is bytes:row['raw_size']=len(raw)
            if mode==stage+'_fault':seen['raw_'+stage]=raw;raise first
            return raw
        class BadPath:
            def __fspath__(self):events.append(dict(stage='fspath'));raise first
        supplied=BadPath() if mode=='path_fspath' else path
        def uid():return call('getuid',native_uid)
        def stating(actual,*args,**kwargs):
            if actual!=path:return native_stat(actual,*args,**kwargs)
            stage='stat_before' if seen.get('stat_calls',0)==0 else 'stat_after'
            seen['stat_calls']=seen.get('stat_calls',0)+1
            return call(stage,native_stat,actual,*args,**kwargs)
        def opening(*args,**kwargs):
            raw=native_open(*args,**kwargs);handles['fd']=raw
            info=native_fstat(raw);handles['identity']=(info.st_dev,info.st_ino)
            events.append(dict(stage='open',returned=True,raw_kind='int',raw_value=raw))
            return raw
        def fstating(fd):
            if fd!=handles.get('fd'):return native_fstat(fd)
            stage='fstat' if seen.get('fstat_calls',0)==0 else 'fstat_after'
            seen['fstat_calls']=seen.get('fstat_calls',0)+1
            return call(stage,native_fstat,fd)
        def reading(fd,requested):return call('read',native_read,fd,requested)
        def closing(fd):return call('close',native_close,fd)
        class HashFacade:
            def __init__(self,h):self.h=h
            def update(self,part):return call('hash_update',self.h.update,part)
            def hexdigest(self):
                raw=call('hexdigest',self.h.hexdigest)
                return raw.upper() if mode=='hexdigest_upper' else raw
        def hashing(*args,**kwargs):
            h=native_sha(*args,**kwargs);handles['hash']=h
            raw=call('hash_ctor',lambda:h)
            return HashFacade(raw) if mode in ('hash_update_fault','hexdigest_fault','hexdigest_upper') else raw
        received=None;marker=object();result=marker
        owners=None if mode=='getuid_fault' else {native_uid()}
        with mock.patch.object(producer.os,'getuid',uid),mock.patch.object(Path,'stat',stating),mock.patch.object(producer.os,'open',opening),mock.patch.object(producer.os,'fstat',fstating),mock.patch.object(producer.os,'read',reading),mock.patch.object(producer.os,'close',closing),mock.patch.object(producer.hashlib,'sha256',hashing):
            try:result=producer._regular_hash(supplied,owners=owners)
            except BaseException as error:received=error
        found=[r for r in producer._REGULAR_HASH_ATTEMPTS if r.original_path is supplied]
        attempt=found[-1] if found else None
        pure=None;before_guard=len(events)
        if mode!='normal2chunks' and attempt is not None:
            try:attempt.guard()
            except BaseException as error:pure=error
        rows=[] if attempt is None else [dict(stage=r['stage'],attempted=r['attempted'],returned=r['returned'],raw_kind='None' if r['raw'] is None else type(r['raw']).__name__,method_known=r['method'] is not None,error_is_received=r['error'] is received and received is not None,raw_text_uppercase=type(r['raw']) is str and r['raw'].isupper()) for r in attempt.steps]
        view=dict(mode=mode,events=events,source_rows=rows,received_type=None if received is None else type(received).__name__,received_original=received is first,
            Source_attempt_present=attempt is not None,Source_original_path_retained=attempt is not None and attempt.original_path is supplied,
            Source_fd=None if attempt is None else attempt.fd,ROOT_fd=handles.get('fd'),Source_fd_is_ROOT_original=attempt is not None and type(attempt.fd) is int and type(handles.get('fd')) is int and attempt.fd==handles['fd'],
            Source_completed=False if attempt is None else attempt.completed,Source_digest_None=attempt is None or attempt.digest is None,
            Source_first_received=attempt is not None and received is not None and attempt.first_error is received,
            pure_guard_first_is_received=pure is received and received is not None,pure_guard_no_monitored_IO=before_guard==len(events),Source_render_before_asserts=list(render),
            result_is_expected_digest=type(result) is str and result==expected,input_size=len(data),expected_digest=expected,ROOT_known_digest=seen.get('raw_hexdigest'),
            limits='Actual UID and OWN native input/mode/flags unchanged; Python method and FD facts DATA, not credentials/ABA/physicalEX/heapRSS/admission. Unique paths/no registryreset/second Sourcehash/replay.')
        (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n')
        try:
            self.assertIsNotNone(attempt);self.assertTrue(attempt.original_path is supplied);self.assertEqual([],render)
            if mode=='normal2chunks':
                self.assertIsNone(received);self.assertEqual(expected,result);self.assertTrue(attempt.completed);self.assertEqual(expected,attempt.digest)
                self.assertEqual([1048576,17,0],[x['raw_size'] for x in events if x['stage']=='read'])
                self.assertEqual(1,sum(x['stage']=='close' for x in events))
            else:
                self.assertIs(result,marker);self.assertFalse(attempt.completed);self.assertIsNone(attempt.digest)
                if mode=='hexdigest_upper':self.assertIs(type(received),producer.ProducerError)
                else:self.assertIs(received,first)
                self.assertIs(attempt.first_error,received);self.assertIs(pure,received);self.assertEqual(before_guard,len(events))
                self.assertFalse(any(x['stage']=='close' for x in events))
                failed='path' if mode=='path_fspath' else 'hexdigest' if mode=='hexdigest_upper' else mode.removesuffix('_fault')
                self.assertEqual(failed,attempt.steps[-1]['stage'])
                if mode=='hexdigest_upper':
                    self.assertTrue(attempt.steps[-1]['returned']);self.assertEqual(expected.upper(),attempt.steps[-1]['raw']);self.assertNotEqual(expected,expected.upper())
                else:self.assertFalse(attempt.steps[-1]['returned']);self.assertIsNone(attempt.steps[-1]['raw'])
                if mode in ('getuid_fault','path_fspath','stat_before_fault'):
                    self.assertIsNone(attempt.fd);self.assertIsNone(handles.get('fd'));self.assertFalse(any(x['stage']=='open' for x in events))
                else:self.assertEqual(handles['fd'],attempt.fd)
                if mode=='hash_update_fault':self.assertEqual(1,sum(x['stage']=='read' for x in events))
                if mode=='hash_ctor_fault':self.assertFalse(any(x['stage']=='read' for x in events))
                if mode=='fstat_fault':self.assertFalse(any(x['stage']=='hash_ctor' for x in events))
        finally:
            cleanup=dict(attempted=False,returned=None,identity_match=None)
            fd=handles.get('fd')
            if type(fd) is int and mode!='normal2chunks':
                try:
                    a=native_fstat(fd);b=native_stat(path)
                    same=(a.st_dev,a.st_ino)==handles['identity']==(b.st_dev,b.st_ino);cleanup['identity_match']=same
                    if same:cleanup['attempted']=True;cleanup['returned']=native_close(fd)
                except BaseException as error:cleanup['error_type']=type(error).__name__
            (base/'ROOT-known-FD-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_actual_getuid_then_ROOT_error_stops_before_path(self):self._hash_early_case('getuid_fault')
    def test_actual_Path_fspath_error_retains_original_without_FD(self):self._hash_early_case('path_fspath')
    def test_actual_stat_before_then_ROOT_error_stops_before_open(self):self._hash_early_case('stat_before_fault')
    def test_actual_initial_fstat_then_ROOT_error_keeps_original_FD(self):self._hash_early_case('fstat_fault')
    def test_actual_hash_constructor_then_ROOT_error_does_not_read(self):self._hash_early_case('hash_ctor_fault')
    def test_actual_hash_update_None_then_ROOT_error_does_not_read_again(self):self._hash_early_case('hash_update_fault')
    def test_actual_hexdigest_then_ROOT_error_does_not_close(self):self._hash_early_case('hexdigest_fault')
    def test_actual_hexdigest_then_uppercase_is_known_invalid(self):self._hash_early_case('hexdigest_upper')
    def test_new_normal_two_chunks_full_SHA_original_close(self):self._hash_early_case('normal2chunks')
