import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-regular-hash-early-seams-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();res=json.loads((P/'new-units/result.json').read_text());assert (res['tests'],res['passes'],res['failures'],res['errors'])==(9,9,0,0)
 old=(P/'before-tests.py').read_bytes();source=(P/'before-producer.py').read_bytes()
 assert (R/'tool/native_perf_build_producer.py').read_bytes()==source and (R/'tool/test_native_perf_build_producer.py').read_bytes()==old
 addition=(P/'regular_hash_early_regressions-v1.py').read_bytes();new=old+b'\n\n'+addition
 ast.parse(new);(R/'tool/test_native_perf_build_producer.py').write_bytes(new)
 before=json.loads((P/'before-hashes.json').read_text());h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in before};assert [k for k in h if h[k]!=before[k]]==['tool/test_native_perf_build_producer.py']
 (P/'after-tests.py').write_bytes(new);(P/'after-edit-hashes.json').write_text(json.dumps(h,indent=2))
 v=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer_source_UNCHANGED=True,source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],oldtests_BYTES_PREFIX_exact=True,appended_class_AST_exact_to_executed_private_v1=True,other19_helpers3bins_unchanged=True,new9_originalSource_PASS=True,no_Sourcefix_or_test_replay=True,not_fullcanonical_admission=True)
 (P/'edit-result.json').write_text(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['regular_hash_early_seams_progress'];n.update(test_append_pending=False,source_UNCHANGED=True,edit=v,ROOT_pending=True);c['active_turn_status']='Regularhash_early_NEW9PASS_testsonlyappend_ROOTpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
