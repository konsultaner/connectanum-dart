class _FileSnapshotAttempt(_JSONWriteAttempt):
    def __init__(self,path,maximum):
        # Reuse pure first/step machinery only; no JSON writer runs.
        super().__init__(path,None)
        self.maximum=maximum
        self.fd=None
        self.close_returned=False

    def run(self):
        call=self._step
        fail=self._fail
        guard=self.guard
        original_path=self.original_path
        maximum=self.maximum
        try:
            path=call('path',lambda:Path,(original_path,))
            self.path=path
            fd=call('open',lambda:os.open,(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC))
            if type(fd) is not int or fd<0:raise ProducerError('unknown log snapshot open return')
            self.fd=fd
            before=call('fstat_before',lambda:os.fstat,(fd,))
            if type(before) is not os.stat_result:raise ProducerError('unknown log snapshot fstat return')
            identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
            if (not stat.S_ISREG(before.st_mode)
                or before.st_uid!=call('getuid',lambda:os.getuid)
                or before.st_mode&0o022 or before.st_size>maximum):
                raise ProducerError('log snapshot type/owner/mode/size differs')
            h=call('hash_ctor',lambda:hashlib.sha256);count=0
            while True:
                requested=min(1024**2,maximum+1-count)
                part=call('read',lambda:os.read,(fd,requested))
                if type(part) is not bytes or len(part)>requested:
                    raise ProducerError('unknown log snapshot read return')
                if not part:break
                count+=len(part)
                updated=call('hash_update',lambda:h.update,(part,))
                if updated is not None:raise ProducerError('unknown log snapshot hash update return')
                if count>maximum:raise ProducerError('log snapshot grew beyond bound')
            if (count!=before.st_size
                or identity(before)!=identity(call('fstat_after',lambda:os.fstat,(fd,)))
                or identity(before)!=identity(call('stat_after',lambda:path.stat,(),dict(follow_symlinks=False)))):
                raise ProducerError('log changed during snapshot')
            digest=call('hexdigest',lambda:h.hexdigest)
            if type(digest) is not str or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
                raise ProducerError('unknown log snapshot digest return')
            value={'size':count,'sha256':digest}
            call('close',lambda:os.close,(fd,)) # Legacy close return is ignored.
            self.close_returned=True
            self.completed=True
            return value
        except BaseException as error:
            guard() # If a step refused, no second metadata/reporting operation.
            fail(error,self.steps[-1] if self.steps else None)