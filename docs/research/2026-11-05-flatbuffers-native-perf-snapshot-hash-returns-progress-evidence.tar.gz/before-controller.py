import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-hash-returns-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1024**3;q=P/'before-units';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_SNAPSHOT_HASH_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 private=(P/'snapshot_hash_regressions-v1.py').read_bytes();tm=types.ModuleType('snapshot_hash_regressions');tm.__file__=str(P/'snapshot_hash_regressions-v1.py');sys.modules[tm.__name__]=tm;exec(compile(private,tm.__file__,'exec'),tm.__dict__)
 cls=tm.SnapshotHashReturnTests;names=unittest.defaultTestLoader.getTestCaseNames(cls);assert len(names)==6
 (q/'declaration.json').open('x').write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,source_sha256=hashlib.sha256(source).hexdigest(),private_sha256=hashlib.sha256(private).hexdigest(),selection=names,expected_NEW6=True,no_child_or_numericalworkload=True),indent=2))
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls));(q/'tests.log').write_text(out.getvalue())
 value=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),selection=names,leases=leases,details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors],not_canonical_admission=True)
 (q/'result.json').write_text(json.dumps(value,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());state['native_perf_only_diagnostic_design']['producer_snapshot_hash_returns_progress'].update(before_pending=False,before_result=value);state['active_turn_status']='Producer_snapshot_hash_returns_NEW6_BEFORE_'+str(value['failures'])+'FAIL_'+str(value['errors'])+'ERROR';cp.write_text(json.dumps(state,indent=2)+'\n')
 l.verify_identity();print(json.dumps({k:value[k] for k in ('tests','failures','errors','passes')}));print(out.getvalue()[-1000:])
