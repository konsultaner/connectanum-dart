import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-snapshot-hash-returns-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-snapshot-hash-returns-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='d19e2bba4c6fd0ab0dd7f5ef0c294dc78016b751'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Validate snapshot hash returns before continuing\n\nThe snapshot helper ignored an invalid hash-update return and continued reading. It also accepted False or uppercase digest returns into a result and closed the FD. It now requires the native None update contract before the next read and an exact lowercase 64-character SHA before constructing the result or closing. Known invalid proxy returns remain recorded as returned; ROOT-known native None/SHA values are never substituted. Unknown hash completion still preserves the original first error and refuses further I/O.\n\nNEW6 beforeb2488d/f12e8f yields3FAIL/3PASS/0ERROR: three known-return refusal policies, not three spontaneous kernel bugs or a RAM cause. Two distinct unknown-completion controls and the new normal1,048,577-byte/two-chunk file already passed. Final958c4b/e9cc2a passes34selected=6matchingNEW+28affected(10previoussnapshot8end10actualwaitcallers). Native size/SHA, flags, default maximum, read/update/stat/digest/close order and all other Source bytes remain exact; old test prefix is exact. Twelve new direct views use zero child actors; affected finite waits and currentDarwinEX observations remain UNIT facts, not full independent EX/originalLinuxcredentials/allactorclosure. Qwen72468 completes0/fullanswer; GLM73037 reaches tokenlimit1 with full partial final ABSENT, not approval or global unavailability. ROOT independently qualifies final source/tests/results without repeating that review.\n\nRead-chunk retention is unchanged and establishes no heap/RSS or fixed-memory bound. Source remains uncommitted, uncanonical and unadmitted; runtime admission, RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-snapshot-hash-returns-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: validate snapshot hash return contracts'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_hash_returns_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Snapshot earlierconstructor-registration/metadata-globalbindings-hashfactory/postreadfstat-pathstat-returnshapes-calleeinterior-ABA; otherAPIs/enclosing-publicunknownCtor; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Current958c4b/e9cc2a ONLYhash_update mustNone BEFOREnextread/hexdigest exactstr-lowerhex64 BEFOREvalue-close; knownFalse-update/False-uppercase-digest rowTRUE rawinvalid retained/noRootnativeNone-SHA adoption; unknownupdate/digestNoneFalse unchanged/first-pureguard-only no SourceIO-close-repr-note-retry-replay-restore/reset. NEW6beforeb2488d/f12e8f=3FAIL3PASS0ERROR/3knownreturnrefusalpolicies NOT3nativekernelbugs-RAMcause; unknownupdate-digest+normal1048577Btwochunks alreadyPASS; final34PASS=6NEW28affected(10snapshot8end10actualwaitcallers)/no old5+5BEFORE/model-numericalreplay-aggregate-current20canonical-admission. SourcectorrawknownROOTproxy!=nativeunderlying/no nativeidentity-auth-admission. Nativehealthymax16GiB-flags-readsize-count/update-stat-digest-close-fullsizeSHA order exact/oldallothermethodshelpersfactoriesfrozenpredicates exact/wholeSourceBYTEprojectback/oldtestPREFIX.12newdirectviews+10prior8end/EX12before68after/ZEROnewchild/Rootclosebefore2unknown-after5negatives AFTERevidence/devino/old3accepted+normalalreadyclosed-no recloseborrowedFD;10priorRootclose7separate/8endRootsameboundwait10 signed7zero1threeCached UNITnotSourcecleanup-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. Qwen72468=0/1388out401err/fullanswer-ROOTqualified/reject1MiBmaxnewboundary/guardbeforeRootsetup/proxy-nativeauth;GLM73037tokenlimit1/0out808err/BOTH EOF-reaped/fullpartialfinalABSENT-notreconstructed/reachableNOTunavailability-approval/no unchangedreviewrepeat. ROOTwholefinalSource-tests-AST qualified NOTmodelwholecurrentapproval; candidatev1-privatev1UNEXECUTEDbeforeedit-firstBEFORE/controllersBEFOREcalls/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. RawchunksUNCHANGED/NOTfixedmemory/default16GiBlogicalfilelimitNOTheapRSSbound/growth-heapRSS-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-reset-evict-deleteauthority/1048577Blogicalbytes NOTheapRSS-magnitude proof. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_snapshot_hash_returns_selected34PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
