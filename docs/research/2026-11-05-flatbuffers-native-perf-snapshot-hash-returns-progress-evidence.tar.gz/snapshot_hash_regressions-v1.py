"""NEW native hash-return controls for snapshot helper; no benchmark actors."""
import os
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class SnapshotHashReturnTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_HASH_FIXTURES']);self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root))
        self.path=self.base/'hash-input.bin';self.body=b'H'*1048576+b'Z'
        with self.path.open('xb') as output:output.write(self.body)

    def _case(self,mode):
        native_os=producer.os;native_hashlib=producer.hashlib;calls=[];fds=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT native hash first')
        class HashProxy:
            def __init__(self,raw):self.raw=raw
            def update(self,part):
                raw=self.raw.update(part);calls.append(dict(kind='native_hash_update_return',raw_None=raw is None,size=len(part)))
                if sum(x['kind']=='native_hash_update_return' for x in calls)==1:
                    if mode=='update_False':return False
                    if mode=='update_unknown':raise first
                return raw
            def hexdigest(self):
                raw=self.raw.hexdigest();seen['native_digest']=raw;calls.append(dict(kind='native_hexdigest_return',raw=raw))
                if mode=='digest_False':return False
                if mode=='digest_upper':return raw.upper()
                if mode=='digest_unknown':raise first
                return raw
        class HashFacade:
            def __getattr__(self,name):return getattr(native_hashlib,name)
            def sha256(self,*args,**kwargs):
                raw=native_hashlib.sha256(*args,**kwargs);seen['native_hasher']=raw;proxy=HashProxy(raw);seen['proxy']=proxy;calls.append(dict(kind='native_hash_ctor_return_then_proxy'));return proxy
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs);info=native_os.fstat(raw);fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)));calls.append(dict(kind='native_open_return',fd=raw,flags=flags));return raw
            def read(self,fd,size):
                raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw)));return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt'));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None));return raw
        returned=False;result=None;received=None;guard_error=None;attempt=None
        try:
            before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(producer,'hashlib',HashFacade()):
                try:result=producer._file_snapshot(self.path);returned=True
                except BaseException as error:received=error
            attempts=producer._FILE_SNAPSHOT_ATTEMPTS[before:];attempt=attempts[-1] if attempts else None
            if mode!='normal' and attempt is not None:
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=[] if attempt is None else attempt.steps
            view=dict(mode=mode,snapshot_hash_control=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,pure_guard_same_received=received is not None and guard_error is received,
                Source_attempt_present=attempt is not None,Source_first_received=False if attempt is None else attempt.first_error is received,Source_completed=None if attempt is None else attempt.completed,Source_close_returned=None if attempt is None else attempt.close_returned,
                Source_ctor_raw_proxy=any(r['stage']=='hash_ctor' and r['returned'] and r['raw'] is seen.get('proxy') for r in rows),ROOT_native_hasher_known='native_hasher' in seen,ROOT_native_digest=seen.get('native_digest'),
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_False=r['raw'] is False,raw_upper64=type(r['raw']) is str and len(r['raw'])==64 and r['raw']==r['raw'].upper(),error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='MODULELOCALproducer.hashlib/osfacades; actualnativehasher thenSourceKNOWNROOTproxy !=nativeunderlying. NativeupdateNone/digestthenfault SourceunknownreturnsNEVERROOTfilled. KnownFalse-update/False-uppercase-digest rawknownreturnedTrue. ROOTactualOWNFD/devino beforefault/afterevidence sameopenFDcloseonly/no closedborrowedreclose. Negativepureguard/no SourceIO-close-repr-note-retry-replay-restore/reset. ZEROnewchild/parentDarwinEXNone UNITnotfullEX-originalLinux-allFDclosure-ownership/admission. 1048577Btwochunkunit notbenchmark-memoryRSSbound-timingcause; rawchunkretentionUNCHANGED/NOTfixedmemory.')
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable']);self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags']);self.assertTrue(attempt is not None);self.assertTrue(view['Source_ctor_raw_proxy']);self.assertTrue('native_hasher' in seen)
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned)
                self.assertEqual(dict(size=len(self.body),sha256=native_hashlib.sha256(self.body).hexdigest()),result)
                self.assertEqual([1048576,1,0],[x['size'] for x in calls if x['kind']=='native_read_return']);self.assertEqual([1048576,1],[x['size'] for x in calls if x['kind']=='native_hash_update_return']);self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls))
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed);self.assertFalse(attempt.close_returned)
                self.assertFalse(any(x['kind'] in ('Source_close_attempt','repr_first','note_first') for x in calls));last=rows[-1]
                if mode.startswith('update'):
                    self.assertEqual('hash_update',last['stage']);self.assertEqual([1048576],[x['size'] for x in calls if x['kind']=='native_read_return']);self.assertFalse(any(x['kind']=='native_hexdigest_return' for x in calls))
                else:self.assertEqual('hexdigest',last['stage']);self.assertTrue('native_digest' in seen)
                if mode.endswith('unknown'):
                    self.assertTrue(received is first);self.assertFalse(last['returned']);self.assertIsNone(last['raw']);self.assertTrue(last['error'] is first)
                else:
                    self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(last['returned'])
                    if mode.endswith('False'):self.assertTrue(last['raw'] is False)
                    else:self.assertEqual(seen['native_digest'].upper(),last['raw'])
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('snapshot hash pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);path=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(path.st_dev,path.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_native_hash_update_then_False_refuses_before_next_read(self):self._case('update_False')
    def test_native_hexdigest_then_False_refuses_before_close(self):self._case('digest_False')
    def test_native_hexdigest_then_uppercase_refuses_before_close(self):self._case('digest_upper')
    def test_native_hash_update_then_first_keeps_unknown_None(self):self._case('update_unknown')
    def test_native_hexdigest_then_first_keeps_unknown_digest(self):self._case('digest_unknown')
    def test_new_normal_twochunk_file_preserves_fullbytes_sha_order_close(self):self._case('normal')
