import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-hash-returns-progress-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in oldh.items())
 assert json.loads((P/'candidate-ROOT-projection.json').read_text())['wholeSource_BYTE_projectsback']
 source=(P/'candidate-producer-v1.py').read_bytes();tests=(P/'before-tests.py').read_bytes()+b'\n\n'+(P/'snapshot_hash_regressions-v1.py').read_bytes();ast.parse(source);ast.parse(tests)
 (R/'tool/native_perf_build_producer.py').write_bytes(source);(R/'tool/test_native_perf_build_producer.py').write_bytes(tests)
 h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert sorted(k for k in h if h[k]!=oldh[k])==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 (P/'after-producer.py').open('xb').write(source);(P/'after-tests.py').open('xb').write(tests);(P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2))
 v=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],wholeSource_BYTE_projectsback=True,all_other_classes_helpers_methods_frozenpredicates_exact=True,healthy_native_IO_order_preserved=True,raw_chunk_retention_growth_UNMEASURED=True,oldtests_PREFIX_exact=True,other18helpers3bins_unchanged=True,only_snapshot_hash_return_checks_Sourcechanged=True,no_historical_artifact_rewrite=True,no_ownership_fullEX_admission_authority=True)
 (P/'edit-result.json').open('x').write(json.dumps(v,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_hash_returns_progress'].update(Source_UNCHANGED=False,edit=v,model_pending=False,after_pending=True);n['current_source_sha256']=h;c['active_turn_status']='Producer_snapshot_hash_returns_NEW6_before3FAIL3PASS_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
