"""Bounded UTF-8 JSON event reader for exact saved-artifact equality and projection.
All values use the standard Python JSONDecoder. No schema or target execution.
"""
import codecs
import hashlib
import json
import re

_WS = re.compile(r"[ \t\r\n]*")
_SPECIAL = re.compile(r'["\\]')
_DELIM = re.compile(r"[ \t\r\n,\]}]")
_DECODER = json.JSONDecoder()

class BoundedJSON:
    def __init__(self, read, size, chunk_size=65536):
        if size < 0 or chunk_size < 1:
            raise ValueError("invalid declared bound")
        self.read = read
        self.size = size
        self.remaining = size
        self.chunk_size = chunk_size
        self.buffer = ""
        self.pos = 0
        self.decoder = codecs.getincrementaldecoder("utf-8")("strict")
        self.finalized = False
        self.bytes_read = 0
        self.characters_consumed = 0
        self.digest = hashlib.sha256()

    def _fill(self):
        while self.pos == len(self.buffer):
            self.buffer = ""
            self.pos = 0
            if self.remaining:
                wanted = min(self.chunk_size, self.remaining)
                raw = self.read(wanted)
                if not raw or len(raw) > wanted:
                    raise ValueError("declared range short/overrun")
                self.remaining -= len(raw)
                self.bytes_read += len(raw)
                self.digest.update(raw)
                self.buffer = self.decoder.decode(raw, final=False)
            elif not self.finalized:
                self.finalized = True
                self.buffer = self.decoder.decode(b"", final=True)
            else:
                return False
        return True

    def _advance(self, count):
        self.pos += count
        self.characters_consumed += count

    def peek(self):
        return self.buffer[self.pos] if self._fill() else None

    def space(self):
        while self._fill():
            end = _WS.match(self.buffer, self.pos).end()
            self._advance(end - self.pos)
            if self.pos < len(self.buffer):
                return self.buffer[self.pos]
        return None

    def expect(self, char):
        if self.space() != char:
            raise ValueError("expected " + repr(char))
        self._advance(1)

    def string(self):
        if self.peek() != '"':
            raise ValueError("expected JSON string")
        pieces = ['"']
        self._advance(1)
        while self._fill():
            found = _SPECIAL.search(self.buffer, self.pos)
            if found is None:
                pieces.append(self.buffer[self.pos:])
                self._advance(len(self.buffer) - self.pos)
                continue
            pieces.append(self.buffer[self.pos:found.end()])
            self._advance(found.end() - self.pos)
            if found.group() == '"':
                token = "".join(pieces)
                value, end = _DECODER.raw_decode(token)
                if end != len(token) or not isinstance(value, str):
                    raise ValueError("invalid complete string token")
                return value
            escaped = self.peek()
            if escaped is None:
                raise ValueError("unfinished escape")
            pieces.append(escaped)
            self._advance(1)
        raise ValueError("unfinished JSON string")

    def atom(self):
        pieces = []
        while self._fill():
            found = _DELIM.search(self.buffer, self.pos)
            end = len(self.buffer) if found is None else found.start()
            pieces.append(self.buffer[self.pos:end])
            self._advance(end - self.pos)
            if found is not None:
                break
        token = "".join(pieces)
        value, end = _DECODER.raw_decode(token)
        if end != len(token) or isinstance(value, (dict, list, str)):
            raise ValueError("invalid primitive token")
        return value

    def events(self):
        char = self.space()
        if char == "{":
            self._advance(1)
            yield ("object_start", None)
            if self.space() != "}":
                while True:
                    if self.space() != '"':
                        raise ValueError("object key must be string")
                    yield ("key", self.string())
                    self.expect(":")
                    yield from self.events()
                    char = self.space()
                    if char == "}":
                        break
                    self.expect(",")
            self.expect("}")
            yield ("object_end", None)
        elif char == "[":
            self._advance(1)
            yield ("array_start", None)
            if self.space() != "]":
                while True:
                    yield from self.events()
                    char = self.space()
                    if char == "]":
                        break
                    self.expect(",")
            self.expect("]")
            yield ("array_end", None)
        elif char == '"':
            yield ("atom_str", self.string())
        elif char is None:
            raise ValueError("missing JSON value")
        else:
            value = self.atom()
            yield ("atom_" + type(value).__name__, value)

    def document_events(self):
        yield from self.events()
        self.finish()

    def finish(self):
        if self.space() is not None or self.remaining or self.bytes_read != self.size:
            raise ValueError("trailing data or unfinished bounded document")

    def value(self):
        root = []
        stack = []
        def append(value):
            if not stack:
                root.append(value)
            elif isinstance(stack[-1][0], list):
                stack[-1][0].append(value)
            else:
                container, key = stack[-1]
                if key is None:
                    raise ValueError("missing object key")
                container[key] = value
                stack[-1][1] = None
        for kind, value in self.events():
            if kind in ("object_start", "array_start"):
                obj = {} if kind == "object_start" else []
                append(obj)
                stack.append([obj, None])
            elif kind in ("object_end", "array_end"):
                stack.pop()
            elif kind == "key":
                stack[-1][1] = value
            else:
                append(value)
        if len(root) != 1 or stack:
            raise ValueError("incomplete value construction")
        return root[0]

    def skip_value(self):
        for unused in self.events():
            pass

    def array_values(self):
        self.expect("[")
        if self.space() != "]":
            while True:
                yield self.value()
                if self.space() == "]":
                    break
                self.expect(",")
        self.expect("]")

    def object_keys(self):
        self.expect("{")
        if self.space() != "}":
            while True:
                if self.space() != '"':
                    raise ValueError("object key must be string")
                key = self.string()
                self.expect(":")
                yield key
                if self.space() == "}":
                    break
                self.expect(",")
        self.expect("}")
