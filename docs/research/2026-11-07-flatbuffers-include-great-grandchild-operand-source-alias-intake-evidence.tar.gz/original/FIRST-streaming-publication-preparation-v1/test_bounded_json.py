import hashlib,importlib.util,io,json,sys
path=sys.argv[1]
raw_module=open(path,"rb").read()
assert hashlib.sha256(raw_module).hexdigest()==sys.argv[2]
spec=importlib.util.spec_from_file_location("FIRST_artifact_bounded_json",path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks=[]
def reader(raw,size=None,chunk=65536):
    declared=len(raw) if size is None else size
    stream=io.BytesIO(raw)
    requests=[]
    def bounded_read(wanted):
        assert 0<wanted<=declared-stream.tell()
        requests.append(wanted)
        return stream.read(wanted)
    return module.BoundedJSON(bounded_read,declared,chunk),stream,requests
valid=[
    b'{"b":1,"a":"x"}',
    json.dumps({"escaped":'quote" slash\\ newline\n tab\t', "unicode":"é😀漢字"},ensure_ascii=False).encode("utf-8"),
    b'{"k":1,"k":2}',
    b'{"a":[],"b":{},"c":[[[],{}]]}',
    b'[1,-1,0.5,1e10,null,true,false,-0.0,123456789012345678901234567890]',
    b'""',b'0',b'null',b'true',b'[]',b'{}',
    b' \t\r\n{"": {"x":[{"q":"ok"}]}}\n',
    b'{"surrogate":"\\ud800","pair":"\\ud83d\\ude00"}'
]
chunks=[1,2,3,7,64,65536]
for index,raw in enumerate(valid):
    expected=json.loads(raw.decode("utf-8"))
    for chunk in chunks:
        parsed,s,req=reader(raw,chunk=chunk)
        assert parsed.value()==expected,(index,chunk)
        parsed.finish()
        assert parsed.bytes_read==len(raw) and s.tell()==len(raw)
        assert parsed.digest.hexdigest()==hashlib.sha256(raw).hexdigest()
        event_reader,s2,req2=reader(raw,chunk=chunk)
        events=list(event_reader.document_events())
        assert events and event_reader.bytes_read==len(raw) and s2.tell()==len(raw)
        checks.append({"case":"standard_JSON_value_and_full_events","fixture":index,"chunk":chunk,"passed":True})
r,unused,unused2=reader(b'{"k":1,"k":2}',chunk=1)
assert list(r.document_events()).count(("key","k"))==2
checks.append({"case":"duplicate_keys_full_events_preserved_last_wins_value","passed":True})
prefix=b'{"x":[1,2]}'
r,s,requests=reader(prefix+b"UNREAD_TAIL",size=len(prefix),chunk=3)
assert r.value()==json.loads(prefix)
r.finish()
assert s.tell()==len(prefix) and r.bytes_read==len(prefix) and sum(requests)==len(prefix)
checks.append({"case":"exact_bound_no_EOF_probe_or_extra_tail_read","passed":True})
invalid=[b"",b"{",b'{"x":1',b'{"x":}',b"[1,]",b'{"x":1,}',b"{}{}",b'"unterminated',b'"bad\\q"',b'"\xff"',b'"\xf0\x9f"',b"01",b"1e",b"{1:2}",b"truefalse"]
for index,raw in enumerate(invalid):
    try:json.loads(raw.decode("utf-8"))
    except (ValueError,UnicodeError):pass
    else:raise AssertionError(("bad oracle fixture",index))
    for chunk in chunks:
        r,s,requests=reader(raw,chunk=chunk)
        try:list(r.document_events())
        except (ValueError,UnicodeError):pass
        else:raise AssertionError(("accepted invalid",index,chunk))
        assert s.tell()<=len(raw)
        checks.append({"case":"standard_JSON_or_UTF8_invalid_rejected","fixture":index,"chunk":chunk,"passed":True})
for first,second in [
    (b'{"a":[1,{"x":true}]}',b'{"a":[1,{"x":false}]}'),
    (b'{"a":[1,2]}',b'{"a":[1]}'),
    (b'{"a":0}',b'{"a":false}'),
    (b'{"a":1,"b":2}',b'{"a":1,"c":2}')
]:
    ra,unused,unused2=reader(first,chunk=1)
    rb,unused,unused2=reader(second,chunk=2)
    assert list(ra.document_events())!=list(rb.document_events())
    checks.append({"case":"changed_nested_field_array_row_type_or_key_detected","passed":True})
raw=json.dumps({"summary":{"x":1},"rows":[1,{"x":[True,None]}],"skip":{"private":[{"all":"kept"}]}}).encode()
for chunk in chunks:
    r,s,requests=reader(raw,chunk=chunk)
    projected={}
    for key in r.object_keys():
        if key=="rows":projected[key]=list(r.array_values())
        elif key=="summary":projected[key]=r.value()
        else:r.skip_value()
    r.finish()
    assert projected=={"summary":{"x":1},"rows":[1,{"x":[True,None]}]}
    assert s.tell()==len(raw) and r.digest.hexdigest()==hashlib.sha256(raw).hexdigest()
    checks.append({"case":"full_document_projection_interfaces_no_unread_fields","chunk":chunk,"passed":True})
print(json.dumps({"checks":len(checks),"all_passed":all(x["passed"] for x in checks),"cases":checks,"module_bytes":len(raw_module),"module_sha256":hashlib.sha256(raw_module).hexdigest(),"standard_library_JSON_oracle":True,"new_original_saved_metadata_processed":False,"Source20_runtime_SDK_or_old_control_tests_touched":False}))
