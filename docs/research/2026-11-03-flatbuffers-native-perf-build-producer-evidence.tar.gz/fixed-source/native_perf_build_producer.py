"""Own source-frozen command evidence, not capture or canonical admission.

Caller holds the official exclusive lease. Only fixed live factories may select
canonical/production recipes; fixture commands are labelled in every receipt.
A waited child and log snapshot do not prove all descendants exited, SDK identity,
complete canonical validation, loader validity, or loaded role/native-image bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time
from types import MappingProxyType


class ProducerError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise ProducerError('Python 3.11 or newer required before producer IO')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _regular_hash(path, maximum=1024**3):
    path=Path(path)
    if not path.is_absolute() or path.resolve(strict=True)!=path:
        raise ProducerError('input path must be canonical without symlinks')
    before=path.stat(follow_symlinks=False)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o022 or not 0<info.st_size<=maximum:
            raise ProducerError('input type/owner/mode/size differs')
        if identity(before)!=identity(info):raise ProducerError('input changed before read')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            h.update(part);count+=len(part)
            if count>maximum:raise ProducerError('input grew beyond bound')
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info):
            raise ProducerError('input changed during read')
        return h.hexdigest()
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('input close failed: '+repr(e))


def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))


def _write_json(path,value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode())
        f.flush();os.fsync(f.fileno())


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None):
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        self.repo=Path(repo);self.directory=Path(run_dir)
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.commands=tuple(tuple(a) for a in commands);self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self.deferred_error=repr(error)
                self._preserve_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        out=self.directory/f'git-{index:03}.stdout';err=self.directory/f'git-{index:03}.stderr'
        with out.open('xb') as o,err.open('xb') as e:
            result=subprocess.run(['git','-C',str(self.repo),*argv],stdin=subprocess.DEVNULL,stdout=o,stderr=e,close_fds=True)
        stdout=_file_snapshot(out,1024**3);stderr=_file_snapshot(err,32*1024**2)
        self._event('git_observation',argv=list(argv),returncode=result.returncode,stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'])
        if result.returncode:raise ProducerError('git observation failed; exact stdout/stderr retained')
        if argv[0]=='archive':return out
        if stdout['size']>32*1024**2:raise ProducerError('git metadata exceeds declared bound')
        return out.read_bytes()

    def _source_guard(self):
        self.lease_check()
        if self._git('rev-parse','HEAD').decode().strip()!=self.source_commit:raise ProducerError('source HEAD differs')
        if self._git('status','--porcelain','--untracked-files=normal'):raise ProducerError('source worktree is not clean')
        if self._git('diff','--no-ext-diff','--no-textconv',self.runtime_commit,self.source_commit,'--','packages','native'):raise ProducerError('runtime source differs')

    def _make_archive(self):
        # git archive bytes are kept without extraction. Validate every blob and mode.
        raw_path=self._git('archive','--format=tar',self.source_commit)
        archive=self.directory/'source.tar'
        # Exclusive hard-link publication keeps original command bytes, no copy/overwrite.
        os.link(raw_path,archive,follow_symlinks=False)
        archive_hash=_regular_hash(archive)
        if archive_hash!=self.expected_archive_sha256:raise ProducerError('source archive differs from immutable expected digest')
        tree={}
        for entry in self._git('ls-tree','-rz',self.source_commit).split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,kind,object_id=meta.split(b' ')
            if kind!=b'blob':raise ProducerError('unsupported source tree entry')
            tree[os.fsdecode(name)]=(mode.decode(),object_id.decode())
        found=set()
        with tarfile.open(archive,'r:') as tar:
            for member in tar:
                if member.isdir():continue
                if member.name not in tree or member.name in found:raise ProducerError('archive has unknown or duplicate source entry')
                mode,object_id=tree[member.name]
                if member.issym() and mode=='120000':data=os.fsencode(member.linkname)
                elif member.isfile() and mode in ('100644','100755'):
                    if member.size>128*1024**2:raise ProducerError('source entry exceeds declared bound')
                    if bool(member.mode&0o111)!=(mode=='100755'):raise ProducerError('source archive executable mode differs')
                    data=tar.extractfile(member).read()
                else:raise ProducerError('source archive type differs')
                if hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=object_id:raise ProducerError('source archive blob differs')
                found.add(member.name)
        if found!=set(tree):raise ProducerError('source archive omits committed files')
        self.source_entries=len(found);self.source_archive_sha256=_regular_hash(archive)
        if self.source_archive_sha256!=archive_hash:raise ProducerError('archive changed during membership check')
        self._event('source_archive',sha256=self.source_archive_sha256,entries=self.source_entries)

    def _input_guard(self):
        self.lease_check()
        for relative,expected in self.inputs.items():
            if _regular_hash(self.repo/relative)!=expected:raise ProducerError('input identity/digest differs: '+relative)

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index])
        self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
        self.log=(self.directory/f'command-{index:03}.log').open('xb')
        record={'argv':argv,'cwd':str(self.repo),'started_ns':time.time_ns(),'returncode':None,'spawn_error':None}
        self.records.append(record)
        try:
            self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=self.log,stderr=subprocess.STDOUT,close_fds=True,env={**os.environ,**self.env_delta})
        except OSError as e:
            record['spawn_error']=repr(e);self._end_command(None)
            self._finish('failed','command spawn failed')
        else:
            record['pid']=self.process.pid;self.pending=True
            self._event('command_spawned',index=index,pid=self.process.pid)

    def _end_command(self,status):
        self.pending=False
        record=self.records[-1];record['returncode']=status;record['ended_ns']=time.time_ns()
        log=self.log;self.log=None
        log.flush();os.fsync(log.fileno());log.close()
        data=_file_snapshot(self.directory/f'command-{len(self.records)-1:03}.log')
        record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
        self._event('command_end',index=len(self.records)-1,**record)

    def _finish(self,status,error=None):
        self.finished=True
        output_hashes={}
        if status=='success':
            for role,path in self.outputs.items():
                if '*' in str(path):
                    matches=sorted(Path(path).parent.glob(Path(path).name))
                    if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                    path=matches[0]
                output_hashes[role]={'path':str(path),'sha256':_regular_hash(Path(path))}
        self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                     'scope':'owned_child_waited_and_file_snapshots_only','capture_ready':False,
                     'status':status,'error':error,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                     'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                     'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance}
        _write_json(self.directory/'result.json',self.result)
        self._event('finished',status=status,error=error)
        events=self.events;self.events=None;events.close()
        return self.result

    def _preserve_failure(self,error):
        try:_write_json(self.directory/'failure.json',{'error':repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance})
        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))
        if not self.pending and self.events is not None:
            events=self.events;self.events=None
            try:events.close()
            except BaseException as secondary:error.add_note('journal close failed: '+repr(secondary))

    def wait(self,timeout):
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        self.lease_check()
        deadline=time.monotonic()+timeout
        try:
            while True:
                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            if self.pending:
                self.deferred_error=repr(e)
                self._preserve_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise


def start_fixture(**kwargs):
    return CommandProducer(**kwargs,provenance='fixture')


def _live_inputs(inputs):
    required={'pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'}
    if type(inputs) is not dict or not required<set(inputs) or any(k not in required and not k.endswith('/.dart_tool/package_config.json') and k!='.dart_tool/package_config.json' for k in inputs):
        raise ProducerError('actual three locks and generated package configs required')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR'):
        if os.environ.get(key):raise ProducerError('undeclared build environment: '+key)


def start_canonical(**kwargs):
    _live_inputs(kwargs.get('inputs'))
    repo=Path(kwargs['repo']);native=repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')
    configured=os.environ.get('CONNECTANUM_NATIVE_LIB')
    if configured and Path(configured).resolve()!=native:raise ProducerError('canonical native path is outside own declared release output')
    return CommandProducer(**kwargs,commands=[['bin/verify']],provenance='canonical_recipe',outputs={'canonical_native':native})


def start_production(**kwargs):
    if sys.platform!='linux':raise ProducerError('production ELF recipe requires actual Linux')
    _live_inputs(kwargs.get('inputs'))
    target=Path(kwargs['run_dir'])/'target'
    return CommandProducer(**kwargs,provenance='production_recipe',env_delta={'CARGO_TARGET_DIR':str(target)},
        commands=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                  ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],
        outputs={'native_elf':target/'release/libct_ffi.so','driver_elf':target/'release/http_stream',
                 'static_rlib':target/'release/deps/libct_core-*.rlib'})
