import hashlib
import json
import os
import pathlib
import stat
import time

references = ["/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu","/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin","/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib","/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib/rustlib","/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu","/home/runner/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/lib","/lib64"]
capture_direct_regular_files = [references[0], references[3]]
root = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-compiler-package-inputs"
root.mkdir()
journal = open(root / "operations.jsonl", "x", encoding="utf-8")
owned = []
observations = []
streams = []

def event(operation, **fields):
    journal.write(json.dumps({"operation": operation, "monotonic_ns": time.monotonic_ns(),
                              **fields}, sort_keys=True) + "\n")
    journal.flush()

def state(fd):
    s = os.fstat(fd)
    return {"dev": s.st_dev, "ino": s.st_ino, "mode": s.st_mode,
            "uid": s.st_uid, "gid": s.st_gid, "size": s.st_size,
            "mtime_ns": s.st_mtime_ns, "ctime_ns": s.st_ctime_ns}

def close_known(fd, role):
    try:
        event("close_attempt", fd=fd, role=role)
    finally:
        os.close(fd)
    owned.remove(fd)
    event("close_return", fd=fd, role=role)

def preserve(directory_fd, name, source_path):
    source = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory_fd)
    owned.append(source)
    try:
        event("source_open_return_before_read", fd=source, source=source_path)
        before = state(source)
        if not stat.S_ISREG(before["mode"]):
            raise RuntimeError("source opened as nonregular input")
        saved = "package-input-%04d.bin" % len(streams)
        destination = os.open(root / saved, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
        owned.append(destination)
        try:
            event("destination_open_return_before_write", fd=destination, saved=saved)
            digest = hashlib.sha256()
            count = 0
            while True:
                chunk = os.read(source, 1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                digest.update(chunk)
                offset = 0
                while offset < len(chunk):
                    written = os.write(destination, chunk[offset:])
                    if written <= 0:
                        raise RuntimeError("destination write made no progress")
                    offset += written
            event("source_EOF", fd=source, bytes=count, sha256=digest.hexdigest())
            after = state(source)
            os.lseek(destination, 0, os.SEEK_SET)
            readback = hashlib.sha256()
            reread = 0
            while True:
                chunk = os.read(destination, 1024 * 1024)
                if not chunk:
                    break
                reread += len(chunk)
                readback.update(chunk)
            event("destination_readback_EOF", fd=destination, bytes=reread,
                  sha256=readback.hexdigest())
            if before != after or count != reread or digest.digest() != readback.digest():
                raise RuntimeError("source metadata or saved stream/readback mismatch")
            row = {"source": source_path, "saved": saved, "bytes": count,
                   "sha256": digest.hexdigest(), "source_before": before,
                   "source_after": after, "saved_readback_matches": True}
            streams.append(row)
            return row
        finally:
            close_known(destination, "saved_package_input")
    finally:
        close_known(source, "package_input")

try:
    for path in references:
        row = {"source_directory_reference": path, "entries": []}
        observations.append(row)
        try:
            directory = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
        except FileNotFoundError as error:
            row["absent_at_source_open_only"] = {"type": type(error).__name__, "text": str(error)}
            event("directory_absent_at_open", path=path, **row["absent_at_source_open_only"])
            continue
        owned.append(directory)
        try:
            event("directory_open_return_before_list", fd=directory, path=path)
            row["directory_before"] = state(directory)
            names = os.listdir(directory)
            event("directory_list_return", fd=directory, count=len(names))
            for name in sorted(names, key=os.fsencode):
                entry = {"name_bytes_hex": os.fsencode(name).hex(), "name": name}
                row["entries"].append(entry)
                s = os.stat(name, dir_fd=directory, follow_symlinks=False)
                entry["separate_lstat"] = {"dev": s.st_dev, "ino": s.st_ino,
                    "mode": s.st_mode, "uid": s.st_uid, "gid": s.st_gid,
                    "size": s.st_size, "mtime_ns": s.st_mtime_ns, "ctime_ns": s.st_ctime_ns}
                if stat.S_ISLNK(s.st_mode):
                    entry["separate_readlink"] = os.readlink(name, dir_fd=directory)
                if path in capture_direct_regular_files and stat.S_ISREG(s.st_mode):
                    entry["saved_stream"] = preserve(directory, name, os.path.join(path, name))
            row["directory_after"] = state(directory)
        finally:
            close_known(directory, "source_directory")
    report = {
        "workflow_revision": os.environ["GITHUB_SHA"], "run_id": os.environ["GITHUB_RUN_ID"],
        "reference_basis": "ALL six previously retained actual compiler-input paths supply "
                           "their four distinct immediate parents; three intermediate package "
                           "ancestors are included without target/ABI/host filtering.",
        "source_directory_references": references,
        "capture_direct_regular_files": capture_direct_regular_files,
        "selection_rule": "List every entry in all seven fixed reference directories. "
                          "Save every direct regular file in the two declared package metadata "
                          "roots only, with no filename/content filter, recursion or tool query. "
                          "Do not reopen previously snapshotted bin/lib/target-library images.",
        "observations": observations, "streams": streams,
        "collector_credentials": {"uid": os.getuid(), "gid": os.getgid(), "groups": os.getgroups()},
        "collector_cwd": os.getcwd(), "native_information_queries": 0, "candidate_executions": 0,
        "remaining_known_input_FDs": list(owned), "all_admission_flags": False,
        "qualification": "Historical source references and new point package inputs only; "
                         "not actual compiler-build CFG_DEFAULT_LINKER/flavor, effective Cargo "
                         "target/config-env, selected C-header/sysroot, ABI, original loaded "
                         "runtime/cohort/credentials, transitive actor FD, atomic ABA/origin/"
                         "authentication or continuous official physical EX/crash admission. "
                         "No path absence is a global absence, bug or generation authority."
    }
    with open(root / "compiler-package-inputs.json", "x", encoding="utf-8") as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
    event("report_saved", observations=len(observations), streams=len(streams),
          native_information_queries=0, candidate_executions=0, remaining_known_input_FDs=list(owned))
finally:
    journal.close()
