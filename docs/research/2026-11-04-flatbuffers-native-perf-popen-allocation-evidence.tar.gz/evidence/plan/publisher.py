import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-preparation');a=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='506dc6a0a42a0f4ddee3d9958eab33996a5e84b4'
 assert git('status','--porcelain')==''
 h=json.loads((p/'current-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 assert before>=1024**3+256*1024**2
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  controller_order_qualified_per_kind=True))
 base='2026-11-04-flatbuffers-native-perf-popen-allocation';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'plan'),(a,'design'),(final_root,'root-final')]+[(pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-before-v'+str(i)),'before-v'+str(i)) for i in (1,2,3)] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='Before V1-V3 controllers saved beforeexecution; model controllers serialized aftercalls with separate command-before receipts. No execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Popen allocation ownership before constructor return\n\nFive new controls exercise the unchanged direct-command producer. Three\nnegative controls call the real Popen initializer and then inject OSError,\nRuntimeError or a False return. False produces the native class-call TypeError\nafter the real initializer has returned normally. The producer has no private\nallocated-object reference before initialization or after these failures.\nA fourth negative rebinds the initializer after capsule import: the declared\nforeign hook runs once before any native initializer, rather than being refused.\nThe normal real-constructor control passes. Result:4FAIL/1PASS, with no missing\nAPIs. These are finite fault models and proposed ownership-contract failures,\nnot four observed SDK/kernel/RAM defects.\n\nFour actual finite OWN Python children return signed0 through the same Popen\nwait methods before unit FD/log cleanup. The child writes a private ready\nfile, waits for a private release directory or deadline and emits no stdout.\nThis intentionally avoids unit SIGPIPE from the producer's existing error\ncleanup, which may close parent pipe copies before child exit. It is not an\noriginal workload, stream-integrity, leak or global orphan demonstration.\nThe unit hook holds each actual instance before native I/O for cleanup only.\nIt never backfills the producer's missing reference or wait marker. Other\ninterpreter bookkeeping is not inspected or adopted.\n\nThe normal case verifies exact Popen class, argv/cwd, DEVNULL, original creator\nwriter, merged stderr, close_fds and environment object/declared unit delta.\nSource wait markers stayFalse/null before and after root waits. Parent pipe\ndescriptors are registered before metadata; unit cleanup checks their original\nidentity/access and never closes a retired or mismatched number. An already\nclosed original read FD does not become reconstructed EOF. Private original\nbuffers, ready observations, signed wait returns before FD cleanup, remaining\nreader suffixes and log bytes are retained. Error objects remain private;\nsaved reports contain native type labels and identity booleans. Unit known-FD/\nwriter cleanup is never a live release, retry, recovery or source-state retag.\nThe official EX lease and actual lease callback span these known finite cases,\non the current Darwin host only.\n\nTwo setup attempts precede the meaningful controls. V1 supplies an unsupported\nenvironment keyword and omits the required lease callback: all five calls stop\nbefore the producer body/native constructor. Its4FAIL/1vacuousPASS and zero\nchildren are not ownership defect counts. V2 uses valid kwargs but passes\nnoncanonical /tmp aliases; all five stop before a native constructor and the\nfinal boundary assertion refuses its counts. Its case reports remain, but no\nsummary exists. Earlier exception text was not serialized and is not rebuilt;\nthe canonical violation is inferred from passed arguments and the source\npredicate. V3 resolves its reserved root canonically, retains the producer at\nentry and reaches all five declared boundaries. Only setup-blocked,\nnonnumerical controls run again; no original numerical data is retried.\nAll versions and their namespaces remain intact.\n\nThe selected repair is UNIMPLEMENTED. It will capture the exact class,\nresolved standard allocator and initializer references, check bindings before\nallocation/initialization, and retain a distinct allocated_process reference\nimmediately after allocation and before initializer I/O. The existing\nattempt.process/self.process assignments remain after normal construction.\nThe initializer must return None, preserving native class-call semantics.\nNew stage facts and frozen DATA schema must retain an allocated but partially\ninitialized object without inventing pid/status/liveness or permission to call\nmethods. Ordinary successful argv/env/stdio behavior must match the original.\nThe original public spawn repr/add_note/pipe/error/end/finish policy remains\noutside this narrow repair and can still mask errors or close pipe copies.\nNo fallback constructor, subclass, SDK/flag change, destructor/GC discard,\nglobal bookkeeper lookup or unknown-actor cancellation is authorized.\n\nGLM32217 design, Qwen32605 tests and Qwen33884 coordinator review complete0\nand are reaped. All advice is qualified by ROOT. ROOT accepts pinning initializer/\nallocator and a distinct allocated field, and corrects the suggestion to fetch\ninherited __new__ directly from vars(Popen). Local descriptor observations\nshow the current administrative allocator is object.__new__; that is data,\nnot loaded-image/original-host proof. ROOT rejects the tests' before-native\nfault description and treating the object as garbage: the real initializer\nfinishes before each injected negative. None-only return validation is required.\nThe review's pipe-boundary finding is false: _spawn creates the source pipe\nbefore invoking Popen, independently of stdlib internal pipes, and every V3\nboundary check passes. Its claim that False is an allowed initializer return\nis false; the native TypeError boundary is intentional. No control is softened\nor rerun to answer those findings. This is no model approval of the whole\ncurrent source or physical closure.\n\nSource b21de603411cae89e1956f78057e8ff9e702b3b3a1e2fcfb4fc1b39be04f84c6\nand test45087533599c3d141513bd6c60660712cd36dcc31606e15b717a2e21f399957b\nremain unchanged. All23 selected source/bin hashes match before and after\ncontrols. Only the exact held producer buffer is compiled in private capsules,\nnot a current20 canonical or native build. All20 helpers remain uncommitted,\nuncanonical and unadmitted; production601 is unedited. No fresh source Git query\nis run for these read-only controls; the prior branch/HEAD observations remain\nhistorical. Private controllers are retained artifacts outside HELPERBUNDLE20.\nBefore controllers V1-V3 are saved before execution; new model controllers\nare serialized after calls with separate command-before receipts. No ordering\nfact is execution admission.\n\nNext implement the retained allocator and matching meaningful regressions,\nthen address original spawn cleanup, historical continuation/log sealing,\ntransitive generic FDs, audit partial/unknown actors, writer/interpreter/\ndelegate/descendant coverage and the full actual officialEX controller.\nOriginal PATH/SDK/bootstrap/first3locks/hiddenconfigs/current20canonical/new\nsource package/OWN native-driver-static RLIB/compiler-tool-kernel and actual\noriginal-host credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/\ntime/coverage remain required before ROOT-qualified immutable COMPLETE\nadmission and diagnostic data. No source-branch commit/push/adoption/strict\ndispatch, borrowed cohort/config/native transplant, favorable redo or postGO\nas preproof. Existing emit/auxiliary predicates stay closed.\n\nProvider absent, live gate always raises, controller closed, ownershipNone,\nall three flagsFalse. No actual SDK/native build/canonical/kernel/broker/\nbenchmark/capture, RAM cause/repair or strict acceptance. Latest assessment\nfree11.73GB is below12GiB: build floor CLOSED; recheck before any build.\nScoped tests use their separate1GiB floor. Cause unmeasured/no cleanup.\nPR132 stays OPEN DRAFT on130; issue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Pre-constructor Popen ownership reproduced; repair unimplemented\n\nFive meaningful controls yield4FAIL/1PASS: the producer lacks an allocated-object reference across three post-initializer fault boundaries and invokes a rebound initializer; normal construction passes. Four actual finite Python children return signed0 before unit FD/log cleanup. Two earlier setup attempts reach no native constructor and are excluded from ownership counts. Source/test and all20 helpers remain unchanged/uncommitted/uncanonical/unadmitted; production601 unedited. Captured allocator/initializer binding, pre-init retention and None-only return handling are selected but UNIMPLEMENTED. Existing public cleanup/full physical EX/runtime admission remain incomplete; build floor CLOSED below12GiB.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-popen-allocation-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-popen-allocation-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-popen-allocation-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: record pre-constructor Popen ownership boundary')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['popen_allocation_preparation'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['popen_allocation_GitHub_descriptions_pending']=True;n['popen_allocation_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
