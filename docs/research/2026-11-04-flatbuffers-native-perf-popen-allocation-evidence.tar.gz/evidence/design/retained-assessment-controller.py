import sys,pathlib,json,hashlib,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-preparation');P.mkdir()
 D=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-design')
 V=[pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-before-v'+str(i)) for i in (1,2,3)]
 root=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-root-assessment');root.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 summary=json.loads((V[2]/'summary.json').read_text());h=summary['source_hashes']
 assert summary['controls']==5 and summary['passed']==1 and summary['failed']==4
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in h.items())
 put(P/'current-hashes.json',h)
 controls={mode:json.loads((V[2]/mode/'result.json').read_text()) for mode in ['oserror','runtime','false_return','normal','class_drift']}
 assert all(row['declared_boundary_reached'] for row in controls.values())
 for mode in ['oserror','runtime','false_return','normal']:
  row=controls[mode];assert row['real_init_returned'] and row['native_wait_observed'] and type(row['native_wait_status']) is int and row['native_wait_status']==0
  assert row['before_init']['actual_instance_exact_class']
  assert row['before_init']['allocated_reference_present'] is False
  assert row['original_wait_observed'] is False and row['source_wait_marker_after_unit_cleanup'] is False
  assert all(row['constructor_arguments'].values())
 assert controls['false_return']['public_error_type']=='TypeError'
 assert controls['class_drift']['foreign_initializer_calls']==1 and controls['class_drift']['native_wait_status'] is None
 assert controls['normal']['expected_property_passed']
 assert all(not controls[mode]['expected_property_passed'] for mode in ['oserror','runtime','false_return','class_drift'])
 models={name:json.loads((D/(name+'-finish.json')).read_text()) for name in ['judge','tests','review']}
 assert all(row['direct_status']==0 and row['reaped'] for row in models.values())
 capture_source=(D/'before-v3-controller.py').read_text()
 assert capture_source.index("state['before_init']=dict")<capture_source.index("real_init(instance,*args,**kwargs)")
 assert capture_source.index("status=state['child_wait'](3)")<capture_source.index("for row in reversed(state['pipe'])")
 assert capture_source.index("pair=real_pipe()")<capture_source.index("row['identity']=identity(os.fstat(row['fd']))")
 source=(V[2]/'source/tool/native_perf_build_producer.py').read_text()
 cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CommandProducer')
 spawn=ast.get_source_segment(source,next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_spawn'))
 assert spawn.index("self.process=subprocess.Popen(")<spawn.index("attempt['process']=self.process")
 with (root/'selected-existing-spawn.txt').open('x') as out:out.write(spawn)
 plan=dict(unimplemented=True,scope='Retain exact allocated direct command Popen before fallible initializer; not actual SDK/native/RAM repair or physical closure',
  source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
  selected='Capture original class, resolved native allocator and initializer references; check current bindings before allocation/initializer. Require standard exact native object allocator, no subclass/foreign factory fallback. Retain a DISTINCT allocated_process field immediately after allocation BEFORE invoking captured initializer. Preserve attempt.process/self.process assignment only on normal constructor return. Preserve argv/cwd/stdio/close_fds/env; enforce None-only initializer result semantics before marking successful class construction.',
  schema='Record allocation/init attempt/normal-return/raw-result facts separately; retain allocated object even if uninitialized fields unknown. Extend frozen DATA schema/rows to include allocated actor, never silently discard it or quarantine every successful normal attempt. No invented status/liveness/child absence/wait authorization from allocated object.',
  public_cleanup='Original spawn repr/add_note/pipe/error/end/finish policy remains unchanged in this proposed narrow component; can mask public errors/close copies while partial actor exists. No live cleanup/retry/cancel/kill/reclose/destructor/GC discard/global-private-active-list adoption. Full physical controller still required.',
  tests='BEFORE v3 exact held source compiled in capsule AFTER declared init wrapper installed, so future captured initializer guard remains tested. Wrapper calls actual original initializer before injecting OSError/RuntimeError/False return. Source reference absence observed BEFORE real initialization and saved before unit cleanup; final pass/fail calculated later from retained booleans. After code changes, rerun new semantic controls only plus affected real factory/history callers; add matching canonical unit coverage with explicit seam migration, no fake positive Popen or weakened state assertions.',
  root_model_corrections=[
   'GLM32217 pin initializer/allocator and distinct allocated field accepted; vars(Popen)[__new__] is wrong for inherited object allocator. Local descriptor observation new_is_object_new is only current administrative DATA, not installed/loaded original-host proof.',
   'Qwen32605 wrongly describes faults as before native setup and suggests treating object as garbage. Actual original init returns normally BEFORE injected failures; preserve exact private object, never discard/reap by inference. ROOT selects original binding+current-identity guards, not automatic adoption of arbitrary current initializer.',
   'ROOT requires None-only initializer return to preserve type-call semantics. False deliberately causes native TypeError AFTER real initializer normal return; no source _execute_child failure claimed.',
   'Qwen33884 P1 pipe-boundary claim false: source _spawn creates source pipe BEFORE Popen constructor, independent of stdlib internal pipes. All v3 boundary checks pass with actual recorded creator pipe. Do not weaken/exclude class-drift guard.',
   'Qwen33884 P2 says False initializer result is allowed; false. Controlled native TypeError is intentional, existing normal case tests None. Foreign hook called1 in class-drift, real original initializer never requested by that hook; no claim no constructor hook ran.',
   'No global orphan/lost-reference/GC leak conclusion. Only CommandProducer private allocation reference is absent; other interpreter bookkeeping not inspected or adopted. Source/library bytes/type/hash facts never actual image/auth/EXrelease/admission proof.'
  ])
 put(root/'selected-plan.json',plan)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='before-and-design-complete_FIX_UNIMPLEMENTED',
  source_sha256=plan['source_sha256'],test_sha256=plan['test_sha256'],hashes=h,source_and_test_unchanged=True,
  controls=dict(v1='five setup-blocked calls: unsupported environment keyword/missing lease_check before producer body, 4FAIL1vacuousPASS/zero native child; not ownership defects',
   v2='valid kwargs but noncanonical /tmp path aliases; five before-native ProducerErrors/boundary guard refuses counts, controller status1 after all case reports; no summary. Earlier exception texts not serialized, canonical violation inferred from passed arguments/source predicate, not recovered message.',
   v3=dict(controls=5,passed=1,failed=4,actual_finite_children=4,all_actual_method_wait_statuses=[row['status'] for row in summary['actual_four_finite_children_waited']],boundary_checks_all_true=True,no_missing_API_errors=True)),
  retained_case_reports={mode:str(V[2]/mode/'result.json') for mode in controls},
  root_actual_observations='Three init-boundary negatives call REAL original initializer then inject OSError/RuntimeError/returnFalse; fourth class-rebinding negative invokes foreign hook1 BEFORE native initializer. Normal actual constructor passes exact class/argv/cwd/DEVNULL/original writer/STDOUT/close_fds/environment identity. Four actual child waits signed0 occur before unit FD/log cleanup, raw source wait markers remainFalse/null and not backfilled. Source old OSError flow itself may close parent copies earlier; child emits no stdout after closure, intentionally finite unit no original workload evidence.',
  raw_limits='Error objects private in process; saved native type/identity booleans/FD facts not serialized objects. Before reference observation is before actual initializer; failure result computed after teardown from retained facts. Actual root hook owns instance before native I/O for unit cleanup only, never backfills library. Closed original read FD has unknown/unobserved EOF, never reconstructed. Full stream/descendant/write-end/SDK/stdlib-loaded-image/original-host credential proof absent. Child interpreter not inspected for global bookkeepers. v1/v2 actual exception messages not retained, no reconstruction. Legacy CLI traceback only chat for v2 boundary assertion; controllers and all raw case files retained. Current full environment values not serialized, only argument identity booleans/declared unit delta. Actual official EX+callback here current Darwin only; no original Linux/root/perf admission.',
  models=models,model_outputs_advisory_root_qualified=True,model_fullcurrent_source_or_closure_approval=False,
  selected_plan=str(root/'selected-plan.json'),no_source_test_HEAD_Git_mutation_or_new_source_Git_query=True,
  source_HEAD_branch_orientation='last retained history-freeze postGit/contract only; no fresh source Git query in read-only before controls',
  all20_uncommitted_uncanonical_unadmitted=True,production601_unedited=True,privatecontrollers_outside_HELPERBUNDLE20=True,
  no_actual_SDK_build_native_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  remaining='Implement retained allocated-Popen helper/regressions with correct class/new/init binding and None return check; old public spawn cleanup still incomplete. Historical selected continuation/log sealing/transitive genericFD/audit unknown starts/write-end/interpreter-delegate-descendant/full physical actualofficialEX/runtime provenance/admission still required.',
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,build_floor_bytes=12*1024**3,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['popen_allocation_preparation']=dict(cache=str(P),design=str(D),before_roots=[str(x) for x in V],assessment=str(root/'assessment.json'),
  root_assessment=str(root),source_sha256=plan['source_sha256'],test_sha256=plan['test_sha256'],unimplemented=True,before_controls=5,before_actual_failures=4,before_passed=1,
  initial_setup_attempts_qualified=True,models_complete_reaped_root_qualified=True,all_known_own_model_test_calls_terminal=True,publication_pending=True,never_repeat_unchanged_before=True)
 n['last_free_bytes']=assessment['free_after'];n['popen_allocation_next_action']=plan
 v['active_turn_status']='allocated_Popen_before4FAIL1PASS_selected_fix_UNIMPLEMENTED_publication_pending'
 c.write_text(json.dumps(v,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source_unchanged=True,before=[5,4,1],actual_signed_waits=[0,0,0,0],fix_unimplemented=True,free=assessment['free_after'])))
