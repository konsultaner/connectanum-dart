import sys,pathlib,os,json,hashlib,types,time,subprocess,fcntl,errno,datetime
from unittest import mock
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
sys.dont_write_bytecode=True
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/tmp/connectanum-native-perf-popen-allocation-before-v2')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def put(path,value):
 with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
def typename(value):return type.__dict__['__name__'].__get__(type(value),type)
def identity(value):return (value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink)
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir()
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize;assert free>=1024**3
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-freeze/guards-fixed-hashes.json').read_text())
 source_dir=P/'source';source_dir.mkdir();buffers={}
 for rel,digest in expected.items():
  raw=(R/rel).read_bytes();assert sha(raw)==digest;buffers[rel]=raw
  target=source_dir/rel;target.parent.mkdir(exist_ok=True)
  with target.open('xb') as out:out.write(raw)
 put(P/'declaration.json',dict(scope='NEW BEFORE controls only; exact b21 source unchanged, finite OWN Python/Fixture, no SDK/build/canonical/kernel/capture',
  source_hashes=expected,free_bytes=free,test_floor_bytes=1024**3,all20_uncommitted_uncanonical_unadmitted=True,
  first_controller_setup_refused='v1 passed unsupported environment kwarg and omitted required lease_check; all5 before producer body/native constructor;4FAIL1vacuousPASS/zero children NOTownership defects; no missing error-message reconstruction. Distinct v2 namespace/valid env_delta/actual official lease callback.',
  constructor_seam='fresh capsule compiled under declared actual initializer wrapper; wrapper holds exact instance BEFORE real init then calls real init BEFORE injected error or False return',
  no_fake_positive_Popen=True,no_library_reference_backfill=True,private_ready_release_NOT_GO=True,
  root_actual_official_EX_through_known_children=True,old_public_pipe_cleanup_policy_unchanged=True,
  no_inference_original_SDK_kernel_defect_or_wholephysical_closure=True))
 real_class=subprocess.Popen;real_init=real_class.__init__;real_pipe=os.pipe
 cases=[];capsules=[]
 child_code=("import sys,time,json,os\nfrom pathlib import Path\n"
  "ready,gate=map(Path,sys.argv[1:])\n"
  "ready.write_text(json.dumps({'cwd':os.getcwd(),'case':os.environ.get('OWN_ALLOC_UNIT')}))\n"
  "deadline=time.monotonic()+8\n"
  "while not gate.exists() and time.monotonic()<deadline:time.sleep(.005)\n"
  "raise SystemExit(0 if gate.exists() else 78)\n")
 for index,mode in enumerate(['oserror','runtime','false_return','normal','class_drift']):
  lease.verify_identity();base=P/mode;base.mkdir();repo=base/'repo';repo.mkdir()
  ready=base/'ready.json';gate=base/'release';sentinel=base/'FORBIDDEN-next'
  argv=[sys.executable,'-c',child_code,str(ready),str(gate)]
  next_argv=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
  injected=OSError(5,'OWN injected AFTER real Popen initialization') if mode=='oserror' else RuntimeError('OWN injected AFTER real Popen initialization')
  state=dict(op=None,child=None,child_wait=None,pipe=[],before_init=None,real_init_returned=False,
   unexpected_initializations=[],foreign_calls=0,args=None,kwargs=None,public_error=None,returned=False)
  def own_pipe():
   pair=real_pipe()
   if state['op'] is not None and not state['pipe']:
    # Exact returned creator descriptors retained before metadata.
    state['pipe']=[dict(fd=fd,identity=None,access=None) for fd in pair]
    for row in state['pipe']:
     row['identity']=identity(os.fstat(row['fd']))
     row['access']=fcntl.fcntl(row['fd'],fcntl.F_GETFL)&os.O_ACCMODE
   return pair
  def initializer(instance,*args,**kwargs):
   state['child']=instance
   if len(args)!=1 or args[0]!=argv:
    state['unexpected_initializations'].append(dict(argument_count=len(args)))
    raise RuntimeError('UNDECLARED initializer refused BEFORE native Popen init')
   state['args']=args;state['kwargs']=kwargs
   op=state['op'];attempt=op._command_attempt
   state['before_init']=dict(allocated_reference_present=attempt.get('allocated_process') is instance,
    returned_process_present=attempt.get('process') is instance,source_process_present=op.process is instance,
    actual_instance_exact_class=type(instance) is real_class)
   real_init(instance,*args,**kwargs)
   state['real_init_returned']=True;state['child_wait']=instance.wait
   state['pid_after_real_init']=instance.pid
   if mode in ('oserror','runtime'):raise injected
   if mode=='false_return':return False
   return None
  def foreign_initializer(instance,*args,**kwargs):
   state['foreign_calls']+=1;state['uninitialized_instance']=instance
   raise RuntimeError('OWN foreign initializer hook BEFORE native initializer')
  name='native_perf_build_producer'
  assert name not in sys.modules
  mod=types.ModuleType(name);mod.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[name]=mod
  capsules.append(mod)
  outer_init=real_init if mode=='class_drift' else initializer
  try:
   with mock.patch.object(real_class,'__init__',new=outer_init):
    exec(compile(buffers['tool/native_perf_build_producer.py'],mod.__file__,'exec'),mod.__dict__)
    actual_event=mod.CommandProducer._event
    def event(op,event_name,**fields):
     if event_name=='command_start':state['op']=op
     return actual_event(op,event_name,**fields)
    def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
    factory_init=foreign_initializer if mode=='class_drift' else outer_init
    with mock.patch.object(mod.CommandProducer,'_source_guard',lambda op:None), \
         mock.patch.object(mod.CommandProducer,'_input_guard',lambda op:None), \
         mock.patch.object(mod.CommandProducer,'_make_archive',archive), \
         mock.patch.object(mod.CommandProducer,'_event',event), \
         mock.patch.object(real_class,'__init__',new=factory_init), \
         mock.patch.object(os,'pipe',new=own_pipe):
     try:
      environment=dict(os.environ);environment['OWN_ALLOC_UNIT']=mode
      result=mod.start_fixture(repo=repo,source_commit='a'*40,runtime_commit='a'*40,
       run_dir=base/'run',expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
       commands=[argv,next_argv],lease_check=lease.verify_identity,env_delta={'OWN_ALLOC_UNIT':mode})
      state['returned']=True
     except BaseException as error:state['public_error']=error
  finally:
   sys.modules.pop(name)
  op=state['op'];data={} if op is None else op.__dict__
  attempt=data.get('_command_attempt');attempt={} if type(attempt) is not dict else attempt
  child=state['child'];before_buffer=data.get('output_buffer')
  if type(before_buffer) is bytes:
   with (base/'original-buffer-before-unit-cleanup.bin').open('xb') as out:out.write(before_buffer)
  report=dict(mode=mode,source_sha256=expected['tool/native_perf_build_producer.py'],
   scope='actual finite Popen/unit constructor boundary, not observed original SDK/kernel failure',
   before_init=state['before_init'],real_init_returned=state['real_init_returned'],
   source_call_returned=state['returned'],foreign_initializer_calls=state['foreign_calls'],
   unexpected_initializer_calls=state['unexpected_initializations'],
   public_error_type=None if state['public_error'] is None else typename(state['public_error']),
   private_primary_is_injected=data.get('_command_history_primary_error') is injected,
   private_primary_is_public=data.get('_command_history_primary_error') is state['public_error'],
   original_attempt_retains_allocated=child is not None and attempt.get('allocated_process') is child,
   original_attempt_retains_returned=child is not None and attempt.get('process') is child,
   source_process_is_child=child is not None and data.get('process') is child,
   producer_pending=data.get('pending') if type(data.get('pending')) is bool else None,
   producer_finished=data.get('finished') if type(data.get('finished')) is bool else None,
   original_wait_observed=attempt.get('wait_observed'),
   original_wait_status=attempt.get('wait_status'),source_record_count=len(data.get('records',[])),
   source_result_is_None=data.get('result') is None,
   native_wait_status=None,native_wait_observed=False,unit_FD_cleanup=[],unit_writer_cleanup=[],
   real_class_exact=child is None or type(child) is real_class)
  if state['kwargs'] is not None:
   kw=state['kwargs']
   report['constructor_arguments']=dict(argv_exact=state['args'][0]==argv,cwd_exact=kw.get('cwd')==repo,
    stdin_DEVNULL=kw.get('stdin')==subprocess.DEVNULL,stdout_original_creator_writer=bool(state['pipe']) and kw.get('stdout')==state['pipe'][1]['fd'],
    stderr_STDOUT=kw.get('stderr')==subprocess.STDOUT,close_fds=kw.get('close_fds'),
    environment_same_object=kw.get('env') is data.get('environment'),
    declared_unit_environment=kw.get('env',{}).get('OWN_ALLOC_UNIT')==mode)
  put(base/'before-unit-cleanup.json',report)
  if state['real_init_returned']:
   end=time.monotonic()+3
   while not ready.exists() and time.monotonic()<end:time.sleep(.005)
   report['ready_observed']=ready.exists()
   if ready.exists():
    ready_raw=ready.read_bytes();report['ready_size']=len(ready_raw);report['ready_sha256']=sha(ready_raw)
    report['ready_data']=json.loads(ready_raw)
   # This is a finite fixture release directory, never a GO token.
   gate.mkdir(mode=0o700)
   status=state['child_wait'](3)
   report['native_wait_status']=status;report['native_wait_observed']=True
   assert type(status) is int
   # Exact METHOD return saved before FD/writer cleanup or source metadata.
   put(base/'actual-wait-before-FD-cleanup.json',dict(pid=child.pid,status=status,method_return_exact_int=True,
    source_wait_marker_not_reconstructed=True,not_fresh_waitsyscall_or_physicalclosure=True))
  elif child is not None:
   # A real initializer failure is outside the injected-after-normal-return fixture.
   # Preserve EX rather than infer absent child or release on partial state.
   put(base/'unexpected-native-initializer-refusal.json',dict(known_object_retained=True,status=None,
    no_invented_zero=True,physical_EX_retained=True))
   print('unexpected native initializer failure; official EX retained for independent assessment',flush=True)
   while True:time.sleep(1)
  # Retired numbers never grant close authority. These are original unit creator ends.
  for row in reversed(state['pipe']):
   fd=row['fd'];entry=dict(fd=fd,role='writer' if row['access']==os.O_WRONLY else 'reader',unit_only=True)
   try:now=os.fstat(fd)
   except OSError as error:
    entry['observed_errno']=error.errno;entry['normal_close_observed']=None
    assert error.errno==errno.EBADF
   else:
    assert identity(now)==tuple(row['identity'])
    assert fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==row['access']
    if row['access']==os.O_RDONLY:
     chunks=[];eof=False
     while True:
      raw=os.read(fd,65536)
      if not raw:eof=True;break
      chunks.append(raw)
     suffix=b''.join(chunks)
     with (base/'unit-reader-suffix.bin').open('xb') as out:out.write(suffix)
     entry.update(eof=eof,size=len(suffix),sha256=sha(suffix))
    entry['close_intent']=True
    result=os.close(fd);entry['normal_close_observed']=result is None
   report['unit_FD_cleanup'].append(entry)
  writers=[] if op is None else [data.get('log'),data.get('output_log'),data.get('events')]
  seen=[]
  for writer in writers:
   if writer is None or any(writer is item for item in seen):continue
   seen.append(writer);entry=dict(closed_before_unit_cleanup=writer.closed)
   if not writer.closed:
    fd=writer.fileno();held=os.fstat(fd);path=pathlib.Path(writer.name)
    assert identity(held)==identity(path.stat())
    entry['close_intent']=True;result=writer.close()
    entry.update(normal_close_return=result is None,closed_after=writer.closed)
   report['unit_writer_cleanup'].append(entry)
  report['source_wait_marker_after_unit_cleanup']=attempt.get('wait_observed')
  report['forbidden_next_absent']=not sentinel.exists()
  report['no_library_backfill_or_source_retag']=attempt.get('wait_observed') is False
  for path in sorted((base/'run').glob('*.log')):
   raw=path.read_bytes()
   with (base/(path.name+'.retained')).open('xb') as out:out.write(raw)
  if mode=='normal':
   passed=(state['returned'] and state['public_error'] is None and report['original_attempt_retains_returned']
    and report['source_process_is_child'] and report['native_wait_status']==0 and all(report['constructor_arguments'].values()))
  elif mode=='class_drift':passed=state['foreign_calls']==0
  else:passed=(state['before_init'] is not None and state['before_init']['allocated_reference_present']
    and report['original_attempt_retains_allocated'] and report['native_wait_status']==0)
  report['expected_property_passed']=passed
  report['declared_boundary_reached']=(op is not None and bool(state['pipe']) and (mode=='class_drift' or state['real_init_returned']))
  put(base/'result.json',report);cases.append(report)
  lease.verify_identity()
 assert all(row['declared_boundary_reached'] for row in cases),'fixture boundary not reached; do not count ownership failure'
 summary=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=expected,
  controls=len(cases),passed=sum(row['expected_property_passed'] for row in cases),
  failed=sum(not row['expected_property_passed'] for row in cases),
  no_original_SDK_native_kernel_canonical_or_benchmark=True,all20_unchanged_uncommitted_uncanonical_unadmitted=True,
  actual_four_finite_children_waited=[dict(mode=row['mode'],status=row['native_wait_status']) for row in cases if row['native_wait_observed']],
  class_drift_no_native_initializer_requested=True,raw_limits='No new original SDK/Python/delegate/descendant/FD/instruction-closure proof. Before/after error objects private; saved identity booleans/native type labels. Source old public cleanup policy unchanged. Root known unit FD/writer cleanup AFTER actual child wait, never live workaround/source status backfill; original source may have closed pipe copies before unit child exit. Current closed read FD is not reconstructed EOF. Unlisted initializer refused BEFORE native call. Exact capsule source compiled only, not current20/canonical/admission.')
 put(P/'summary.json',summary)
 for rel,digest in expected.items():assert sha((R/rel).read_bytes())==digest
 lease.verify_identity()
 print(json.dumps({key:summary[key] for key in ['controls','passed','failed','actual_four_finite_children_waited']}))
