import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py')
assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0610_STATIC_EX',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
import os,stat,datetime,shutil,base64,gzip,re
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132')
P=B/'2026-11-08-actions-include-great-great-great-grandchild-directory-inputs-v1/FIRST-local-static-binding-v1'
v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v,ensure_ascii=True,indent=2));save('controller.py',sys.argv[2])
 free=shutil.disk_usage(B).free;save('fresh-storage-floor-BEFORE-scoped-STATIC.json',json.dumps({'free_bytes':free,'floor_bytes':1073741824,'no_build_or_test_execution_authority':True},indent=2));assert free>=1073741824
 CP=B/'current-task-checkpoint.json';old=CP.read_bytes();save('checkpoint-BEFORE-STATIC-entered-PRIVATE.json',old);d=json.loads(old)
 node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_localSTATIC']={'phase':'FIRST_ENTERED_bindings_PENDING_notadmitted','directory':str(P),'native_OWNmetadata_PID':os.getpid(),'separate_outer_PID_pipeEOF':None,'all_admission_flags':False,'ownership':None}
 d['active_turn_status'].update(new_directory71_preparation='FIRST_localSTATIC_actual_NEW71_source_literals_bindings_ENTERED_NO_SDKquery',next='ONLYSAMEoriginal FIRSTlocalSTATIC session; no targetexec-eval-import-globals/source_AST_reverse_condition_codec_or_oldreader-replays/sourcepublication-dispatch-SDKquery-Source20-runtime-adoption-build-native-cleanup')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];bindings=[];outputs=[];owners=[]
 def md(fd):
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);return {k:getattr(s,k) for k in keys},s.st_atime_ns
 def read(row,point=False):
  b={'role':row['role'],'path':row['path'],'range':[0,row['bytes']],'expected_sha256':row['sha256'],'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(row['path'],os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd)
   if point:row=dict(row,bytes=b['before']['st_size']);b['range']=[0,row['bytes']]
   assert b['before']['st_size']==row['bytes'];save(row['role']+'-point-BEFORE-contentIO-PRIVATE.json',json.dumps(b,indent=2));parts=[];count=0;h=hashlib.sha256()
   while count<row['bytes']:
    block=os.read(fd,min(65536,row['bytes']-count));assert block;parts.append(block);count+=len(block);h.update(block)
   raw=b''.join(parts);b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert b['before']==b['after'] and (point or h.hexdigest()==row['sha256']);b.update(bytes=count,sha256=h.hexdigest())
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(row['role']+'-INPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  if row['decode_gzip']:
   decoded=gzip.decompress(raw);assert len(decoded)==row['decoded_bytes'] and hashlib.sha256(decoded).hexdigest()==row['decoded_sha256'] and len(decoded.decode('utf-8','strict'))==row['decoded_UTF8_characters'];return decoded
  return raw
 def write(name,raw):
  b={'name':name,'path':str(P/name),'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};outputs.append(b);fd=os.open(P/name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);b['open_return_fd']=fd;primary=None
  try:
   b['before'],b['before_atime_ns_POINT_ONLY']=md(fd);n=0
   while n<len(raw):
    sent=os.write(fd,raw[n:n+65536]);assert sent>0;n+=sent
   os.fsync(fd);os.lseek(fd,0,os.SEEK_SET);n=0;h=hashlib.sha256();readback_parts=[]
   while n<len(raw):
    block=os.read(fd,min(65536,len(raw)-n));assert block and block==raw[n:n+len(block)];readback_parts.append(block);n+=len(block);h.update(block)
   b['after'],b['after_atime_ns_POINT_ONLY']=md(fd);assert n==len(raw)==b['after']['st_size'] and h.hexdigest()==hashlib.sha256(raw).hexdigest() and (b['before']['st_dev'],b['before']['st_ino'])==(b['after']['st_dev'],b['after']['st_ino']);b.update(bytes=n,sha256=h.hexdigest(),SAMEOUTPUTFD_ALLbytes_BYTEWISE_readback=True)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(name+'-OUTPUTFD-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return {'path':str(P/name),'bytes':b['bytes'],'sha256':b['sha256']},b''.join(readback_parts)

 maprow={'role':'NEWcontrolled_region_patchmap_METADATA','path':v['patch_map_metadata']['path'],'bytes':None,'sha256':None,'decode_gzip':False}
 mapraw=read(maprow,True);patchmap=json.loads(mapraw);assert type(patchmap) is list and len(patchmap)==4
 regions=[]
 for x in patchmap:
  a,z=x['new_range'];assert type(a) is int and type(z) is int and 0<=a<=z<=79775955 and z-a==x['new_inserted_bytes']
  regions.append({'label':x['label'],'range':[a,z],'bytes':z-a,'expected_sha256':x['new_inserted_sha256'],'original_patchmap_record_UNCHANGED':x})
 save('declared-NEWcontrol-regions-BEFORE-SOURCE-contentIO-PRIVATE.json',json.dumps(regions,indent=2))
 raw_inputs={row['role']:read(row) for row in v['exact_saved_inputs']}
 source=raw_inputs['NEW71_collector_SOURCE'];workflow=raw_inputs['NEW40job_workflow_SOURCE'];scope=raw_inputs['NEW71_RAW_SOURCE_scope_noLF'];packet=raw_inputs['NEW71_encoded_runtime_metadata_packet']
 validation_raw=raw_inputs['consumed_source_validation_METADATA_ONLY'];validation=json.loads(validation_raw)
 condition_raw=raw_inputs['NEW39_SOURCEfalse_NEW40true_RAWproof_BYTEEXACT_REUSE_NOreevaluate']
 codec_raw=raw_inputs['consumed28883414event_codecproof_METADATA_ONLY_NOreexecute'];codec=json.loads(codec_raw);job=raw_inputs['NEW40job_block_source_ONLY']
 spans={}
 for region in regions:
  a,z=region['range'];raw=source[a:z];assert len(raw)==region['bytes'] and hashlib.sha256(raw).hexdigest()==region['expected_sha256'];spans[region['label']]=raw
 loaderlabel='NEW71_loader_AFTER_all_old49_63_190_199_29guards_BEFORE_INPUTIO'
 helperlabel='NEW71_helpers_AFTER_original_save_json_before_original_main'
 loader=spans[loaderlabel];helpers=spans[helperlabel];report=spans['NEW71_report_fields_separate_oldfields_unchanged']
 loader_start=next(x['range'][0] for x in regions if x['label']==loaderlabel);loader_end=next(x['range'][1] for x in regions if x['label']==loaderlabel)
 def only_literal(pattern,raw):
  hits=list(re.finditer(pattern,raw,re.M));assert len(hits)==1
  hit=hits[0];encoded=hit.group(1);assert re.fullmatch(rb'[A-Za-z0-9+/]*={0,2}',encoded)
  return base64.b64decode(encoded,validate=True),{'literal_byte_range_WITHIN_NEWloader':[hit.start(1),hit.end(1)],'literal_base64_bytes':len(encoded)}
 scope_carrier,scope_literal=only_literal(rb"^    NEW71_SOURCE_RAW = gzip\.decompress\(base64\.b64decode\('([A-Za-z0-9+/=]+)', validate=True\)\)$",loader)
 decoded_scope=gzip.decompress(scope_carrier);assert decoded_scope==scope and len(scope)==94092 and not scope.endswith(b'\n')
 scope_text=scope.decode('utf-8','strict');decoded_scope_text=decoded_scope.decode('utf-8','strict')
 assert decoded_scope_text==scope_text and json.loads(decoded_scope_text)==json.loads(scope_text)
 scope_object=json.loads(scope_text);rows=scope_object['ALL71_NEW_lexicaldirectory_TEXT_candidates'];assert len(rows)==71;refs=[]
 for i,row in enumerate(rows):
  assert row['new_directory_ordinal_ZERO_based']==i and row['query_permission'] is None and row['alias_identity'] is None
  literal=row['NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child'];assert type(literal) is str;refs.append(literal)
 scope_literal.update(decoded_bytes=len(decoded_scope),decoded_sha256=hashlib.sha256(decoded_scope).hexdigest(),whole_RAWbytes_UTF8JSONSTRING_EVERYstandardPythonfield_equal_to_bound_SOURCE=True,SOURCE_terminal_LF=False)
 assert loader.count(b'        NEW71_DIRECTORY_REFERENCES.append(original_row["NEW_lexical_candidate_TEXT_parent_plus_literal_slash_plus_saved_single_child"])')==1
 decoded_packet,packet_literal=only_literal(rb"^    NEW71_PACKET_RAW = base64\.b64decode\('([A-Za-z0-9+/=]+)', validate=True\)$",loader)
 assert decoded_packet==packet and len(packet)==33736361
 packet_literal.update(decoded_bytes=len(decoded_packet),decoded_sha256=hashlib.sha256(decoded_packet).hexdigest(),all_encoded_bytes_equal_bound_packet=True,packet_decompression_runtime_codec_reexecution=False)
 assert codec['total_ordered_events']==28883414 and codec['ALL_original_runtime_bytes_equal_reconstructed_packet_wire'] is True
 assert codec['packet']==validation['packet_encoded_INPUT'] and codec['original_runtime']==validation['runtime_original_binding']
 assert codec['ALL291_original_groupcounts_preserved']==validation['ALL291original_groupcounts_UNCHANGED']
 groups=codec['ALL291_original_groupcounts_preserved'];assert len(groups)==291 and sum(groups)==28720117
 for name,value in [('NEW71_PACKET_ROW',codec['packet']),('NEW71_RUNTIME_ROW',codec['original_runtime']),('NEW71_EXPECTED_GROUPCOUNTS',groups)]:
  assert loader.count(('    '+name+' = '+repr(value)+'\n').encode())==1
 imports=[]
 for name in ['gzip','base64','zlib','codecs']:
  positions=[x.start() for x in re.finditer(re.escape(('import '+name+'\n').encode()),helpers)];assert positions
  imports.append({'module_literal':name,'helper_relative_byte_positions':positions,'metadata_ONLY_not_loaded_delegate_effectiveABI_or_access':True})
 definitions=[]
 for name in ['NEW71_BoundedJSON','NEW71CompressedUTF8','NEW71PacketWire','NEW71_save_exact_metadata_bytes','NEW71_validate_owned_literal_history']:
  hits=list(re.finditer(rb'(?m)^(?:class|def) '+name.encode()+rb'\b',helpers));assert len(hits)==1
  definitions.append({'literal':name,'helper_relative_byte_position':hits[0].start(),'not_target_import_or_execution':True})
 assert b'        raw = value\n' in helpers and b'        assert type(value) is bytes\n' in helpers
 oldscopes=[]
 for name,count in [('PRIOR_DIRECTORY_REFERENCES',49),('PRIOR_CHILD_DIRECTORY_REFERENCES',63),('PRIOR_GRANDCHILD_DIRECTORY_REFERENCES',190),('PRIOR_GREAT_GREAT_GRANDCHILD_DIRECTORY_REFERENCES',199)]:
  token=name.encode();positions=[x.start() for x in re.finditer(rb'(?<![A-Za-z0-9_])'+token+rb'(?![A-Za-z0-9_])',source[:loader_start])];assert positions
  guards=[{'range':[x.start(),x.end()],'raw_UTF8':x.group().decode('utf-8')} for x in re.finditer(rb'(?m)^.*assert len\('+token+rb'\).*$',source[:loader_start])]
  assert guards
  oldscopes.append({'scope_literal':name,'original_declared_count_METADATA':count,'ALL_token_byte_positions_BEFORE_NEWloader':positions,'actual_lexical_assert_rows_BEFORE_NEWloader':guards,'old_scope_proof_NOTreevaluated':True})
 alias=b'    PRIOR_GREAT_GREAT_GREAT_GRANDCHILD_DIRECTORY_REFERENCES = DIRECTORY_REFERENCES\n';guard29=b'    assert len(PRIOR_GREAT_GREAT_GREAT_GRANDCHILD_DIRECTORY_REFERENCES) == 29\n'
 assert loader.count(alias)==1 and loader.count(guard29)==1 and loader.index(alias)<loader.index(guard29)
 guard29rows=[{'range':[x.start(),x.end()],'raw_UTF8':x.group().decode('utf-8')} for x in re.finditer(rb'(?m)^.*assert.*len\(DIRECTORY_REFERENCES\) == 29.*$',source[:loader_start])];assert guard29rows
 input_token=b'    for ordinal, reference in enumerate(DIRECTORY_REFERENCES):';input_positions=[x.start() for x in re.finditer(re.escape(input_token),source)]
 assert len(input_positions)==1 and input_positions[0]>loader_end
 order_tokens=[
 b'    NEW71_scope_written = NEW71_save_exact_metadata_bytes("NEW71-scope-before-INPUT-IO.json", NEW71_SOURCE_RAW)',
 b'    NEW71_packet_written = NEW71_save_exact_metadata_bytes("NEW71-exact-wire-fragment-packet-original.json.gz", NEW71_PACKET_RAW)',
 b'    NEW71_history_before_INPUTIO = NEW71_validate_owned_literal_history(NEW71_PACKET_ROW, NEW71_RUNTIME_ROW, NEW71_DIRECTORY_REFERENCES, NEW71_EXPECTED_GROUPCOUNTS)',
 b'    NEW71_history_written = save_json("NEW71-actual-runtime-metadata-guard-before-INPUT-IO.json", NEW71_history_before_INPUTIO)',
 b'    DIRECTORY_REFERENCES = NEW71_DIRECTORY_REFERENCES']
 order=[]
 for token in order_tokens:
  assert loader.count(token)==1;order.append({'literal':token.decode(),'absolute_source_byte_position':loader_start+loader.index(token)})
 assert [x['absolute_source_byte_position'] for x in order]==sorted(x['absolute_source_byte_position'] for x in order)
 assert b'assert NEW71_scope_written["bytes"] == 94092 and NEW71_scope_written["sha256"] == "0556b6dd4da02409b69528e1647c93b8e80e9a01cad4d5ae7b078c98cb4fcf36"' in loader
 reportkeys=[hit.group(1).decode() for hit in re.finditer(rb'(?m)^        "(NEW71_[^"]+)":',report)];assert len(reportkeys)==11
 assert workflow.endswith(job) and len(workflow)<500000 and len(workflow)<512000
 campaign='flatbuffers_include_great_great_great_grandchild_directory71_inputs';collectorref='.github/collectors/pr132_include_great_great_great_grandchild_directory71_inputs.py'
 uploader=chr(36)+'{{ runner.temp }}/native-perf-include-great-great-great-grandchild-directory71-inputs'
 assert ('          - '+campaign+'\n').encode() in workflow
 assert ('python3 - < '+collectorref).encode() in job and uploader.encode() in job
 for token in [b'runs-on: ubuntu-24.04',b'sdk: 3.13.5',b'RUSTUP_TOOLCHAIN: 1.99.0',b'uses: dtolnay/rust-toolchain@1.99.0',b'uses: actions/upload-artifact@v7']:assert token in job
 newroot=b'OUT = pathlib.Path(os.environ["RUNNER_TEMP"]) / "native-perf-include-great-great-great-grandchild-directory71-inputs"';assert spans['NEW71_unique_OWN_output_namespace']==newroot
 assert validation['new39SOURCEconditions_status_UNPERFORMED'] is None and validation['new40jobSOURCEguard_status_UNPERFORMED'] is None and validation['localSTATIC_runtime_preproof_status_UNPERFORMED'] is None
 assert all(x['close_return_fd']==x['open_return_fd'] for x in bindings)

 runtime_preproof={k:None for k in ['workflow_revision','run_id','observations','collector_credentials','collector_cwd','collector_argv','collector_interpreter_reference','directory_SOURCE_INPUT_opens','directory_SOURCE_INPUT_entrymetadata','remaining_known_input_output_FDs']}
 facts={'phase':'FIRST_NEW71_localSTATIC_BINDINGS_PASS_NO_TARGET_EXEC_SDKquery_Actions_NOTadmitted',
 'declaration':v,'input_bindings_ALLfields_PRIVATE':bindings,'declared_NEWcontrol_regions':regions,
 'actual_scope_literal_binding':scope_literal,'actual_packet_literal_binding':packet_literal,
 'ALL71_saved_literal_refs_nativeorder_duplicates_UNCHANGED':refs,'new_reference_count':len(refs),
 'imports_METADATA_ONLY':imports,'helper_definition_locations_ONLY':definitions,
 'old_scope_lexical_locations_NOTproof_replay':oldscopes,'original29_lexical_guards_BEFORE_NEWloader':guard29rows,
 'original29_preserving_alias_BEFORE_override':True,'new_loader_range':[loader_start,loader_end],
 'new_loader_metadata_order_BEFORE_INPUT_IO':order,'original_directory_INPUTloop_positions':input_positions,
 'RAWscope_output_source_bytes':94092,'RAWscope_output_source_sha256':hashlib.sha256(scope).hexdigest(),
 'RAWscope_no_terminalLF_preserved':True,'original_save_json_BYTEEXACT_preservation_consumedproof_REUSEONLY':True,
 'new_report71_keys':reportkeys,'new_report71_field_count':len(reportkeys),
 'new_job_collector_ref':collectorref,'new_job_uploader_ref':uploader,'new_campaign_literal':campaign,
 'new_workflow_bytes':len(workflow),'workflow_bounds_500000_512000_PASS':True,
 'original265291183_parent5a187768_Linux_Dart_recipe_labels_preserved_NOTadmitted':True,
 'new39SOURCEfalse_new40true_raw_proof_BYTEEXACT_REUSED_NOreevaluation':True,
 'original_parsed_jobs33_STALE_inheritedall199label_UNMODIFIED':True,
 'old_source_AST_reverse_Ruby_source_condition_codec_whole9GB_proof_bodies_NOTreplayed':True,
 'actual_new39_job_SKIPs_UNMEASURED':None,'original_static_and_sourcevalidation_NULLs_immutable_NEWfacts_SEPARATE':True,
 'runtime_preproof_UNMEASURED_NULLS_immutable_at_THIS_STATIC_point':runtime_preproof,
 'declared_input_FDs_closed_POINT_NOTglobal_actor_closure':True,'ALL71_SDKdirectories_DEFERRED_at_THIS_STATIC_point':True,
 'readlink_counts_matchlists_nonmatchlists_UNPERFORMED_NULL_not0':True,'alias_identity':None,'query_permission':None,
 'no_targetexec_eval_import_globals_SDKbody_header_directory_query_Actions_sourcecommit_push_Source20_runtime_build_native_adoption_cleanup':True,
 'pointFD_stat_countSHA_close_readback_NOTatomicABA_originaldrivercredentials_access_effectiveABI_continuousphysicalEX_crash_admission':True,
 'all_admission_flags':False,'ownership':None}
 raw=(json.dumps(facts,ensure_ascii=True,indent=2)[:-1]+',\n"original_SOURCE_JSON_value_verbatim":').encode()+scope+b',\n"original_source_validation_JSON_value_verbatim":'+validation_raw+b',\n"original_NEW39condition_JSON_value_verbatim_REUSED_NOTreevaluated":'+condition_raw+b',\n"original_codecproof_JSON_value_verbatim_REUSED_NOTreexecuted":'+codec_raw+b',\n"original_patchmap_JSON_value_verbatim":'+mapraw+b'\n}'
 result,readback=write('FIRST-NEW71-localSTATIC-result-PRIVATE.json',raw)
 copy,copyback=write('FIRST-NEW71-localSTATIC-whole-copy-PRIVATE.json',readback)
 assert raw==readback==copyback
 text0=raw.decode('utf-8','strict');text1=copyback.decode('utf-8','strict');assert text0==text1 and json.loads(text0)==json.loads(text1)
 class ObjectPairs(list):pass
 def events(x):
  if isinstance(x,ObjectPairs):
   yield ('object_start',None)
   for k,value in x:yield ('key',k);yield from events(value)
   yield ('object_end',None)
  elif type(x) is list:
   yield ('array_start',None)
   for value in x:yield from events(value)
   yield ('array_end',None)
  else:yield ('atom_'+type(x).__name__,x)
 p0=json.loads(text0,object_pairs_hook=ObjectPairs);p1=json.loads(text1,object_pairs_hook=ObjectPairs);counts={};total=0
 from itertools import zip_longest
 missing=object()
 for a,b in zip_longest(events(p0),events(p1),fillvalue=missing):
  assert a is not missing and b is not missing and a==b
  counts[a[0]]=counts.get(a[0],0)+1;total+=1
 proof={'result':result,'whole_private_copy':copy,'whole_RAWbytes_UTF8JSONSTRING_characters_equal':True,
 'EVERY_standardPython_field_exhaustive_ordered_structure_duplicatekeys_arraypositions_typedleaves_equal':True,
 'ordered_event_counts':counts,'total_ordered_events':total,'UTF8_JSONSTRING_characters':len(text0),
 'all_original_private_fields_stat_times_FDcredentials_relationships_NULLs_UNCHANGED':True,
 'no_public_projection_yet_no_oldproof_or_oracle_replay':True,'all_admission_flags':False,'ownership':None}
 proofrow,_=write('FIRST-NEW71-localSTATIC-whole-ALLfield-proof.json',json.dumps(proof,ensure_ascii=True,indent=2).encode())
 assert all(x['close_return_fd']==x['open_return_fd'] for x in bindings+outputs)
 descriptor={'phase':facts['phase'],'directory':str(P),'result':result,'proof':proofrow,'inputs':len(bindings),'newcontrol_regions':len(regions),
 'new_refs':len(refs),'imports_metadata_only':len(imports),'report_fields_NEW71':len(reportkeys),
 'condition_proof_reused_bytes':len(condition_raw),'condition_proof_reused_sha256':hashlib.sha256(condition_raw).hexdigest(),
 'runtime_preproof_UNMEASURED_NULLs':runtime_preproof,'sourcecommit':None,'run_id':None,'all_admission_flags':False,'ownership':None}
 save('FIRST-NEW71-localSTATIC-completion-descriptor.json',json.dumps(descriptor,ensure_ascii=True,indent=2))
 old=CP.read_bytes();save('checkpoint-BEFORE-STATIC-completion-PRIVATE.json',old);d=json.loads(old);node=d['actions_include_great_great_great_grandchild_directory71_preparation_v1']
 node['FIRST_localSTATIC']=descriptor;node['phase']='FIRST_NEW71_localSTATIC_BINDINGS_PASS_NO_ACTIONSsource_publication_dispatch_SDKquery_NOTadmitted'
 d['active_turn_status'].update(new_directory71_preparation='FIRSTlocalSTATIC_complete9bindings4regions71refs11NEWreportfields_NOquery_NOTadmitted',next='FIRST publication of NEWlocalSTATIC evidence or expresslydeclared FIRSTremaining originalActions sourcepublication/preflight tail with both FULLGitblobJSON decoded BYTEEXACT readbacks before dispatch. No oldAST-reverse-sourcecondition-codec-whole9GB-model-SDK-Actions-acquisition-proof replay; no Source20-runtimeadoption-build-native-numerical-cleanup/allsetupUNADMITTED.')
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];CP.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(descriptor,ensure_ascii=True),flush=True)
