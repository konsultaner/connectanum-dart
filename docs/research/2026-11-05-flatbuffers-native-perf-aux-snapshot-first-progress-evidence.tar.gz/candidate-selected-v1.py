_AUX_FINALIZATION_GROUPS={}

def _aux_finalization_group(owner):
    previous=_AUX_FINALIZATION_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('auxiliary finalization owner mismatch')
        previous[1]()
        return previous
    primary=[None];secondary=[]
    def guard():
        if primary[0] is not None:raise primary[0]
    def retain(error):
        if primary[0] is None:primary[0]=error
        return primary[0]
    group=(owner,guard,retain,secondary)
    _AUX_FINALIZATION_GROUPS[id(owner)]=group
    return group

def _aux_finalization_guard(owner):
    previous=_AUX_FINALIZATION_GROUPS.get(id(owner))
    if previous is not None:
        if previous[0] is not owner:raise ProducerError('auxiliary finalization owner mismatch')
        previous[1]()


def _complete(self):
        _aux_finalization_guard(self)
        self._constructor_guard()
        try:self._intent_call_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._init_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._start_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._wait_lease_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._select_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._stream_read_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._direct_wait_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._status_poll_guard(whole=True)
        except BaseException as error:self._defer(error)
        try:self._buffer_write_guard(whole=True)
        except BaseException as error:self._defer(error)
        binding=self._finalization_binding;state=binding[0]
        if state['attempted']:raise ProducerError('auxiliary finalization attempt is permanently terminal')
        state['attempted']=True
        try:
            if (self._natural_wait_observed is not True or type(self._natural_wait_status) is not int
                or self._natural_wait_process is not self.process or type(self.status) is not int
                or self.status!=self._natural_wait_status):
                raise ProducerError('actual same auxiliary method wait required before finalization')
            constructor=binding[2];resources=constructor[0].get('streams')
            if type(resources) is not tuple or len(resources)!=2:
                raise ProducerError('original auxiliary finalization writers required')
            output={}
            for index,role in enumerate(('stdout','stderr')):
                stream=constructor[3+index];original=resources[index]
                if (type(original) is not tuple or len(original)!=5 or original[1] is not stream
                    or type(stream) is not dict or any(type(key) is not str for key in stream)
                    or self.streams.get(role) is not stream or stream.get('eof') is not True
                    or type(stream.get('buffer')) is not bytes or stream['buffer']
                    or stream.get('fd') is not None or stream.get('writer') is not None
                    or stream.get('write_close_confirmed') is not True or stream.get('quarantined') is not False
                    or stream.get('log') is not original[2]):
                    raise ProducerError('known auxiliary EOF/empty buffers/original writer required')
                for slot in ('fd','writer'):
                    if not any(row.get('stream') is stream and row.get('slot')==slot
                        and row.get('attempted') is True and row.get('returned') is True
                        and row.get('raw_return') is None and row.get('result_valid') is True
                        and row.get('completed') is True for row in binding[3][1]):
                        raise ProducerError('known creator close return required before writer finalization')
                log=original[2]
                self._finalization_step(binding,'flush',role,log,None,lambda:log.flush())
                fd=self._finalization_step(binding,'fileno',role,log,None,lambda:log.fileno())
                self._finalization_step(binding,'fsync',role,log,fd,lambda:os.fsync(fd))
                self._finalization_step(binding,'close',role,log,fd,lambda:log.close())
                stream['log']=None
                item={'eof':stream['eof'],'stream_bytes':stream['bytes'],'stream_sha256':stream['hash'].hexdigest(),
                    'parent_write_close_confirmed':stream['write_close_confirmed'],'quarantined':stream['quarantined']}
                item['snapshot']=self._finalization_step(binding,'snapshot',role,log,None,
                    lambda:_file_snapshot(stream['path'],stream['maximum']))
                item['snapshot_matches_stream']=item['snapshot']=={'size':stream['bytes'],'sha256':stream['hash'].hexdigest()}
                if not item['snapshot_matches_stream']:raise ProducerError('auxiliary log bytes changed: '+role)
                output[role]=item
            okay=(self.error is None and self.spawn_error is None and self.status==0
                and all(s['eof'] and s['write_close_confirmed'] for s in self.streams.values()))
            result={'kind':'auxiliary-command-observation-v1','scope':'owned_direct_child_and_two_output_streams_only',
                'capture_ready':False,'whole_descendant_exit_proven':False,'intent_sha256':self.intent_sha256,
                'argv':list(self.argv),'cwd':str(self.cwd),'pid':None if self.process is None else self.process.pid,
                'returncode':self.status,'spawn_error':self.spawn_error,'status':'success' if okay else 'failed',
                'primary_error':self.error,'secondary_errors':self.secondary_errors,'outputs':output}
            if self.status is not None and self.status!=0 and result['primary_error'] is None:result['primary_error']='auxiliary command nonzero or signal'
            state['candidate_result']=result;self.publication_attempted=True
            self._finalization_step(binding,'result',None,None,None,
                lambda:_write_json(self.directory/(self.name+'-result.json'),result))
            self.result=result;self.pending=False;self.finished=True;state['completed']=True
            return result
        except BaseException as error:
            _aux_finalization_guard(self)
            self._retain_finalization_error(binding,None,error)
            raise self._finalization_primary_error

def _finalization_guard(self):
        _aux_finalization_guard(self)
        first=self._finalization_error()
        if first is not None:raise first
        binding=self._finalization_binding
        if type(binding) is not tuple or len(binding)!=5:
            raise ProducerError('auxiliary finalization binding changed')
        state,journal,constructor,creator,secondary=binding
        if (self._finalization_primary_error is not None or type(state) is not dict
            or any(type(key) is not str for key in state)
            or set(state)!={'attempted','completed','first_error','quarantined','current','candidate_result'}
            or state is not self._finalization_state or type(state['attempted']) is not bool
            or type(state['completed']) is not bool or state['first_error'] is not None
            or state['quarantined'] is not False or self._finalization_quarantined is not False
            or type(journal) is not list or journal is not self._finalization_journal
            or constructor is not self._constructor_quarantine_binding or creator is not self._creator_close_binding
            or type(secondary) is not list or secondary is not self._finalization_secondary_errors):
            raise ProducerError('auxiliary finalization state changed')
        required={'stage','role','log','fd','process','candidate_result','attempted','returned','raw_return','result_valid','completed','error'}
        for row in journal:
            if (type(row) is not dict or any(type(key) is not str for key in row) or set(row)!=required
                or type(row['stage']) is not str or row['stage'] not in ('flush','fileno','fsync','close','snapshot','result')
                or row['attempted'] is not True or row['returned'] is not True
                or row['result_valid'] is not True or row['completed'] is not True or row['error'] is not None
                or row['process'] is not constructor[0].get('allocated_process')):
                raise ProducerError('auxiliary finalization operation unknown')
            if row['stage']=='result':
                if row['role'] is not None or row['candidate_result'] is not state['candidate_result']:
                    raise ProducerError('auxiliary finalization result binding changed')
            elif type(row['role']) is not str or row['role'] not in ('stdout','stderr'):
                raise ProducerError('auxiliary finalization role changed')
        if ((journal and state['current'] is not journal[-1]) or (not journal and state['current'] is not None)):
            raise ProducerError('auxiliary finalization current operation changed')

def _finalization_step(self,binding,stage,role,log,fd,action):
        group=_aux_finalization_group(self);retain=group[2]
        self._constructor_guard()
        if self._finalization_binding is not binding:raise ProducerError('original auxiliary finalization required')
        row=dict(stage=stage,role=role,log=log,fd=fd,process=self.process,candidate_result=binding[0]['candidate_result'],
            attempted=True,returned=None,raw_return=None,result_valid=None,completed=False,error=None)
        binding[0]['current']=row;list.append(binding[1],row)
        try:
            value=action();row['raw_return']=value;row['returned']=True
            if stage=='fileno':valid=type(value) is int and value>=0
            elif stage=='snapshot':
                valid=(type(value) is dict and all(type(key) is str for key in value)
                    and set(value)=={'size','sha256'} and type(value['size']) is int and value['size']>=0
                    and type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None)
            else:valid=value is None
            row['result_valid']=valid
            if not valid:raise TypeError('auxiliary finalization native return invalid')
            # Preserve actual returns before all post-call binding metadata.
            self._startup_guard();self._creator_close_guard()
            if (self._finalization_binding is not binding or binding[0] is not self._finalization_state
                or binding[1] is not self._finalization_journal or binding[4] is not self._finalization_secondary_errors
                or self.process is not row['process']):
                raise ProducerError('auxiliary finalization binding changed after operation')
            if role is not None:
                stream=binding[2][3 if role=='stdout' else 4]
                expected=None if stage=='snapshot' else log
                if self.streams.get(role) is not stream or stream.get('log') is not expected:
                    raise ProducerError('auxiliary finalization writer binding changed')
            row['completed']=True
            return value
        except BaseException as error:
            primary=retain(error)
            try:self._retain_finalization_error(binding,row,error)
            except BaseException as secondary:list.append(group[3],secondary)
            finally:raise primary