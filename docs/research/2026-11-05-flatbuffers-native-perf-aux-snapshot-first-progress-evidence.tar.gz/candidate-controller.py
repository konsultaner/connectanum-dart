import sys,pathlib,json,hashlib,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();before=(P/'before-producer.py').read_text();tree=ast.parse(before);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 helper="_AUX_FINALIZATION_GROUPS={}\n\ndef _aux_finalization_group(owner):\n    previous=_AUX_FINALIZATION_GROUPS.get(id(owner))\n    if previous is not None:\n        if previous[0] is not owner:raise ProducerError('auxiliary finalization owner mismatch')\n        previous[1]()\n        return previous\n    primary=[None];secondary=[]\n    def guard():\n        if primary[0] is not None:raise primary[0]\n    def retain(error):\n        if primary[0] is None:primary[0]=error\n        return primary[0]\n    group=(owner,guard,retain,secondary)\n    _AUX_FINALIZATION_GROUPS[id(owner)]=group\n    return group\n\ndef _aux_finalization_guard(owner):\n    previous=_AUX_FINALIZATION_GROUPS.get(id(owner))\n    if previous is not None:\n        if previous[0] is not owner:raise ProducerError('auxiliary finalization owner mismatch')\n        previous[1]()\n\n\n";start=sum(len(x) for x in before.splitlines(True)[:min([cls.lineno]+[x.lineno for x in cls.decorator_list])-1]);candidate=before[:start]+helper+before[start:]
 parts=[]
 for name in ('_complete','_finalization_guard','_finalization_step'):
  node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name==name);old=ast.get_source_segment(before,node);new=old
  if name in ('_complete','_finalization_guard'):
   header=old.splitlines(True)[0];new=new.replace(header,header+'        _aux_finalization_guard(self)\n',1)
  if name=='_complete':
   prior="""        except BaseException as error:
            self._retain_finalization_error(binding,None,error)
            raise self._finalization_primary_error"""
   replacement="""        except BaseException as error:
            _aux_finalization_guard(self)
            self._retain_finalization_error(binding,None,error)
            raise self._finalization_primary_error"""
   assert new.count(prior)==1;new=new.replace(prior,replacement,1)
  if name=='_finalization_step':
   header=old.splitlines(True)[0];new=new.replace(header,header+'        group=_aux_finalization_group(self);retain=group[2]\n',1)
   prior="""        except BaseException as error:
            self._retain_finalization_error(binding,row,error)
            raise self._finalization_primary_error"""
   replacement="""        except BaseException as error:
            primary=retain(error)
            try:self._retain_finalization_error(binding,row,error)
            except BaseException as secondary:list.append(group[3],secondary)
            finally:raise primary"""
   assert new.count(prior)==1;new=new.replace(prior,replacement,1)
  assert candidate.count(old)==1;candidate=candidate.replace(old,new,1);parts.append(dict(symbol=name,old=old,new=new))
 ast.parse(candidate);back=candidate
 for part in reversed(parts):back=back.replace(part['new'],part['old'],1)
 assert back.count(helper)==1;back=back.replace(helper,'',1);assert back==before
 (P/'candidate-producer-v1.py').open('x').write(candidate);(P/'projection-parts-v1.json').open('x').write(json.dumps(dict(helper=helper,methods=parts),indent=2))
 (P/'candidate-selected-v1.py').open('x').write(helper+'\n\n'.join(x['new'] for x in parts))
 proof=dict(wholeSource_BYTE_projectsback=True,all_other_existing_methods_helpers_classes_factories_frozenpredicates_exact=True,old_finalization_guard_predicates_exact_after_prefix_removal=True,oldtests_PREFIX_exact=True,new_private_owner_strong_group_processlife_no_pop_reset_evict=True,Source_first_captured_BEFORE_secondary_metadata=True,Scope_only_finalizationStep_first_capture_and_guard_prefixes=True,early_complete_metadata_before_firststep_calleeinterior_globalbindings_ABA_incomplete=True)
 (P/'candidate-ROOT-projection.json').open('x').write(json.dumps(proof,indent=2));(P/'candidate.diff').open('x').write(''.join(difflib.unified_diff(before.splitlines(True),candidate.splitlines(True),fromfile='before',tofile='candidate')))
 views=[json.loads(f.read_text()) for f in (P/'before-units/fixtures').glob('*/view-before-ROOT-cleanup.json')]
 print(json.dumps([dict(mode=v['mode'],received_First=v['received_First'],received_Secondary=v['received_Secondary'],primary_field_First=v['primary_field_First'],primary_field_Secondary=v['primary_field_Secondary'],snapshots=v['snapshot_ctor_calls'],registry_delta=v['Source_snapshot_registry_delta'],eof=v['both_eof'],status=v['natural_wait_status'],journal_last=v['journal'][-1]) for v in views],indent=2));l.verify_identity();print((P/'candidate.diff').read_text())
