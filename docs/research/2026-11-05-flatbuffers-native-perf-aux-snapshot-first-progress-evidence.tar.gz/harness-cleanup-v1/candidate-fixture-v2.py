class AuxiliaryNaturalWaitWitnessTests(unittest.TestCase):
    """Finite direct method witnesses; never actor/descendant/EX admission."""
    def setUp(self):
        import time
        self.time=time;self.base=Path(tempfile.mkdtemp(prefix='aux-wait-witness-',
            dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.actors=[];self.gates=[];self.sequence=0;self.saved=0;self.malformed=[]
        self.root_actors=[];self.root_cleanup_attempted=False

    def start(self,code=0,close_early=False):
        self.sequence+=1;label='aux-'+str(self.sequence)
        directory=self.base/label;directory.mkdir();ready=self.base/(label+'-ready');gate=self.base/(label+'-release')
        self.gates.append(gate)
        script=("import os,sys,time\nfrom pathlib import Path\n"
                "ready,gate=map(Path,sys.argv[1:3]);status=int(sys.argv[3]);early=sys.argv[4]=='yes'\n"
                "if early:os.close(1);os.close(2)\n"
                "else:os.write(1,b'OWN-witness-out\\n');os.write(2,b'OWN-witness-err\\n')\n"
                "ready.write_text('ready');end=time.monotonic()+10\n"
                "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
                "raise SystemExit(status if gate.exists() else 78)\n")
        op=producer.AuxiliaryCommand(directory=directory,name='witness',argv=[sys.executable,'-c',script,
            str(ready),str(gate),str(code),'yes' if close_early else 'no'],cwd=self.base,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=65536,stderr_max=65536)
        self.actors.append((op,code))
        root=dict(op=op,code=code,gate=gate,directory=directory,process=None,wait=None,logs=[],pipes=[])
        self.root_actors.append(root) # Before start and fallible native I/O.
        native_os=producer.os;native_open=Path.open;allocate=producer.AuxiliaryCommand._allocate_process
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def pipe(self):
                row=dict(attempted=True,returned=False,fds=None,identities=None);root['pipes'].append(row)
                value=native_os.pipe();row['fds']=value;row['returned']=True
                row['identities']=[(native_os.fstat(fd).st_dev,native_os.fstat(fd).st_ino) for fd in value];return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            if path in (directory/'witness.stdout',directory/'witness.stderr'):
                row=dict(object=value,close=value.close,path=path,fd=None,identity=None);root['logs'].append(row)
                row['fd']=value.fileno();info=native_os.fstat(row['fd']);row['identity']=(info.st_dev,info.st_ino)
            return value
        def allocating(current,record):
            value=allocate(current,record)
            root.update(process=value,wait=value.wait,pid=value.pid) # Actual returned object before Source publication.
            return value
        with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(Path,'open',opening),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocating):
            op.start()
        end=self.time.monotonic()+3
        while not ready.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(ready.exists());return op,gate

    def release(self,gate):
        if not gate.exists():
            with gate.open('x') as f:f.write('OWN finite release, NOT GO\n')

    def state(self,label,op):
        self.saved+=1
        row=dict(pid=op.process.pid,cached_Popen_returncode=op.process.returncode,status=op.status,pending=op.pending,
            finished=op.finished,stdout_eof=op.streams['stdout']['eof'],stderr_eof=op.streams['stderr']['eof'],
            wait_observed=getattr(op,'_natural_wait_observed',None),wait_status=getattr(op,'_natural_wait_status',None),
            wait_process_bound=getattr(op,'_natural_wait_process',None) is op.process,
            whole_actor_ownership_complete=None,capture_ready=False)
        with (self.base/(str(self.saved)+'-'+label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def complete(self,op):
        for _ in range(15):
            result=op.wait(1)
            if result is not None:return result
        self.fail('known finite auxiliary did not complete')

    def poll_exit(self,op):
        end=self.time.monotonic()+3
        while op.status is None and self.time.monotonic()<end:
            op._observe_status()
            if op.status is None:self.time.sleep(.005)
        self.assertIs(type(op.status),int)

    def test_actual_wait_witness_survives_prebody_complete_error(self):
        op,gate=self.start();self.release(gate);fault=OSError(5,'OWN complete prebody failure after actual wait')
        with mock.patch.object(op,'_complete',side_effect=fault):
            with self.assertRaises(OSError) as caught:self.complete(op)
        self.assertIs(caught.exception,fault);row=self.state('after-complete-error-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertTrue(row['pending']);self.assertFalse(row['finished'])
        self.assertIsNone(op.result)

    def test_poll_cached_zero_is_not_wait_method_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op)
        self.state('poll-only-zero-before-fixture-cleanup',op)
        self.assertEqual(0,op.status);self.assertEqual(0,op.process.returncode)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)
        self.assertIsNone(op._natural_wait_process)

    def test_wait_timeout_retains_exact_process_then_same_actor_completion(self):
        op,gate=self.start(close_early=True);process=op.process
        self.assertIsNone(op.wait(.02));self.state('after-real-wait-timeout',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)
        self.assertIsNone(op._natural_wait_status);self.assertTrue(op.pending);self.assertFalse(op.finished)
        self.release(gate);result=self.complete(op);self.state('same-process-natural-completion',op)
        self.assertIs(op.process,process);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)

    def test_normal_completion_records_exact_process_and_signed_zero(self):
        op,gate=self.start();self.release(gate);result=self.complete(op)
        self.state('normal-completion',op)
        self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_natural_nonzero_is_retained_not_invented_zero(self):
        op,gate=self.start(code=78);self.release(gate);result=self.complete(op)
        self.state('natural-nonzero',op)
        self.assertEqual('failed',result['status']);self.assertEqual(78,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(78,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process)

    def test_boolean_wait_return_refuses_without_false_zero_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op);caught=None;self.malformed.append(op)
        with mock.patch.object(op.process,'wait',return_value=False):
            try:self.complete(op)
            except producer.ProducerError as error:caught=error
        self.state('malformed-bool-method-return-before-fixture-cleanup',op)
        self.assertIsNotNone(caught)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)

    def test_process_drift_after_timeout_refuses_second_actor_wait(self):
        op,gate=self.start(close_early=True);other,other_gate=self.start(close_early=True)
        process=op.process;self.assertIsNone(op.wait(.02))
        op.process=other.process
        with self.assertRaises(producer.ProducerError):op._wait_natural_status(0)
        # Keep Source drift visible; ROOT owns the original actor independently.
        self.state('foreign-process-refused-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)

    def tearDown(self):
        # Terminal ROOT fixture cleanup; never call Source.wait or trust Source fields.
        if self.root_cleanup_attempted:raise RuntimeError('ROOT fixture cleanup is permanently terminal')
        self.root_cleanup_attempted=True
        receipts=[];errors=[]
        for gate in self.gates:
            try:self.release(gate)
            except BaseException as error:errors.append(error)
        for index,root in enumerate(self.root_actors):
            receipt=dict(pid=root.get('pid'),status=None,expected_status=root['code'],readers=[],pipes=[],logs=[],
                Source_wait_called=False,Source_fields_not_restored=True,unit_only_not_live_ownership_EX_originalLinux_allactorclosure=True)
            try:
                if root['wait'] is None:raise RuntimeError('ROOT actual returned Popen handle unknown')
                status=root['wait'](10);receipt.update(status=status,cached_possible=True)
                for number,pipe in enumerate(root['pipes']):
                    if not pipe['returned'] or pipe['identities'] is None:
                        receipt['pipes'].append(dict(known_creator_return=False,closure_unknown=True));continue
                    for end,(fd,identity) in enumerate(zip(pipe['fds'],pipe['identities'])):
                        item=dict(fd=fd,end=end,same_original_identity=False,errno=None)
                        try:
                            info=os.fstat(fd);item['same_original_identity']=(info.st_dev,info.st_ino)==tuple(identity)
                            if item['same_original_identity'] and end==0:
                                item['nonblocking']=os.get_blocking(fd) is False
                                if not item['nonblocking']:raise RuntimeError('ROOT reader mode differs; no blocking read or flag reset')
                                data=os.read(fd,65536);tail=os.read(fd,1);raw=data+tail
                                name='root-actor-'+str(index)+'-pipe-'+str(number)+'-raw.bin'
                                with (self.base/name).open('xb') as out:out.write(raw)
                                receipt['readers'].append(dict(fd=fd,size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),EOF=tail==b'',raw=name,partial_if_no_EOF=True))
                        except OSError as error:item['errno']=error.errno
                        receipt['pipes'].append(item)
                receipt['logs']=[dict(fd=x['fd'],path=str(x['path']),closed=x['object'].closed,identity=x['identity']) for x in root['logs']]
                with (self.base/('root-actor-'+str(index)+'-before-close.json')).open('x') as out:json.dump(receipt,out,indent=2)
                # Evidence exists before known original FD/FileIO closure; no borrowed FD recovery.
                for pipe in root['pipes']:
                    if pipe['returned'] and pipe['identities'] is not None:
                        for fd,identity in zip(pipe['fds'],pipe['identities']):
                            try:
                                info=os.fstat(fd)
                                if (info.st_dev,info.st_ino)==tuple(identity):os.close(fd)
                            except OSError as error:
                                if error.errno!=9:raise
                for entry in root['logs']:
                    if not entry['object'].closed:
                        info=os.fstat(entry['fd']);path=entry['path'].stat()
                        if (info.st_dev,info.st_ino)==entry['identity']==(path.st_dev,path.st_ino):entry['close']()
            except BaseException as error:
                errors.append(error);receipt['ROOT_error_type']=type(error).__name__;receipt['closure_unknown']=True
            receipts.append(receipt)
        # Collect every known actor before summary/assertions; unknown status remains None.
        try:
            with (self.base/'root-known-actors.json').open('x') as out:json.dump(receipts,out,indent=2)
        except BaseException as error:errors.append(error)
        if errors:raise errors[0]
        for row in receipts:
            self.assertIs(type(row['status']),int);self.assertEqual(row['expected_status'],row['status'])
            self.assertTrue(all(x['EOF'] for x in row['readers']))

