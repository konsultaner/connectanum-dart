import sys,pathlib,json,hashlib,ast,os,types,unittest,io,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1/harness-cleanup-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items());free=shutil.disk_usage(R).free;assert free>=1024**3
 q=P/'after-NEW3';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir();os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tests=(R/'tool/test_native_perf_build_producer.py').read_bytes();tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 cls=tm.NaturalWaitCleanupScopeTests;names=unittest.defaultTestLoader.getTestCaseNames(cls);assert len(names)==3
 (q/'declaration.json').open('x').write(json.dumps(dict(free_bytes=free,selection=names,ONLYmatchingNEW3=True,no_old27_or2oldbody_replay=True,hashes=h),indent=2))
 leases=[]
 class Result(unittest.TextTestResult):
  def startTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='before',raw_None=raw is None));super().startTest(test)
  def stopTest(self,test):
   raw=l.verify_identity();leases.append(dict(test=test.id(),position='after',raw_None=raw is None));super().stopTest(test)
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
 (q/'tests.log').write_text(out.getvalue());v=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),passes=result.testsRun-len(result.failures)-len(result.errors),selection=names,leases=leases,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(t),traceback=tb) for t,tb in result.failures+result.errors],old27_remains25PASS2ERROR_frozen=True,no_aggregate_currentcanonical_admission=True)
 (q/'result.json').write_text(json.dumps(v,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());state['native_perf_only_diagnostic_design']['aux_snapshot_first_progress'].update(cleanup_after_pending=False,cleanup_after_result=v,ROOT_pending=True);state['active_turn_status']='Aux_fixture_NEW3AFTER_'+str(v['passes'])+'PASS_'+str(v['errors'])+'ERROR_ROOTpending';cp.write_text(json.dumps(state,indent=2)+'\n');l.verify_identity();print(json.dumps({k:v[k] for k in ('tests','failures','errors','passes','source_sha256','test_sha256')}));print(out.getvalue()[-1000:])
 if not result.wasSuccessful():sys.exit(1)
