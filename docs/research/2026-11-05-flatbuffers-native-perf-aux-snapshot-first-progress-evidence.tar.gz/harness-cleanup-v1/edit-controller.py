import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1/harness-cleanup-v1");R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads((P/'before-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in oldh.items())
 candidate=(P/'candidate-tests-v2.py').read_bytes();ast.parse(candidate);part=json.loads((P/'projection-parts-v2.json').read_text());private=(P/'cleanup-regressions-v1.py').read_bytes()
 assert candidate.endswith(b'\n\n'+private);assert candidate[:-(len(private)+2)].decode().replace(part['new'],part['old'],1)==(P/'before-tests.py').read_text()
 (R/'tool/test_native_perf_build_producer.py').write_bytes(candidate);h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert [k for k in h if h[k]!=oldh[k]]==['tool/test_native_perf_build_producer.py']
 (P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2));(P/'after-tests.py').open('xb').write(candidate)
 v=dict(Source_UNCHANGED=True,source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],only_future_fixture_cleanup_andNEW3_changed=True,oldtest_PREFIX_exact=False,wholeoldtest_BYTE_projectsback_by_reverse_fixture_removeNEW3=True,all_old_test_assertions_exact=True,no_Sourcefieldrestore_publicwait_retry_guardrelaxation=True,old27_25PASS2ERROR_frozen_no_rerun=True)
 (P/'edit-result.json').open('x').write(json.dumps(v,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');state=json.loads(cp.read_text());n=state['native_perf_only_diagnostic_design'];n['current_source_sha256']=h;n['aux_snapshot_first_progress'].update(cleanup_edit=v,cleanup_after_pending=True,old_after27_status='25PASS2teardownERROR_FROZEN',full_admission_complete=False);state['active_turn_status']='Aux_fixture_ROOTcleanup_testonly_edited_NEW3AFTERpending_no_oldbodyreplay';cp.write_text(json.dumps(state,indent=2)+'\n')
 l.verify_identity();print(json.dumps(v))
