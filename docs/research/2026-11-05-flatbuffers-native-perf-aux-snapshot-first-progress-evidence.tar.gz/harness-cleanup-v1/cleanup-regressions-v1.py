"""NEW ROOT fixture-cleanup tests; no legacy wait/boolean/timeout bodies."""
import os
import json
import hashlib
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer
import test_native_perf_build_producer as baseline_tests

class NaturalWaitCleanupScopeTests(TestCase):
    def _case(self,mode):
        fixture=baseline_tests.AuxiliaryNaturalWaitWitnessTests(methodName='runTest');fixture.setUp()
        native_os=producer.os;native_open=Path.open;native_allocate=producer.AuxiliaryCommand._allocate_process
        actor={'attempted':False,'process':None,'wait':None};pipes=[];logs=[];calls=[];evidence_ready=False;op=None;foreign=None;received=None
        class WaitBarrier(RuntimeError):pass
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def pipe(self):
                row=dict(attempted=True,returned=False,fds=None,identities=None);pipes.append(row);raw=native_os.pipe();row['fds']=raw;row['returned']=True
                row['identities']=[(native_os.fstat(fd).st_dev,native_os.fstat(fd).st_ino) for fd in raw];return raw
        def opening(path,*args,**kwargs):
            raw=native_open(path,*args,**kwargs)
            if path.name in ('witness.stdout','witness.stderr') and path.is_relative_to(fixture.base):
                row=dict(object=raw,close=raw.close,path=path,fd=None,identity=None);logs.append(row);fd=raw.fileno();row['fd']=fd;info=native_os.fstat(fd);row['identity']=(info.st_dev,info.st_ino)
            return raw
        def allocate(current,record):
            actor['attempted']=True;raw=native_allocate(current,record);actor.update(process=raw,wait=raw.wait,pid=raw.pid);return raw
        def forbidden(*args,**kwargs):calls.append('Source_wait_barrier');raise WaitBarrier('ROOT prevents any Source.wait body')
        try:
            with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(Path,'open',opening),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate):
                op,gate=fixture.start();op.wait=forbidden
                if mode=='foreign':foreign=object();op.process=foreign
                if mode=='finished':op.finished=True;op.result={'ROOT_fake':'not ownership or completion'}
                try:fixture.tearDown()
                except BaseException as error:received=error
            view=dict(cleanup_scope_control=True,mode=mode,teardown_returned=received is None,received_type=None if received is None else type(received).__name__,Source_wait_calls=len(calls),
                Source_process_foreign_stays=mode!='foreign' or op.process is foreign,Source_finished_fake_stays=mode!='finished' or op.finished is True,
                ROOT_original_Popen_known=actor['process'] is not None,ROOT_pid=actor.get('pid'),root_fixture_receipt=(fixture.base/'root-known-actors.json').exists(),
                limits='NEWfreshcleanupcases only/no oldboolean-timeout bodies replay. ROOTcapturesnativepipe/FileIO andreturned_allocate_process Popen/boundwait beforeIO/hooks; any Source.wait blockedBEFORESourcebody. Sourcefieldsnotrestored/notownershipauthority. Knownsameactorwait10/rawpipe-fullEOF-evidence-beforeFDclose UNITnotoriginalLinux-fullEX-interpreter-descendantclosure. Old27/2teardownerrors frozen/oldactorAPI not reconstructed. No SDK-benchmark-adoption-RAMcause.')
            (fixture.base/'cleanup-scope-view-before-external-ROOT.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertTrue(received is None);self.assertEqual(0,len(calls));self.assertTrue(view['Source_process_foreign_stays']);self.assertTrue(view['Source_finished_fake_stays']);self.assertTrue(view['root_fixture_receipt'])
            receipt=json.loads((fixture.base/'root-known-actors.json').read_text());self.assertEqual(1,len(receipt));self.assertTrue(type(receipt[0]['status']) is int);self.assertEqual(0,receipt[0]['status'])
            self.assertEqual(actor['pid'],receipt[0]['pid']);self.assertEqual([True,True],[x['EOF'] for x in receipt[0]['readers']])
        finally:
            cleanup=[]
            if actor['wait'] is not None:
                status=actor['wait'](10);cleanup.append(dict(kind='external_ROOT_same_bound_wait',pid=actor.get('pid'),status=status,cached_possible=True));self.assertTrue(type(status) is int);self.assertEqual(0,status)
            if evidence_ready:
                for index,row in enumerate(pipes):
                    if row['returned'] and row['identities'] is not None:
                        for end,(fd,identity) in enumerate(zip(row['fds'],row['identities'])):
                            item=dict(kind='external_ROOT_known_pipe',fd=fd,end=end,ROOT_close=False)
                            try:
                                info=native_os.fstat(fd);same=(info.st_dev,info.st_ino)==tuple(identity);item['same_original_identity']=same
                                if same:
                                    if end==0:
                                        data=native_os.read(fd,65536);tail=native_os.read(fd,1);item.update(size=len(data),sha256=hashlib.sha256(data).hexdigest(),EOF=tail==b'')
                                        (fixture.base/('external-pipe-'+str(index)+'-raw.bin')).write_bytes(data)
                                    raw=native_os.close(fd);item.update(ROOT_close=True,raw_None=raw is None)
                            except OSError as error:item['errno']=error.errno
                            cleanup.append(item)
                for row in logs:
                    item=dict(kind='external_ROOT_known_log',fd=row['fd'],closed_before=row['object'].closed,ROOT_close=False)
                    if not row['object'].closed:
                        info=native_os.fstat(row['fd']);pathstat=row['path'].stat()
                        if (info.st_dev,info.st_ino)==row['identity']==(pathstat.st_dev,pathstat.st_ino):raw=row['close']();item.update(ROOT_close=True,raw_None=raw is None)
                    cleanup.append(item)
            (fixture.base/'external-ROOT-cleanup.json').write_text(json.dumps(dict(evidence_ready=evidence_ready,rows=cleanup),indent=2)+'\n')
    def test_cleanup_never_calls_replaced_Source_wait(self):self._case('barrier')
    def test_cleanup_keeps_foreign_process_field_and_uses_original_actor(self):self._case('foreign')
    def test_cleanup_ignores_fake_finished_result_fields(self):self._case('finished')
