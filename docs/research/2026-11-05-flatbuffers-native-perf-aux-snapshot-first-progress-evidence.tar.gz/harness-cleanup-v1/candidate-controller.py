import sys,pathlib,json,hashlib,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1/harness-cleanup-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();before=(P/'before-tests.py').read_text();tree=ast.parse(before);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryNaturalWaitWitnessTests');old=ast.get_source_segment(before,cls);new=old
 new=new.replace('        self.actors=[];self.gates=[];self.sequence=0;self.saved=0;self.malformed=[]','        self.actors=[];self.gates=[];self.sequence=0;self.saved=0;self.malformed=[]\n        self.root_actors=[];self.root_cleanup_attempted=False',1)
 needle='        self.actors.append((op,code));op.start()'
 replacement="""        self.actors.append((op,code))
        root=dict(op=op,code=code,gate=gate,directory=directory,process=None,wait=None,logs=[],pipes=[])
        self.root_actors.append(root) # Before start and fallible native I/O.
        native_os=producer.os;native_open=Path.open;allocate=producer.AuxiliaryCommand._allocate_process
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def pipe(self):
                row=dict(attempted=True,returned=False,fds=None,identities=None);root['pipes'].append(row)
                value=native_os.pipe();row['fds']=value;row['returned']=True
                row['identities']=[(native_os.fstat(fd).st_dev,native_os.fstat(fd).st_ino) for fd in value];return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            if path in (directory/'witness.stdout',directory/'witness.stderr'):
                row=dict(object=value,close=value.close,path=path,fd=None,identity=None);root['logs'].append(row)
                row['fd']=value.fileno();info=native_os.fstat(row['fd']);row['identity']=(info.st_dev,info.st_ino)
            return value
        def allocating(current,record):
            value=allocate(current,record)
            root.update(process=value,wait=value.wait,pid=value.pid) # Actual returned object before Source publication.
            return value
        with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(Path,'open',opening),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocating):
            op.start()"""
 assert new.count(needle)==1;new=new.replace(needle,replacement,1)
 prior="""        try:
            with self.assertRaises(producer.ProducerError):op._wait_natural_status(0)
        finally:op.process=process"""
 replacement="""        with self.assertRaises(producer.ProducerError):op._wait_natural_status(0)
        # Keep Source drift visible; ROOT owns the original actor independently."""
 assert new.count(prior)==1;new=new.replace(prior,replacement,1)
 marker='    def tearDown(self):';start=new.index(marker)
 new=new[:start]+"""    def tearDown(self):
        # Terminal ROOT fixture cleanup; never call Source.wait or trust Source fields.
        if self.root_cleanup_attempted:raise RuntimeError('ROOT fixture cleanup is permanently terminal')
        self.root_cleanup_attempted=True
        for gate in self.gates:self.release(gate)
        receipts=[]
        for index,root in enumerate(self.root_actors):
            if root['wait'] is None:
                receipts.append(dict(known_returned_Popen=False,status=None,closure_unknown=True));continue
            status=root['wait'](10)
            readers=[];pipe_observations=[]
            for number,pipe in enumerate(root['pipes']):
                if not pipe['returned'] or pipe['identities'] is None:
                    pipe_observations.append(dict(known_creator_return=False,closure_unknown=True));continue
                for end,(fd,identity) in enumerate(zip(pipe['fds'],pipe['identities'])):
                    item=dict(fd=fd,end=end,same_original_identity=False,errno=None)
                    try:
                        info=os.fstat(fd);item['same_original_identity']=(info.st_dev,info.st_ino)==tuple(identity)
                        if item['same_original_identity'] and end==0:
                            data=os.read(fd,65536);tail=os.read(fd,1)
                            raw=data+tail;name='root-actor-'+str(index)+'-pipe-'+str(number)+'-raw.bin'
                            with (self.base/name).open('xb') as out:out.write(raw)
                            readers.append(dict(fd=fd,size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),EOF=tail==b'',raw=name))
                    except OSError as error:item['errno']=error.errno
                    pipe_observations.append(item)
            log_observations=[dict(fd=x['fd'],path=str(x['path']),closed=x['object'].closed,identity=x['identity']) for x in root['logs']]
            receipt=dict(pid=root['pid'],status=status,cached_possible=True,readers=readers,pipes=pipe_observations,logs=log_observations,
                Source_wait_called=False,Source_fields_not_restored=True,unit_only_not_live_ownership_EX_originalLinux_allactorclosure=True)
            with (self.base/('root-actor-'+str(index)+'-before-close.json')).open('x') as out:json.dump(receipt,out,indent=2)
            # Evidence exists before known original FD/FileIO closure; no borrowed FD recovery.
            for pipe in root['pipes']:
                if pipe['returned'] and pipe['identities'] is not None:
                    for fd,identity in zip(pipe['fds'],pipe['identities']):
                        try:
                            info=os.fstat(fd)
                            if (info.st_dev,info.st_ino)==tuple(identity):os.close(fd)
                        except OSError as error:
                            if error.errno!=9:raise
            for entry in root['logs']:
                if not entry['object'].closed:
                    info=os.fstat(entry['fd']);path=entry['path'].stat()
                    if (info.st_dev,info.st_ino)==entry['identity']==(path.st_dev,path.st_ino):entry['close']()
            receipts.append(receipt)
            self.assertIs(type(status),int);self.assertEqual(root['code'],status)
            self.assertTrue(all(x['EOF'] for x in readers))
        with (self.base/'root-known-actors.json').open('x') as out:json.dump(receipts,out,indent=2)
"""
 assert before.count(old)==1;candidate=before.replace(old,new,1);ast.parse(candidate)
 private=(P/'cleanup-regressions-v1.py').read_text();ast.parse(private);after=candidate+'\n\n'+private
 assert candidate.replace(new,old,1)==before
 # Existing test assertions remain byte-identical; only cleanup-oriented process restoration is removed.
 oldtree=ast.parse(old);newtree=ast.parse(new)
 oldassert=[ast.get_source_segment(old,n) for n in ast.walk(oldtree) if isinstance(n,ast.Assert) or isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr.startswith('assert')]
 newassert=[ast.get_source_segment(new,n) for n in ast.walk(newtree) if isinstance(n,ast.Assert) or isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr.startswith('assert')]
 # Compare assertions in every existing test_ method, excluding fixture cleanup methods.
 def testasserts(text,tree):
  return {n.name:[ast.get_source_segment(text,x) for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr.startswith('assert')] for n in tree.body[0].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
 assert testasserts(old,oldtree)==testasserts(new,newtree)
 (P/'candidate-tests-v1.py').open('x').write(after);(P/'candidate-fixture-v1.py').open('x').write(new+'\n');(P/'projection-parts-v1.json').open('x').write(json.dumps(dict(old=old,new=new),indent=2))
 (P/'candidate-projection.json').open('x').write(json.dumps(dict(whole_previous_tests_BYTE_projectsback_after_remove_NEW3_append_and_reverse_fixture=True,all_existing_test_method_assertions_exact=True,all_other_existing_classes_methods_exact=True,Source_UNCHANGED=True,old27_results_frozen=True,no_oldbody_replay=True,oldtest_PREFIX_NOT_exact=True,cleanup_only_field_restore_removed_Source_foreign_stays=True),indent=2));(P/'candidate.diff').open('x').write(''.join(difflib.unified_diff(before.splitlines(True),candidate.splitlines(True),fromfile='old-fixture',tofile='ROOT-ledger-fixture')))
 l.verify_identity();print(json.dumps(dict(Source_UNCHANGED=True,fixture_chars=len(new),existing_test_assertions_exact=True,old27_frozen=True,matchingNEW3AFTER_only=True,oldtest_PREFIX_exact=False)))
