class AuxiliaryFinalizationQuarantineTests(unittest.TestCase):
    def _final_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-finalization-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        aux=None;phase=['init'];events=[];trigger=[None];proxies={};calls={'defer':0,'repr':0};child=[None];bound_wait=[None]
        original_open=Path.open;original_fsync=os.fsync;original_snapshot=producer._file_snapshot
        original_json=producer._write_json;original_complete=producer.AuxiliaryCommand._complete
        original_defer=producer.AuxiliaryCommand._defer;original_allocate=producer.AuxiliaryCommand._allocate_process
        class Fault(OSError):
            def __repr__(error):calls['repr']+=1;return 'finalization boundary error'
        injected=Fault(5,'native finalization operation returned before injected fault')
        def event(stage,role):
            row=dict(stage=stage,role=role,native_returned=False,pending=aux.pending,finished=aux.finished,
                result_is_None=aux.result is None,private_wait_observed=aux._natural_wait_observed,
                private_wait_status=aux._natural_wait_status,both_eof=all(s['eof'] for s in aux.streams.values()))
            events.append(row);return row
        def fault(row,stage,role):
            row['native_returned']=True
            if mode==stage and role=='stdout' and trigger[0] is None:
                trigger[0]=len(events)-1;raise injected
        class Facade:
            def __init__(self,native,role):self.native=native;self.role=role
            @property
            def name(self):return self.native.name
            @property
            def closed(self):return self.native.closed
            def write(self,data):return self.native.write(data)
            def fileno(self):
                if phase[0]=='final':
                    row=event('fileno',self.role);value=self.native.fileno();row['native_returned']=True;return value
                return self.native.fileno()
            def flush(self):
                if phase[0]=='final':
                    row=event('flush',self.role);value=self.native.flush();fault(row,'flush',self.role);return value
                return self.native.flush()
            def close(self):
                if phase[0]=='final':
                    row=event('close',self.role);value=self.native.close();fault(row,'close',self.role);return value
                return self.native.close()
        def opening(path,*args,**kwargs):
            value=original_open(path,*args,**kwargs)
            for role in ('stdout','stderr'):
                if path==base/('finalizer.'+role):
                    proxy=Facade(value,role);proxies[role]=proxy;return proxy
            return value
        def syncing(fd):
            role=next((role for role,p in proxies.items() if not p.native.closed and p.native.fileno()==fd),None)
            if phase[0]=='final' and role is not None:
                row=event('fsync',role);value=original_fsync(fd);fault(row,'fsync',role);return value
            return original_fsync(fd)
        def snapshot(path,maximum):
            role=next((role for role in proxies if Path(path)==base/('finalizer.'+role)),None)
            if phase[0]=='final' and role is not None:
                row=event('snapshot',role);value=original_snapshot(path,maximum);fault(row,'snapshot',role);return value
            return original_snapshot(path,maximum)
        def writing(path,data):
            if phase[0]=='final':
                name=Path(path).name;stage='result' if name=='finalizer-result.json' else 'failure' if name=='finalizer-failure.json' else 'other-json'
                row=event(stage,'stdout');value=original_json(path,data);fault(row,stage,'stdout');return value
            return original_json(path,data)
        def complete(current):
            phase[0]='final';return original_complete(current)
        def defer(current,error):calls['defer']+=1;return original_defer(current,error)
        def allocate(current,record):
            value=original_allocate(current,record);child[0]=value;bound_wait[0]=value.wait;return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'fsync',syncing),
            mock.patch.object(producer,'_file_snapshot',snapshot),mock.patch.object(producer,'_write_json',writing),
            mock.patch.object(producer.AuxiliaryCommand,'_complete',complete),
            mock.patch.object(producer.AuxiliaryCommand,'_defer',defer),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        raised=None;result=None;cleanup=[]
        try:
            for patch in patches:patch.start()
            try:
                aux=producer.AuxiliaryCommand(directory=base,name='finalizer',argv=[sys.executable,'-c',
                    "import os;os.write(1,b'final-out');os.write(2,b'final-err')"],cwd=base,
                    environment=dict(os.environ),lease_check=lambda:None)
                self.assertIs(aux,aux.start())
                try:result=aux.wait(3)
                except BaseException as error:raised=error
            finally:
                for patch in reversed(patches):patch.stop()
            phase[0]='report'
            journal=getattr(aux,'_finalization_journal',None)
            normalized=[] if type(journal) is not list else [dict(stage=row.get('stage'),role=row.get('role'),
                attempted=row.get('attempted'),returned=row.get('returned'),completed=row.get('completed'),
                error_is_original=row.get('error') is injected,raw_is_None=row.get('raw_return') is None) for row in journal]
            report=dict(mode=mode,events=events,calls=calls,trigger_index=trigger[0],raised_is_original=raised is injected,
                result_is_None=result is None,source_result_is_None=aux.result is None,pending=aux.pending,finished=aux.finished,
                publication_attempted=aux.publication_attempted,private_wait_observed=aux._natural_wait_observed,
                private_wait_status=aux._natural_wait_status,both_eof=all(s['eof'] for s in aux.streams.values()),
                log_closed={role:p.closed for role,p in proxies.items()},journal=normalized,
                scope='real native FileIO facade and actual finite naturalwait/EOF only; no SDK/physicalEX admission')
            with (base/'finalization-before-cleanup.json').open('x') as out:json.dump(report,out,indent=2)
            self.assertTrue(report['private_wait_observed']);self.assertEqual(0,report['private_wait_status']);self.assertTrue(report['both_eof'])
            if mode=='normal':
                self.assertIsNone(raised);self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode'])
                self.assertTrue(aux.finished);self.assertFalse(aux.pending);self.assertIs(result,aux.result)
                self.assertEqual(['flush','fileno','fsync','close','snapshot']*2+['result'],[r['stage'] for r in events])
            else:
                self.assertEqual(0,calls['defer']);self.assertEqual(0,calls['repr']);self.assertIs(injected,raised)
                self.assertIsNotNone(trigger[0]);self.assertEqual(trigger[0]+1,len(events))
                self.assertTrue(aux.pending);self.assertFalse(aux.finished);self.assertIsNone(aux.result)
                self.assertFalse(any(row['stage']=='failure' for row in events))
                self.assertIs(type(journal),list);self.assertTrue(journal);self.assertIs(injected,getattr(aux,'_finalization_primary_error',None))
                self.assertEqual(mode,journal[-1]['stage']);self.assertIsNone(journal[-1]['returned'])
                self.assertIs(injected,journal[-1]['error'])
                if mode in ('flush','fsync'):self.assertFalse(proxies['stdout'].closed)
                self.assertIs(aux.publication_attempted,mode=='result')
        finally:
            phase[0]='unit-cleanup'
            if bound_wait[0] is not None:
                status=bound_wait[0](3);cleanup.append(dict(kind='bound_same_finite_wait',pid=child[0].pid,status=status,cached_possible=True))
                self.assertIs(type(status),int);self.assertEqual(0,status)
            for role,proxy in proxies.items():
                if not proxy.native.closed:
                    fd=proxy.native.fileno();a=os.fstat(fd);b=Path(proxy.name).stat()
                    self.assertEqual((a.st_dev,a.st_ino),(b.st_dev,b.st_ino));proxy.native.close()
                    cleanup.append(dict(kind='known_raw_log_close',role=role,fd=fd,returned=True,not_source_retry=True))
            with (base/'finalization-unit-cleanup.json').open('x') as out:json.dump(cleanup,out,indent=2)

    def test_native_flush_then_error_stops_before_finally_close(self):
        self._final_case('flush')
    def test_native_fsync_then_error_stops_before_log_close(self):
        self._final_case('fsync')
    def test_native_log_close_then_error_never_advances_snapshot(self):
        self._final_case('close')
    def test_snapshot_return_then_error_never_advances_other_log(self):
        self._final_case('snapshot')
    def test_original_result_write_then_error_never_marks_complete(self):
        self._final_case('result')
    def test_normal_actual_natural_wait_log_finalization_and_result(self):
        self._final_case('normal')
