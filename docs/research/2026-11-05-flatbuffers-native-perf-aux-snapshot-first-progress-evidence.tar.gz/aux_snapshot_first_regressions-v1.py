"""NEW auxiliary snapshot-first versus metadata-secondary controls."""
import os
import sys
import json
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class AuxSnapshotFirstTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_AUX_SNAPSHOT_FIRST_FIXTURES'])
        self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root)).resolve()

    def _case(self,mode):
        base=self.base;calls=[];pipes=[];logs=[];actor={'attempted':False,'process':None,'wait':None};seen={'snapshot':[],'armed':False,'spent':False};aux=None;evidence_ready=False
        native_os=producer.os;native_open=Path.open;native_ctor=producer._FileSnapshotAttempt
        native_allocate=producer.AuxiliaryCommand._allocate_process
        native_get=producer.AuxiliaryCommand.__getattribute__;native_set=producer.AuxiliaryCommand.__setattr__
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_First'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_First'));return BaseException.add_note(self,note)
        class Secondary(OSError):
            def __repr__(self):calls.append(dict(kind='repr_Secondary'));return BaseException.__repr__(self)
        first=First('ROOT snapshot constructor first');second=Secondary('ROOT finalization metadata secondary')
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def pipe(self):
                row={'attempted':True,'returned':False,'fds':None,'identities':None};pipes.append(row)
                raw=native_os.pipe();row['fds']=raw;row['returned']=True
                row['identities']=[(native_os.fstat(fd).st_dev,native_os.fstat(fd).st_ino) for fd in raw]
                calls.append(dict(kind='ROOT_native_pipe_return',fds=list(raw)));return raw
        def opening(path,*args,**kwargs):
            raw=native_open(path,*args,**kwargs)
            if path in (base/'auxfirst.stdout',base/'auxfirst.stderr'):
                row=dict(object=raw,close=raw.close,path=path,fd=None,identity=None);logs.append(row)
                fd=raw.fileno();row['fd']=fd;info=native_os.fstat(fd);row['identity']=(info.st_dev,info.st_ino)
                calls.append(dict(kind='ROOT_native_log_return',role=path.suffix,fd=fd))
            return raw
        def allocate(current,record):
            actor['attempted']=True;calls.append(dict(kind='ROOT_allocate_attempt_before_call'))
            raw=native_allocate(current,record)
            actor['process']=raw;actor['wait']=raw.wait;actor['pid']=raw.pid
            calls.append(dict(kind='ROOT_allocate_known_Popen_return',pid=raw.pid));return raw
        def ctor(path,maximum):
            calls.append(dict(kind='ROOT_snapshot_ctor_attempt',path=str(path),maximum=maximum))
            raw=native_ctor(path,maximum);seen['snapshot'].append(raw)
            calls.append(dict(kind='ROOT_actual_snapshot_ctor_return',known_only_ROOT=mode!='normal'))
            group=producer.__dict__.get('_AUX_FINALIZATION_GROUPS',{}).get(id(aux))
            if group is not None and group[0] is aux:seen['guard']=group[1];seen['group']=group
            if mode!='normal':seen['armed']=True;raise first
            return raw
        def getting(current,name):
            raw=native_get(current,name)
            if current is aux and name=='_finalization_primary_error' and seen['armed'] and not seen['spent'] and mode=='get':
                seen['spent']=True;calls.append(dict(kind='ROOT_native_primary_get_then_secondary',native_None=raw is None));raise second
            return raw
        def setting(current,name,value):
            target=current is aux and name=='_finalization_primary_error' and seen['armed'] and not seen['spent'] and mode in ('set','set_after')
            if target:
                seen['spent']=True;calls.append(dict(kind='ROOT_primary_set_intent',value_First=value is first,native_attempted=mode=='set_after'))
                if mode=='set_after':
                    raw=native_set(current,name,value);calls.append(dict(kind='ROOT_native_primary_set_return',raw_None=raw is None));raise second
                raise second
            return native_set(current,name,value)
        received=None;result=None;pure_error=None;pure_called=False
        try:
            with mock.patch.object(producer,'os',OSFacade()),mock.patch.object(Path,'open',opening),mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate):
                aux=producer.AuxiliaryCommand(directory=base,name='auxfirst',argv=[sys.executable,'-c',"import os;os.write(1,b'AUXFIRST-out');os.write(2,b'AUXFIRST-err')"],cwd=base,environment=dict(os.environ),lease_check=lambda:official_ex_verify())
                self.assertIs(aux,aux.start())
                self.assertTrue(actor['process'] is not None);self.assertTrue(actor['wait'] is not None)
                snapshot_before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
                with mock.patch.object(producer,'_FileSnapshotAttempt',ctor),mock.patch.object(producer.AuxiliaryCommand,'__getattribute__',getting),mock.patch.object(producer.AuxiliaryCommand,'__setattr__',setting):
                    try:result=aux.wait(10)
                    except BaseException as error:received=error
                snapshot_after=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            # No Source method after refusal. Only a captured private closure, when supplied BEFORE the fault.
            count_before_guard=len(calls)
            if mode!='normal' and 'guard' in seen:
                pure_called=True
                try:seen['guard']()
                except BaseException as error:pure_error=error
            journal=native_get(aux,'_finalization_journal');primary=native_get(aux,'_finalization_primary_error')
            view=dict(aux_snapshot_first_control=True,mode=mode,received_First=received is first,received_Secondary=received is second,received_type=None if received is None else type(received).__name__,result=result,
                original_bound_Popen_known=actor['process'] is not None,actor_pid=actor.get('pid'),snapshot_ctor_calls=len(seen['snapshot']),Source_snapshot_registry_delta=snapshot_after-snapshot_before,
                primary_field_First=primary is first,primary_field_Secondary=primary is second,primary_field_None=primary is None,
                pending=native_get(aux,'pending'),finished=native_get(aux,'finished'),Source_result_None=native_get(aux,'result') is None,
                natural_wait_observed=native_get(aux,'_natural_wait_observed'),natural_wait_status=native_get(aux,'_natural_wait_status'),
                both_eof=all(x['eof'] for x in native_get(aux,'streams').values()),Source_guard_captured_before_fault='guard' in seen,pure_guard_called=pure_called,pure_guard_First=pure_error is first,pure_guard_trace_unchanged=count_before_guard==len(calls),
                private_secondary_Second='group' in seen and any(x is second for x in seen['group'][3]),
                journal=[dict(stage=r['stage'],role=r['role'],returned=r['returned'],raw_None=r['raw_return'] is None,completed=r['completed'],error_First=r['error'] is first,error_Secondary=r['error'] is second) for r in journal],
                calls=list(calls),logs=[dict(path=str(r['path']),fd=r['fd'],identity=r['identity'],closed=r['object'].closed) for r in logs],pipes=[dict(attempted=r['attempted'],returned=r['returned'],fds=r['fds'],identities=r['identities']) for r in pipes],
                limits='ConfirmedOWNreturned_allocate_process Popen andboundwait BEFORE Sourcepublication/targethooks; pipecreatorreturns andnativeFileIOhandlesbeforeSourceIO. Snapshotctor actualobjectROOTknown only/neverSourceadopted/no partialPopenmethods. Metadatahooks boundedoneownedAux/delegate-restored/no Sourcefieldrestoration. PureprivateguardcapturedBEFOREfault whenavailable; BEFOREmissingguard no postfaultSourcemethod. ROOTsameboundwait10 andknownFDdevino cleanupAFTERevidence UNITnotSourcecleanup-liveownership-fullEX-originalLinux-allFD-interpreter-descendantclosure. SetupAPIincomplete/no globalPIDscan-kill-reconstruction-fullreap. No SDK/broker/benchmark/admission/RAMcause.')
            payloads={}
            for role in ('stdout','stderr'):
                raw=(base/('auxfirst.'+role)).read_bytes();payloads[role]=dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
            view['actual_output_files']=payloads
            (base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(2,len(pipes));self.assertEqual(2,len(logs));self.assertTrue(view['natural_wait_observed']);self.assertEqual(0,view['natural_wait_status']);self.assertTrue(view['both_eof'])
            for role,expected in [('stdout',b'AUXFIRST-out'),('stderr',b'AUXFIRST-err')]:
                self.assertEqual(dict(size=len(expected),sha256=hashlib.sha256(expected).hexdigest()),payloads[role])
            if mode=='normal':
                self.assertIsNone(received);self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode']);self.assertTrue(view['finished']);self.assertFalse(view['pending']);self.assertEqual(2,snapshot_after-snapshot_before);self.assertEqual(2,len(seen['snapshot']))
            else:
                self.assertTrue(received is first);self.assertIsNone(result);self.assertTrue(view['pending']);self.assertFalse(view['finished']);self.assertTrue(view['Source_result_None']);self.assertEqual(0,snapshot_after-snapshot_before);self.assertEqual(1,len(seen['snapshot']));self.assertTrue(seen['spent'])
                self.assertEqual('snapshot',journal[-1]['stage']);self.assertEqual('stdout',journal[-1]['role']);self.assertIsNone(journal[-1]['returned']);self.assertIsNone(journal[-1]['raw_return'])
                self.assertFalse(any(x['kind'].startswith(('repr_','note_')) for x in calls))
                if 'guard' in seen:self.assertTrue(pure_error is first);self.assertEqual(count_before_guard,len(calls))
        finally:
            cleanup=[]
            if actor['wait'] is not None:
                status=actor['wait'](10);cleanup.append(dict(kind='ROOT_same_original_bound_wait',pid=actor.get('pid'),status=status,cached_possible=True));self.assertTrue(type(status) is int);self.assertEqual(0,status)
            if evidence_ready:
                for row in logs:
                    item=dict(kind='ROOT_known_log',fd=row['fd'],closed_before=row['object'].closed,ROOT_close=False)
                    if not row['object'].closed:
                        info=native_os.fstat(row['fd']);pathstat=row['path'].stat();same=(info.st_dev,info.st_ino)==row['identity']==(pathstat.st_dev,pathstat.st_ino);item['original_FD_path_identity_match']=same
                        if same:raw=row['close']();item.update(ROOT_close=True,raw_None=raw is None)
                    cleanup.append(item)
                for row in pipes:
                    if row['returned'] and row['identities'] is not None:
                        for fd,identity in zip(row['fds'],row['identities']):
                            item=dict(kind='ROOT_known_pipe',fd=fd,ROOT_close=False)
                            try:
                                info=native_os.fstat(fd);same=(info.st_dev,info.st_ino)==tuple(identity);item['original_FD_identity_match']=same
                                if same:raw=native_os.close(fd);item.update(ROOT_close=True,raw_None=raw is None)
                            except OSError as error:item['errno']=error.errno
                            cleanup.append(item)
            (base/'ROOT-unit-cleanup.json').write_text(json.dumps(dict(evidence_ready=evidence_ready,rows=cleanup),indent=2)+'\n')

    def test_snapshot_First_survives_primary_get_secondary(self):self._case('get')
    def test_snapshot_First_survives_primary_set_beforewrite_secondary(self):self._case('set')
    def test_snapshot_First_preserved_after_native_primary_store_then_secondary(self):self._case('set_after')
    def test_new_normal_auxiliary_snapshot_full_bytes_and_status(self):self._case('normal')
