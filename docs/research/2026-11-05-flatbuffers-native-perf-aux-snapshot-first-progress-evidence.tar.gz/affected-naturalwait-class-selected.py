class AuxiliaryNaturalWaitWitnessTests(unittest.TestCase):
    """Finite direct method witnesses; never actor/descendant/EX admission."""
    def setUp(self):
        import time
        self.time=time;self.base=Path(tempfile.mkdtemp(prefix='aux-wait-witness-',
            dir=os.environ.get('CONNECTANUM_PERF_PRODUCER_FIXTURES'))).resolve()
        self.actors=[];self.gates=[];self.sequence=0;self.saved=0;self.malformed=[]

    def start(self,code=0,close_early=False):
        self.sequence+=1;label='aux-'+str(self.sequence)
        directory=self.base/label;directory.mkdir();ready=self.base/(label+'-ready');gate=self.base/(label+'-release')
        self.gates.append(gate)
        script=("import os,sys,time\nfrom pathlib import Path\n"
                "ready,gate=map(Path,sys.argv[1:3]);status=int(sys.argv[3]);early=sys.argv[4]=='yes'\n"
                "if early:os.close(1);os.close(2)\n"
                "else:os.write(1,b'OWN-witness-out\\n');os.write(2,b'OWN-witness-err\\n')\n"
                "ready.write_text('ready');end=time.monotonic()+10\n"
                "while not gate.exists() and time.monotonic()<end:time.sleep(.005)\n"
                "raise SystemExit(status if gate.exists() else 78)\n")
        op=producer.AuxiliaryCommand(directory=directory,name='witness',argv=[sys.executable,'-c',script,
            str(ready),str(gate),str(code),'yes' if close_early else 'no'],cwd=self.base,
            environment=dict(os.environ),lease_check=lambda:None,stdout_max=65536,stderr_max=65536)
        self.actors.append((op,code));op.start()
        end=self.time.monotonic()+3
        while not ready.exists() and self.time.monotonic()<end:self.time.sleep(.005)
        self.assertTrue(ready.exists());return op,gate

    def release(self,gate):
        if not gate.exists():
            with gate.open('x') as f:f.write('OWN finite release, NOT GO\n')

    def state(self,label,op):
        self.saved+=1
        row=dict(pid=op.process.pid,cached_Popen_returncode=op.process.returncode,status=op.status,pending=op.pending,
            finished=op.finished,stdout_eof=op.streams['stdout']['eof'],stderr_eof=op.streams['stderr']['eof'],
            wait_observed=getattr(op,'_natural_wait_observed',None),wait_status=getattr(op,'_natural_wait_status',None),
            wait_process_bound=getattr(op,'_natural_wait_process',None) is op.process,
            whole_actor_ownership_complete=None,capture_ready=False)
        with (self.base/(str(self.saved)+'-'+label+'.json')).open('x') as f:json.dump(row,f,indent=2)
        return row

    def complete(self,op):
        for _ in range(15):
            result=op.wait(1)
            if result is not None:return result
        self.fail('known finite auxiliary did not complete')

    def poll_exit(self,op):
        end=self.time.monotonic()+3
        while op.status is None and self.time.monotonic()<end:
            op._observe_status()
            if op.status is None:self.time.sleep(.005)
        self.assertIs(type(op.status),int)

    def test_actual_wait_witness_survives_prebody_complete_error(self):
        op,gate=self.start();self.release(gate);fault=OSError(5,'OWN complete prebody failure after actual wait')
        with mock.patch.object(op,'_complete',side_effect=fault):
            with self.assertRaises(OSError) as caught:self.complete(op)
        self.assertIs(caught.exception,fault);row=self.state('after-complete-error-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertTrue(row['pending']);self.assertFalse(row['finished'])
        self.assertIsNone(op.result)

    def test_poll_cached_zero_is_not_wait_method_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op)
        self.state('poll-only-zero-before-fixture-cleanup',op)
        self.assertEqual(0,op.status);self.assertEqual(0,op.process.returncode)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)
        self.assertIsNone(op._natural_wait_process)

    def test_wait_timeout_retains_exact_process_then_same_actor_completion(self):
        op,gate=self.start(close_early=True);process=op.process
        self.assertIsNone(op.wait(.02));self.state('after-real-wait-timeout',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)
        self.assertIsNone(op._natural_wait_status);self.assertTrue(op.pending);self.assertFalse(op.finished)
        self.release(gate);result=self.complete(op);self.state('same-process-natural-completion',op)
        self.assertIs(op.process,process);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)

    def test_normal_completion_records_exact_process_and_signed_zero(self):
        op,gate=self.start();self.release(gate);result=self.complete(op)
        self.state('normal-completion',op)
        self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(0,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process);self.assertFalse(result['capture_ready'])
        self.assertFalse(result['whole_descendant_exit_proven'])

    def test_natural_nonzero_is_retained_not_invented_zero(self):
        op,gate=self.start(code=78);self.release(gate);result=self.complete(op)
        self.state('natural-nonzero',op)
        self.assertEqual('failed',result['status']);self.assertEqual(78,result['returncode'])
        self.assertIs(op._natural_wait_observed,True);self.assertEqual(78,op._natural_wait_status)
        self.assertIs(op._natural_wait_process,op.process)

    def test_boolean_wait_return_refuses_without_false_zero_witness(self):
        op,gate=self.start();self.release(gate);self.poll_exit(op);caught=None;self.malformed.append(op)
        with mock.patch.object(op.process,'wait',return_value=False):
            try:self.complete(op)
            except producer.ProducerError as error:caught=error
        self.state('malformed-bool-method-return-before-fixture-cleanup',op)
        self.assertIsNotNone(caught)
        self.assertIs(op._natural_wait_observed,False);self.assertIsNone(op._natural_wait_status)

    def test_process_drift_after_timeout_refuses_second_actor_wait(self):
        op,gate=self.start(close_early=True);other,other_gate=self.start(close_early=True)
        process=op.process;self.assertIsNone(op.wait(.02))
        op.process=other.process
        try:
            with self.assertRaises(producer.ProducerError):op._wait_natural_status(0)
        finally:op.process=process
        self.state('foreign-process-refused-before-fixture-cleanup',op)
        self.assertIs(op._natural_wait_process,process);self.assertIs(op._natural_wait_observed,False)

    def tearDown(self):
        for gate in self.gates:self.release(gate)
        rows=[]
        for op,code in self.actors:
            self.state('before-private-fixture-completion',op)
            # Same known actor completion ONLY for finite unit teardown.
            result=op.result if op.finished else self.complete(op)
            status=op.process.wait(timeout=3)
            self.assertIs(type(status),int);self.assertEqual(code,status)
            if type(result['returncode']) is int:self.assertEqual(code,result['returncode'])
            else:self.assertIs(type(result['returncode']),bool);self.assertTrue(any(op is actor for actor in self.malformed))
            for stream in result['outputs'].values():
                self.assertTrue(stream['eof']);self.assertTrue(stream['snapshot_matches_stream'])
            rows.append(dict(pid=op.process.pid,actual_same_Popen_final_wait=status,raw_result=result))
        with (self.base/'known-auxiliary-actors.json').open('x') as f:json.dump(rows,f,indent=2)
