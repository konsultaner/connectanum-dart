import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-snapshot-first-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-aux-snapshot-first-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='c247d11b1b6e2c34f85bb34e00cea2b0b4571410'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Preserve the auxiliary snapshot error before fallible metadata\n\nA controlled snapshot constructor completed inside the test controller, which then raised the original error before returning the object to Source. A subsequent auxiliary metadata getter or setter could replace that error. Four new regressions produced 2FAIL/2PASS/0ERROR before the change. A private first-error record now precedes secondary metadata handling; a pure guard prevents repeated metadata handling. All four matching regressions pass. The unknown constructor object remains unregistered and unavailable to Source.\n\nThe initial affected selection is permanently recorded as 25PASS/0FAIL/2ERROR across 27 tests. The two errors arose in older teardown code after correct permanent wait refusals in unchanged Source paths. Those test bodies and completed controls were not replayed. Three different, predeclared fixture-cleanup regressions failed before a test-only repair and pass afterwards. The repaired fixture retains the original actor and handles before I/O and uses its original bound wait, independent of Source wait/result/process fields. The original 27 results remain unchanged; these epochs do not form a current canonical suite.\n\nSource and test projections preserve the other existing behavior and assertions. Known finite actors and FD cleanup remain scoped unit evidence. Process-lifetime retention, memory use, transitive actors, original Linux credentials and full runtime admission remain unresolved. Source remains uncommitted, uncanonical and unadmitted. RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-aux-snapshot-first-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: preserve auxiliary snapshot first error'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['aux_snapshot_first_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'harness-cleanup-v1'/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Continue with a NEW predeclared regression for _git archive snapshotConstructorFirst through higher initialization/defer/preserve, or auxiliary metadata failure BEFORE privategroup/row/try. These are prospective questions, not executed counterexamples. Current Source350759/test43e6e0: private auxiliary first-error group and three modified finalization methods preserve snapshotFirst through actual metadata get/set Secondary; Source fields remain unknown/None where writes did not complete. NEW4beforec4199a/0e4e94=2FAIL2PASS0ERROR; matchingNEW4PASS inside initialAFTER27 at350759/5ff931=25PASS0FAIL2teardownERROR FROZEN. Relevant6AuxFinalization+10actualProducerPASS and5otherNaturalWitnessPASS are historical parts of that27, not a green27/currentcanonical. Two old teardown errors stop in unchanged_constructor_guard/_wait_natural_status before_complete after correct permanent refusals. No completed25/2oldbodies/old7suite replay or missing oldactor-API/status reconstruction. Futurefixture TESTONLY NEW3differentcleanupcases before3FAIL after3PASS once at350759/43e6e0; old27 unchanged. Original Popen/boundwait/nativepipe/FileIO retainedBEFOREIO, Rootfinitegates-noGO/sourcewaitbarrier/foreignprocess/fakefinished-result cannotdrivecleanup; allknownactors collected before summary/assertions, originalnonblockingreaders/rawEOF before knownFDclose. No Source fieldrestore/retry/partialPopenmethods/unknownobjectadoption. WholeSourceBYTEprojectback, reversefixture+removeNEW3+primaryNEW4 wholeoldtestBYTEexact; oldtestPREFIX NOTexact/alloldassertions exact. Qwen90975-GLM91528-Qwen93394debug-GLM94885harness all0-fullanswers-BOTH EOF-reaped-ROOTqualified, no wholecurrentapproval; v2fixture adoption beforefirstedit-AFTER/no modelrepeat. Planningv1silenttruncation-marker-1 BEFOREmodelPopen/contextfile, terminal/rawAPIkept/oldcontextunserialized-notreconstructed; freshv2firstactualmodelcall. Current23hashes-other18helpers3bins/SourceGit2before4after all0-BOTH/HEAD601ownbranch20untrackedproductiontrackedempty DATA. All20uncommitteduncanonicalunadmitted/no sourcecommit-push-adoption-SDK-nativebuild-current20canonical-kernel-broker-benchmarkcapture-strictdispatch. Earliermetadata-bindings-calleeinterior-concurrentABA-multiowner-historical-transitive/fullindependentEX-originalruntimeimmutableCOMPLETEadmission incomplete. Strongowner/group/closures/rawchunks processlife NOTfixedmemory; growth-heapRSS-timing-leakcauseUNMEASURED/no RAMrepair-memorybound-trim-reset-evict-deleteauthority. UnknownPopenCtorPERMANENT/no partialmethods-fieldderivedsettlement; fields/status/EOF/FDclosed/leaseNone DATA never physicalEX-ownership/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Aux_snapshot_first_NEW4PASS_old27_25PASS2ERROR_frozen_cleanupNEW3PASS_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
