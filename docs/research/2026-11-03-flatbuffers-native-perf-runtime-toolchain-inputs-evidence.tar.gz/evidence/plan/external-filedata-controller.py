import sys,os,pathlib,json,hashlib,stat
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-runtime-toolchain-plan')
 a=pathlib.Path('/private/tmp/connectanum-native-perf-runtime-toolchain-external-inputs-v1')
 root=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-native-preflight-runtime/connectanum-dart')
 flutter=pathlib.Path('/Users/konsultaner/flutter/flutter')
 selected=[
 root/'.tool-versions',
 flutter/'bin/dart',flutter/'bin/flutter',flutter/'bin/internal/shared.sh',flutter/'bin/internal/update_dart_sdk.sh',
 flutter/'bin/internal/update_engine_version.sh',flutter/'bin/internal/engine.version',
 flutter/'bin/cache/engine-dart-sdk.stamp',flutter/'bin/cache/engine.stamp',
 flutter/'bin/cache/dart-sdk/version',flutter/'bin/cache/dart-sdk/revision',
 flutter/'bin/cache/flutter_tools.stamp',
 pathlib.Path('/Users/konsultaner/.cargo/env'),
 pathlib.Path('/Users/konsultaner/.cargo/config'),pathlib.Path('/Users/konsultaner/.cargo/config.toml'),
 pathlib.Path('/Users/konsultaner/.rustup/settings.toml'),
 ]
 a.mkdir(mode=0o700)
 def put(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 put(a/'attempt-and-declaration.json',dict(terminal=True,scope='NEW fixed PATH wrapper and exact SDK stamp/config FILEDATA, no SDK/tool CLI',
  selected=[str(v) for v in selected],library_execution_policy_not_applied_to_artifact_DATA=True,
  limit_bytes=2*1024**2,no_credential_file_read=True,no_recursive_external_or_other_worktree_scan=True,
  all_admission_flags=False))
 local=a/'LOCAL-ONLY';local.mkdir(mode=0o700)
 ident=lambda s:{k:getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_flags')}
 rows=[]
 for index,path in enumerate(selected):
  try:first=path.lstat()
  except FileNotFoundError:rows.append(dict(path=str(path),present=False));continue
  before=dict(path=str(path),stat=ident(first));put(a/(str(index).zfill(2)+'-before.json'),before)
  assert stat.S_ISREG(first.st_mode) and first.st_size<=2*1024**2
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
  try:
   held=os.fstat(fd);assert ident(held)==ident(first)
   chunks=[];size=0
   while True:
    part=os.read(fd,65536)
    if not part:break
    chunks.append(part);size+=len(part);assert size<=2*1024**2
   data=b''.join(chunks)
   last=os.fstat(fd);path_last=path.lstat()
   assert size==held.st_size and ident(held)==ident(last)==ident(path_last)
  finally:os.close(fd)
  name=str(index).zfill(2)+'-'+path.name
  with (local/name).open('xb') as f:f.write(data)
  row=dict(path=str(path),present=True,sha256=hashlib.sha256(data).hexdigest(),size=size,
   before=ident(held),after=ident(last),path_after=ident(path_last),body_retained_LOCALONLY=name,no_execution=True)
  rows.append(row);put(a/(str(index).zfill(2)+'-after.json'),row)
 put(a/'input-observations.json',rows)
 # Newly selected symbol ranges use the earlier consumed runtime source buffer, not a path reread.
 source=pathlib.Path('/private/tmp/connectanum-native-perf-runtime-toolchain-inputs-v1/runtime-inputs/14-common.sh').read_text()
 import re
 lines=source.splitlines();ranges=[]
 for name in ['ensure_dart_env','cargo_with_retry','run_command_with_timeout','retry_command','ensure_chrome_env']:
  starts=[i for i,line in enumerate(lines) if re.match(r'^(?:function\s+)?'+name+r'\s*\(\)',line)]
  assert len(starts)==1
  start=starts[0];end=next(i for i in range(start+1,len(lines)) if lines[i]=='}')+1
  body='\n'.join(lines[start:end]);assert len(body)<=24000
  ranges.append(name+' original-lines '+str(start+1)+'-'+str(end)+'\n'+body)
 with (p/'selected-toolchain-followups.txt').open('x') as f:f.write('\n\n'.join(ranges))
 put(a/'summary.json',dict(scope='fixed wrapper/stamp/config FILEDATA only',present=sum(x['present'] for x in rows),
  absent=sum(not x['present'] for x in rows),no_compiler_or_SDK_execution_or_originalhost_proof=True,
  no_source_toolchain_config_or_cohort_mutation=True,all_admission_flags=False))
 print(json.dumps(dict(present=[dict(path=x['path'],size=x['size'],sha256=x['sha256']) for x in rows if x['present']],
  absent=[x['path'] for x in rows if not x['present']]),indent=2))
 lease.verify_identity()
