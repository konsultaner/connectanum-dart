require 'yaml';require 'json';require 'digest'
v=JSON.parse(File.read(ARGV[0]));base=File.binread(v.fetch('parent_path'));raise unless Digest::SHA256.hexdigest(base)==v.fetch('parent_sha256')
old=YAML.load(base);oldjobs=old.fetch('jobs');raise unless oldjobs.size==32
oldkey='flatbuffers-include-child-regular-inputs';newkey='flatbuffers-include-grandchild-regular-inputs';raise if oldjobs.key?(newkey)
job=Marshal.load(Marshal.dump(oldjobs.fetch(oldkey)))
def transform(x,reverse=false)
 pairs=[['flatbuffers_include_child_regular_inputs','flatbuffers_include_grandchild_regular_inputs'],['flatbuffers-include-child-regular-inputs','flatbuffers-include-grandchild-regular-inputs'],['native-perf-include-child-regular-inputs','native-perf-include-grandchild-regular-inputs'],['pr132_include_child_regular_inputs.py','pr132_include_grandchild_regular_inputs.py'],['FlatBuffers include child regular inputs (no execution)','FlatBuffers include grandchild regular inputs (no execution)']]
 case x
 when Hash;x.each_with_object({}){|(k,z),h|h[k]=transform(z,reverse)}
 when Array;x.map{|z|transform(z,reverse)}
 when String;pairs.reduce(x){|s,p|a,b=reverse ? p.reverse : p;s.gsub(a,b)}
 else;x
 end
end
job=transform(job);raise unless transform(job,true)==oldjobs.fetch(oldkey)
scripts=job.fetch('steps').select{|s|s['run'].is_a?(String)&&s['run'].include?('python3 - < .github/collectors/pr132_include_grandchild_regular_inputs.py')};raise unless scripts.size==1
u=job.fetch('steps').select{|s|s['uses'].is_a?(String)&&s['uses'].start_with?('actions/upload-artifact@')};raise unless u.size==1&&u[0].fetch('with').fetch('path')=='${{ runner.temp }}/native-perf-include-grandchild-regular-inputs'
block=YAML.dump({newkey=>job}).sub(/\A---\s*\n/,'').lines.map{|l|'  '+l}.join
choice="          - flatbuffers_include_child_regular_inputs\n";addition="          - flatbuffers_include_grandchild_regular_inputs\n";raise unless base.scan(choice).size==1
candidate=base.sub(choice){choice+addition}+"\n"+block
raise unless candidate.bytesize<500000&&candidate.bytesize<512000
fresh=YAML.load(candidate);newjobs=fresh.fetch('jobs');raise unless newjobs.size==33&&oldjobs.all?{|k,x|newjobs.fetch(k)==x}
freshjobs=newjobs.reject{|k,x|k==newkey};rest=fresh.dup;rest['jobs']=freshjobs
onkey=fresh.key?('on')?'on':true;rest=Marshal.load(Marshal.dump(rest));opts=rest.fetch(onkey).fetch('workflow_dispatch').fetch('inputs').fetch('campaign').fetch('options');raise unless opts.count('flatbuffers_include_grandchild_regular_inputs')==1;opts.delete('flatbuffers_include_grandchild_regular_inputs');raise unless rest==old
raise unless candidate[0,candidate.bytesize-("\n"+block).bytesize].sub(addition,'')==base
File.open(v.fetch('candidate_path'),'wb'){|f|f.write(candidate)};File.open(v.fetch('job_block_path'),'wb'){|f|f.write(block)}
puts JSON.generate({'ALL32_old_jobs_unchanged'=>true,'ALL_original_top_fields_preserved_except_new_campaign_option'=>true,'new_job_reverse_projection_equal_old_template'=>true,'whole_original_workflow_reverse_projection_BYTEEXACT'=>true,'parsed_jobs'=>33,'new_job_key'=>newkey,'workflow_bytes'=>candidate.bytesize,'workflow_sha256'=>Digest::SHA256.hexdigest(candidate),'declared_regular_file_stdin_python3_dash_NOT_identical_FD_topology'=>true,'uploader_sink_match'=>true,'ALL32_original_job_conditions'=>oldjobs.map{|k,j|{'job'=>k,'if'=>j['if']}}})
