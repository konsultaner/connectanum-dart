import sys,pathlib,json,hashlib,subprocess,shutil,datetime,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-returns-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();parts=json.loads((P/'projection-parts.json').read_text())
 assert source==(P/'candidate-producer-v1.py').read_text() and tests==(P/'candidate-tests-v1.py').read_text()
 assert source.replace(parts['new'],parts['old'],1)==(P/'before-producer.py').read_text()
 assert tests==(P/'before-tests.py').read_text()+'\n\n'+(P/'group_return_regressions-v2.py').read_text()
 before=json.loads((P/'before-NEW4/result.json').read_text());after=json.loads((P/'after-selected6/result.json').read_text())
 assert (before['tests'],before['failures'],before['errors'])==(6,3,0) and (after['tests'],after['failures'],after['errors'])==(6,0,0)
 assert len(before['leases'])==len(after['leases'])==12 and all(x['raw_None'] for x in before['leases']+after['leases'])
 controls={}
 for label,folder in [('BEFORE',P/'before-NEW4/fixtures'),('AFTER',P/'after-selected6/new-fixtures')]:
  views=[];waits=[];pipes=files=setup_count=0
  for d in sorted(folder.iterdir()):
   v=json.loads((d/'view-before-ROOT-wait.json').read_text());c=json.loads((d/'ROOT-unit-cleanup.json').read_text());setup=json.loads((d/'setup-commands.json').read_text());assert len(setup)==7 and all(x['status']==0 and x['both_separate_EOF'] for x in setup);setup_count+=len(setup)
   for i,x in enumerate(setup):
    for channel in ('stdout','stderr'):
     raw=(d/f'setup-{i}-{channel}.bin').read_bytes();assert len(raw)==x[channel+'_size'] and hashlib.sha256(raw).hexdigest()==x[channel+'_sha256']
   w=[r for r in c['rows'] if r['kind']=='same_original_bound_wait'];assert all(x['status']==0 and x['signed_native_int'] for x in w);waits+=w
   pipes+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='creatorFD');files+=sum(r.get('closed_by_ROOT',False) for r in c['rows'] if r['kind']=='file')
   mode=v['group_return_contract'];assert v['ROOT_tuple_not_filled_called_or_adopted']
   if mode=='known':
    assert v['received_First'] and not v['Source_returned_owner'] and v['reserved_native_returned_None'] and not v['spawn_returned_inside_ROOT'] and not w and not v['known_invalid_returned']
    journal=[json.loads(line) for line in (d/'run/journal.jsonl').read_bytes().splitlines()];assert [e['event'] for e in journal]==['reserved']
   else:
    assert len(w)==6 and v['spawn_raw_None'] and v['spawn_stage']=='spawned' and v['Source_pending_DATA'] and not v['Source_finished_DATA']
    assert (d/'ROOT-recipe-pipe.bin').read_bytes()==b'GROUP-RETURN-v1--outGROUP-RETURN-v1--err' and (d/'ROOT-recipe-pipe-tail.bin').read_bytes()==b''
    if mode in ('runtime','exit'):
     assert label=='BEFORE' and v['group_calls']==1 and v['received_First'] and not v['Source_returned_owner'] and v['post_invalid_gets']==[]
     v['ROOT_correction']='unsupportedmode KeyError BEFORE callbackreturn; known_invalid_returned isintent, NOT returned invalid literal'
    elif label=='BEFORE':
     assert v['Source_returned_owner'] and not v['received_First'] and v['received_type']=='AssertionError' and v['group_calls']==3 and len(v['post_invalid_gets'])==59 and v['Source_failure_attempted_DATA']
    else:
     assert mode in ('none','false','true') and not v['Source_returned_owner'] and v['received_First'] and v['group_calls']==1 and v['post_invalid_gets']==[] and not v['Source_failure_attempted_DATA']
   views.append(v)
  if label=='BEFORE':assert len(views)==6 and len(waits)==30 and pipes==5 and files==10 and setup_count==42
  else:assert len(views)==4 and len(waits)==18 and pipes==3 and files==6 and setup_count==28
  controls[label]=dict(views=views,wait_rows=waits,Root_pipe_closes_AFTERevidence=pipes,Root_file_closes_AFTERevidence=files,separate_setupGit_rows=setup_count)
 parent=[x for r in after['root_original_waits'] for x in r['rows']];assert len(parent)==36 and all(r['status']==0 and r['signed_native_int'] for r in parent)
 # V2 only removes accidental method declarations; intended behavior bytes exact.
 s=(P/'group_return_regressions-v1.py').read_text();v2=(P/'group_return_regressions-v2.py').read_text()
 def methods(s):return {f.name:ast.get_source_segment(s,f) for c in ast.parse(s).body if isinstance(c,ast.ClassDef) and c.name=='GroupReturnContractTests' for f in c.body if isinstance(f,ast.FunctionDef)}
 m1=methods(s);m2=methods(v2);assert all(m1[k]==v for k,v in m2.items()) and len(m1)-len(m2)==2
 models={}
 for name in ('planning','review'):
  r=json.loads((P/name/'result.json').read_text());assert r['status']==0 and r['both_separate_EOF'] and (P/name/'answer.txt').is_file();models[name]=r
 q=P/'ROOT-source-Git';q.mkdir();commands=[]
 def git(args):
  i=len(commands);argv=['git',*args];(q/f'{i}-before.json').write_text(json.dumps(dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);wait=child.wait;(q/f'{i}-start.json').write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=wait(10);(q/f'{i}-stdout.bin').write_bytes(out);(q/f'{i}-stderr.bin').write_bytes(err)
  commands.append(dict(argv=argv,pid=child.pid,status=status,both_separate_EOF=True,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()));(q/'commands.json').write_text(json.dumps(commands,indent=2));assert status==0 and not err;return out
 assert git(['rev-parse','HEAD']).decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-native-perf-guard'
 status=git(['status','--porcelain','--untracked-files=all']).decode().splitlines();assert len(status)==20 and all(x.startswith('?? tool/') for x in status) and {x[3:] for x in status}=={k for k in h if k.startswith('tool/')}
 assert git(['diff','601108ea6216464bd00ae29c16cfaf0a59c71db6','--stat','--','packages','native'])==b''
 free=shutil.disk_usage(R).free
 ass=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],actual_BEFORE6=before,matching_intendedNEW4_before='3FAIL1PASS0ERROR_subset_ONLY',extra2_before='unintended unsupportedmodeKeyError_guardedPASS_NOTdeclarednormalcontrols_FROZEN',AFTER6=after,after_matchingNEW4_plus2callers=True,controls=controls,parent_after36_includes_same_NEW18_plus18affected=True,models=models,model_ROOT_qualification=json.loads((P/'review-ROOT-qualification.json').read_text()),Source_whole_BYTEprojectback=True,oldtest_PREFIX_exact=True,v2_only_remove_extra2_declarations_NEW4behavior_exact=True,no_BEFORE_replay=True,no_prior5_6_old27_old25_old2bodies_old7suite_private2_replay=True,only_constructor_knownNone_bool_before_metadata=True,other_nonNone_bool_shapes_interiors_bindings_concurrentABA_transitive_unproved=True,kind_contract_NOTidentity_ownership_auth=True,Source_fields_status_EOF_not_liveness_EXrelease_admission=True,unknown_beforeview_waitread_cleanup_incomplete=True,unit_NOTphysicalEX_originalLinux_fullFD_interpreter_delegate_descendant_closure=True,current23hashes_other18helpers3bins_SourceGit4_0_BOTH=True,SourceGit=commands,all20_uncommitted_uncanonical_unadmitted=True,stronggroups_rawchunks_NOTfixedmemory_RSSgrowth_timing_cause_UNMEASURED=True,no_Sourcecommit_push_adoption_SDKbuild_kernel_broker_benchmarkcapture_strictdispatch_RAMrepair_acceptance=True,storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck=True,no_build_capture_deletion_authority=True,cause_outside_oldcleanup='UNMEASURED'))
 (P/'ROOT-assessment.json').open('x').write(json.dumps(ass,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_group_returns_progress'].update(ROOT_pending=False,ROOT_qualified=True,ROOT_assessment=str(P/'ROOT-assessment.json'),docs_pending=True,actual_BEFORE6='3FAIL3PASS0ERROR_FROZEN',matchingNEW4before='3FAIL1PASS0ERROR_subset',source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256']);c.update(updated_utc=ass['utc'],active_turn_status='Constructor_group_returns_NEW4before3FAIL1PASS_actual6FROZEN_AFTER6PASS_ROOTqualified_DOCSpending');cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=ass['source_sha256'],test_sha256=ass['test_sha256'],actual_BEFORE6='3FAIL3PASS_FROZEN',intendedNEW4='3FAIL1PASS',AFTER6PASS=True,extra2_correction_without_replay=True,current23hashes_SourceGit4_0_BOTH=True,free_bytes=free,full_admission=False)))
