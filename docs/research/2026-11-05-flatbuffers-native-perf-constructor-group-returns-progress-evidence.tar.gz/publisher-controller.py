import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-returns-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-constructor-group-returns-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='ac2a0102e7c52c1ae2ab4e2802f35cabaea81699'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Refuse known None and bool failure-group returns\n\nThe constructor now refuses explicit None/False/True failure-group returns before reading pending or entering deferral. Previously each invalid first return was accepted: subsequent native group calls completed and the constructor returned an owner. The new reserved-event control already preserved First. This checks unsupported return kinds, not identity, ownership or all possible group shapes.\n\nThe actual before run has6tests:3FAIL/3PASS/0ERROR. Its intended four-case subset is3FAIL/1PASS. Two old method declarations were accidentally retained in the private harness; they invoked unsupported mode keys and passed through the existing acquisition-error guard. Their intent flag does not establish a returned invalid value. All six raw results remain frozen. Harnessv2 removes only those two declarations without replaying before cases.\n\nFinal after6/6 pass once: matchingNEW4 plus environment-preservation and committed-archive caller controls. Whole Source reverse projection and the old test prefix are exact; only the constructor's explicit return-kind check changes. The ROOT-only native tuple is never filled into Source. Actor waits, FD closes and Darwin lease observations remain scoped unit evidence. Source remains uncommitted, uncanonical and unadmitted; RAM repair and strict acceptance are incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-constructor-group-returns-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: refuse known invalid failure group returns'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['constructor_group_returns_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Next NEWpredeclared question: other group object/tuple/callable return contracts or binding/interior/concurrentABA/historical-transitive immutableoriginalruntimepreflight, with noSourceeditwithoutmeaningfulactualBEFOREfail. Current534c16/0bc3ab selected6PASS=matchingNEW4v2+2healthyconstructorcallers(envpreservation/archivecommittedbytes). ActualBEFOREv1six=3FAIL3PASS0ERROR FROZEN; intendedNEW4subset3FAIL1PASS; 2unintended retainedmethoddecls runtime/exit invokeunsupportedmodedictKeyError BEFOREcallbackreturn andprioracquisitionguardFirstPASS, NOTdeclarednormalcontrols/knowninvalidreturns. Their invalid_returned flag wasintent notcompletedreturn. V2ONLYremoves2decls/NEW4bodyassertions exact/no BEFOREreplay. Nativefailuregroup tuple completesROOT, firstcallback knownreturnsNone/False/True toSource, latercallsoriginalnative; beforeSourceacceptsbadfirstreturn, helpercalls3/getters59/ownerpublished, RootassertsnoSource.wait/adoption. NewguardONLYif group isNone or type(group)isbool:raisealreadyknownFirst BEFOREmetadata; AFTERhelpercalls1/getters0/noownerpublication/defer-preserve-repr-close/RootnativeTuplefill. PositiveactualreservednativeeventNone thenFirst/knownnativeGroup/noSourceGit-recipe (notoldspawnedevent/inputdrift), alreadyPASS. WholeSourceBYTEprojectback/oldtestPREFIXexact/other18helpers3bins-oldauxpredicates-owner_emit_attempted exact; kindcontractNOTtype-origin-ownership-auth/allshapes. Beforefull6views/sourceRoot30waits0=18intended+12accidental; AFTER4views18waits0; parentafter36=18sameNEW+18affected/noaddedduplicates. BeforefullRoot5pipe10filesincludesintended3pipe6files+extra2pipe4files; AFTER3pipe6files AFTERevidence only. SetupGitbefore42=28intended14extra/after28 separate0-BOTH. ParentDarwinEX12before(incl4extra)/12afterNone UNITnotphysicalEX-originalLinux/fullFD-interpreter-delegate-descendantclosure/admission; unexpectedbeforeview/waitread cleanup incomplete/no fullreap-PIDscan-kill/omissionreconstruction. Qwen16186=0/1054out400err;GLM17105=0/1638out679err/fullanswers-BOTH EOF-reaped-ROOTqualified NOTwholecurrentapproval. Rejectstickyflagmask claim(resetwouldhidecallbacks)/strongowner-IDreuse; malformedotherreturns unproved; SourceRAISESFirst/nopytestsuggestionexecution/firstinvalid vs laternativecalls distinct. Fresh23hashes/4SourceGit0-BOTH/HEAD601ownbranch20untracked-prodempty DATA/notcompiledcanonical. No prior5-6-old27/25-2bodies-7suite-privatependingTrue2 replay/currentcanonicalaggregate. Stronggroups-closures-rawchunksprocesslife NOTfixedmemory/heapRSSgrowth-allocvolume-timing-leakcauseUNMEASURED/no RAMrepair-memorybound-trim-pop-reset-evict-deleteauthority. All20uncommitteduncanonicalunadmitted/providerABSENT/gatealwaysraises/controllerCLOSED/ownershipNone/all3flagsFalse/noSourceadoption-SDKbuild-kernel-broker-benchmarkcapture-strictdispatch; UnknownPopenCtorPERMANENT/no partialmethods-fieldderivedsettlement.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Constructor_group_returns_selected6PASS_before6frozen_correctedNEW4_docs_pushed_admin_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
