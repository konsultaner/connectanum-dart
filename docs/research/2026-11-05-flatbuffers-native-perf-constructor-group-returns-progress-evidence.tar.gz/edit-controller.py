import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-constructor-group-returns-progress-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();oldh=json.loads(pathlib.Path('/tmp/connectanum-native-perf-constructor-group-acquisition-progress-v1/after-edit-hashes.json').read_text())
 actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert actual==oldh
 old=(R/'tool/native_perf_build_producer.py').read_text();oldtests=(R/'tool/test_native_perf_build_producer.py').read_text();new=(P/'candidate-producer-v1.py').read_text();newtests=(P/'candidate-tests-v1.py').read_text();parts=json.loads((P/'projection-parts.json').read_text())
 assert old==(P/'before-producer.py').read_text() and oldtests==(P/'before-tests.py').read_text()
 assert new.replace(parts['new'],parts['old'],1)==old and newtests==oldtests+'\n\n'+parts['append']
 def methods(s):
  return {c.name+'.'+f.name:ast.get_source_segment(s,f) for c in ast.parse(s).body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef)}
 before=methods(old);after=methods(new);assert [k for k in before if before[k]!=after[k]]==['CommandProducer.__init__']
 (R/'tool/native_perf_build_producer.py').write_text(new);(R/'tool/test_native_perf_build_producer.py').write_text(newtests)
 h={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in oldh};assert all(v==oldh[k] for k,v in h.items() if k not in ('tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'))
 (P/'after-edit-hashes.json').open('x').write(json.dumps(h,indent=2));(P/'after-producer.py').open('x').write(new);(P/'after-tests.py').open('x').write(newtests)
 receipt=dict(source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],wholeSource_BYTEprojectback=True,only_existing_method_changed='CommandProducer.__init__',oldtest_PREFIX_exact=True,other18helpers3bins_unchanged=True,unknown_group_ROOT_tuple_not_adopted=True,no_Source_ownerfield_restore_cleanup=True,no_build_capture_adoption=True)
 (P/'edit-result.json').open('x').write(json.dumps(receipt,indent=2));cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['current_source_sha256']=h;n['constructor_group_returns_progress'].update(edit=receipt,Source_test_edits=True,after_pending=True);c['active_turn_status']='Constructor_group_returns_Sourceedited_AFTERpending';cp.write_text(json.dumps(c,indent=2)+'\n');l.verify_identity();print(json.dumps(receipt))
