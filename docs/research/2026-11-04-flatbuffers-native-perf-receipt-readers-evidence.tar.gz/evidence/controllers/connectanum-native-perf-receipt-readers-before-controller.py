import sys,pathlib,os,json,hashlib,types,io,unittest,datetime,errno,stat
from unittest import mock
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 root=pathlib.Path('/tmp/connectanum-native-perf-receipt-readers-before-v1');root.mkdir()
 def put(name,value):
  with (root/name).open('x') as output_file:json.dump(value,output_file,indent=2);output_file.write('\n')
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 put('attempt.json',dict(scope='NEW finite direct generic sealed-JSON helper BEFORE regression, no source edit/SDK/projectCLI/build/capture',
  expected_source_sha256='5847df17f0a3acac8a7d54b942c5096a52e13ffa248812cbd12cbccd53d7dfb0',
  actual_official_EX_held=True,no_children_or_threads_requested=True,no_admission=True))
 source_path=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_build_producer.py')
 free=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize;assert free>=1024**3
 source_record=dict(fd=None,close_attempted=False,close_returned=None)
 source_fd=os.open(source_path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);source_record['fd']=source_fd
 try:
  info=os.fstat(source_fd);assert info.st_size<=2*1024**2 and info.st_uid==501 and info.st_gid==20
  identity=lambda value:(value.st_dev,value.st_ino,value.st_mode,value.st_uid,value.st_gid,value.st_nlink,value.st_size,value.st_mtime_ns,value.st_ctime_ns)
  pieces=[]
  while True:
   part=os.read(source_fd,65536)
   if not part:break
   pieces.append(part)
  raw=b''.join(pieces);assert sha(raw)=='5847df17f0a3acac8a7d54b942c5096a52e13ffa248812cbd12cbccd53d7dfb0'
  assert identity(info)==identity(os.fstat(source_fd))==identity(source_path.stat())
  source_record.update(identity=identity(info),size=len(raw),sha256=sha(raw))
 finally:
  source_record['close_attempted']=True;os.close(source_fd);source_record['close_returned']=True
 put('source-read.json',source_record)
 with (root/'consumed-producer-source.py').open('xb') as output_file:output_file.write(raw)
 sys.dont_write_bytecode=True
 producer=types.ModuleType('receipt_readers_before_producer');producer.__file__=str(source_path);sys.modules[producer.__name__]=producer
 exec(compile(raw,str(source_path),'exec'),producer.__dict__)
 records=[]
 class HookError(RuntimeError):pass
 class BeforeControls(unittest.TestCase):
  def control(self,kind):
   body=(b'{"OWN":"sealed-json"}\n');path=root/(kind+'-input.json')
   with path.open('xb') as output_file:output_file.write(body)
   hooks=[];fds=[];closes=[]
   class CloseError(OSError):
    def __repr__(self):hooks.append('close_repr');raise HookError('OWN close repr')
    def __str__(self):hooks.append('close_str');raise HookError('OWN close str')
    def add_note(self,note):hooks.append('close_add_note');raise HookError('OWN close note')
   class EarlierError(RuntimeError):
    def __repr__(self):hooks.append('first_repr');raise HookError('OWN first repr')
    def __str__(self):hooks.append('first_str');raise HookError('OWN first str')
    def add_note(self,note):hooks.append('first_add_note');raise HookError('OWN first note')
   closing_error=CloseError(5,'OWN actual-close-then-error');earlier=EarlierError('OWN earlier')
   original_open=os.open;original_close=os.close
   def opening(actual_path,flags,*args,**kwargs):
    fd=original_open(actual_path,flags,*args,**kwargs)
    if pathlib.Path(actual_path)==path:fds.append(fd)
    return fd
   def closing(fd):
    if not fds or fd!=fds[-1]:return original_close(fd)
    info=os.fstat(fd);path_info=path.stat();observed=dict(fd=fd,identity=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_size),
     path_identity=(path_info.st_dev,path_info.st_ino,path_info.st_mode,path_info.st_uid,path_info.st_gid,path_info.st_size),native_close_returned=None)
    closes.append(observed)
    returned=original_close(fd);observed['native_close_returned']=returned is None
    if kind!='ambient_success':raise closing_error
    return returned
   caught=None;result=None
   with mock.patch.object(producer.os,'open',opening),mock.patch.object(producer.os,'close',closing):
    if kind=='body_error':
     with mock.patch.object(producer,'_sha',side_effect=earlier):
      try:result=producer._read_json(path,sha(body))
      except BaseException as error:caught=error
    else:
     try:raise earlier
     except EarlierError:
      try:result=producer._read_json(path,sha(body))
      except BaseException as error:caught=error
   closed_observation=None
   if fds:
    try:os.fstat(fds[-1])
    except OSError as error:closed_observation=dict(fstat_errno=error.errno,observed_EBADF=error.errno==errno.EBADF)
   intended=None if kind=='ambient_success' else earlier if kind=='body_error' else closing_error
   row=dict(kind=kind,source_function='_read_json',actual_os_open_returned_FDs=fds,
    actual_same_FD_native_closes=closes,postcall_numeric_FD_observation=closed_observation,
    intended_error_type=None if intended is None else type.__dict__['__name__'].__get__(type(intended),type),
    caught_error_type=None if caught is None else type.__dict__['__name__'].__get__(type(caught),type),
    caught_is_intended=caught is intended,hooks=list(hooks),returned_value=result,
    resource_owner_record_in_original_helper=False,unknown_original_actor_closure=True,
    fixture_only_no_SDK_or_workload=True,ownership_complete=None,all_admission_flags=False)
   records.append(row);put(kind+'-observation.json',row)
   self.assertEqual(1,len(fds));self.assertEqual(1,len(closes));self.assertTrue(closes[0]['native_close_returned'])
   self.assertTrue(closed_observation['observed_EBADF'])
   self.assertTrue(caught is intended);self.assertEqual([],hooks)
   if kind=='ambient_success':self.assertEqual({'OWN':'sealed-json'},result)
  def test_ambient_close_error_is_first_without_hooks(self):self.control('ambient_close')
  def test_body_error_survives_actual_close_error_without_hooks(self):self.control('body_error')
  def test_success_in_ambient_handler_does_not_call_hooks(self):self.control('ambient_success')
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(BeforeControls);output=io.StringIO()
 result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
 with (root/'tests.log').open('x') as output_file:output_file.write(output.getvalue())
 report=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),successful=result.wasSuccessful(),
  source_sha256=source_record['sha256'],observations=records,free_before=free,
  scope='Direct generic helper finite file BEFORE fault-model unit controls, not original SDK/build/RAM/canonical defect count',
  failures_detail=[dict(test=str(test),traceback=traceback) for test,traceback in result.failures],
  errors_detail=[dict(test=str(test),traceback=traceback) for test,traceback in result.errors])
 put('report.json',report);sys.modules.pop(producer.__name__)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text())
 value['native_perf_only_diagnostic_design']['receipt_readers_preparation']=dict(
  design='/tmp/connectanum-native-perf-receipt-readers-design',before=str(root/'report.json'),
  implementation_unimplemented=True,current_source_unchanged=True,before_counts=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors)),
  review_pending=False,publication_pending=True,all_known_own_models_and_controls_terminal=True,
  no_SDK_build_capture_or_canonical=True,all_admission_flags=False,scope='Direct receipt reader plan and finite generic _read_json BEFORE error-hook controls ONLY')
 value['active_turn_status']='receipt_readers_design_BEFORE_controls_complete_implementation_pending'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),source_unchanged=True)))
