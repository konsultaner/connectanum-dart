import sys,pathlib,json,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 root=pathlib.Path('/tmp/connectanum-native-perf-receipt-readers-assessment');root.mkdir()
 design=pathlib.Path('/tmp/connectanum-native-perf-receipt-readers-design')
 before=pathlib.Path('/tmp/connectanum-native-perf-receipt-readers-before-v1')
 report=json.loads((before/'report.json').read_text())
 assert (report['tests'],report['failures'],report['errors'])==(3,2,0)
 assert len(report['observations'])==3
 for row in report['observations']:
  assert len(row['actual_os_open_returned_FDs'])==1 and len(row['actual_same_FD_native_closes'])==1
  assert row['actual_same_FD_native_closes'][0]['native_close_returned'] is True
  assert row['postcall_numeric_FD_observation']['observed_EBADF'] is True
 negative=[row for row in report['observations'] if row['kind']!='ambient_success']
 assert all(row['caught_is_intended'] is False and row['caught_error_type']=='HookError' and row['hooks']==['close_repr'] for row in negative)
 normal=next(row for row in report['observations'] if row['kind']=='ambient_success')
 assert normal['caught_is_intended'] is True and normal['hooks']==[] and normal['returned_value']=={'OWN':'sealed-json'}
 models={name:json.loads((design/(name+'-finish.json')).read_text()) for name in ['judge','tests']}
 assert all(result['direct_status']==0 and result['reaped'] for result in models.values())
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='direct_receipt_readers_design_and_generic_JSON_BEFORE_controls',
  implementation_unimplemented=True,source_unchanged=True,producer_sha256='5847df17f0a3acac8a7d54b942c5096a52e13ffa248812cbd12cbccd53d7dfb0',
  test_sha256='0f2fbb429d5471e6b56fc19dba1a167bbddb04a0be2d519d3496cc3a931e93f3',
  source_scope='Exact producer source buffer heldFD/path beforeafter observed and compiled solely to use generic _read_json; not current20 validation/canonical/native compiled proof. No new source branch/HEAD observation or edit.',
  before_report=report,models=models,
  design='Independent purpose-keyed direct receipt reader ledger sharing durable receipt quarantine; preserve generic helpers outside direct receipt calls, output terminal-path policy and existing gates. Records beforeopen/exactFD beforecallback-metadata. Bind original records/FD/progress around callback. Every native close BaseException retained+quarantined before choosing earliest raise; unknownclose no reclose/newopen/publication. JSON receipt readers deliberately gain scoped identity/type/owner/mode/path checks, not claim genericJSON already had them.',
  root_model_qualification='GLM direct0: accept explicit close failure retention and deliberate JSON tightening; reject read-idempotency as failed-purpose retry authority, pre-open-fstat wording and inference of deliberate omission. Qwen direct0: repr is on closingerror not ProducerError, actual nativeclose before fault not mocked raise-only, no guessed command. Proposed nonOSError close control NOTexecuted.',
  actual_control_scope='NEW finite actual raw-file/nativeclose then injectederror fault models/currentPython only, no recipe/Git/SDK/compiler/version/child/worker requested.2FAIL1PASS; no missingAPI errors, no original SDK/build/RAM/canonical defect count. Exact error objects private; booleans/types/hooks/FDidentity/nativeclose/EBADF facts serialized. No globalFD/actor/EXrelease proof.',
  no_unchanged_controls_models_archives_or_serialization_reconstruction=True,
  no_current20_canonical_source_adoption_SDK_nativebuild_kernel_broker_benchmark_capture_strictdispatch=True,
  wholephysical_controller_incomplete=True,all20_uncommitted_uncanonical_unadmitted=True,production601_unedited=True,
  owner_emit_attempted_and_old_aux_predicates_unchanged=True,provider_absent=True,live_gate_always_raises=True,controller_closed=True,
  ownership_complete=None,all_admission_flags=False,free_after=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize,no_cleanup=True,space_cause_unmeasured=True)
 with (root/'assessment.json').open('x') as output_file:json.dump(assessment,output_file,indent=2);output_file.write('\n')
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text())
 value['native_perf_only_diagnostic_design']['receipt_readers_preparation'].update(assessment=str(root/'assessment.json'),root_assessment=str(root),
  implementation_unimplemented=True,publication_pending=True,models_qualified_by_ROOT=True,never_repeat_unchanged=True)
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(qualified_before_counts=[3,2,0],implementation_unimplemented=True,free_bytes=assessment['free_after'])))
