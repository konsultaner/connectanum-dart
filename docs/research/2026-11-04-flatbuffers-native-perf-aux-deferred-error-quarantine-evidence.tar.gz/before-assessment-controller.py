import sys,pathlib,json,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-defer-design-v1');q=p/'before';result=json.loads((q/'result.json').read_text())
 reports=[];journals=[]
 for path in sorted((q/'fixtures').rglob('deferred-before-cleanup.json')):
  raw=path.read_bytes();value=json.loads(raw);reports.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),value=value))
 for path in sorted((q/'fixtures').rglob('deferred-unit-cleanup.json')):
  raw=path.read_bytes();journals.append(dict(path=str(path.relative_to(p)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),value=json.loads(raw)))
 assert result['tests']==7 and result['failures']==6 and result['errors']==0 and len(reports)==7 and len(journals)==7
 assert all(x['value']['raised_is_mask'] and x['value']['calls']['repr']>=1 for x in reports if x['value']['mode']!='normal')
 waits=[row for j in journals for row in j['value'] if row['kind']=='bound_same_finite_wait'];assert len(waits)==7 and all(type(x['status']) is int and x['status']==0 for x in waits)
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),NEW_before7='6FAIL1normalPASS0APIerrors',source_epoch='49e30d/1063c6',reports=reports,journals=journals,known_finite_same_bound_method_waits=len(waits),all_saved_waits_signed0=True,cached_possible=True,ROOT_callbacks_and_wrappers_fixture_only=True,source_never_received_hidden_native_returns=True,initial_all_actor_FD_allocation_and_native_close_api_observations_not_all_serialized=True,no_reconstruction_or_fullphysicalEX_claim=True,production_fix_UNIMPLEMENTED=True,models_advisory_only=True)
 with (p/'ROOT-before-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_deferred_error_quarantine']=dict(path=str(p),candidate_UNIMPLEMENTED=True,NEW_before7='6FAIL1normalPASS0APIerrors',source_epoch='49e30d/1063c6',ROOT_before_assessment=str(p/'ROOT-before-assessment.json'),planning_pid=43392,planning_status=0,review_pending=True,review_outer_session=76430,per_native_IO_progress_fullphysicalEX_runtimeadmission_INCOMPLETE=True)
 c['active_turn_status']='Aux_deferred_error_NEWbefore7_6FAIL1normalPASS_candidate_unexecuted_review_pending_source_unchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(new_before_tests=7,failures=6,errors=0,normal_pass=1,known_saved_bound_waits=7,statuses_all_signed0=True,source_unchanged=True)))
