import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-defer-design-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'test-planning';q.mkdir();ctx=json.loads((P/'selected-source.json').read_text())
 context="""NEW narrow test planning: Auxiliary original _defer/wait error path. Existing ctor/startup/creatorclose/finalization quarantines already consumed; do not replay their tests. No code change yet. _defer currently reprs actual error, publishes failure JSON/add_note, returns; wait LEASE failure then continues to observe/read/write/status/select. Read/write/status errors also defer, may run custom repr/metadata and mask exact first. Proposed bounded fix: before any repr/check/report retain original error INSTANCE in private state bound before original intent I/O, permanently quarantine error path; no repr/str/add_note/equality/failure/stagingfile/cleanup/next wait operations; guarded reentry raises same bound first after scalar/flag damage. Preserve existing earlier constructor/creator/finalization first errors and normal success/timeout behavior. No partial Popen method authority or settlement. New _defer barrier DOES NOT implement per-read/write/status/select syscall progress or whole physicalEX; hidden ROOT returns stay UNKNOWN.
Proposed new real fixtures: quiet finite OWN Python actualstart; lease callback calls actual original check then raises hostile-repr first; native read returns then wrapper raises; native stdout log write returns then wrapper raises; direct _defer with hostile repr; bound-first guard survives dropped scalar/Falseflag; normal actual command output/EOF/result positive. Root handles captured BEFORE wrappers, precleanup snapshot BEFOREassertions; same actual finite actor natural wait + knownFD unit cleanup afterevidence only, NEVER source recovery/release. At real method IO use ROOT wrappers (not absent APIs/mocked actor); source must never learn hidden return. Output <=160words concrete missing meaningful controls/false assumptions only; no retries/stagingfiles/tombstones/unguardedclose or atomic/globalABA/auth claims.
CURRENT_SOURCE:
"""+json.dumps(ctx)
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','1400','--max-input-chars','10000','--max-response-chars','6000','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),NEW_defer_barrier_question=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-900:])
