import sys,pathlib,json,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-defer-design-v1');s=(p/'source-before.py').read_text();t=(p/'tests-before.py').read_text();klass=next(x for x in ast.parse(s).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 names=('_finalization_error','_retain_finalization_error','_finalization_guard','_constructor_guard')
 methods={x.name:ast.get_source_segment(s,x) for x in klass.body if isinstance(x,ast.FunctionDef) and x.name in names}
 init=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='__init__')
 methods['init_first_85_lines']='\n'.join(ast.get_source_segment(s,init).splitlines()[:85])
 tc=next(x for x in ast.parse(t).body if isinstance(x,ast.ClassDef) and x.name=='PartialAuxiliaryContinuationTests')
 methods['partial_fixture_class']=ast.get_source_segment(t,tc)
 with (p/'focused-integration-context.json').open('x') as f:json.dump(methods,f,indent=2)
 l.verify_identity();print(json.dumps(methods))
