import sys,pathlib,json,ast,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-wait-defer-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 with (P/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='NEW question: original Auxiliary wait-stream errors and _defer masking/continuation; narrow source/tests only; no tests/models/builds/native/SDK/HEAD/Git/archive/cleanup in this controller',producer_expected_sha256='49e30dbac9ed38688aea9fe66937768d466cfd2f098b5c791d1d3693a3fdc544',test_expected_sha256='1063c6e0e721c2c4c4fa4bd140cf91768655ea4c06cfda080b6c5ff979767937',prior_components_consumed_no_repeat=True,production_unchanged=True,actual_official_EX=True),f,indent=2)
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 assert hashlib.sha256(source).hexdigest()=='49e30dbac9ed38688aea9fe66937768d466cfd2f098b5c791d1d3693a3fdc544' and hashlib.sha256(tests).hexdigest()=='1063c6e0e721c2c4c4fa4bd140cf91768655ea4c06cfda080b6c5ff979767937'
 for name,data in [('source-before.py',source),('tests-before.py',tests)]:
  with (P/name).open('xb') as f:f.write(data)
 source=source.decode();tests=tests.decode();tree=ast.parse(source);klass=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 methods={x.name:ast.get_source_segment(source,x) for x in klass.body if isinstance(x,ast.FunctionDef) and x.name in ('_defer','wait')}
 index={x.name:[v.name for v in x.body if isinstance(v,ast.FunctionDef)] for x in ast.parse(tests).body if isinstance(x,ast.ClassDef) and any(k in x.name for k in ['Auxiliary','AllocatedAuxiliary'])}
 with (P/'selected-source.json').open('x') as f:json.dump(methods,f,indent=2)
 with (P/'test-symbol-index.json').open('x') as f:json.dump(index,f,indent=2)
 l.verify_identity();print(json.dumps(methods));print('test classes:',','.join(index))
