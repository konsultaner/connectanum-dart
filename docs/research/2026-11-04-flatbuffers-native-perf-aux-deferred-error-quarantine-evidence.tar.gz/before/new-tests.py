class AuxiliaryDeferredErrorQuarantineTests(unittest.TestCase):
    """NEW finite command errors; ROOT cleanup is never live source authority."""
    def _deferred_case(self,mode):
        base=Path(tempfile.mkdtemp(prefix='aux-deferred-',dir=os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])).resolve()
        phase=['init'];events=[];calls={'repr':0,'add_note':0};trigger=[None]
        proxies={};pipes=[];native_closed=set();child=[None];bound_wait=[None]
        aux=None;raised=None;result=None;probe=[];cleanup=[]
        native_open=Path.open;native_pipe=os.pipe;native_close=os.close;native_read=os.read
        native_select=producer.select.select;native_json=producer._write_json
        actual_observe=producer.AuxiliaryCommand._observe_status
        actual_complete=producer.AuxiliaryCommand._complete
        actual_allocate=producer.AuxiliaryCommand._allocate_process
        mask=RuntimeError('ROOT hostile repr masking must never run')
        class First(OSError):
            def __repr__(error):
                calls['repr']+=1;events.append(dict(stage='hostile_repr'));raise mask
            def add_note(error,note):
                calls['add_note']+=1;raise mask
        first=First(5,'OWN known native boundary then deferred error')
        second=First(6,'OWN later error must not replace first')
        def row(stage,**data):
            value=dict(stage=stage,**data);events.append(value);return value
        def injecting(stage,value):
            if mode==stage and trigger[0] is None:
                trigger[0]=len(events)-1;raise first
            return value
        class Facade:
            def __init__(self,native,role):self.native=native;self.role=role
            @property
            def name(self):return self.native.name
            @property
            def closed(self):return self.native.closed
            def fileno(self):return self.native.fileno()
            def flush(self):
                if phase[0]!='init':row('flush',role=self.role)
                return self.native.flush()
            def close(self):
                if phase[0]!='init':row('log_close',role=self.role)
                return self.native.close()
            def write(self,data):
                value=self.native.write(data)
                if phase[0]=='wait':
                    row('write',role=self.role,requested_hex=bytes(data).hex(),native_return=value)
                    if self.role=='stdout':return injecting('write',value)
                return value
        def opening(path,*args,**kwargs):
            value=native_open(path,*args,**kwargs)
            for role in ('stdout','stderr'):
                if path==base/('deferred.'+role):
                    proxy=Facade(value,role);proxies[role]=proxy;return proxy
            return value
        def piping():
            values=native_pipe()
            for fd in values:
                st=os.fstat(fd);pipes.append(dict(fd=fd,dev=st.st_dev,ino=st.st_ino))
            return values
        def closing(fd):
            if phase[0] in ('wait','probe'):row('fd_close',fd=fd)
            value=native_close(fd);native_closed.add(fd);return value
        def reading(fd,size):
            try:value=native_read(fd,size)
            except (BlockingIOError,InterruptedError):
                if phase[0]=='wait':row('read_retryable',fd=fd)
                raise
            if phase[0]=='wait':
                row('read',fd=fd,native_return_hex=value.hex())
                if aux is not None and fd==aux.streams['stdout']['fd'] and value:return injecting('read',value)
            return value
        def selecting(*args):
            if phase[0]=='wait':row('select')
            return native_select(*args)
        def writing(path,data):
            if phase[0]!='init':row('json',name=Path(path).name)
            return native_json(path,data)
        def observe(current):
            value=actual_observe(current)
            if phase[0]=='wait':row('observe_status',native_return_is_None=value is None);return injecting('observe_status',value)
            return value
        def complete(current):
            if phase[0]!='init':row('complete')
            return actual_complete(current)
        original_lease=lambda:None
        def lease():
            value=original_lease()
            if phase[0]=='wait':row('lease',native_return_is_None=value is None);return injecting('lease',value)
            return value
        def allocate(current,record):
            value=actual_allocate(current,record);child[0]=value;bound_wait[0]=value.wait;return value
        patches=[mock.patch.object(Path,'open',opening),mock.patch.object(os,'pipe',piping),
            mock.patch.object(os,'close',closing),mock.patch.object(os,'read',reading),
            mock.patch.object(producer.select,'select',selecting),mock.patch.object(producer,'_write_json',writing),
            mock.patch.object(producer.AuxiliaryCommand,'_observe_status',observe),
            mock.patch.object(producer.AuxiliaryCommand,'_complete',complete),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate)]
        try:
            for patch in patches:patch.start()
            try:
                aux=producer.AuxiliaryCommand(directory=base,name='deferred',argv=[sys.executable,'-c',
                    "import os;os.write(1,b'defer-out');os.write(2,b'defer-err')"],
                    cwd=base,environment=dict(os.environ),lease_check=lease)
                self.assertIs(aux,aux.start());phase[0]='wait'
                try:
                    if mode in ('direct','reentry'):
                        row('direct_defer');trigger[0]=len(events)-1;aux._defer(first)
                    else:result=aux.wait(3)
                except BaseException as error:raised=error
                if mode=='reentry':
                    phase[0]='probe'
                    if hasattr(aux,'_deferred_primary_error'):aux._deferred_primary_error=None
                    if hasattr(aux,'_deferred_quarantined'):aux._deferred_quarantined=False
                    for label,call in [('guard',aux._constructor_guard),('defer',lambda:aux._defer(second))]:
                        caught=None
                        try:call()
                        except BaseException as error:caught=error
                        probe.append(dict(label=label,raised_is_first=caught is first))
            finally:
                for patch in reversed(patches):patch.stop()
            phase[0]='report'
            report=dict(mode=mode,events=events,calls=calls,trigger_index=trigger[0],
                raised_is_first=raised is first,raised_is_mask=raised is mask,
                result_is_None=result is None,pending=aux.pending,finished=aux.finished,
                source_result_is_None=aux.result is None,failure_attempted=aux.failure_attempted,
                publication_attempted=aux.publication_attempted,probe=probe,
                retained_scalar_is_first=getattr(aux,'_deferred_primary_error',None) is first,
                scope='ROOT wrappers over actual finite command/native returns plus synthetic lease callback; hidden returns NOT source knowledge; no SDK/physicalEX/runtime admission')
            with (base/'deferred-before-cleanup.json').open('x') as f:json.dump(report,f,indent=2)
            if mode=='normal':
                self.assertIsNone(raised);self.assertEqual(0,result['returncode'])
                self.assertTrue(aux.finished);self.assertFalse(aux.pending)
                self.assertEqual(b'defer-out',(base/'deferred.stdout').read_bytes())
                self.assertEqual(b'defer-err',(base/'deferred.stderr').read_bytes())
            else:
                self.assertEqual(0,calls['repr']);self.assertEqual(0,calls['add_note'])
                self.assertIs(first,raised);self.assertIsNotNone(trigger[0])
                self.assertEqual(trigger[0]+1,len(events));self.assertTrue(aux.pending)
                self.assertFalse(aux.finished);self.assertIsNone(aux.result)
                self.assertFalse(aux.failure_attempted);self.assertFalse(aux.publication_attempted)
                self.assertFalse((base/'deferred-failure.json').exists())
                if mode=='reentry':self.assertTrue(all(x['raised_is_first'] for x in probe))
                else:self.assertTrue(report['retained_scalar_is_first'])
        finally:
            phase[0]='unit-cleanup'
            if bound_wait[0] is not None:
                status=bound_wait[0](3);cleanup.append(dict(kind='bound_same_finite_wait',pid=child[0].pid,status=status,cached_possible=True))
                self.assertIs(type(status),int);self.assertEqual(0,status)
            # Every descriptor here was returned to this ROOT unit wrapper before source use.
            # Successful native closes were recorded; this does not authorize live recovery.
            for item in pipes:
                fd=item['fd']
                if fd in native_closed:continue
                st=os.fstat(fd);self.assertEqual((item['dev'],item['ino']),(st.st_dev,st.st_ino))
                value=native_close(fd);cleanup.append(dict(kind='known_root_pipe_close',fd=fd,dev=st.st_dev,ino=st.st_ino,raw_None=value is None))
            for role,proxy in proxies.items():
                if not proxy.native.closed:
                    fd=proxy.native.fileno();a=os.fstat(fd);b=Path(proxy.name).stat()
                    self.assertEqual((a.st_dev,a.st_ino),(b.st_dev,b.st_ino));proxy.native.close()
                    cleanup.append(dict(kind='known_raw_log_close',role=role,fd=fd,returned=True))
            with (base/'deferred-unit-cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)

    def test_direct_error_object_precedes_hostile_repr(self):self._deferred_case('direct')
    def test_bound_lease_callback_return_then_fault_stops_before_loop(self):self._deferred_case('lease')
    def test_actual_read_return_then_fault_has_no_reporting(self):self._deferred_case('read')
    def test_actual_log_write_return_then_fault_has_no_reporting(self):self._deferred_case('write')
    def test_actual_status_observation_then_fault_has_no_reporting(self):self._deferred_case('observe_status')
    def test_bound_first_survives_scalar_and_flag_damage(self):self._deferred_case('reentry')
    def test_normal_actual_command_bytes_and_completion(self):self._deferred_case('normal')
