import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0844_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import subprocess,base64,gzip,ast,time,datetime,zipfile,io,os,shutil
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-child-regular-inputs-v1';N=P/'source-generation-v1';A=P/'Actions-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();A.mkdir()
 def save(n,b):
  with (A/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('execution-declaration.json',json.dumps({'scope':'FIRST NEW ORIGINALActions ALL1199declaredregular child BODYinputs, atomic2file source/BOTHreadbacks BEFORE FIRSTdispatch. ALL30oldjobs sourcepredicates false for declareddispatch/newcampaign then actualSKIPPED required/31total. Lossless public-safe metadata-source gzip packaging is notSDKbodycompression/fielddrop/schema waiver/aliasmutability shortcut. All1199literalparent+singlebasename declaredBEFOREINPUT; all1280metadata/63deferred/18rawlinksUNEXPANDED-UNFOLLOWED/oldncurseshexNULL/priorledgers kept. Originalcopyfunctions/guard-fields preserved-byteexactreverse; originalLinux-Dart3.13.5-Rust1.99/PATH-env-argv-credentials-recipes unchangedNOTadmitted. No candidateexecution/bootstrap/dependency/build/driver/perf/numerical/Source20-runtime adoption/oldquestion-query-model-run-acquisition-archive replay. FIRSTnewreport STATICfieldbinding extraction is not oldASTvalidation repeat or SDK/source20 import. Unknownpartial/crashoutcomespermanentquarantine/no cleanup-retry-ownerdiscard.','parent_source':'7520bfd0c37d217e9e17d2b6be819aa32177b8a9','new_branch':'codex/pr132-actions-include-child-regular-inputs-20261107','all_admission_flags':False,'ownership':None},indent=2));save('controller.py',sys.argv[2]);save('actual-new-source-review-context.json',json.dumps(v,ensure_ascii=True,indent=2));save('ROOT-review-qualification.md',v['ROOT_review_qualification'])
 free=shutil.disk_usage(A).free;save('fresh-preflight-check-floor.json',json.dumps({'free_bytes':free,'required_bytes':1073741824,'not_build_authority':True}));assert free>=1073741824
 children=[]
 def native(label,args):
  save(label+'-request.json',json.dumps({'argv':args,'cwd':str(A)},indent=2));p=subprocess.Popen(args,cwd=A,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(p);save(label+'-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_IO':True},indent=2));o,e=p.communicate();status=p.wait();save(label+'.stdout',o);save(label+'.stderr',e);r={'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(o),'stderr_bytes':len(e),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_sha256':hashlib.sha256(e).hexdigest()};save(label+'-completion.json',json.dumps(r,indent=2));print(json.dumps({'label':label,**r}),flush=True);assert status==0;return o
 def api(label,method,endpoint,body=None):
  args=['gh','api','--hostname','github.com','--method',method,endpoint]
  if body is not None:save(label+'-body.json',json.dumps(body,ensure_ascii=True,indent=2));args+=['--input',str(A/(label+'-body.json'))]
  return native(label,args)
 scoped=(P/'ALL1199-new-exact-public-safe-scope.json').read_bytes();assert len(scoped)==3463612 and hashlib.sha256(scoped).hexdigest()=='2fa42e2c02962f9d4a323072786842f61af96eefe7874994295bbdaa204aedea';scope=json.loads(scoped);validation=json.loads((N/'FIRST-candidate-validation.json').read_bytes());source=(N/'candidate-wamp-profile-benchmarks.yml').read_bytes();collector=(N/'collector.py').read_bytes()
 assert len(source)==validation['workflow_bytes']==478834 and hashlib.sha256(source).hexdigest()==validation['workflow_sha256']=='bc32ac78cda0828dce8685c4549a0cc71d85f23df1160c9495ea9643629b058d'
 assert len(collector)==validation['collector_bytes']==476719 and hashlib.sha256(collector).hexdigest()==validation['collector_sha256']=='7f39f33ce265b8f156d3a7f5ddf4538fea14957cbb99169e7293a7514f11da0e'
 assert validation['ALL30_old_jobs_unchanged'] and validation['whole_original_workflow_reverse_projection_BYTEEXACT'] and validation['whole_original_regular_collector_reverse_projection_BYTEEXACT'] and validation['whole_scope_BYTEEXACT_JSONSTRING_PythonALLfield_equality']
 campaign='flatbuffers_include_child_regular_inputs'
 def condition_value(node):
  if isinstance(node,ast.Expression):return condition_value(node.body)
  if isinstance(node,ast.Constant):assert isinstance(node.value,(bool,str));return node.value
  if isinstance(node,ast.BoolOp):
   values=[condition_value(x) for x in node.values];assert all(isinstance(x,bool) for x in values)
   return all(values) if isinstance(node.op,ast.And) else any(values) if isinstance(node.op,ast.Or) else (_ for _ in ()).throw(RuntimeError('unsupported Boolean op'))
  if isinstance(node,ast.Compare):
   assert len(node.ops)==len(node.comparators)==1;left=condition_value(node.left);right=condition_value(node.comparators[0])
   if isinstance(node.ops[0],ast.Eq):return left==right
   if isinstance(node.ops[0],ast.NotEq):return left!=right
  raise RuntimeError('unsupported condition node; no dispatch permission')
 conditions=[]
 for row in validation['ALL30_original_job_conditions']:
  text=row['if'].replace('github.event_name',repr('workflow_dispatch')).replace('inputs.campaign',repr(campaign)).replace('always()','True').replace('&&',' and ').replace('||',' or ')
  value=condition_value(ast.parse(text,mode='eval'));assert value is False;conditions.append({**row,'declared_dispatch_SOURCE_inferred_false_NOT_actual_skip_yet':True})
 assert len(conditions)==30;save('ALL30-original-condition-source-preflight-BEFOREdispatch.json',json.dumps(conditions,indent=2))
 # FIRST current program STATIC metadata/report-field binding, no candidate execution and no repeated AST syntax test.
 tree=ast.parse(collector.decode());prefix=collector.decode().split('\nimport base64, gzip\n',1)[0];constants={};imports=[]
 for node in ast.parse(prefix).body:
  if isinstance(node,ast.Import):imports.extend(a.asname or a.name.split('.')[0] for a in node.names)
  if isinstance(node,ast.Assign):
   assert len(node.targets)==1 and isinstance(node.targets[0],ast.Name);value=node.value
   if isinstance(value,ast.Call):
    assert isinstance(value.func,ast.Attribute) and isinstance(value.func.value,ast.Name) and value.func.value.id=='json' and value.func.attr=='loads' and len(value.args)==1;obj=json.loads(ast.literal_eval(value.args[0]))
   else:obj=ast.literal_eval(value)
   constants[node.targets[0].id]=obj
 assert 'json' in imports and 'hashlib' in imports
 constants['prior_regular_references']=constants['references'];constants['references']=scope['ALL1199_source_regular_references'];constants['NEW_CHILD_SCOPE']=scope
 reports=[x for x in ast.walk(tree) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='report' for t in x.targets)];assert len(reports)==1 and isinstance(reports[0].value,ast.Dict);expected={}
 for key,value in zip(reports[0].value.keys,reports[0].value.values):
  assert isinstance(key,ast.Constant) and isinstance(key.value,str)
  if isinstance(value,ast.Name) and value.id in constants:expected[key.value]=constants[value.id]
  elif isinstance(value,ast.Constant):expected[key.value]=value.value
 expected['NEW_scope_exact_JSON_bytes']=len(scoped);expected['NEW_scope_exact_JSON_sha256']=hashlib.sha256(scoped).hexdigest()
 assert len(expected['source_regular_references'])==1199 and len(expected['original_ALL160_regular_reference_metadata_NOT_requeried'])==160 and expected['NEW_ALL1199_child_regular_input_scope']==scope
 save('FIRST-static-report-field-bindings-BEFOREremote-IO.json',json.dumps({'source_import_bindings':imports,'expected_static_report_fields':expected,'no_targetcode_executed':True,'no_old_AST_validation_repeated':True},ensure_ascii=True,indent=2));save('ALL1199-exact-execution-scope-before-remote-IO.json',scoped)
 parent='7520bfd0c37d217e9e17d2b6be819aa32177b8a9';parentrecord=json.loads((B/'2026-11-07-actions-include-directory-inputs-v1/Actions-v1/FIRST-new-directory-source-commit.stdout').read_bytes());assert parentrecord['sha']==parent;repo='repos/konsultaner/connectanum-dart';branch='codex/pr132-actions-include-child-regular-inputs-20261107';path='.github/workflows/wamp-profile-benchmarks.yml';cpth='.github/collectors/pr132_include_child_regular_inputs.py'
 t=json.loads(api('FIRST-new-child-regular-two-file-tree','POST',repo+'/git/trees',{'base_tree':parentrecord['tree']['sha'],'tree':[{'path':path,'mode':'100644','type':'blob','content':source.decode()},{'path':cpth,'mode':'100644','type':'blob','content':collector.decode()}]}))
 committed=json.loads(api('FIRST-new-child-regular-commit','POST',repo+'/git/commits',{'message':'Declare all1199 regular include child inputs [skip ci]','tree':t['sha'],'parents':[parent]}));sha=committed['sha'];assert [x['sha'] for x in committed['parents']]==[parent]
 made=json.loads(api('FIRST-new-child-regular-branch','POST',repo+'/git/refs',{'ref':'refs/heads/'+branch,'sha':sha}));assert made['object']['sha']==sha
 back=json.loads(api('FIRST-new-child-regular-workflow-readback','GET',repo+'/contents/'+path+'?ref='+sha));assert base64.b64decode(back['content'])==source
 backc=json.loads(api('FIRST-new-child-regular-collector-readback','GET',repo+'/contents/'+cpth+'?ref='+sha));assert base64.b64decode(backc['content'])==collector
 save('source-publication-receipt.json',json.dumps({'source_commit':sha,'branch':branch,'parent':parent,'workflow_bytes':len(source),'workflow_sha256':hashlib.sha256(source).hexdigest(),'collector_path':cpth,'collector_bytes':len(collector),'collector_sha256':hashlib.sha256(collector).hexdigest(),'BOTH_independent_readbacks_byteexact_BEFOREdispatch':True,'ALL30oldjobs_preserved':True,'ALL30oldconditions_SOURCE_inferred_false_BEFOREdispatch':True,'source_scope_lossless_BYTEEXACT_JSONSTRING_PythonALLfield_equality':True,'all_original_fields_copyfunctions_and_gates_preserved':True,'all_admission_flags':False},indent=2))
 api('FIRST-dispatch-only-NEW1199-child-regular-inputs','POST',repo+'/actions/workflows/265291183/dispatches',{'ref':branch,'inputs':{'campaign':campaign}})
 run=None
 for i in range(8):
  rows=json.loads(api('FIRST-discover-NEW1199-child-regular-run-'+str(i),'GET',repo+'/actions/workflows/265291183/runs?branch='+branch+'&event=workflow_dispatch&per_page=5'))['workflow_runs'];found=[x for x in rows if x['head_sha']==sha];assert len(found)<=1
  if found:run=found[0];break
  time.sleep(5)
 assert run is not None,'Unknown dispatch outcome; terminal/no redispatch'
 rid=run['id'];save('actual-new-run-identity.json',json.dumps(run,indent=2));print(json.dumps({'new_run':rid,'source_commit':sha}),flush=True)
 cp=B/'current-task-checkpoint.json';raw=cp.read_bytes();save('checkpoint-before-watch.json',raw);d=json.loads(raw);d['actions_include_child_regular_inputs_v1'].update(phase='NEW_ALL1199_source_run_dispatched_ONCE_originalwatch_pending',source_commit=sha,branch=branch,run_id=rid,raw_directory=str(A),all_admission_flags=False);d['active_turn_status'].update(new_include_child_regular_inputs='NEW_originalwatch_pending',run_id=rid,source_commit=sha,all_admission_flags=False,RAM_repair_FINAL_strict48_50_cleanCI='INCOMPLETE');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 native('FIRST-watch-only-NEW1199-child-regular-run',['gh','run','watch',str(rid),'--repo','konsultaner/connectanum-dart','--exit-status','--interval','10'])
 final=json.loads(api('FIRST-new-child-regular-final','GET',repo+'/actions/runs/'+str(rid)));assert final['status']=='completed' and final['conclusion']=='success'
 jobs=json.loads(api('FIRST-new-child-regular-jobs','GET',repo+'/actions/runs/'+str(rid)+'/jobs?per_page=100'))['jobs'];target=[x for x in jobs if x['name']=='FlatBuffers include child regular inputs (no execution)'];assert len(target)==1 and target[0]['conclusion']=='success';jid=target[0]['id'];assert len(jobs)==31 and all(x['conclusion']=='skipped' for x in jobs if x['id']!=jid)
 log=api('FIRST-new-child-regular-job-log','GET',repo+'/actions/jobs/'+str(jid)+'/logs');arts=json.loads(api('FIRST-new-child-regular-artifact-list','GET',repo+'/actions/runs/'+str(rid)+'/artifacts?per_page=100'))['artifacts'];assert len(arts)==1;art=arts[0];rawzip=api('FIRST-new-child-regular-artifact-zip','GET',repo+'/actions/artifacts/'+str(art['id'])+'/zip');zsha=hashlib.sha256(rawzip).hexdigest();assert len(rawzip)==art['size_in_bytes']
 if art.get('digest'):assert art['digest']=='sha256:'+zsha
 Z=zipfile.ZipFile(io.BytesIO(rawzip));infos=Z.infolist();assert len(infos)==len(set(x.filename for x in infos));destroot=A/'artifact-members';destroot.mkdir();index=[]
 for info in infos:
  name=pathlib.PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts
  if info.is_dir():continue
  data=Z.read(info);dest=destroot/info.filename;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
  index.append({'name':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 save('actual-new-artifact-member-index.json',json.dumps(index,indent=2))
 def member(basename):
  found=[x for x in index if pathlib.PurePosixPath(x['name']).name==basename];assert len(found)==1
  return found[0],(destroot/found[0]['name']).read_bytes()
 rm,reportraw=member('include-child-regular-inputs.json');report=json.loads(reportraw);assert report['workflow_revision']==sha and str(report['run_id'])==str(rid)
 for key,value in expected.items():assert report[key]==value,key
 refs=scope['ALL1199_source_regular_references'];assert [r['source_reference'] for r in report['observations']]==refs and len(refs)==1199 and report['remaining_known_input_output_FDs']==[] and report['all_admission_flags'] is False
 sm,sraw=member('NEW-child-scope-BEFORE-INPUT-IO.json');assert sraw==scoped and sraw.decode()==scoped.decode() and json.loads(sraw)==scope
 jm,jraw=member('operations.jsonl');events=[json.loads(line) for line in jraw.splitlines() if line];writes=[x for x in events if x.get('operation')=='report_bytes_written'];assert len(writes)==1 and writes[0]['bytes']==len(reportraw) and writes[0]['sha256']==hashlib.sha256(reportraw).hexdigest()
 present=[];absent=[];matched=[];total=0
 for row in report['observations']:
  if 'absent_at_open_only' in row:assert 'saved_member' not in row;absent.append(row['source_reference']);continue
  assert row['source_fd_before']==row['source_fd_after'] and row['bytes']==row['source_fd_before']['size'] and row['same_saved_output_FD_stream_matches'] is True
  mr=[x for x in index if pathlib.PurePosixPath(x['name']).name==row['saved_member']];assert len(mr)==1 and mr[0]['bytes']==row['bytes'] and mr[0]['sha256']==row['sha256']
  saved_events=[x for x in events if x.get('operation')=='input_stream_saved' and x.get('source')==row['source_reference']];assert len(saved_events)==1 and saved_events[0]['bytes']==row['bytes'] and saved_events[0]['sha256']==row['sha256']
  present.append(row['source_reference']);total+=row['bytes'];matched.append({'source_reference':row['source_reference'],'saved_member':mr[0]['name'],'bytes':row['bytes'],'sha256':row['sha256'],'saved_stream_independently_matches_ONCE':True})
 assert len(present)+len(absent)==1199 and report['regular_source_INPUT_body_opens']==len(present) and report['regular_source_INPUT_hashes']==len(present)
 for key in ['entry_symlink_target_follows','recursive_walks','directory_queries','collector_child_executions','native_information_queries','candidate_executions','environment_mutations']:assert report[key]==0
 result={'source_commit':sha,'branch':branch,'run_id':rid,'run_url':run['html_url'],'job_id':jid,'job_conclusion':'success','ALL30_previous_jobs':'skipped_not_rerun','artifact_id':art['id'],'artifact_bytes':len(rawzip),'artifact_sha256':zsha,'job_log_bytes':len(log),'job_log_sha256':hashlib.sha256(log).hexdigest(),'report_bytes':len(reportraw),'report_sha256':hashlib.sha256(reportraw).hexdigest(),'present_regular_streams':len(present),'absent_at_open_only':absent,'total_new_regular_stream_bytes':total,'ALL1199_source_refs':refs,'ALL1199_new_stream_bindings':matched,'NEW_ALL1199_exact_public_safe_scope':scope,'ALL_preserved_static_report_fields':expected,'new_source_validation':validation,'ROOT_review_qualification':v['ROOT_review_qualification'],'all_new_saved_body_interiors_UNINSPECTED':True,'entry_symlink_target_follows':0,'recursive_walks':0,'directory_queries':0,'collector_child_executions':0,'native_information_queries':0,'candidate_executions':0,'environment_mutations':0,'remaining_known_input_output_FDs':[],'all_admission_flags':False,'ownership':None,'separate_outer_launcher_PID_pipe_EOF':None,'qualification':report['qualification']}
 rawresult=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-NEW-ALL1199-regular-child-input-assessment-PRIVATE.json',rawresult);rawcp=cp.read_bytes();save('checkpoint-before-acquisition-result.json',rawcp);d=json.loads(rawcp);node=d['actions_include_child_regular_inputs_v1'];node.update(phase='COMPLETE_CONSUMED_FIRST_ORIGINAL_Actions_ALL1199_regular_child_inputs_NOT_admitted',raw_directory=str(A),source_commit=sha,run_id=rid,job_id=jid,original_saved_result=str(A/'ROOT-NEW-ALL1199-regular-child-input-assessment-PRIVATE.json'),original_saved_result_bytes=len(rawresult),original_saved_result_sha256=hashlib.sha256(rawresult).hexdigest(),present_regular_streams=len(present),absent_at_open_only=absent,total_new_regular_stream_bytes=total,artifact_id=art['id'],artifact_bytes=len(rawzip),artifact_sha256=zsha,report_bytes=len(reportraw),report_sha256=hashlib.sha256(reportraw).hexdigest(),public_documentation_pending=True,model_review_pending=False,all_admission_flags=False);d['active_turn_status'].update(new_include_child_regular_inputs='COMPLETE_CONSUMED_publication_pending',next='FIRST ALL1199originalActions regular childstreams acquired/independentlymatched ONCE/currentbodyinteriorsUNINSPECTED. Publish exactsaveddata/newmetadata-losslesssource packaging/sourceguard/review qualifications; no oldquery-model-parser-Action-run-acquisition/archive replay or nativebodyinterpretation/import/compile/build/numerical/Source20-runtime adoption. Originalepochs/all1280-63deferred-18unfollowed/oldncursesNULL protected; allflagsFALSE/RAMrepair-FINALstrict48/50-cleanCI incomplete.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'result_saved':'ROOT-NEW-ALL1199-regular-child-input-assessment-PRIVATE.json','result_bytes':len(rawresult),'result_sha256':hashlib.sha256(rawresult).hexdigest(),'source_commit':sha,'run_id':rid,'job_id':jid,'present_regular_streams':len(present),'absent_at_open_only':absent,'total_new_regular_stream_bytes':total,'artifact_id':art['id'],'artifact_bytes':len(rawzip),'artifact_sha256':zsha,'report_bytes':len(reportraw),'report_sha256':hashlib.sha256(reportraw).hexdigest(),'job_log_bytes':len(log),'job_log_sha256':hashlib.sha256(log).hexdigest(),'all_admission_flags':False}),flush=True);lease.verify_identity()
