import sys,pathlib,json,ast,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text()
 assert hashlib.sha256(source.encode()).hexdigest()=='e69a9ef704daf63c3c2aa2b57bb60ba744b20a09a9146f302f6b7b418dcbdfcb' and hashlib.sha256(tests.encode()).hexdigest()=='15ad487666e86a746c81ce5928b90099b163eae34a6cd7fb22ef704c4563be94'
 c=next(x for x in ast.parse(source).body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');lines=source.splitlines()
 names={'wait','observe','_defer','_close_slot','_complete','_read_available','_flush','_observe_natural_wait','_drain','_drain_one','_poll_process'}
 methods={x.name:'\n'.join(lines[x.lineno-1:x.end_lineno]) for x in c.body if isinstance(x,ast.FunctionDef) and x.name in names}
 for name,data in [('before-producer.py',source),('before-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(data)
 with (P/'source-context.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),methods=methods,free_bytes=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize),f,indent=2)
 l.verify_identity();print(json.dumps(methods))
