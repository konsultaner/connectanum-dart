import sys,pathlib,json,hashlib,subprocess,datetime,os,ast,copy
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'ROOT-assessment';q.mkdir();calls=[]
 def run(args):
  argv=['git','-C',str(R),*args];child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();status=child.wait();slot=len(calls);row=dict(argv=argv,pid=child.pid,status=status,stdout_eof=True,stderr_eof=True)
  for label,raw in [('stdout',out),('stderr',err)]:
   with (q/(str(slot)+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   row[label+'_size']=len(raw);row[label+'_sha256']=hashlib.sha256(raw).hexdigest()
  calls.append(row);(q/'command-progress.json').write_text(json.dumps(calls,indent=2)+'\n');assert type(status) is int and status==0
  return out
 head=run(['rev-parse','HEAD']).decode().strip();branch=run(['branch','--show-current']).decode().strip();gitstatus=run(['status','--porcelain=v1','--untracked-files=all']).decode();production=run(['diff','--exit-code','HEAD','--','packages','native'])
 names={f'tool/{prefix}{name}.py' for name in ['guard','blocked_exec','proc_witness','handoff','session','input_census','build_producer','metadata','mapped_images','admission'] for prefix in ['native_perf_','test_native_perf_']}
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 assert all(line.startswith('?? ') for line in gitstatus.splitlines()) and {line[3:] for line in gitstatus.splitlines()}==names and not production
 final=json.loads((P/'after-edit-hashes.json').read_text());before=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1/after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in final.items()) and all(final[k]==v for k,v in before.items() if 'build_producer.py' not in k)
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();old=ast.parse((P/'before-producer.py').read_text());new=ast.parse(source)
 oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in new.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_creator_close_error','_creator_close_guard','_retain_creator_close_error'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','_close_slot','_constructor_guard'})
 projected=copy.deepcopy(nm['__init__']);projected.body=[x for x in projected.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr.startswith('_creator_close_') for t in x.targets))]
 assert ast.dump(projected)==ast.dump(om['__init__'])
 projected=copy.deepcopy(nm['_constructor_guard'])
 projected.body=[x for x in projected.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='close_error' for t in x.targets)) and not(isinstance(x,ast.If) and ast.unparse(x.test)=='close_error is not None') and not(isinstance(x,ast.Expr) and ast.unparse(x)=='self._creator_close_guard()')]
 assert ast.dump(projected)==ast.dump(om['_constructor_guard'])
 for x,y in zip(old.body,new.body):
  if isinstance(x,ast.ClassDef) and x.name=='_RetainedPreflightOwner':
   xm={z.name:z for z in x.body if isinstance(z,ast.FunctionDef)};ym={z.name:z for z in y.body if isinstance(z,ast.FunctionDef)}
   assert set(xm)==set(ym) and all(ast.dump(node)==ast.dump(ym[name]) for name,node in xm.items() if name!='_capture_command_history')
  elif x is not oc:assert ast.dump(x)==ast.dump(y)
 assert tests==(P/'before-existing-tests.py').read_text()+'\n\n'+(P/'new-tests-v3.py').read_text()
 invariant=dict(ROOTwhole_final_affected_source_and7case_helper_review=True,init_ctor_guard_project_back_ASTexact=True,all_other_original_methods_factories_publicemitters_gates_ASTexact=True,only_creator_close_and_typedAux_history_schema_changed_besides_declared_private_state=True,all_original_tests_bytes_unchanged=True,other18_helpers_3bins_byteexact=True,normal_osclose_target_and_order_preserved_None_only_return=True,no_new_fd_inspection_actor_methods_or_replay_in_newguards=True,model_full_current_source_approval=False,typed_close_DATA_normal_caller_executed_unknown_derived_state_schema_staticqualified_not_runtime_authority=True)
 with (P/'ROOT-final-invariants.json').open('x') as f:json.dump(invariant,f,indent=2)
 observations=[];journals=[];probes=[]
 for stage in ('before','before-normal-control','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('before-cleanup.json')):
   data=json.loads(path.read_text());observations.append(dict(stage=stage,path=str(path),data=data))
   if stage=='after-selected' and data['mode']!='normal':
    assert len(data['events'])==1 and data['writes']==[] and data['repr_calls']==0 and data['foreign_close_called'] is False
    assert data['pending'] is True and data['finished'] is False and data['result_is_None']
  for path in sorted((P/stage/'fixtures').rglob('unit-cleanup.json')):
   data=json.loads(path.read_text())
   if isinstance(data,list) and any(row.get('kind')=='bound_same_child_method_wait' for row in data):
    assert all(type(row['status']) is int and row['status']==0 for row in data if row['kind']=='bound_same_child_method_wait')
    journals.append(dict(stage=stage,path=str(path),data=data))
  for path in sorted((P/stage/'fixtures').rglob('unit-refusal-probes-before-cleanup.json')):
   data=json.loads(path.read_text());assert data['all_first_identity_preserved'] and data['no_native_close_or_publication']
   probes.append(dict(stage=stage,path=str(path),data=data))
 for name,data in [('new-precleanup-reports.json',observations),('new-unit-journals.json',journals),('new-refusal-probes.json',probes)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 a=json.loads((P/'before/result.json').read_text());b=json.loads((P/'before-normal-control/result.json').read_text());z=json.loads((P/'after-selected/result.json').read_text())
 assert (a['tests'],a['failures'],a['errors'])==(4,4,0) and (b['tests'],b['failures'],b['errors'])==(1,0,0) and (z['tests'],z['failures'],z['errors'])==(11,0,0)
 fs=os.statvfs(R);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],all23_hashes=final,NEWbefore4=dict(source='e69a9e/15ad48',tests=4,failures=4,errors=0,qualification='common stronger pre-close slot intent predicate also fails normal-intent test; NOT4nativebugs/normalfunctionalregression'),separate_NEWnormal_control=dict(source='e69a9e/15ad48',tests=1,failures=0,errors=0),AFTERselected11=dict(source='b3c8bc/421946',tests=11,failures=0,errors=0,matching_new=5,added_positive_noop_and_boundfirst=2,affected=4),no_combined_or_full_current20canonical_claim=True,negative_raw_before='each2nativeclose+spawnpublication; errorrepr1+failurepublication; normalfileSuccessDATA not originalAPI reconstruction',source_Git=dict(head=head,branch=branch,exact20untracked=True,production_packages_native_diffempty=True,four_actual_signed0_BOTHseparateEOF=True,DATA_only_not_loadedimage_or_admission=True),ROOT_before_qualification=json.loads((P/'ROOT-before-qualification.json').read_text()),model_planning=json.loads((P/'test-planning/finish.json').read_text()),model_review=json.loads((P/'review/finish.json').read_text()),ROOT_review_assessment=json.loads((P/'ROOT-review-assessment.json').read_text()),model_review_before_v3_schema_refinement_new2positivecontrols_and_refusal_assertions=True,all_candidates_unexecuted_before_final_edit_no_candidatefailure_counts=True,new_unit_creator_cleanup_journals=len(journals),new_bound_same_child_wait0_rows=sum(1 for x in journals for row in x['data'] if row.get('kind')=='bound_same_child_method_wait'),new_refusal_probe_files=len(probes),unit_knownFD_rootreaderraws_not_live_recovery_or_fullEX=True,required_legacy_setup_actorFD_APIreturns_notall_retained_no_reconstruction=True,all_named_source_model_test_edit_ROOT_controllers_saved_BEFOREcalls=True,other18helpers_3bins_byteexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,storage_change_cause_outside_old_cleanup_UNMEASURED=True,no_SDK_build_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_open_draft_base130_issue103_milestone_open=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_creator_close_quarantine'].update(ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW creator-close postcomponent4Git actual0/BOTHseparateEOF/branchcodex/flatbuffers-native-perf-guard/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Finalb3c8bc/421946 eleven selected PASS=5matchingNEW+2addedpositive+4affected; ROOTqualified NOTmodelfullcurrentapproval/current20canonical/admission')
 c['active_turn_status']='Aux_creator_close_b3c8bc_421946_selected11PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],tests=assessment['test_sha256'],NEWbefore4='4FAIL0ERROR qualifiedpolicy',separateNEWnormal='1PASS',AFTERselected11='PASS',new_unit_journals=len(journals),new_boundwait0_rows=assessment['new_bound_same_child_wait0_rows'],refusal_probe_files=len(probes),free_bytes=free)))
