import sys,pathlib,json,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1');s=(p/'candidate-v2-producer.py').read_text()
 marker="                and cs.get('first_error') is values.get('_creator_close_primary_error'))"
 assert s.count(marker)==1;s=s.replace(marker,"                and cs.get('first_error') is values.get('_creator_close_primary_error') and cs.get('first_error') is None)")
 marker="            close_quarantined=(values.get('_creator_close_primary_error') is not None\n"
 assert s.count(marker)==1;s=s.replace(marker,marker+"                or cs.get('first_error') is not None\n")
 ast.parse(s)
 with (p/'candidate-v3-producer.py').open('x') as f:f.write(s)
 note=dict(candidate_UNIMPLEMENTED_static_only=True,GLM33919_complete0_not_approval=True,ROOT_rejected=['R1 guarded original binding drift is intentional refusal, not normal failure; never trust historical rows as authority','R2 next guarded I/O raises retained creator error; no source doubleclose of alias; tombstone is not physical proof and would overwrite actual drift data','R3 all BaseException objects retained exactly; retries forbidden; no new interrupt policy','R4 stale state first cannot pass identity check when scalar cleared; model claimfalse; globalproducerfieldsvalidfalse alreadyrefuses'],ROOT_refinement='explicit state.first_error None in healthy close_ok and include bound state first nonNone in typed close_quarantined, preserving DATA classification under scalar drift',new_positive_controls=['successful second empty-slot no-op returnsFalse with zero nativeclose/publication','bound first error survives private scalar/flag loss and all guarded reentry is refused without I/O'],model_review_BEFORE_finalV3_and_newpositivecontrols_no_fullcurrentapproval=True,other_defer_complete_postpaths_physicalEX_INCOMPLETE=True)
 with (p/'ROOT-review-assessment.json').open('x') as f:json.dump(note,f,indent=2)
 l.verify_identity()
