import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'review';q.mkdir()
 context="""NEW narrow creator-FD close review. Candidate-v2 is private UNIMPLEMENTED/UNEXECUTED, worktree e69a9e/15ad48 unchanged. Only Auxiliary creator-FD close intent/unknown handling plus DATA schema, not whole postconstructor. Existing _defer/_complete/stream-log failure paths remain OUTSIDE and still incomplete. No SDK/nativebuild/canonical/benchmark/capture/adoption.
Before4 initial test failures0API: common stronger new publicslot-retention-at-close predicate also fails on normal path; do NOTcall4runtimebugs/normalfunctionalbreak. Raw negative cases each actually perform SECONDnativeclose+spawnedmetadata after unknown/invalid/drift; errorcase also repr1/failureJSON. Separate NEW functionalnormal controlPASS, not aggregated. Exactknown finite quietPython child and root-native boundwait before fault; root-own aliaspipe cleanup onlyfinite unit, no live/physicalEX release.
Candidate binds private close intent/ref/target before nativeclose, retains rawreturn before None-only validation/postchecks/slotclear, permanent firsterror/refusal no repr/defer/reclose/retry/nextIO/publication/partialPopenmethods. Successful native calls/args/order unchanged. Empty-slot False remains no-op DATA, never a close syscall/closure proof. Context original FDnumbers/objects/type/pointers not ownership/auth/atomicABA/EX/admission. Old constructor private first raised before closeerrorfastpath; a real new closeerror can occur only after constructor guard success. Recovery from all-arbitrary foreign state writes NOTclaimed.
Qwen32359planning0 has wrong suggestions: ROOT rejects repr firing, rawNone vs methodTrue confusion, and clearingfd to authorize retries. Sourcefields neverpermission; strong original contexts and known actual IO progress, independent physicalEX controller still required.
Need actual P0/P1/P2 bugs in candidate. <=220words, concise evidence. Do NOT confuse schema-only gate with actor authority, inventcompleted status, propose retries or native methods frompartialPopen. Modelselected review advisory/not fullsourceapproval.
WHOLE CANDIDATE DELTA:\n"""+(P/'candidate-v2.diff').read_text()+'\nWHOLE NEW TEST HELPER/5METHODS:\n'+(P/'new-tests-v2.py').read_text()
 assert len(context)<30000
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--provider','openai','--model','glm-5.3-flash-q6','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--reasoning-budget','256','--num-predict','1800','--max-input-chars','30000','--max-response-chars','9000','--timeout','240','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),candidate_unimplemented=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_creator_close_quarantine']=dict(path=str(P),candidate_UNIMPLEMENTED=True,source_unchanged='e69a9e/15ad48',NEWbefore4='4FAIL0ERROR commonintentpredicate includes normal-intent policy, not4nativebugs',separateNEWnormal='1PASS',review_pid=child.pid,review_pending=True,otherpostpaths_and_physicalEX_runtimeadmission_INCOMPLETE=True);c['active_turn_status']='Aux_creator_close_NEWbefore4FAIL_separate_normal1PASS_sourceunchanged_candidateUNIMPLEMENTED_GLMreview';cp.write_text(json.dumps(c,indent=2)+'\n')
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-1000:])
