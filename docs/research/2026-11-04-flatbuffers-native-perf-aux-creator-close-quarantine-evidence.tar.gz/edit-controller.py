import sys,pathlib,json,hashlib,ast,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();h=json.loads(pathlib.Path('/tmp/connectanum-native-perf-aux-nonconstructor-quarantine-v1/after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 a=json.loads((P/'before/result.json').read_text());b=json.loads((P/'before-normal-control/result.json').read_text())
 assert (a['tests'],a['failures'],a['errors'])==(4,4,0) and (b['tests'],b['failures'],b['errors'])==(1,0,0)
 source=(P/'candidate-v3-producer.py').read_text();oldtests=(R/'tool/test_native_perf_build_producer.py').read_text();new=(P/'new-tests-v3.py').read_text();tests=oldtests+'\n\n'+new
 old=ast.parse((R/'tool/native_perf_build_producer.py').read_text());candidate=ast.parse(source)
 oc=next(x for x in old.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand');nc=next(x for x in candidate.body if isinstance(x,ast.ClassDef) and x.name=='AuxiliaryCommand')
 om={x.name:x for x in oc.body if isinstance(x,ast.FunctionDef)};nm={x.name:x for x in nc.body if isinstance(x,ast.FunctionDef)}
 assert set(nm)-set(om)=={'_creator_close_error','_creator_close_guard','_retain_creator_close_error'}
 assert all(ast.dump(node)==ast.dump(nm[name]) for name,node in om.items() if name not in {'__init__','_close_slot','_constructor_guard'})
 allowed_history='_RetainedPreflightOwner'
 for x,y in zip(old.body,candidate.body):
  if isinstance(x,ast.ClassDef) and x.name==allowed_history:
   xf={z.name:z for z in x.body if isinstance(z,ast.FunctionDef)};yf={z.name:z for z in y.body if isinstance(z,ast.FunctionDef)}
   assert set(xf)==set(yf) and all(ast.dump(node)==ast.dump(yf[name]) for name,node in xf.items() if name!='_capture_command_history')
  elif x is not oc:assert ast.dump(x)==ast.dump(y)
 ast.parse(tests)
 with (P/'edit-declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_hashes=h,scope='creator-FD close only plus typed frozenAux closeDATA',NEWbefore4='4FAIL0ERROR commonnewintentpredicate includes normal-intent policy; not4nativebugs',separateNEWfunctionalnormal='1PASS',model_review_BEFORE_v3_and_two_addedpositivecontrols=True,no_model_fullcurrentapproval=True,otherpost_defer_complete_and_physicalEX_INCOMPLETE=True),f,indent=2)
 (R/'tool/native_perf_build_producer.py').write_text(source);(R/'tool/test_native_perf_build_producer.py').write_text(tests)
 final={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in h};assert all(final[k]==v for k,v in h.items() if 'build_producer.py' not in k)
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(final,f,indent=2)
 for name,data in [('after-producer.py',source),('after-existing-tests.py',tests)]:
  with (P/name).open('x') as f:f.write(data)
 l.verify_identity();print(json.dumps({k:v for k,v in final.items() if 'build_producer' in k}))
