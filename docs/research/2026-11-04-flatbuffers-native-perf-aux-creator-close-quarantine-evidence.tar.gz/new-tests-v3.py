class AuxiliaryCreatorCloseQuarantineTests(unittest.TestCase):
    def _creator_case(self,mode,require_intent=True,repeat_empty=False,lose_first=False):
        root=Path(os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES'])
        base=Path(tempfile.mkdtemp(prefix='aux-creator-close-',dir=root)).resolve()
        phase=['setup'];pairs=[];events=[];writes=[];logs=[];child=[None];bound_wait=[None]
        target=[None];fired=[False];repr_calls=[];cleanup=[]
        original_pipe=os.pipe;original_close=os.close;original_write=producer._write_json
        original_allocate=producer.AuxiliaryCommand._allocate_process
        def ident(fd):
            st=os.fstat(fd);return (st.st_dev,st.st_ino,st.st_mode)
        foreign=original_pipe();foreign_ids=tuple(ident(fd) for fd in foreign)
        class Fault(OSError):
            def __repr__(error):repr_calls.append('repr');return 'creator-close boundary error'
        injected=Fault(5,'actual native close returned before injected fault')
        aux=None
        def piping():
            value=original_pipe()
            if phase[0]=='resource':pairs.append(dict(pair=value,identities=tuple(ident(fd) for fd in value)))
            return value
        def allocate(current,record):
            phase[0]='constructor';value=original_allocate(current,record)
            child[0]=value;bound_wait[0]=value.wait
            logs.extend(current.streams[role]['log'] for role in ('stdout','stderr'))
            target[0]=current.streams['stdout']['writer'];phase[0]='post'
            return value
        def closing(fd):
            selected=phase[0]=='post' and fd==target[0] and not fired[0]
            if phase[0]=='post':
                events.append(dict(fd=fd,selected=selected,slot_is_original=aux.streams['stdout']['writer']==fd if selected else None,
                    foreign_fd=fd in foreign))
            if selected:fired[0]=True
            returned=original_close(fd)
            if selected:
                if mode=='error':raise injected
                if mode=='invalid':return False
                if mode=='drift':aux.streams['stdout']['writer']=foreign[1]
            return returned
        def writing(path,data):
            if phase[0]=='post':writes.append(Path(path).name)
            return original_write(path,data)
        patches=[mock.patch.object(os,'pipe',piping),mock.patch.object(os,'close',closing),
            mock.patch.object(producer.AuxiliaryCommand,'_allocate_process',allocate),
            mock.patch.object(producer,'_write_json',writing)]
        returned=None;raised=None;result=None
        try:
            aux=producer.AuxiliaryCommand(directory=base,name='creator',argv=[sys.executable,'-c',
                "import os;os.write(1,b'creator-out');os.write(2,b'creator-err')"],cwd=base,
                environment=dict(os.environ),lease_check=lambda:None)
            phase[0]='resource'
            for patch in patches:patch.start()
            try:
                try:returned=aux.start()
                except BaseException as error:raised=error
                if mode=='normal':
                    self.assertIsNone(raised);self.assertIs(aux,returned);result=aux.wait(3)
                    if repeat_empty:
                        before_calls=len(events);before_writes=len(writes)
                        self.assertIs(False,aux._close_slot(aux.streams['stdout'],'writer'))
                        self.assertIs(False,aux._close_slot(aux.streams['stdout'],'fd'))
                        self.assertEqual(before_calls,len(events));self.assertEqual(before_writes,len(writes))
            finally:
                for patch in reversed(patches):patch.stop()
            journal=getattr(aux,'_creator_close_journal',None)
            rows=[] if type(journal) is not list else [dict(role=row.get('role'),slot=row.get('slot'),fd=row.get('fd'),
                attempted=row.get('attempted'),returned=row.get('returned'),raw_is_None=row.get('raw_return') is None,
                raw_is_False=row.get('raw_return') is False,result_valid=row.get('result_valid'),
                error_is_raised=row.get('error') is raised) for row in journal]
            report=dict(mode=mode,events=events,writes=writes,repr_calls=len(repr_calls),raised_is_injected=raised is injected,
                returned_is_self=returned is aux,pending=aux.pending,finished=aux.finished,result_is_None=aux.result is None,
                retained_original_process=aux.process is child[0],source_primary_is_raised=getattr(aux,'_creator_close_primary_error',None) is raised,
                rows=rows,foreign_close_called=any(row['foreign_fd'] for row in events),creator_call_returned=True,
                scope='quiet finite OWN child and ROOT-own foreign-pipe alias; actual same bound wait unit-only')
            with (base/'before-cleanup.json').open('x') as out:json.dump(report,out,indent=2)
            if require_intent:self.assertTrue(events[0]['slot_is_original'])
            if mode=='normal':
                self.assertEqual('success',result['status']);self.assertEqual(0,result['returncode'])
                if require_intent:
                    self.assertEqual(6 if repeat_empty else 4,len(rows))
                    self.assertTrue(all(row['returned'] is True and row['raw_is_None'] and row['result_valid'] is True for row in rows[:4]))
                    if repeat_empty:
                        self.assertTrue(all(row['attempted'] is False and row['returned'] is None and row['fd'] is None for row in rows[4:]))
            else:
                self.assertEqual(1,len(events));self.assertEqual([],writes);self.assertEqual([],repr_calls)
                self.assertFalse(report['foreign_close_called']);self.assertTrue(report['retained_original_process'])
                self.assertTrue(aux.pending);self.assertFalse(aux.finished);self.assertIsNone(aux.result)
                if mode=='error':self.assertIs(injected,raised)
                elif mode=='invalid':self.assertIs(type(raised),TypeError)
                else:self.assertIs(type(raised),producer.ProducerError)
                self.assertTrue(report['source_primary_is_raised']);self.assertIs(type(journal),list)
                self.assertEqual(1,len(journal));self.assertEqual(target[0],journal[0]['fd'])
                self.assertIs(journal[0]['stream'],aux.streams['stdout'])
                self.assertIs(journal[0]['log'],logs[0]);self.assertIs(True,journal[0]['attempted'])
                if mode=='error':self.assertIsNone(journal[0]['returned']);self.assertIsNone(journal[0]['result_valid'])
                else:
                    self.assertIs(True,journal[0]['returned'])
                    self.assertIs(journal[0]['result_valid'],mode=='drift')
                if mode=='drift':self.assertEqual(foreign[1],aux.streams['stdout']['writer'])
                original_primary=aux._creator_close_primary_error
                original_flag=aux._creator_close_quarantined;original_state_flag=aux._creator_close_state['quarantined']
                try:
                    if lose_first:
                        aux._creator_close_primary_error=None;aux._creator_close_quarantined=False;aux._creator_close_state['quarantined']=False
                    before_calls=len(events);before_writes=len(writes)
                    for action in (aux.start,lambda:aux.wait(0),aux._complete,lambda:aux._close_slot(aux.streams['stdout'],'writer')):
                        with self.assertRaises(BaseException) as caught:action()
                        self.assertIs(raised,caught.exception)
                    self.assertEqual(before_calls,len(events));self.assertEqual(before_writes,len(writes))
                    with (base/'unit-refusal-probes-before-cleanup.json').open('x') as out:
                        json.dump(dict(lose_first=lose_first,all_first_identity_preserved=True,no_native_close_or_publication=True,
                            scope='finite unit refusal probes only, no live retry/recovery'),out,indent=2)
                finally:
                    aux._creator_close_primary_error=original_primary;aux._creator_close_quarantined=original_flag
                    aux._creator_close_state['quarantined']=original_state_flag

        finally:
            # Known finite unit handles only. No source drain/reclose/recovery.
            if bound_wait[0] is not None:
                status=bound_wait[0](3);cleanup.append(dict(kind='bound_same_child_method_wait',pid=child[0].pid,status=status,cached_possible=True))
                self.assertIs(type(status),int);self.assertEqual(0,status)
            for item in pairs:
                fd=item['pair'][1];wanted=item['identities'][1]
                try:now=ident(fd)
                except OSError as gone:
                    if gone.errno!=9:raise
                    cleanup.append(dict(kind='writer',fd=fd,already_invalid=True));continue
                if now==wanted:original_close(fd);cleanup.append(dict(kind='writer',fd=fd,known_identity_close_returned=True))
                else:cleanup.append(dict(kind='writer',fd=fd,identity_changed_no_close=True))
            for index,item in enumerate(pairs):
                fd=item['pair'][0];wanted=item['identities'][0];raw=b'';eof=False;missing=False;blocked=False
                try:now=ident(fd)
                except OSError as gone:
                    if gone.errno!=9:raise
                    missing=True;now=None
                if now==wanted:
                    for attempt in range(4):
                        try:part=os.read(fd,65536)
                        except BlockingIOError:blocked=True;break
                        raw+=part
                        if not part:eof=True;break
                    original_close(fd)
                with (base/('root-unit-reader-'+str(index)+'.bin')).open('xb') as out:out.write(raw)
                cleanup.append(dict(kind='reader',fd=fd,already_invalid=missing,identity_matched=now==wanted,eof_observed=eof,
                    blocked_without_retry=blocked,size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
            for log in logs:
                if log.closed:continue
                held=os.fstat(log.fileno());current=Path(log.name).stat()
                self.assertEqual((held.st_dev,held.st_ino),(current.st_dev,current.st_ino))
                log.close()
            for fd,wanted in zip(foreign,foreign_ids):
                self.assertEqual(wanted,ident(fd));original_close(fd)
            with (base/'unit-cleanup.json').open('x') as out:json.dump(cleanup,out,indent=2)

    def test_native_close_return_then_error_keeps_creator_intent(self):
        self._creator_case('error')

    def test_non_None_close_return_does_not_confirm_success(self):
        self._creator_case('invalid')

    def test_slot_drift_after_actual_close_stops_before_next_IO(self):
        self._creator_case('drift')

    def test_normal_actual_creator_close_and_completion_preserved(self):
        self._creator_case('normal')

    def test_separate_normal_functional_control_requires_no_new_private_API(self):
        self._creator_case('normal',False)

    def test_successful_empty_slot_reentry_is_no_native_close(self):
        self._creator_case('normal',True,True)

    def test_bound_first_survives_scalar_and_flag_loss_without_IO(self):
        self._creator_case('error',True,False,True)
