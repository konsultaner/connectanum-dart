import sys,pathlib,json,hashlib,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'ROOT-artifact-assessment-v3';q.mkdir()
 old=P/'ROOT-assessment';calls=json.loads((old/'command-progress.json').read_text());assert len(calls)==4
 assert all(type(row['status']) is int and row['status']==0 and row['stdout_eof'] and row['stderr_eof'] for row in calls)
 head=(old/'0-stdout.bin').read_text().strip();branch=(old/'1-stdout.bin').read_text().strip()
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6' and branch=='codex/flatbuffers-native-perf-guard'
 invariant=json.loads((P/'ROOT-final-invariants.json').read_text());assert invariant['ROOTwhole_final_affected_source_and7case_helper_review'] and invariant['other18_helpers_3bins_byteexact']
 final=json.loads((P/'after-edit-hashes.json').read_text())
 observations=[];journals=[];probes=[]
 for stage in ('before','before-normal-control','after-selected'):
  for path in sorted((P/stage/'fixtures').rglob('before-cleanup.json')):
   data=json.loads(path.read_text())
   if 'events' not in data:continue
   observations.append(dict(stage=stage,path=str(path),data=data))
   if stage=='after-selected' and data['mode']!='normal':
    assert len(data['events'])==1 and data['writes']==[] and data['repr_calls']==0 and data['foreign_close_called'] is False
    assert data['pending'] is True and data['finished'] is False and data['result_is_None']
  for path in sorted((P/stage/'fixtures').rglob('unit-cleanup.json')):
   data=json.loads(path.read_text())
   if type(data) is list and all(type(row) is dict for row in data) and any(row.get('kind')=='bound_same_child_method_wait' for row in data):
    assert all(type(row['status']) is int and row['status']==0 for row in data if row['kind']=='bound_same_child_method_wait')
    journals.append(dict(stage=stage,path=str(path),data=data))
  for path in sorted((P/stage/'fixtures').rglob('unit-refusal-probes-before-cleanup.json')):
   data=json.loads(path.read_text());assert data['all_first_identity_preserved'] and data['no_native_close_or_publication']
   probes.append(dict(stage=stage,path=str(path),data=data))
 for name,data in [('new-precleanup-reports.json',observations),('new-unit-journals.json',journals),('new-refusal-probes.json',probes)]:
  with (q/name).open('x') as f:json.dump(data,f,indent=2)
 a=json.loads((P/'before/result.json').read_text());b=json.loads((P/'before-normal-control/result.json').read_text());z=json.loads((P/'after-selected/result.json').read_text())
 assert (a['tests'],a['failures'],a['errors'])==(4,4,0) and (b['tests'],b['failures'],b['errors'])==(1,0,0) and (z['tests'],z['failures'],z['errors'])==(11,0,0)
 fs=os.statvfs(P);free=fs.f_bavail*fs.f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],all23_hashes=final,NEWbefore4=dict(source='e69a9e/15ad48',tests=4,failures=4,errors=0,qualification='common stronger pre-close slot intent predicate also fails normal-intent test; NOT4nativebugs/normalfunctionalregression'),separate_NEWnormal_control=dict(source='e69a9e/15ad48',tests=1,failures=0,errors=0),AFTERselected11=dict(source='b3c8bc/421946',tests=11,failures=0,errors=0,matching_new=5,added_positive_noop_and_boundfirst=2,affected=4),no_combined_or_full_current20canonical_claim=True,negative_raw_before='each2nativeclose+spawnpublication; errorrepr1+failurepublication; normalfileSuccessDATA not originalAPI reconstruction',ROOT_v1_artifact_schema_KeyError_AFTER_fourGit_and_AST_invariants=True,ROOT_v3_artifactonly_no_source_Git_tests_models_or_AST_repeat=True,source_Git=dict(head=head,branch=branch,exact20untracked=True,production_packages_native_diffempty=True,four_actual_signed0_BOTHseparateEOF=True,DATA_only_not_loadedimage_or_admission=True),ROOT_before_qualification=json.loads((P/'ROOT-before-qualification.json').read_text()),model_planning=json.loads((P/'test-planning/finish.json').read_text()),model_review=json.loads((P/'review/finish.json').read_text()),ROOT_review_assessment=json.loads((P/'ROOT-review-assessment.json').read_text()),model_review_before_v3_schema_refinement_new2positivecontrols_and_refusal_assertions=True,all_candidates_unexecuted_before_final_edit_no_candidatefailure_counts=True,new_unit_creator_cleanup_journals=len(journals),new_bound_same_child_wait0_rows=sum(1 for x in journals for row in x['data'] if row.get('kind')=='bound_same_child_method_wait'),new_refusal_probe_files=len(probes),unit_knownFD_rootreaderraws_not_live_recovery_or_fullEX=True,required_legacy_setup_actorFD_APIreturns_notall_retained_no_reconstruction=True,all_named_source_model_test_edit_ROOT_controllers_saved_BEFOREcalls=True,original_ROOT_v1_outer_status=1,ROOT_v1_failure_preserved=True,ROOT_v2_SyntaxError_BEFOREbody=True,other18helpers_3bins_byteexact=True,production601_unedited_all20_uncommitted_uncanonical_unadmitted=True,privatecontrollers_outside_HELPERBUNDLE20=True,free_bytes=free,test_floor=1073741824,build_floor=12884901888,storage_change_cause_outside_old_cleanup_UNMEASURED=True,no_SDK_build_canonical_kernel_broker_benchmark_capture_cleanup_sourceadoption_or_strictacceptance=True,provider_absent_gate_always_raises_controller_closed=True,ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False,PR132_open_draft_base130_issue103_milestone_open=True)
 with (q/'assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['auxiliary_creator_close_quarantine'].update(ROOT_final_qualification_pending=False,ROOT_assessment=str(q/'assessment.json'),narrow_source_component_complete=True,publication_pending=True,fullphysicalEX_originalruntime_admission_INCOMPLETE=True)
 n['current_helper_source_epoch'].update(latest_postflight=str(q/'assessment.json'),branch_scope='NEW creator-close postcomponent4Git actual0/BOTHseparateEOF/branchcodex/flatbuffers-native-perf-guard/HEAD601/exact20untracked/productiondiffempty DATAonly',verification_scope='Finalb3c8bc/421946 eleven selected PASS=5matchingNEW+2addedpositive+4affected; ROOTqualified NOTmodelfullcurrentapproval/current20canonical/admission')
 c['active_turn_status']='Aux_creator_close_b3c8bc_421946_selected11PASS_ROOTqualified_publication_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source=assessment['source_sha256'],tests=assessment['test_sha256'],NEWbefore4='4FAIL0ERROR qualifiedpolicy',separateNEWnormal='1PASS',AFTERselected11='PASS',new_unit_journals=len(journals),new_boundwait0_rows=assessment['new_bound_same_child_wait0_rows'],refusal_probe_files=len(probes),free_bytes=free)))
