import sys,pathlib,json,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-aux-postconstructor-quarantine-v1')
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=P/'test-planning';q.mkdir();methods=json.loads((P/'source-context.json').read_text())['methods']
 context="""NEW focused regression planning: creator pipe-FD close AFTER actual Auxiliary Popen constructor success, not consumed startup/constructor tests. Source _close_slot clears FD BEFORE os.close; unknown close error invokes repr/report and source advances to other close/spawn publication. Need native real BEFORE, no missingAPI failures.
Narrow next component ONLY creator-FD close uncertainty; original _defer/_complete and other postconstructor paths remain OUTSIDE scope. Plan private close intent+original stream/slot/fd/log BEFORE os.close, return+rawvalue BEFORE postchecks/fieldclear; None-only native close result; unknown/invalid/drift retains first and permanently refuses all guarded source I/O, no repr/defer/next close/spawn output. Normal arguments/native order unchanged. Source fields/types/FDnumbers NEVERownership or EXrelease/admission. Separate frozenAux DATA should expose closequarantine without rewriting constructor-return facts/oldgates.
Proposed NEW4 finite actual quiet Python children, exact native bound samewait retained before fault: (1) os.close(original stdout writer) actually returns then wrapperraises OSError with repr hook counter; (2) actualclose returns then wrapperreturnsFalse; (3) actualclose returns then wrapperchanges public writer slot to separate ROOT-ownpipe FD; source mustrefuse before next IO, never closeforeignalias; (4) normal two-stream startup/wait. ROOTrecords precleanup nativeclose/metadatawrites andfirsterror, all knownFD identities; finite bound wait0 and exactknown ROOT unit cleanup only AFTER evidence, no live remedy/physicalclosure. Hidden EOF/status notwaiver.
Give <=140words of concrete missing assertions/real conceptual problem. No code/restatingplan/stagingfiles/retry/ungardedclose/field-as-authority.
SOURCE:\n"""+methods['_close_slot']+'\n'+methods['_defer']
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','1300','--max-input-chars','6000','--max-response-chars','5000','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),NEW_creator_FD_close_only=True),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 out,err=child.communicate();status=child.wait();inp.close()
 for name,b in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(b)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'finish.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode());print(err.decode()[-900:])
