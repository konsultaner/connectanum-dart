from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
validation=r'''
def _mapped_payload_schema(obs,spec):
    required={'scope','capture_ready','fixture_only','observed','raw_evidence','cleanup_errors','monotonic_begin_ns',
              'process','mappings','native_mappings','monotonic_end_ns','limitations'}
    if (set(obs)!=required or type(obs['limitations']) is not list or len(obs['limitations'])>32
            or any(type(v) is not str or len(v)>1024 for v in obs['limitations'])
            or not all(_api().mapped._u64_text(obs[k]) for k in ('monotonic_begin_ns','monotonic_end_ns'))
            or int(obs['monotonic_end_ns'])<int(obs['monotonic_begin_ns'])):
        return False
    def mapping(m):
        keys={'start','end','offset','perms','device_major','device_minor','inode','pathname_bytes_hex','classification'}
        return (type(m) is dict and set(m)==keys
                and all(_api().mapped._u64_text(m[k]) for k in ('start','end','offset','inode'))
                and int(m['start'])<int(m['end'])
                and all(type(m[k]) is int and 0<=m[k]<2**32 for k in ('device_major','device_minor'))
                and type(m['perms']) is str and re.fullmatch('[r-][w-][x-][ps]',m['perms']) is not None
                and m['classification']=='unclassified' and type(m['pathname_bytes_hex']) is str
                and len(m['pathname_bytes_hex'])<=2*1024**2 and not len(m['pathname_bytes_hex'])%2
                and re.fullmatch('[0-9a-f]*',m['pathname_bytes_hex']) is not None)
    if any(not mapping(m) for m in obs['mappings']):return False
    if any(int(a['end'])>int(b['start']) for a,b in zip(obs['mappings'],obs['mappings'][1:])):return False
    seen=set()
    for item in obs['native_mappings']:
        if type(item) is not dict or set(item)!={'mapping','backing'} or not mapping(item['mapping']):return False
        b=item['backing'];m=item['mapping']
        if (type(b) is not dict or set(b)!={'identity','sha256','size','device_major','device_minor','inode'}
                or type(b['identity']) is not list or len(b['identity'])!=8
                or not all(_api().mapped._u64_text(v) for v in b['identity'][:6])
                or any(type(v) is not str or re.fullmatch('-?(0|[1-9][0-9]{0,19})',v) is None for v in b['identity'][6:])
                or not _digest(b['sha256']) or type(b['size']) is not int or not 64<=b['size']<=512*1024**2
                or any(type(b[k]) is not int or not 0<=b[k]<2**32 for k in ('device_major','device_minor'))
                or b['inode']!=m['inode'] or b['identity'][1]!=b['inode'] or b['identity'][2]!=str(b['size'])
                or int(b['identity'][4]) not in (0,spec.controller_uid)
                or not stat.S_ISREG(int(b['identity'][3])) or int(b['identity'][3])&0o6022
                or (b['device_major'],b['device_minor'])!=(m['device_major'],m['device_minor'])
                or (m['start'],m['end']) in seen):
            return False
        seen.add((m['start'],m['end']))
    return True

'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();root=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool')
 p=root/'native_perf_mapped_images.py';s=p.read_text().replace('def __init__(self, root, fixture_only, handle_factory):','def __init__(self, root, fixture_only, handle_factory, artifact_owner_uid):',1)
 s=s.replace('        self._handle_factory = handle_factory','        self._handle_factory = handle_factory\n        if type(artifact_owner_uid) is not int or not 0<=artifact_owner_uid<2**32:\n            raise GuardError(\'invalid declared artifact owner\')\n        self._artifact_owner_uid = artifact_owner_uid',1)
 s=s.replace('def live(cls):','def live(cls, *, artifact_owner_uid):',1).replace("return cls(Path('/proc'), False, _PidHandle)","if artifact_owner_uid == 0:\n            raise GuardError('original unprivileged artifact owner required')\n        return cls(Path('/proc'), False, _PidHandle, artifact_owner_uid)",1)
 s=s.replace('def fixture(cls, root, handle_factory):','def fixture(cls, root, handle_factory, *, artifact_owner_uid=None):',1).replace('return cls(Path(root).resolve(strict=True), True, handle_factory)','return cls(Path(root).resolve(strict=True), True, handle_factory,\n                   os.getuid() if artifact_owner_uid is None else artifact_owner_uid)',1)
 s=s.replace('before.st_uid not in {0, os.getuid()}','before.st_uid not in {0, self._artifact_owner_uid}',1);p.write_text(s)
 p=root/'test_native_perf_mapped_images.py';s=p.read_text().replace('MappedImageReader.live()','MappedImageReader.live(artifact_owner_uid=os.getuid())');p.write_text(s)
 p=root/'native_perf_session.py';s=p.read_text().replace('_api().mapped.MappedImageReader.live(),PidHandle','_api().mapped.MappedImageReader.live(artifact_owner_uid=spec.controller_uid),PidHandle',1)
 s=s.replace("or index+1<len(nodes) and node['parent_pid']!=nodes[index+1].get('pid')", "or index+1<len(nodes) and (type(nodes[index+1]) is not dict or node['parent_pid']!=nodes[index+1].get('pid'))",1)
 a=s.index('\ndef admit_mapped_report(');s=s[:a]+'\n'+validation+s[a:]
 s=s.replace("    for item in native:\n", "    if not _mapped_payload_schema(obs,spec):\n        raise SessionError('mapped nested payload schema differs')\n    for item in native:\n",1);p.write_text(s)
 p=root/'test_native_perf_session.py';s=p.read_text().replace('mapped.MappedImageReader.fixture(root,FixtureHandle),FixtureHandle','mapped.MappedImageReader.fixture(root,FixtureHandle,artifact_owner_uid=spec.controller_uid),FixtureHandle');p.write_text(s);lease.verify_identity()
