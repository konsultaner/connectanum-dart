from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
addition=r'''
def _role_target(spec, target):
    required={'role','pid','start_ticks','exe_path','exe_sha256','native_path','native_sha256','argv_hex'}
    if (type(target) is not dict or set(target)!=required or target['role'] not in ('client','server')
            or not _int(target['pid'],1) or target['pid'] in (spec.controller_pid,spec.wrapper_pid)
            or not _api().mapped._u64_text(target['start_ticks']) or target['start_ticks']=='0'
            or not all(_digest(target[k]) for k in ('exe_sha256','native_sha256'))
            or not all(type(target[k]) is str and len(target[k])<=2048 and Path(target[k]).is_absolute() for k in ('exe_path','native_path'))
            or type(target['argv_hex']) is not list or not 1<=len(target['argv_hex'])<=256
            or any(type(v) is not str or len(v)>4096 or len(v)%2 or re.fullmatch('[0-9a-f]*',v) is None for v in target['argv_hex'])
            or not target['argv_hex'][0] or len(_bytes(target))>4096):
        raise SessionError('invalid bounded mapped-role target')
    argv=tuple(bytes.fromhex(v) for v in target['argv_hex'])
    if any(b'\0' in v for v in argv):
        raise SessionError('mapped role argv contains NUL')
    return argv


def _collect_mapped_with_readers(spec,target,reader,mapped_reader,handle_factory):
    argv=_role_target(spec,target)
    result={'fixture_only':reader.fixture_only,'capture_ready':False,'lineage':[], 'raw_evidence':reader.evidence}
    handles=[]
    try:
        if type(reader.fixture_only) is not bool or reader.fixture_only != mapped_reader._fixture_only:
            raise SessionError('mapped reader provenance differs')
        pid=target['pid'];seen=set()
        for depth in range(8):
            if pid in seen:
                raise SessionError('positive parent chain cycle')
            seen.add(pid);handle=handle_factory(pid);handles.append(handle);handle.require_alive()
            path=Path(str(pid));cookie=reader._process_stat(path/'stat',pid)
            status=reader._read(path/'status')
            uid,gid=reader_module_credentials(status)
            if uid!=(spec.controller_uid,)*4 or gid!=(spec.controller_gid,)*4:
                raise SessionError('positive ancestor credentials differ')
            _identity,digest=reader._image(path/'exe')
            if not depth and (cookie.start_ticks!=int(target['start_ticks']) or digest!=target['exe_sha256']):
                raise SessionError('mapped target process differs')
            node={'pid':pid,'parent_pid':cookie.parent_pid,'start_ticks':str(cookie.start_ticks),
                  'uid':spec.controller_uid,'gid':spec.controller_gid,'image_sha256':digest}
            result['lineage'].append(node)
            if pid==spec.wrapper_pid:
                if (cookie.start_ticks!=spec.wrapper_start or cookie.parent_pid!=spec.controller_pid or digest!=spec.driver_sha):
                    raise SessionError('actual post-exec driver anchor differs')
                break
            pid=cookie.parent_pid
            if pid<=0:
                raise SessionError('positive parent chain does not reach driver')
        else:
            raise SessionError('positive parent depth limit')
        observation=mapped_reader.observe(pid=target['pid'],start_ticks=int(target['start_ticks']),
            executable_path=target['exe_path'],executable_sha256=target['exe_sha256'],
            native_path=target['native_path'],native_sha256=target['native_sha256'],expected_argv=argv,
            uid=spec.controller_uid,gid=spec.controller_gid)
        result['observation']=observation
        if observation.get('observed') is not True:
            raise SessionError('mapped backing observation refused; raw evidence retained')
        for node,handle in zip(result['lineage'],handles):
            path=Path(str(node['pid']));cookie=reader._process_stat(path/'stat',node['pid'])
            uid,gid=reader_module_credentials(reader._read(path/'status'))
            _identity,digest=reader._image(path/'exe');handle.require_alive()
            if (cookie.parent_pid!=node['parent_pid'] or str(cookie.start_ticks)!=node['start_ticks']
                    or digest!=node['image_sha256'] or uid!=(spec.controller_uid,)*4 or gid!=(spec.controller_gid,)*4):
                raise SessionError('positive parent chain changed across observation')
    except BaseException as error:
        result['error']={'type':type(error).__name__,'errno':getattr(error,'errno',None),'reason':str(error)}
    finally:
        for handle in handles:
            try:handle.close()
            except BaseException as error:
                result.setdefault('cleanup_errors',[]).append({'type':type(error).__name__,'errno':getattr(error,'errno',None)})
        if result.get('cleanup_errors') and 'error' not in result:
            result['error']={'type':'SessionError','errno':None,'reason':'lineage descriptor cleanup uncertain'}
        # Exact raw proc bytes stay base64; statidentity numbers remain JSON-safe.
        for entry in reader.evidence:
            if 'identity' in entry:entry['identity']=[str(v) for v in entry['identity']]
    return result


def reader_module_credentials(status):
    return _api().proc._credentials(status,'Uid'),_api().proc._credentials(status,'Gid')


def live_mapped_audit(spec,target):
    _check_root_linux()
    return _collect_mapped_with_readers(spec,target,_api().proc.ProcReader(),
                                       _api().mapped.MappedImageReader.live(),PidHandle)


def run_mapped_auditor(spec,request_id,*,fixture_peer=None,identity=None,collector=None,transform=None):
    if re.fullmatch('[0-9a-f]{32}',request_id or '') is None:
        raise SessionError('invalid mapped request ID')
    if fixture_peer is None:
        _check_root_linux()
        if any(v is not None for v in (identity,collector,transform)):
            raise SessionError('live role cannot select fixture injections')
    mode='mapped-'+request_id
    directory=PrivateDirectory(spec.directory,spec.controller_uid);sock=None
    try:
        sock,wire=connect_wire(spec,'r'+request_id+'.sock',fixture_peer=fixture_peer)
        helper_preface(wire,spec,mode,(identity or actual_identity)())
        followup=new_round(sock,wire,spec=spec,as_controller=False)
        with followup.once():
            request=followup.read_frame();expected={'event':'mapped_request',**spec.context(mode)}
            if (set(request)!=set(expected)|{'target','target_sha256'}
                    or any(type(request[k]) is not type(v) or request[k]!=v for k,v in expected.items())
                    or request['target_sha256']!=_sha(_bytes(request['target']))):
                raise SessionError('mapped request context differs')
            _role_target(spec,request['target'])
            report=(collector or (lambda value:live_mapped_audit(spec,value)))(request['target'])
            value={**report,'context':spec.context(mode),'target_sha256':request['target_sha256'],'role':request['target']['role']}
            if transform is not None:value=transform(value)
            receipt=write_report(directory,'r'+request_id+'.json',value)
            followup.send_frame({'event':'mapped_report',**spec.context(mode),'target_sha256':request['target_sha256'],'receipt':receipt})
    finally:
        primary=sys.exception()
        for action in ([sock.close] if sock is not None else [])+[directory.close]:
            try:action()
            except BaseException as secondary:
                if primary is not None:primary.add_note('mapped helper cleanup failure: '+repr(secondary))
                else:raise


def admit_mapped_report(spec,report,request_id,target,*,fixture_only=False):
    _role_target(spec,target)
    required={'fixture_only','capture_ready','lineage','raw_evidence','observation','context','target_sha256','role'}
    if (type(report) is not dict or set(report)!=required or report['fixture_only'] is not fixture_only
            or report['capture_ready'] is not False or not _same(report['context'],spec.context('mapped-'+request_id))
            or report['target_sha256']!=_sha(_bytes(target)) or report['role']!=target['role']
            or type(report['raw_evidence']) is not list or type(report['lineage']) is not list
            or not 2<=len(report['lineage'])<=8):
        raise SessionError('mapped report context/provenance/schema refused')
    nodes=report['lineage']
    for index,node in enumerate(nodes):
        if (type(node) is not dict or set(node)!={'pid','parent_pid','start_ticks','uid','gid','image_sha256'}
                or any(not _int(node[k],1) for k in ('pid','parent_pid'))
                or not _api().mapped._u64_text(node['start_ticks']) or node['start_ticks']=='0'
                or type(node['uid']) is not int or node['uid']!=spec.controller_uid
                or type(node['gid']) is not int or node['gid']!=spec.controller_gid or not _digest(node['image_sha256'])
                or index+1<len(nodes) and node['parent_pid']!=nodes[index+1].get('pid')):
            raise SessionError('mapped positive lineage schema differs')
    if (len({n['pid'] for n in nodes})!=len(nodes) or nodes[0]['pid']!=target['pid']
            or nodes[0]['start_ticks']!=target['start_ticks'] or nodes[0]['image_sha256']!=target['exe_sha256']
            or nodes[-1]['pid']!=spec.wrapper_pid or nodes[-1]['start_ticks']!=str(spec.wrapper_start)
            or nodes[-1]['parent_pid']!=spec.controller_pid or nodes[-1]['image_sha256']!=spec.driver_sha):
        raise SessionError('mapped positive lineage anchor differs')
    obs=report['observation']
    if (type(obs) is not dict or obs.get('fixture_only') is not fixture_only
            or obs.get('capture_ready') is not False or obs.get('observed') is not True
            or obs.get('scope')!='mapped_backing_file_observation_only' or obs.get('cleanup_errors')!=[]
            or 'error' in obs or type(obs.get('process')) is not dict):
        raise SessionError('mapped backing report refused')
    p=obs['process'];native=obs.get('native_mappings')
    if (not _same(p,{'pid':target['pid'],'parent_pid':nodes[0]['parent_pid'],'start_ticks':target['start_ticks'],
            'uid':spec.controller_uid,'gid':spec.controller_gid,'argv_hex':target['argv_hex'],'executable_sha256':target['exe_sha256']})
            or type(native) is not list or not 1<=len(native)<=64 or type(obs.get('mappings')) is not list
            or len(obs['mappings'])>8192 or type(obs.get('raw_evidence')) is not list):
        raise SessionError('mapped process or native schema differs')
    for item in native:
        if (type(item) is not dict or set(item)!={'mapping','backing'} or type(item['mapping']) is not dict
                or type(item['backing']) is not dict or item['backing'].get('sha256')!=target['native_sha256']
                or item['mapping'] not in obs['mappings'] or 'x' not in item['mapping'].get('perms','')):
            raise SessionError('mapped native identity differs')
    return report  # Supporting evidence only; never an arming/readiness token.


class MappedAuditExchange:
    """One terminal scoped request plus independently owned natural-exit waits."""
    def __init__(self,spec,backend,request_id,target):
        if (not isinstance(request_id,str) or re.fullmatch('[0-9a-f]{32}',request_id) is None
                or type(backend.fixture_only) is not bool):
            raise SessionError('invalid mapped transport declaration')
        _role_target(spec,target)
        self.spec,self.backend,self.request_id=spec,backend,request_id
        self._target=_json(_bytes(target));self.target_sha=_sha(_bytes(self._target));self.fixture_only=backend.fixture_only
        self.directory=PrivateDirectory(spec.directory,spec.controller_uid)
        self.started=self.launch_attempted=self.launch_returned=self.boot_verified=self.finalized=False
        self.child=self.handle=self.report=self.launcher_exit=self.peer_exited=None
        self.report_admitted=self.ownership_complete=self.closed=False
        self.errors=[]

    def start(self):
        if self.started or self.backend.fixture_only is not self.fixture_only:
            raise SessionError('mapped request is terminal or provenance changed')
        self.started=True;rid=self.request_id;mode='mapped-'+rid
        sock=listener=None;wires=[]
        try:
            write_report(self.directory,'a'+rid+'.json',{'context':self.spec.context(mode),'target':self._target,'target_sha256':self.target_sha})
            listener=PrivateListener(self.directory,'r'+rid+'.sock')
            self.launch_attempted=True
            self.child=self.backend.launch('mapped',rid);self.launch_returned=True
            sock,wire=self.backend.accept(listener,self.child);wires.append(wire)
            if wire.fixture_only is not self.fixture_only:raise SessionError('mapped peer provenance differs')
            self.handle=self.backend.handle(wire.peer);self.handle.require_alive()
            controller_preface(wire,self.spec,mode);self.boot_verified=True
            followup=new_round(sock,wire,spec=self.spec,as_controller=True);wires.append(followup)
            with followup.once():
                followup.send_frame({'event':'mapped_request',**self.spec.context(mode),'target':self._target,'target_sha256':self.target_sha})
                response=followup.read_frame();expected={'event':'mapped_report',**self.spec.context(mode),'target_sha256':self.target_sha}
                if (set(response)!=set(expected)|{'receipt'} or any(type(response[k]) is not type(v) or response[k]!=v for k,v in expected.items())
                        or type(response['receipt']) is not dict or response['receipt'].get('name')!='r'+rid+'.json'):
                    raise SessionError('mapped response receipt context differs')
                self.report=read_report(self.directory,response['receipt'])
                admit_mapped_report(self.spec,self.report,rid,self._target,fixture_only=self.fixture_only)
                self.report_admitted=True
            return self.report
        finally:
            primary=sys.exception()
            actions=([sock.close] if sock is not None else [])+([listener.close] if listener is not None else [])
            actions.append(lambda:write_report(self.directory,'t'+rid+'.json',{'context':self.spec.context(mode),'fixture_only':self.fixture_only,
                'rounds':[{'peer':dataclasses.asdict(w.peer),'state':w.state,'raw_evidence':w.evidence} for w in wires]}))
            for action in actions:
                try:action()
                except BaseException as error:
                    self.errors.append({'type':type(error).__name__,'errno':getattr(error,'errno',None)})
                    if primary is not None:primary.add_note('mapped protocol cleanup/evidence failure: '+repr(error))
                    else:primary=error
            if sys.exception() is None and primary is not None:raise primary

    def finish(self,timeout=10.0):
        if (not self.started or self.finalized or type(timeout) not in (int,float)
                or not math.isfinite(timeout) or not 0<timeout<=60):
            raise SessionError('invalid terminal mapped natural wait')
        deadline=time.monotonic()+timeout
        if self.child is not None and self.launcher_exit is None:
            self.launcher_exit=self.backend.wait_sampler(self.child,max(.000001,deadline-time.monotonic()))
        if self.handle is not None and self.peer_exited is None:
            self.handle.wait_exited(max(0,deadline-time.monotonic()));self.peer_exited=True
        self.ownership_complete=(not self.launch_attempted or self.launch_returned and self.launcher_exit is not None
                                  and self.boot_verified and self.peer_exited is True)
        self.finalized=True  # BEFORE exclusive publication; partial is terminal.
        value={'context':self.spec.context('mapped-'+self.request_id),'fixture_only':self.fixture_only,'capture_ready':False,
               'launcher_exit':self.launcher_exit,'peer_exited':self.peer_exited,'boot_verified':self.boot_verified,
               'ownership_complete':self.ownership_complete,'report_admitted':self.report_admitted,'errors':self.errors}
        write_report(self.directory,'x'+self.request_id+'.json',value)
        return value

    def close_metadata(self):
        if self.closed:return
        if not self.finalized or not self.ownership_complete:
            raise SessionError('mapped observer ownership pending or quarantined')
        self.closed=True
        handle,self.handle=self.handle,None
        directory,self.directory=self.directory,None
        primary=None
        for action in ([handle.close] if handle is not None else [])+[directory.close]:
            try:action()
            except BaseException as error:
                self.errors.append({'type':type(error).__name__,'errno':getattr(error,'errno',None)})
                if primary is None:primary=error
                else:primary.add_note('mapped metadata secondary close failure: '+repr(error))
        if primary is not None:
            self.ownership_complete=False
            raise primary

'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/native_perf_session.py');s=p.read_text()
 s=s.replace("'native_perf_proc_witness', 'native_perf_handoff', 'native_perf_session', 'native_perf_input_census')","'native_perf_proc_witness', 'native_perf_handoff', 'native_perf_session', 'native_perf_input_census',\n                                        'native_perf_build_producer','native_perf_metadata','native_perf_mapped_images')",1)
 s=s.replace("MODULE_ORDER = ('native_perf_guard', 'native_perf_blocked_exec', 'native_perf_proc_witness', 'native_perf_handoff')","MODULE_ORDER = ('native_perf_guard', 'native_perf_blocked_exec', 'native_perf_proc_witness', 'native_perf_handoff', 'native_perf_mapped_images')",1)
 s=s.replace("handoff=importlib.import_module('native_perf_handoff'))","handoff=importlib.import_module('native_perf_handoff'),\n        mapped=importlib.import_module('native_perf_mapped_images'))",1)
 s=s.replace("if mode not in ('helper', 'audit') or mode == 'audit' and phase not in ('before-enable', 'before-go'):","if (mode not in ('helper', 'audit', 'mapped') or mode == 'audit' and phase not in ('before-enable', 'before-go')\n            or mode == 'mapped' and (not isinstance(phase,str) or re.fullmatch('[0-9a-f]{32}',phase) is None)):",1)
 s=s.replace('        self.refusal_completion = None','        self.refusal_completion = None\n        self.mapped_operations = []',1)
 a=s.index('    def _save(self, basename, mode, wires):')
 method='''    def start_mapped(self,request_id,target):
        if self.release_attempted is not True:
            raise SessionError('mapped role requests require a GO attempt')
        operation=MappedAuditExchange(self.spec,self.backend,request_id,target)
        self.mapped_operations.append(operation)  # Retain owned actor even if start raises.
        operation.start()
        return operation

'''
 s=s[:a]+method+s[a:]
 a=s.index('    def close_metadata(self):',s.index('class SessionController'))
 s=s[:a]+s[a:].replace("    def close_metadata(self):\n", "    def close_metadata(self):\n        if any(not op.finalized or not op.ownership_complete for op in self.mapped_operations):\n            raise SessionError('mapped observer actors remain owned or quarantined')\n        for operation in self.mapped_operations:operation.close_metadata()\n",1)
 a=s.index('\ndef main(argv=None):');s=s[:a]+'\n'+addition+s[a:]
 s=s.replace("choices=('helper', 'audit')","choices=('helper', 'audit', 'mapped')",1).replace("parser.add_argument('--phase', choices=('before-enable', 'before-go'))","parser.add_argument('--phase')",1)
 s=s.replace("    else:\n        run_auditor(spec, args.phase)","    elif args.mode == 'audit':\n        run_auditor(spec, args.phase)\n    else:\n        run_mapped_auditor(spec,args.phase)",1)
 p.write_text(s);lease.verify_identity()
