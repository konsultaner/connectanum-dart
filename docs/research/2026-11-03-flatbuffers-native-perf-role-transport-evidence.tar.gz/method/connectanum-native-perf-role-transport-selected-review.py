class MappedAuditExchange:
    """One terminal scoped request plus independently owned natural-exit waits."""
    def __init__(self,spec,backend,request_id,target):
        if (not isinstance(request_id,str) or re.fullmatch('[0-9a-f]{32}',request_id) is None
                or type(backend.fixture_only) is not bool):
            raise SessionError('invalid mapped transport declaration')
        _role_target(spec,target)
        self.spec,self.backend,self.request_id=spec,backend,request_id
        self._target=_json(_bytes(target));self.target_sha=_sha(_bytes(self._target));self.fixture_only=backend.fixture_only
        self.directory=PrivateDirectory(spec.directory,spec.controller_uid)
        self.started=self.launch_attempted=self.launch_returned=self.boot_verified=self.finalized=False
        self.child=self.handle=self.report=self.launcher_exit=self.peer_exited=None
        self.report_admitted=self.ownership_complete=self.closed=False
        self.errors=[]

    def start(self):
        if self.started or self.backend.fixture_only is not self.fixture_only:
            raise SessionError('mapped request is terminal or provenance changed')
        self.started=True;rid=self.request_id;mode='mapped-'+rid
        sock=listener=None;wires=[]
        try:
            write_report(self.directory,'a'+rid+'.json',{'context':self.spec.context(mode),'target':self._target,'target_sha256':self.target_sha})
            listener=PrivateListener(self.directory,'r'+rid+'.sock')
            self.launch_attempted=True
            self.child=self.backend.launch('mapped',rid);self.launch_returned=True
            sock,wire=self.backend.accept(listener,self.child);wires.append(wire)
            if wire.fixture_only is not self.fixture_only:raise SessionError('mapped peer provenance differs')
            self.handle=self.backend.handle(wire.peer);self.handle.require_alive()
            controller_preface(wire,self.spec,mode);self.boot_verified=True
            followup=new_round(sock,wire,spec=self.spec,as_controller=True);wires.append(followup)
            with followup.once():
                followup.send_frame({'event':'mapped_request',**self.spec.context(mode),'target':self._target,'target_sha256':self.target_sha})
                response=followup.read_frame();expected={'event':'mapped_report',**self.spec.context(mode),'target_sha256':self.target_sha}
                if (set(response)!=set(expected)|{'receipt'} or any(type(response[k]) is not type(v) or response[k]!=v for k,v in expected.items())
                        or type(response['receipt']) is not dict or response['receipt'].get('name')!='r'+rid+'.json'):
                    raise SessionError('mapped response receipt context differs')
                self.report=read_report(self.directory,response['receipt'])
                admit_mapped_report(self.spec,self.report,rid,self._target,fixture_only=self.fixture_only)
                self.report_admitted=True
            return self.report
        finally:
            primary=sys.exception()
            actions=([sock.close] if sock is not None else [])+([listener.close] if listener is not None else [])
            actions.append(lambda:write_report(self.directory,'t'+rid+'.json',{'context':self.spec.context(mode),'fixture_only':self.fixture_only,
                'rounds':[{'peer':dataclasses.asdict(w.peer),'state':w.state,'raw_evidence':w.evidence} for w in wires]}))
            for action in actions:
                try:action()
                except BaseException as error:
                    self.errors.append({'type':type(error).__name__,'errno':getattr(error,'errno',None)})
                    if primary is not None:primary.add_note('mapped protocol cleanup/evidence failure: '+repr(error))
                    else:primary=error
            if sys.exception() is None and primary is not None:raise primary

    def finish(self,timeout=10.0):
        if (not self.started or self.finalized or type(timeout) not in (int,float)
                or not math.isfinite(timeout) or not 0<timeout<=60):
            raise SessionError('invalid terminal mapped natural wait')
        deadline=time.monotonic()+timeout
        if self.child is not None and self.launcher_exit is None:
            self.launcher_exit=self.backend.wait_sampler(self.child,max(.000001,deadline-time.monotonic()))
        if self.handle is not None and self.peer_exited is None:
            self.handle.wait_exited(max(0,deadline-time.monotonic()));self.peer_exited=True
        self.ownership_complete=(not self.launch_attempted or self.launch_returned and self.launcher_exit is not None
                                  and self.boot_verified and self.peer_exited is True)
        self.finalized=True  # BEFORE exclusive publication; partial is terminal.
        value={'context':self.spec.context('mapped-'+self.request_id),'fixture_only':self.fixture_only,'capture_ready':False,
               'launcher_exit':self.launcher_exit,'peer_exited':self.peer_exited,'boot_verified':self.boot_verified,
               'ownership_complete':self.ownership_complete,'report_admitted':self.report_admitted,'errors':self.errors}
        write_report(self.directory,'x'+self.request_id+'.json',value)
        return value

    def close_metadata(self):
        if self.closed:return
        if not self.finalized or not self.ownership_complete:
            raise SessionError('mapped observer ownership pending or quarantined')
        self.closed=True
        handle,self.handle=self.handle,None
        directory,self.directory=self.directory,None
        primary=None
        for action in ([handle.close] if handle is not None else [])+[directory.close]:
            try:action()
            except BaseException as error:
                self.errors.append({'type':type(error).__name__,'errno':getattr(error,'errno',None)})
                if primary is None:primary=error
                else:primary.add_note('mapped metadata secondary close failure: '+repr(error))
        if primary is not None:
            self.ownership_complete=False
            raise primary

