from pathlib import Path
import sys
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease
new=r'''
    def mapped_setup(self, *, delay=0, corrupt=None):
        import native_perf_mapped_images as mapped
        root=self.directory/'role-proc';role=root/'300';anchor=root/'99999'
        for p in (role,anchor):(p/'map_files').mkdir(parents=True)
        exe=self.directory/'role-dart';native=self.directory/'role-native';driver=self.directory/'role-driver'
        for p,suffix in [(exe,b'dart'),(native,b'native'),(driver,b'driver')]:
            p.write_bytes(b'\x7fELF\x02\x01'+bytes(58)+suffix);p.chmod(0o600)
        spec=dataclasses.replace(self.spec(),driver_path=str(driver),driver_sha=session._sha(driver.read_bytes()))
        argv=(b'dart',b'worker',b'',b'\xff')
        def process(p,pid,parent,start,image,args):
            fields=['S',str(parent)]+['0']*17+[str(start)]
            (p/'stat').write_text(f'{pid} (role fixture) '+ ' '.join(fields)+'\n')
            (p/'status').write_text('Uid:\t'+ '\t'.join([str(spec.controller_uid)]*4)+'\nGid:\t'+'\t'.join([str(spec.controller_gid)]*4)+'\n')
            (p/'cmdline').write_bytes(b'\0'.join(args)+b'\0');(p/'exe').symlink_to(image)
        process(role,300,99999,901,exe,argv);process(anchor,99999,spec.controller_pid,123,driver,(b'driver',))
        st=native.stat();(role/'maps').write_text(f'1000-2000 r-xp 0 {os.major(st.st_dev):x}:{os.minor(st.st_dev):x} {st.st_ino} /ignored (deleted)\n')
        (role/'map_files'/'1000-2000').symlink_to(native)
        target={'role':'client','pid':300,'start_ticks':'901','exe_path':str(exe),'exe_sha256':session._sha(exe.read_bytes()),'native_path':str(native),'native_sha256':session._sha(native.read_bytes()),'argv_hex':[v.hex() for v in argv]}
        backend=FixtureBackend(spec,self.log.fileno());backend.mapped_delay=delay;backend.mapped_corrupt=corrupt
        def collect(request):
            return session._collect_mapped_with_readers(spec,request,session._api().proc.ProcReader.fixture(root),mapped.MappedImageReader.fixture(root,FixtureHandle),FixtureHandle)
        backend.mapped_collector=collect;self.backends.append(backend)
        return spec,backend,target,root

    def mapped_exchange(self, *, delay=0, corrupt=None):
        spec,backend,target,root=self.mapped_setup(delay=delay,corrupt=corrupt)
        op=session.MappedAuditExchange(spec,backend,'d'*32,target)
        # OWN fixture fallback closes only inert metadata after all known children
        # have been naturally reaped by each test. No live cleanup workaround.
        def close_fixture():
            if op.handle is not None:op.handle.close()
            if op.directory is not None:op.directory.close()
        self.addCleanup(close_fixture)
        return op,target,root

    def test_mapped_transport_positive_natural_reaping_and_raw_context(self):
        op,target,_=self.mapped_exchange();r=op.start()
        self.assertTrue(r['observation']['observed']);self.assertFalse(r['capture_ready']);self.assertTrue(r['fixture_only'])
        self.assertEqual([p['pid'] for p in r['lineage']],[300,99999]);self.assertEqual(r['target_sha256'],session._sha(session._bytes(target)))
        result=op.finish(1);self.assertTrue(result['ownership_complete']);self.assertEqual(result['launcher_exit'],0);self.assertTrue(result['peer_exited'])
        op.close_metadata()

    def test_mapped_transport_terminal_existing_attempt_no_relaunch(self):
        op,_,_=self.mapped_exchange();path=self.directory/('a'+'d'*32+'.json');path.write_bytes(b'partial-terminal')
        with self.assertRaises(FileExistsError):op.start()
        self.assertEqual(path.read_bytes(),b'partial-terminal');self.assertEqual(len(op.backend.children),0)
        with self.assertRaises(SessionError):op.start()
        op.finish(1);op.close_metadata()

    def test_mapped_transport_requires_post_go_controller_state(self):
        spec,backend,target,_=self.mapped_setup();controller=session.SessionController(spec,backend)
        self.addCleanup(controller.directory.close)
        with self.assertRaises(SessionError):controller.start_mapped('d'*32,target)
        self.assertEqual(len(backend.children),0)

    def test_mapped_transport_fixture_cannot_admit_live(self):
        op,target,_=self.mapped_exchange();r=op.start()
        with self.assertRaises(SessionError):session.admit_mapped_report(op.spec,r,op.request_id,target,fixture_only=False)
        op.finish(1);op.close_metadata()

    def test_mapped_transport_pending_natural_wait_no_second_launch(self):
        op,_,_=self.mapped_exchange(delay=.15);op.start()
        with self.assertRaises(SessionError):op.finish(.005)
        self.assertFalse(op.finalized);self.assertEqual(len(op.backend.children),1)
        with self.assertRaises(SessionError):op.close_metadata()
        op.finish(1);op.close_metadata();self.assertEqual(len(op.backend.children),1)

    def test_mapped_transport_unknown_launch_quarantines_null_status(self):
        op,_,_=self.mapped_exchange()
        with patch.object(op.backend,'launch',side_effect=OSError(5,'unconfirmed launch fault')):
            with self.assertRaises(OSError):op.start()
        r=op.finish(1);self.assertIsNone(r['launcher_exit']);self.assertFalse(r['ownership_complete'])
        with self.assertRaises(SessionError):op.close_metadata()

    def test_mapped_transport_partial_final_report_terminal(self):
        op,_,_=self.mapped_exchange();op.start();real=session.write_report
        def partial(directory,name,value):
            if name.startswith('x'):
                with directory.name(name).open('xb') as f:f.write(b'partial')
                raise OSError(errno.ENOSPC,'synthetic report failure')
            return real(directory,name,value)
        with patch.object(session,'write_report',side_effect=partial):
            with self.assertRaises(OSError):op.finish(1)
        with self.assertRaises(SessionError):op.finish(1)
        self.assertEqual((self.directory/('x'+'d'*32+'.json')).read_bytes(),b'partial');op.close_metadata()

    def test_mapped_transport_broken_positive_parent_chain_refuses(self):
        op,_,root=self.mapped_exchange();p=root/'300'/'stat';p.write_text(p.read_text().replace('S 99999 ','S 77777 '))
        with self.assertRaises(SessionError):op.start()
        self.assertIsNotNone(op.report);self.assertIn('error',op.report)
        op.finish(1);op.close_metadata()

    def test_mapped_transport_parent_cycle_refuses(self):
        op,_,root=self.mapped_exchange();p=root/'300'/'stat';p.write_text(p.read_text().replace('S 99999 ','S 300 '))
        with self.assertRaises(SessionError):op.start()
        self.assertIn('cycle',op.report['error']['reason']);op.finish(1);op.close_metadata()

    def test_mapped_transport_bundle_binds_all18_exact_sources(self):
        self.assertEqual(len(session.BUNDLE_FILES),18)
        self.assertIn('native_perf_mapped_images',session.MODULE_ORDER)
        self.assertIn('tool/native_perf_build_producer.py',session.BUNDLE_FILES)

    def test_mapped_transport_oversize_target_before_any_launch(self):
        spec,backend,target,_=self.mapped_setup();target['argv_hex']=['ab'*5000]
        with self.assertRaises(SessionError):session.MappedAuditExchange(spec,backend,'d'*32,target)
        self.assertEqual(len(backend.children),0);self.assertFalse((self.directory/('a'+'d'*32+'.json')).exists())

    def test_mapped_transport_wrong_context_retained_and_owned_exit(self):
        def corrupt(r):r['target_sha256']='f'*64;return r
        op,_,_=self.mapped_exchange(corrupt=corrupt)
        with self.assertRaises(SessionError):op.start()
        self.assertEqual(op.report['target_sha256'],'f'*64)
        result=op.finish(1);self.assertTrue(result['ownership_complete']);self.assertFalse(result['report_admitted']);op.close_metadata()
'''
with local_resource_lease(exclusive=True) as lease:
 lease.verify_identity();p=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart/tool/test_native_perf_session.py');s=p.read_text()
 branch='''                elif mode == 'mapped':
                    session.run_mapped_auditor(self.spec, phase, fixture_peer=peer, identity=self._identity,
                                              collector=self.mapped_collector, transform=getattr(self,'mapped_corrupt',None))
                    time.sleep(getattr(self,'mapped_delay',0))
'''
 s=s.replace("                else:\n                    directory = PrivateDirectory",branch+"                else:\n                    directory = PrivateDirectory",1)
 s=s+new if "if __name__" not in s else s.replace("\nif __name__",new+"\nif __name__",1)
 p.write_text(s);lease.verify_identity()
r=Path('/tmp/connectanum-native-perf-metadata-run.py').read_text().replace('native-perf-metadata-','native-perf-role-transport-').replace('test_native_perf_metadata.py','test_native_perf_session.py').replace('CONNECTANUM_PERF_METADATA_FIXTURES','CONNECTANUM_PERF_SESSION_FIXTURE_EVIDENCE').replace('synthetic PERFILE2 files and OWN regular filesystem guards only','changed Session source/bootstrap and OWN fork/listener synthetic role transport only')
Path('/tmp/connectanum-native-perf-role-transport-run.py').write_text(r)
