"""Own source-frozen command evidence, not capture or canonical admission.

Caller holds the official exclusive lease. Only fixed live factories may select
canonical/production recipes; fixture commands are labelled in every receipt.
A waited child and log snapshot do not prove all descendants exited, SDK identity,
complete canonical validation, loader validity, or loaded role/native-image bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time
from types import MappingProxyType


class ProducerError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise ProducerError('Python 3.11 or newer required before producer IO')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _regular_hash(path, maximum=1024**3, *, owners=None):
    owners={os.getuid()} if owners is None else owners
    path=Path(path)
    if not path.is_absolute() or path.resolve(strict=True)!=path:
        raise ProducerError('input path must be canonical without symlinks')
    before=path.stat(follow_symlinks=False)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
            raise ProducerError('input type/owner/mode/size differs')
        if identity(before)!=identity(info):raise ProducerError('input changed before read')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            h.update(part);count+=len(part)
            if count>maximum:raise ProducerError('input grew beyond bound')
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info):
            raise ProducerError('input changed during read')
        return h.hexdigest()
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('input close failed: '+repr(e))


def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))


def _write_json(path,value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode())
        f.flush();os.fsync(f.fileno())


VERSION_ARGS={'git':('--version',),'python3':('--version',),'bash':('--version',),
              'dart':('--version',),'cargo':('--version',),'rustc':('--version','--verbose')}
TOOL_FIELDS={'entry','target','sha256','version_prefix','entry_device','entry_inode','entry_mode',
             'entry_uid','entry_link','target_device','target_inode','target_mode','target_uid'}


def describe_tool(name,version_prefix,*,lookup_path=None):
    """Read-only intent preparation; executes no program and authenticates no image."""
    if name not in VERSION_ARGS or type(version_prefix) is not str or not 0<len(version_prefix)<=256 or '\0' in version_prefix or '\n' in version_prefix:
        raise ProducerError('invalid fixed tool/version declaration')
    entry=shutil.which(name,path=lookup_path)
    if entry is None or not Path(entry).is_absolute():raise ProducerError('tool PATH resolution missing or nonabsolute: '+name)
    entry=Path(entry);before=entry.lstat();target=entry.resolve(strict=True)
    if not (stat.S_ISREG(before.st_mode) or stat.S_ISLNK(before.st_mode)) or before.st_uid not in (0,os.getuid()):
        raise ProducerError('tool entry type/owner differs: '+name)
    info=target.stat()
    if not info.st_mode&0o111:raise ProducerError('tool target is not executable: '+name)
    digest=_regular_hash(target,maximum=512*1024**2,owners={0,os.getuid()})
    fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
    link=os.readlink(entry) if stat.S_ISLNK(before.st_mode) else None
    if fields(before)!=fields(entry.lstat()) or target!=entry.resolve(strict=True) or fields(info)!=fields(target.stat()):
        raise ProducerError('tool entry/target changed during observation: '+name)
    return {'entry':str(entry),'target':str(target),'sha256':digest,'version_prefix':version_prefix,
            'entry_device':before.st_dev,'entry_inode':before.st_ino,'entry_mode':before.st_mode,'entry_uid':before.st_uid,'entry_link':link,
            'target_device':info.st_dev,'target_inode':info.st_ino,'target_mode':info.st_mode,'target_uid':info.st_uid}


def _tool_table(value):
    if value is None:return MappingProxyType({})
    if type(value) is not dict or not 0<len(value)<=len(VERSION_ARGS):raise ProducerError('invalid tool table')
    result={}
    integers={'entry_device','entry_inode','entry_mode','entry_uid','target_device','target_inode','target_mode','target_uid'}
    for name,spec in value.items():
        if type(name) is not str or name not in VERSION_ARGS or type(spec) is not dict or set(spec)!=TOOL_FIELDS:
            raise ProducerError('invalid fixed tool snapshot schema')
        if any(type(spec[k]) is not int or spec[k]<0 for k in integers) or any(type(spec[k]) is not str or not spec[k] for k in ('entry','target','sha256','version_prefix')) or (spec['entry_link'] is not None and type(spec['entry_link']) is not str):
            raise ProducerError('invalid typed tool snapshot')
        if (not re.fullmatch('[0-9a-f]{64}',spec['sha256']) or not Path(spec['entry']).is_absolute() or not Path(spec['target']).is_absolute()
            or not 0<len(spec['version_prefix'])<=256 or '\0' in spec['version_prefix'] or '\n' in spec['version_prefix']):raise ProducerError('invalid tool digest/path/version declaration')
        result[name]=MappingProxyType(dict(spec))
    return MappingProxyType(result)


def _required_tools(value):
    if type(value) is not dict or set(value)!=set(VERSION_ARGS):
        raise ProducerError('live recipe requires all six declared tool snapshots')


LOCK_PATHS={'pub':'pubspec.lock','transport':'native/transport/Cargo.lock','bench':'native/bench/Cargo.lock'}
CANONICAL_RECIPES=[['bin/verify']]
PRODUCTION_RECIPES=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                    ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']]


def _required_context(kwargs):
    if (type(kwargs.get('census_id')) is not str or not re.fullmatch('[0-9a-f]{32}',kwargs['census_id'])
        or type(kwargs.get('expected_sdk')) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',kwargs['expected_sdk'])
        or type(kwargs.get('config_bindings')) is not dict or not {'server','client'}<=set(kwargs['config_bindings'])):
        raise ProducerError('live recipe needs pre-child census/SDK/config context')


def _read_json(path,expected):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NONBLOCK|os.O_NOFOLLOW)
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:data=f.read(2*1024**2+1)
        if len(data)>2*1024**2 or _sha(data)!=expected:raise ProducerError('sealed JSON size/digest differs')
        def pairs(values):
            out={}
            for key,value in values:
                if key in out:raise ProducerError('duplicate JSON key')
                out[key]=value
            return out
        def constant(value):raise ProducerError('nonfinite JSON constant')
        try:result=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('malformed sealed JSON') from e
        if type(result) is not dict:raise ProducerError('sealed JSON must be an object')
        return result
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('sealed JSON close failed: '+repr(e))


def _dart_sdk(line):
    match=re.match(r'^Dart SDK version: ([0-9]+\.[0-9]+\.[0-9]+) \(stable\)(?: |$)',line)
    if match is None:raise ProducerError('stable Dart SDK line required')
    return match[1]


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None,tools=None,census_id=None,expected_sdk=None,config_bindings=None):
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        if ((census_id is None)!=(expected_sdk is None) or (census_id is not None and
            (type(census_id) is not str or not re.fullmatch('[0-9a-f]{32}',census_id) or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)))):
            raise ProducerError('invalid pre-child census/SDK context')
        config_bindings={} if config_bindings is None else config_bindings
        if (type(config_bindings) is not dict or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}',k) or type(v) is not str or v not in inputs for k,v in config_bindings.items())
            or (config_bindings and (expected_sdk is None or not {'server','client'}<=set(config_bindings)))):
            raise ProducerError('unbound pre-child config context')
        self.census_id=census_id;self.expected_sdk=expected_sdk;self.config_bindings=MappingProxyType(dict(config_bindings))
        self.evidence_complete=False;self.receipt_attempted=False;self.intent_sha256=None;self.result_sha256=None;self.journal_sha256=None
        self.repo=Path(repo);self.directory=Path(run_dir)
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.tools=_tool_table(tools)
        self.task_kinds=tuple(('tool_version',name) for name in sorted(self.tools))+tuple(('recipe',None) for _ in commands)
        self.commands=tuple((self.tools[name]['entry'],*VERSION_ARGS[name]) for name in sorted(self.tools))+tuple(tuple(a) for a in commands)
        self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.environment={**os.environ,**self.env_delta};self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            _write_json(self.directory/'intent.json',{'kind':'build-preparation-intent-v1','source_commit':source_commit,'runtime_commit':runtime_commit,
                        'census_id':self.census_id,'expected_sdk':self.expected_sdk,'config_bindings':dict(self.config_bindings),
                        'expected_archive_sha256':expected_archive_sha256,'inputs':dict(self.inputs),'tools':{k:dict(v) for k,v in self.tools.items()},
                        'commands':[list(a) for a in self.commands],'task_kinds':self.task_kinds,'provenance':provenance,
                        'producer_file_sha256':_regular_hash(Path(__file__).resolve()),'environment_delta':self.env_delta})
            self.intent_sha256=_regular_hash(self.directory/'intent.json')
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self.deferred_error=repr(error)
                self._preserve_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        out=self.directory/f'git-{index:03}.stdout';err=self.directory/f'git-{index:03}.stderr'
        with out.open('xb') as o,err.open('xb') as e:
            result=subprocess.run([self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv],stdin=subprocess.DEVNULL,stdout=o,stderr=e,close_fds=True,env=self.environment)
        stdout=_file_snapshot(out,1024**3);stderr=_file_snapshot(err,32*1024**2)
        self._event('git_observation',argv=list(argv),returncode=result.returncode,stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'])
        if result.returncode:raise ProducerError('git observation failed; exact stdout/stderr retained')
        if argv[0]=='archive':return out
        if stdout['size']>32*1024**2:raise ProducerError('git metadata exceeds declared bound')
        return out.read_bytes()

    def _source_guard(self,observe=None):
        observe=self._git if observe is None else observe
        self.lease_check()
        self._tool_guard()
        if observe('rev-parse','HEAD').decode().strip()!=self.source_commit:raise ProducerError('source HEAD differs')
        if observe('status','--porcelain','--untracked-files=normal'):raise ProducerError('source worktree is not clean')
        if observe('diff','--no-ext-diff','--no-textconv',self.runtime_commit,self.source_commit,'--','packages','native'):raise ProducerError('runtime source differs')

    def _make_archive(self):
        # git archive bytes are kept without extraction. Validate every blob and mode.
        raw_path=self._git('archive','--format=tar',self.source_commit)
        archive=self.directory/'source.tar'
        # Exclusive hard-link publication keeps original command bytes, no copy/overwrite.
        os.link(raw_path,archive,follow_symlinks=False)
        archive_hash=_regular_hash(archive)
        if archive_hash!=self.expected_archive_sha256:raise ProducerError('source archive differs from immutable expected digest')
        tree={}
        for entry in self._git('ls-tree','-rz',self.source_commit).split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,kind,object_id=meta.split(b' ')
            if kind!=b'blob':raise ProducerError('unsupported source tree entry')
            tree[os.fsdecode(name)]=(mode.decode(),object_id.decode())
        found=set()
        with tarfile.open(archive,'r:') as tar:
            for member in tar:
                if member.isdir():continue
                if member.name not in tree or member.name in found:raise ProducerError('archive has unknown or duplicate source entry')
                mode,object_id=tree[member.name]
                if member.issym() and mode=='120000':data=os.fsencode(member.linkname)
                elif member.isfile() and mode in ('100644','100755'):
                    if member.size>128*1024**2:raise ProducerError('source entry exceeds declared bound')
                    if bool(member.mode&0o111)!=(mode=='100755'):raise ProducerError('source archive executable mode differs')
                    data=tar.extractfile(member).read()
                else:raise ProducerError('source archive type differs')
                if hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=object_id:raise ProducerError('source archive blob differs')
                found.add(member.name)
        if found!=set(tree):raise ProducerError('source archive omits committed files')
        self.source_entries=len(found);self.source_archive_sha256=_regular_hash(archive)
        if self.source_archive_sha256!=archive_hash:raise ProducerError('archive changed during membership check')
        self._event('source_archive',sha256=self.source_archive_sha256,entries=self.source_entries)


    def _tool_guard(self):
        for name,expected in self.tools.items():
            observed=describe_tool(name,expected['version_prefix'],lookup_path=self.environment.get('PATH'))
            if observed!=dict(expected):raise ProducerError('tool entry/target identity differs: '+name)

    def _version_guard(self):
        record=self.records[-1]
        if record['kind']!='tool_version':return
        if record['log_bytes']>65536:raise ProducerError('tool version output exceeds declared bound')
        path=self.directory/f'command-{len(self.records)-1:03}.log'
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            with os.fdopen(fd,'rb',closefd=False) as reader:data=reader.read(65537)
            if len(data)!=record['log_bytes'] or _sha(data)!=record['log_sha256']:raise ProducerError('tool version bytes changed')
            text=data.decode('utf-8')
            prefix=self.tools[record['tool']]['version_prefix']
            line=text.splitlines()[0] if text else ''
            match=line.startswith(prefix)
            suffix=line[len(prefix):] if match else ''
            if not text or '\0' in text or not text.endswith('\n') or not match or (not prefix[-1].isspace() and suffix and not suffix[0].isspace()):
                raise ProducerError('tool version differs: '+record['tool'])
            record['version_line']=text.splitlines()[0]
            if record['tool']=='dart' and self.expected_sdk is not None and _dart_sdk(record['version_line'])!=self.expected_sdk:
                raise ProducerError('reported Dart SDK differs from pre-child context')
        finally:
            primary=sys.exception()
            try:os.close(fd)
            except OSError as error:
                if primary is None:raise
                primary.add_note('version descriptor close failed: '+repr(error))


    def _config_guard(self):
        for relative in set(self.config_bindings.values()):
            value=_read_json(self.repo/relative,self.inputs[relative])
            packages=value.get('packages')
            if (type(value.get('configVersion')) is not int or value['configVersion']!=2
                or value.get('generator')!='pub' or value.get('generatorVersion')!=self.expected_sdk
                or type(packages) is not list or not packages):raise ProducerError('config generator/SDK differs')
            names=set()
            for entry in packages:
                if (type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names
                    or type(entry.get('rootUri')) is not str or not entry['rootUri']
                    or type(entry.get('packageUri')) is not str):raise ProducerError('invalid generated package config entry')
                names.add(entry['name'])

    def _input_guard(self):
        self.lease_check()
        for relative,expected in self.inputs.items():
            if _regular_hash(self.repo/relative)!=expected:raise ProducerError('input identity/digest differs: '+relative)
        if self.config_bindings:self._config_guard()

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index])
        self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
        self.log=(self.directory/f'command-{index:03}.log').open('xb')
        kind,tool=self.task_kinds[index]
        record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),'returncode':None,'spawn_error':None}
        self.records.append(record)
        try:
            self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=self.log,stderr=subprocess.STDOUT,close_fds=True,env=self.environment)
        except OSError as e:
            record['spawn_error']=repr(e);self._end_command(None)
            self._finish('failed','command spawn failed')
        else:
            record['pid']=self.process.pid;self.pending=True
            self._event('command_spawned',index=index,pid=self.process.pid)

    def _end_command(self,status):
        self.pending=False
        record=self.records[-1];record['returncode']=status;record['ended_ns']=time.time_ns()
        log=self.log;self.log=None
        log.flush();os.fsync(log.fileno());log.close()
        data=_file_snapshot(self.directory/f'command-{len(self.records)-1:03}.log')
        record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
        self._event('command_end',index=len(self.records)-1,**record)

    def _finish(self,status,error=None):
        self.finished=True
        output_hashes={}
        if status=='success':
            for role,path in self.outputs.items():
                if '*' in str(path):
                    matches=sorted(Path(path).parent.glob(Path(path).name))
                    if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                    path=matches[0]
                output_hashes[role]={'path':str(path),'sha256':_regular_hash(Path(path))}
        self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                     'scope':'owned_child_waited_and_file_snapshots_only','capture_ready':False,
                     'status':status,'error':error,'census_id':self.census_id,'expected_sdk':self.expected_sdk,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                     'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                     'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance,'tools':{k:dict(v) for k,v in self.tools.items()}}
        _write_json(self.directory/'result.json',self.result)
        self.result_sha256=_regular_hash(self.directory/'result.json')
        self._event('finished',status=status,error=error)
        events=self.events;self.events=None;events.close()
        self.journal_sha256=_regular_hash(self.directory/'journal.jsonl');self.evidence_complete=True
        return self.result

    def _preserve_failure(self,error):
        try:_write_json(self.directory/'failure.json',{'error':repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance})
        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))
        if not self.pending and self.events is not None:
            events=self.events;self.events=None
            try:events.close()
            except BaseException as secondary:error.add_note('journal close failed: '+repr(secondary))

    def wait(self,timeout):
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        self.lease_check()
        deadline=time.monotonic()+timeout
        try:
            while True:
                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._version_guard();self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            if self.pending:
                self.deferred_error=repr(e)
                self._preserve_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise


def start_fixture(**kwargs):
    return CommandProducer(**kwargs,provenance='fixture')


def _live_inputs(inputs):
    required={'pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'}
    if type(inputs) is not dict or not required<set(inputs) or any(k not in required and not k.endswith('/.dart_tool/package_config.json') and k!='.dart_tool/package_config.json' for k in inputs):
        raise ProducerError('actual three locks and generated package configs required')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR'):
        if os.environ.get(key):raise ProducerError('undeclared build environment: '+key)


def start_canonical(**kwargs):
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    repo=Path(kwargs['repo']);native=repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')
    configured=os.environ.get('CONNECTANUM_NATIVE_LIB')
    if configured and Path(configured).resolve()!=native:raise ProducerError('canonical native path is outside own declared release output')
    return CommandProducer(**kwargs,commands=[['bin/verify']],provenance='canonical_recipe',outputs={'canonical_native':native})


def start_production(**kwargs):
    if sys.platform!='linux':raise ProducerError('production ELF recipe requires actual Linux')
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    _required_context(kwargs)
    target=Path(kwargs['run_dir'])/'target'
    return CommandProducer(**kwargs,provenance='production_recipe',env_delta={'CARGO_TARGET_DIR':str(target)},
        commands=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                  ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],
        outputs={'native_elf':target/'release/libct_ffi.so','driver_elf':target/'release/http_stream',
                 'static_rlib':target/'release/deps/libct_core-*.rlib'})



def _receipt_source_audit(run):
    path=run.directory/'receipt-source-audit.jsonl'
    audit=path.open('xb');index=0
    try:
        def observe(*argv):
            nonlocal index
            number=index;index+=1
            out=run.directory/f'receipt-git-{number:03}.stdout';err=run.directory/f'receipt-git-{number:03}.stderr'
            with out.open('xb') as o,err.open('xb') as e:
                cmd=[run.tools['git']['entry'],'-C',str(run.repo),*argv]
                result=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=o,stderr=e,close_fds=True,env=run.environment)
            stdout=_file_snapshot(out,32*1024**2);stderr=_file_snapshot(err,32*1024**2)
            record={'argv':cmd,'returncode':result.returncode,'stdout':stdout,'stderr':stderr}
            audit.write((json.dumps(record,sort_keys=True)+'\n').encode());audit.flush();os.fsync(audit.fileno())
            if result.returncode:raise ProducerError('receipt source observation failed; original bytes retained')
            return out.read_bytes()
        run._source_guard(observe)
    finally:
        primary=sys.exception()
        try:audit.close()
        except OSError as e:
            if primary is None:raise
            primary.add_note('receipt source audit close failed: '+repr(e))
    return _regular_hash(path)


def _emit(run,phase,fixture):
    if type(run) is not CommandProducer or phase not in ('canonical','execution'):
        raise ProducerError('owned producer and valid phase required')
    if run.pending or not run.finished or not run.evidence_complete or run.result['status']!='success':
        raise ProducerError('successful complete owned producer required')
    if fixture:
        if run.provenance!='fixture':raise ProducerError('fixture emitter only accepts fixture provenance')
    elif run.provenance!=('canonical_recipe' if phase=='canonical' else 'production_recipe'):
        raise ProducerError('live receipt cannot adopt fixture or foreign producer provenance')
    if run.receipt_attempted:raise ProducerError('receipt attempt is permanently terminal')
    run.receipt_attempted=True
    try:
        _write_json(run.directory/'receipt-attempt.json',{'census_id':run.census_id,'phase':phase,'fixture':fixture,'terminal':True})
        if run.census_id is None or run.expected_sdk is None or not {'server','client'}<=set(run.config_bindings):
            raise ProducerError('receipt context was not declared before child')
        intent=_read_json(run.directory/'intent.json',run.intent_sha256)
        sealed=_read_json(run.directory/'result.json',run.result_sha256)
        if (intent['census_id']!=run.census_id or intent['expected_sdk']!=run.expected_sdk
            or intent['config_bindings']!=dict(run.config_bindings) or intent['inputs']!=dict(run.inputs)
            or intent['source_commit']!=run.source_commit or intent['runtime_commit']!=run.runtime_commit
            or intent['expected_archive_sha256']!=run.source_archive_sha256 or sealed!=run.result
            or intent['provenance']!=run.provenance or sealed['provenance']!=run.provenance
            or sealed['kind']!=('fixture-command-evidence-v1' if fixture else 'own-command-evidence-v1')):
            raise ProducerError('pre-child receipt context changed')
        if _regular_hash(run.directory/'journal.jsonl')!=run.journal_sha256:raise ProducerError('sealed journal changed')
        source_audit_sha256=_receipt_source_audit(run);run._input_guard()
        if _regular_hash(run.directory/'source.tar')!=run.source_archive_sha256:raise ProducerError('sealed archive changed')
        if set(run.tools)!=set(VERSION_ARGS) or len(sealed['commands'])!=len(run.commands):raise ProducerError('six probes and all recipes required')
        recipes=[];dart=None
        for index,record in enumerate(sealed['commands']):
            if (record['argv']!=list(run.commands[index]) or (record['kind'],record['tool'])!=run.task_kinds[index]
                or record['returncode']!=0 or record['spawn_error'] is not None):raise ProducerError('command phase/argv/status differs')
            log=_file_snapshot(run.directory/f'command-{index:03}.log')
            if log!={'size':record['log_bytes'],'sha256':record['log_sha256']}:raise ProducerError('command log changed')
            if record['kind']=='recipe':recipes.append({'argv':record['argv'],'exit':record['returncode']})
            elif record['tool']=='dart':dart=_dart_sdk(record['version_line'])
        if dart!=run.expected_sdk:raise ProducerError('actual reported SDK differs')
        if not fixture and [r['argv'] for r in recipes]!=(CANONICAL_RECIPES if phase=='canonical' else PRODUCTION_RECIPES):
            raise ProducerError('live phase recipe differs')
        expected_roles={'canonical_native'} if phase=='canonical' else {'native_elf','driver_elf','static_rlib'}
        if set(sealed['outputs'])!=expected_roles:raise ProducerError('own output roles differ')
        for role,entry in sealed['outputs'].items():
            path=Path(entry['path'])
            if not fixture:
                if phase=='canonical':
                    expected=run.repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')
                    if path!=expected:raise ProducerError('canonical native outside own output')
                elif role=='static_rlib':
                    if path.parent!=run.directory/'target/release/deps' or not re.fullmatch(r'libct_core-[A-Za-z0-9_]+\.rlib',path.name):raise ProducerError('RLIB outside own production target')
                elif path!=run.directory/'target/release'/('libct_ffi.so' if role=='native_elf' else 'http_stream'):
                    raise ProducerError('production artifact outside own target')
            if _regular_hash(path)!=entry['sha256']:raise ProducerError('own output bytes changed')
        complete=run.directory/'complete-command.log'
        with complete.open('xb') as out:
            for index,record in enumerate(sealed['commands']):
                fd=os.open(run.directory/f'command-{index:03}.log',os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
                try:
                    h=hashlib.sha256();count=0
                    while True:
                        part=os.read(fd,1024**2)
                        if not part:break
                        count+=len(part)
                        if count>record['log_bytes']:raise ProducerError('command log grew during copy')
                        h.update(part);out.write(part)
                    if count!=record['log_bytes'] or h.hexdigest()!=record['log_sha256']:raise ProducerError('command bytes changed during copy')
                finally:
                    primary=sys.exception()
                    try:os.close(fd)
                    except OSError as e:
                        if primary is None:raise
                        primary.add_note('command log close failed: '+repr(e))
            out.flush();os.fsync(out.fileno())
        common={'census_id':run.census_id,'source_commit':run.source_commit,'runtime_commit':run.runtime_commit,
                'source_archive_sha256':run.source_archive_sha256,'sdk':dart,'log_sha256':_regular_hash(complete,maximum=16*1024**3),
                'lock_hashes':{k:run.inputs[p] for k,p in LOCK_PATHS.items()},
                'package_configs':{k:run.inputs[p] for k,p in run.config_bindings.items()},'commands':recipes}
        receipt={'kind':('fixture-' if fixture else 'own-')+('canonical-v1' if phase=='canonical' else 'production-v1'),**common}
        if phase=='canonical':receipt['native_sha256']=sealed['outputs']['canonical_native']['sha256']
        else:receipt.update(outputs={k:v['sha256'] for k,v in sealed['outputs'].items()},features=[])
        _write_json(run.directory/'input-receipt.json',receipt)
        binding={'scope':'command-produced links only; independent canonical breadth/descendant/SDK-image/root admission still required',
                 'capture_ready':False,'fixture':fixture,'census_id':run.census_id,'intent_sha256':run.intent_sha256,
                 'result_sha256':run.result_sha256,'journal_sha256':run.journal_sha256,'source_audit_sha256':source_audit_sha256,'receipt_sha256':_regular_hash(run.directory/'input-receipt.json'),
                 'log_sha256':receipt['log_sha256']}
        _write_json(run.directory/'receipt-binding.json',binding)
        return receipt
    except BaseException as e:
        try:_write_json(run.directory/'receipt-failure.json',{'primary_error':repr(e),'terminal':True})
        except BaseException as secondary:e.add_note('receipt failure publication failed: '+repr(secondary))
        raise


def emit_receipt(run):
    if (type(run) is not CommandProducer or run.provenance not in ('canonical_recipe','production_recipe')
        or type(run.result) is not dict or run.result.get('kind')!='own-command-evidence-v1' or run.result.get('provenance')!=run.provenance):
        raise ProducerError('live receipt requires actual live-factory provenance')
    return _emit(run,'canonical' if run.provenance=='canonical_recipe' else 'execution',False)


def emit_fixture_receipt(run,phase):
    return _emit(run,phase,True)


# Separate SDK-method observer only. Never injected into WAMP/benchmark workers.
DART_PACKAGE_PROBE_SOURCE = r"""import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

Future<void> main(List<String> args) async {
  if (args.length != 1 || !RegExp(r'^[0-9a-f]{32}$').hasMatch(args.single)) {
    stderr.writeln('one declared nonce required');
    exitCode = 64;
    return;
  }
  final missingName = '__native_perf_absent_${args.single}';
  final active = await Isolate.packageConfig;
  String? bytesBase64;
  final mappings = <Map<String, Object?>>[];
  if (active != null) {
    if (active.scheme != 'file') throw StateError('non-file active config unsupported');
    final file = File.fromUri(active);
    if (file.lengthSync() > 2 * 1024 * 1024) throw StateError('active config too large');
    final bytes = file.readAsBytesSync();
    if (bytes.length > 2 * 1024 * 1024) throw StateError('active config grew');
    bytesBase64 = base64Encode(bytes);
    final config = jsonDecode(utf8.decode(bytes));
    if (config is! Map || config['packages'] is! List) throw StateError('config shape');
    final packages = config['packages'] as List;
    if (packages.length > 1024) throw StateError('too many packages');
    for (final entry in packages) {
      if (entry is! Map || entry['name'] is! String) throw StateError('package name');
      final name = entry['name'] as String;
      final resolved = await Isolate.resolvePackageUri(Uri.parse('package:$name/'));
      mappings.add({'name': name, 'uri': resolved?.toString()});
    }
  }
  final missing = await Isolate.resolvePackageUri(Uri.parse('package:$missingName/'));
  stdout.writeln(jsonEncode({
    'kind': 'dart-package-config-observation-v1',
    'script': Platform.script.toString(),
    'sdk': Platform.version,
    'config_uri': active?.toString(),
    'config_b64': bytesBase64,
    'mappings': mappings,
    'missing_name': missingName,
    'missing_uri': missing?.toString(),
  }));
}
"""


def validate_package_observation(value,*,expected_sdk,expected_script_uri,expected_config_uri,expected_config_bytes,nonce):
    """Validate helper-only observations, not compiled/loaded-role provenance."""
    import base64
    from urllib.parse import urlsplit
    keys={'kind','script','sdk','config_uri','config_b64','mappings','missing_name','missing_uri'}
    if (type(value) is not dict or set(value)!=keys or value['kind']!='dart-package-config-observation-v1'
        or type(nonce) is not str or not re.fullmatch('[0-9a-f]{32}',nonce)
        or type(expected_sdk) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',expected_sdk)
        or type(expected_script_uri) is not str or not expected_script_uri.startswith('file:')
        or type(value['sdk']) is not str or len(value['sdk'])>4096 or value['script']!=expected_script_uri
        or value['missing_name']!='__native_perf_absent_'+nonce or value['missing_uri'] is not None
        or type(value['mappings']) is not list or len(value['mappings'])>1024):
        raise ProducerError('invalid package observation schema/context')
    if _dart_sdk('Dart SDK version: '+value['sdk'])!=expected_sdk:raise ProducerError('package observer SDK differs')
    if expected_config_bytes is None:
        if expected_config_uri is not None or value['config_uri'] is not None or value['config_b64'] is not None or value['mappings']:
            raise ProducerError('null-config negative differs')
        raw=None;names=[]
    else:
        if (type(expected_config_bytes) is not bytes or not 0<len(expected_config_bytes)<=2*1024**2
            or type(expected_config_uri) is not str or not expected_config_uri.startswith('file:')
            or value['config_uri']!=expected_config_uri or type(value['config_b64']) is not str):raise ProducerError('package config context differs')
        try:raw=base64.b64decode(value['config_b64'],validate=True)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config encoding') from e
        if raw!=expected_config_bytes:raise ProducerError('exact package config bytes differ')
        def pairs(values):
            out={}
            for key,entry in values:
                if key in out:raise ProducerError('duplicate package config JSON key')
                out[key]=entry
            return out
        def constant(entry):raise ProducerError('nonfinite package config JSON')
        try:config=json.loads(raw,object_pairs_hook=pairs,parse_constant=constant)
        except (ValueError,UnicodeError) as e:raise ProducerError('invalid package config JSON') from e
        if (type(config) is not dict or type(config.get('configVersion')) is not int or config['configVersion']!=2
            or config.get('generatorVersion')!=expected_sdk or type(config.get('packages')) is not list
            or not 0<len(config['packages'])<=1024):raise ProducerError('package config schema/SDK differs')
        names=[]
        for entry in config['packages']:
            if type(entry) is not dict or type(entry.get('name')) is not str or not entry['name'] or entry['name'] in names:
                raise ProducerError('package config has duplicate/invalid names')
            names.append(entry['name'])
        if value['missing_name'] in names:raise ProducerError('absent query name is in declared config')
    if len(names)!=len(value['mappings']):raise ProducerError('package mapping inventory differs')
    mappings=[];other=0
    for name,entry in zip(names,value['mappings']):
        if type(entry) is not dict or set(entry)!= {'name','uri'} or entry['name']!=name:
            raise ProducerError('package mapping order/entry differs')
        uri=entry['uri']
        if uri is not None:
            if type(uri) is not str or not 0<len(uri)<=16384 or any(c in uri for c in '\0\r\n') or re.search(r'%(?![0-9a-fA-F]{2})',uri):
                raise ProducerError('invalid resolved package URI')
            try:scheme=urlsplit(uri).scheme
            except ValueError as e:raise ProducerError('malformed resolved URI') from e
            if not scheme or scheme=='package':raise ProducerError('package URI was not resolved')
        else:scheme=None
        if scheme!='file':other+=1
        mappings.append((name,uri))
    return {'scope':'helper_package_config_observation_only','capture_ready':False,'config_sha256':None if raw is None else _sha(raw),
            'package_count':len(names),'mappings':tuple(mappings),'other_or_null':other,'sdk':value['sdk'],'config_uri':value['config_uri']}
