from pathlib import Path
import sys,os,json,hashlib,subprocess,types,secrets,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
from ollama_companion import local_resource_lease,LocalResourceLeaseError
wt=Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');base=Path('/tmp/connectanum-native-perf-package-resolution-control').resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
try:
 with local_resource_lease(exclusive=True) as lease:
  lease.verify_identity();assert shutil.disk_usage(wt).free>=1024**3
  frozen=json.loads(Path('/tmp/connectanum-native-perf-build-producer-package-fixed-tests.json').read_bytes());assert frozen['exit']==0
  assert all(sha((wt/p).read_bytes())==h for p,h in frozen['source_sha256'].items())
  previous=Path('/tmp/connectanum-native-perf-build-producer-receipt-fixed-source/native_perf_build_producer.py').read_bytes();current=(wt/'tool/native_perf_build_producer.py').read_bytes();assert current[:len(previous)]==previous
  base.mkdir(mode=0o700)
  module=types.ModuleType('own_package_observer');module.__file__=str(wt/'tool/native_perf_build_producer.py');exec(compile(current,module.__file__,'exec'),module.__dict__)
  old=json.loads(Path('/tmp/connectanum-native-perf-tool-identity-local-cli-control-v2/declaration.json').read_bytes());wrapper=Path(old['tools']['dart']['target']);sdk=(wrapper.parent/'cache/dart-sdk').resolve();dart=(sdk/'bin/dart').resolve();shared=wrapper.parent/'internal/shared.sh'
  assert (sdk/'version').read_text().strip()=='3.13.1'
  corefiles={'sdk_entry':dart,'sdk_version':sdk/'version','isolate_api_source':sdk/'lib/isolate/isolate.dart','launcher':wrapper,'launcher_shared':shared}
  # Support stamps only; not a complete delegated SDK/image inventory.
  stamps={k:{'sha256':module._regular_hash(p.resolve(),maximum=512*1024**2,owners={0,os.getuid()}),'path':str(p.resolve())} for k,p in corefiles.items()}
  local_locks={'pubspec.lock':'4c719ebf08ce4d65571d5c4b25f9ec16567405ab99c8ee298143acadfa2691b8','native/transport/Cargo.lock':'0cb8ef90485ccae06b2981d023ea44d46c6309ba46a1186dffab581169f9f0c3','native/bench/Cargo.lock':'ea60fd1c65bd64f04a65ff9c1410348ef2d22450c7d63e4556149f7b6f1c0189'}
  for relative,h in local_locks.items():assert sha((wt/relative).read_bytes())==h
  config=(wt/'.dart_tool/package_config.json').resolve();raw=config.read_bytes();cfg=json.loads(raw);assert cfg['generator']=='pub' and cfg['generatorVersion']=='3.13.1' and cfg['configVersion']==2
  source=module.DART_PACKAGE_PROBE_SOURCE.encode();outside_nonce=secrets.token_hex(16);inside_nonce=secrets.token_hex(16)
  outside=base/'outside';outside.mkdir();inside=wt/'.dart_tool'/('native-perf-package-resolution-'+inside_nonce)
  ignored=subprocess.run(['git','check-ignore','--quiet','--',str(inside.relative_to(wt))],cwd=wt);assert ignored.returncode==0
  inside.mkdir(mode=0o700)
  controls=[{'name':'outside','script':outside/'probe.dart','cwd':outside,'nonce':outside_nonce,'config':None}, {'name':'workspace','script':inside/'probe.dart','cwd':wt,'nonce':inside_nonce,'config':str(config)}]
  for c in controls:
   with c['script'].open('xb') as out:out.write(source);out.flush();os.fsync(out.fileno())
  with (base/'probe-source.dart').open('xb') as out:out.write(source)
  with (base/'expected-package-config.json').open('xb') as out:out.write(raw)
  declaration={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'TWO OWN helper-isolate metadata controls ONLY; not original WAMP worker/compiled-input/native-image proof or diagnostic data','source_sha256':frozen['source_sha256'],'producer_prefix_unchanged_from_prior45':True,'probe_source_sha256':sha(source),'controller_sha256':sha(Path(__file__).read_bytes()),'stamps':stamps,'expected_Dart':'3.13.1','expected_generator':'pub3.13.1','expected_config_sha256':sha(raw),'expected_package_count':len(cfg['packages']),'actual_LOCAL_lock_hashes':local_locks,'free_bytes':shutil.disk_usage(wt).free,'sdk_path_choice':'explicit cachedSDK METHOD CONTROL to avoid Flutter launcher bootstrap/upgrade; original WAMP launcher/flags unchanged','controls':[{k:str(v) if isinstance(v,Path) else v for k,v in c.items()} for c in controls],'original_UID':os.getuid(),'original_GID':os.getgid(),'no_added_SDK_flags':True}
  with (base/'declaration.json').open('x') as out:json.dump(declaration,out,indent=2);out.write('\n')
  results=[]
  for c in controls:
   folder=base/c['name'] if c['name']=='workspace' else outside
   if c['name']=='workspace':folder.mkdir()
   command=[str(dart),str(c['script']),c['nonce']]
   with (folder/'started.json').open('x') as out:json.dump({'argv':command,'cwd':str(c['cwd']),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':True},out)
   with (folder/'stdout.json').open('xb') as out,(folder/'stderr.log').open('xb') as err:
    child=subprocess.Popen(command,cwd=c['cwd'],stdout=out,stderr=err,stdin=subprocess.DEVNULL,close_fds=True,env=dict(os.environ))
    while True:
     try:status=child.wait(timeout=1);break
     except subprocess.TimeoutExpired:lease.verify_identity()
   result={'name':c['name'],'pid':child.pid,'signed_exit':status,'stdout_sha256':sha((folder/'stdout.json').read_bytes()),'stderr_sha256':sha((folder/'stderr.log').read_bytes()),'source_sha256':sha(c['script'].read_bytes()),'validation':None,'validation_error':None}
   try:
    if status!=0:raise RuntimeError('helper exited nonzero; complete raw retained')
    report=module._read_json(folder/'stdout.json',result['stdout_sha256'])
    result['validation']=module.validate_package_observation(report,expected_sdk='3.13.1',expected_script_uri=c['script'].as_uri(),expected_config_uri=c['config'] and config.as_uri(),expected_config_bytes=None if c['config'] is None else raw,nonce=c['nonce'])
   except BaseException as e:result['validation_error']=repr(e)
   assert result['source_sha256']==sha(source)
   assert raw==config.read_bytes()
   for relative,h in local_locks.items():assert sha((wt/relative).read_bytes())==h
   for key,entry in stamps.items():assert module._regular_hash(Path(entry['path']),maximum=512*1024**2,owners={0,os.getuid()})==entry['sha256'],key
   with (folder/'result.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
   results.append(result)
  lease.verify_identity();assert all(sha((wt/p).read_bytes())==h for p,h in frozen['source_sha256'].items())
  summary={'scope':declaration['scope'],'all_source_SDK_config_locks_unchanged':True,'results':results,'complete_pass':all(r['signed_exit']==0 and r['validation_error'] is None for r in results),'no_benchmark_or_targetVMservice_request':True}
  with (base/'summary.json').open('x') as out:json.dump(summary,out,indent=2);out.write('\n')
  print(json.dumps({'pass':summary['complete_pass'],'results':[{k:r[k] for k in ('name','signed_exit','validation_error')}|({'packages':r['validation']['package_count'],'other_or_null':r['validation']['other_or_null']} if r['validation'] else {}) for r in results]}))
  sys.exit(0 if summary['complete_pass'] else 1)
except LocalResourceLeaseError as e:
 with Path(str(base)+'-lease-refusal.json').open('x') as out:json.dump({'before_control':True,'error':str(e)},out)
 print(str(e));sys.exit(75)
