import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

Future<void> main(List<String> args) async {
  if (args.length != 1 || !RegExp(r'^[0-9a-f]{32}$').hasMatch(args.single)) {
    stderr.writeln('one declared nonce required');
    exitCode = 64;
    return;
  }
  final missingName = '__native_perf_absent_${args.single}';
  final active = await Isolate.packageConfig;
  String? bytesBase64;
  final mappings = <Map<String, Object?>>[];
  if (active != null) {
    if (active.scheme != 'file') throw StateError('non-file active config unsupported');
    final file = File.fromUri(active);
    if (file.lengthSync() > 2 * 1024 * 1024) throw StateError('active config too large');
    final bytes = file.readAsBytesSync();
    if (bytes.length > 2 * 1024 * 1024) throw StateError('active config grew');
    bytesBase64 = base64Encode(bytes);
    final config = jsonDecode(utf8.decode(bytes));
    if (config is! Map || config['packages'] is! List) throw StateError('config shape');
    final packages = config['packages'] as List;
    if (packages.length > 1024) throw StateError('too many packages');
    for (final entry in packages) {
      if (entry is! Map || entry['name'] is! String) throw StateError('package name');
      final name = entry['name'] as String;
      final resolved = await Isolate.resolvePackageUri(Uri.parse('package:$name/'));
      mappings.add({'name': name, 'uri': resolved?.toString()});
    }
  }
  final missing = await Isolate.resolvePackageUri(Uri.parse('package:$missingName/'));
  stdout.writeln(jsonEncode({
    'kind': 'dart-package-config-observation-v1',
    'script': Platform.script.toString(),
    'sdk': Platform.version,
    'config_uri': active?.toString(),
    'config_b64': bytesBase64,
    'mappings': mappings,
    'missing_name': missingName,
    'missing_uri': missing?.toString(),
  }));
}
