require 'yaml'; require 'json'; require 'digest'
v=JSON.parse(File.read(ARGV[0])); base=File.binread(v.fetch('parent_path')); raise unless Digest::SHA256.hexdigest(base)==v.fetch('parent_sha256')
doc=YAML.load(base); jobs=doc.fetch('jobs'); raise unless jobs.size==14
oldkey='flatbuffers-c-tool-runtime-inputs'; newkey='flatbuffers-c-runtime-transitive-inputs'; raise if jobs.key?(newkey)
job=jobs.fetch(oldkey); oldcollector=v.fetch('old_collector'); newcollector=v.fetch('new_collector')
scripts=job.fetch('steps').select{|s| s['run'].is_a?(String) && s['run'].include?(oldcollector)}; raise unless scripts.size==1
scripts[0]['run']=scripts[0]['run'].sub(oldcollector){newcollector}
def transform(x)
 case x
 when Hash; x.each_with_object({}){|(k,v),h| h[k]=transform(v)}
 when Array; x.map{|v|transform(v)}
 when String; x.gsub('flatbuffers_c_tool_runtime_inputs','flatbuffers_c_runtime_transitive_inputs').gsub('flatbuffers-c-tool-runtime-inputs','flatbuffers-c-runtime-transitive-inputs').gsub('native-perf-c-tool-runtime-inputs','native-perf-c-runtime-transitive-inputs').gsub('FlatBuffers C-tool runtime reference inputs (no execution)','FlatBuffers transitive C-runtime reference inputs (no execution)')
 else;x
 end
end
job=transform(job); block=YAML.dump({newkey=>job}).sub(/\A---\s*\n/,'').lines.map{|l| '  '+l}.join
choice="          - flatbuffers_c_tool_runtime_inputs\n"; raise unless base.scan(choice).size==1
addition="          - flatbuffers_c_runtime_transitive_inputs\n"; candidate=base.sub(choice){choice+addition}; candidate+="\n"+block
File.open(v.fetch('candidate_path'),'wb'){|f|f.write(candidate)}; File.open(v.fetch('job_block_path'),'wb'){|f|f.write(block)}
puts JSON.generate({'new_job_key'=>newkey,'parent_jobs'=>14,'new_job_count'=>15,'candidate_bytes'=>candidate.bytesize,'candidate_sha256'=>Digest::SHA256.hexdigest(candidate)})
