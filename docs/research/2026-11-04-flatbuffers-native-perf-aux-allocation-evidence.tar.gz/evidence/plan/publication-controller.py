import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-preparation');a=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='859478b4bed3e4e7963823e1c775e864d3972c0f'
 assert git('status','--porcelain')==''
 h=json.loads((p/'current-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 assert before>=1024**3+256*1024**2
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  controller_order_qualified_per_kind=True))
 base='2026-11-04-flatbuffers-native-perf-aux-allocation';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'plan'),(a,'design'),(final_root,'root-final'),(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-before-v1'),'before-v1'),(pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-orientation'),'orientation')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='All three original model/control controller files saved BEFORE execution; copies aftercalls. Root assessment/publication originals also saved BEFORE execution. Separate command-before/model stdout-stderr/direct waits retained. No execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Auxiliary Popen allocation ownership before constructor return\n\nThe separate AuxiliaryCommand path still assigns process only after the Popen\ntype call returns. Five new controls of the unchanged source produce4FAIL/1PASS,\nwith all declared boundaries reached and no missing-API errors. These are\nAuxiliary controls, not repeats of the consumed direct CommandProducer cases.\n\nThree negatives call the actual original Popen initializer and then inject\nOSError, RuntimeError or a False result. False deliberately causes the native\ntype-call TypeError. The source lacks its allocated-object reference before\nreal initialization and after failure. Its original handler closes pipe copies,\ncalls complete and publishes failed state while the actual quiet finite child\nstill exists. A separate post-import initializer rebind calls the declared\nforeign hook once before any real initializer. Normal actual construction and\nthe two-output-stream Auxiliary caller pass. These are finite fault-model/\nownership-contract failures, not four measured SDK/kernel/RAM defects or a\nglobal orphan/leak claim.\n\nThe root fixture holds the actual instance before native initializer I/O solely\nfor unit cleanup, never library backfill. Four finite OWN Python children return\nsigned0 through the exact same bound Popen wait methods before root FD/log\ncleanup. Their private ready/release/deadline is not a GO token or original\nworkload. They emit no stdout after the source may close pipe copies, avoiding\nunit SIGPIPE. Negative source method-wait markers remainFalse/null after root\nwaits; they are not reconstructed. The normal Auxiliary wait API runs after the\nroot wait and can return cached0, not proof of a fresh wait syscall. Its actual\nreturn and stream observations are retained separately.\n\nNormal constructor checks retain exact Popen class, argv/cwd, DEVNULL, distinct\noriginal stdout/stderr creator writers, close_fds and the original start-time\nenvironment dict-copy semantics. Constructor tuple/MappingProxyType metadata\nalone does not prove actual call arguments were bound before allocation.\nPipe creator descriptors are retained before metadata. Unit cleanup checks their\noriginal identity/access, never recloses retired numbers or reconstructs EOF\non already closed readers. Original log objects are held before initializer\nI/O. Exact objects/errors stay private; reports save native type labels and\nidentity booleans. Administrative fixture API returns are not exhaustive, and\nfull transitive FD/delegate/descendant or physical EX closure is not established.\nThe official EX lease and actual lease callback span these known finite cases\non the current Darwin host, not the original Linux/root/perf environment.\n\nGLM42299 design and Qwen42865 tests complete0 and are reaped. ROOT accepts private\nallocated-object retention and unknown-partial DATA. GLM's suggestion to enforce\nthe complete comment belongs to the separate public cleanup repair; this narrow\ncomponent cannot claim that policy fixed. Its claim of copying only in the\nconstructor is false: start also evaluates list(argv) and dict(environment).\nPreserve each original copy and evaluation boundary. Qwen's claim that argv is\nstill a list at the constructor lease callback is false; tuple assignment precedes\nthat callback. Its no-child expectation contradicts the declared post-real-init\nfault. Check native FD values/directions/pipe identities, not Python object IDs\nor an invented shared file object. Cwd is assigned as a Path before the canonical\ncheck, so its never-assigned claim is false. No guessed pytest/grep command,\nunrelated lease/path control or mock-only positive is run. Advice is not\nimplementation, full-source, SDK or physical release approval.\n\nThe selected repair is UNIMPLEMENTED. Initialize a private native allocation\nledger, durable original binding, exact allocated-process reference and private\nfirst/staged errors before constructor lease callback/intent hashing/writing.\nReserve the single attempt before start I/O. Pin and check the exact original\nclass, resolved standard object allocator and initializer. Bind original actual\ncall arguments before allocation, including the existing start list/environment\ncopies, cwd, DEVNULL, distinct stdout/stderr writers and close_fds. Retain the\nexact allocated object before captured initializer I/O. Process/pending follow\nnormal None-only construction; no fallback/subclass/SDK change. Extend frozen\nAuxiliary DATA to retain allocation/stage/partial-unknown facts without inventing\nabsence0, pid/status/liveness or permission to call partial-object methods.\nDo not silently discard partial objects or quarantine ordinary successful\nconstruction. Old emit/freeze/auxiliary gates stay unchanged.\n\nOriginal spawn_error repr/defer/add_note/pipe-close/complete/failed publication\nremains incomplete outside the allocation-only component and may mask errors\nor close copies before child exit. No unknown-object wait/destructor/GC discard,\nglobal bookkeeper adoption, retry/cancel/kill/reclose or live unit recovery is\nauthorized. The consumed before5 must not run again unchanged. Only a new\nsource epoch may run semantic AFTER, matching regression and affected actual\nAuxiliary/factory/history caller checks.\n\nSource5e88c1d716ff01947b48154884c904e5b89c994d626e1988d6db156dd808cda6\nand test144a184e2055dd3a7fd842f7a74eed52fa44bf1e05079de0b598c9908286334c\nare unchanged. All23 selected source/bin hashes match before and after controls.\nOnly the held producer buffer is compiled per private capsule, not current20\ncanonical/native code. All20 helpers remain untracked, uncommitted, uncanonical\nand unadmitted; production601 unedited. No fresh source Git/HEAD query is run;\nthe prior direct-component branch/HEAD observations remain historical.\nPrivate controllers are separate artifacts outside HELPERBUNDLE20. All three\noriginal model/control controller files are saved before execution; their exact\ncopies are retained after calls. Separate command-before/model stdout/stderr/\nsigned-wait receipts retain the actual ordering. Before controller direct0\nmeans expected observations recorded, not5semanticPASS.\n\nNext implement retained Auxiliary allocation and matching tests, then original\npublic cleanup, historical continuation/log sealing, transitive generic FDs,\naudit partial/unknown actors, shared journals/historical writers, interpreter/\ndelegate/descendant coverage and the independent full actual officialEX\ncontroller. Original PATH/SDK/bootstrap/first3locks/hiddenconfigs/current20\ncanonical/new source package/OWN native-driver-static RLIB/compiler-tool-kernel,\nactual original-host credentials/access/pidfd/FDexec/inheritance/arming/metadata/\nrole/time/coverage and ROOT-qualified immutable COMPLETE admission remain\nnecessary before diagnostic data. No source commit/push/adoption/strict dispatch,\nborrowed cohort/config/native transplant, favorable redo, SDK change or postGO\nas preproof.\n\nProvider absent, gate always raises, controller closed, ownershipNone, all\nthree flagsFalse. No actual SDK/native build/canonical/kernel/broker/benchmark/\ncapture, RAM cause/repair or strict acceptance. Assessment free3.16GB remains\nbelow12GiB: build floor CLOSED, recheck before builds; scoped tests retain their\nseparate1GiB floor. Cause unmeasured/no cleanup. PR132 stays OPEN DRAFT on130;\nissue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Auxiliary pre-constructor ownership reproduced; repair unimplemented\n\nFive new Auxiliary controls yield4FAIL/1PASS with no missing APIs: three actual initializer normal returns precede injected failures, leaving no source allocated reference; the old handler completes/publishes while the finite child exists. Initializer drift invokes the foreign hook; normal real two-stream construction passes. Four actual finite child method-waits return signed0 before root cleanup; no source marker backfill or SDK/kernel/RAM defect claim. Retained allocation/typed unknown DATA is selected but UNIMPLEMENTED. All23 source/bin buffers remain exact;20helpers uncommitted/uncanonical/unadmitted, production601 unedited. Public cleanup/full physical EX/original-runtime admission remain incomplete. Build floor CLOSED below12GiB; cause unmeasured/no cleanup.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-aux-allocation-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-aux-allocation-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-aux-allocation-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: record Auxiliary pre-constructor ownership boundary')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['aux_allocation_preparation'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['aux_allocation_GitHub_descriptions_pending']=True;n['aux_allocation_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
