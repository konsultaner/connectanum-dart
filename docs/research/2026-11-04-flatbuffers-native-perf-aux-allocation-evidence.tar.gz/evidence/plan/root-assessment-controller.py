import sys,pathlib,json,hashlib,datetime,os,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity()
 P=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-preparation');P.mkdir()
 D=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-design');V=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-before-v1')
 Q=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-root-assessment');Q.mkdir()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,value):
  with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 summary=json.loads((V/'summary.json').read_text());h=summary['hashes']
 assert (summary['controls'],summary['passed'],summary['failed'])==(5,1,4) and summary['all_boundaries_reached'] and summary['no_missing_API_errors']
 assert len(summary['actual_finite_children'])==4 and all(type(row['status']) is int and row['status']==0 for row in summary['actual_finite_children'])
 controls={mode:json.loads((V/mode/'result.json').read_text()) for mode in ['oserror','runtime','false_return','normal','class_drift']}
 for mode in ['oserror','runtime','false_return']:
  row=controls[mode];assert row['actual_real_init_returned'] and not row['source_before_init']['allocated_reference_present'] and not row['source_allocated_reference_after'] and row['source_process_None'] and row['source_finished']
  assert row['source_natural_wait_after_unit']==dict(observed=False,status=None)
  assert row['native_wait_observed'] and type(row['native_wait_status']) is int and row['native_wait_status']==0
 assert controls['class_drift']['foreign_initializer_calls']==1 and not controls['class_drift']['actual_real_init_returned']
 assert controls['normal']['expected_property_passed'] and all(controls['normal']['constructor_arguments'].values())
 for rel,digest in h.items():assert sha((R/rel).read_bytes())==digest
 put(P/'current-hashes.json',h)
 for filename in ['aux-allocation-judge-controller.py','aux-allocation-tests-controller.py','aux-allocation-before-v1-controller.py']:
  raw=(pathlib.Path('/tmp/connectanum-native-perf-'+filename)).read_bytes()
  with (P/filename).open('xb') as f:f.write(raw)
 source=(V/'source23/tool/native_perf_build_producer.py').read_text();tree=ast.parse(source)
 aux=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand')
 methods={n.name:n for n in aux.body if isinstance(n,ast.FunctionDef)}
 start=ast.get_source_segment(source,methods['start'])
 assert 'self.process=subprocess.Popen(list(self.argv)' in start
 assert start.index('self.spawn_error=repr(error)')<start.index("self._close_slot(stream,'writer')")<start.index('return self._complete()')
 with (Q/'selected-AuxiliaryCommand.txt').open('x') as f:f.write(ast.get_source_segment(source,aux))
 plan=dict(unimplemented=True,source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
  scope='Exact allocated Auxiliary Popen retention only; not full publiccleanup/physicalclosure/runtime admission',
  selected='Initialize private native allocation ledger and durable original reference binding, exact allocated_process and private first/staged error state BEFORE constructor lease callback/intent hash-write. Reserve one attempt BEFORE start fallibleIO. Check exact captured original class/resolved native object allocator/initializer and ledger bindings. Bind original call arguments BEFORE allocator including existing list(self.argv) and dict(self.environment) exactly once at their original start boundary, cwd, DEVNULL, distinctstdout-stderr creatorwriters/close_fds. Retain exact allocated object BEFORE capturedinitializerIO; self.process/pending onlynormalNone-return, reject nonNone preserving native semantics.',
  history='Extend frozen Auxiliary DATA observation of private allocated object/stages/unknown partial init and original binding; never infer absence0/liveness/waitauthority from processNone or finished. Do not silently discard partial object or quarantine ordinary success. All old emit/auxiliary/freeze predicates unchanged, no admission/EXrelease.',
  public_cleanup='Original repr/_defer/add_note/pipe-close/_complete/failed publication policy stays explicitly incomplete/outside narrow allocation component; maymask or closecopies before actualchildexit. No current fixture/synthetic cleanup/source markers retagged. No unknown-object method, GCdiscard/destructor/privateglobalbookkeeper/retry/cancel/kill/reclose/fallback/subclass/SDK change.',
  tests='Matching meaningful before5 consumed: no unchanged rerun. After newsourceepoch only semanticAFTER, normal actualAux/history/real source factory callers; match selected unit regressions, explicit affected seam migration without assertionsoftening/fakepositive. Add exact retained allocated/firsterror/dataunknown and preallocator argumentref/None semantics controls. Actual unregistered capsules/finites not current20canonical/native.'
 )
 put(Q/'selected-plan.json',plan)
 model=[]
 for role in ['judge','tests']:
  rec=json.loads((D/(role+'-finish.json')).read_text());assert rec['direct_status']==0 and rec['reaped'];model.append(dict(role=role,**rec))
 free=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='Auxiliary_preconstructor_BEFORE_and_selected_design_COMPLETE_REPAIR_UNIMPLEMENTED',hashes=h,source_and_test_all23_unchanged=True,source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],
  controls=dict(controls=5,passed=1,failed=4,missing_API_errors=0,all_declared_boundaries_reached=True,actual_finite_children=summary['actual_finite_children']),
  new_question='Separate AuxiliaryCommand path still blind typecall; prior direct allocation component does not cover it. Three real initializer normalreturns precede injected failures, source lacks allocated reference beforeinit/afterfailure and marks finished after its oldcleanup while actual finite child exists. Classinitrebind calls foreignhook1 before native; normal actual constructor/two-stream caller passes. Finite faultmodel/contract failures, not measured SDK/kernel/RAM/globalorphan defects.',
  source_normal_semantics='Actual exact Popen/argv/cwd/DEVNULL/two distinct original creator writer FDs/close_fds and start environment dictcopy equality verified. Constructor retains tuple argv and copied MappingProxyType; start also makes its original list and dict copies. Those wrapper metadata observations alone are not proof of actualcall BEFOREallocator binding.',
  model_advice=model,ROOT_qualifications=json.loads((D/'ROOT-model-qualifications-before-controls.json').read_text()),
  selected_plan=plan,
  raw_limits='Actual finite OWN Python with private quiet ready-release-deadline NOTGO/workload. Root holds instance BEFORErealinit onlyforunitcleanup, neverlibrarybackfill. Four actual bound samePopen waits signed0 saved BEFORErootFD/writerclose; source may closecopies/_complete-publish earlier. Negative sourcewaitFalse/null unbackfilled. NormalAux.wait afterrootwait may use cached0, no freshsyscall guarantee. ClosedreadFD neverreconstructedEOF/retiredFDnotreclosed. Original refs/errors private/savedbool-nativeclassnames; administrativefixtureAPIreturns not exhaustive. CurrentDarwinactualofficialEX/callback spansknownfinitecases, notoriginalLinux/root/perf/fullactorFD-delegate-descendant/instructionclosure or physicalrelease.',
  provenance='All three original model/control controller files saved BEFORE execution; byteexact copies now retained in preparation. Separate command-before receipts and fullstdout-stderr/directsignedwaits saved for modelchildren. Beforecontroller top-level API return0 means expected observations recorded, not5semanticPASS. No Git/sourceHEAD query this read-only phase; prior post-direct-component branchHEAD orientation only. Exact held producer buffer compiled per capsule, not current20canonical/native.',
  unchanged_scope='All23 selected source/bin buffers exact beforeafter/all20untracked-uncommitted-uncanonical-unadmitted/production601unedited/privatecontrollers outsideHELPERBUNDLE20. Existing owner_emit_attempted/freeze/auxpredicates unchanged. No SDK/compiler/version/bootstrap/native/canonical/kernel/broker/benchmark/capture/sourcecommitpushadoption/strictdispatch.',
  next='Implement selected Auxiliary allocation retention and matching newsourceepoch regression/affected realcaller checks, then originalpubliccleanup/historicalcontinuation-logseal/transitivegenericFD/auditpartialunknownactors/sharedjournal-writers/interpreter-delegate-descendant/fullactualofficialEX/originalruntime provenance and ROOT-qualified immutable COMPLETEadmission before diagnosticdata.',
  live=dict(provider_absent=True,gate_always_raises=True,controller_closed=True,ownership=None,capture_ready=False,source_admitted=False,live_admission=False,no_RAMcause_repair_acceptance=True),
  free_bytes=free,build_floor_bytes=12884901888,build_floor_open=free>=12884901888,test_floor_bytes=1073741824,cause_unmeasured=True,no_cleanup=True)
 put(Q/'assessment.json',assessment)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(checkpoint.read_text());n=v['native_perf_only_diagnostic_design']
 n['aux_allocation_preparation']=dict(cache=str(P),design=str(D),before=str(V),root_assessment=str(Q/'assessment.json'),source_sha256=plan['source_sha256'],test_sha256=plan['test_sha256'],unimplemented=True,meaningful_controls=5,failed=4,passed=1,no_missing_API_errors=True,all23_unchanged=True,publication_pending=True,models_complete0_reaped=True,never_repeat_unchanged=True)
 n['aux_allocation_next_action']=plan;n['last_free_bytes']=free;v['updated_utc']=assessment['utc'];checkpoint.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity();print(json.dumps(dict(controls=5,failed=4,passed=1,source_unchanged=True,repair_unimplemented=True,free=free)))
