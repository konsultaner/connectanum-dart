import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();D=pathlib.Path('/tmp/connectanum-native-perf-aux-allocation-design');plan=json.loads((D/'declaration.json').read_text())
 def put(name,value):
  with (D/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');raw=(R/'tool/native_perf_build_producer.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==plan['source_epoch']
 s=raw.decode();c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='AuxiliaryCommand')
 context=json.dumps(plan,indent=2)+'\nROOT qualifications of GLM42299: do not widen this allocation-only component to claim old _complete/publiccleanup fixed. Partialobject private and DATAunknown/quarantine, not childexists inference. GLM says argv/env copied exactlyonce at ctor only; source ALSO makes list(self.argv)/dict(self.environment) in start call. Preserve EACH original copy/evaluation boundary, bind actualcall args BEFORE allocator; checking tuple/MappingProxyType in wrapper alone is NOT preallocation binding proof. Source classcall already evaluates kwargs BEFORE actualallocator. Four actual finite quiet children must naturally wait, root-heldinstance cleanupONLY never sourcebackfill/release. New Auxpath distinct from consumed direct path; no repeat direct cases. Need up to4 focused test pitfalls/new source-supported scenarios, max220words, no mockallPopen/kill/retry/publiccleanup/admission approval.\n\n'+'\n\n'.join(ast.get_source_segment(s,n) for n in c.body if isinstance(n,ast.FunctionDef) and n.name in ('__init__','start'))
 (D/'tests-context.txt').write_text(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--stdin','--num-predict','1400','--max-input-chars','13000','--max-response-chars','7500','--timeout','180','--save-output',str(D/'tests.txt'),'--prompt','NEW Auxiliary preconstructor real finite controls: up to4 concrete pitfalls, max220words. Do not repeat direct-path tests or invent SDK/physicalclosure authority.']
 put('tests-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=plan['source_epoch']))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);put('tests-started.json',dict(pid=child.pid))
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (D/('tests-'+label+'.bin')).open('xb') as f:f.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('tests-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-7500:])
