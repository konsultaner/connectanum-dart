
class FrozenCommandHistoryTests(KnownActorInventoryTests):
    """New selectors only; finite OWN Python/Fixture, never SDK or release."""
    def setUp(self):
        super().setUp();self.history_sources=[];self.history_threads=[];self.history_reports=[]
    def done(self,owner):
        thread=owner._thread
        if thread is not None and all(thread is not item for item in self.history_threads):self.history_threads.append(thread)
        return super().done(owner)
    def history_owner(self,two=False):
        if not two:
            owner,op,sentinel,fault=self.initialized(mixed=True)
        else:
            first,first_ready=self.argv('history-first');second,second_ready=self.argv('history-second')
            sentinel=self.base/'FORBIDDEN-history-third'
            last=[sys.executable,'-c',"from pathlib import Path;Path(__import__('sys').argv[1]).write_text('forbidden')",str(sentinel)]
            def check():
                action=self.actions.get('callback')
                if action is not None:action()
            def archive(op):op.source_archive_sha256='0'*64;op.source_entries=1
            actual=producer.start_fixture
            def factory(**kwargs):
                run=actual(**kwargs);self.known.append(run);return run
            with mock.patch.object(producer.CommandProducer,'_source_guard',lambda op:None), \
                 mock.patch.object(producer.CommandProducer,'_make_archive',archive), \
                 mock.patch.object(producer.CommandProducer,'_input_guard',lambda op:None), \
                 mock.patch.object(producer,'start_fixture',factory):
                owner=producer.start_owned_preflight('fixture',owner_id=digest(str(self.base).encode())[:32],
                    repo=self.repo,source_commit='a'*40,runtime_commit='a'*40,run_dir=self.base/'history-run',
                    expected_archive_sha256='0'*64,inputs={'never-read.fixture':'0'*64},
                    commands=[first,second,last],lease_check=check)
                self.owners.append(owner);self.done(owner);op=self.known[-1]
                self.ready(first_ready);first_process=op.process
                self.release(self.base/'history-first-release')
                first_status=first_process.wait(3)
                self.history_reports.append(dict(fixture_only_first_actual_wait=dict(pid=first_process.pid,status=first_status)))
                self.assertEqual(0,first_status)
                owner.continue_wait(.01);self.done(owner);self.ready(second_ready)
            self.assertEqual(2,len(op._command_attempts))
            fault=RuntimeError('OWN failure after second finite command starts')
            def fail(current,timeout):self.assertIs(op,current);raise fault
            with mock.patch.object(producer.CommandProducer,'wait',fail):owner.continue_wait(0);self.done(owner)
        self.history_sources.append(dict(owner=owner,op=op,history=op._command_attempts,
            attempts=tuple(op._command_attempts),current=op._command_attempt,events=op.events,sentinel=sentinel))
        return owner,op,sentinel
    def history_snapshot(self,label,owner):
        rows=owner.command_history_observations() if hasattr(owner,'command_history_observations') else ()
        result=dict(scope='finite Fixture/SYNTHETIC callbacks only, no SDK/canonical/physical closure',
            view=dict(owner.observe(0)),workers=[dict(row) for row in owner.worker_lifecycle()],
            rows=[dict(row) for row in rows])
        with (self.base/(label+'.json')).open('x') as out:json.dump(result,out,indent=2)
        return rows
    def freeze_history(self,owner):
        self.assertIs(owner,owner.freeze_command_history());self.done(owner)
        return self.history_snapshot('history-frozen-'+str(len(owner._workers)),owner)
    def test_two_actual_commands_retained_and_no_actor_IO(self):
        owner,op,sentinel=self.history_owner(True)
        attempts=tuple(op._command_attempts);first,second=[item['process'] for item in attempts]
        self.assertIsNot(first,second);self.assertTrue(attempts[0]['wait_observed'])
        with mock.patch.object(producer.subprocess.Popen,'poll',side_effect=AssertionError('poll forbidden')), \
             mock.patch.object(producer.subprocess.Popen,'wait',side_effect=AssertionError('wait forbidden')), \
             mock.patch.object(producer.os,'fstat',side_effect=AssertionError('fstat forbidden')), \
             mock.patch.object(producer.os,'read',side_effect=AssertionError('read forbidden')), \
             mock.patch.object(producer.os,'close',side_effect=AssertionError('close forbidden')):
            rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['snapshot_checked']);self.assertFalse(rows[0]['quarantined'])
        commands=[row for row in rows if row['role']=='command'];self.assertEqual(2,len(commands))
        self.assertEqual([first.pid,second.pid],[row['pid'] for row in commands])
        self.assertEqual([True,False],[row['method_wait_observed'] for row in commands])
        self.assertIs(first,owner._history_attempt_refs[0]['process'])
        self.assertIs(second,owner._history_attempt_refs[1]['process'])
        self.assertTrue(op.pending);self.assertFalse(op.finished);self.assertIsNone(op.result)
        self.assertFalse(op.log.closed);self.assertFalse(op.events.closed);self.assertFalse(sentinel.exists())
        for row in rows:
            self.assertIs(type(row),producer.MappingProxyType)
            for value in row.values():self.assertIn(type(value),(str,int,bool,type(None)))
            self.assertIsNone(row['actor_ownership_complete'])
            for flag in ('capture_ready','source_admitted','live_admission'):self.assertFalse(row[flag])
        with self.assertRaises(TypeError):rows[0]['pending']=False
        for action in [owner.freeze_command_history,owner.freeze_known_actors,lambda:owner.continue_wait(0)]:
            with self.assertRaises(producer.ProducerError):action()
    def test_command_quarantine_does_not_drop_available_data(self):
        owner,op,_=self.history_owner();owner._command_quarantined=True
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['snapshot_checked'])
        self.assertTrue(owner._command_quarantined);self.assertIs(op,owner._history_producer)
        self.assertTrue(any(row['role']=='auxiliary' for row in rows))
    def test_current_outside_list_retained_and_quarantined(self):
        owner,op,_=self.history_owner();current=op._command_attempt
        op._command_attempts=[]
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['quarantined']);self.assertFalse(rows[0]['snapshot_checked'])
        self.assertTrue(rows[0]['current_outside_history']);self.assertIs(current,owner._history_current_attempt)
        self.assertIs(op.process,current['process']);self.assertIsNotNone(owner._history_primary_error)
    def test_callback_list_swap_keeps_original_handles(self):
        owner,op,_=self.history_owner();original=op._command_attempts;child=op.process
        self.actions['callback']=lambda:setattr(op,'_command_attempts',list(original))
        rows=self.freeze_history(owner)
        self.assertTrue(rows[0]['quarantined']);self.assertIs(child,owner._history_attempt_refs[0]['process'])
        self.assertTrue(any(item is original for item in owner._history_binding))
        self.assertTrue(op.pending);self.assertIsNone(op.result)
    def test_hostile_public_record_key_never_invokes_equality(self):
        owner,op,_=self.history_owner();record=op.records[-1];previous=record.pop('returncode');calls=[]
        class Key:
            def __hash__(self):return hash('returncode')
            def __eq__(self,other):calls.append('equality');raise AssertionError('custom equality')
        key=Key();record[key]=None
        try:
            rows=self.freeze_history(owner)
            self.assertEqual([],calls);self.assertTrue(rows[0]['quarantined'])
            self.assertIs(op.process,owner._history_attempt_refs[0]['process'])
        finally:
            del record[key];record['returncode']=previous
    def test_unknown_start_is_not_invented_no_actor_or_zero(self):
        owner,op,_=self.history_owner();attempt=op._command_attempt
        prior=attempt['popen_returned'];attempt['popen_returned']=False
        try:
            rows=self.freeze_history(owner);command=next(row for row in rows if row['role']=='command')
            self.assertTrue(rows[0]['quarantined']);self.assertTrue(command['start_outcome_unknown'])
            self.assertTrue(command['retained_process']);self.assertIsNone(command['method_wait_status'])
            self.assertIs(op.process,owner._history_current_attempt['process'])
        finally:attempt['popen_returned']=prior
    def test_old_inventory_and_history_are_mutually_terminal(self):
        owner,op,_=self.history_owner();self.freeze(owner)
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
        self.assertFalse(owner._history_attempted)
    def test_emit_attempt_refusal_is_unchanged(self):
        owner,op,_=self.history_owner();owner._owner_emit_attempted=True
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
        self.assertFalse(owner._history_attempted);self.assertIs(op,owner._operation)
    def test_thread_setup_attempt_stays_terminal(self):
        owner,op,_=self.history_owner();error=RuntimeError('OWN history Thread setup fault before native constructor')
        with mock.patch.object(producer.threading,'Thread',side_effect=error):
            self.assertIs(owner,owner.freeze_command_history())
        self.history_snapshot('setup-terminal',owner)
        self.assertTrue(owner._history_attempted);self.assertIsNone(owner._workers[-1]['_thread'])
        self.assertFalse(owner._workers[-1]['call_done']);self.assertTrue(owner._workers[-1]['start_settled'])
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
    def test_private_primary_survives_cache_secondary_and_stale_rows(self):
        owner,op,_=self.history_owner();original=op._command_attempts
        self.actions['callback']=lambda:setattr(op,'_command_attempts',list(original))
        actual=producer._RetainedPreflightOwner._cache_command_history
        error=OSError(5,'OWN cache publication fault');calls=[]
        def cache(current,rows,checked,quarantined):
            calls.append((checked,quarantined))
            if len(calls)>1:raise error
            return actual(current,rows,checked,quarantined)
        with mock.patch.object(producer._RetainedPreflightOwner,'_cache_command_history',cache):
            rows=self.freeze_history(owner)
        self.assertTrue(owner._history_quarantined);self.assertIsNotNone(owner._history_primary_error)
        self.assertIsNot(error,owner._history_primary_error);self.assertIs(error,owner._history_secondary_errors[0])
        self.assertFalse(rows[0]['quarantined']) # old PUBLIC row is historical; private state rules
        with self.assertRaises(producer.ProducerError):owner.freeze_command_history()
    def tearDown(self):
        # Exact finite-unit handles only. No source finish/next spawn or marker backfill.
        pre=[];buffers=[]
        operations=[]
        for owner in self.owners:
            if owner._operation is not None and all(owner._operation is not op for op in operations):operations.append(owner._operation)
        for op in self.known:
            if all(op is not item for item in operations):operations.append(op)
        for op in operations:
            data=op.__dict__;buffer=data.get('output_buffer')
            if type(buffer) is bytes:
                with (self.base/('before-buffer-'+str(len(buffers))+'.bin')).open('xb') as out:out.write(buffer)
                buffers.append(dict(size=len(buffer),sha256=digest(buffer)))
            pre.append(dict(pending=data.get('pending') if type(data.get('pending')) is bool else None,
                finished=data.get('finished') if type(data.get('finished')) is bool else None,
                result_is_None=data.get('result') is None,records=len(data.get('records',[]))))
        with (self.base/'before-unit-teardown.json').open('x') as out:json.dump(pre,out,indent=2)
        self.actions.clear()
        for event in self.barriers:event.set()
        for gate in self.gates:self.release(gate)
        threads=[]
        for owner in self.owners:
            thread=owner._thread
            if thread is not None and all(thread is not item for item in self.history_threads):self.history_threads.append(thread)
        for thread in self.history_threads:
            returned=thread.join(3);threads.append(dict(ident=thread.ident,join_return_is_None=returned is None,alive=thread.is_alive()))
        actors=[];waited=[];closed=[]
        for op in operations:
            data=op.__dict__;records=data.get('records')
            if type(records) is list and records and data.get('process') is not None:
                while records[-1]['output_eof'] is not True:self.actual_drain(op,self.time.monotonic()+1)
            source=next((item for item in self.history_sources if item['op'] is op),None)
            attempts=() if source is None else source['attempts']
            for attempt in attempts:
                child=attempt['process']
                if child is not None and all(child is not item for item in waited):
                    status=child.wait(3);waited.append(child)
                    actors.append(dict(role='command',pid=child.pid,status=status,method_marker_not_backfilled=True))
            for aux in data.get('auxiliary_operations',[]):
                if aux.process is None:continue
                result=None
                while result is None:result=self.actual_aux_wait(aux,1)
                child=aux.process
                if all(child is not item for item in waited):
                    status=child.wait(3);waited.append(child)
                    actors.append(dict(role='auxiliary',pid=child.pid,status=status,
                        outputs=result.get('outputs'),returncode=result.get('returncode')))
            writers=[attempt.get('log') for attempt in attempts]
            writers += [data.get('log'),data.get('events')]
            for writer in writers:
                if writer is None or any(writer is item for item in closed):continue
                closed.append(writer)
                if writer.closed:continue
                fd=writer.fileno();held=os.fstat(fd);path=Path(writer.name);now=path.stat()
                self.assertEqual((held.st_dev,held.st_ino),(now.st_dev,now.st_ino))
                writer.close()
                self.history_reports.append(dict(fixture_only_known_writer_close=dict(fd=fd,closed=writer.closed)))
            if source is not None:
                self.assertFalse(source['sentinel'].exists())
                output=Path(data['output_log'].name).read_bytes()
                stream=data['output_hash'].hexdigest()
                self.history_reports.append(dict(current_merged_output=dict(size=len(output),sha256=digest(output),stream_sha256=stream,eof=records[-1]['output_eof'])))
                self.assertEqual(digest(output),stream);self.assertTrue(records[-1]['output_eof'])
        with (self.base/'unit-teardown.json').open('x') as out:json.dump(dict(threads=threads,actors=actors,original_buffers=buffers,notes=self.history_reports),out,indent=2)
        self.assertTrue(all(not row['alive'] for row in threads))
        self.assertTrue(all(row['status']==0 for row in actors))
