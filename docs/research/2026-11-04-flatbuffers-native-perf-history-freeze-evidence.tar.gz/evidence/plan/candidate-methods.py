
    def _history_failure(self,error):
        self._history_quarantined=True
        if self._history_primary_error is None:self._history_primary_error=error
        else:self._history_secondary_errors.append(error)

    def _capture_command_history(self,retain):
        # References/scalars only: never inspect retired FD numbers or poll/wait.
        op=self._operation
        if retain:self._history_producer=op
        binding=[]
        if retain:self._history_binding=binding
        else:self._history_check_binding=binding
        seen=set();bad=False
        def hold(value,deep=False):
            nonlocal bad
            if retain:self._history_capture_current=value
            binding.append(value)
            kind=type(value)
            if kind not in (dict,list,tuple) or not deep:return
            ident=id(value)
            if ident in seen:return
            seen.add(ident)
            if kind is dict:
                pairs=tuple(dict.items(value))
                for key,item in pairs:
                    hold(key)
                    if type(key) is not str:bad=True
                    hold(item,True)
            else:
                for item in value:hold(item,True)
        def dictionary(obj,kind,deep=False):
            nonlocal bad
            hold(obj)
            if type(obj) is not kind:bad=True;return None
            data=object.__getattribute__(obj,'__dict__')
            hold(data,deep)
            if type(data) is not dict:bad=True;return None
            pairs=tuple(dict.items(data))
            for key,value in pairs:
                if not deep:hold(key);hold(value)
                if type(key) is not str:bad=True
            if any(type(key) is not str for key,value in pairs):return None
            return data
        def primitive(value,kind,nullable=False):
            return (nullable and value is None) or type(value) is kind
        def process(proc):
            if proc is None:return False,None,None,True
            data=dictionary(proc,_COMMAND_POPEN_TYPE)
            if data is None:return False,None,None,False
            pid=data.get('pid');status=data.get('returncode')
            okay=type(pid) is int and pid>0 and 'returncode' in data and primitive(status,int,True)
            return True,pid if type(pid) is int else None,status if primitive(status,int,True) else None,okay
        hold(op)
        if threading.current_thread() is not self._thread:
            raise ProducerError('command history capture requires retained worker')
        owner_callback=self._kwargs.get('lease_check');hold(owner_callback)
        if retain:self._history_callback=owner_callback
        fields=dictionary(op,CommandProducer)
        data={} if fields is None else fields
        history=data.get('_command_attempts');current=data.get('_command_attempt')
        records=data.get('records');ledger=data.get('auxiliary_operations')
        hold(history,True);hold(current,True);hold(records,True);hold(ledger)
        attempts=tuple(history) if type(history) is list else ()
        auxiliaries=tuple(ledger) if type(ledger) is list else ()
        if retain:
            self._history_attempt_refs=attempts;self._history_current_attempt=current
            self._history_auxiliary_refs=auxiliaries
        # Each attempt/current/auxiliary root is retained before any callback.
        extra=() if current is None or any(item is current for item in attempts) else (current,)
        all_attempts=attempts+extra
        for item in all_attempts:hold(item,True)
        auxiliary_fields=tuple(dictionary(aux,AuxiliaryCommand,True) for aux in auxiliaries)
        current_process=data.get('process');hold(current_process)
        current_direct=process(current_process)
        callback_ok=callable(owner_callback) and data.get('lease_check') is owner_callback
        valid=(fields is not None and type(history) is list and '_command_attempt' in data
            and type(records) is list and type(ledger) is list
            and type(data.get('pending')) is bool and type(data.get('finished')) is bool
            and callback_ok and current_direct[3] and not extra
            and len({id(item) for item in attempts})==len(attempts)
            and len({id(aux) for aux in auxiliaries})==len(auxiliaries))
        rows=[dict(role='producer',index=-1,history_known=type(history) is list,
            history_entries=len(attempts) if type(history) is list else None,
            current_outside_history=bool(extra),auxiliary_known=type(ledger) is list,
            auxiliary_entries=len(auxiliaries) if type(ledger) is list else None,
            pending=data.get('pending') if type(data.get('pending')) is bool else None,
            finished=data.get('finished') if type(data.get('finished')) is bool else None,
            retained_current_process=current_direct[0],current_pid=current_direct[1],
            current_cached_returncode=current_direct[2],fields_valid=valid)]
        required={'index','argv','kind','tool','record','log','reader_fd','writer_fd',
            'pipe_attempted','pipe_returned','popen_attempted','popen_returned','process',
            'parent_writer_close_attempted','parent_writer_close_returned','cleanup_close_attempts',
            'stage','first_error','error_stage','wait_process','wait_status','wait_observed',
            'raw_wait_return','wait_uncertain','wait_timeouts'}
        for ordinal,attempt in enumerate(all_attempts):
            native=(type(attempt) is dict and all(type(key) is str for key in attempt))
            record={} if not native else attempt
            keys=set(record) if native else set()
            child=record.get('process');held,pid,cached,child_ok=process(child)
            public=record.get('record')
            public_native=type(public) is dict and all(type(key) is str for key in public)
            cached_record=None if not public_native else public.get('returncode')
            observed=record.get('wait_observed');status=record.get('wait_status')
            raw=record.get('raw_wait_return');wait_process=record.get('wait_process')
            scalars=(primitive(record.get('index'),int) and record.get('index')==ordinal
                and type(record.get('argv')) is tuple and all(type(arg) is str for arg in record['argv'])
                and type(record.get('kind')) is str and primitive(record.get('tool'),str,True)
                and type(record.get('stage')) is str and primitive(record.get('error_stage'),str,True)
                and type(record.get('wait_timeouts')) is int and record['wait_timeouts']>=0
                and type(observed) is bool and primitive(status,int,True)
                and type(record.get('wait_uncertain')) is bool
                and type(record.get('cleanup_close_attempts')) is list
                and all(type(record.get(key)) is bool for key in
                    ('pipe_attempted','popen_attempted','parent_writer_close_attempted'))
                and all(primitive(record.get(key),bool,True) for key in
                    ('pipe_returned','popen_returned','parent_writer_close_returned'))
                and all(primitive(record.get(key),int,True) for key in ('reader_fd','writer_fd')))
            wait_ok=((observed is False and status is None)
                or (observed is True and type(status) is int and type(raw) is int and status==raw
                    and wait_process is child and type(cached) is int and cached==status))
            public_ok=(public is None or (public_native and 'returncode' in public
                and primitive(cached_record,int,True)))
            if observed is True and cached_record is not None:
                wait_ok=wait_ok and type(cached_record) is int and type(status) is int and cached_record==status
            start_unknown=record.get('popen_attempted') is True and record.get('popen_returned') is not True
            returned_ok=(record.get('popen_returned') is not True or held)
            okay=(native and keys==required and scalars and wait_ok and public_ok
                and child_ok and returned_ok and not start_unknown and ordinal<len(attempts))
            valid=valid and okay
            rows.append(dict(role='command',index=ordinal,current=attempt is current,
                outside_history=ordinal>=len(attempts),retained_process=held,pid=pid,
                cached_returncode=cached,record_cached_returncode=cached_record if primitive(cached_record,int,True) else None,
                method_wait_observed=observed if type(observed) is bool else None,
                method_wait_status=status if primitive(status,int,True) else None,
                wait_uncertain=record.get('wait_uncertain') if type(record.get('wait_uncertain')) is bool else None,
                popen_attempted=record.get('popen_attempted') if type(record.get('popen_attempted')) is bool else None,
                popen_returned=record.get('popen_returned') if primitive(record.get('popen_returned'),bool,True) else None,
                start_outcome_unknown=start_unknown,retained_log=record.get('log') is not None,
                stage=record.get('stage') if type(record.get('stage')) is str else None,fields_valid=okay))
        for index,(aux,aux_data) in enumerate(zip(auxiliaries,auxiliary_fields)):
            values={} if aux_data is None else aux_data
            held,pid,cached,child_ok=process(values.get('process'))
            okay=(aux_data is not None and 'process' in values and child_ok
                and values.get('lease_check') is owner_callback
                and all(type(values.get(key)) is bool for key in ('started','pending','finished')))
            valid=valid and okay
            rows.append(dict(role='auxiliary',index=index,retained_process=held,pid=pid,cached_returncode=cached,
                started=values.get('started') if type(values.get('started')) is bool else None,
                pending=values.get('pending') if type(values.get('pending')) is bool else None,
                finished=values.get('finished') if type(values.get('finished')) is bool else None,fields_valid=okay))
        valid=valid and not bad
        rows[0]['fields_valid']=valid
        return binding,rows,valid

    def _cache_command_history(self,rows,checked,quarantined):
        error=self._history_primary_error
        label=None if error is None else type.__dict__['__name__'].__get__(type(error),type)
        self._history_rows=tuple(MappingProxyType(dict(row,scope='command_history_data_only',
            snapshot_checked=checked,quarantined=quarantined,first_error=label,
            actor_ownership_complete=None,capture_ready=False,source_admitted=False,live_admission=False))
            for row in rows)

    def _freeze_command_history(self):
        rows=[]
        try:
            original,rows,valid=self._capture_command_history(True)
            self._cache_command_history(rows,False,not valid)
            if not valid:raise ProducerError('command history fields or start outcome unknown')
            self._history_callback()
            current,after,valid=self._capture_command_history(False)
            if not valid or len(original)!=len(current) or any(a is not b for a,b in zip(original,current)):
                raise ProducerError('command history binding changed across lease callback')
            self._cache_command_history(rows,True,False)
        except BaseException as error:
            self._history_failure(error)
            try:self._cache_command_history(rows,False,True)
            except BaseException as secondary:self._history_failure(secondary)
            raise self._history_primary_error
        return self._history_rows

    def freeze_command_history(self):
        """One terminal DATA snapshot; no actor I/O, closure or admission."""
        return self._schedule('command_history_inventory')

    def command_history_observations(self):
        with self._lock:return self._history_rows
