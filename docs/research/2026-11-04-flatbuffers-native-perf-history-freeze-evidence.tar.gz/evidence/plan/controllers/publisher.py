import sys,pathlib,json,hashlib,os,stat,tarfile,io,gzip,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts')
import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 p=pathlib.Path('/tmp/connectanum-native-perf-history-freeze');a=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design-v2')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-root-assessment')
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart');d=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
 sha=lambda b:hashlib.sha256(b).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 admin=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-administration')
 admin.mkdir()
 commands=[]
 def command(argv):
  lease.verify_identity()
  slot=len(commands);rec=dict(argv=argv,status=None,stdout_eof=False,stderr_eof=False)
  commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  rec['Popen']=child;rec['pid']=child.pid
  stdout,stderr=child.communicate()
  rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=admin/(str(slot)+'-'+label+'.bin')
   with path.open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_size']=len(raw);rec[label+'_sha256']=sha(raw)
  safe=[{k:v for k,v in row.items() if k!='Popen'} for row in commands]
  (admin/'publication-command-progress.json').write_text(json.dumps(safe,indent=2)+'\n')
  lease.verify_identity()
  assert rec['status']==0,(argv,rec['status'],stderr[:1000])
  return stdout.decode()
 def git(*args):
  return command(['git','-C',str(d),*args])
 assert git('branch','--show-current').strip()=='codex/flatbuffers-acceptance-status'
 assert git('rev-parse','HEAD').strip()=='922b0b39bf52f29bb6d427fc8e42c0d4b340d7c3'
 assert git('status','--porcelain')==''
 h=json.loads((p/'guards-fixed-hashes.json').read_text())
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 before=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 assert before>=1024**3+256*1024**2
 put(p/'publication-declaration.json',dict(roots=[str(p),str(a),str(final_root)],own_status_docs_only=True,source_and_runtime_no_edit=True,
  new_evidence_archive_only=True,embedded_source_archives_opaque=True,regular_member_max=256*1024**2,
  no_official_helper_body_included=True,no_previous_archive_read=True,free_before=before,
  selected_method_test_coordinators_retained_after_calls=True))
 base='2026-11-04-flatbuffers-native-perf-history-freeze';out=d/'docs/research';archive=out/(base+'-evidence.tar.gz')
 identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
 files=[(root,path,prefix) for root,prefix in [(p,'plan'),(a,'design'),(final_root,'root-final')] for path in sorted(root.rglob('*'))]
 members=[];special=[]
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w|') as tar:
    for root,path,prefix in files:
     first=path.lstat();rel=prefix+'/'+path.relative_to(root).as_posix()
     if stat.S_ISDIR(first.st_mode):continue
     if not stat.S_ISREG(first.st_mode):
      special.append(dict(path=rel,mode=first.st_mode));continue
     fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
     try:
      held=os.fstat(fd);assert identity(first)==identity(held) and held.st_size<=256*1024**2
      member=tarfile.TarInfo('evidence/'+rel);member.size=held.st_size;member.mode=stat.S_IMODE(held.st_mode)
      member.uid=held.st_uid;member.gid=held.st_gid;member.mtime=held.st_mtime
      digest=hashlib.sha256()
      class Reader:
       def read(self,size):
        data=os.read(fd,size);digest.update(data);return data
      tar.addfile(member,Reader())
      assert not os.read(fd,1) and identity(held)==identity(os.fstat(fd))==identity(path.lstat())
      members.append(dict(path=member.name,size=held.st_size,sha256=digest.hexdigest(),source_identity=identity(held)))
     finally:os.close(fd)
 digest=hashlib.sha256()
 with archive.open('rb') as f:
  for part in iter(lambda:f.read(65536),b''):digest.update(part)
 archive_sha=digest.hexdigest();expected={v['path']:v for v in members};seen=set()
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar:
   assert member.isfile() and member.name in expected and member.name not in seen
   digest=hashlib.sha256();size=0
   with tar.extractfile(member) as f:
    for part in iter(lambda:f.read(65536),b''):size+=len(part);digest.update(part)
   assert size==expected[member.name]['size'] and digest.hexdigest()==expected[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(expected)
 root=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-root-readback.json')
 put(root,dict(archive_sha256=archive_sha,regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special,
  members=members,new_archive_only=True,no_old_archive_analysis_or_tests_repeated=True))
 assessment=json.loads((final_root/'assessment.json').read_text());assessment['coordinator_provenance_qualification']='Preceding owner-error declaration says selected full coordinators saved beforeexecution; actual full controllers were serialized after calls. Per-call command-before receipts/source buffers distinct. No old evidence rewritten or execution admission inferred.'
 assessment['new_public_evidence']=dict(archive_sha256=archive_sha,
  regular_members=len(members),all_regular_members_byteexact=True,special_nodes_metadata_only=special)
 put(out/(base+'-assessment.json'),assessment)
 note="# Frozen command history as terminal data\n\nA separate serialized owner action now freezes all available direct command\nhistory and auxiliary references as data. It accepts a failed retained producer\nwhether initialization returned or raised, while retaining the existing\nowner_emit_attempted refusal and old auxiliary predicates. Its reservation\nprecedes Thread setup/start. It is mutually terminal with the earlier known\ninventory/log-seal actions and blocks later ordinary producer phases.\nThe original worker join and settled-start gates still apply. The new worker\nleaves earlier owner pending/finished observations historical.\n\nExact producer/current process/record/log/journal, original history list,\nordered attempt dictionaries, current attempt and auxiliary roots precede\ncallback I/O. Builtin containers and native string keys are checked before\nlookups or custom equality. A current attempt outside its list is retained\nand quarantined. Unknown starts are not invented absent or successful.\nThe original binding becomes an immutable tuple before cache publication or\nthe locally retained original callback. Current process/record and historical\nrecord alignment are checked; callback drift quarantines. Private exact first/\nsecondary errors and durable quarantine remain authoritative if a public row\ncannot be updated. Cached public rows contain immutable primitive data only.\n\nNo new poll, wait, stream/log I/O, FD metadata, close, audit, next spawn,\nproducer completion, result/receipt publication or retag occurs. Historical\nFD numbers and closed objects remain data and never authorize operations on a\nreused descriptor. Stored method waits and cached returncodes remain distinct;\ncached codes do not prove a fresh wait syscall or liveness. These checks do\nnot provide global atomicity, ABA protection, foreign-write prevention, writer/\ndescendant authentication, physical EX release or admission. Raw private\nbindings are not a concurrent observer API or a heap/RSS bound.\n\nBefore implementation, ten new controls yield one fixture failure and nine\nmissing-API errors. The fixture mocked archive creation but omitted the\npost-command synthetic source.tar hash boundary. The original wait correctly\nfinishes failed before the second command starts. Its actual first wait0 is\nsaved; complete initial actor/FD/API journaling is absent and never rebuilt.\nOnly that blocked case is corrected and rerun before implementation, producing\none missing-API error. The fixture now explicitly mocks only that source.tar\nhash; output hashing remains native. Source history roots are retained earlier.\n\nInitial12selected pass:10new controls plus2required existing known-owner\ncallers. Three new controls then fail: a foreign current Popen and inconsistent\ncurrent public record receive checked rows, and a callback clears the mutable\nprivate binding. Current/history process and record alignment plus immutable\nbinding guards correct these. Four selected controls pass: those three plus\nthe affected actual two-command case. Thirteen new methods exist; this is not\na combined full-final13/14/16 or canonical result.\n\nControls use actual finite OWN Python/Fixture processes, synthetic callbacks\nand mocked source/archive/input boundaries. The positive history case starts\ntwo separately retained commands, overwrites the current process normally and\nkeeps the second pending; the third sentinel stays absent. The original source\nwait records its method return after an earlier real unit wait has cached0,\nwhich is legitimate and does not establish a new wait syscall. Other controls\nretain actual auxiliary processes. Negative field/key restoration and known\nsame-handle drain/wait/log close are unit teardown only, never a live workaround,\nrecovery, release or source-flag retag. New precleanup views/buffers and teardown\nsigned waits, merged EOF/full current log digest/stream hash and auxiliary\noutputs are retained. Old required setup/API returns remain incompletely\nserialized. No SDK/version/bootstrap/compiler/native/canonical or complete\ninterpreter/delegate/descendant/writer proof follows.\n\nGLM28462 architecture and Qwen29003 test advice complete0 and are reaped.\nROOT accepts an explicit action/mutual terminal reservation and rejects the\nclaim that failed initialized owners cannot reenter the scheduler, an extra\ncommand-quarantine exclusion for data retention, and a prohibition on normal\nowner Thread/cache slots. ROOT rejects invented test APIs, mocking builtin\nlist.append, moving entries out of the original ledger, observer mutation\nclaims and mock-only positive processes. The selected current-source review\n30235 ends directly1 at its token limit: stdout0; stderr697B reports6495 visible\noutput characters. The full partial/final answer is absent. It is reachable\nand reaped, not unavailable or approval; the request is not repeated.\nROOT checks whole final affected methods/tests and structural invariants,\nnot a model approval of the full current source.\n\nSix owner methods are added; only constructor/schedule/work change among old\nowner methods. Removing those additions projects the three methods byteexact\nto the original. CommandProducer, AuxiliaryCommand, other owner methods,\nmodule functions/factories/gates/emitters, original test classes, other18\nhelpers and3selected bin scripts remain byteexact. Final producer\nb21de603411cae89e1956f78057e8ff9e702b3b3a1e2fcfb4fc1b39be04f84c6;\ntest45087533599c3d141513bd6c60660712cd36dcc31606e15b717a2e21f399957b.\nFour new post-control Git queries retain direct signed0 and both separate EOF\nstreams: contracted branch/HEAD601/twenty untracked helpers/empty tracked\nproduction diff. Native outputs or loaded instructions are not newly proved.\nAll20 helpers remain uncommitted, uncanonical and unadmitted; production601 is\nunedited. Private controllers remain retained artifacts outside HELPERBUNDLE20.\nNo source-branch commit/push/adoption or strict dispatch occurs.\n\nCoordinator provenance correction: the preceding owner-error publication\ndeclaration says selected coordinators were saved before execution. Those\nfull controller files were serialized after their calls. Actual per-call\ncommand-before receipts and source buffers remain separately retained.\nThis phase records controller files retained after calls. No evidence is\nreconstructed, archive rewritten or before-execution admission inferred.\n\nIndependent historical continuation/log sealing, transitive generic FDs,\naudit partial actors/unknown starts, historical writers/interpreters/\ndelegates/descendants and a full physical actual officialEX controller remain\nincomplete. The new action permits only a terminal data snapshot. Old emit\nfreeze refusal and auxiliary predicates remain. No status, EOF, join, closed\nobject, empty ledger or source-file fact grants release/admission. Original\nPATH/SDK/bootstrap/first3locks/hiddenconfigs/current20canonical/new source\npackage/OWN native-driver-static RLIB/compiler-tool-kernel and actual original\nhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/\ncoverage remain required before ROOT-qualified immutable COMPLETE admission\nand diagnostic data. No borrowed cohort/config/native transplant, favorable\nredo, SDK change or postGO as preproof.\n\nProvider absent, live gate always raises, controller closed, ownershipNone,\nall three admission flagsFalse. No SDK/native build/canonical/kernel/broker/\nbenchmark/capture, RAM cause/repair or strict acceptance. Latest assessment\nfree11.75GB remains below12GiB: build floor CLOSED, recheck before any build.\nScoped controls checked their separate1GiB floor. Cause unmeasured/no cleanup.\nPR132 stays OPEN DRAFT on130; issue103 and milestone remain OPEN.\n"
 with (out/(base+'-preparation.md')).open('x') as f:f.write(note)
 block="## 2026-11-04 — Historical command inventory frozen as data\n\nA separate terminal owner action retains command/auxiliary history before callback I/O and exposes immutable primitive observations. Unknown starts and record/process/binding drift quarantine; no actor/FD I/O, pipeline advancement, producer retag, release or admission. Before10 yields1fixture failure+9missingAPI errors; the corrected blocked fixture yields1missingAPI error. Initial12selected pass;3new guards fail then4targeted pass separately, not a full-final13/canonical result. Selected review hits a token limit; ROOT verifies final methods/tests/invariants. All20 helpers remain uncommitted/uncanonical/unadmitted; production601 unedited. Physical continuation/closure/runtime admission remain incomplete; build floor CLOSED below12GiB. Prior coordinator-before-execution wording is corrected: full controllers were retained after calls.\n\n[Preparation](research/2026-11-04-flatbuffers-native-perf-history-freeze-preparation.md), [assessment](research/2026-11-04-flatbuffers-native-perf-history-freeze-assessment.json), [evidence](research/2026-11-04-flatbuffers-native-perf-history-freeze-evidence.tar.gz).\n\n"
 for file,content in [('docs/project_state.md',block),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',block.replace('](research/','](../research/'))]:
  path=d/file;text=path.read_text();at=text.index('## ');path.write_text(text[:at]+content+text[at:])
 paths=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']+['docs/research/'+base+suffix for suffix in ('-preparation.md','-assessment.json','-evidence.tar.gz')]
 git('add','--',*paths)
 git('diff','--cached','--check')
 git('commit','-m','docs: freeze historical command inventory as data')
 commit=git('rev-parse','HEAD').strip()
 git('push','origin','codex/flatbuffers-acceptance-status')
 assert not git('status','--porcelain')
 for rel,digest in h.items():assert sha((r/rel).read_bytes())==digest
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['history_freeze_component'].update(publication_pending=False,docs_commit=commit,root_readback=str(root),evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),never_repeat_unchanged=True)
 n['history_freeze_GitHub_descriptions_pending']=True;n['history_freeze_automation_update_pending']=True
 n['last_free_bytes']=os.statvfs(d).f_bavail*os.statvfs(d).f_frsize
 v['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v['status_docs_commit']=commit
 c.write_text(json.dumps(v,indent=2)+'\n')
 lease.verify_identity()
 print(json.dumps(dict(commit=commit,evidence_archive_sha256=archive_sha,evidence_regular_members=len(members),all_byteexact=True,free_after=n['last_free_bytes'])))
