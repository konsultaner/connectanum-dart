import sys,pathlib,json,ast,hashlib,subprocess,datetime,os
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 P=pathlib.Path('/tmp/connectanum-native-perf-history-freeze');D=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design-v2')
 root=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-root-assessment');root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,value):
  with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 original=json.loads((P/'original-hashes.json').read_text());final=json.loads((P/'guards-fixed-hashes.json').read_text())
 assert all(sha((R/rel).read_bytes())==digest for rel,digest in final.items())
 assert {rel for rel in final if final[rel]!=original[rel]}=={'tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py'}
 def nodes(text):
  return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 def methods(text,name):
  cls=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name==name)
  return {n.name:ast.get_source_segment(text,n) for n in cls.body if isinstance(n,ast.FunctionDef)}
 old=(P/'original-source/tool/native_perf_build_producer.py').read_text();new=(R/'tool/native_perf_build_producer.py').read_text()
 on=nodes(old);nn=nodes(new);assert set(on)==set(nn)
 assert all(nn[name]==body for name,body in on.items() if name!='_RetainedPreflightOwner')
 om=methods(old,'_RetainedPreflightOwner');nm=methods(new,'_RetainedPreflightOwner')
 added={'_history_failure','_capture_command_history','_cache_command_history','_freeze_command_history','freeze_command_history','command_history_observations'}
 assert set(nm)-set(om)==added
 assert {name for name in om if om[name]!=nm[name]}=={'__init__','_schedule','_work'}
 init_addition="        self._history_attempted=False;self._history_rows=()\n        self._history_producer=None;self._history_binding=None;self._history_check_binding=None\n        self._history_callback=None;self._history_capture_current=None\n        self._history_attempt_refs=();self._history_current_attempt=None;self._history_auxiliary_refs=()\n        self._history_primary_error=None;self._history_secondary_errors=[];self._history_quarantined=False\n"
 assert nm['__init__'].replace(init_addition,'')==om['__init__']
 scheduled=nm['_schedule'].replace("            if self._history_attempted:\n                raise ProducerError('command history attempt is permanently terminal')\n",'')
 scheduled=scheduled.replace("            if action=='command_history_inventory':\n                if self._failed is not True or self._operation is None or self._owner_emit_attempted:\n                    raise ProducerError('command history snapshot not eligible')\n                self._history_attempted=True\n            elif action=='known_log_seal':","            if action=='known_log_seal':")
 assert scheduled==om['_schedule']
 worked=nm['_work'].replace("\n            elif action=='command_history_inventory':result=self._freeze_command_history()",'')
 worked=worked.replace("('actor_inventory','known_stream_wait','known_log_seal','command_history_inventory')","('actor_inventory','known_stream_wait','known_log_seal')")
 assert worked==om['_work']
 for name in added:
  tree=ast.parse(nm[name])
  for node in ast.walk(tree):
   if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute):
    assert node.func.attr not in {'poll','wait','read','write','open','close','fstat','stat','fsync','flush','Popen','start','join','kill','terminate','_end_command','_finish','_complete'},(name,node.func.attr)
 assert "original=tuple(original);self._history_binding=original" in nm['_freeze_command_history']
 assert nm['_freeze_command_history'].index("original=tuple(original)")<nm['_freeze_command_history'].index('self._cache_command_history(')
 assert "current.get('process') is current_process" in nm['_capture_command_history']
 assert "current.get('record') is records[-1]" in nm['_capture_command_history']
 assert "public is records[ordinal]" in nm['_capture_command_history']
 assert "any(a is not b for a,b in zip(original,current))" in nm['_freeze_command_history']
 ot=nodes((P/'original-source/tool/test_native_perf_build_producer.py').read_text());nt=nodes((R/'tool/test_native_perf_build_producer.py').read_text())
 assert all(nt[name]==body for name,body in ot.items())
 assert set(nt)-set(ot)=={'FrozenCommandHistoryTests'}
 declared=[n.name for n in ast.parse(nt['FrozenCommandHistoryTests']).body[0].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
 assert len(declared)==13
 with (root/'whole-final-affected-methods-and-tests.txt').open('x') as out:
  out.write('\n\n'.join(nm[name] for name in sorted(added|{'__init__','_schedule','_work'}))+'\n\n'+nt['FrozenCommandHistoryTests'])
 invariants=dict(new_six_owner_methods=sorted(added),original_constructor_schedule_work_project_back_byteexact=True,
  all_other_owner_CommandProducer_Auxiliary_module_functions_factories_gates_emitters_byteexact=True,
  all_original_test_classes_byteexact=True,other18tools_and3bins_byteexact=True,
  no_new_actor_or_FD_IO_except_original_lease_callback=True,immutable_local_original_binding_before_cache_callback=True,
  exact_current_Popen_record_and_historical_record_alignment=True,privatecontrollers_outside_HELPERBUNDLE20=True)
 put(root/'structural-qualification.json',invariants)
 stages={}
 for stage in ['before','before-fixture-fixed','implemented','guards-before','guards-fixed']:
  raw=(P/(stage+'-tests.json')).read_bytes();data=json.loads(raw)
  stages[stage]=dict(tests=data['tests'],failures=data['failures'],errors=data['errors'],source_hashes=data['source_sha256'],report=stage+'-tests.json',sha256=sha(raw))
 assert [(s['tests'],s['failures'],s['errors']) for s in stages.values()]==[(10,1,9),(1,0,1),(12,0,0),(3,3,0),(4,0,0)]
 models={name:json.loads((D/(name+'-finish.json')).read_text()) for name in ['judge','tests','review']}
 assert models['judge']['direct_status']==models['tests']['direct_status']==0 and models['review']['direct_status']==1
 assert all(v['reaped'] for v in models.values())
 put(root/'models-raw-status.json',models)
 commands=[]
 def git(*args):
  row=dict(argv=['git','-C',str(R),*args],pid=None,status=None);commands.append(row)
  child=subprocess.Popen(row['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['pid']=child.pid
  stdout,stderr=child.communicate();row['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (root/(str(len(commands)-1)+'-'+label+'.bin')).open('xb') as out:out.write(raw)
   row[label+'_eof']=True;row[label+'_size']=len(raw);row[label+'_sha256']=sha(raw)
  put(root/('git-'+str(len(commands)-1)+'.json'),row);assert row['status']==0 and not stderr
  return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain');diff=git('diff','--name-only','HEAD','--','packages','native')
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert set(status.splitlines())=={'?? '+rel for rel in final if rel.startswith('tool/')} and not diff
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='new terminal historical frozen DATA inventory only, not continuation/physicalclosure',
  source_sha256=final['tool/native_perf_build_producer.py'],test_sha256=final['tool/test_native_perf_build_producer.py'],hashes=final,
  stages=stages,declared_new_methods=declared,
  counts_qualification='BEFORE10=1fixture-boundaryFAIL+9missingAPIERROR, not10production defects. Corrected only blocked actual2-command case yields1missingAPIERROR. Initial12PASS=10new+2required old callers. NEW3guards3FAIL ->4selectedPASS=3new+affected actual2-command case.13newdeclared cases; no combinedfullfinal13/14/16/canonical.',
  root_final_source_qualification='ROOT whole affected final source/tests plus source/AST projection checks. Six owner helpers and ctor/schedule/work additions only. Oneattempt before Thread creation; no postcatch producer refresh. Cached immutable primitive rows, private durable quarantine/first-secondary. Frozen original binding/localcallback precede cache/callback. Callback and record/Popen/layout drift quarantine while retaining original references. Public historical rows never authority. Unknown starts not invented absent/zero; no historical number FD operations.',
  raw_limits='Actual finite OWN Python/Fixture with SYNTHETIC lease callbacks and mocked source/archive/input boundaries. Two-command helper explicitly mocks only synthetic source.tar hash, no SDK/archive/native/version/canonical proof. Actual2 commands before overwrite/currentpending plus actual Aux controls, source SAMEPopen wait may return cached0 after earlier real unit wait. No fresh wait syscall. First helper fault legitimately finishes failed on missing synthetic source.tar hash before second starts; actual firstwait0 saved, full initial actor/FD/API journal not systematically serialized, never reconstructed. Later helper retains source history list earlier. New precleanup views/buffers and unit same-handle natural statuses/merged EOF/full current log digest and streamhash plus Aux outputs retained. Unit stream drain/log-close/negative field restoration never live workaround/source flag retag or full graph closure. Historical complete logs/data and child interpreter/delegates/descendant-writers not authenticated. Old required caller setup/API returns not all serialized. New tuple binding and counters not atomic/globalABA/foreignwrite prevention or heap/RSS bound.',
  models=models,ROOT_model_qualification='GLM28462 design explicit action/mutualterminal accepted. ROOT rejects false failedinitialized-unreachable claim, extra command_quarantined eligibility (DATA retains refs), no ownerthread-cache updates claim. Qwen29003 tests invents API/mocks builtinlist.append/moves entries/observe mutation/allmockpositives; ROOT uses actual finite Fixture/Python and synthetic negative boundaries, no adoption/retry or discarded handles. Selected review30235 direct1 tokenlimit: stdout0, stderr697B reports6495 visible output chars, full partial/final ABSENT, reachable/reaped NOTunavailable/approval. Never repeat unchanged review. ROOT independent whole final checks/tests/invariants; no model full-current-source approval.',
  invariants=invariants,posttest_Git=commands,branch=branch,HEAD=head,all20_uncommitted_uncanonical_unadmitted=True,
  production_tracked_diff_empty=True,native_output_instructionclosure_not_proved=True,no_source_commit_push_adoption_strictdispatch=True,
  remaining='Independent selected historical continuation/log sealing, transitive genericFD/auditpartialactors/unknownstarts/historical writers/interpreters/delegates/descendants and full physical actual officialEX controller remain incomplete. New snapshot is terminal DATA only; old emit freeze refusal/auxpredicates unchanged. No status/EOF/join/closedobject/emptyledger/sourcefile fact grants release/admission. Original PATH SDK/bootstrap/first3locks hiddenconfigs/current20canonical/newsourcepackage/OWNnative-driver-staticRLIB/compiler-tool-kernel+actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage and ROOT-qualified immutable COMPLETEadmission required before diagnosticdata.',
  provider_absent=True,live_gate_always_raises=True,controller_closed=True,ownership_complete=None,all_admission_flags=False,
  no_actual_SDK_nativebuild_canonical_kernel_broker_benchmark_capture_RAMcause_repair_acceptance=True,
  free_after=os.statvfs(R).f_bavail*os.statvfs(R).f_frsize,build_floor_bytes=12*1024**3,no_cleanup=True,space_cause_unmeasured=True)
 put(root/'assessment.json',assessment)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');v=json.loads(c.read_text());n=v['native_perf_only_diagnostic_design']
 n['history_freeze_component'].update(root_assessment=str(root),assessment=str(root/'assessment.json'),root_assessment_pending=False,
  review_pending=False,publication_pending=True,models_qualified=True,all_known_own_model_test_calls_terminal=True,never_repeat_unchanged=True,
  source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],fullphysical_bridge_incomplete=True)
 n['last_free_bytes']=assessment['free_after'];v['active_turn_status']='history_freeze_ROOT_qualified_publication_pending'
 c.write_text(json.dumps(v,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['source_sha256'],test=assessment['test_sha256'],stages={k:[s['tests'],s['failures'],s['errors']] for k,s in stages.items()},free=assessment['free_after'])))
