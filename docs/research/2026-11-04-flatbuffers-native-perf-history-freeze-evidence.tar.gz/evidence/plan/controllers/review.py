import sys,pathlib,json,ast,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();work=pathlib.Path('/tmp/connectanum-native-perf-history-freeze-design-v2')
 R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 raw=(R/'tool/native_perf_build_producer.py').read_bytes();s=raw.decode()
 expected=json.loads(pathlib.Path('/tmp/connectanum-native-perf-history-freeze/guards-fixed-hashes.json').read_text())
 assert hashlib.sha256(raw).hexdigest()==expected['tool/native_perf_build_producer.py']
 cls=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='_RetainedPreflightOwner')
 names={'_history_failure','_capture_command_history','_cache_command_history','_freeze_command_history','freeze_command_history','command_history_observations','_schedule','_work'}
 context='NEW historical frozen DATA inventory only. Empty fields initialized before constructor worker. One terminal action on failed retained producer, initializedTrue ORFalse, emitFalse, original knowninventory/log attempts refuse it. Existing oldaux predicates unchanged. Reserve BEFORE Thread setup; sameworkerjoin/startsettled gate retained; no pending/finished refresh after new worker. No actor/FD IO except original lease callback; retired FDnumbers data only. Raw handles/containers/ordered fields before callback; immutable original binding/local callback before cache. Cached primitive immutable rows/private first-secondary/quarantine. BEFORE10=1fixture synthetic archive-boundary FAIL+9missingAPIERROR, blockedcase after explicit source.tar hashmock ->1missingAPIERROR; initial12PASS=10new+2required. NEW3guards FAIL(currentPopen mismatch/currentrecord mismatch/mutableprivatebinding clear), fixed4PASS=3guards+affected actual2-command control separate, not combinedfinal/canonical. Actual finite Fixture/Python and synthetic negative boundaries only; original production601 unedited/all20 uncommitted uncanonical/unadmitted. Unknown starts remain unknown; no fullphysicalcontroller/EXrelease/descendants/writer authentication/globalatomicity/ABA/current20 canonical/admission. Review max2 source-supported bugs/max250words, preserve strict original predicates. Reject global foreign-mutator prevention or automatic close/retry/rebind/cancel recommendations; advice ROOT verifies.\n\n'
 context+='\n\n'.join(ast.get_source_segment(s,n) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in names)
 assert len(context)<27000
 def put(name,value):
  with (work/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
 with (work/'review-context.txt').open('x') as out:out.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','2000','--max-input-chars','27000','--max-response-chars','9500','--timeout','180','--save-output',str(work/'review.txt'),'--prompt','Review selected current historical DATA inventory max2 concrete source-supported gaps/max250words. No actual SDK/canonical/physicalrelease approval; no globalatomicity/ABA/foreignwrite prevention or close-cancel-retry recommendation.']
 put('review-command-before.json',dict(argv=argv,input_chars=len(context),input_sha256=hashlib.sha256(context.encode()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest()))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(context.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (work/('review-'+label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put('review-finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9500:])
