"""OWN finite current-Darwin method control; not benchmark/capture admission."""
import os,sys
if (sys.platform,os.getuid(),os.geteuid(),os.getgid(),os.getegid())!=('darwin',501,501,20,20):
    raise RuntimeError('preselected OWN current-host method context differs; no host reselection')
import ast,hashlib,json,pathlib,stat,subprocess,threading,time,types,traceback
sys.dont_write_bytecode=True
R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
P=pathlib.Path('/private/tmp/connectanum-native-perf-owned-lease-control-v4')
HELPER_INPUT=pathlib.Path("/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py")
PREP=json.loads("{\"scope\":\"NEW OWN current-host finite method-control plan, not original diagnosticdata\",\"source_sha256\":{\"tool/native_perf_admission.py\":\"a554dc4039efff204a1a5c35c7a59eaee4312fc3626b8a4224c2d2f770bc68a7\",\"tool/native_perf_blocked_exec.py\":\"3823f54a2c7d24e75f46463a64d5a4016854327fbc748adaaf7cb32cbca684c0\",\"tool/native_perf_build_producer.py\":\"7b808c4ee6bdf4a81cecf92418810472dcec3e767d483b947b2aba2760b40485\",\"tool/native_perf_guard.py\":\"9ea12fa1cf5ae11ed0c0a8018e734a653a4f3d9b40021810c2b994e5b1bb7bd9\",\"tool/native_perf_handoff.py\":\"82ee4f42e76723b79e376e7fa7dd2014203ced8024ec781852698c864c5c8f7f\",\"tool/native_perf_input_census.py\":\"e2f7295266614063cafc65edaa535e0463f1e9af01b21c505d547c3287cf226c\",\"tool/native_perf_mapped_images.py\":\"4750b1bb751772d539ffbdeb84900dbe9b8d3bb22a85ab48b16a21bf87180728\",\"tool/native_perf_metadata.py\":\"a344abfeee4454fb6740a54cc291d4cd8f862b57798ee5f0f6090c5d2631a44b\",\"tool/native_perf_proc_witness.py\":\"cf25789a22e8fc159f74631aa851fd22e0bff804086c2bbcc28ec38b5fbf719e\",\"tool/native_perf_session.py\":\"8adde8179669bcb3bf3a00c7384a04d3e6003eaf3d63aae02881f4d92f141800\",\"tool/test_native_perf_admission.py\":\"4863f391563149aa7f0de15227ac2e6529c9d710f0e9da1394401fe4fa604612\",\"tool/test_native_perf_blocked_exec.py\":\"52f5398da09094240bffabd295ba366a7d4200130e22f9f8e223fa6b745c3ba3\",\"tool/test_native_perf_build_producer.py\":\"3764ce61225b2e2c8d3c025d07eabd6a896df7ca0f59214ac14cc9b98e9a9379\",\"tool/test_native_perf_guard.py\":\"f92d44ed3363d831dcd1cc5e1cbd6a3806295537572b1f978a95c12ee55f07b0\",\"tool/test_native_perf_handoff.py\":\"da831ea8dfe36b8d050dafab7a5588981aadd4a26849b9bb86dbbdff5fa95551\",\"tool/test_native_perf_input_census.py\":\"f5c2cc34fdfef21fa97f49ecfad86cef45665cb375f8d62b700d1e37815d4aed\",\"tool/test_native_perf_mapped_images.py\":\"ab27d42656baa4ebd992d2f7a0a9d6a2240e0ef8742ba691b6fb3faf19a1ded0\",\"tool/test_native_perf_metadata.py\":\"44a37049e1fac158f1b4695d304d4181e77446377686aec4cd713c031be9bd20\",\"tool/test_native_perf_proc_witness.py\":\"cb80c2e7f86d519ec2f545c83eabacb40c1c54789d9de3f5e1ca72448eed02ba\",\"tool/test_native_perf_session.py\":\"4dfeb089ee00132f3e1332c7a6bccf5266abdf05e7593364072992aecca201e0\"},\"helper_path\":\"/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py\",\"helper_sha256\":\"d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8\",\"not_executed\":true}")
POSITIVE="import json,os,sys,time\nfrom pathlib import Path\nready,release=map(Path,sys.argv[1:3])\nwith ready.open('x') as f:json.dump({'pid':os.getpid(),'scope':'OWN finite method child'},f)\nos.mkdir(str(ready)+'.committed')\ndeadline=time.monotonic()+5\nwhile not release.is_dir():\n    if time.monotonic()>=deadline:\n        print(json.dumps({'scope':'OWN method only','natural_refusal':'release absent'}),flush=True)\n        sys.exit(78)\n    time.sleep(.01)\nprint(json.dumps({'scope':'OWN finite method child','pid':os.getpid(),'released':True}),flush=True)\n"
PROBE="import errno,hashlib,json,os,stat,sys,types\nfrom pathlib import Path\nsys.dont_write_bytecode=True\ncache,expected,logical,lease_path=sys.argv[1:5]\np=Path(cache);before=p.stat(follow_symlinks=False)\nfd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)\ntry:\n    info=os.fstat(fd);assert stat.S_ISREG(info.st_mode) and info.st_uid==501 and info.st_gid==20 and not info.st_mode&0o022\n    data=b''\n    while len(data)<=1024**2:\n        part=os.read(fd,min(65536,1024**2+1-len(data)))\n        if not part:break\n        data+=part\n    identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)\n    assert identity(before)==identity(info)==identity(os.fstat(fd))==identity(p.stat(follow_symlinks=False))\nfinally:\n    primary=sys.exception()\n    try:os.close(fd)\n    except OSError as close_error:\n        if primary is None:raise\n        primary.add_note('OWN input close also failed: '+type(close_error).__name__)\nassert len(data)<=1024**2 and hashlib.sha256(data).hexdigest()==expected\nname='own_lease_control_probe_official_helper';assert name not in sys.modules\nm=types.ModuleType(name);m.__file__=logical;sys.modules[name]=m\nexec(compile(data,logical,'exec'),m.__dict__)\nactual=str(m.local_resource_lease_path())\nassert actual==lease_path\ntry:\n    with m.local_resource_lease(exclusive=True) as lease:\n        lease.verify_identity()\n        print(json.dumps({'scope':'OWN official lease probe only','unexpected_admission':True,'lease_path':actual}),flush=True)\n        sys.exit(2)\nexcept m.LocalResourceLeaseError as error:\n    cause=error.__cause__;number=getattr(cause,'errno',None)\n    print(json.dumps({'scope':'OWN official lease probe only','refused':True,\n        'reported_error':str(error),'cause_errno':number,'cause_errno_name':errno.errorcode.get(number),\n        'lease_path':actual,'admitted_work_executed':False}),flush=True)\n    sys.exit(78 if number in (errno.EACCES,errno.EAGAIN) else 79)\n"
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read_regular(path,expected):
    before=path.stat(follow_symlinks=False)
    try:fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    except OSError as open_error:
        open_error.add_note('OWN observed input before open='+json.dumps({'path':str(path),'before':identity(before)}));raise
    info=None
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=501 or info.st_gid!=20 or info.st_mode&0o022 or not 0<info.st_size<=1024**2:
            raise RuntimeError('fixed OWN method input type/UID/GID/mode/size differs: '+str(path))
        if identity(info)!=identity(before):raise RuntimeError('input changed before read')
        chunks=[];count=0
        while count<=1024**2:
            part=os.read(fd,min(65536,1024**2+1-count))
            if not part:break
            chunks.append(part);count+=len(part)
        data=b''.join(chunks)
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info) or sha(data)!=expected:
            raise RuntimeError('input changed/hash differs: '+str(path))
        return data,{'path':str(path),'sha256':sha(data),'identity':identity(info)}
    except BaseException as read_error:
        read_error.add_note('OWN observed input='+json.dumps({'path':str(path),'before':identity(before),'held':None if info is None else identity(info)}))
        raise
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as close_error:
            if primary is None:raise
            primary.add_note('OWN input close also failed: '+type(close_error).__name__)
def module(name,data,filename):
    if name in sys.modules:raise RuntimeError('OWN module slot already exists')
    result=types.ModuleType(name);result.__file__=filename;sys.modules[name]=result
    exec(compile(data,filename,'exec'),result.__dict__)
    return result
helper_bytes,helper_info=read_regular(HELPER_INPUT,PREP['helper_sha256'])
helper=module('own_lease_control_official_helper',helper_bytes,PREP['helper_path'])
def writej(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def wait_same_owned_child(child):
    while True:
        try:return child.wait(timeout=.1)
        except subprocess.TimeoutExpired:continue
owners=[];releases=[];direct=[];direct_handles=[];callbacks=[];views=[];fallback=[];callback_lock=threading.Lock()
def command(argv,label,cwd):
    record={'argv':argv,'cwd':str(cwd),'pid':None,'returncode':None,'both_output_eof':False}
    direct.append(record)
    process=subprocess.Popen(argv,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
    direct_handles.append(process);record['pid']=process.pid
    stdout,stderr=process.communicate();record.update(returncode=process.returncode,both_output_eof=True)
    if len(stdout)>1024**2 or len(stderr)>1024**2:raise RuntimeError('OWN finite setup output exceeded bound')
    (P/(label+'.stdout')).write_bytes(stdout);(P/(label+'.stderr')).write_bytes(stderr)
    if process.returncode:raise RuntimeError('OWN setup command failed: '+label)
    return stdout
def record_view(owner,label,timeout=.1):
    view=dict(owner.observe(timeout));views.append({'label':label,**view})
    return view
def settle(owner,label):
    while True:
        view=record_view(owner,label)
        if not view['call_done']:continue
        if not view['initialized']:
            raise RuntimeError('OWN method constructor failed/unknown; exact owner retained')
        if view['producer_finished'] and not view['producer_pending']:return owner._operation.result
        if view['failed'] and view['producer_pending'] is not True:raise RuntimeError('OWN method phase failure; no recovery')
        owner.continue_wait(.1)
def make_case(producer,label,source,check,arguments):
    case=P/label;case.mkdir();repo=case/'repo';repo.mkdir()
    (repo/'child.py').write_text(source);(repo/'.gitignore').write_text('inputs/\n')
    for suffix,args in [('init',['init','-q']),('email',['config','user.email','own-fixture@example.invalid']),
                        ('name',['config','user.name','OWN Method Fixture']),('add',['add','.']),
                        ('commit',['commit','-qm','OWN finite method fixture'])]:
        command(['git',*args],label+'-'+suffix,repo)
    head=command(['git','rev-parse','HEAD'],label+'-head',repo).decode().strip()
    archive=command(['git','archive','--format=tar',head],label+'-archive',repo)
    (repo/'inputs').mkdir();input_path=repo/'inputs/fixture-data';input_path.write_bytes(b'OWN fixture data only\n')
    kwargs=dict(repo=repo,source_commit=head,runtime_commit=head,run_dir=case/'run',
        expected_archive_sha256=sha(archive),inputs={'inputs/fixture-data':sha(input_path.read_bytes())},
        commands=[[sys.executable,'child.py',*arguments]],lease_check=check)
    owner=producer.start_owned_preflight('fixture',owner_id=sha(label.encode())[:32],**kwargs)
    owners.append(owner)
    return owner,case
def callback(lease,entered=None,release=None):
    first=[True]
    def check():
        lease.verify_identity()
        info=os.fstat(lease.fd)
        with callback_lock:
            callbacks.append({'pid':os.getpid(),'thread_ident':threading.get_ident(),'fd':lease.fd,
                'lease_path':str(lease.path),'identity':identity(info),'exclusive':lease.exclusive,
                'closed':lease.closed,'inheritable':os.get_inheritable(lease.fd)})
        if entered is not None and first[0]:
            first[0]=False;entered.set()
            if not release.wait(5):raise RuntimeError('OWN initial method callback release absent')
    return check
error=None;summary=None
with helper.local_resource_lease(exclusive=True) as lease:
    lease.verify_identity()
    if os.statvfs(R).f_bavail*os.statvfs(R).f_frsize<1024**3:raise RuntimeError('scoped1GiB floor closed before method attempt')
    P.mkdir(mode=0o700)
    declaration=dict(kind='own-current-darwin-retained-preflight-lease-control-v4',
        expected_context={'platform':'darwin','uid':501,'euid':501,'gid':20,'egid':20},
        scope='OWN finite method only; no original-host/root/Linux/perf/SDK/canonical/admission',
        source_sha256=PREP['source_sha256'],helper_source_sha256=PREP['helper_sha256'],
        helper_source_local_only=True,positive_source_sha256=sha(POSITIVE.encode()),probe_source_sha256=sha(PROBE.encode()),
        proposed_fixture_outcomes=[0,78],own_positive_release_natural_refusal_seconds=5,
        own_ready_release_protocol='private directory barriers only, NOT original GO',
        no_original_workload_gate_or_request_changes=True,capture_ready=False,source_admitted=False,live_admission=False)
    writej(P/'declaration-before-inputs.json',declaration)
    lease_before={'fd':lease.fd,'path':str(lease.path),'identity':identity(os.fstat(lease.fd)),
                  'exclusive':lease.exclusive,'closed':lease.closed,'inheritable':os.get_inheritable(lease.fd)}
    writej(P/'lease-before.json',lease_before);writej(P/'helper-source-link.json',helper_info)
    input_observations=[];after_input_observations=[]
    try:
        source_dir=P/'source20';source_dir.mkdir();blobs={}
        for rel,expected in PREP['source_sha256'].items():
            data,info=read_regular(R/rel,expected);input_observations.append(info);blobs[rel]=data
            path=source_dir/pathlib.Path(rel).name;path.write_bytes(data)
        producer=module('own_current_lease_control_producer',blobs['tool/native_perf_build_producer.py'],str(R/'tool/native_perf_build_producer.py'))
        entered=threading.Event();release=threading.Event();releases.append(release)
        ready=P/'positive-ready.json';positive_release=P/'positive-release'
        positive,case=make_case(producer,'positive',POSITIVE,callback(lease,entered,release),[str(ready),str(positive_release)])
        try:
            if not entered.wait(2):raise RuntimeError('OWN real lease callback did not reach declared barrier')
            partial=record_view(positive,'actual_verified_callback_barrier',0)
            if partial['call_done'] or not partial['retained_operation'] or partial['initialized'] or partial['producer_pending'] is not None:
                raise RuntimeError('partial observer fabricated initialized producer state')
            writej(P/'partial-observation.json',partial)
        finally:release.set()
        ready_commit=pathlib.Path(str(ready)+'.committed')
        while not ready_commit.is_dir():
            view=record_view(positive,'waiting_for_own_child')
            if view['call_done']:
                if view['failed']:raise RuntimeError('OWN positive constructor/phase failed')
                if view['producer_finished']:raise RuntimeError('OWN child ended before committed readiness')
                if view['initialized']:positive.continue_wait(.05)
        child_ready=json.loads(ready.read_text())
        child_ready['commit_directory_observed_identity']=identity(ready_commit.stat())
        while not record_view(positive,'construct_complete')['call_done']:pass
        positive.continue_wait(0)
        while not record_view(positive,'zero_wait_complete')['call_done']:pass
        positive_release.mkdir(mode=0o700)
        positive_result=settle(positive,'positive_same_actor_continuation')
        if positive_result['commands'][0]['returncode']!=0 or positive_result['commands'][0]['output_eof'] is not True:
            raise RuntimeError('OWN positive natural outcome differs; terminal/no rerun')
        positive_frame=json.loads((P/'positive/run/command-000.log').read_bytes())
        if positive_frame.get('released') is not True or positive_frame.get('pid')!=child_ready.get('pid') or positive_frame.get('pid')!=positive_result['commands'][0]['pid']:
            raise RuntimeError('OWN reported child PID/release frame differs from retained direct child')
        lease.verify_identity()
        negative,case=make_case(producer,'negative',PROBE,callback(lease),[str(HELPER_INPUT),PREP['helper_sha256'],PREP['helper_path'],str(lease.path)])
        negative_result=settle(negative,'negative_same_actor_continuation')
        raw=(case/'run/command-000.log').read_bytes();probe=json.loads(raw)
        if negative_result['commands'][0]['returncode']!=78 or negative_result['commands'][0]['output_eof'] is not True or probe.get('refused') is not True or probe.get('admitted_work_executed') is not False:
            raise RuntimeError('OWN official probe outcome differs; terminal/no rerun')
        lease.verify_identity()
        after={'fd':lease.fd,'path':str(lease.path),'identity':identity(os.fstat(lease.fd)),
               'exclusive':lease.exclusive,'closed':lease.closed,'inheritable':os.get_inheritable(lease.fd)}
        if lease_before!=after:raise RuntimeError('held lease file/FD declaration continuity differs')
        if not callbacks or any(x['pid']!=os.getpid() or x['identity']!=lease_before['identity'] or not x['exclusive'] or x['closed'] or x['inheritable'] for x in callbacks):
            raise RuntimeError('actual worker callback lease observations differ')
        for rel,expected in PREP['source_sha256'].items():
            data,info=read_regular(R/rel,expected);after_input_observations.append(info)
        summary=dict(kind='own-current-darwin-method-only',outcomes=[positive_result['commands'][0]['returncode'],negative_result['commands'][0]['returncode']],
            positive_child_ready=child_ready,positive_child_frame=positive_frame,probe_report=probe,callback_count=len(callbacks),
            lease_before=lease_before,lease_after=after,source20_unchanged=True,
            own_fixture_only=True,capture_ready=False,source_admitted=False,live_admission=False,
            not_original_host_root_Linux_perf_SDK_native_or_complete_provenance=True)
    except BaseException as caught:error=caught
    finally:
        for event in releases:event.set()
        for process in direct_handles:
            if process.returncode is None:
                status=wait_same_owned_child(process)
                fallback.append({'pid':process.pid,'status':status,'scope':'OWN finite setup error wait only; raw streams may be incomplete, no replay'})
        # Every method child is OWN and finite. Preserve the same owner; no relaunch/cancel.
        for owner in owners:
            while True:
                view=owner.observe(.1)
                if not view['call_done']:continue
                if view['initialized'] and view['producer_pending']:
                    owner.continue_wait(.1);continue
                if not view['initialized'] and owner._operation is not None:
                    child=getattr(owner._operation,'process',None)
                    if child is not None:
                        status=wait_same_owned_child(child)
                        fallback.append({'pid':child.pid,'status':status,'scope':'OWN finite method error fallback only, NEVER live controller proof'})
                owner.observe(2)
                break
        writej(P/'input-observations.json',input_observations);writej(P/'after-input-observations.json',after_input_observations)
        writej(P/'callback-observations.json',callbacks);writej(P/'owner-observations.json',views)
        writej(P/'setup-parents.json',direct);writej(P/'fallback.json',fallback)
        if error is not None:writej(P/'error.json',{'type':type(error).__name__,'message':str(error),'traceback':''.join(traceback.format_exception(error))})
        if summary is not None:writej(P/'summary.json',summary)
        lease.verify_identity()
if error is not None:raise error
writej(P/'parent-after-lease.json',{'lease_closed_reported_by_official_helper':lease.closed,'no_close_replay':True})
print(json.dumps({'scope':'OWN finite method only','outcomes':summary['outcomes'],'callback_count':len(callbacks),
    'all_known_own_fixture_workers_joined':all(not x._thread.is_alive() for x in owners),
    'no_live_admission':True}))
