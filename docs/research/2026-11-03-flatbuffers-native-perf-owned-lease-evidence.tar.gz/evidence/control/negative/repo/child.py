import errno,hashlib,json,os,stat,sys,types
from pathlib import Path
sys.dont_write_bytecode=True
cache,expected,logical,lease_path=sys.argv[1:5]
p=Path(cache);before=p.stat(follow_symlinks=False)
fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
try:
    info=os.fstat(fd);assert stat.S_ISREG(info.st_mode) and info.st_uid==501 and info.st_gid==20 and not info.st_mode&0o022
    data=b''
    while len(data)<=1024**2:
        part=os.read(fd,min(65536,1024**2+1-len(data)))
        if not part:break
        data+=part
    identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert identity(before)==identity(info)==identity(os.fstat(fd))==identity(p.stat(follow_symlinks=False))
finally:
    primary=sys.exception()
    try:os.close(fd)
    except OSError as close_error:
        if primary is None:raise
        primary.add_note('OWN input close also failed: '+type(close_error).__name__)
assert len(data)<=1024**2 and hashlib.sha256(data).hexdigest()==expected
name='own_lease_control_probe_official_helper';assert name not in sys.modules
m=types.ModuleType(name);m.__file__=logical;sys.modules[name]=m
exec(compile(data,logical,'exec'),m.__dict__)
actual=str(m.local_resource_lease_path())
assert actual==lease_path
try:
    with m.local_resource_lease(exclusive=True) as lease:
        lease.verify_identity()
        print(json.dumps({'scope':'OWN official lease probe only','unexpected_admission':True,'lease_path':actual}),flush=True)
        sys.exit(2)
except m.LocalResourceLeaseError as error:
    cause=error.__cause__;number=getattr(cause,'errno',None)
    print(json.dumps({'scope':'OWN official lease probe only','refused':True,
        'reported_error':str(error),'cause_errno':number,'cause_errno_name':errno.errorcode.get(number),
        'lease_path':actual,'admitted_work_executed':False}),flush=True)
    sys.exit(78 if number in (errno.EACCES,errno.EAGAIN) else 79)
