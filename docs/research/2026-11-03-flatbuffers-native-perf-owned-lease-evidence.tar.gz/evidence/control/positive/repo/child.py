import json,os,sys,time
from pathlib import Path
ready,release=map(Path,sys.argv[1:3])
with ready.open('x') as f:json.dump({'pid':os.getpid(),'scope':'OWN finite method child'},f)
os.mkdir(str(ready)+'.committed')
deadline=time.monotonic()+5
while not release.is_dir():
    if time.monotonic()>=deadline:
        print(json.dumps({'scope':'OWN method only','natural_refusal':'release absent'}),flush=True)
        sys.exit(78)
    time.sleep(.01)
print(json.dumps({'scope':'OWN finite method child','pid':os.getpid(),'released':True}),flush=True)
