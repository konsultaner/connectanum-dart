"""Own source-frozen command evidence, not capture or canonical admission.

Caller holds the official exclusive lease. Only fixed live factories may select
canonical/production recipes; fixture commands are labelled in every receipt.
A waited child and log snapshot do not prove all descendants exited, SDK identity,
complete canonical validation, loader validity, or loaded role/native-image bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time
from types import MappingProxyType


class ProducerError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise ProducerError('Python 3.11 or newer required before producer IO')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _regular_hash(path, maximum=1024**3, *, owners=None):
    owners={os.getuid()} if owners is None else owners
    path=Path(path)
    if not path.is_absolute() or path.resolve(strict=True)!=path:
        raise ProducerError('input path must be canonical without symlinks')
    before=path.stat(follow_symlinks=False)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in owners or info.st_mode&0o022 or not 0<info.st_size<=maximum:
            raise ProducerError('input type/owner/mode/size differs')
        if identity(before)!=identity(info):raise ProducerError('input changed before read')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            h.update(part);count+=len(part)
            if count>maximum:raise ProducerError('input grew beyond bound')
        if count!=info.st_size or identity(os.fstat(fd))!=identity(info) or identity(path.stat(follow_symlinks=False))!=identity(info):
            raise ProducerError('input changed during read')
        return h.hexdigest()
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('input close failed: '+repr(e))


def _file_snapshot(path, maximum=16*1024**3):
    """Stream even empty logs, retaining a bounded before/after file snapshot."""
    path=Path(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
        if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_mode&0o022 or before.st_size>maximum:
            raise ProducerError('log snapshot type/owner/mode/size differs')
        h=hashlib.sha256();count=0
        while True:
            part=os.read(fd,min(1024**2,maximum+1-count))
            if not part:break
            count+=len(part);h.update(part)
            if count>maximum:raise ProducerError('log snapshot grew beyond bound')
        if count!=before.st_size or identity(before)!=identity(os.fstat(fd)) or identity(before)!=identity(path.stat(follow_symlinks=False)):
            raise ProducerError('log changed during snapshot')
        return {'size':count,'sha256':h.hexdigest()}
    finally:
        primary=sys.exception()
        try:os.close(fd)
        except OSError as e:
            if primary is None:raise
            primary.add_note('snapshot close failed: '+repr(e))


def _write_json(path,value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode())
        f.flush();os.fsync(f.fileno())


VERSION_ARGS={'git':('--version',),'python3':('--version',),'bash':('--version',),
              'dart':('--version',),'cargo':('--version',),'rustc':('--version','--verbose')}
TOOL_FIELDS={'entry','target','sha256','version_prefix','entry_device','entry_inode','entry_mode',
             'entry_uid','entry_link','target_device','target_inode','target_mode','target_uid'}


def describe_tool(name,version_prefix,*,lookup_path=None):
    """Read-only intent preparation; executes no program and authenticates no image."""
    if name not in VERSION_ARGS or type(version_prefix) is not str or not 0<len(version_prefix)<=256 or '\0' in version_prefix or '\n' in version_prefix:
        raise ProducerError('invalid fixed tool/version declaration')
    entry=shutil.which(name,path=lookup_path)
    if entry is None or not Path(entry).is_absolute():raise ProducerError('tool PATH resolution missing or nonabsolute: '+name)
    entry=Path(entry);before=entry.lstat();target=entry.resolve(strict=True)
    if not (stat.S_ISREG(before.st_mode) or stat.S_ISLNK(before.st_mode)) or before.st_uid not in (0,os.getuid()):
        raise ProducerError('tool entry type/owner differs: '+name)
    info=target.stat()
    if not info.st_mode&0o111:raise ProducerError('tool target is not executable: '+name)
    digest=_regular_hash(target,maximum=512*1024**2,owners={0,os.getuid()})
    fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_mtime_ns,s.st_ctime_ns)
    link=os.readlink(entry) if stat.S_ISLNK(before.st_mode) else None
    if fields(before)!=fields(entry.lstat()) or target!=entry.resolve(strict=True) or fields(info)!=fields(target.stat()):
        raise ProducerError('tool entry/target changed during observation: '+name)
    return {'entry':str(entry),'target':str(target),'sha256':digest,'version_prefix':version_prefix,
            'entry_device':before.st_dev,'entry_inode':before.st_ino,'entry_mode':before.st_mode,'entry_uid':before.st_uid,'entry_link':link,
            'target_device':info.st_dev,'target_inode':info.st_ino,'target_mode':info.st_mode,'target_uid':info.st_uid}


def _tool_table(value):
    if value is None:return MappingProxyType({})
    if type(value) is not dict or not 0<len(value)<=len(VERSION_ARGS):raise ProducerError('invalid tool table')
    result={}
    integers={'entry_device','entry_inode','entry_mode','entry_uid','target_device','target_inode','target_mode','target_uid'}
    for name,spec in value.items():
        if type(name) is not str or name not in VERSION_ARGS or type(spec) is not dict or set(spec)!=TOOL_FIELDS:
            raise ProducerError('invalid fixed tool snapshot schema')
        if any(type(spec[k]) is not int or spec[k]<0 for k in integers) or any(type(spec[k]) is not str or not spec[k] for k in ('entry','target','sha256','version_prefix')) or (spec['entry_link'] is not None and type(spec['entry_link']) is not str):
            raise ProducerError('invalid typed tool snapshot')
        if (not re.fullmatch('[0-9a-f]{64}',spec['sha256']) or not Path(spec['entry']).is_absolute() or not Path(spec['target']).is_absolute()
            or not 0<len(spec['version_prefix'])<=256 or '\0' in spec['version_prefix'] or '\n' in spec['version_prefix']):raise ProducerError('invalid tool digest/path/version declaration')
        result[name]=MappingProxyType(dict(spec))
    return MappingProxyType(result)


def _required_tools(value):
    if type(value) is not dict or set(value)!=set(VERSION_ARGS):
        raise ProducerError('live recipe requires all six declared tool snapshots')


class CommandProducer:
    """One reserved run and one actual child at a time; never kills or retries."""
    def __init__(self,*,repo,source_commit,runtime_commit,run_dir,expected_archive_sha256,
                 inputs,commands,lease_check,provenance,outputs=None,env_delta=None,tools=None):
        lease_check()
        if (not all(type(v) is str and re.fullmatch('[0-9a-f]{40}',v) for v in (source_commit,runtime_commit))
            or type(expected_archive_sha256) is not str or not re.fullmatch('[0-9a-f]{64}',expected_archive_sha256)
            or type(inputs) is not dict or not 0<len(inputs)<=64
            or any(type(k) is not str or Path(k).is_absolute() or '..' in Path(k).parts or type(v) is not str or not re.fullmatch('[0-9a-f]{64}',v) for k,v in inputs.items())
            or type(commands) is not list or not 0<len(commands)<=16
            or any(type(argv) is not list or not argv or any(type(v) is not str or not v or '\0' in v for v in argv) for argv in commands)):
            raise ProducerError('invalid producer plan')
        self.repo=Path(repo);self.directory=Path(run_dir)
        if self.repo.resolve(strict=True)!=self.repo or self.directory.parent.resolve(strict=True)!=self.directory.parent or self.directory==self.repo or self.repo in self.directory.parents:
            raise ProducerError('run must be a new canonical directory outside source worktree')
        self.source_commit=source_commit;self.runtime_commit=runtime_commit
        self.expected_archive_sha256=expected_archive_sha256;self.inputs=MappingProxyType(dict(inputs))
        self.tools=_tool_table(tools)
        self.task_kinds=tuple(('tool_version',name) for name in sorted(self.tools))+tuple(('recipe',None) for _ in commands)
        self.commands=tuple((self.tools[name]['entry'],*VERSION_ARGS[name]) for name in sorted(self.tools))+tuple(tuple(a) for a in commands)
        self.lease_check=lease_check;self.provenance=provenance
        self.outputs=dict(outputs or {});self.env_delta=dict(env_delta or {});self.environment={**os.environ,**self.env_delta};self.process=None;self.log=None
        self.pending=False;self.finished=False;self.result=None;self.records=[];self.git_index=0;self.deferred_error=None
        self.directory.mkdir(mode=0o700)
        self.events=(self.directory/'journal.jsonl').open('xb')
        self.source_archive_sha256=None;self.source_entries=None
        try:
            _write_json(self.directory/'started.json',{'terminal':True,'source_commit':source_commit,'runtime_commit':runtime_commit,'provenance':provenance})
            _write_json(self.directory/'intent.json',{'kind':'build-preparation-intent-v1','source_commit':source_commit,'runtime_commit':runtime_commit,
                        'expected_archive_sha256':expected_archive_sha256,'inputs':dict(self.inputs),'tools':{k:dict(v) for k,v in self.tools.items()},
                        'commands':[list(a) for a in self.commands],'task_kinds':self.task_kinds,'provenance':provenance,
                        'producer_file_sha256':_regular_hash(Path(__file__).resolve()),'environment_delta':self.env_delta})
            self._event('reserved',source_commit=source_commit,runtime_commit=runtime_commit,provenance=provenance,
                        producer_file_sha256=_regular_hash(Path(__file__).resolve()),environment_delta=self.env_delta)
            self._source_guard()
            self._make_archive()
            self._input_guard()
            self._spawn()
        except BaseException as error:
            if self.pending:
                # Preserve the actual owned child and return its waitable handle.
                self.deferred_error=repr(error)
                self._preserve_failure(error)
            else:
                self.finished=True
                self._preserve_failure(error)
                raise

    @property
    def child_pid(self):
        return None if self.process is None else self.process.pid

    def _event(self,event,**fields):
        self.events.write((json.dumps({'event':event,'wall_time_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},sort_keys=True)+'\n').encode())
        self.events.flush();os.fsync(self.events.fileno())

    def _git(self,*argv):
        index=self.git_index;self.git_index+=1
        out=self.directory/f'git-{index:03}.stdout';err=self.directory/f'git-{index:03}.stderr'
        with out.open('xb') as o,err.open('xb') as e:
            result=subprocess.run([self.tools['git']['entry'] if 'git' in self.tools else 'git','-C',str(self.repo),*argv],stdin=subprocess.DEVNULL,stdout=o,stderr=e,close_fds=True,env=self.environment)
        stdout=_file_snapshot(out,1024**3);stderr=_file_snapshot(err,32*1024**2)
        self._event('git_observation',argv=list(argv),returncode=result.returncode,stdout_sha256=stdout['sha256'],stderr_sha256=stderr['sha256'])
        if result.returncode:raise ProducerError('git observation failed; exact stdout/stderr retained')
        if argv[0]=='archive':return out
        if stdout['size']>32*1024**2:raise ProducerError('git metadata exceeds declared bound')
        return out.read_bytes()

    def _source_guard(self):
        self.lease_check()
        self._tool_guard()
        if self._git('rev-parse','HEAD').decode().strip()!=self.source_commit:raise ProducerError('source HEAD differs')
        if self._git('status','--porcelain','--untracked-files=normal'):raise ProducerError('source worktree is not clean')
        if self._git('diff','--no-ext-diff','--no-textconv',self.runtime_commit,self.source_commit,'--','packages','native'):raise ProducerError('runtime source differs')

    def _make_archive(self):
        # git archive bytes are kept without extraction. Validate every blob and mode.
        raw_path=self._git('archive','--format=tar',self.source_commit)
        archive=self.directory/'source.tar'
        # Exclusive hard-link publication keeps original command bytes, no copy/overwrite.
        os.link(raw_path,archive,follow_symlinks=False)
        archive_hash=_regular_hash(archive)
        if archive_hash!=self.expected_archive_sha256:raise ProducerError('source archive differs from immutable expected digest')
        tree={}
        for entry in self._git('ls-tree','-rz',self.source_commit).split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,kind,object_id=meta.split(b' ')
            if kind!=b'blob':raise ProducerError('unsupported source tree entry')
            tree[os.fsdecode(name)]=(mode.decode(),object_id.decode())
        found=set()
        with tarfile.open(archive,'r:') as tar:
            for member in tar:
                if member.isdir():continue
                if member.name not in tree or member.name in found:raise ProducerError('archive has unknown or duplicate source entry')
                mode,object_id=tree[member.name]
                if member.issym() and mode=='120000':data=os.fsencode(member.linkname)
                elif member.isfile() and mode in ('100644','100755'):
                    if member.size>128*1024**2:raise ProducerError('source entry exceeds declared bound')
                    if bool(member.mode&0o111)!=(mode=='100755'):raise ProducerError('source archive executable mode differs')
                    data=tar.extractfile(member).read()
                else:raise ProducerError('source archive type differs')
                if hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()!=object_id:raise ProducerError('source archive blob differs')
                found.add(member.name)
        if found!=set(tree):raise ProducerError('source archive omits committed files')
        self.source_entries=len(found);self.source_archive_sha256=_regular_hash(archive)
        if self.source_archive_sha256!=archive_hash:raise ProducerError('archive changed during membership check')
        self._event('source_archive',sha256=self.source_archive_sha256,entries=self.source_entries)


    def _tool_guard(self):
        for name,expected in self.tools.items():
            observed=describe_tool(name,expected['version_prefix'],lookup_path=self.environment.get('PATH'))
            if observed!=dict(expected):raise ProducerError('tool entry/target identity differs: '+name)

    def _version_guard(self):
        record=self.records[-1]
        if record['kind']!='tool_version':return
        if record['log_bytes']>65536:raise ProducerError('tool version output exceeds declared bound')
        path=self.directory/f'command-{len(self.records)-1:03}.log'
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            with os.fdopen(fd,'rb',closefd=False) as reader:data=reader.read(65537)
            if len(data)!=record['log_bytes'] or _sha(data)!=record['log_sha256']:raise ProducerError('tool version bytes changed')
            text=data.decode('utf-8')
            prefix=self.tools[record['tool']]['version_prefix']
            line=text.splitlines()[0] if text else ''
            match=line.startswith(prefix)
            suffix=line[len(prefix):] if match else ''
            if not text or '\0' in text or not text.endswith('\n') or not match or (not prefix[-1].isspace() and suffix and not suffix[0].isspace()):
                raise ProducerError('tool version differs: '+record['tool'])
            record['version_line']=text.splitlines()[0]
        finally:
            primary=sys.exception()
            try:os.close(fd)
            except OSError as error:
                if primary is None:raise
                primary.add_note('version descriptor close failed: '+repr(error))

    def _input_guard(self):
        self.lease_check()
        for relative,expected in self.inputs.items():
            if _regular_hash(self.repo/relative)!=expected:raise ProducerError('input identity/digest differs: '+relative)

    def _spawn(self):
        index=len(self.records);argv=list(self.commands[index])
        self._event('command_start',index=index,argv=argv,cwd=str(self.repo))
        self.log=(self.directory/f'command-{index:03}.log').open('xb')
        kind,tool=self.task_kinds[index]
        record={'argv':argv,'cwd':str(self.repo),'kind':kind,'tool':tool,'started_ns':time.time_ns(),'returncode':None,'spawn_error':None}
        self.records.append(record)
        try:
            self.process=subprocess.Popen(argv,cwd=self.repo,stdin=subprocess.DEVNULL,stdout=self.log,stderr=subprocess.STDOUT,close_fds=True,env=self.environment)
        except OSError as e:
            record['spawn_error']=repr(e);self._end_command(None)
            self._finish('failed','command spawn failed')
        else:
            record['pid']=self.process.pid;self.pending=True
            self._event('command_spawned',index=index,pid=self.process.pid)

    def _end_command(self,status):
        self.pending=False
        record=self.records[-1];record['returncode']=status;record['ended_ns']=time.time_ns()
        log=self.log;self.log=None
        log.flush();os.fsync(log.fileno());log.close()
        data=_file_snapshot(self.directory/f'command-{len(self.records)-1:03}.log')
        record['log_bytes']=data['size'];record['log_sha256']=data['sha256']
        self._event('command_end',index=len(self.records)-1,**record)

    def _finish(self,status,error=None):
        self.finished=True
        output_hashes={}
        if status=='success':
            for role,path in self.outputs.items():
                if '*' in str(path):
                    matches=sorted(Path(path).parent.glob(Path(path).name))
                    if len(matches)!=1:raise ProducerError('production artifact selection is not unique: '+role)
                    path=matches[0]
                output_hashes[role]={'path':str(path),'sha256':_regular_hash(Path(path))}
        self.result={'kind':'fixture-command-evidence-v1' if self.provenance=='fixture' else 'own-command-evidence-v1',
                     'scope':'owned_child_waited_and_file_snapshots_only','capture_ready':False,
                     'status':status,'error':error,'source_commit':self.source_commit,'runtime_commit':self.runtime_commit,
                     'source_archive_sha256':self.source_archive_sha256,'source_entries':self.source_entries,
                     'inputs':dict(self.inputs),'commands':self.records,'outputs':output_hashes,'provenance':self.provenance,'tools':{k:dict(v) for k,v in self.tools.items()}}
        _write_json(self.directory/'result.json',self.result)
        self._event('finished',status=status,error=error)
        events=self.events;self.events=None;events.close()
        return self.result

    def _preserve_failure(self,error):
        try:_write_json(self.directory/'failure.json',{'error':repr(error),'commands':self.records,'source_commit':self.source_commit,'provenance':self.provenance})
        except BaseException as secondary:error.add_note('failure evidence publication failed: '+repr(secondary))
        if not self.pending and self.events is not None:
            events=self.events;self.events=None
            try:events.close()
            except BaseException as secondary:error.add_note('journal close failed: '+repr(secondary))

    def wait(self,timeout):
        if self.finished:raise ProducerError('completed or failed producer is permanently terminal')
        if type(timeout) not in (int,float) or not 0<=timeout<=60:raise ProducerError('bounded wait required')
        self.lease_check()
        deadline=time.monotonic()+timeout
        try:
            while True:
                try:status=self.process.wait(timeout=max(0,deadline-time.monotonic()))
                except subprocess.TimeoutExpired:return None
                self._end_command(status)
                if self.deferred_error is not None:return self._finish('failed',self.deferred_error)
                if status!=0:return self._finish('failed','command returned nonzero or signal')
                try:
                    self._version_guard();self._source_guard();self._input_guard()
                    if _regular_hash(self.directory/'source.tar')!=self.source_archive_sha256:raise ProducerError('source archive changed after command')
                except BaseException as e:return self._finish('failed',repr(e))
                if len(self.records)==len(self.commands):return self._finish('success')
                self._spawn()
                if self.finished:return self.result
        except BaseException as e:
            if self.pending:
                self.deferred_error=repr(e)
                self._preserve_failure(e)
                return None
            self.finished=True
            self._preserve_failure(e)
            raise


def start_fixture(**kwargs):
    return CommandProducer(**kwargs,provenance='fixture')


def _live_inputs(inputs):
    required={'pubspec.lock','native/transport/Cargo.lock','native/bench/Cargo.lock'}
    if type(inputs) is not dict or not required<set(inputs) or any(k not in required and not k.endswith('/.dart_tool/package_config.json') and k!='.dart_tool/package_config.json' for k in inputs):
        raise ProducerError('actual three locks and generated package configs required')
    for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR'):
        if os.environ.get(key):raise ProducerError('undeclared build environment: '+key)


def start_canonical(**kwargs):
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    repo=Path(kwargs['repo']);native=repo/'native/transport/target/release'/('libct_ffi.dylib' if sys.platform=='darwin' else 'libct_ffi.so')
    configured=os.environ.get('CONNECTANUM_NATIVE_LIB')
    if configured and Path(configured).resolve()!=native:raise ProducerError('canonical native path is outside own declared release output')
    return CommandProducer(**kwargs,commands=[['bin/verify']],provenance='canonical_recipe',outputs={'canonical_native':native})


def start_production(**kwargs):
    if sys.platform!='linux':raise ProducerError('production ELF recipe requires actual Linux')
    _live_inputs(kwargs.get('inputs'))
    _required_tools(kwargs.get('tools'))
    target=Path(kwargs['run_dir'])/'target'
    return CommandProducer(**kwargs,provenance='production_recipe',env_delta={'CARGO_TARGET_DIR':str(target)},
        commands=[['cargo','build','--release','--locked','--manifest-path','native/transport/Cargo.toml','-p','ct_ffi'],
                  ['cargo','build','--release','--locked','--manifest-path','native/bench/Cargo.toml','--bin','http_stream']],
        outputs={'native_elf':target/'release/libct_ffi.so','driver_elf':target/'release/http_stream',
                 'static_rlib':target/'release/deps/libct_core-*.rlib'})
