"""Mandatory input-file/receipt checks only; never a live capture admission token.

Caller supplies immutable expected context/cohorts and holds the official lease.
Hash linkage does not prove actual build execution or log completeness. Trusted
build controllers, root audit, host capability and loaded-image proof remain.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys
from types import MappingProxyType


class CensusError(RuntimeError):
    pass


if sys.version_info < (3, 11):
    raise CensusError('Python 3.11 or newer required before input census IO')


ROLES = {'source_archive': 'blob', 'canonical_receipt': 'json', 'canonical_log': 'blob',
         'canonical_native': 'blob', 'production_receipt': 'json', 'production_log': 'blob',
         'native_elf': 'elf', 'driver_elf': 'elf', 'static_rlib': 'ar',
         **{phase + '/' + lock: 'lock' for phase in ('canonical', 'execution')
            for lock in ('pub', 'transport', 'bench')}}
MAXIMUM = {'blob': 2 * 1024**3, 'elf': 256 * 1024**2, 'ar': 2 * 1024**3,
           'lock': 16 * 1024**2, 'json': 16 * 1024**2}


def _hex(value, size):
    return type(value) is str and re.fullmatch('[0-9a-f]{' + str(size) + '}', value) is not None


def _freeze(value):
    return MappingProxyType({k: _freeze(v) if type(v) is dict else v for k, v in value.items()})


@dataclass(frozen=True)
class CensusContext:
    census_id: str
    source_commit: str
    runtime_commit: str
    owner_uid: int
    elf_machine: int
    lock_hashes: dict
    sdks: dict

    def __post_init__(self):
        if (not _hex(self.census_id, 32) or not _hex(self.source_commit, 40) or not _hex(self.runtime_commit, 40)
                or type(self.owner_uid) is not int or self.owner_uid < 0
                or type(self.elf_machine) is not int or not 0 < self.elf_machine < 65536
                or type(self.lock_hashes) is not dict or set(self.lock_hashes) != {'canonical', 'execution'}
                or any(type(v) is not dict or set(v) != {'pub', 'transport', 'bench'}
                       or any(not _hex(h, 64) for h in v.values()) for v in self.lock_hashes.values())
                or type(self.sdks) is not dict or set(self.sdks) != {'canonical', 'execution'}
                or any(type(v) is not str or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', v) for v in self.sdks.values())):
            raise CensusError('invalid immutable census context')
        object.__setattr__(self, 'lock_hashes', _freeze(self.lock_hashes))
        object.__setattr__(self, 'sdks', _freeze(self.sdks))


@dataclass(frozen=True)
class CheckedCensus:
    files: object
    bindings: object
    aliases: tuple
    scope: str = 'file_checks_only'


def _json(data):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise CensusError('duplicate JSON key')
            result[key] = value
        return result
    try:
        value = json.loads(data, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(CensusError('invalid JSON constant')))
    except (ValueError, UnicodeError) as error:
        raise CensusError('invalid JSON input') from error
    if type(value) is not dict:
        raise CensusError('JSON input must be an object')
    return value


def _identity(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns, info.st_mode, info.st_uid, info.st_gid


def _read(role, entry, kind, context):
    if type(entry) is not dict or set(entry) != {'path', 'sha256'} or not _hex(entry['sha256'], 64) or type(entry['path']) is not str:
        raise CensusError('invalid census file entry: ' + role)
    path = Path(entry['path'])
    if not path.is_absolute() or path.resolve(strict=True) != path:
        raise CensusError('input path must be canonical and without symlinks: ' + role)
    before = path.lstat()
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise CensusError('input must be regular: ' + role)
        if info.st_uid != context.owner_uid or stat.S_IMODE(info.st_mode) & 0o022:
            raise CensusError('input owner or permissions differ: ' + role)
        if not 0 < info.st_size <= MAXIMUM[kind]:
            raise CensusError('input size outside declared bound: ' + role)
        identity = _identity(info)
        if _identity(before) != identity:
            raise CensusError('input changed before read: ' + role)
        digest, prefix, chunks, count = hashlib.sha256(), b'', [], 0
        while True:
            chunk = os.read(fd, min(1024**2, MAXIMUM[kind] + 1 - count))
            if not chunk:
                break
            count += len(chunk)
            if count > MAXIMUM[kind]:
                raise CensusError('input changed beyond size bound: ' + role)
            digest.update(chunk)
            prefix = (prefix + chunk)[:64]
            if kind == 'json':
                chunks.append(chunk)
        if (count != info.st_size or _identity(os.fstat(fd)) != identity
                or _identity(path.lstat()) != identity or path.resolve(strict=True) != path):
            raise CensusError('input changed during read: ' + role)
        actual_sha = digest.hexdigest()
        if actual_sha != entry['sha256']:
            raise CensusError('input digest mismatch: ' + role)
        if kind == 'elf':
            if (len(prefix) < 64 or prefix[:7] != b'\x7fELF\x02\x01\x01'
                    or struct.unpack_from('<H', prefix, 18)[0] != context.elf_machine
                    or struct.unpack_from('<H', prefix, 52)[0] != 64
                    or struct.unpack_from('<H', prefix, 16)[0] not in ((3,) if role == 'native_elf' else (2, 3))):
                raise CensusError('unsupported ELF header: ' + role)
        if kind == 'ar' and not prefix.startswith(b'!<arch>\n'):
            raise CensusError('static RLIB archive header differs')
        record = {'path': str(path), 'sha256': actual_sha, 'device': info.st_dev,
                  'inode': info.st_ino, 'size': count, 'owner_uid': info.st_uid, 'mode': info.st_mode}
        return record, _json(b''.join(chunks)) if kind == 'json' else None
    finally:
        primary = sys.exception()
        try:
            os.close(fd)
        except OSError as error:
            if primary is not None:
                primary.add_note('input descriptor cleanup failure: ' + repr(error))
            else:
                raise CensusError('input descriptor cleanup failure') from error


def _commands(value, *, canonical):
    if type(value) is not list or not 0 < len(value) <= 64:
        raise CensusError('invalid command receipt')
    for command in value:
        if (type(command) is not dict or set(command) != {'argv', 'exit'}
                or type(command['exit']) is not int or command['exit'] != 0
                or type(command['argv']) is not list or not 0 < len(command['argv']) <= 256
                or any(type(v) is not str or not v or '\0' in v or len(v) > 4096 for v in command['argv'])):
            raise CensusError('incomplete command or nonzero exit receipt')
    if canonical and value != [{'argv': ['bin/verify'], 'exit': 0}]:
        raise CensusError('new canonical command must be bin/verify')
    if not canonical:
        build_seen = False
        for command in value:
            argv = command['argv']
            if Path(argv[0]).name != 'cargo' or 'build' not in argv[1:]:
                continue
            build_seen = True
            selected = []
            for index, argument in enumerate(argv[1:], 1):
                if argument == '--all-features':
                    raise CensusError('production all-features cannot exclude ffi-test')
                if argument in ('--features', '-F'):
                    if index + 1 >= len(argv):
                        raise CensusError('invalid production build feature argument')
                    selected.extend(re.split(r'[,\s]+', argv[index + 1]))
                elif argument.startswith('--features='):
                    selected.extend(re.split(r'[,\s]+', argument.split('=', 1)[1]))
                elif argument.startswith('-F') and argument != '-F':
                    selected.extend(re.split(r'[,\s]+', argument[2:]))
            if any(v.split('/')[-1] == 'ffi-test' for v in selected):
                raise CensusError('ffi-test in actual production build command')
        if not build_seen:
            raise CensusError('production receipt lacks declared cargo build command')



def verify_census(manifest, context):
    if not isinstance(context, CensusContext) or type(manifest) is not dict or set(manifest) != {'context', 'files', 'bindings'}:
        raise CensusError('invalid input census schema')
    files, bindings = manifest['files'], manifest['bindings']
    if (type(files) is not dict or not 16 <= len(files) <= 64
            or any(type(role) is not str for role in files) or not set(ROLES) <= set(files)):
        raise CensusError('missing or invalid input roles')
    if any(type(entry) is not dict or set(entry) != {'path', 'sha256'}
           or type(entry['path']) is not str or not _hex(entry['sha256'], 64) for entry in files.values()):
        raise CensusError('invalid file entry schema before IO')
    configs = set(files) - set(ROLES)
    if not configs or any(not re.fullmatch('[a-z_]+/[A-Za-z0-9_-]{1,64}', role) or not role.startswith('config/') for role in configs):
        raise CensusError('unknown input role')
    expected_context = {'census_id': context.census_id, 'source_commit': context.source_commit,
        'runtime_commit': context.runtime_commit, 'source_archive_sha256': files['source_archive'].get('sha256')}
    if type(manifest['context']) is not dict or manifest['context'] != expected_context:
        raise CensusError('manifest source/context differs')
    if type(bindings) is not dict or set(bindings) != {'canonical', 'execution'}:
        raise CensusError('invalid config phase bindings')
    used = set()
    for phase, consumers in bindings.items():
        if (type(consumers) is not dict or not {'server', 'client'} <= set(consumers)
                or any(type(k) is not str or not re.fullmatch('[a-z_]{1,48}', k) for k in consumers)
                or any(type(v) is not str or v not in configs for v in consumers.values())):
            raise CensusError('config consumer binding differs')
        used.update(consumers.values())
    if used != configs:
        raise CensusError('unbound generated config input')
    records, objects, aliases, identities = {}, {}, [], {}
    for role, entry in files.items():
        kind = ROLES.get(role, 'json')
        record, value = _read(role, entry, kind, context)
        records[role], objects[role] = record, value
        identities.setdefault((record['device'], record['inode']), []).append(role)
        if '/' in role and role.split('/')[0] in ('canonical', 'execution'):
            phase, lock = role.split('/')
            if record['sha256'] != context.lock_hashes[phase][lock]:
                raise CensusError('actual lock cohort differs: ' + role)
    for roles in identities.values():
        if len(roles) > 1:
            if set(roles) != {'canonical/pub', 'execution/pub'} or context.lock_hashes['canonical']['pub'] != context.lock_hashes['execution']['pub']:
                raise CensusError('conflicting input role inode alias')
            aliases.append(tuple(sorted(roles)))
    common = {'census_id': context.census_id, 'source_commit': context.source_commit,
              'runtime_commit': context.runtime_commit, 'source_archive_sha256': records['source_archive']['sha256']}
    for phase, role, kind in [('canonical', 'canonical_receipt', 'own-canonical-v1'),
                              ('execution', 'production_receipt', 'own-production-v1')]:
        receipt = objects[role]
        extra = {'native_sha256'} if phase == 'canonical' else {'outputs', 'features'}
        if (set(receipt) != set(common) | {'kind', 'sdk', 'log_sha256', 'lock_hashes', 'package_configs', 'commands'} | extra
                or any(type(receipt[k]) is not str or receipt[k] != v for k, v in common.items())
                or receipt['kind'] != kind or receipt['sdk'] != context.sdks[phase]):
            raise CensusError('own source receipt context or SDK differs: ' + role)
        if receipt['lock_hashes'] != dict(context.lock_hashes[phase]):
            raise CensusError('receipt lock cohort differs: ' + role)
        expected_configs = {consumer: records[config]['sha256'] for consumer, config in bindings[phase].items()}
        if receipt['package_configs'] != expected_configs:
            raise CensusError('receipt config hashes differ: ' + role)
        log_role = 'canonical_log' if phase == 'canonical' else 'production_log'
        if receipt['log_sha256'] != records[log_role]['sha256']:
            raise CensusError('complete declared log digest differs: ' + role)
        _commands(receipt['commands'], canonical=phase == 'canonical')
        if phase == 'canonical':
            if receipt['native_sha256'] != records['canonical_native']['sha256']:
                raise CensusError('own canonical native differs')
        else:
            features = receipt['features']
            if (type(features) is not list or any(type(v) is not str or not v for v in features)
                    or any(v.split('/')[-1] == 'ffi-test' for v in features)):
                raise CensusError('ffi-test or invalid production feature receipt')
            if receipt['outputs'] != {r: records[r]['sha256'] for r in ('native_elf', 'driver_elf', 'static_rlib')}:
                raise CensusError('actual production output hashes differ')
    return CheckedCensus(_freeze(records), _freeze(copy_bindings(bindings)), tuple(sorted(aliases)))


def copy_bindings(bindings):
    return {phase: dict(consumers) for phase, consumers in bindings.items()}
