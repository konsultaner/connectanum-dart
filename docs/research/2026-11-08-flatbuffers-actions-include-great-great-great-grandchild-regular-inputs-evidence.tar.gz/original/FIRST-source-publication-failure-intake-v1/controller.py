import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)




import os,stat,datetime
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-08-actions-include-great-great-great-grandchild-regular-inputs-v1';A=P/'FIRST-originalActions-v1';Q=P/'FIRST-source-publication-failure-intake-v1'
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 inputs=[('collector_POST_stdout',A/'FIRST-new375-collector-Gitblob-create.stdout',240,'22970568d7bdb2b2d6d95efaf8d26b752ab0228c62f6ee4d74b2b109caa343d7'),('collector_POST_stderr',A/'FIRST-new375-collector-Gitblob-create.stderr',152,'06719e11a6b515084de67d1087bbbc2981012146779eb759268478acde707534')]
 save('declaration.json',json.dumps({'purpose':'FIRSTunread fullactualfailedcollectorGitblobPOST response intake/newfailurequestionONLY/no API-body-source-reverse-SDKquery-Actions replay/retry; originalFIRST-originalActions-v1 FOREVERterminal. Known gh84866 signed1/full240out152err/BOTH EOF; successfulworkflowblobcreation separate/no treecommitbranchdispatch entered. Preserveallprivatefields andunknowns/no cause inferred beforeactualerror.','inputs':[{'role':r,'path':str(p),'range':[0,n],'sha256':h} for r,p,n,h in inputs]},indent=2));save('controller.py',sys.argv[1]);raws={};bindings=[]
 for role,path,size,sha in inputs:
  b={'role':role,'path':str(path),'range':[0,size],'expected_sha256':sha,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None
  try:
   a=os.fstat(fd);keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];b['before']={k:getattr(a,k) for k in keys};b['before_atime_ns_POINT_ONLY']=a.st_atime_ns;assert stat.S_ISREG(a.st_mode) and a.st_size==size;raw=b''
   while len(raw)<size:
    block=os.read(fd,size-len(raw));assert block;raw+=block
   z=os.fstat(fd);b['after']={k:getattr(z,k) for k in keys};b['after_atime_ns_POINT_ONLY']=z.st_atime_ns;b.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());assert b['before']==b['after'] and b['sha256']==sha;save(role+'-original-PRIVATE',raw);raws[role]=raw.decode()
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  if primary is not None:raise primary
 save('new-error-input-bindings-PRIVATE.json',json.dumps(bindings,indent=2))
 cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-failure-intake.json',before);d=json.loads(before);node=d['actions_include_great_great_great_grandchild_regular_inputs_v1'];node.update(phase='FIRST_SOURCE_PUBLICATION_FOREVER_TERMINAL_collector_Gitblob_POST_signed1_BEFOREtree_commit_branch_dispatch',Actions_failed_namespace=str(A),source_commit=None,run_id=None,source_publication_failure={'collector_POST_pid':84866,'signed_status':1,'stdout_bytes':240,'stdout_sha256':inputs[0][3],'stderr_bytes':152,'stderr_sha256':inputs[1][3],'stdout_eof':True,'stderr_eof':True,'same_original_wait_may_be_cached':True,'outer_execsession':14124,'outer_tool_exit_code':1,'failed_namespace_forever_terminal':True,'workflow_blob_POST_succeeded_separate':True,'tree_commit_branch_dispatch_UNPERFORMED':True,'full_actual_saved_error':raws,'newSDK_INPUT_queries':0,'no_retries':True},all_admission_flags=False)
 d['active_turn_status'].update(new_include_great_great_great_grandchild_regular_inputs='FIRSTsourcepublication_failed_BEFOREtree_commit_branch_dispatch_NOretry',next='FIRSTnewerrorcontext triage/advisory overexactoriginalsavedPOSTresponse; preserveterminalnamespace/no collectorPOSTretry/newnamespace-alone retry/sourcepreproofreplay/SDK-Actionsquery. Allstatic7bindings60fields10UNMEASUREDpreproofimmutable andoriginal38PASSraw intact. Runtimeadmission-RAMrepair-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'actual_new_error':raws,'skills':{p:pathlib.Path(p).read_text() for p in ['/Users/konsultaner/.codex/skills/local-debug/SKILL.md','/Users/konsultaner/.codex/skills/local-model-companions/SKILL.md']}}),flush=True);lease.verify_identity()
