"""NEW snapshot native UID return-shape controls."""
import os
import json
import stat
import hashlib
import tempfile
from pathlib import Path
from unittest import TestCase, mock
import native_perf_build_producer as producer

class SnapshotUidReturnTests(TestCase):
    def setUp(self):
        root=Path(os.environ['CONNECTANUM_PERF_SNAPSHOT_UID_FIXTURES']);self.base=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=root));self.path=self.base/'uid-input.bin';self.body=b'UID-control-content'
        with self.path.open('xb') as output:output.write(self.body)

    def _case(self,mode):
        path=self.path
        if mode=='directory':path=self.base/'uid-directory';path.mkdir()
        native_os=producer.os;calls=[];fds=[];seen={};evidence_ready=False
        class First(OSError):
            def __repr__(self):calls.append(dict(kind='repr_first'));return BaseException.__repr__(self)
            def add_note(self,note):calls.append(dict(kind='note_first'));return BaseException.add_note(self,note)
        first=First('ROOT UID first')
        class OSFacade:
            def __getattr__(self,name):return getattr(native_os,name)
            def open(self,path,flags,*args,**kwargs):
                raw=native_os.open(path,flags,*args,**kwargs);info=native_os.fstat(raw);fds.append(dict(fd=raw,identity=(info.st_dev,info.st_ino),close=native_os.close,path=Path(path),flags=flags,inheritable=native_os.get_inheritable(raw)));calls.append(dict(kind='native_open_return',fd=raw,flags=flags));return raw
            def fstat(self,fd):
                raw=native_os.fstat(fd);seen['native_fstat']=raw;calls.append(dict(kind='native_Source_fstat_return',uid=raw.st_uid,is_regular=stat.S_ISREG(raw.st_mode),is_directory=stat.S_ISDIR(raw.st_mode)));return raw
            def getuid(self):
                raw=native_os.getuid();seen['native_uid']=raw;calls.append(dict(kind='native_getuid_return',raw=raw,native_exact_int=type(raw) is int))
                if mode=='float':return float(raw)
                if mode=='unknown':raise first
                return raw
            def read(self,fd,size):
                raw=native_os.read(fd,size);calls.append(dict(kind='native_read_return',size=len(raw)));return raw
            def close(self,fd):
                calls.append(dict(kind='Source_close_attempt'));raw=native_os.close(fd);calls.append(dict(kind='native_close_return',raw_None=raw is None));return raw
        returned=False;result=None;received=None;guard_error=None;attempt=None
        try:
            before=len(producer._FILE_SNAPSHOT_ATTEMPTS)
            with mock.patch.object(producer,'os',OSFacade()):
                try:result=producer._file_snapshot(path);returned=True
                except BaseException as error:received=error
            attempt=producer._FILE_SNAPSHOT_ATTEMPTS[before:][-1]
            if mode!='normal':
                try:attempt.guard()
                except BaseException as error:guard_error=error
            rows=attempt.steps
            view=dict(mode=mode,snapshot_uid_control=True,Source_returned=returned,result=result,received_type=None if received is None else type(received).__name__,received_first=received is first,pure_guard_same_received=received is not None and guard_error is received,Source_first_received=attempt.first_error is received,
                Source_completed=attempt.completed,Source_close_returned=attempt.close_returned,ROOT_native_uid_known='native_uid' in seen,ROOT_native_uid=seen.get('native_uid'),ROOT_native_uid_exact_int='native_uid' in seen and type(seen['native_uid']) is int,
                Source_steps=[dict(stage=r['stage'],returned=r['returned'],raw_None=r['raw'] is None,raw_float=type(r['raw']) is float,raw_float_value=r['raw'] if type(r['raw']) is float else None,raw_native_uid_int='native_uid' in seen and type(r['raw']) is int and r['raw']==seen['native_uid'],error_first=r.get('error') is first) for r in rows],
                calls=list(calls),ROOT_fds=[dict(fd=x['fd'],identity=x['identity'],flags=x['flags'],inheritable=x['inheritable']) for x in fds],
                limits='DirectOWNfile-directory/MODULELOCALosfacade/actualnativegetuid int thenknownfloat-orFirst/no credential-env-hostchange. Knownfloat rawTRUE vsunknownNoneFalse neverROOTnativeUIDfilled; integer shape DATAnotcredentials-auth-accessproof. ROOTactualFD/devino-beforefault/sameopenFDcleanupAFTERevidence only/no closedborrowedreclose. ZEROchild/DarwinEXNone UNITnotSourcecleanup-fullEX-originalLinux-allFD-interpreter-descendantclosure-ownership-admission. RawchunksUNCHANGED/NOTfixedmemory/heapRSS-timing-causeUNMEASURED.')
            if mode!='directory':(self.base/'input-retained.bin').write_bytes(path.read_bytes())
            (self.base/'view-before-ROOT-cleanup.json').write_text(json.dumps(view,indent=2)+'\n');evidence_ready=True
            self.assertEqual(1,len(fds));self.assertFalse(fds[0]['inheritable']);self.assertEqual(os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,fds[0]['flags'])
            if mode=='normal':
                self.assertTrue(returned);self.assertIsNone(received);self.assertTrue(attempt.completed);self.assertTrue(attempt.close_returned);self.assertEqual(dict(size=len(self.body),sha256=hashlib.sha256(self.body).hexdigest()),result)
                self.assertEqual(1,sum(x['kind']=='Source_close_attempt' for x in calls));self.assertEqual(1,sum(x['kind']=='native_getuid_return' for x in calls));self.assertTrue(type(seen['native_uid']) is int)
            else:
                self.assertFalse(returned);self.assertTrue(guard_error is received);self.assertTrue(attempt.first_error is received);self.assertFalse(attempt.completed);self.assertFalse(attempt.close_returned)
                self.assertFalse(any(x['kind'] in ('Source_close_attempt','repr_first','note_first','native_read_return') for x in calls));self.assertFalse(any(r['stage'] in ('hash_ctor','hash_update','hexdigest') for r in rows))
                last=rows[-1]
                if mode=='unknown':
                    self.assertTrue(received is first);self.assertFalse(last['returned']);self.assertIsNone(last['raw']);self.assertTrue(last['error'] is first);self.assertTrue(type(seen['native_uid']) is int)
                else:self.assertTrue(type(received) is producer.ProducerError);self.assertTrue(last['returned'])
                if mode=='directory':
                    self.assertEqual('fstat_before',last['stage']);self.assertFalse('native_uid' in seen);self.assertFalse(any(x['kind']=='native_getuid_return' for x in calls));self.assertTrue(stat.S_ISDIR(last['raw'].st_mode))
                else:
                    self.assertEqual('getuid',last['stage']);self.assertEqual(1,sum(x['kind']=='native_getuid_return' for x in calls))
                    if mode=='float':self.assertTrue(type(last['raw']) is float);self.assertEqual(float(seen['native_uid']),last['raw'])
                count=len(calls)
                try:attempt.guard()
                except BaseException as error:self.assertTrue(error is received)
                else:self.fail('UID pure guard returned')
                self.assertEqual(count,len(calls))
        finally:
            cleanup=[]
            for item in fds:
                row=dict(fd=item['fd'],evidence_ready=evidence_ready,ROOT_close=False)
                if evidence_ready:
                    try:
                        info=native_os.fstat(item['fd']);pathstat=item['path'].stat();same=(info.st_dev,info.st_ino)==item['identity']==(pathstat.st_dev,pathstat.st_ino);row['original_FD_path_identity_match']=same
                        if same:
                            raw=item['close'](item['fd']);row['ROOT_close']=True;row['ROOT_close_None']=raw is None
                    except OSError as error:row['fstat_or_close_errno']=error.errno
                cleanup.append(row)
            (self.base/'ROOT-unit-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')

    def test_native_uid_then_float_refuses_before_hash_read(self):self._case('float')
    def test_native_uid_then_first_keeps_unknown_uid(self):self._case('unknown')
    def test_actual_OWNdirectory_shortcircuits_before_uid_hash_read(self):self._case('directory')
    def test_new_normal_uid_file_preserves_native_sha_order(self):self._case('normal')
