import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-snapshot-uid-returns-progress-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-05-flatbuffers-native-perf-snapshot-uid-returns-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='82297e3ea94aa9972c8a3f4716de48efc6488cb3'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=None
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-constructor-primary-web-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="## 2026-11-05 — Require an exact UID return before snapshot reads\n\nA controlled wrapper returned501.0 after the native getuid call returned501. The helper accepted numeric equality with the file owner and continued hashing, reading and closing the file. It now requires an exact nonnegative native integer before comparing the owner or reading. The known float stays recorded as returned; an unknown completion keeps its original error and stays unknown. Actual credentials and native I/O order remain unchanged.\n\nFour new controls before99d39c/dfd8e9 produced1FAIL/3PASS/0ERROR. This is one controlled return-contract continuation gap, not a spontaneous kernel bug or a RAM cause. The unknown-completion control, actual owned directory and distinct normal19-byte file already passed. Final3a007f/286a72 passes44selected=4matchingNEW+40affected(22previoussnapshot8end10actualwaitcallers). The directory still short-circuits before getuid. Whole Source projection and the existing test prefix are exact. Both advisory models completed; ROOT rejects their incorrect API and test claims and independently qualifies the patch and results.\n\nEight new direct views create no child actors. Current Darwin lease observations, known FD cleanup and affected finite waits remain unit evidence; full independent EX and original Linux actor closure remain unproved. Read-chunk retention is unchanged and establishes no heap/RSS bound. Source remains uncommitted, uncanonical and unadmitted; runtime admission, RAM repair and strict acceptance remain incomplete.\n\n"
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-05-flatbuffers-native-perf-snapshot-uid-returns-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-05')
  assert common.splitlines()[0] not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:]
  if relative=='docs/project_state.md':new=new.replace('Last updated: 2026-11-04.','Last updated: 2026-11-05.',1)
  path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: require exact snapshot UID returns'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['producer_snapshot_uid_returns_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']="Snapshot earlierconstructor-registration/metadata-globalbindings-hashfactory/calleeinterior-returnshapes-statcontents-concurrentABA; otherAPIs/enclosing-publicunknownCtor; frozenhistorical continuation-logsealing; transitiveunknownactors/sharedwriters/interpreterdelegates; fullindependentactualofficialEX+originalruntimeimmutableCOMPLETEadmission. Current3a007f/286a72 ONLYgetuid exactnativeint>=0 BEFOREownercompare/hash-read; knownfloat501.0 rowTRUE retained vsunknownNoneFalse/originalFirst; ROOTnative501 neverSourcefilled. Originalnonregular-getuid-owner-mode-size shortcircuit/nativeIOorder/flags/defaultmax preserved; immutablebeforestat_uid read movesacrossreturnedcall/notglobalbindings-calleeinterior-ABAproof. NEW4before99d39c/dfd8e9=1FAIL3PASS0ERROR: actualnativegetuid501->ROOTfloat501.0 accepted equality/fullhash-read-close-result, onecontrolledcontinuationgap/refusalpolicy NOTnativekernelbug-RAMcause; unknownUID/nativeOWNdirectory/normal19B alreadyPASS; final44PASS=4NEW40affected(22snapshot8end10actualwaitcallers)/no old22BEFORE-model-numericalreplay-aggregate-current20canonical-admission.8newdirectviews+22prior8end/EX8before88after/ZEROnewchild/Root2before3afterFDcloses AFTERevidence/devino-only/oldfloat+normalalreadyclosed-no borrowedreclose;22priorRootclose17separate/8endRootsameboundwait10 signed7zero1threeCached UNITnotSourcecleanup-fullEX-originalLinux/allFD-interpreter-delegate-descendantclosure. Qwen79578=0/1977out488err;GLM79756=0/1682out598err/fullanswers-BOTH EOF-reaped-ROOTqualified NOTwholecurrentapproval. RejectANDwording(actualOR)/fakeFD1-MagicMock-globalpatch/duplicate_st_mode; Path.stat follow_symlinks existsbyactualBEFOREnormalPASS/explicitFalse andraw_uidtypeconjunctionalreadyexists; no flagdrop-APIchange-oldnormalreplay. Planningv1missingselected-source cache BEFOREcommand-Popen-model/inputfiles/oldtest-planningTERMINAL; freshv2actualbefore-snapshot firstmodelcall/no modelretry-unavailability-Sourcefailingregression. Candidatev1-privatev1UNEXECUTEDbeforeSourceedit-firstBEFORE/controllersBEFOREcalls/wholeSourceBYTEprojectback/oldtestPREFIXexact/othermethodshelpersfactoriesfrozenpredicates exact/23hashes-other18helpers3bins4NEWGit0BOTH-601ownbranch20untrackedproductionempty DATA. RawchunksUNCHANGED/NOTfixedmemory/default16GiBlogicalfilelimitNOTheapRSSbound/growth-heapRSS-timing-leakcauseUNMEASURED/no memorybound-RAMrepair-trim-reset-evict-deleteauthority. NativeUID0 legitimate≠Falseifactuallyreturned/credentials-env-hostunchanged/UIDshapeDATA notcredentialauth-access-ownerproof. UnknownCtorPERMANENTrefusal/no partialPopenmethods-fieldderivedsettlement; retainknownhandlesBEFOREIO/boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance; fieldfacts DATAneverEXrelease/admission."+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Producer_snapshot_uid_selected44PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
