import sys,pathlib,json,hashlib,ast,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path("/tmp/connectanum-native-perf-snapshot-uid-returns-progress-v1")
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();before=(P/'before-producer.py').read_text()
 old="""            if (not stat.S_ISREG(before.st_mode)
                or before.st_uid!=call('getuid',lambda:os.getuid)
                or before.st_mode&0o022 or before.st_size>maximum):
                raise ProducerError('log snapshot type/owner/mode/size differs')
"""
 new="""            if not stat.S_ISREG(before.st_mode):
                raise ProducerError('log snapshot type/owner/mode/size differs')
            uid=call('getuid',lambda:os.getuid)
            if type(uid) is not int or uid<0:
                raise ProducerError('unknown log snapshot uid return')
            if before.st_uid!=uid or before.st_mode&0o022 or before.st_size>maximum:
                raise ProducerError('log snapshot type/owner/mode/size differs')
"""
 assert before.count(old)==1
 after=before.replace(old,new,1);ast.parse(after);assert after.replace(new,old,1)==before
 (P/'candidate-producer-v1.py').open('x').write(after)
 node=next(x for x in ast.parse(after).body if isinstance(x,ast.ClassDef) and x.name=='_FileSnapshotAttempt')
 (P/'candidate-snapshot-v1.py').open('x').write(ast.get_source_segment(after,node)+'\n');(P/'projection-parts-v1.json').open('x').write(json.dumps(dict(old=old,new=new),indent=2))
 receipt=dict(wholeSource_BYTE_projectsback=True,all_other_existing_methods_helpers_classes_factories_frozenpredicates_exact=True,oldtests_PREFIX_exact=True,only_native_uid_shape_check=True,original_nonregular_getuid_owner_mode_size_shortcircuit_nativeIO_order_preserved=True,privatev1_BEFORE4_frozen=True,no_before_replay=True,Qwen_planning_ROOT_qualified='79578status0/full1977stdout488stderr. OR firstnotregular isTrue andshortcircuits; modelANDwordingwrong. Neveradopt fakeFD1, MagicMockstat, globalos.patch, duplicate-st_mode snippet or oldopen-shape repeat; actualOWNfile/directory/nativegetuid thenfloat-orFirst controls retained.')
 (P/'candidate-ROOT-projection.json').open('x').write(json.dumps(receipt,indent=2));(P/'candidate.diff').open('x').write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before',tofile='candidate')))
 views=[json.loads(f.read_text()) for f in (P/'before-units/fixtures').glob('*/view-before-ROOT-cleanup.json')]
 print(json.dumps([dict(mode=v['mode'],Source_returned=v['Source_returned'],result=v['result'],received=v['received_type'],last=v['Source_steps'][-1],nativeuid=v['ROOT_native_uid'],calls=v['calls']) for v in views],indent=2))
 l.verify_identity();print((P/'candidate.diff').read_text())
