import sys,pathlib,json,ast,os,stat,hashlib,subprocess,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-receipt-failure-orientation');p.mkdir()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 put(p/'attempt.json',dict(scope='NEW receipt-audit failure ownership orientation only',source_epoch='c85869a483f9059a5c07e3f032adecbf238c18f62c00c5cfd8bde858ccfe951e',no_old_controls_reviews_archives_repeated=True,no_source_or_runtime_mutation=True,no_recipe_SDK_test_build_capture=True))
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 f=r/'tool/native_perf_build_producer.py';fd=os.open(f,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  first=os.fstat(fd);assert stat.S_ISREG(first.st_mode) and first.st_uid==501 and first.st_gid==20 and first.st_size<2*1024**2
  parts=[]
  while True:
   part=os.read(fd,65536)
   if not part:break
   parts.append(part)
  raw=b''.join(parts)
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,getattr(s,'st_flags',None))
  assert hashlib.sha256(raw).hexdigest()=='c85869a483f9059a5c07e3f032adecbf238c18f62c00c5cfd8bde858ccfe951e'
  assert identity(first)==identity(os.fstat(fd))==identity(f.stat())
 finally:os.close(fd)
 text=raw.decode();tree=ast.parse(text);lines=text.splitlines();selected=[]
 wanted={'_observe_auxiliary','_receipt_source_audit','_emit','emit_receipt','emit_fixture_receipt'}
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name in wanted:selected.append('\n'.join(lines[n.lineno-1:n.end_lineno]))
  if isinstance(n,ast.ClassDef):
   names={'CommandProducer':{'_git','_end_command','_finish','_preserve_failure'},'_RetainedPreflightOwner':{'_capture_known_actors','_freeze_known_actors','emit'}}
   if n.name in names:
    for item in n.body:
     if isinstance(item,ast.FunctionDef) and item.name in names[n.name]:
      selected.append(n.name+':\n'+'\n'.join(lines[item.lineno-1:item.end_lineno]))
 source='\n\n'.join(selected)
 with (p/'selected-source.txt').open('x') as out:out.write(source)
 put(p/'input-receipt.json',dict(source_sha256=hashlib.sha256(raw).hexdigest(),selected_sha256=hashlib.sha256(source.encode()).hexdigest(),selected_chars=len(source),source_identity=identity(first)))
 prompt='Summarize ONLY this NEW question: after receipt source-audit failure, which existing exact Popen/auxiliary/log handles remain, and which fields differ from failed pending recipe? Explain why current freeze/known-wait/log-seal gates cannot simply be waived. Focus actual _emit/_receipt_source_audit/_git/_end_command/_finish/capture code. Max450words; no implementation, physical lease-release, canonical or RAM claims. Advisory; ROOT verifies. Source excerpts labeled with class names.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--stdin','--num-predict','1400','--max-response-chars','9000','--max-input-chars','40000','--timeout','180','--save-output',str(p/'summary.txt'),'--prompt',prompt]
 put(p/'command-before.json',dict(argv=argv,input_sha256=hashlib.sha256(source.encode()).hexdigest(),input_chars=len(source)))
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(source.encode());status=child.wait()
 for label,data in [('stdout',stdout),('stderr',stderr)]:
  with (p/(label+'.bin')).open('xb') as out:out.write(data)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 put(p/'finish.json',result);lease.verify_identity();print(json.dumps(result));print(stdout.decode(errors='replace')[-9000:])
