import sys,pathlib,json,subprocess,hashlib,datetime,difflib
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();p=pathlib.Path('/tmp/connectanum-native-perf-receipt-error-design');cache=pathlib.Path('/tmp/connectanum-native-perf-receipt-error')
 h=json.loads((cache/'implemented-hashes.json').read_text());r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 parts=[]
 for rel in ['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']:
  before=(cache/'original-source'/rel).read_text();after=(cache/'implemented-source'/rel).read_text()
  assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h[rel]
  parts.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile='after/'+rel)))
 diff='\n'.join(parts)
 with (p/'review-selected-diff.txt').open('x') as f:f.write(diff)
 prompt='Review NEW receipt-error-retention implementation, up to2 actual bugs/max400words. Exact earliest primary/private staged secondaries, no repr/str/add_note; secondary same object still occurrence; TYPEONLY public failure JSON names re-raised earliest object. Constructor starts EMPTY history, no clearing/retry. Gates stay strict; no physical actor/FD closure or audit buffered-write/close-policy repair claimed. Tests real finite Fixture Git+six tool SHIMS, NOT SDK/build. Negative IO proxies close real own handles then inject faults. Find missing error paths/identity mistakes, not hypothetical future pipeline permissions. Advisory ROOT verifies.'
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','review','--stdin','--num-predict','1700','--max-response-chars','10000','--max-input-chars','40000','--timeout','180','--save-output',str(p/'review.txt'),'--prompt',prompt]
 assert len(diff)<39000
 with (p/'review-command-before.json').open('x') as f:json.dump(dict(argv=argv,input_chars=len(diff),input_sha256=hashlib.sha256(diff.encode()).hexdigest(),source_sha256=h),f,indent=2)
 child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=child.communicate(diff.encode());status=child.wait()
 for label,raw in [('stdout',stdout),('stderr',stderr)]:
  with (p/('review-'+label+'.bin')).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,direct_status=status,stdout_eof=True,stderr_eof=True,stdout_size=len(stdout),stderr_size=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),input_chars=len(diff),reaped=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h)
 with (p/'review-finish.json').open('x') as f:json.dump(result,f,indent=2)
 lease.verify_identity();print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}));print(stdout.decode(errors='replace')[-10000:])
