import sys,pathlib,json,hashlib,subprocess,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 source_root=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 cache=pathlib.Path('/tmp/connectanum-native-perf-receipt-error')
 design=pathlib.Path('/tmp/connectanum-native-perf-receipt-error-design')
 final_root=pathlib.Path('/tmp/connectanum-native-perf-receipt-error-root-finalization-v2');final_root.mkdir()
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,obj):
  with path.open('x') as output_file:json.dump(obj,output_file,indent=2);output_file.write('\n')
 put(final_root/'attempt.json',dict(scope='NEW retained-report finalization only after two admin guard errors',no_AST_tests_models_oldarchives_or_branch_Git_repeat=True,
  prior_branch_Git_PID_status_buffers_not_serialized=None,do_not_reconstruct_unknown_as_zero=True,
  only_HEAD_status_productiondiff_Git_first_time=True,no_source_or_runtime_mutation=True))
 bundle=json.loads((cache/'boundaries-fixed-hashes.json').read_text())
 # Boundary comparison is a file-data publication guard, never canonical admission.
 for rel,digest in bundle.items():assert sha((source_root/rel).read_bytes())==digest
 stage_results={};controls={};fixture_index={}
 for stage in ['before','implemented','boundaries-before','boundaries-fixed']:
  path=cache/(stage+'-tests.json');raw=path.read_bytes();report=json.loads(raw)
  stage_results[stage]=dict(path=path.relative_to(cache).as_posix(),sha256=sha(raw),size=len(raw),
   tests=report['tests'],failures=report['failures'],errors=report['errors'])
  controls[stage]=[]
  for pattern in ('error-control-before-cleanup.json','ambient-context-control.json'):
   for item in sorted((cache/(stage+'-fixtures')).rglob(pattern)):
    raw=item.read_bytes();controls[stage].append(dict(path=item.relative_to(cache).as_posix(),size=len(raw),sha256=sha(raw),observed=json.loads(raw)))
  fixture_index[stage]=[]
  for item in sorted((cache/(stage+'-fixtures')).rglob('new-known-actors.json')):
   raw=item.read_bytes();data=json.loads(raw)
   fixture_index[stage].append(dict(path=item.relative_to(cache).as_posix(),size=len(raw),sha256=sha(raw),
    recorded_setup_Git_count=len(data['setup_Git']),recorded_available_final_Popen_count=len(data['actors']),
    recorded_auxiliary_stream_count=len(data['streams']),reported_command_records_count=len(data['reported_command_records']),
    previous_command_Popen_handles_NOT_retained_or_reconstructed=data['previous_command_Popen_handles_NOT_retained_or_reconstructed']))
 # No stream-content reread or earlier structural guard re-execution to fill omissions.
 commands=[]
 def git(*args):
  argv=['git','-C',str(source_root),*args];record=dict(argv=argv,status=None);commands.append(record)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);record['pid']=child.pid
  stdout,stderr=child.communicate();record['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   path=final_root/('git-'+str(len(commands))+'-'+label+'.bin')
   with path.open('xb') as output_file:output_file.write(raw)
   record[label+'_eof']=True;record[label+'_sha256']=sha(raw);record[label+'_size']=len(raw)
  put(final_root/('git-'+str(len(commands))+'-return.json'),record)
  lease.verify_identity();assert record['status']==0
  return stdout.decode()
 head=git('rev-parse','HEAD').strip()
 status=git('status','--porcelain')
 production_diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify')
 assert head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 assert set(line[3:] for line in status.splitlines())=={rel for rel in bundle if rel.startswith('tool/')} and len(status.splitlines())==20
 assert production_diff==''
 assessment=dict(kind='receipt_error_identity_retention_source_component_v2',
 current_source_sha256=bundle['tool/native_perf_build_producer.py'],current_test_sha256=bundle['tool/test_native_perf_build_producer.py'],source_bundle_hashes=bundle,
 behavior='Constructor initializes empty private receipt primary/stage/ordered secondary occurrence objects before lease callback. Process-life retention uses identity, never error repr/str/add_note/equality. Explicit secondary occurrence may be same object as primary. Existing public primary_error string now TYPEONLY via native type-name descriptor and names earliest re-raised retained object. No reset/retry/publication overwrite; previously retained private receipt failure additionally refuses a new emit.',
 body_error_ownership='Explicit LOCAL primary for audit body/per-input-FD body, not ambient inherited sys.exception. Entire complete-output BODY captures errors before context close, including input-open/flush/fsync paths. Earliest retained primary wins later output-close masking; ordinary bare re-raise when same object. These tracked module boundaries do not globally repair/prove arbitrary nested-helper internal masking.',
 results='Before7FAIL actual hooks/identity failures. Initial9PASS=7new+2required emit callers. NEWbefore2FAIL: remaining input-open error masked by actual output-context close, and INTRODUCED false ambient caller-exception history in initial implementation. Fixed4PASS separately=2new+2affected cleanup callers. Nine new cases exist, not combined13/full-final11/canonical.',
 resource_limit='CLOSE POLICY unchanged: audit/output BufferedWriter.close may implicitly flush after earlier write/flush failure. Receipt audit/output/failure-writer handles and uncertainty/full actor inventory still incomplete. This error fix grants NO physical EX release, writer/descendant closure or admission. Freeze owner_emit_attempted refusal and old aux predicates unchanged.',
 fixture_scope='Actual tiny OWN Git/FIXTURE source, six shell version SHIMS+finite Python recipe/synthetic output roles/Fixture receipts, NOT installed SDK/compiler/bootstrap/native/canonical evidence. Negative source/publication/Pathcontext/FDclose boundaries mocked; audit/output/FDclose controls perform actual own native close before fault. New actual setupGit signed status+BOTH EOF/fullrawstreamfiles saved; available LASTrecipe+Aux Popen finalwait0 and Aux2EOF/FD-path/digest rows saved. Earlier command Popen handles overwritten by existing producer; source records reported0, not reconstructed wait journal/handle/SDK proof. Legacy required setup/APIreturns not all serialized. Error identities serialized as booleans/stages/types only, not persisted exception objects. Root actualEX through known finite controls; fixturecallbacks synthetic. No cancel/kill/replay/live workaround or full Git/delegate/interpreter/descendant/instruction closure proof.',
 models=dict(Gemma_orientation=dict(pid=6574,direct_status=0,root_corrections='Requires status success, not !=success; audit may fail before any row; local close is not inventory. _finish retains lastPopen while clearing log/events; pure object inventory not invalid just because audit failed; no nonrepudiation/globalauth claim.'),
  GLM_plan=dict(pid=7116,direct_status=0,root_qualification='First-before-close, publication matches re-raised earliest and private sequential observation/process-life. Constructor starts NONE; no reset or constructor error history. No close-policy/physical proof.'),
  Qwen_tests=dict(pid=7140,direct_status=0,root_qualification='ZERO hooks, actual Git Fixture not echo config, no guessed fields/commands; explicit secondary occurrence retained even same object. No fake positive SDK/actor proof.'),
  Qwen_review=dict(pid=8865,direct_status=1,input_chars=17734,tokenlimit=1700,reported_visible_chars=6015,stdout_size=0,
   full_partial_final_assessment_absent=True,backend_reachable=True,reaped=True,no_unavailability_or_approval=True,
   source_epoch='3209641094614cf1ca96c5eb9e3d11ea5db21d4782dc5ea74524bb2ee3e38e31',
   test_epoch='40ef5a6a83459afb2448e176daba9964ab1cde10dec40c05cc9082406e0b2e53'),
  ROOT='Independently added input-open/ambient regressions after review epoch. Whole final changed constructor/helper/audit/emitter and tests inspected. Narrow exception-operand/nohook guard and original-testclass checks executed in first finalizer before its bookkeeping failure. Not model fullcurrent-source approval; no unchanged controls/reviews repeated.'),
 source_preservation='Only producer/test pair. Constructor only three private initializers, existing _receipt_source_audit/_emit changed +new _retain_receipt_error. All other CommandProducer methods, AuxiliaryCommand/retainedowner classes, original modulefunctions/factories/publicemitters/gates except stricter receipt terminal history, original testclasses/other18tools/selected3bins unchanged. First structural assertion path reached invalid broad-str guard; individual predicate returns not all serialized, not reconstructed/repeated. Final source snapshots retained.',
 administrative_failures=dict(initial_functions_JSparse='before nested tools/filesystem/sourcewrite/actor; fulltoolbody not separately serialized',
  first_ROOT_assessment='direct1 overly broad no-str predicate rejected legitimate str(run.repo), line41 BEFORE stage/Git work; exact source retained/fullrawCLItrace not regularfile',
  first_report_finalizer='direct1 UnboundLocalError f shadow at line72 after first branch Git communicate/wait but BEFORE buffer/PID/status serialization. PerGitPID/signedstatus/rawbuffers NULL/unknown, never invented0. Exact source retained/fullrawCLItrace not regularfile. No unchanged branchGit/AST/tests/models rerun to fill gap.',
  current_finalization='Distinct namespace consumes retained JSON reports only, no source execution/stream-content re-audit. Remaining HEAD/status/diff first executed now.'),
 prior_unserialized_branch_Git=dict(argv=['git','-C',str(source_root),'branch','--show-current'],pid=None,status=None,stdout=None,stderr=None,scope='Reported invocation/control-flow FILEDATA, not persisted process/stream proof'),
 stage_results=stage_results,serialized_controls=controls,NEW_fixture_report_index=fixture_index,
 own_posttest_Git=commands,own_HEAD=head,current_branch_observation=None,
 expected_branch_contract='codex/flatbuffers-native-perf-guard (earlier observed, not re-observed after missing first finalizer serialization)',
 whole_helper_WT_dirty20=True,all20_uncommitted_uncanonical_unadmitted=True,production_tracked_diff_empty=True,
 production_native_outputs_instructionclosure_not_newly_proved=True,private_controllers_outside_HELPERBUNDLE20=True,
 no_source_commit_push_adoption_or_strictdispatch=True,
 remaining='Receipt resource/writer uncertainty and audit partialactors/unknownstarts/fullphysical officialEX controller, current20 canonical/newsourceepoch package, originalPATH SDK/bootstrap/first3locks-hiddenconfigs, OWNnative-driver-staticRLIB/compiler-tool-kernel and actualoriginalhost credential/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage provenance remain incomplete. ProviderABSENT/gatealwaysraises/controllerclosed/all3flagsFalse/ownershipNone. No actual SDK/nativebuild/canonical/kernel/broker/benchmark/capture/RAMcause-repair/acceptance.',
 free_after=os.statvfs(source_root).f_bavail*os.statvfs(source_root).f_frsize,no_cleanup=True,space_change_cause_unmeasured=True)
 put(final_root/'assessment.json',assessment)
 checkpoint=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');value=json.loads(checkpoint.read_text());native=value['native_perf_only_diagnostic_design']
 native['receipt_error_component'].update(assessment=str(final_root/'assessment.json'),root_finalization=str(final_root),
  review_pending=False,publication_pending=True,ROOT_final_methods_review_pending=False,all_own_model_test_sessions_terminal=True,
  never_repeat_unchanged=True,no_close_policy_or_physicalcontroller_proof=True,before7FAIL_fixed9PASS=True,
  NEWboundaries2FAIL_fixed4PASS_separate=True,ambient_history_bug_introduced_in_initial_implementation=True,
  root_admin_broad_str_then_shadow_errors=True,prior_branch_Git_PID_status_streams_not_serialized=True,
  source_sha256=assessment['current_source_sha256'],test_sha256=assessment['current_test_sha256'],all_admission_flags=False)
 native['last_free_bytes']=assessment['free_after'];value['active_turn_status']='receipt_error_ROOT_assessed9PASS_plus_separate4PASS_publication_pending_fullphysicalbridge_incomplete'
 checkpoint.write_text(json.dumps(value,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['current_source_sha256'],test=assessment['current_test_sha256'],
  stage_results=stage_results,posttestGit_statuses=[record['status'] for record in commands],
  prior_branch_status=None,free=assessment['free_after'])))
