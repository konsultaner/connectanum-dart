
class ReceiptErrorRetentionTests(unittest.TestCase):
    """New exact-error controls; finite FIXTURE shims are never SDK evidence."""
    start=ProducerTests.start
    finish=ProducerTests.finish
    make_tool=ProducerTests.make_tool
    receipt_fixture=ProducerTests.receipt_fixture

    def setUp(self):
        self.setup_children=[];self.setup_records=[]
        ProducerTests.setUp(self)

    def git(self,*args):
        number=len(self.setup_records)
        child=subprocess.Popen(['git','-C',str(self.repo),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.setup_children.append(child)
        stdout,stderr=child.communicate();status=child.wait()
        row=dict(pid=child.pid,argv=list(args),status=status,stdout_eof=True,stderr_eof=True)
        for name,data in [('stdout',stdout),('stderr',stderr)]:
            with (self.base/('setup-'+str(number)+'-'+name+'.bin')).open('xb') as f:f.write(data)
            row[name+'_size']=len(data);row[name+'_sha256']=digest(data)
        self.setup_records.append(row)
        self.assertEqual(0,status)
        return stdout

    def hooks(self):
        calls=[]
        class HookTrip(RuntimeError):pass
        class HookError(OSError):
            def __repr__(self):calls.append('repr');raise HookTrip('OWN repr hook')
            def __str__(self):calls.append('str');raise HookTrip('OWN str hook')
            def add_note(self,note):calls.append('note');raise HookTrip('OWN note hook')
        return calls,HookError

    def capture(self,run,primary,invoke,hooks,extra=None):
        caught=None
        try:invoke()
        except BaseException as error:caught=error
        first=run.__dict__.get('_receipt_primary_error_object')
        secondaries=run.__dict__.get('_receipt_secondary_error_objects',[])
        path=run.directory/'receipt-failure.json'
        public=path.read_bytes() if path.exists() else None
        row=dict(caught_type=None if caught is None else type.__getattribute__(type(caught),'__name__'),
            caught_is_primary=caught is primary,retained_first_is_primary=first is primary,
            primary_stage=run.__dict__.get('_receipt_primary_error_stage'),hooks=list(hooks),
            secondary_stages=[entry[0] for entry in secondaries],
            secondary_types=[type.__getattribute__(type(entry[1]),'__name__') for entry in secondaries],
            receipt_attempted=run.receipt_attempted,
            public_failure_hex=None if public is None else public.hex(),
            public_failure_sha256=None if public is None else digest(public),
            no_input_receipt=not (run.directory/'input-receipt.json').exists(),
            no_binding=not (run.directory/'receipt-binding.json').exists())
        if extra is not None:row.update(extra())
        with (self.base/'error-control-before-cleanup.json').open('x') as f:json.dump(row,f,indent=2)
        return caught,secondaries,public

    def assert_first(self,run,primary,caught,hooks):
        self.assertTrue(caught is primary)
        self.assertTrue(run.__dict__.get('_receipt_primary_error_object') is primary)
        self.assertEqual([],hooks);self.assertTrue(run.receipt_attempted)
        self.assertFalse((run.directory/'input-receipt.json').exists())
        self.assertFalse((run.directory/'receipt-binding.json').exists())

    def test_source_primary_never_calls_repr_str_or_add_note(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks();primary=Error(5,'OWN private source failure')
        with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary):
            caught,secondary,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
        self.assert_first(run,primary,caught,hooks)
        self.assertEqual([],secondary)
        self.assertEqual({'primary_error':'HookError','terminal':True},json.loads(raw))

    def test_partial_failure_publication_keeps_primary_secondary_and_no_retry(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN source');secondary=Error(28,'OWN publication');writes=[];actual=producer._write_json
        def write(path,value):
            if Path(path).name=='receipt-failure.json':
                writes.append('publication');Path(path).write_bytes(b'OWN-partial-failure');raise secondary
            return actual(path,value)
        with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary),\
             mock.patch.object(producer,'_write_json',write):
            caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
        self.assert_first(run,primary,caught,hooks)
        self.assertEqual(b'OWN-partial-failure',raw);self.assertEqual(['publication'],writes)
        self.assertEqual('failure_publication',errors[-1][0]);self.assertTrue(errors[-1][1] is secondary)
        with mock.patch.object(producer,'_regular_hash',side_effect=AssertionError('second artifact read')):
            with self.assertRaises(producer.ProducerError):producer.emit_fixture_receipt(run,'canonical')
        self.assertEqual(b'OWN-partial-failure',(run.directory/'receipt-failure.json').read_bytes())

    def audit_close(self,body_error):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN source body') if body_error else None
        close_error=Error(5,'OWN after actual audit close');closed=[]
        actual=Path.open
        class Audit:
            def __init__(self,writer):self.writer=writer
            def __getattr__(self,name):return getattr(self.writer,name)
            def close(self):
                self.writer.close();closed.append(self.writer.closed);raise close_error
        def opening(path,*args,**kwargs):
            writer=actual(path,*args,**kwargs)
            return Audit(writer) if path.name=='receipt-source-audit.jsonl' and args and args[0]=='xb' else writer
        def source_guard(current,observe=None):
            if primary is not None:raise primary
        wanted=primary if primary is not None else close_error
        with mock.patch.object(Path,'open',opening),mock.patch.object(producer.CommandProducer,'_source_guard',source_guard):
            caught,errors,raw=self.capture(run,wanted,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks,
                lambda:dict(actual_audit_closed=list(closed)))
        self.assert_first(run,wanted,caught,hooks);self.assertEqual([True],closed)
        if body_error:self.assertTrue(errors[0][1] is close_error)
        else:self.assertEqual([],errors)
        self.assertEqual('HookError',json.loads(raw)['primary_error'])

    def test_actual_audit_close_secondary_never_replaces_source_primary(self):
        self.audit_close(True)

    def test_actual_audit_close_without_body_error_is_exact_primary(self):
        self.audit_close(False)

    def copy_failure(self,close_fd=False,close_output=False):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks()
        primary=Error(5,'OWN copy read');fd_error=Error(5,'OWN after FD close');out_error=Error(5,'OWN after output close')
        active=[];closed=[];output_closed=[]
        actual_read=producer.os.read;actual_close=producer.os.close;actual_open=Path.open
        def read(fd,count):
            if (run.directory/'complete-command.log').exists():
                if not active:active.append(fd)
                if fd==active[0]:raise primary
            return actual_read(fd,count)
        def close(fd):
            result=actual_close(fd)
            if active and fd==active[0]:
                closed.append(fd)
                if close_fd:raise fd_error
            return result
        class Output:
            def __init__(self,writer):self.writer=writer
            def __enter__(self):return self.writer.__enter__()
            def __exit__(self,*args):
                self.writer.__exit__(*args);output_closed.append(self.writer.closed);raise out_error
        def opening(path,*args,**kwargs):
            writer=actual_open(path,*args,**kwargs)
            return Output(writer) if close_output and path.name=='complete-command.log' and args and args[0]=='xb' else writer
        with mock.patch.object(producer.os,'read',read),mock.patch.object(producer.os,'close',close),\
             mock.patch.object(Path,'open',opening):
            caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks,
                lambda:dict(actual_fd_close_count=len(closed),actual_output_closed=list(output_closed)))
        self.assert_first(run,primary,caught,hooks);self.assertEqual(1,len(closed))
        if close_fd:self.assertTrue(any(error is fd_error for stage,error in errors))
        if close_output:
            self.assertTrue(any(error is out_error for stage,error in errors));self.assertEqual([True],output_closed)
        self.assertEqual('HookError',json.loads(raw)['primary_error'])

    def test_copy_read_primary_survives_actual_FD_close_secondary(self):
        self.copy_failure(close_fd=True)

    def test_earliest_copy_error_survives_actual_output_context_close(self):
        self.copy_failure(close_fd=True,close_output=True)

    def test_same_primary_object_at_publication_retains_secondary_occurrence(self):
        run,_,_,_=self.receipt_fixture();hooks,Error=self.hooks();primary=Error(5,'OWN repeated object')
        actual=producer._write_json
        def write(path,value):
            if Path(path).name=='receipt-failure.json':raise primary
            return actual(path,value)
        with mock.patch.object(producer,'_receipt_source_audit',side_effect=primary),mock.patch.object(producer,'_write_json',write):
            caught,errors,raw=self.capture(run,primary,lambda:producer.emit_fixture_receipt(run,'canonical'),hooks)
        self.assert_first(run,primary,caught,hooks)
        self.assertTrue(raw is None);self.assertEqual(1,len(errors))
        self.assertEqual('failure_publication',errors[0][0]);self.assertTrue(errors[0][1] is primary)

    def tearDown(self):
        actors=[];streams=[];command_records=[]
        for run in self.runs:
            self.assertFalse(run.pending);self.assertTrue(run.finished)
            command_records.extend(dict(record) for record in run.records)
            processes=[('last_recipe_only',run.process)]
            for index,auxiliary in enumerate(run.auxiliary_operations):
                self.assertTrue(auxiliary.finished)
                processes.append(('auxiliary-'+str(index),auxiliary.process))
                for role,stream in auxiliary.streams.items():
                    self.assertTrue(stream['eof']);self.assertIsNone(stream['fd'])
                    path=stream['path'];fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
                    try:
                        first=os.fstat(fd);parts=[]
                        self.assertLessEqual(first.st_size,2*1024**2)
                        while True:
                            part=os.read(fd,65536)
                            if not part:break
                            parts.append(part)
                        raw=b''.join(parts);after=os.fstat(fd);info=path.stat()
                        identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
                        self.assertEqual(identity(first),identity(after));self.assertEqual(identity(first),identity(info))
                    finally:os.close(fd)
                    self.assertEqual(stream['bytes'],len(raw));self.assertEqual(stream['hash'].hexdigest(),digest(raw))
                    streams.append(dict(auxiliary_index=index,role=role,pid=auxiliary.process.pid,eof=stream['eof'],
                        fd_is_none=stream['fd'] is None,path=path.relative_to(self.base).as_posix(),
                        size=len(raw),sha256=digest(raw),held_before_after_path_identity=identity(first)))
            for role,process in processes:
                status=process.wait(timeout=2);self.assertIs(type(status),int);self.assertEqual(0,status)
                actors.append(dict(role=role,pid=process.pid,actual_same_Popen_final_wait=status))
        with (self.base/'new-known-actors.json').open('x') as f:
            json.dump(dict(setup_Git=self.setup_records,actors=actors,streams=streams,reported_command_records=command_records,
                previous_command_Popen_handles_NOT_retained_or_reconstructed=True,all_recorded_final_wait_statuses_zero=True,
                no_live_workaround=True,not_complete_descendant_instruction_or_FDclosure=True),f,indent=2)

