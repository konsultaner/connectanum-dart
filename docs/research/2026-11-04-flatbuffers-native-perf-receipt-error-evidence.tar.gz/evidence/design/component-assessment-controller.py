import sys,pathlib,json,hashlib,ast,copy,subprocess,os,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=True) as lease:
 lease.verify_identity()
 r=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
 p=pathlib.Path('/tmp/connectanum-native-perf-receipt-error');d=pathlib.Path('/tmp/connectanum-native-perf-receipt-error-design')
 sha=lambda raw:hashlib.sha256(raw).hexdigest()
 def put(path,obj):
  with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 put(p/'assessment-attempt.json',dict(scope='NEW ROOT source/error-stage assessment + posttest own Git metadata',no_tests_models_oldarchives_or_numerical_repeat=True))
 original=json.loads((p/'original-hashes.json').read_text());final=json.loads((p/'boundaries-fixed-hashes.json').read_text())
 assert len(original)==len(final)==23
 for rel,digest in final.items():assert sha((r/rel).read_bytes())==digest
 changed=[rel for rel in final if final[rel]!=original[rel]]
 assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 def source(stage,rel):return (p/(stage+'-source')/rel).read_text()
 old=ast.parse(source('original','tool/native_perf_build_producer.py'));newtext=source('boundaries-fixed','tool/native_perf_build_producer.py');new=ast.parse(newtext)
 dump=lambda n:ast.dump(n,include_attributes=False)
 funcs=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 classes=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
 of=funcs(old);nf=funcs(new);oc=classes(old);nc=classes(new)
 assert set(nf)-set(of)=={'_retain_receipt_error'}
 modified=[name for name in of if dump(of[name])!=dump(nf[name])]
 assert set(modified)=={'_receipt_source_audit','_emit'}
 assert oc.keys()==nc.keys()
 for name in oc:
  if name!='CommandProducer':assert dump(oc[name])==dump(nc[name]),name
 methods=lambda c:{n.name:n for n in c.body if isinstance(n,ast.FunctionDef)}
 om=methods(oc['CommandProducer']);nm=methods(nc['CommandProducer'])
 assert om.keys()==nm.keys()
 assert [name for name in om if dump(om[name])!=dump(nm[name])]==['__init__']
 ctor=copy.deepcopy(nm['__init__'])
 fields={'_receipt_primary_error_object','_receipt_primary_error_stage','_receipt_secondary_error_objects'}
 ctor.body=[node for node in ctor.body if not (isinstance(node,ast.Assign) and any(isinstance(target,ast.Attribute) and target.attr in fields for target in node.targets))]
 assert dump(ctor)==dump(om['__init__'])
 # Provenance/success gates unchanged; only terminal failure history additionally refuses.
 assert [dump(n) for n in of['_emit'].body[:3]]==[dump(n) for n in nf['_emit'].body[:3]]
 assert dump(of['emit_receipt'])==dump(nf['emit_receipt']) and dump(of['emit_fixture_receipt'])==dump(nf['emit_fixture_receipt'])
 for name in ['_retain_receipt_error','_receipt_source_audit','_emit']:
  calls=[node for node in ast.walk(nf[name]) if isinstance(node,ast.Call)]
  assert not any(isinstance(node.func,ast.Name) and node.func.id in {'repr','str'} or isinstance(node.func,ast.Attribute) and node.func.attr=='add_note' for node in calls)
  assert not any(isinstance(node.func,ast.Attribute) and node.func.attr=='exception' for node in calls)
 lines=newtext.splitlines();selected='\n\n'.join('\n'.join(lines[n.lineno-1:n.end_lineno]) for n in [nm['__init__'],nf['_retain_receipt_error'],nf['_receipt_source_audit'],nf['_emit']])
 with (d/'ROOT-final-affected-source.txt').open('x') as f:f.write(selected)
 ot=ast.parse(source('original','tool/test_native_perf_build_producer.py'));nt=ast.parse(source('boundaries-fixed','tool/test_native_perf_build_producer.py'))
 otc=classes(ot);ntc=classes(nt)
 assert set(ntc)-set(otc)=={'ReceiptErrorRetentionTests'}
 for name in otc:assert dump(otc[name])==dump(ntc[name]),name
 assert {name:dump(v) for name,v in funcs(ot).items()}=={name:dump(v) for name,v in funcs(nt).items()}
 newtests=[n.name for n in ntc['ReceiptErrorRetentionTests'].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
 assert len(newtests)==9
 stages={};controls={}
 for stage in ['before','implemented','boundaries-before','boundaries-fixed']:
  report=json.loads((p/(stage+'-tests.json')).read_text());fixture_reports=[];git_rows=[];actor_rows=[];stream_rows=[];reported_commands=[]
  for path in sorted((p/(stage+'-fixtures')).rglob('new-known-actors.json')):
   data=json.loads(path.read_text())
   assert data['previous_command_Popen_handles_NOT_retained_or_reconstructed'] is True
   assert data['all_recorded_final_wait_statuses_zero'] is True
   fixture_reports.append(dict(path=path.relative_to(p).as_posix(),sha256=sha(path.read_bytes()),size=path.stat().st_size))
   git_rows.extend(data['setup_Git']);actor_rows.extend(data['actors']);stream_rows.extend(data['streams']);reported_commands.extend(data['reported_command_records'])
   for row in data['setup_Git']:
    assert type(row['status']) is int and row['status']==0 and row['stdout_eof'] is True and row['stderr_eof'] is True
   for row in data['actors']:assert type(row['actual_same_Popen_final_wait']) is int and row['actual_same_Popen_final_wait']==0
   for row in data['streams']:
    raw=(path.parent/row['path']).read_bytes()
    assert len(raw)==row['size'] and sha(raw)==row['sha256'] and row['eof'] is True and row['fd_is_none'] is True
  stages[stage]=dict(tests=report['tests'],failures=report['failures'],errors=report['errors'],NEW_fixture_reports=fixture_reports,
   NEW_actual_setup_Git_rows=len(git_rows),NEW_available_lastrecipe_aux_Popen_rows=len(actor_rows),
   NEW_signed_final_wait_statuses=[row['actual_same_Popen_final_wait'] for row in actor_rows],
   NEW_aux_stream_rows=len(stream_rows),reported_command_records=len(reported_commands),
   reported_fixture_toolshim_records=sum(row['kind']=='tool_version' for row in reported_commands),
   previous_command_Popen_handles_not_retained=True,legacy_required_setup_APIreturns_not_all_serialized=True)
  controls[stage]=[]
  for pattern in ('error-control-before-cleanup.json','ambient-context-control.json'):
   for path in sorted((p/(stage+'-fixtures')).rglob(pattern)):
    raw=path.read_bytes();controls[stage].append(dict(path=path.relative_to(p).as_posix(),sha256=sha(raw),size=len(raw),observed=json.loads(raw)))
 assert stages['before']['tests']==7 and stages['before']['failures']==7 and not stages['before']['errors']
 assert stages['implemented']['tests']==9 and not stages['implemented']['failures'] and not stages['implemented']['errors']
 assert stages['boundaries-before']['tests']==2 and stages['boundaries-before']['failures']==2 and not stages['boundaries-before']['errors']
 assert stages['boundaries-fixed']['tests']==4 and not stages['boundaries-fixed']['failures'] and not stages['boundaries-fixed']['errors']
 commands=[]
 def git(*args):
  argv=['git','-C',str(r),*args];rec=dict(argv=argv,status=None);commands.append(rec)
  child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);rec['pid']=child.pid
  stdout,stderr=child.communicate();rec['status']=child.wait()
  for label,raw in [('stdout',stdout),('stderr',stderr)]:
   with (p/('root-git-'+str(len(commands))+'-'+label+'.bin')).open('xb') as f:f.write(raw)
   rec[label+'_eof']=True;rec[label+'_sha256']=sha(raw);rec[label+'_size']=len(raw)
  put(p/('root-git-'+str(len(commands))+'-return.json'),rec)
  assert rec['status']==0;lease.verify_identity();return stdout.decode()
 branch=git('branch','--show-current').strip();head=git('rev-parse','HEAD').strip()
 assert branch=='codex/flatbuffers-native-perf-guard' and head=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
 status=git('status','--porcelain');assert set(line[3:] for line in status.splitlines())=={rel for rel in final if rel.startswith('tool/')}
 production_diff=git('diff','HEAD','--','packages','native','bin/bootstrap','bin/test-all','bin/verify');assert production_diff==''
 assessment=dict(kind='receipt_error_identity_retention_source_component_v1',current_source_sha256=final['tool/native_perf_build_producer.py'],
 current_test_sha256=final['tool/test_native_perf_build_producer.py'],source_bundle_hashes=final,
 behavior='Private receipt error history initialized empty before constructor lease callback. Exact primary/stage and ordered secondary occurrence objects retained process-life by identity, no repr/str/add_note/custom exception equality. Explicit secondary may be same object as primary. TYPEONLY existing primary_error public string via native type-name descriptor; earliest retained error re-raised if a later output context close replaced it. Existing success/provenance/recipe/SDK/source/output gates preserved; previous private receipt error additionally refuses a new public attempt. No reset/retry/publication overwrite.',
 boundaries='Audit body and per-input-FD body have explicit local primary variables, not inherited sys.exception. Entire complete-output BODY records error before context close, including input-open/final flush/fsync failures. These are tracked receipt/audit/copy boundaries; arbitrary nested-helper internal first-error masking is NOT globally repaired/proved.',
 before='Seven NEWcontrols fail with actual custom-hook/primary-identity problems, not seven RAM/canonical production defects. Positive setup uses actual finite FIXTURE source/Git and six shell version shims, never actual SDK/version validation.',
 results='Initial9PASS=7new+2required emitter callers. NEWboundaries2FAIL: remaining input-open error masked by actual output close; INTRODUCED false ambient-handler error history due sys.exception in initial implementation. Fixed4PASS separately=2new+2affected cleanup callers. Nine NEWtest cases exist; not combined13/fullfinal11/canonical.',
 resource_scope='Existing receipt/audit/copy CLOSE POLICY unchanged. Buffered audit/output close may implicitly flush after earlier write/flush failure; uncertainty/quarantine/actor inventory NOT repaired by this narrow error fix. No closed-FD/physical lease-release/admission authority. Missing receipt audit/output/failure-writer resources, receipt-audit partial actors/unknown starts/history/full physical controller still incomplete. Freeze owner_emit_attempted refusal unchanged.',
 provenance='Actual finite tiny owned Git Fixture/6tool shellshims+Pythonrecipe/synthetic output roles/Fixture receipts ONLY. No installed SDK/compiler/bootstrap/native build/canonical/kernel/broker/benchmark/capture. Negative source/metadata/Pathcontext/FDclose boundaries mocked; audit/output/FD close controls call actual own native close before injected fault. No cancel/kill/reset/replay; partial failure bytes remain terminal.',
 raw_limits='NEWsetup Git args, signed samePopenstatuses/BOTH EOF/fullstreamfileSHA saved. NEWavailable lastrecipe+Aux Popen handles natural finalwait0 and aux2EOF/heldFD-path bytes-digest recorded. Previous SIXversion/other command Popen handles overwritten by existing producer; their source records reported0, not reconstructed handles/full peractor wait journals/SDK proof. Required legacy setup/APIreturns not all serialized. Error identities retained private in process; serialization is observation booleans/stages/types, not persisted exception objects. Full Git/shim/interpreter/delegated/descendant/instruction/FD closure not proved. Root actualofficialEX spans known controls; fixture leasecallbacks synthetic.',
 models=dict(orientation=dict(pid=6574,direct_status=0,corrections='Actual _emit requires status success; source audit may fail before first row. Audit localwriter close not durable ownership record. _finish clears log/events refs but retains lastPopen. Pure inventory not invalid merely because audit failed; reject nonrepudiation/globalauth claim.'),
  judge=dict(pid=7116,direct_status=0,qualification='Accept first-before-close, publication matches re-raised earliest, private sequential observation point/processlife. Constructor starts NONE, not constructor error history. No physical closure/close policy proof.'),
  tests=dict(pid=7140,direct_status=0,qualification='ZERO hooks, real Git Fixture not echo config, no guessed fields/commands, retain secondary occurrence even same object. No fake positive SDK/actor closure proof.'),
  review=dict(pid=8865,direct_status=1,input_chars=17734,reason='reachable Ollama tokenlimit1700/stderr6015reportedvisiblechars/stdout0/fullpartialfinalABSENT',reaped=True,source_epoch='3209641094614cf1ca96c5eb9e3d11ea5db21d4782dc5ea74524bb2ee3e38e31',test_epoch='40ef5a6a83459afb2448e176daba9964ab1cde10dec40c05cc9082406e0b2e53',not_unavailable_or_approval=True),
  ROOT='New input-open and introduced ambient-handler regressions independently identified. Whole affected final constructor/helper/audit/emitter + NEWtests/AST/file invariants inspected; NOT model fullcurrent-source approval. No unchanged review/test/readback repeats.'),
 preserved=dict(CommandProducer_other_methods=True,AuxiliaryCommand_all=True,retained_owner_all=True,otheroriginalmodulefunctions_factories_emitters_gates_except_declared=True,
  original_testclasses=True,other18tools_selected3bins=True,production601_no_edit=True),
 changed_original_modulefunctions=modified,CommandProducer_constructor_only_three_private_initializers=True,new_helper='_retain_receipt_error',
 administrative_failure='Initial functionsJSparse missing-parenthesis BEFORE nested tools/filesystem/sourcewrite/actor; fulltoolbody not separately saved. Exact receipt retained, no reconstruction.',
 stage_results=stages,serialized_regression_controls=controls,own_posttest_Git=commands,own_HEAD=head,own_branch=branch,
 whole_helper_WT_dirty20=True,all20_uncommitted_uncanonical_unadmitted=True,private_controllers_outside_HELPERBUNDLE20=True,
 no_source_commit_push_adoption_or_strictdispatch=True,
 remaining='Independent full physical officialEX controller/receipt resource-writer uncertainty/audit partial actors/unknownstarts, current20 canonical/newsourceepoch package, runtime originalPATH SDK/bootstrap/first3locks/hiddenconfigs, OWN production native/driver/RLIB/compiler-tool-kernel and actualoriginalhost credentials/access/pidfd/FDexec/inheritance/arming/metadata/role/time/coverage pending. ProviderABSENT/liveadmissionalwaysraises/controllerclosed/all3flagsFalse/ownershipNone. No RAM cause/repair or acceptance.',
 free_after=os.statvfs(r).f_bavail*os.statvfs(r).f_frsize,no_cleanup=True,space_change_cause_unmeasured=True)
 put(p/'assessment.json',assessment)
 c=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');x=json.loads(c.read_text());n=x['native_perf_only_diagnostic_design']
 n['receipt_error_component'].update(assessment=str(p/'assessment.json'),review_pending=False,publication_pending=True,
  ROOT_final_methods_review_pending=False,all_own_model_test_sessions_terminal=True,never_repeat_unchanged=True,
  no_close_policy_or_physicalcontroller_proof=True,before7FAIL_fixed9PASS=True,NEWboundaries2FAIL_fixed4PASS_separate=True,
  ambient_history_bug_introduced_in_initial_implementation=True,all_admission_flags=False,source_sha256=assessment['current_source_sha256'],test_sha256=assessment['current_test_sha256'])
 n['last_free_bytes']=assessment['free_after'];x['active_turn_status']='receipt_error_ROOT_assessed9PASS_plus_separate4PASS_publication_pending_fullphysicalbridge_incomplete'
 c.write_text(json.dumps(x,indent=2)+'\n');lease.verify_identity()
 print(json.dumps(dict(source=assessment['current_source_sha256'],test=assessment['current_test_sha256'],
 stages={key:{k:v for k,v in value.items() if k in ['tests','failures','errors','NEW_actual_setup_Git_rows','NEW_available_lastrecipe_aux_Popen_rows','NEW_aux_stream_rows','reported_fixture_toolshim_records']} for key,value in stages.items()},
 Git_direct_statuses=[row['status'] for row in commands],free=assessment['free_after'])))
