
    def test_input_open_primary_survives_actual_output_context_close(self):
        self.copy_failure(open_input=True,close_output=True)

