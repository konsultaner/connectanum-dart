import sys,pathlib,json,ast,hashlib,subprocess,re,shutil,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 h=json.loads((P/'after-edit-hashes.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 source=(R/'tool/native_perf_build_producer.py').read_text();tests=(R/'tool/test_native_perf_build_producer.py').read_text();before=(P/'before-producer.py').read_text()
 assert source==(P/'after-producer.py').read_text()
 assert tests==(P/'existing-tests-affected-v2.py').read_text()+'\n\n'+(P/'appended-tests-v2.py').read_text()
 old=ast.parse(before);current=ast.parse(source)
 oldother=[ast.dump(n,include_attributes=False) for n in old.body if not (isinstance(n,ast.FunctionDef) and n.name=='_write_json')]
 newother=[ast.dump(n,include_attributes=False) for n in current.body if not (isinstance(n,ast.FunctionDef) and n.name=='_write_json' or isinstance(n,ast.ClassDef) and n.name=='_JSONWriteAttempt' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_JSON_WRITE_ATTEMPTS' for t in n.targets))]
 assert oldother==newother
 write=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='_write_json');lines=before.splitlines(keepends=True)
 assert source==''.join(lines[:write.lineno-1])+(P/'candidate-v2.py').read_text().rstrip()+'\n'+''.join(lines[write.end_lineno:])
 beforelog=(P/'before-units/stderr.bin').read_text()
 outcomes=re.findall(r'^(test_.*) \.\.\. (FAIL|ok|ERROR)$',beforelog,re.M)
 assert len(outcomes)==10 and sum(x[1]=='FAIL' for x in outcomes)==7 and sum(x[1]=='ok' for x in outcomes)==3 and not any(x[1]=='ERROR' for x in outcomes)
 after=json.loads((P/'after-selected/result.json').read_text());assert (after['tests'],after['failures'],after['errors'])==(25,0,0)
 bv=[json.loads(f.read_text()) for f in sorted((P/'before-units/fixtures').glob('*/view-before-ROOT-cleanup.json'))]
 av=[json.loads(f.read_text()) for f in sorted((P/'after-selected/fixtures').glob('*/view-before-ROOT-cleanup.json'))]
 assert len(bv)==len(av)==10
 afterby={v['mode']:v for v in av};beforeby={v['mode']:v for v in bv}
 assert beforeby['write_and_exit_fault']['received_secondary'] and afterby['write_and_exit_fault']['received_original']
 for mode in ['json_error','write_fault','write_and_exit_fault','flush_fault','fsync_fault','short3']:
  assert afterby[mode]['events'][-1]['stage']==('json' if mode=='json_error' else 'write' if mode in ['write_fault','write_and_exit_fault','short3'] else mode.removesuffix('_fault'))
  assert not afterby[mode]['native_closed']
 for mode,v in afterby.items():
  assert v['source_attempt_present']
  if mode.startswith('normal'):assert v['source_completed'] and v['file_size']==38
  else:assert not v['source_completed']
 for mode in ['write_fault','write_and_exit_fault','flush_fault','fsync_fault','exit_fault']:
  row=afterby[mode]['source_rows'][-1];assert not row['returned'] and row['raw']['value'] is None
 shortrow=afterby['short3']['source_rows'][-1];assert shortrow['stage']=='write' and shortrow['returned'] and shortrow['raw']['value']==3
 assert not afterby['short3']['result_is_None'] and beforeby['short3']['result_is_None']
 cleanup=[json.loads(f.read_text()) for f in (P/'after-selected/fixtures').glob('*/ROOT-known-writer-cleanup.json')]
 closed=[v for v in cleanup if v['attempted']]
 assert len(cleanup)==10 and len(closed)==6 and all(v['identity_match'] and v['returned'] is None and 'error_type' not in v for v in closed)
 git=[]
 commands=[['rev-parse','HEAD'],['branch','--show-current'],['status','--short','--untracked-files=all'],['diff','--name-only','HEAD','--','packages','native']]
 q=P/'ROOT-git';q.mkdir()
 for i,args in enumerate(commands):
  argv=['git',*args];op=dict(argv=argv,cwd=str(R),Popen_attempted=True,pid=None)
  (q/(str(i)+'-before.json')).write_text(json.dumps(op,indent=2))
  child=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(i)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(i)+'-stdout.bin')).write_bytes(out);(q/(str(i)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_separate_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());git.append(item);assert status==0 and err==b''
  if i==0:assert out.decode().strip()=='601108ea6216464bd00ae29c16cfaf0a59c71db6'
  elif i==1:assert out.decode().strip()=='codex/flatbuffers-native-perf-guard'
  elif i==2:
   expected={k for k in h if k.startswith('tool/native_perf_') or k.startswith('tool/test_native_perf_')}
   assert len(expected)==20
   assert {line[3:] for line in out.decode().splitlines()}==expected and all(x.startswith('?? ') for x in out.decode().splitlines())
  elif i==3:assert out==b''
 body=next(n for n in current.body if isinstance(n,ast.ClassDef) and n.name=='_JSONWriteAttempt')
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['add_note','close'] for n in ast.walk(body))
 free=shutil.disk_usage(R).free
 assessment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=h['tool/native_perf_build_producer.py'],test_sha256=h['tool/test_native_perf_build_producer.py'],before=dict(tests=10,failures=7,passes=3,errors=0,interpretation='5 automatic-exit path failures include masking first; 1 prefix3 count integrity failure; 1 exit-error retained-attempt policy failure. NOT7 native/kernel bugs'),after=after,ROOT=dict(source_bytes_and_all_other_AST_exact=True,original_test_bytes_exact_except_declared_one_helper_and_append=True,hashes23=h,other18_helpers_and3bins_unchanged=True,normal_JSON_and_Python_APIorder_preserved=True,ignored_normal_exit_None_False_object_preserved=True,unknown_return_None_is_not_known_None=True,pure_first_guard_no_IO_asserted=True,new_units_known_native_ROOT_cleanup_after_raws=6,cleanup_identity_verified=True,git_commands=git,whole_final_selected_source_tests_AST_independently_qualified_NOT_model_full_current_approval=True),limits=['Source tools still all20uncommitted/uncanonical/unadmitted; production601 untouched','Global generic writer registry is process-life literal native Path DATA; relative/absolute aliases, restart, credentials, ownership, durable namespace, atomic ABA not established','Unknown handles retain original received refs; partial open unknown cannot be reconstructed from ROOT hidden native return','Registry/rows/closures/values/tracebacks retain shared refs; growth unmeasured; no exact heap/RSS/timing/cause/trim-reset-evict permission','Path/open/enter/lookup/encode/fileno-invalid/metadata-damage negative branches SOURCE only, not executed coverage','New writer units are actual parent BufferedWriter/json/fsync facades, controlled prefix3 and postreturn faults; method counts not syscall counts','ROOT known native close AFTER evidence unit only; 0 precleanup output may become 3B during ROOT close, never Source publication/durability/physical EX','Earlier fixture setup/actorFD/other delegate API returns not all serialized; no complete child FD/interpreter/delegate/descendant instruction census','BEFORE unittest subprocess has signed1+BOTHEOF; AFTER executes same-process under actual officialEX + unit log, not independent full physical EX controller','No SDK/native build/canonical/kernel/broker/benchmark/capture/adoption/RAM repair/strict acceptance; provider absent/gate always raises/controller closed/ownership None/all flagsFalse'],remaining=['generic _regular_hash internal open/read/fstat/close/add_note','unexecuted earlier generic writer open/enter/fileno error seams and original factory partial-object retention','actual FileIO backing writer FDs/earlier init/internalFD errors','enclosing producer cleanup/reporting','independent frozen historical continuation/log sealing','transitive unknown actors/shared journal writers/interpreter delegates','full independent actual official EX and original-runtime immutable COMPLETE admission'],storage=dict(free_bytes=free,test_floor_open=free>=1024**3,build_floor_open=free>=12*1024**3,recheck_required=True,no_build_capture_authority=True,outside_old_cleanup_cause='UNMEASURED',no_deletion_authority=True))
 with (P/'ROOT-assessment.json').open('x') as f:json.dump(assessment,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['generic_json_writer_progress'];n.update(ROOT_assessment=str(P/'ROOT-assessment.json'),ROOT_qualified=True,component_scope='generic writer selected body-error/shortwrite retention ONLY; not all generic FD error seams/full admission',source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256']);c['active_turn_status']='Generic_JSONwriter_scoped25PASS_ROOTqualified_DOCS_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(source_sha256=assessment['source_sha256'],test_sha256=assessment['test_sha256'],tests=25,failures=0,errors=0,git4_all0_BOTH_EOF=True,free_bytes=free,ROOT_qualified=True,full_admission=False)))
