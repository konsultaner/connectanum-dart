import sys,pathlib,json,hashlib,ast
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 old=(P/'before-producer.py').read_text();tests=(P/'before-existing-tests.py').read_text()
 assert (R/'tool/native_perf_build_producer.py').read_text()==old
 assert (R/'tool/test_native_perf_build_producer.py').read_text()==tests
 candidate=(P/'candidate-v2.py').read_text()
 tree=ast.parse(old);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_write_json')
 lines=old.splitlines(keepends=True)
 source=''.join(lines[:fn.lineno-1])+candidate.rstrip()+'\n'+''.join(lines[fn.end_lineno:])
 changed_tests=(P/'existing-tests-affected-v2.py').read_text()+'\n\n'+(P/'appended-tests-v2.py').read_text()
 ast.parse(source);ast.parse(changed_tests)
 old_other=[ast.dump(n,include_attributes=False) for n in tree.body if not (isinstance(n,ast.FunctionDef) and n.name=='_write_json')]
 new_other=[ast.dump(n,include_attributes=False) for n in ast.parse(source).body if not (isinstance(n,ast.FunctionDef) and n.name=='_write_json' or isinstance(n,ast.ClassDef) and n.name=='_JSONWriteAttempt' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_JSON_WRITE_ATTEMPTS' for t in n.targets))]
 assert old_other==new_other
 beforehashes=json.loads((P/'before-hashes.json').read_text())
 (R/'tool/native_perf_build_producer.py').write_text(source)
 (R/'tool/test_native_perf_build_producer.py').write_text(changed_tests)
 afterhashes={k:hashlib.sha256((R/k).read_bytes()).hexdigest() for k in beforehashes}
 changed=[k for k in beforehashes if beforehashes[k]!=afterhashes[k]]
 assert sorted(changed)==['tool/native_perf_build_producer.py','tool/test_native_perf_build_producer.py']
 for name,body in [('after-producer.py',source),('after-tests.py',changed_tests)]:
  with (P/name).open('x') as f:f.write(body)
 with (P/'after-edit-hashes.json').open('x') as f:json.dump(afterhashes,f,indent=2)
 result=dict(source_sha256=afterhashes['tool/native_perf_build_producer.py'],test_sha256=afterhashes['tool/test_native_perf_build_producer.py'],changed=changed,other21_hashes_unchanged=True,old_other_source_AST_exact=True,original_tests_exact_except_declared_one_helper_and_append=True,canonical=False,admitted=False)
 with (P/'edit-result.json').open('x') as f:json.dump(result,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['generic_json_writer_progress'];n.update(source_UNCHANGED=False,candidate_UNIMPLEMENTED=False,edit=result,after_pending=True);c['active_turn_status']='Generic_JSONwriter_NEW10_before7FAIL3PASS_minimalinternalrepair_awaitingAFTER';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(result))
