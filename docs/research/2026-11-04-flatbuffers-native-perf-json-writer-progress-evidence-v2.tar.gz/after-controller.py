import sys,pathlib,json,hashlib,os,io,types,unittest,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-design-v1');R=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart')
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity()
 h=json.loads((P/'after-edit-hashes.json').read_text())
 assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==v for k,v in h.items())
 free=shutil.disk_usage(R).free;assert free>=1073741824
 q=P/'after-selected';q.mkdir();fixtures=q/'fixtures';fixtures.mkdir()
 os.environ['CONNECTANUM_JSON_WRITER_FIXTURES']=str(fixtures);os.environ['CONNECTANUM_PERF_PRODUCER_FIXTURES']=str(fixtures)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'tool'))
 source=(R/'tool/native_perf_build_producer.py').read_bytes();tests=(R/'tool/test_native_perf_build_producer.py').read_bytes()
 producer=types.ModuleType('native_perf_build_producer');producer.__file__=str(R/'tool/native_perf_build_producer.py');sys.modules[producer.__name__]=producer;exec(compile(source,producer.__file__,'exec'),producer.__dict__)
 tm=types.ModuleType('test_native_perf_build_producer');tm.__file__=str(R/'tool/test_native_perf_build_producer.py');sys.modules[tm.__name__]=tm;tm.__dict__['official_ex_verify']=l.verify_identity;exec(compile(tests,tm.__file__,'exec'),tm.__dict__)
 classes=['GenericJSONWriterProgressTests','AuxiliaryIntentCallProgressTests']
 names=[cls+'.'+name for cls in classes for name in unittest.defaultTestLoader.getTestCaseNames(getattr(tm,cls))]
 names+=['ProducerTests.test_positive_exact_source_commands_and_output_bytes','ProducerTests.test_nonzero_exit_preserves_log_and_prevents_next_command','ProducerTests.test_spawn_failure_retains_null_status_no_retry','ProducerTests.test_postspawn_journal_error_keeps_owned_child_waitable','AuxiliaryInitLeaseProgressTests.test_normal_INIT_actual_verify_None_preserves_intent_and_output','AuxiliaryInitLeaseProgressTests.test_INIT_ignored_False_return_preserves_original_contract','AuxiliaryStartupResourceQuarantineTests.test_normal_actual_two_stream_startup_and_wait_remain_successful','AuxiliaryFinalizationQuarantineTests.test_normal_actual_natural_wait_log_finalization_and_result']
 with (q/'declaration.json').open('x') as f:json.dump(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes=free,selection=names,expected_count=25,scope='10matchingNEW + 15 affected: 7outer including earlierprefix contract, 4CommandProducer ctor/finish/failure,2INIT,Aux startup/finalization. Not full current20canonical or admission',hashes=h),f,indent=2)
 assert len(names)==25
 suite=unittest.TestSuite()
 for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name,tm))
 out=io.StringIO();result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
 (q/'tests.log').write_text(out.getvalue())
 value=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),selection=names,source_sha256=hashlib.sha256(source).hexdigest(),test_sha256=hashlib.sha256(tests).hexdigest(),details=[dict(test=str(test),traceback=tb) for test,tb in result.failures+result.errors],not_current20canonical_or_original_runtime_admission=True)
 (q/'result.json').write_text(json.dumps(value,indent=2))
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design']['generic_json_writer_progress'];n.update(after_pending=False,after_result=value);c['active_turn_status']='Generic_JSONwriter_AFTER_'+str(result.testsRun)+'_tests_'+str(len(result.failures))+'FAIL_'+str(len(result.errors))+'ERROR_ROOT_pending';cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(value));print(out.getvalue()[-1200:])
 if not result.wasSuccessful():sys.exit(1)
