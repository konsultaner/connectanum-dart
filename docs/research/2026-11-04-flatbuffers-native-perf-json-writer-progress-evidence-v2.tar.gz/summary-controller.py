import sys,pathlib,json,subprocess,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();p=pathlib.Path("/tmp/connectanum-native-perf-json-writer-design-v1");q=p/'existing-resource-summary';q.mkdir()
 selected=json.loads((p/'existing-resource-selected.json').read_text());body='\n\n'.join(value for name,value in selected.items() if name!='_RetainedPreflightOwner')
 context="Summarize only these retained receipt-resource helpers for NEW generic JSON writer design. <=200words. Explain exact run/context preconditions, resource handle retention before fallible I/O, normal read/write/sync/close behavior, and whether they can directly replace generic _write_json buffered Path.open('xb')/writeJSON-LF/flush-fsync-context-exit without weakening old owner/freeze gates or changing normal I/O. Do not equate fields/FDs/closed/status with ownership/auth/physicalEX; claims advisory. _RetainedPreflightOwner2056line class intentionally excluded, do not invent its lifecycle. Need identify hard dependencies before exact sourceinspection. No tests/sourcechanges/CLI/kernel/SDK/benchmark underway.\n"+body
 with (q/'context.txt').open('x') as f:f.write(context)
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','summarize','--provider','ollama','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','900','--max-input-chars','20000','--max-response-chars','5000','--timeout','180','--save-output',str(q/'answer.txt')]
 with (q/'command-before.json').open('x') as f:json.dump(dict(argv=argv,context_chars=len(context),context_sha256=hashlib.sha256(context.encode()).hexdigest(),Popen_attempted=True,pid=None),f,indent=2)
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (q/'start.json').open('x') as f:json.dump(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),f)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());c['native_perf_only_diagnostic_design']['generic_json_writer_progress']=dict(path=str(p),source_epoch='4bac3d/4b55a5',source_UNCHANGED=True,NEWtests_UNEXECUTED=True,candidate_UNIMPLEMENTED=True,summary_pid=child.pid,summary_pending=True,scope='generic _write_json INTERNAL descriptor/context design; _regular_hash otherpaths/fullruntimeadmission separate');c['active_turn_status']='Generic_JSONwriter_NEWquestion_existinghelpers_summary_source4bac3d_unchanged';cp.write_text(json.dumps(c,indent=2)+'\n')
 out,err=child.communicate();status=child.wait();inp.close()
 for name,raw in [('stdout.bin',out),('stderr.bin',err)]:
  with (q/name).open('xb') as f:f.write(raw)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_EOF=True)
 with (q/'result.json').open('x') as f:json.dump(result,f,indent=2)
 l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-1000:])
