import sys,pathlib,json,hashlib,subprocess,tarfile,stat,datetime,shutil
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
P=pathlib.Path('/tmp/connectanum-native-perf-json-writer-design-v1');D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart')
prefix='docs/research/2026-11-04-flatbuffers-native-perf-json-writer-progress'
with m.local_resource_lease(exclusive=True) as l:
 l.verify_identity();q=P/'docs-publication';q.mkdir();commands=[]
 def git(args):
  index=len(commands);argv=['git',*args]
  (q/(str(index)+'-before.json')).write_text(json.dumps(dict(argv=argv,cwd=str(D),Popen_attempted=True,pid=None)))
  child=subprocess.Popen(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (q/(str(index)+'-start.json')).write_text(json.dumps(dict(pid=child.pid)))
  out,err=child.communicate();status=child.wait()
  (q/(str(index)+'-stdout.bin')).write_bytes(out);(q/(str(index)+'-stderr.bin')).write_bytes(err)
  item=dict(argv=argv,pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),both_separate_EOF=True);commands.append(item)
  (q/'commands.json').write_text(json.dumps(commands,indent=2))
  assert status==0,(args,status,err[-1000:]);return out
 assert git(['rev-parse','HEAD']).decode().strip()=='bab69f068d879ba6a9f72a168a45f3c519e99ddb'
 assert git(['branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 assessment=json.loads((P/'ROOT-assessment.json').read_text())
 rawweb=P/'python-with-web-tool-return.txt'
 selected=[];excluded=[]
 for path in sorted(P.rglob('*')):
  rel=path.relative_to(P).as_posix();info=path.lstat()
  if not stat.S_ISREG(info.st_mode):continue
  if rel.startswith('docs-publication/') or rel=='python-with-web-tool-return.txt':
   excluded.append(dict(path=rel,reason='live publication bookkeeping outside immutable archive' if rel.startswith('docs-publication/') else 'primary web-tool raw retained LOCAL ONLY; public paraphrase+URL+digest',size=info.st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()));continue
  selected.append(path)
 manifest=dict(selected=[dict(path=x.relative_to(P).as_posix(),size=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in selected],excluded=excluded,qualification='regular members only; selected-member manifest added separately; later publication/readback files outside this snapshot')
 manifestpath=P/'selected-member-manifest.json'
 with manifestpath.open('x') as f:json.dump(manifest,f,indent=2)
 selected.append(manifestpath)
 archive=D/(prefix+'-evidence.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
  for path in selected:tf.add(path,arcname=path.relative_to(P).as_posix(),recursive=False)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)==len(selected) and all(x.isfile() for x in members)
  for member in members:
   original=(P/member.name).read_bytes();raw=tf.extractfile(member).read()
   assert original==raw,member.name
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 assessment['publication']=dict(evidence=prefix+'-evidence.tar.gz',archive_sha256=digest,selected_regular_members=len(selected),all_selected_members_BYTEEXACT=True,excluded_local_raw_research=dict(sha256=hashlib.sha256(rawweb.read_bytes()).hexdigest(),full_HTML_NOT_retained=True),scope='only selected new question; no old archives; later publication bookkeeping outside members',preparation=prefix+'-preparation.md',assessment=prefix+'-assessment.json')
 (D/(prefix+'-assessment.json')).write_text(json.dumps(assessment,indent=2)+'\n')
 md=(P/'public-preparation.md').read_text()
 footer='\nThe evidence archive contains '+str(len(selected))+' selected regular members, all verified byte-exact. Archive SHA256: '+digest+'. Publication/readback receipts created afterwards are outside this snapshot.\n'
 (D/(prefix+'-preparation.md')).write_text(md+footer)
 common="""## 2026-11-04 — JSON writer retains first errors before automatic close

The generic JSON writer now retains original received manager/writer handles and per-operation intent/raw returns, rejects short counts and preserves first errors before metadata. Unknown or invalid body completion stops before automatic exit or another writer operation. Normal buffered xb/sorted-ASCII JSON/newline/method order/None result and ignored normal exit returns remain intact. Literal-Path process-lifetime records are DATA, not persistent namespaces, credentials, ownership, heap/RSS bounds or physical EX.

NEW10 at4bac3d/4b55a5 yield7FAIL/3normalPASS/0APIerrors: five automatic-exit path failures include one first-error mask, one controlled3byte write is accepted, and one exit-error case fails stronger retention policy. Finalf599f8/3c6328 passes25selected checks (10new+15affected), not aggregated/current20canonical/admission. The prior prefix test now requires the earlier stop before flush/hash and retained known count3. ROOT verifies final source/tests/AST, 23 hashes and4newGit0/BOTHstreams/601/20untracked/productiondiffempty DATA. Gemma limit1 and GLM/Qwen/GLM advisory0 are qualified; model input precedes final v2 locals/affected-helper changes. Generic hash/internalFD/earlier construction/enclosing cleanup/transitive actors/full independent EX/runtime admission remain incomplete. No SDK/build/capture/adoption/RAM repair/strict acceptance.

"""
 for relative,links in [('docs/project_state.md','research/'),('docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md','../research/')]:
  path=D/relative;old=path.read_text()
  name='2026-11-04-flatbuffers-native-perf-json-writer-progress'
  block=common+'[Exact regression, epochs and limits]('+links+name+'-preparation.md), [assessment]('+links+name+'-assessment.json), [evidence]('+links+name+'-evidence.tar.gz).\n\n'
  pos=old.index('## 2026-11-04')
  assert 'JSON writer retains first errors before automatic close' not in old
  with (q/(path.name+'-before.txt')).open('x') as f:f.write(old)
  new=old[:pos]+block+old[pos:];path.write_text(new);assert path.read_text()==new
 allowed=['docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md',prefix+'-preparation.md',prefix+'-assessment.json',prefix+'-evidence.tar.gz']
 changes=git(['status','--porcelain','--untracked-files=all']).decode().splitlines()
 assert {x[3:] for x in changes}==set(allowed)
 git(['add','--',*allowed]);git(['diff','--cached','--check']);git(['commit','-m','docs: record scoped JSON writer failure retention'])
 head=git(['rev-parse','HEAD']).decode().strip()
 git(['push','origin','codex/flatbuffers-acceptance-status'])
 assert git(['status','--porcelain','--untracked-files=all'])==b''
 receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),docs_commit=head,archive_sha256=digest,selected_regular_members=len(selected),all_selected_BYTEEXACT=True,docs_only_files=allowed,git_commands=commands,source_commit_push_adoption=False,full_admission=False)
 with (P/'publication-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
 cp=pathlib.Path('/tmp/connectanum-current-task-checkpoint.json');c=json.loads(cp.read_text());n=c['native_perf_only_diagnostic_design'];n['generic_json_writer_progress'].update(publication=receipt,docs_pending=False)
 n['current_source_sha256']=json.loads((P/'after-edit-hashes.json').read_text());n['current_free_bytes_about']=assessment['storage']['free_bytes']
 constraints=n['next'][n['next'].index('\nNeed '):]
 n['next']='Original generic _regular_hash INTERNAL open/read/fstat/close/add_note progress; writer unexecuted path/open/enter/lookup/encode/invalid-fileno/metadata seams; earlier init/original enclosing factory partialobjectretention; actual FileIO backing writerFDs/internalFDerrors; enclosingproducer cleanup/reporting; independent frozen historical continuation/logsealing; transitive unknownactors/sharedwriters/interpreterdelegates; fullindependent actualofficialEX and originalruntime immutableCOMPLETE admission. Currentf599f8/3c6328 generic JSON writer selected body-error/shortwrite-only progress complete with25selectedPASS; allprior scopes historical, no current20canonical/admission. Unknownconstructor permanentrefusal/no field-derived ownerclose API. Retainknownhandles BEFOREfallibleIO; boundedSAMEactorwaits/no cancel-restart-reset-retry-replay-advance. Freezeowner_emit_attempted/oldfreeze-aux predicates unchanged; FDclosed/status/EOF/join/history/sourcefacts NEVEREXrelease/admission.'+constraints
 c.update(status_docs_commit=head,updated_utc=receipt['utc'],active_turn_status='Generic_JSONwriter_scoped25PASS_docs_pushed_descriptions_automation_pending')
 cp.write_text(json.dumps(c,indent=2)+'\n')
 l.verify_identity();print(json.dumps(dict(docs_commit=head,archive_sha256=digest,members=len(selected),docs_only=True,source_uncommitted=True)))
