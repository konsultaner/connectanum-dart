"""Fresh generic writer IO fixtures. No SDK/build/capture/admission authority."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock
import native_perf_build_producer as producer


class GenericJSONWriterProgressTests(unittest.TestCase):
    def _writer_case(self, mode):
        root = Path(os.environ['CONNECTANUM_JSON_WRITER_FIXTURES'])
        base = Path(tempfile.mkdtemp(prefix=mode+'-', dir=root)).resolve()
        path = base/'data.json'
        events=[]; handles={}; observed={}; primary=OSError('ROOT injected post-return error')
        secondary=OSError('ROOT injected exit secondary')
        value={'z':'\u00e4','a':[1,True,None]}
        if mode=='json_error':
            value=[]; value.append(value)
        original_open=Path.open
        original_dumps=json.dumps
        original_fsync=os.fsync

        def view_raw(raw):
            if raw is None:return {'kind':'None','value':None}
            if type(raw) in (int,bool,str):return {'kind':type(raw).__name__,'value':raw}
            return {'kind':type(raw).__name__}

        def native_call(stage, fn, *args, **kwargs):
            events.append({'stage':stage,'attempted':True,'returned':False})
            row=events[-1]
            try:raw=fn(*args,**kwargs)
            except BaseException as error:
                row['error_type']=type(error).__name__
                if stage=='json':observed['primary']=error
                raise
            row['returned']=True;row['raw']=view_raw(raw)
            if mode==stage+'_fault' or (mode=='write_and_exit_fault' and stage=='write'):
                raise primary
            return raw

        class Manager:
            def __enter__(self):
                native_call('enter',handles['native'].__enter__)
                return self
            def write(self, payload):
                actual=payload[:3] if mode=='short3' else payload
                return native_call('write',handles['native'].write,actual)
            def flush(self):return native_call('flush',handles['native'].flush)
            def fileno(self):return native_call('fileno',handles['native'].fileno)
            def __exit__(self,*args):
                raw=native_call('exit',handles['native'].__exit__,*args)
                if mode=='write_and_exit_fault':raise secondary
                if mode=='normal_exit_false':return False
                if mode=='normal_exit_object':return handles['ignored_object']
                return raw

        def opening(actual_path,*args,**kwargs):
            if actual_path!=path:return original_open(actual_path,*args,**kwargs)
            f=native_call('open',original_open,actual_path,*args,**kwargs)
            handles['native']=f
            info=os.fstat(f.fileno())
            handles['identity']=(info.st_dev,info.st_ino)
            manager=Manager();handles['manager']=manager
            return manager
        def dumping(actual_value,*args,**kwargs):
            return native_call('json',original_dumps,actual_value,*args,**kwargs)
        def syncing(fd):return native_call('fsync',original_fsync,fd)
        handles['ignored_object']=object()
        received=None;result_marker=object();result=result_marker
        with mock.patch.object(Path,'open',opening), mock.patch.object(producer.json,'dumps',dumping), mock.patch.object(producer.os,'fsync',syncing):
            try:result=producer._write_json(path,value)
            except BaseException as error:received=error

        attempt=None
        records=getattr(producer,'_JSON_WRITE_ATTEMPTS',None)
        if type(records) is list:
            found=[r for r in records if getattr(r,'path',None)==path]
            if found:attempt=found[-1]
        rows=[]
        if attempt is not None:
            for row in attempt.steps:
                rows.append(dict(stage=row['stage'],attempted=row['attempted'],returned=row['returned'],
                    raw=view_raw(row['raw']),error_type=None if row['error'] is None else type(row['error']).__name__))
        raw=path.read_bytes() if path.exists() else None
        data=dict(mode=mode,events=events,received_type=None if received is None else type(received).__name__,
            received_original=received is observed.get('primary',primary),received_secondary=received is secondary,
            result_is_None=result is None,source_attempt_present=attempt is not None,
            source_completed=False if attempt is None else attempt.completed,
            native_closed=handles['native'].closed,file_size=None if raw is None else len(raw),
            file_sha256=None if raw is None else hashlib.sha256(raw).hexdigest(),source_rows=rows,
            limits='Python method observations/known native parent writer only; no full backing-FD/delegate census, durability, physical EX, heap RSS or admission')
        (base/'view-before-ROOT-cleanup.json').write_text(original_dumps(data,indent=2)+'\n')
        if raw is not None:(base/'observed-output.bin').write_bytes(raw)
        try:
            if mode.startswith('normal'):
                self.assertIsNone(received)
                self.assertIsNone(result)
                expected=(original_dumps(value,sort_keys=True,ensure_ascii=True)+'\n').encode()
                self.assertEqual(raw,expected)
                self.assertEqual([r['stage'] for r in events],['open','enter','json','write','flush','fileno','fsync','exit'])
                if attempt is not None:self.assertTrue(attempt.completed)
            elif mode=='short3':
                self.assertIsNotNone(received,'short prefix was accepted as complete JSON')
                self.assertEqual([r['stage'] for r in events],['open','enter','json','write'])
            elif mode=='exit_fault':
                self.assertIs(received,primary)
                self.assertEqual([r['stage'] for r in events],['open','enter','json','write','flush','fileno','fsync','exit'])
            else:
                expected_primary=observed.get('primary',primary)
                self.assertIs(received,expected_primary,'automatic exit replaced the first exception')
                failed='json' if mode=='json_error' else ('write' if mode=='write_and_exit_fault' else mode.removesuffix('_fault'))
                stages=['open','enter','json','write','flush','fileno','fsync']
                self.assertEqual([r['stage'] for r in events],stages[:stages.index(failed)+1],
                    'source advanced to another writer operation after the fault')
            if not mode.startswith('normal'):
                self.assertIsNotNone(attempt,'original writer attempt/manager was not retained')
                self.assertIs(attempt.manager,handles['manager'])
                self.assertIs(attempt.writer,handles['manager'])
                self.assertFalse(attempt.completed)
                self.assertIs(attempt.first_error,received)
                count=len(events)
                try:attempt.guard()
                except BaseException as error:self.assertIs(error,received)
                else:self.fail('pure guard accepted a permanently failed writer')
                self.assertEqual(len(events),count,'pure guard performed IO')
        finally:
            # ROOT unit cleanup AFTER raw evidence and assertions, never source recovery.
            f=handles['native'];cleanup=dict(attempted=False,returned=None,identity_match=None)
            if not f.closed:
                try:
                    a=os.fstat(f.fileno());b=path.stat()
                    same=(a.st_dev,a.st_ino)==handles['identity']==(b.st_dev,b.st_ino)
                    cleanup['identity_match']=same
                    if same:
                        cleanup['attempted']=True
                        cleanup['returned']=f.close()
                except BaseException as error:cleanup['error_type']=type(error).__name__
            (base/'ROOT-known-writer-cleanup.json').write_text(original_dumps(cleanup,indent=2)+'\n')

    def test_actual_json_error_has_no_automatic_exit(self):self._writer_case('json_error')
    def test_actual_write_then_fault_has_no_automatic_exit(self):self._writer_case('write_fault')
    def test_actual_write_first_is_not_masked_by_exit_secondary(self):self._writer_case('write_and_exit_fault')
    def test_actual_flush_then_fault_has_no_automatic_exit(self):self._writer_case('flush_fault')
    def test_actual_fsync_then_fault_has_no_automatic_exit(self):self._writer_case('fsync_fault')
    def test_controlled_actual_prefix3_stops_before_flush(self):self._writer_case('short3')
    def test_actual_exit_then_fault_retains_unknown_and_originals(self):self._writer_case('exit_fault')
    def test_normal_full_JSON_bytes_and_operation_order(self):self._writer_case('normal')
    def test_normal_ignored_exit_False_is_preserved(self):self._writer_case('normal_exit_false')
    def test_normal_ignored_exit_object_is_preserved(self):self._writer_case('normal_exit_object')
