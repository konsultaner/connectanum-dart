import sys,pathlib,json,subprocess,hashlib,datetime
sys.path.insert(0,'/Users/konsultaner/.codex/skills/local-model-companions/scripts');import ollama_companion as m
with m.local_resource_lease(exclusive=False) as l:
 l.verify_identity();q=pathlib.Path('/tmp/connectanum-native-perf-json-writer-design-v1/writer-test-planning')
 context=(q/'context.txt').read_bytes()
 argv=[sys.executable,'/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py','tests','--provider','ollama','--stdin','--repo','/Users/konsultaner/.codex/worktrees/flatbuffers-ppt-custom-detail-map/connectanum-dart','--num-predict','1700','--max-input-chars','9000','--max-response-chars','9000','--timeout','180','--save-output',str(q/'answer.txt')]
 (q/'command-before.json').write_text(json.dumps(dict(argv=argv,input_size=len(context),input_sha256=hashlib.sha256(context).hexdigest(),Popen_attempted=True,pid=None)))
 inp=(q/'context.txt').open('rb');child=subprocess.Popen(argv,stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (q/'start.json').write_text(json.dumps(dict(pid=child.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())))
 out,err=child.communicate();status=child.wait();inp.close();(q/'stdout.bin').write_bytes(out);(q/'stderr.bin').write_bytes(err)
 result=dict(pid=child.pid,status=status,stdout_size=len(out),stderr_size=len(err),both_EOF=True,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());(q/'result.json').write_text(json.dumps(result,indent=2))
 l.verify_identity();print(json.dumps(result));print(out.decode(errors='replace'));print(err.decode(errors='replace')[-400:])
