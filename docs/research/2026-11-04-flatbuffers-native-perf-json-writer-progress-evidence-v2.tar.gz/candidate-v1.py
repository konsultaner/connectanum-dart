# Retained IO observations only. These records grant no ownership or admission.
_JSON_WRITE_ATTEMPTS = []


class _JSONWriteAttempt:
    def __init__(self,path,value):
        self.original_path=path
        self.value=value
        self.path=None
        self.manager=None
        self.writer=None
        self.payload=None
        self.steps=[]
        self.completed=False
        self.first_error=None
        self.secondary_errors=[]
        first=[None]
        secondary=self.secondary_errors

        def guard():
            if first[0] is not None:raise first[0]

        def fail(error,row=None):
            if first[0] is None:first[0]=error # Bind BEFORE any error metadata.
            primary=first[0]
            try:
                self.first_error=primary
                if row is not None:row['error']=primary
            except BaseException as metadata_error:
                secondary.append(metadata_error)
            finally:
                raise primary

        self.guard=guard
        self._fail=fail

    def _step(self,stage,lookup,args=(),kwargs=None):
        self.guard()
        row=dict(stage=stage,attempted=True,lookup=lookup,args=args,kwargs=kwargs,
            method=None,returned=False,raw=None,error=None)
        self.steps.append(row) # Intent precedes lookup, not just the call.
        try:
            method=lookup()
            row['method']=method
            returned=method(*args,**({} if kwargs is None else kwargs))
            row['raw']=returned # Raw return precedes checks and the next operation.
            row['returned']=True
            return returned
        except BaseException as error:
            self._fail(error,row)

    def run(self):
        call=self._step
        fail=self._fail
        try:
            path=call('path',lambda:Path,(self.original_path,))
            self.path=path
            # Literal native Path namespace, process lifetime only; no alias,
            # cross-process, kernel identity or persistent admission inference.
            for previous in _JSON_WRITE_ATTEMPTS:
                if previous is self:break
                if previous.path is None or previous.path==path:
                    previous.guard()
                    raise FileExistsError('JSON output namespace was already attempted')
            manager=call('open',lambda:path.open,('xb',))
            self.manager=manager
            # Match normal with special-method lookup before entering. Do not
            # call exit on an unknown/invalid body or enter result.
            enter=call('enter_lookup',lambda:lambda:type(manager).__enter__)
            exit_method=call('exit_lookup',lambda:lambda:type(manager).__exit__)
            writer=call('enter',lambda:enter,(manager,))
            self.writer=writer
            rendered=call('json',lambda:json.dumps,(self.value,),
                dict(sort_keys=True,ensure_ascii=True))
            if type(rendered) is not str:raise ProducerError('unknown JSON text return')
            payload=call('encode',lambda:lambda:(rendered+'\n').encode())
            self.payload=payload
            count=call('write',lambda:writer.write,(payload,))
            if type(count) is not int or count!=len(payload):
                raise ProducerError('incomplete JSON write return')
            flushed=call('flush',lambda:writer.flush)
            if flushed is not None:raise ProducerError('unknown JSON flush return')
            fd=call('fileno',lambda:writer.fileno)
            if type(fd) is not int or fd<0:raise ProducerError('unknown JSON fileno return')
            synced=call('fsync',lambda:os.fsync,(fd,))
            if synced is not None:raise ProducerError('unknown JSON fsync return')
            call('exit',lambda:exit_method,(manager,None,None,None))
            # Normal exit return was always ignored, including False/objects.
            self.completed=True
        except BaseException as error:
            fail(error,self.steps[-1] if self.steps else None)


def _write_json(path,value):
    attempt=_JSONWriteAttempt(path,value)
    _JSON_WRITE_ATTEMPTS.append(attempt) # Retain BEFORE path conversion/open.
    attempt.run()
