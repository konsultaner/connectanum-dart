import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)

import subprocess,datetime,tarfile,io,gzip,stat,time,contextlib
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-great-grandchild-entry-source-alias-intake-v1';R=P;S=P/'FIRST-summary-v1';Q=P/'publication-v1';D=pathlib.Path('/Users/konsultaner/.codex/worktrees/flatbuffers-perf-fix/connectanum-dart');v=json.loads(sys.argv[1])
@contextlib.contextmanager
def first_body():
 for attempt in range(1,37):
  cm=m.local_resource_lease(exclusive=True)
  try:lease=cm.__enter__()
  except m.LocalResourceLeaseError as e:
   print(json.dumps({'official_EX_pretarget_refusal':attempt,'body_entered':False,'error':str(e)}),flush=True)
   if attempt==36:raise
   time.sleep(10);continue
  try:yield lease,attempt-1
  except BaseException:
   if not cm.__exit__(*sys.exc_info()):raise
  else:cm.__exit__(None,None,None)
  return
with first_body() as (lease,refusals):
 lease.verify_identity();Q.mkdir()
 def save(n,b):
  with (Q/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 save('declaration.json',json.dumps(v['publication_declaration'],indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context.json',json.dumps(v['actual_returns'],ensure_ascii=True,indent=2))
 children=[]
 def native(label,args):
  save(label+'-request.json',json.dumps({'argv':args,'cwd':str(D)},indent=2));p=subprocess.Popen(args,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE);children.append(p);save(label+'-creator.json',json.dumps({'pid':p.pid,'strong_original_handle_retained_before_IO':True},indent=2))
  o,e=p.communicate();status=p.wait();save(label+'.stdout',o);save(label+'.stderr',e);save(label+'-completion.json',json.dumps({'pid':p.pid,'signed_status':status,'same_original_wait':True,'wait_may_be_cached':True,'stdout_eof':True,'stderr_eof':True,'stdout_bytes':len(o),'stderr_bytes':len(e),'stdout_sha256':hashlib.sha256(o).hexdigest(),'stderr_sha256':hashlib.sha256(e).hexdigest()},indent=2));assert status==0;return o




 assert native('branch',['git','branch','--show-current']).decode().strip()=='codex/flatbuffers-acceptance-status'
 assert native('head',['git','rev-parse','HEAD']).decode().strip()=='fc4f6b00fd4ee99354e665be1656e964d2fc8462'
 assert native('clean-before',['git','status','--porcelain=v1','--untracked-files=all'])==b''
 bindings=[]
 def read(path,size,sha,role):
  b={'role':role,'path':str(path),'range':[0,size],'expected_sha256':sha,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(b);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);b['open_return_fd']=fd;primary=None;raw=None
  try:
   a=os.fstat(fd)
   if size is None:
    size=a.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'sha256_before_first_read':None},indent=2));b['range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];b['before']={k:getattr(a,k) for k in keys};b['before_atime_ns_POINT_ONLY']=a.st_atime_ns;assert stat.S_ISREG(a.st_mode) and a.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    block=os.read(fd,min(65536,size-count));assert block,'earlyrangeend/FOREVERquarantine';parts.append(block);count+=len(block);h.update(block)
   z=os.fstat(fd);b.update(after={k:getattr(z,k) for k in keys},after_atime_ns_POINT_ONLY=z.st_atime_ns,bytes=count,sha256=h.hexdigest());assert b['before']==b['after'] and count==size and (sha is None or h.hexdigest()==sha);raw=b''.join(parts)
  except BaseException as e:primary=e;b['primary_error']={'kind':type(e).__name__,'text':str(e)}
  try:os.close(fd);b['close_return_fd']=fd
  except BaseException as e:
   b['close_error_unknown']={'kind':type(e).__name__,'text':str(e)}
   if primary is None:primary=e
  save(role+'-binding-PRIVATE.json',json.dumps(b,indent=2))
  if primary is not None:raise primary
  return raw
 descriptor=json.loads(v['exact_original_descriptor_JSON']);save('exact-new-result-range-BEFORE-IO.json',json.dumps({'path':str(P/descriptor['result_saved']),'range':[0,descriptor['result_bytes']],'sha256':descriptor['result_sha256'],'all_original_fields_gates_before_projection':True},indent=2));raw=read(P/descriptor['result_saved'],descriptor['result_bytes'],descriptor['result_sha256'],'new2308_original_intake_result');save('original-saved-result-bound-PRIVATE.json',raw);bound=read(Q/'original-saved-result-bound-PRIVATE.json',len(raw),hashlib.sha256(raw).hexdigest(),'independent_whole_new2308_result_copy');assert raw==bound and raw.decode()==bound.decode();result=json.loads(raw);assert result==json.loads(bound);summary=result['summary'];assert summary==descriptor['summary']

 assert summary['ALL2308_original_new_child_records']==2308 and summary['ALL199_original_parent_queries_preserved']==199 and summary['type_counts_from_original_modes']=={'regular':2279,'directory':29,'symlink':0,'other':0,'unknown':0} and summary['saved_metadata_read_binding_count']==4
 assert summary['prior_CP_top_level_node_count']==v['expected_summary']['prior_CP_top_level_node_count'] and summary['prior_CP_string_scalar_count']==v['expected_summary']['prior_CP_string_scalar_count'] and summary==v['expected_summary']
 assert summary['symlink_literal_candidates_with_prior_CP_matches']==summary['symlink_rawhex_candidates_with_prior_CP_matches']==0 and summary['link_comparisons_performed']==0 and summary['link_comparisons_UNPERFORMED_NULL']==2308 and summary['ALL2308_nonlink_comparison_count_fields_UNPERFORMED_NULL'] is True

 for key in ['new_SDK_queries','new_Actions_queries','new_headerbody_reads','new_recursive_queries','candidate_executions']:assert summary[key]==0
 assert summary['all_admission_flags'] is False and summary['ownership'] is None and summary['separate_outer_launcher_PID_pipe_EOF'] is None
 rows=result['ALL2308_original_child_relationships_with_NEW_counts'];assert len(rows)==2308 and len(result['ALL_original_NEW_symlink_metadata_UNEXPANDED_UNFOLLOWED'])==0 and len(result['ALL199_original_parent_query_records_PRIVATE_preserved'])==199 and len(result['ALL_four_savedmetadata_read_bindings_PRIVATE_fullstat-times'])==4
 safe=[]
 for row in rows:
  metadata=row['original_separate_parent_child_metadata'];s=metadata['original_separate_lstat_full_stat_times_PRIVATE'];public={k:value for k,value in metadata.items() if k not in ['original_separate_lstat_full_stat_times_PRIVATE','original_full_child_record_PRIVATE','original_parent_query_record_except_children_PRIVATE']}
  public['EXPLICITLY_DERIVED_original_mode_UIDGID_nlink_size_only']={k:s[k] for k in ['st_mode','st_uid','st_gid','st_nlink','st_size']} if s is not None else None
  counts={k:value for k,value in row.items() if k!='original_separate_parent_child_metadata' and not k.endswith('_PRIVATE')};counts['original_separate_parent_child_metadata']=public;safe.append(counts)
 assert len(safe)==2308
 links=[r for r in safe if r['link_comparison_performed']];assert len(links)==0 and sum(r['prior_CP_name_scalar_match_count']>0 for r in safe)==summary['record_name_candidates_with_prior_CP_scalar_matches'] and sum(r['prior_CP_namehex_scalar_match_count']>0 for r in safe)==summary['record_namehex_candidates_with_prior_CP_scalar_matches'] and all(r['prior_CP_link_literal_scalar_match_count'] is None and r['prior_CP_link_rawhex_scalar_match_count'] is None for r in safe)

 model=json.loads(read(S/'completion.json',None,None,'new_summary_completion'));assert model==v['exact_model_completion'] and model['signed_status']==0 and model['stdout_eof'] and model['stderr_eof']
 save('ALL-publication-bindings-PRIVATE.json',json.dumps(bindings,indent=2));selected=[];derived=Q/'derived';derived.mkdir()
 def original(name,path):
  assert stat.S_ISREG(path.lstat().st_mode);selected.append({'name':name,'data':path.read_bytes(),'path':path})
 def deriv(name,obj):
  data=(json.dumps(obj,ensure_ascii=True,indent=2)+'\n').encode();path=derived/name
  with path.open('xb') as f:f.write(data)
  selected.append({'name':'derived/'+name,'data':data,'path':path})

 for name,path in [('intake-declaration.json',P/'declaration.json'),('intake-controller.py',P/'controller.py'),('summary-selection.json',S/'NEW2308-entry-intake-summary-selection.json'),('prior-CP-exact-range-BEFORE-content-IO.json',P/'prior_CP_metadata-exact-range-BEFORE-content-IO.json'),('located-report-source-range-BEFORE-content-IO.json',P/'located-report-exact-source-range-BEFORE-content-IO.json'),('original-index-pointFD-range-BEFORE-content-IO.json',P/'original_index-exact-range-BEFORE-content-IO.json'),('intake-original-result-descriptor.json',P/'FIRST-original-result-descriptor.json'),('summary-declaration.json',S/'declaration.json'),('summary-controller.py',S/'controller.py'),('summary-request.json',S/'request.json'),('summary-completion.json',S/'completion.json')]:original(name,path)
 deriv('ALL2308-source-entry-metadata-with-counts.json',{'interpretation':'EXPLICITLY_DERIVED ALL2308savedparent-child metadata andNEWpriorCPrelationshipcounts; fulloriginalstat-times/CPscalars-locations-offsets/privatefullrecords excludedONLYfrompublicprojection, originalallfields-gatesPRIVATEunchanged/no alias-newness-absence-querypermission inference','summary':summary,'ALL2308':safe})
 deriv('ALL2308-UNPERFORMED-link-comparison-metadata.json',{'interpretation':'EXPLICITLY_DERIVED 0NEWsymlinkeligible candidates THISdataset/ALL2308nonlinkcomparison-countsNULL not0; earlier6and18rawlinks UNEXPANDED-UNFOLLOWED unchanged/oldtopncursesrawhexNULLneverretrofilled','new_symlink_candidates':links,'ALL2308_UNPERFORMED_link_comparisons':[{'original_record_position_ONE_based':r['new_saved_record_position_ONE_based'],'comparison_performed':r['link_comparison_performed'],'literal_match_count':r['prior_CP_link_literal_scalar_match_count'],'rawhex_match_count':r['prior_CP_link_rawhex_scalar_match_count']} for r in safe]})
 root={'interpretation':'EXPLICITLY_DERIVED_ROOT_advisory_raw_and_admission_limits','ROOT_qualification':v['ROOT_qualification'],'model_completion':model,'original_saved_result_bytes':len(raw),'original_saved_result_sha256':hashlib.sha256(raw).hexdigest(),'whole_original_raw_JSONSTRING_Python_ALLfield_equality':True,'all_original_gates_preserved':True,'separate_outer_launcher_PID_pipe_EOF':None,'all_admission_flags':False,'ownership':None};deriv('ROOT-model-and-admission-limits.json',root);assert len(selected)==14
 buf=io.BytesIO()
 with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for row in selected:
    assert row['path'].read_bytes()==row['data'];info=tarfile.TarInfo(row['name']);info.size=len(row['data']);info.mode=0o644;info.uid=info.gid=info.mtime=0;tar.addfile(info,io.BytesIO(row['data']))
 archive=buf.getvalue();save('selected-evidence.tar.gz',archive)
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  members=tar.getmembers();assert len(members)==14 and all(x.isfile() for x in members) and [x.name for x in members]==[x['name'] for x in selected]
  for member,row in zip(members,selected):assert tar.extractfile(member).read()==row['data']
 ar={'selected_regular_members':14,'original_declaration_controller_completion_descriptor_files':11,'explicitly_derived_metadata_files':3,'all_selected_members_byteexact':True,'archive_bytes':len(archive),'archive_sha256':hashlib.sha256(archive).hexdigest(),'not_full_raw_directory_Source20_or_runtime_package':True,'members':[{'name':x['name'],'bytes':len(x['data']),'sha256':hashlib.sha256(x['data']).hexdigest()} for x in selected]};save('selected-archive-verification.json',json.dumps(ar,indent=2))

 assessment={**summary,'ALL2308_safe_prior_reference_relationships':safe,'NEW_safe_link_metadata_THISdataset':links,'ROOT_qualification':root,'archive':ar,'full_raw_PRIVATE':True,'next':v['next'],'RAM_repair_original_immutable_admission_FINAL_strict48_50_clean_final_CI':'INCOMPLETE'};save('public-assessment.json',json.dumps(assessment,ensure_ascii=True,indent=2)+'\n')
 def fill(s):return s.replace('ARCHIVE_BYTES_TOKEN',str(len(archive))).replace('ARCHIVE_SHA_TOKEN',ar['archive_sha256'])
 slug='2026-11-07-flatbuffers-include-great-great-grandchild-entry-source-alias-intake';note=fill(v['note']);save('public-note.md',note)
 paths=['docs/research/'+slug+'.md','docs/research/'+slug+'-assessment.json','docs/research/'+slug+'-evidence.tar.gz','docs/project_state.md','docs/exec-plans/2026-10-03-flatbuffers-zero-copy-native-buffers.md']
 for rel,data in [(paths[0],note.encode()),(paths[1],(Q/'public-assessment.json').read_bytes()),(paths[2],archive)]:
  with (D/rel).open('xb') as f:f.write(data)
 for rel,link in [(paths[3],'research/'+slug+'.md'),(paths[4],'../research/'+slug+'.md')]:
  target=D/rel;before=target.read_bytes();save('before-'+target.name,before);pos=before.index(b'\n')+1;added=fill(v['state_addition']).replace('EVIDENCE_LINK_TOKEN',link).encode();after=before[:pos]+added+before[pos:];assert after[:pos]==before[:pos] and after[pos+len(added):]==before[pos:];target.write_bytes(after)
 native('diff-check',['git','diff','--check']);native('stage',['git','add','--']+paths);staged=native('staged-exact-five',['git','diff','--cached','--name-only','-z']).decode().split('\0');assert sorted(x for x in staged if x)==sorted(paths)
 native('commit',['git','commit','-m','Record all2308 include great-great-grandchild source relationships [skip ci]']);commit=native('new-head',['git','rev-parse','HEAD']).decode().strip();native('push-github',['git','push','github','HEAD:refs/heads/codex/flatbuffers-acceptance-status']);assert native('clean-after',['git','status','--porcelain=v1','--untracked-files=all'])==b''
 receipt={'docs_commit':commit,'only_five_documentation_paths':paths,**ar,'docs_clean_after':True,'new_Actions_execution':False,'new_directory_INPUT_queries':0,'publication_pretarget_EX_refusals':refusals,'whole_original_raw_JSONSTRING_Python_ALLfield_equality_gates_preserved':True,'original_saved_result_bytes':len(raw),'original_saved_result_sha256':hashlib.sha256(raw).hexdigest(),'all_admission_flags':False};save('publication-receipt.json',json.dumps(receipt,indent=2))
 cp=B/'current-task-checkpoint.json';cpraw=cp.read_bytes();save('checkpoint-before-publication.json',cpraw);d=json.loads(cpraw);node=d['actions_include_great_great_grandchild_entry_source_alias_intake_v1'];node.update(phase='COMPLETE_CONSUMED_FIRST_ALL2308_saved_entry_source_alias_relationships_public_docs_NOT_admitted',model_summary_pending=False,public_documentation_pending=False,docs_commit=commit,public_archive_sha256=ar['archive_sha256'],public_archive_bytes=len(archive),public_selected_regular_members=14,publication_receipt=str(Q/'publication-receipt.json'),model_completion=model,ROOT_model_qualification=v['ROOT_qualification'],all_component_work_consumed=True,all_admission_flags=False,next=v['next'])
 d['docs_commit']=commit;d['status_docs_commit']=commit;d['active_turn_status'].update(new_include_great_great_grandchild_entry_source_alias_intake='COMPLETE_CONSUMED_public_docs_published_NOT_queried',latest_docs_commit=commit,next=v['next'],all_admission_flags=False)
 d['native_perf_only_diagnostic_design'].update(phase='ALL2308_saved_entry_source_alias_relationships_complete_NOT_admitted',next=v['next'],provider='Original_GitHub_Actions_route_selected_NOT_runtime_admitted',controller='CLOSED',ownership=None,capture_ready=False,evidence_complete=False,source_admitted=False,live_admission=False)
 d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt),flush=True);lease.verify_identity()
