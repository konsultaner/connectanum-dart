import pathlib,sys,json,hashlib,importlib.util
H=pathlib.Path('/Users/konsultaner/.codex/skills/local-model-companions/scripts/ollama_companion.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='d9dab4fa22040d987a25239e0d767683a4647d9b4ecee25d46379979d73b15a8'
sp=importlib.util.spec_from_file_location('pr132_0738_startup_SH',H);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)





import os,stat,datetime,collections
B=pathlib.Path('/Users/konsultaner/.codex/task-evidence/connectanum-pr132');P=B/'2026-11-07-actions-include-great-grandchild-physical-text-v1';A=B/'2026-11-07-actions-include-great-grandchild-regular-inputs-v1/FIRST-originalActions-v1';F=B/'2026-11-07-actions-include-great-grandchild-regular-inputs-v1/FIRST-remaining-saved4868-verification-v1';v=json.loads(sys.argv[1])
with m.local_resource_lease(exclusive=False) as lease:
 lease.verify_identity();P.mkdir()
 def save(n,b):
  with (P/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
 declaration={'scope':'FIRST saved-data physical-text intake forALL4868 NEWoriginalActions regularBODYstreams84566663B/run42392808246/source46d477775e6e6e5dded97373db2d82bc1e1b32e7. Threeexactsavedmetadata source ranges/SHA declaredBEFOREIO; report/index ONLYlocateoriginalsavedrecords/memberranges, newremainingresultoriginalfullfields/stat-times retainedPRIVATE. EACHsavedbody literalSDKsource refkeptunaltered andlocalartifactmemberlocator/byte-range/SHA declaredBEFOREANYbodycontentIO. All4868physicalLF-segments/SP-TAB-leading#-ASCIIword/include-delimiter-physicaloperand/backslashLF-CRLF/NUL/UTF8 byte-character-offset metadata FIRSTONLY. No SDKquery/bodyreader-parser-oldscope-replay/streamjournalcomparison-Actions-acquisition-model-review-archive-numerical replay; no linejoin-commentstrip/preprocessor/compiler/include-target resolution/eval/import-execute-headercompile/defaultcompiler-ABI inference. Everyorder-duplicate-rawrow/fulloriginalfields-stat-times preserved/no favorablelanguage-version-ABI-defaultcompilerfilter-aliasdedup. Everyoperand comparisonUNPERFORMED-count-matchlistsNULL not0; CsemanticsUNEVALUATED. Original5067metadata190queryepochs199DEFERRED0NEWlinks THISdataset/new4868physicalread epoch separate vsprior1425-63-1229laterbody-original190DEFERRED6earlierlinks/prior1280-49-1199-old63DEFERRED18olderlinks-oldtopncurses.h literalcurses.h originalrawreadlinkhexNOTsavedNULL/ALLledgers unchanged. Original48static10UNMEASUREDpreproof immutable/newactualfacts separate. OriginalActionscontrollerownershipKeyErrornamespaceFOREVERterminal/oldfinalresultUNSAVEDNULL/newremainingproofcompletedONCE notoldreconstruction/no sourcefieldrestore-schema-gatewaiver. SameFDregularO_NOFOLLOW-boundedcountSHA-stat-close/no fileEOFprobe-outofrange-read/notatomicABA-origin-pathchain-globalactorFD-originaldrivercredentials-access-effectivecompilerABI-continuousofficialphysicalEX-crash admission/separateouterPID-EOFNULL/unknownpartialcrashpermanentquarantine. AllsetupUNADMITTED/flagsFALSE/ownershipNone/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE/noSource20-runtime adoption-build-cleanup.','saved_metadata_inputs':[{'role':'original_saved_remaining_result','path':str(F/'ROOT-NEW-ALL4868-regular-great-grandchild-input-assessment-PRIVATE.json'),'range':[0,63401479],'sha256':'a49f18de7e725caedeebcae268c14669346acb1ea4de23f151f61c5d389854f0'},{'role':'original_saved_report_ONLYlocator','path':str(A/'artifact-members/include-great-grandchild-regular-inputs.json'),'range':[0,41140608],'sha256':'2b512886a4c6da1e1015e2b9889cece9b8a27a5a5def0a25d886db8ec00e71c9'},{'role':'original_saved_index_ONLYlocator','path':str(A/'actual-new-artifact-member-index.json'),'range':[0,677666],'sha256':'f8f084f9caaab3a8f06ca93c77c9809abee1869ba7e0d2a516f24968c95d1737'}],'lexical_definition':'Physical segments splitONLYatLF andincludeLF; nonemptyunterminatedtail countsone. Leading skipONLYSP-TAB; #thenONLYSP-TAB thenASCII[A-Za-z_][A-Za-z0-9_]*word. Include/include_next physicaloperand startsafterONLYSP-TAB; firstliteralclosing quote-or-angle delimiter onSAMEphysicalsegment, NOescape-comment-line-splice/preprocessor semantics. Rawrows/positions retained; invalidUTF8 text/charoffsetsNULL withrawhex anderror retained.','all_admission_flags':False,'ownership':None}
 save('execution-declaration.json',json.dumps(declaration,indent=2));save('controller.py',sys.argv[2]);save('actual-new-root-context-PRIVATE.json',json.dumps(v,ensure_ascii=True,indent=2));bindings=[]
 def read_bounded(path,size,expected,role):
  binding={'role':role,'path':str(path),'declared_range':[0,size],'expected_original_sha256':expected,'open_return_fd':None,'close_return_fd':None,'file_EOF_probe':None};bindings.append(binding);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);binding['open_return_fd']=fd;primary=None;raw=None
  try:
   before=os.fstat(fd)
   if size is None:
    size=before.st_size;save(role+'-range-BEFORE-content-IO.json',json.dumps({'path':str(path),'range':[0,size],'same_open_FD':fd,'role':role,'no_prior_hash_reconstructed_or_revalidated':True},indent=2));binding['declared_range']=[0,size]
   keys=['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'];binding['before']={k:getattr(before,k) for k in keys};binding['before_atime_ns_POINT_ONLY']=before.st_atime_ns;assert stat.S_ISREG(before.st_mode) and before.st_size==size;parts=[];count=0;h=hashlib.sha256()
   while count<size:
    chunk=os.read(fd,min(65536,size-count));assert chunk,'earlyrangeend/permanentquarantine';parts.append(chunk);h.update(chunk);count+=len(chunk)
   after=os.fstat(fd);binding.update(after={k:getattr(after,k) for k in keys},after_atime_ns_POINT_ONLY=after.st_atime_ns,bytes=count,sha256=h.hexdigest());assert binding['before']==binding['after'] and count==size and (expected is None or h.hexdigest()==expected);raw=b''.join(parts)
  except BaseException as error:
   primary=error;binding['primary_error']={'kind':type(error).__name__,'text':str(error)}
  try:os.close(fd);binding['close_return_fd']=fd
  except BaseException as error:
   binding['close_error_unknown']={'kind':type(error).__name__,'text':str(error)}
   if primary is None:primary=error
  if primary is not None:raise primary
  return raw



 raws={}
 for source in declaration['saved_metadata_inputs']:
  raw=read_bounded(pathlib.Path(source['path']),source['range'][1],source['sha256'],source['role']);raws[source['role']]=raw;save(source['role']+'-bound-PRIVATE.json',raw)
 original=json.loads(raws['original_saved_remaining_result']);report=json.loads(raws['original_saved_report_ONLYlocator']);index=json.loads(raws['original_saved_index_ONLYlocator'])
 rows=report['observations'];manifest=[]
 for ordinal,row in enumerate(rows):
  if 'absent_at_open_only' in row:raise RuntimeError('unexpected absent saved-row vsdeclaredALL4868 scope/no body IO yet')
  matches=[entry for entry in index if entry['name']==row['saved_member'] or entry['name'].endswith('/'+row['saved_member'])];assert len(matches)==1
  entry=matches[0];assert entry['bytes']==row['bytes'] and entry['sha256']==row['sha256']
  manifest.append({'ordinal':ordinal,'original_literal_source_reference_UNALTERED':row['source_reference'],'original_saved_member_literal':row['saved_member'],'original_index_member_literal':entry['name'],'local_saved_artifact_path_ONLYlocator':str(A/'artifact-members'/entry['name']),'range':[0,row['bytes']],'sha256':row['sha256'],'all_original_report_observation_fields_PRIVATE':row})
 assert len(manifest)==4868 and sum(row['range'][1] for row in manifest)==84566663
 save('ALL4868-local-saved-body-ranges-BEFORE-ANY-body-IO-PRIVATE.json',json.dumps(manifest,ensure_ascii=True,indent=2))
 files=[];totals=collections.Counter();words=collections.Counter();operands=collections.Counter();invalids=[];tails=[];allops=[]
 def positions(raw,needle):
  result=[];start=0
  while True:
   x=raw.find(needle,start)
   if x<0:return result
   result.append(x);start=x+1
 def alpha(c):return 65<=c<=90 or 97<=c<=122 or c==95
 def alnum(c):return alpha(c) or 48<=c<=57
 for row in manifest:
  ordinal=row['ordinal'];raw=read_bounded(pathlib.Path(row['local_saved_artifact_path_ONLYlocator']),row['range'][1],row['sha256'],'FIRST_NEW4868_saved_body_physical_'+str(ordinal))
  try:
   text0=raw.decode('utf-8');utf8=True;utf8error=None
  except UnicodeDecodeError as e:
   utf8=False;text0=None;utf8error={'kind':type(e).__name__,'start':e.start,'end':e.end,'reason':e.reason};invalids.append(ordinal)
  lf=raw.count(b'\n');nul=positions(raw,b'\0');slashlf=positions(raw,b'\\\n');slashcrlf=positions(raw,b'\\\r\n');tail=bool(raw and not raw.endswith(b'\n'))
  if tail:tails.append(ordinal)
  directives=[];ops=[];start=0;line_no=0;charbase=0
  while start<len(raw):
   at=raw.find(b'\n',start);end=len(raw) if at<0 else at+1;line=raw[start:end];content_end=len(line)-(1 if line.endswith(b'\n') else 0);decoded=line.decode('utf-8') if utf8 else None
   i=0
   while i<content_end and line[i] in (32,9):i+=1
   if i<content_end and line[i]==35:
    hashpos=i;i+=1
    while i<content_end and line[i] in (32,9):i+=1
    word_start=i
    if i<content_end and alpha(line[i]):
     i+=1
     while i<content_end and alnum(line[i]):i+=1
    word_end=i;word=line[word_start:word_end].decode('ascii') if word_end>word_start else None
    def charoffset(relative):
     return charbase+len(line[:relative].decode('utf-8')) if utf8 else None
    record={'directive_row_ordinal':len(directives),'physical_segment_ordinal_zero':line_no,'file_byte_range':[start,end],'file_character_range_UTF8':[charbase,charbase+len(decoded)] if utf8 else None,'LF_terminated':line.endswith(b'\n'),'raw_line_bytes_hex':line.hex(),'raw_line_UTF8':decoded,'leading_SP_TAB_bytes_hex':line[:hashpos].hex(),'hash_file_byte_offset':start+hashpos,'hash_file_character_offset_UTF8':charoffset(hashpos),'ASCII_directive_word':word,'directive_word_bytes_hex':line[word_start:word_end].hex(),'directive_word_file_byte_range':[start+word_start,start+word_end],'directive_word_file_character_range_UTF8':[charoffset(word_start),charoffset(word_end)] if utf8 else None,'after_directive_word_physical_bytes_hex':line[word_end:content_end].hex()}
    directives.append(record);words[word if word is not None else 'NO_ASCII_WORD_UNMEASURED']+=1
    if word in ('include','include_next'):
     j=word_end
     while j<content_end and line[j] in (32,9):j+=1
     opening=line[j:j+1];closing=b'>' if opening==b'<' else b'"' if opening==b'"' else None;k=line.find(closing,j+1,content_end) if closing is not None else -1
     kind='angle_delimited_literal' if opening==b'<' and k>=0 else 'quote_delimited_literal' if opening==b'"' and k>=0 else 'unterminated_delimiter_UNPERFORMED' if closing is not None else 'macro_or_other_UNDELIMITED_UNPERFORMED'
     literal=line[j+1:k] if closing is not None and k>=0 else None
     try:literaltext=literal.decode('utf-8') if literal is not None else None
     except UnicodeDecodeError:literaltext=None
     operand={'file_ordinal':ordinal,'directive_row_ordinal':record['directive_row_ordinal'],'physical_segment_ordinal_zero':line_no,'directive_word':word,'physical_operand_kind':kind,'physical_tail_bytes_hex':line[j:content_end].hex(),'physical_tail_UTF8':line[j:content_end].decode('utf-8') if utf8 else None,'physical_tail_file_byte_range':[start+j,start+content_end],'physical_tail_file_character_range_UTF8':[charoffset(j),charoffset(content_end)] if utf8 else None,'literal_operand_bytes_hex':literal.hex() if literal is not None else None,'literal_operand_UTF8':literaltext,'literal_operand_file_byte_range':[start+j+1,start+k] if literal is not None else None,'literal_operand_file_character_range_UTF8':[charoffset(j+1),charoffset(k)] if literal is not None and utf8 else None,'opening_delimiter_byte':opening[0] if closing is not None else None,'closing_delimiter_byte':closing[0] if literal is not None else None,'comparison_performed':False,'comparison_match_count_UNPERFORMED':None,'comparison_matches_UNPERFORMED':None,'comparison_nonmatches_UNPERFORMED':None,'include_target_resolution_UNPERFORMED':None,'C_preprocessor_semantics_UNEVALUATED':None}
     ops.append(operand);allops.append(operand);operands[kind]+=1
   if utf8:charbase+=len(decoded)
   line_no+=1;start=end
  assert line_no==lf+int(tail) and (not utf8 or charbase==len(text0))
  files.append({'ordinal':ordinal,'original_literal_source_reference_UNALTERED':row['original_literal_source_reference_UNALTERED'],'original_saved_member_literal':row['original_saved_member_literal'],'original_index_member_literal':row['original_index_member_literal'],'original_source_observation_ALLfields_PRIVATE':row['all_original_report_observation_fields_PRIVATE'],'new_saved_body_binding_index':len(bindings)-1,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'LF_bytes':lf,'physical_segments':line_no,'nonempty_unterminated_tail_PRESENT':tail,'UTF8_strict':utf8,'UTF8_decode_error_UNMEASURED_if_valid':utf8error,'UTF8_character_count':len(text0) if utf8 else None,'NUL_file_byte_positions':nul,'backslash_LF_file_byte_positions':slashlf,'backslash_CRLF_file_byte_positions':slashcrlf,'ALL_SP_TAB_leading_hash_raw_physical_rows':directives,'ALL_include_include_next_physical_operands':ops,'C_preprocessor_semantics_UNEVALUATED':None})
  totals.update(files=1,bytes=len(raw),LF_bytes=lf,physical_segments=line_no,nonempty_unterminated_tail_files=int(tail),strict_UTF8_files=int(utf8),invalid_UTF8_files=int(not utf8),NUL_bytes=len(nul),backslash_LF=len(slashlf),backslash_CRLF=len(slashcrlf),SP_TAB_leading_hash_rows=len(directives),include_include_next_operands=len(ops))
 assert totals['files']==4868 and totals['bytes']==84566663 and len(bindings)==4871 and sum(operands.values())==len(allops)==totals['include_include_next_operands']
 summary={'source_commit':'46d477775e6e6e5dded97373db2d82bc1e1b32e7','run_id':42392808246,'job_id':128463761879,'totals':dict(totals),'ALL_directive_word_counts':dict(words),'ALL_physical_operand_kind_counts':dict(operands),'invalid_UTF8_file_ordinals':invalids,'nonempty_unterminated_tail_file_ordinals':tails,'saved_metadata_bindings':3,'saved_body_bindings':4868,'all_bindings':len(bindings),'new_SDK_queries':0,'new_Actions_queries':0,'new_directory_queries':0,'candidate_executions':0,'preprocessor_compiler_include_target_resolution_UNPERFORMED':None,'all_operand_comparison_counts_lists_UNPERFORMED_NULL':True,'all_original_private_fields_stat_times_relationships_preserved':True,'all_admission_flags':False,'ownership':None,'separate_outer_PID_pipe_EOF':None}
 result={'summary':summary,'execution_declaration':declaration,'ALL_saved_metadata_and_body_read_bindings_PRIVATE':bindings,'ALL4868_physical_file_records_PRIVATE':files,'ALL_include_operand_rows_PRIVATE':allops,'ALL_original_report_fields_PRIVATE_UNCHANGED':report,'ALL_original_remaining_result_fields_PRIVATE_UNCHANGED':original,'ALL_original_index_metadata_UNCHANGED':index,'qualification':'FIRSTphysicalbytes-only lexicalmetadata/fullrawrows-order-duplicates-offsets retainedPRIVATE/no oldparser-replay/no Csemantics-query-execution-admission/alloriginalfields-gates unchanged; newlocalread epoch separatefromoriginalActionsphysicalepoch andmetadataepochs; no Source20-runtime adoption-build-cleanup.'}
 rawresult=(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode();save('ROOT-FIRST-ALL4868-great-grandchild-physical-text-PRIVATE.json',rawresult);save('FIRST-ALL4868-physical-text-summary.json',json.dumps(summary,indent=2))
 descriptor={'original_saved_result_name':'ROOT-FIRST-ALL4868-great-grandchild-physical-text-PRIVATE.json','original_saved_result_bytes':len(rawresult),'original_saved_result_sha256':hashlib.sha256(rawresult).hexdigest(),'summary':summary}
 save('original-saved-result-descriptor.json',json.dumps(descriptor,indent=2))
 cp=B/'current-task-checkpoint.json';before=cp.read_bytes();save('checkpoint-before-physical-result.json',before);d=json.loads(before);d['actions_include_great_grandchild_physical_text_v1']={'phase':'COMPLETE_CONSUMED_FIRST_ALL4868_saved_physical_text_NOT_admitted','directory':str(P),'original_saved_result':str(P/descriptor['original_saved_result_name']),'original_saved_result_bytes':len(rawresult),'original_saved_result_sha256':descriptor['original_saved_result_sha256'],'summary':summary,'public_documentation_pending':True,'all_admission_flags':False,'ownership':None};d['active_turn_status'].update(new_include_great_grandchild_physical_text='COMPLETE_CONSUMED_publication_pending',next='FIRSTsummary-publication NEWALL4868savedphysicaltext ONLY/no oldreader-parser-model-SDKquery-Actions-acquisition-archive-numerical replay. Alloriginalmetadata-stat-times-epochs-199DEFERRED-prior6and18links unchanged/allsetupUNADMITTED/RAMrepair-originalimmutableadmission-FINALstrict48/50-cleanCI INCOMPLETE.');d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['updated_at']=d['updated_utc'];cp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(descriptor),flush=True);lease.verify_identity()
